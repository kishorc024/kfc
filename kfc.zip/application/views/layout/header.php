<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>KUSUM Fertility Center </title>
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="description" content="KUSUM - Website">
    <meta name="author" content="merkulove">
    <meta name="keywords" content="">
    <link rel="icon" href="<?= base_url();?>assets/img/favicon.png">
    <link rel="stylesheet" type="text/css" href="<?= base_url();?>assets/css/main.min.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url();?>assets/css/button.min.css">

    <style>
    .shape {
        position: absolute;
        top: 100%;
        left: 0;
        width: 110 px;
        background-color: #d1ebff;
        box-shadow: 0 0 10px rgb(0 0 0 / 10%);
        border-radius: 20px;
        margin-top: 15px;
        padding: 20px;
        z-index: 999999;
        opacity: 10;
        /* visibility: hidden; */
        transition: all .4s ease-in-out;
    }
    </style>
</head>

<body>
    <div class="wrapper">
        <div class="main-section">
            <header>
                <div class="container">
                    <div class="header-content d-flex flex-wrap align-items-center">
                        <div class="logo"><a href="" title="">
                                <img src="<?= base_url();?>assets/images/logo.jpeg" alt=""
                                    srcset="assets/images/logo.jpeg 2x"></a></div>
                        <!--logo end-->
                        <ul class="contact-add d-flex flex-wrap">
                            <li>
                                <div class="contact-info"><img src="<?= base_url();?>assets/img/icon1.png" alt="">
                                    <div class="contact-tt">
                                        <h4>Call</h4><span>+2 342 5446 67</span>
                                    </div>
                                </div>
                                <!--contact-info end-->
                            </li>
                            <li>
                                <div class="contact-info"><img src="<?= base_url();?>assets/img/icon2.png" alt="">
                                    <div class="contact-tt">
                                        <h4>Work Time</h4><span>Mon - Fri 8 AM - 5 PM</span>
                                    </div>
                                </div>
                                <!--contact-info end-->
                            </li>
                            <li>
                                <div class="contact-info"><img src="<?= base_url();?>assets/img/icon3.png" alt="">
                                    <div class="contact-tt">
                                        <h4>Address</h4><span>Shivaji Peth, Kolhapur</span>
                                    </div>
                                </div>
                                <!--contact-info end-->
                            </li>
                        </ul>
                        <!--contact-information end-->
                        <div class="menu-btn"><a href="#"><span class="bar1"></span> <span class="bar2"></span> <span
                                    class="bar3"></span></a></div>
                        <!--menu-btn end-->
                    </div>
                    <!--header-content end-->
                    <div class="navigation-bar d-flex flex-wrap align-items-center">
                        <nav>
                            <ul>
                                <li class="shape text-center"><a class="" href="" title=""><i class="fa fa-home " style="color:#6965A0"></i><br>Home</a></li>
                                <li class="shape text-center"><a class=" " href="" title=""><i class="fa fa-info-circle" style="color:#6965A0"></i><br>About</a></li>
                                <li class="shape text-center"><a class=" " href="" title=""><i class="fa fa-stethoscope" style="color:#6965A0"></i><br>Service</a>
                                    <ul>
                                        <li class="shape"><a href="" title="">IVF Treatments</a></li>
                                        <li class="shape"><a href="" title="">IUI Treatments</a></li>
                                        <li class="shape"><a href="" title="">ICSI Treatments</a></li>
                                        <li class="shape"><a href="" title="">Test Tube Baby</a></li>
                                    </ul>
                                </li>


                                <li class="shape text-center"><a href="" title=""><i class="fa fa-rss" style="color:#6965A0"></i><br>Blogs</a>

                                </li>
                                <li class="shape text-center"><a href="" title=""><i class="fa fa-phone" style="color:#6965A0"></i><br>Contacts</a></li>
                            </ul>
                        </nav>
                        <!--nav end-->
                        <ul class="social-links ml-auto">
                            <li><a href="#" title=""><i class="fab fa-facebook-f"></i></a></li>
                            <li><a href="#" title=""><i class="fab fa-linkedin-in"></i></a></li>
                            <li><a href="#" title=""><i class="fab fa-instagram"></i></a></li>
                        </ul>
                    </div>
                    <!--navigation-bar end-->
                </div>
            </header>
            <!--header end-->
            <div class="responsive-menu">
                <ul>
                    <li><a href="" title="">Home</a></li>
                    <li><a href="about.html" title="">About</a></li>
                    <li><a href="events.html" title="">Events</a></li>
                    <li><a href="event-single.html" title="">Event Single</a></li>
                    <li><a href="schedule.html" title="">Schedule</a></li>
                    <li><a href="classes.html" title="">Classes</a></li>
                    <li><a href="class-single.html" title="">Classe Single</a></li>
                    <li><a href="teachers.html" title="">Teachers</a></li>
                    <li><a href="teacher-single.html" title="">Teacher Single</a></li>
                    <li><a href="blog.html" title="">Blog</a></li>
                    <li><a href="post.html" title="">Blog Single</a></li>
                    <li><a href="contacts.html" title="">Contacts</a></li>
                    <li><a href="error.html" title="">404</a></li>
                </ul>
            </div>
            <!--responsive-menu end-->