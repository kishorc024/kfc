<section class="page-title-area" style="background-color:black">
    
    <div class="container">
        <div class="row" >
            <div class="col-md-12">
                <!-- <div class="page-titleV1">
                    <h2>SUCCESS STORIES</h2>
                </div> -->
            </div>
        </div>
        
    </div>
</section>
<section class="blog-page-wrapper section-padding">
    <div class="container">
        <div class="row">
            
            <div class="col-md-12 order-sm-1 order-md-2 order-1">
                <div class="blog-wrapper">
                    <div class="row">
                    <?php
                                
                                foreach ($result as $row) {
                                    ?>
                        <div class="col-md-4">
                            <div class="single-blogV3">
                                <!-- <div class="sb-img">
                                    <a href="blog-details-1.html"><img src="assets/img/blog/bp3-1.jpg" alt=""></a>
                                </div> -->
                                <div class="sb-text">
                                    <div class="sb-date">
                                        <span>
                                        <?=  date_format(date_create($row->createdon), "F j, Y") ?></span>
                                    </div>
                                    <div class="sbt">
                                        <a href="<?= base_url('blog/view/'.$row->urltitle);?>" title="<?= $row->title;?>"><?= $row->title;?></a>
                                        <p></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php }?>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</section>