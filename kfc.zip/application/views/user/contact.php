<section class="page-title-area">
    <div class="pta-bg">
        <img src="assets/img/bg/pta-1.jpg" alt="">
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="page-titleV1">
                    <h2>CONTACT</h2>
                </div>
            </div>
        </div>
        
    </div>
</section>


<section class="contact-area section-padding">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="contact-info">
                    <h4>Contact Info:</h4>
                    <div class="ci-single">
                        <div class="cis-icon">
                            <i class="fa fa-phone" aria-hidden="true"></i>
                        </div>
                        <div class="cis-text">
                            <p><a style="font-size:20px" href="tel:+91 8080064746"> +91 8080064746</a></p>
                            <p><a style="font-size:20px" href="tel:+91 9834484160"> +91 9834484160</a></p>  
                        </div>
                    </div>
                    <div class="ci-single">
                        <div class="cis-icon">
                            <i class="fa fa-envelope" aria-hidden="true"></i>
                        </div>
                        <div class="cis-text">
                            <p><a style="font-size:18px" href="mailto:fitnessatchangeme@gmail.com"> fitnessatchangeme@gmail.com</a></p>
                        </div>
                    </div>
                    <div class="ci-single">
                        <div class="cis-icon">
                            <i class="fa fa-map-marker" aria-hidden="true"></i>
                        </div>
                        <div class="cis-text">
                            <p>Plot No. 76, Lane No. 6, <br>Hari Om Nagar, Rankala, Kolhapur,<br> Maharashtra, 416012.</p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- <div class="col-md-6">
                <div class="cp-wrapper">
                    <h4>Drop Us a Message:</h4>
                    <form class="cf" method="post"
                        action="" id="cf">
                        <div class="form-group">
                            <input type="text" class="form-control" id="firstName" name="firstName"
                                placeholder="Your Name">
                        </div>
                        <div class="form-group">
                            <input type="email" class="form-control" id="email" name="email"
                                placeholder="Your Email Address" required="">
                        </div>
                        <div class="form-group">
                            <textarea class="form-control" id="msg" name="msg"
                                placeholder="Message Details*"></textarea>
                        </div>
                        <button type="submit" id="submit" name="submit" class="cf-btn">Send Now</button>
                        <div class="cf-msg"></div>
                    </form>
                </div>
            </div> -->
            <div class="col-md-6">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3821.734982352814!2d74.2064422!3d16.6901401!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc1aaa4ca71ed9b%3A0x5a055abbfa621ba1!2sCHANGE%20ME%20FUNCTIONAL%20TRAINING%20%26%20PILATES%20STUDIO!5e0!3m2!1sen!2sin!4v1627967757846!5m2!1sen!2sin" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                
            </div>
        </div>
    </div>
</section>