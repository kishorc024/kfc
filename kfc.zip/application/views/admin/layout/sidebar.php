<div class="sidebar" id="sidebar">
    <div class="sidebar-inner slimscroll">
        <div id="sidebar-menu" class="sidebar-menu">
            <ul>
                <li>
                    <a href="<?php echo base_url('admin'); ?>"><i class="fa fa-dashboard"></i>
                        <span>Dashboard</span></a>
                </li>                
               
                <li>
                    <a href="<?php echo base_url('admin/testimonials'); ?>"><i class="fa fa-comments"></i>
                        <span>Testimonials</span></a>
				</li>  
                <li>
                    <a href="<?php echo base_url('admin/blogs'); ?>"><i class="fa fa-tasks"></i>
                        <span>Blogs</span></a>
				</li>               
                
                <li>
                    <a href="<?php echo base_url('logout'); ?>"><i class="fa fa-sign-out"></i>
                        <span>Logout</span></a>
                </li>               
            </ul>
        </div>
    </div>
</div>
