<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-10-28 16:08:26 --> Config Class Initialized
INFO - 2021-10-28 16:08:26 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:08:26 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:26 --> Utf8 Class Initialized
INFO - 2021-10-28 16:08:26 --> URI Class Initialized
DEBUG - 2021-10-28 16:08:26 --> No URI present. Default controller set.
INFO - 2021-10-28 16:08:26 --> Router Class Initialized
INFO - 2021-10-28 16:08:26 --> Output Class Initialized
INFO - 2021-10-28 16:08:26 --> Security Class Initialized
DEBUG - 2021-10-28 16:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:26 --> Input Class Initialized
INFO - 2021-10-28 16:08:26 --> Language Class Initialized
INFO - 2021-10-28 16:08:26 --> Loader Class Initialized
INFO - 2021-10-28 16:08:26 --> Helper loaded: url_helper
INFO - 2021-10-28 16:08:26 --> Helper loaded: file_helper
DEBUG - 2021-10-28 16:08:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-28 16:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-28 16:08:26 --> Controller Class Initialized
INFO - 2021-10-28 16:08:26 --> Helper loaded: cookie_helper
INFO - 2021-10-28 16:08:26 --> Model "CookieModel" initialized
INFO - 2021-10-28 16:08:26 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-28 16:08:26 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-28 16:08:26 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-28 16:08:26 --> Final output sent to browser
DEBUG - 2021-10-28 16:08:26 --> Total execution time: 0.0706
INFO - 2021-10-28 16:08:26 --> Config Class Initialized
INFO - 2021-10-28 16:08:26 --> Hooks Class Initialized
INFO - 2021-10-28 16:08:26 --> Config Class Initialized
INFO - 2021-10-28 16:08:26 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:08:26 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:26 --> Utf8 Class Initialized
DEBUG - 2021-10-28 16:08:26 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:26 --> Utf8 Class Initialized
INFO - 2021-10-28 16:08:26 --> URI Class Initialized
INFO - 2021-10-28 16:08:26 --> URI Class Initialized
INFO - 2021-10-28 16:08:26 --> Router Class Initialized
INFO - 2021-10-28 16:08:26 --> Router Class Initialized
INFO - 2021-10-28 16:08:26 --> Output Class Initialized
INFO - 2021-10-28 16:08:26 --> Security Class Initialized
INFO - 2021-10-28 16:08:26 --> Output Class Initialized
INFO - 2021-10-28 16:08:26 --> Security Class Initialized
DEBUG - 2021-10-28 16:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:26 --> Input Class Initialized
DEBUG - 2021-10-28 16:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:26 --> Input Class Initialized
INFO - 2021-10-28 16:08:26 --> Language Class Initialized
INFO - 2021-10-28 16:08:26 --> Language Class Initialized
INFO - 2021-10-28 16:08:26 --> Config Class Initialized
INFO - 2021-10-28 16:08:26 --> Hooks Class Initialized
ERROR - 2021-10-28 16:08:26 --> 404 Page Not Found: Assets/css
ERROR - 2021-10-28 16:08:26 --> 404 Page Not Found: Assets/css
INFO - 2021-10-28 16:08:26 --> Config Class Initialized
DEBUG - 2021-10-28 16:08:26 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:26 --> Hooks Class Initialized
INFO - 2021-10-28 16:08:26 --> Config Class Initialized
INFO - 2021-10-28 16:08:26 --> Utf8 Class Initialized
INFO - 2021-10-28 16:08:26 --> Hooks Class Initialized
INFO - 2021-10-28 16:08:26 --> URI Class Initialized
DEBUG - 2021-10-28 16:08:26 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:26 --> Utf8 Class Initialized
DEBUG - 2021-10-28 16:08:26 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:26 --> Router Class Initialized
INFO - 2021-10-28 16:08:26 --> Utf8 Class Initialized
INFO - 2021-10-28 16:08:26 --> URI Class Initialized
INFO - 2021-10-28 16:08:26 --> URI Class Initialized
INFO - 2021-10-28 16:08:26 --> Output Class Initialized
INFO - 2021-10-28 16:08:26 --> Router Class Initialized
INFO - 2021-10-28 16:08:26 --> Router Class Initialized
INFO - 2021-10-28 16:08:26 --> Security Class Initialized
INFO - 2021-10-28 16:08:26 --> Output Class Initialized
INFO - 2021-10-28 16:08:26 --> Output Class Initialized
DEBUG - 2021-10-28 16:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:26 --> Input Class Initialized
INFO - 2021-10-28 16:08:26 --> Language Class Initialized
INFO - 2021-10-28 16:08:26 --> Security Class Initialized
INFO - 2021-10-28 16:08:26 --> Security Class Initialized
ERROR - 2021-10-28 16:08:26 --> 404 Page Not Found: Assets/css
DEBUG - 2021-10-28 16:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:26 --> Input Class Initialized
DEBUG - 2021-10-28 16:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:26 --> Input Class Initialized
INFO - 2021-10-28 16:08:26 --> Language Class Initialized
INFO - 2021-10-28 16:08:26 --> Language Class Initialized
ERROR - 2021-10-28 16:08:26 --> 404 Page Not Found: Assets/fonts
ERROR - 2021-10-28 16:08:26 --> 404 Page Not Found: Assets/css
INFO - 2021-10-28 16:08:26 --> Config Class Initialized
INFO - 2021-10-28 16:08:26 --> Hooks Class Initialized
INFO - 2021-10-28 16:08:26 --> Config Class Initialized
INFO - 2021-10-28 16:08:26 --> Hooks Class Initialized
INFO - 2021-10-28 16:08:26 --> Config Class Initialized
INFO - 2021-10-28 16:08:26 --> Config Class Initialized
INFO - 2021-10-28 16:08:26 --> Hooks Class Initialized
INFO - 2021-10-28 16:08:26 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:08:26 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:26 --> Utf8 Class Initialized
DEBUG - 2021-10-28 16:08:26 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:26 --> Utf8 Class Initialized
INFO - 2021-10-28 16:08:26 --> URI Class Initialized
DEBUG - 2021-10-28 16:08:26 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:26 --> Utf8 Class Initialized
DEBUG - 2021-10-28 16:08:26 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:26 --> Utf8 Class Initialized
INFO - 2021-10-28 16:08:26 --> URI Class Initialized
INFO - 2021-10-28 16:08:26 --> URI Class Initialized
INFO - 2021-10-28 16:08:26 --> Router Class Initialized
INFO - 2021-10-28 16:08:26 --> URI Class Initialized
INFO - 2021-10-28 16:08:26 --> Router Class Initialized
INFO - 2021-10-28 16:08:26 --> Router Class Initialized
INFO - 2021-10-28 16:08:26 --> Router Class Initialized
INFO - 2021-10-28 16:08:26 --> Output Class Initialized
INFO - 2021-10-28 16:08:26 --> Output Class Initialized
INFO - 2021-10-28 16:08:26 --> Output Class Initialized
INFO - 2021-10-28 16:08:26 --> Security Class Initialized
INFO - 2021-10-28 16:08:26 --> Security Class Initialized
INFO - 2021-10-28 16:08:26 --> Security Class Initialized
DEBUG - 2021-10-28 16:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-10-28 16:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-10-28 16:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:26 --> Input Class Initialized
INFO - 2021-10-28 16:08:26 --> Input Class Initialized
INFO - 2021-10-28 16:08:26 --> Input Class Initialized
INFO - 2021-10-28 16:08:26 --> Language Class Initialized
INFO - 2021-10-28 16:08:26 --> Language Class Initialized
INFO - 2021-10-28 16:08:26 --> Language Class Initialized
INFO - 2021-10-28 16:08:26 --> Output Class Initialized
ERROR - 2021-10-28 16:08:26 --> 404 Page Not Found: Assets/css
ERROR - 2021-10-28 16:08:26 --> 404 Page Not Found: Assets/css
ERROR - 2021-10-28 16:08:26 --> 404 Page Not Found: Assets/css
INFO - 2021-10-28 16:08:26 --> Security Class Initialized
DEBUG - 2021-10-28 16:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:26 --> Input Class Initialized
INFO - 2021-10-28 16:08:26 --> Language Class Initialized
ERROR - 2021-10-28 16:08:26 --> 404 Page Not Found: Assets/css
INFO - 2021-10-28 16:08:26 --> Config Class Initialized
INFO - 2021-10-28 16:08:26 --> Hooks Class Initialized
INFO - 2021-10-28 16:08:26 --> Config Class Initialized
INFO - 2021-10-28 16:08:26 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:08:26 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:26 --> Utf8 Class Initialized
DEBUG - 2021-10-28 16:08:26 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:26 --> URI Class Initialized
INFO - 2021-10-28 16:08:26 --> Utf8 Class Initialized
INFO - 2021-10-28 16:08:26 --> URI Class Initialized
INFO - 2021-10-28 16:08:26 --> Router Class Initialized
INFO - 2021-10-28 16:08:26 --> Router Class Initialized
INFO - 2021-10-28 16:08:26 --> Output Class Initialized
INFO - 2021-10-28 16:08:26 --> Output Class Initialized
INFO - 2021-10-28 16:08:26 --> Security Class Initialized
INFO - 2021-10-28 16:08:26 --> Security Class Initialized
DEBUG - 2021-10-28 16:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:26 --> Input Class Initialized
INFO - 2021-10-28 16:08:26 --> Language Class Initialized
DEBUG - 2021-10-28 16:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:26 --> Input Class Initialized
INFO - 2021-10-28 16:08:26 --> Language Class Initialized
ERROR - 2021-10-28 16:08:26 --> 404 Page Not Found: Assets/css
ERROR - 2021-10-28 16:08:26 --> 404 Page Not Found: Assets/css
INFO - 2021-10-28 16:08:26 --> Config Class Initialized
INFO - 2021-10-28 16:08:26 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:08:26 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:26 --> Utf8 Class Initialized
INFO - 2021-10-28 16:08:26 --> URI Class Initialized
INFO - 2021-10-28 16:08:26 --> Router Class Initialized
INFO - 2021-10-28 16:08:26 --> Output Class Initialized
INFO - 2021-10-28 16:08:26 --> Security Class Initialized
INFO - 2021-10-28 16:08:26 --> Config Class Initialized
INFO - 2021-10-28 16:08:26 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:26 --> Input Class Initialized
INFO - 2021-10-28 16:08:26 --> Language Class Initialized
ERROR - 2021-10-28 16:08:26 --> 404 Page Not Found: Assets/js
DEBUG - 2021-10-28 16:08:26 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:26 --> Utf8 Class Initialized
INFO - 2021-10-28 16:08:26 --> URI Class Initialized
INFO - 2021-10-28 16:08:26 --> Router Class Initialized
INFO - 2021-10-28 16:08:27 --> Output Class Initialized
INFO - 2021-10-28 16:08:27 --> Config Class Initialized
INFO - 2021-10-28 16:08:27 --> Security Class Initialized
INFO - 2021-10-28 16:08:27 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:27 --> Input Class Initialized
INFO - 2021-10-28 16:08:27 --> Language Class Initialized
DEBUG - 2021-10-28 16:08:27 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:27 --> Utf8 Class Initialized
ERROR - 2021-10-28 16:08:27 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:08:27 --> URI Class Initialized
INFO - 2021-10-28 16:08:27 --> Router Class Initialized
INFO - 2021-10-28 16:08:27 --> Output Class Initialized
INFO - 2021-10-28 16:08:27 --> Security Class Initialized
DEBUG - 2021-10-28 16:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:27 --> Input Class Initialized
INFO - 2021-10-28 16:08:27 --> Language Class Initialized
ERROR - 2021-10-28 16:08:27 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:08:27 --> Config Class Initialized
INFO - 2021-10-28 16:08:27 --> Hooks Class Initialized
INFO - 2021-10-28 16:08:27 --> Config Class Initialized
INFO - 2021-10-28 16:08:27 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:08:27 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:27 --> Utf8 Class Initialized
DEBUG - 2021-10-28 16:08:27 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:27 --> Utf8 Class Initialized
INFO - 2021-10-28 16:08:27 --> URI Class Initialized
INFO - 2021-10-28 16:08:27 --> URI Class Initialized
INFO - 2021-10-28 16:08:27 --> Router Class Initialized
INFO - 2021-10-28 16:08:27 --> Router Class Initialized
INFO - 2021-10-28 16:08:27 --> Config Class Initialized
INFO - 2021-10-28 16:08:27 --> Hooks Class Initialized
INFO - 2021-10-28 16:08:27 --> Output Class Initialized
INFO - 2021-10-28 16:08:27 --> Output Class Initialized
INFO - 2021-10-28 16:08:27 --> Security Class Initialized
DEBUG - 2021-10-28 16:08:27 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:27 --> Utf8 Class Initialized
INFO - 2021-10-28 16:08:27 --> Security Class Initialized
INFO - 2021-10-28 16:08:27 --> URI Class Initialized
DEBUG - 2021-10-28 16:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:27 --> Input Class Initialized
INFO - 2021-10-28 16:08:27 --> Language Class Initialized
INFO - 2021-10-28 16:08:27 --> Router Class Initialized
ERROR - 2021-10-28 16:08:27 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:08:27 --> Output Class Initialized
DEBUG - 2021-10-28 16:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:27 --> Input Class Initialized
INFO - 2021-10-28 16:08:27 --> Language Class Initialized
INFO - 2021-10-28 16:08:27 --> Security Class Initialized
ERROR - 2021-10-28 16:08:27 --> 404 Page Not Found: Assets/js
DEBUG - 2021-10-28 16:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:27 --> Input Class Initialized
INFO - 2021-10-28 16:08:27 --> Language Class Initialized
ERROR - 2021-10-28 16:08:27 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:08:27 --> Config Class Initialized
INFO - 2021-10-28 16:08:27 --> Hooks Class Initialized
INFO - 2021-10-28 16:08:27 --> Config Class Initialized
INFO - 2021-10-28 16:08:27 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:08:27 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:27 --> Utf8 Class Initialized
DEBUG - 2021-10-28 16:08:27 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:27 --> URI Class Initialized
INFO - 2021-10-28 16:08:27 --> Utf8 Class Initialized
INFO - 2021-10-28 16:08:27 --> URI Class Initialized
INFO - 2021-10-28 16:08:27 --> Router Class Initialized
INFO - 2021-10-28 16:08:27 --> Router Class Initialized
INFO - 2021-10-28 16:08:27 --> Output Class Initialized
INFO - 2021-10-28 16:08:27 --> Output Class Initialized
INFO - 2021-10-28 16:08:27 --> Security Class Initialized
INFO - 2021-10-28 16:08:27 --> Security Class Initialized
DEBUG - 2021-10-28 16:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:27 --> Input Class Initialized
INFO - 2021-10-28 16:08:27 --> Language Class Initialized
DEBUG - 2021-10-28 16:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:27 --> Input Class Initialized
INFO - 2021-10-28 16:08:27 --> Language Class Initialized
ERROR - 2021-10-28 16:08:27 --> 404 Page Not Found: Assets/js
ERROR - 2021-10-28 16:08:27 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:08:27 --> Config Class Initialized
INFO - 2021-10-28 16:08:27 --> Hooks Class Initialized
INFO - 2021-10-28 16:08:27 --> Config Class Initialized
INFO - 2021-10-28 16:08:27 --> Hooks Class Initialized
INFO - 2021-10-28 16:08:27 --> Config Class Initialized
DEBUG - 2021-10-28 16:08:27 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:27 --> Hooks Class Initialized
INFO - 2021-10-28 16:08:27 --> Utf8 Class Initialized
DEBUG - 2021-10-28 16:08:27 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:27 --> Utf8 Class Initialized
INFO - 2021-10-28 16:08:27 --> Config Class Initialized
INFO - 2021-10-28 16:08:27 --> Hooks Class Initialized
INFO - 2021-10-28 16:08:27 --> URI Class Initialized
INFO - 2021-10-28 16:08:27 --> URI Class Initialized
INFO - 2021-10-28 16:08:27 --> Router Class Initialized
INFO - 2021-10-28 16:08:27 --> Router Class Initialized
DEBUG - 2021-10-28 16:08:27 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:27 --> Utf8 Class Initialized
INFO - 2021-10-28 16:08:27 --> URI Class Initialized
INFO - 2021-10-28 16:08:27 --> Output Class Initialized
INFO - 2021-10-28 16:08:27 --> Output Class Initialized
INFO - 2021-10-28 16:08:27 --> Router Class Initialized
INFO - 2021-10-28 16:08:27 --> Security Class Initialized
INFO - 2021-10-28 16:08:27 --> Security Class Initialized
INFO - 2021-10-28 16:08:27 --> Output Class Initialized
DEBUG - 2021-10-28 16:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:27 --> Input Class Initialized
DEBUG - 2021-10-28 16:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:27 --> Input Class Initialized
INFO - 2021-10-28 16:08:27 --> Language Class Initialized
INFO - 2021-10-28 16:08:27 --> Security Class Initialized
INFO - 2021-10-28 16:08:27 --> Language Class Initialized
DEBUG - 2021-10-28 16:08:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-10-28 16:08:27 --> 404 Page Not Found: Assets/js
ERROR - 2021-10-28 16:08:27 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:08:27 --> Input Class Initialized
INFO - 2021-10-28 16:08:27 --> Language Class Initialized
ERROR - 2021-10-28 16:08:27 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:08:27 --> Config Class Initialized
INFO - 2021-10-28 16:08:27 --> Hooks Class Initialized
INFO - 2021-10-28 16:08:27 --> Config Class Initialized
INFO - 2021-10-28 16:08:27 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:08:27 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:27 --> Utf8 Class Initialized
INFO - 2021-10-28 16:08:27 --> URI Class Initialized
DEBUG - 2021-10-28 16:08:27 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:27 --> Utf8 Class Initialized
DEBUG - 2021-10-28 16:08:27 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:27 --> Utf8 Class Initialized
INFO - 2021-10-28 16:08:27 --> URI Class Initialized
INFO - 2021-10-28 16:08:27 --> Router Class Initialized
INFO - 2021-10-28 16:08:27 --> URI Class Initialized
INFO - 2021-10-28 16:08:27 --> Router Class Initialized
INFO - 2021-10-28 16:08:27 --> Output Class Initialized
INFO - 2021-10-28 16:08:27 --> Router Class Initialized
INFO - 2021-10-28 16:08:27 --> Security Class Initialized
INFO - 2021-10-28 16:08:27 --> Output Class Initialized
INFO - 2021-10-28 16:08:27 --> Output Class Initialized
DEBUG - 2021-10-28 16:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:27 --> Security Class Initialized
INFO - 2021-10-28 16:08:27 --> Input Class Initialized
INFO - 2021-10-28 16:08:27 --> Language Class Initialized
DEBUG - 2021-10-28 16:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:27 --> Input Class Initialized
INFO - 2021-10-28 16:08:27 --> Security Class Initialized
ERROR - 2021-10-28 16:08:27 --> 404 Page Not Found: Assets/fonts
INFO - 2021-10-28 16:08:27 --> Language Class Initialized
DEBUG - 2021-10-28 16:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:27 --> Input Class Initialized
ERROR - 2021-10-28 16:08:27 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:08:27 --> Language Class Initialized
ERROR - 2021-10-28 16:08:27 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:08:27 --> Config Class Initialized
INFO - 2021-10-28 16:08:27 --> Hooks Class Initialized
INFO - 2021-10-28 16:08:27 --> Config Class Initialized
INFO - 2021-10-28 16:08:27 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:08:27 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:27 --> Utf8 Class Initialized
DEBUG - 2021-10-28 16:08:27 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:27 --> Utf8 Class Initialized
INFO - 2021-10-28 16:08:27 --> URI Class Initialized
INFO - 2021-10-28 16:08:27 --> Router Class Initialized
INFO - 2021-10-28 16:08:27 --> Config Class Initialized
INFO - 2021-10-28 16:08:27 --> Hooks Class Initialized
INFO - 2021-10-28 16:08:27 --> Config Class Initialized
INFO - 2021-10-28 16:08:27 --> Hooks Class Initialized
INFO - 2021-10-28 16:08:27 --> Output Class Initialized
DEBUG - 2021-10-28 16:08:27 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:27 --> Utf8 Class Initialized
INFO - 2021-10-28 16:08:27 --> Security Class Initialized
DEBUG - 2021-10-28 16:08:27 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:27 --> Utf8 Class Initialized
INFO - 2021-10-28 16:08:27 --> URI Class Initialized
INFO - 2021-10-28 16:08:27 --> URI Class Initialized
DEBUG - 2021-10-28 16:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:27 --> Input Class Initialized
INFO - 2021-10-28 16:08:27 --> Language Class Initialized
INFO - 2021-10-28 16:08:27 --> Router Class Initialized
INFO - 2021-10-28 16:08:27 --> Router Class Initialized
INFO - 2021-10-28 16:08:27 --> Output Class Initialized
INFO - 2021-10-28 16:08:27 --> Output Class Initialized
ERROR - 2021-10-28 16:08:27 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:08:27 --> Security Class Initialized
INFO - 2021-10-28 16:08:27 --> Security Class Initialized
DEBUG - 2021-10-28 16:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:27 --> Input Class Initialized
DEBUG - 2021-10-28 16:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:27 --> URI Class Initialized
INFO - 2021-10-28 16:08:27 --> Input Class Initialized
INFO - 2021-10-28 16:08:27 --> Language Class Initialized
INFO - 2021-10-28 16:08:27 --> Language Class Initialized
INFO - 2021-10-28 16:08:27 --> Router Class Initialized
ERROR - 2021-10-28 16:08:27 --> 404 Page Not Found: Assets/js
ERROR - 2021-10-28 16:08:27 --> 404 Page Not Found: Assets/images
INFO - 2021-10-28 16:08:27 --> Output Class Initialized
INFO - 2021-10-28 16:08:27 --> Security Class Initialized
DEBUG - 2021-10-28 16:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:27 --> Input Class Initialized
INFO - 2021-10-28 16:08:27 --> Language Class Initialized
ERROR - 2021-10-28 16:08:27 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:08:27 --> Config Class Initialized
INFO - 2021-10-28 16:08:27 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:08:27 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:27 --> Utf8 Class Initialized
INFO - 2021-10-28 16:08:27 --> URI Class Initialized
INFO - 2021-10-28 16:08:27 --> Router Class Initialized
INFO - 2021-10-28 16:08:27 --> Output Class Initialized
INFO - 2021-10-28 16:08:27 --> Security Class Initialized
DEBUG - 2021-10-28 16:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:27 --> Input Class Initialized
INFO - 2021-10-28 16:08:27 --> Language Class Initialized
ERROR - 2021-10-28 16:08:27 --> 404 Page Not Found: Assets/images
INFO - 2021-10-28 16:08:28 --> Config Class Initialized
INFO - 2021-10-28 16:08:28 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:08:28 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:28 --> Utf8 Class Initialized
INFO - 2021-10-28 16:08:28 --> URI Class Initialized
INFO - 2021-10-28 16:08:28 --> Router Class Initialized
INFO - 2021-10-28 16:08:28 --> Output Class Initialized
INFO - 2021-10-28 16:08:28 --> Security Class Initialized
DEBUG - 2021-10-28 16:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:28 --> Input Class Initialized
INFO - 2021-10-28 16:08:28 --> Language Class Initialized
ERROR - 2021-10-28 16:08:28 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:08:28 --> Config Class Initialized
INFO - 2021-10-28 16:08:28 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:08:28 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:28 --> Utf8 Class Initialized
INFO - 2021-10-28 16:08:28 --> URI Class Initialized
INFO - 2021-10-28 16:08:28 --> Router Class Initialized
INFO - 2021-10-28 16:08:28 --> Output Class Initialized
INFO - 2021-10-28 16:08:28 --> Security Class Initialized
DEBUG - 2021-10-28 16:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:28 --> Input Class Initialized
INFO - 2021-10-28 16:08:28 --> Language Class Initialized
ERROR - 2021-10-28 16:08:28 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:08:28 --> Config Class Initialized
INFO - 2021-10-28 16:08:28 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:08:28 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:28 --> Utf8 Class Initialized
INFO - 2021-10-28 16:08:28 --> URI Class Initialized
INFO - 2021-10-28 16:08:28 --> Router Class Initialized
INFO - 2021-10-28 16:08:28 --> Output Class Initialized
INFO - 2021-10-28 16:08:28 --> Security Class Initialized
DEBUG - 2021-10-28 16:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:28 --> Input Class Initialized
INFO - 2021-10-28 16:08:28 --> Language Class Initialized
ERROR - 2021-10-28 16:08:28 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:08:28 --> Config Class Initialized
INFO - 2021-10-28 16:08:28 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:08:28 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:28 --> Utf8 Class Initialized
INFO - 2021-10-28 16:08:28 --> URI Class Initialized
INFO - 2021-10-28 16:08:28 --> Router Class Initialized
INFO - 2021-10-28 16:08:28 --> Output Class Initialized
INFO - 2021-10-28 16:08:28 --> Security Class Initialized
DEBUG - 2021-10-28 16:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:28 --> Input Class Initialized
INFO - 2021-10-28 16:08:28 --> Language Class Initialized
ERROR - 2021-10-28 16:08:28 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:08:28 --> Config Class Initialized
INFO - 2021-10-28 16:08:28 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:08:28 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:28 --> Utf8 Class Initialized
INFO - 2021-10-28 16:08:28 --> URI Class Initialized
INFO - 2021-10-28 16:08:28 --> Router Class Initialized
INFO - 2021-10-28 16:08:28 --> Output Class Initialized
INFO - 2021-10-28 16:08:28 --> Security Class Initialized
DEBUG - 2021-10-28 16:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:28 --> Input Class Initialized
INFO - 2021-10-28 16:08:28 --> Language Class Initialized
ERROR - 2021-10-28 16:08:28 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:08:28 --> Config Class Initialized
INFO - 2021-10-28 16:08:28 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:08:28 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:28 --> Utf8 Class Initialized
INFO - 2021-10-28 16:08:28 --> URI Class Initialized
INFO - 2021-10-28 16:08:28 --> Router Class Initialized
INFO - 2021-10-28 16:08:28 --> Output Class Initialized
INFO - 2021-10-28 16:08:28 --> Security Class Initialized
DEBUG - 2021-10-28 16:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:28 --> Input Class Initialized
INFO - 2021-10-28 16:08:28 --> Language Class Initialized
ERROR - 2021-10-28 16:08:28 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:08:28 --> Config Class Initialized
INFO - 2021-10-28 16:08:28 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:08:28 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:28 --> Utf8 Class Initialized
INFO - 2021-10-28 16:08:28 --> URI Class Initialized
INFO - 2021-10-28 16:08:28 --> Router Class Initialized
INFO - 2021-10-28 16:08:28 --> Output Class Initialized
INFO - 2021-10-28 16:08:28 --> Security Class Initialized
DEBUG - 2021-10-28 16:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:28 --> Input Class Initialized
INFO - 2021-10-28 16:08:28 --> Language Class Initialized
ERROR - 2021-10-28 16:08:28 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:08:28 --> Config Class Initialized
INFO - 2021-10-28 16:08:28 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:08:28 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:28 --> Utf8 Class Initialized
INFO - 2021-10-28 16:08:28 --> URI Class Initialized
INFO - 2021-10-28 16:08:28 --> Router Class Initialized
INFO - 2021-10-28 16:08:28 --> Output Class Initialized
INFO - 2021-10-28 16:08:28 --> Security Class Initialized
DEBUG - 2021-10-28 16:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:28 --> Input Class Initialized
INFO - 2021-10-28 16:08:28 --> Language Class Initialized
ERROR - 2021-10-28 16:08:28 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:08:28 --> Config Class Initialized
INFO - 2021-10-28 16:08:28 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:08:28 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:28 --> Utf8 Class Initialized
INFO - 2021-10-28 16:08:28 --> URI Class Initialized
INFO - 2021-10-28 16:08:28 --> Router Class Initialized
INFO - 2021-10-28 16:08:28 --> Output Class Initialized
INFO - 2021-10-28 16:08:28 --> Security Class Initialized
DEBUG - 2021-10-28 16:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:28 --> Input Class Initialized
INFO - 2021-10-28 16:08:28 --> Language Class Initialized
ERROR - 2021-10-28 16:08:28 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:08:28 --> Config Class Initialized
INFO - 2021-10-28 16:08:28 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:08:28 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:28 --> Utf8 Class Initialized
INFO - 2021-10-28 16:08:28 --> URI Class Initialized
INFO - 2021-10-28 16:08:28 --> Router Class Initialized
INFO - 2021-10-28 16:08:28 --> Output Class Initialized
INFO - 2021-10-28 16:08:28 --> Security Class Initialized
DEBUG - 2021-10-28 16:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:28 --> Input Class Initialized
INFO - 2021-10-28 16:08:28 --> Language Class Initialized
ERROR - 2021-10-28 16:08:28 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:08:28 --> Config Class Initialized
INFO - 2021-10-28 16:08:28 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:08:28 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:28 --> Utf8 Class Initialized
INFO - 2021-10-28 16:08:28 --> URI Class Initialized
INFO - 2021-10-28 16:08:28 --> Router Class Initialized
INFO - 2021-10-28 16:08:28 --> Output Class Initialized
INFO - 2021-10-28 16:08:28 --> Security Class Initialized
DEBUG - 2021-10-28 16:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:28 --> Input Class Initialized
INFO - 2021-10-28 16:08:28 --> Language Class Initialized
ERROR - 2021-10-28 16:08:28 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:08:28 --> Config Class Initialized
INFO - 2021-10-28 16:08:28 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:08:28 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:28 --> Utf8 Class Initialized
INFO - 2021-10-28 16:08:28 --> URI Class Initialized
INFO - 2021-10-28 16:08:28 --> Router Class Initialized
INFO - 2021-10-28 16:08:28 --> Output Class Initialized
INFO - 2021-10-28 16:08:28 --> Security Class Initialized
DEBUG - 2021-10-28 16:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:28 --> Input Class Initialized
INFO - 2021-10-28 16:08:28 --> Language Class Initialized
ERROR - 2021-10-28 16:08:28 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:08:28 --> Config Class Initialized
INFO - 2021-10-28 16:08:28 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:08:28 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:28 --> Utf8 Class Initialized
INFO - 2021-10-28 16:08:28 --> URI Class Initialized
INFO - 2021-10-28 16:08:28 --> Router Class Initialized
INFO - 2021-10-28 16:08:28 --> Output Class Initialized
INFO - 2021-10-28 16:08:28 --> Security Class Initialized
DEBUG - 2021-10-28 16:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:28 --> Input Class Initialized
INFO - 2021-10-28 16:08:28 --> Language Class Initialized
ERROR - 2021-10-28 16:08:28 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:08:28 --> Config Class Initialized
INFO - 2021-10-28 16:08:28 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:08:28 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:28 --> Utf8 Class Initialized
INFO - 2021-10-28 16:08:28 --> URI Class Initialized
INFO - 2021-10-28 16:08:28 --> Router Class Initialized
INFO - 2021-10-28 16:08:28 --> Output Class Initialized
INFO - 2021-10-28 16:08:28 --> Security Class Initialized
DEBUG - 2021-10-28 16:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:28 --> Input Class Initialized
INFO - 2021-10-28 16:08:28 --> Language Class Initialized
ERROR - 2021-10-28 16:08:28 --> 404 Page Not Found: Assets/fonts
INFO - 2021-10-28 16:08:28 --> Config Class Initialized
INFO - 2021-10-28 16:08:28 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:08:28 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:28 --> Utf8 Class Initialized
INFO - 2021-10-28 16:08:28 --> URI Class Initialized
INFO - 2021-10-28 16:08:28 --> Router Class Initialized
INFO - 2021-10-28 16:08:28 --> Output Class Initialized
INFO - 2021-10-28 16:08:28 --> Security Class Initialized
DEBUG - 2021-10-28 16:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:28 --> Input Class Initialized
INFO - 2021-10-28 16:08:28 --> Language Class Initialized
ERROR - 2021-10-28 16:08:28 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:08:28 --> Config Class Initialized
INFO - 2021-10-28 16:08:28 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:08:28 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:28 --> Utf8 Class Initialized
INFO - 2021-10-28 16:08:28 --> URI Class Initialized
INFO - 2021-10-28 16:08:28 --> Router Class Initialized
INFO - 2021-10-28 16:08:28 --> Output Class Initialized
INFO - 2021-10-28 16:08:28 --> Security Class Initialized
DEBUG - 2021-10-28 16:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:28 --> Input Class Initialized
INFO - 2021-10-28 16:08:28 --> Language Class Initialized
ERROR - 2021-10-28 16:08:28 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:08:28 --> Config Class Initialized
INFO - 2021-10-28 16:08:28 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:08:28 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:28 --> Utf8 Class Initialized
INFO - 2021-10-28 16:08:28 --> URI Class Initialized
INFO - 2021-10-28 16:08:28 --> Router Class Initialized
INFO - 2021-10-28 16:08:28 --> Output Class Initialized
INFO - 2021-10-28 16:08:28 --> Security Class Initialized
DEBUG - 2021-10-28 16:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:28 --> Input Class Initialized
INFO - 2021-10-28 16:08:28 --> Language Class Initialized
ERROR - 2021-10-28 16:08:28 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:08:28 --> Config Class Initialized
INFO - 2021-10-28 16:08:28 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:08:28 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:28 --> Utf8 Class Initialized
INFO - 2021-10-28 16:08:28 --> URI Class Initialized
INFO - 2021-10-28 16:08:28 --> Router Class Initialized
INFO - 2021-10-28 16:08:28 --> Output Class Initialized
INFO - 2021-10-28 16:08:28 --> Security Class Initialized
DEBUG - 2021-10-28 16:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:28 --> Input Class Initialized
INFO - 2021-10-28 16:08:28 --> Language Class Initialized
ERROR - 2021-10-28 16:08:28 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-28 16:08:29 --> Config Class Initialized
INFO - 2021-10-28 16:08:29 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:08:29 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:08:29 --> Utf8 Class Initialized
INFO - 2021-10-28 16:08:29 --> URI Class Initialized
INFO - 2021-10-28 16:08:29 --> Router Class Initialized
INFO - 2021-10-28 16:08:29 --> Output Class Initialized
INFO - 2021-10-28 16:08:29 --> Security Class Initialized
DEBUG - 2021-10-28 16:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:08:29 --> Input Class Initialized
INFO - 2021-10-28 16:08:29 --> Language Class Initialized
ERROR - 2021-10-28 16:08:29 --> 404 Page Not Found: Assets/images
INFO - 2021-10-28 16:30:23 --> Config Class Initialized
INFO - 2021-10-28 16:30:23 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:23 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:23 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:23 --> URI Class Initialized
DEBUG - 2021-10-28 16:30:23 --> No URI present. Default controller set.
INFO - 2021-10-28 16:30:23 --> Router Class Initialized
INFO - 2021-10-28 16:30:23 --> Output Class Initialized
INFO - 2021-10-28 16:30:23 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:23 --> Input Class Initialized
INFO - 2021-10-28 16:30:23 --> Language Class Initialized
INFO - 2021-10-28 16:30:23 --> Loader Class Initialized
INFO - 2021-10-28 16:30:23 --> Helper loaded: url_helper
INFO - 2021-10-28 16:30:23 --> Helper loaded: file_helper
DEBUG - 2021-10-28 16:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-28 16:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-28 16:30:23 --> Controller Class Initialized
INFO - 2021-10-28 16:30:23 --> Helper loaded: cookie_helper
INFO - 2021-10-28 16:30:23 --> Model "CookieModel" initialized
INFO - 2021-10-28 16:30:23 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-28 16:30:23 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-28 16:30:23 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-28 16:30:23 --> Final output sent to browser
DEBUG - 2021-10-28 16:30:23 --> Total execution time: 0.0549
INFO - 2021-10-28 16:30:23 --> Config Class Initialized
INFO - 2021-10-28 16:30:23 --> Hooks Class Initialized
INFO - 2021-10-28 16:30:23 --> Config Class Initialized
INFO - 2021-10-28 16:30:23 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:23 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:23 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:23 --> URI Class Initialized
DEBUG - 2021-10-28 16:30:23 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:23 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:23 --> Router Class Initialized
INFO - 2021-10-28 16:30:23 --> URI Class Initialized
INFO - 2021-10-28 16:30:23 --> Output Class Initialized
INFO - 2021-10-28 16:30:23 --> Config Class Initialized
INFO - 2021-10-28 16:30:23 --> Hooks Class Initialized
INFO - 2021-10-28 16:30:23 --> Router Class Initialized
INFO - 2021-10-28 16:30:23 --> Output Class Initialized
INFO - 2021-10-28 16:30:23 --> Config Class Initialized
INFO - 2021-10-28 16:30:23 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:23 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:23 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:23 --> Security Class Initialized
INFO - 2021-10-28 16:30:23 --> URI Class Initialized
DEBUG - 2021-10-28 16:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:23 --> Router Class Initialized
INFO - 2021-10-28 16:30:23 --> Input Class Initialized
DEBUG - 2021-10-28 16:30:23 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:23 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:23 --> Language Class Initialized
INFO - 2021-10-28 16:30:23 --> URI Class Initialized
INFO - 2021-10-28 16:30:23 --> Output Class Initialized
ERROR - 2021-10-28 16:30:23 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:23 --> Router Class Initialized
INFO - 2021-10-28 16:30:23 --> Security Class Initialized
INFO - 2021-10-28 16:30:23 --> Output Class Initialized
DEBUG - 2021-10-28 16:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:23 --> Input Class Initialized
INFO - 2021-10-28 16:30:23 --> Language Class Initialized
INFO - 2021-10-28 16:30:23 --> Security Class Initialized
ERROR - 2021-10-28 16:30:23 --> 404 Page Not Found: Assets/js
DEBUG - 2021-10-28 16:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:23 --> Input Class Initialized
INFO - 2021-10-28 16:30:23 --> Language Class Initialized
INFO - 2021-10-28 16:30:23 --> Security Class Initialized
ERROR - 2021-10-28 16:30:23 --> 404 Page Not Found: Assets/js
DEBUG - 2021-10-28 16:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:23 --> Input Class Initialized
INFO - 2021-10-28 16:30:23 --> Language Class Initialized
ERROR - 2021-10-28 16:30:23 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:23 --> Config Class Initialized
INFO - 2021-10-28 16:30:23 --> Config Class Initialized
INFO - 2021-10-28 16:30:23 --> Hooks Class Initialized
INFO - 2021-10-28 16:30:23 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:23 --> UTF-8 Support Enabled
DEBUG - 2021-10-28 16:30:23 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:23 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:23 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:23 --> URI Class Initialized
INFO - 2021-10-28 16:30:23 --> URI Class Initialized
INFO - 2021-10-28 16:30:23 --> Router Class Initialized
INFO - 2021-10-28 16:30:23 --> Router Class Initialized
INFO - 2021-10-28 16:30:23 --> Output Class Initialized
INFO - 2021-10-28 16:30:23 --> Output Class Initialized
INFO - 2021-10-28 16:30:23 --> Security Class Initialized
INFO - 2021-10-28 16:30:23 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:23 --> Input Class Initialized
INFO - 2021-10-28 16:30:23 --> Language Class Initialized
DEBUG - 2021-10-28 16:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:23 --> Config Class Initialized
INFO - 2021-10-28 16:30:23 --> Input Class Initialized
INFO - 2021-10-28 16:30:23 --> Hooks Class Initialized
INFO - 2021-10-28 16:30:23 --> Config Class Initialized
INFO - 2021-10-28 16:30:23 --> Hooks Class Initialized
INFO - 2021-10-28 16:30:23 --> Language Class Initialized
ERROR - 2021-10-28 16:30:23 --> 404 Page Not Found: Assets/js
DEBUG - 2021-10-28 16:30:23 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:23 --> Utf8 Class Initialized
DEBUG - 2021-10-28 16:30:23 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:23 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:23 --> URI Class Initialized
INFO - 2021-10-28 16:30:23 --> URI Class Initialized
INFO - 2021-10-28 16:30:23 --> Router Class Initialized
INFO - 2021-10-28 16:30:23 --> Router Class Initialized
INFO - 2021-10-28 16:30:23 --> Output Class Initialized
INFO - 2021-10-28 16:30:23 --> Output Class Initialized
INFO - 2021-10-28 16:30:23 --> Security Class Initialized
INFO - 2021-10-28 16:30:23 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:23 --> Input Class Initialized
INFO - 2021-10-28 16:30:23 --> Language Class Initialized
DEBUG - 2021-10-28 16:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:23 --> Input Class Initialized
INFO - 2021-10-28 16:30:23 --> Language Class Initialized
ERROR - 2021-10-28 16:30:23 --> 404 Page Not Found: Assets/js
ERROR - 2021-10-28 16:30:23 --> 404 Page Not Found: Assets/js
ERROR - 2021-10-28 16:30:23 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:23 --> Config Class Initialized
INFO - 2021-10-28 16:30:23 --> Hooks Class Initialized
INFO - 2021-10-28 16:30:23 --> Config Class Initialized
INFO - 2021-10-28 16:30:23 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:23 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:23 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:23 --> URI Class Initialized
DEBUG - 2021-10-28 16:30:23 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:23 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:23 --> Router Class Initialized
INFO - 2021-10-28 16:30:23 --> URI Class Initialized
INFO - 2021-10-28 16:30:23 --> Router Class Initialized
INFO - 2021-10-28 16:30:23 --> Output Class Initialized
INFO - 2021-10-28 16:30:23 --> Output Class Initialized
INFO - 2021-10-28 16:30:23 --> Config Class Initialized
INFO - 2021-10-28 16:30:23 --> Security Class Initialized
INFO - 2021-10-28 16:30:23 --> Hooks Class Initialized
INFO - 2021-10-28 16:30:23 --> Config Class Initialized
INFO - 2021-10-28 16:30:23 --> Hooks Class Initialized
INFO - 2021-10-28 16:30:23 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:23 --> Input Class Initialized
INFO - 2021-10-28 16:30:23 --> Language Class Initialized
DEBUG - 2021-10-28 16:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-10-28 16:30:23 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:23 --> Input Class Initialized
INFO - 2021-10-28 16:30:23 --> Utf8 Class Initialized
DEBUG - 2021-10-28 16:30:23 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:23 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:23 --> Language Class Initialized
ERROR - 2021-10-28 16:30:23 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:23 --> URI Class Initialized
INFO - 2021-10-28 16:30:23 --> URI Class Initialized
ERROR - 2021-10-28 16:30:23 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:23 --> Router Class Initialized
INFO - 2021-10-28 16:30:23 --> Router Class Initialized
INFO - 2021-10-28 16:30:23 --> Output Class Initialized
INFO - 2021-10-28 16:30:23 --> Output Class Initialized
INFO - 2021-10-28 16:30:23 --> Security Class Initialized
INFO - 2021-10-28 16:30:23 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-10-28 16:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:23 --> Input Class Initialized
INFO - 2021-10-28 16:30:23 --> Input Class Initialized
INFO - 2021-10-28 16:30:23 --> Language Class Initialized
INFO - 2021-10-28 16:30:23 --> Language Class Initialized
ERROR - 2021-10-28 16:30:23 --> 404 Page Not Found: Assets/js
ERROR - 2021-10-28 16:30:23 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:23 --> Config Class Initialized
INFO - 2021-10-28 16:30:23 --> Config Class Initialized
INFO - 2021-10-28 16:30:23 --> Hooks Class Initialized
INFO - 2021-10-28 16:30:23 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:23 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:23 --> Utf8 Class Initialized
DEBUG - 2021-10-28 16:30:23 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:23 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:23 --> URI Class Initialized
INFO - 2021-10-28 16:30:23 --> URI Class Initialized
INFO - 2021-10-28 16:30:23 --> Router Class Initialized
INFO - 2021-10-28 16:30:23 --> Router Class Initialized
INFO - 2021-10-28 16:30:23 --> Output Class Initialized
INFO - 2021-10-28 16:30:23 --> Output Class Initialized
INFO - 2021-10-28 16:30:23 --> Security Class Initialized
INFO - 2021-10-28 16:30:23 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-10-28 16:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:23 --> Input Class Initialized
INFO - 2021-10-28 16:30:23 --> Input Class Initialized
INFO - 2021-10-28 16:30:23 --> Language Class Initialized
INFO - 2021-10-28 16:30:23 --> Language Class Initialized
ERROR - 2021-10-28 16:30:23 --> 404 Page Not Found: Assets/js
ERROR - 2021-10-28 16:30:23 --> 404 Page Not Found: Assets/fonts
INFO - 2021-10-28 16:30:23 --> Config Class Initialized
INFO - 2021-10-28 16:30:23 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:23 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:23 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:23 --> Config Class Initialized
INFO - 2021-10-28 16:30:23 --> Hooks Class Initialized
INFO - 2021-10-28 16:30:23 --> URI Class Initialized
INFO - 2021-10-28 16:30:23 --> Router Class Initialized
DEBUG - 2021-10-28 16:30:23 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:23 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:23 --> Output Class Initialized
INFO - 2021-10-28 16:30:23 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:23 --> Input Class Initialized
INFO - 2021-10-28 16:30:23 --> Config Class Initialized
INFO - 2021-10-28 16:30:23 --> Hooks Class Initialized
INFO - 2021-10-28 16:30:23 --> Language Class Initialized
DEBUG - 2021-10-28 16:30:24 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:24 --> Utf8 Class Initialized
ERROR - 2021-10-28 16:30:24 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:24 --> URI Class Initialized
INFO - 2021-10-28 16:30:24 --> URI Class Initialized
INFO - 2021-10-28 16:30:24 --> Config Class Initialized
INFO - 2021-10-28 16:30:24 --> Hooks Class Initialized
INFO - 2021-10-28 16:30:24 --> Router Class Initialized
INFO - 2021-10-28 16:30:24 --> Router Class Initialized
INFO - 2021-10-28 16:30:24 --> Output Class Initialized
INFO - 2021-10-28 16:30:24 --> Output Class Initialized
DEBUG - 2021-10-28 16:30:24 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:24 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:24 --> URI Class Initialized
INFO - 2021-10-28 16:30:24 --> Security Class Initialized
INFO - 2021-10-28 16:30:24 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-10-28 16:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:24 --> Input Class Initialized
INFO - 2021-10-28 16:30:24 --> Router Class Initialized
INFO - 2021-10-28 16:30:24 --> Input Class Initialized
INFO - 2021-10-28 16:30:24 --> Language Class Initialized
INFO - 2021-10-28 16:30:24 --> Language Class Initialized
ERROR - 2021-10-28 16:30:24 --> 404 Page Not Found: Assets/images
INFO - 2021-10-28 16:30:24 --> Output Class Initialized
ERROR - 2021-10-28 16:30:24 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:24 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:24 --> Input Class Initialized
INFO - 2021-10-28 16:30:24 --> Language Class Initialized
ERROR - 2021-10-28 16:30:24 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:24 --> Config Class Initialized
INFO - 2021-10-28 16:30:24 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:24 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:24 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:24 --> URI Class Initialized
INFO - 2021-10-28 16:30:24 --> Router Class Initialized
INFO - 2021-10-28 16:30:24 --> Output Class Initialized
INFO - 2021-10-28 16:30:24 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:24 --> Input Class Initialized
INFO - 2021-10-28 16:30:24 --> Language Class Initialized
ERROR - 2021-10-28 16:30:24 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:24 --> Config Class Initialized
INFO - 2021-10-28 16:30:24 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:24 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:24 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:24 --> URI Class Initialized
INFO - 2021-10-28 16:30:24 --> Router Class Initialized
INFO - 2021-10-28 16:30:24 --> Output Class Initialized
INFO - 2021-10-28 16:30:24 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:24 --> Input Class Initialized
INFO - 2021-10-28 16:30:24 --> Language Class Initialized
ERROR - 2021-10-28 16:30:24 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:24 --> Config Class Initialized
INFO - 2021-10-28 16:30:24 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:24 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:24 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:24 --> URI Class Initialized
INFO - 2021-10-28 16:30:24 --> Router Class Initialized
INFO - 2021-10-28 16:30:24 --> Output Class Initialized
INFO - 2021-10-28 16:30:24 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:24 --> Input Class Initialized
INFO - 2021-10-28 16:30:24 --> Language Class Initialized
ERROR - 2021-10-28 16:30:24 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:24 --> Config Class Initialized
INFO - 2021-10-28 16:30:24 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:24 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:24 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:24 --> URI Class Initialized
INFO - 2021-10-28 16:30:24 --> Router Class Initialized
INFO - 2021-10-28 16:30:24 --> Output Class Initialized
INFO - 2021-10-28 16:30:24 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:24 --> Input Class Initialized
INFO - 2021-10-28 16:30:24 --> Language Class Initialized
ERROR - 2021-10-28 16:30:24 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:24 --> Config Class Initialized
INFO - 2021-10-28 16:30:24 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:24 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:24 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:24 --> URI Class Initialized
INFO - 2021-10-28 16:30:24 --> Router Class Initialized
INFO - 2021-10-28 16:30:24 --> Output Class Initialized
INFO - 2021-10-28 16:30:24 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:24 --> Input Class Initialized
INFO - 2021-10-28 16:30:24 --> Language Class Initialized
ERROR - 2021-10-28 16:30:24 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:24 --> Config Class Initialized
INFO - 2021-10-28 16:30:24 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:24 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:24 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:24 --> URI Class Initialized
INFO - 2021-10-28 16:30:24 --> Router Class Initialized
INFO - 2021-10-28 16:30:24 --> Output Class Initialized
INFO - 2021-10-28 16:30:24 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:24 --> Input Class Initialized
INFO - 2021-10-28 16:30:24 --> Language Class Initialized
ERROR - 2021-10-28 16:30:24 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:24 --> Config Class Initialized
INFO - 2021-10-28 16:30:24 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:24 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:24 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:24 --> URI Class Initialized
INFO - 2021-10-28 16:30:24 --> Router Class Initialized
INFO - 2021-10-28 16:30:24 --> Output Class Initialized
INFO - 2021-10-28 16:30:24 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:24 --> Input Class Initialized
INFO - 2021-10-28 16:30:24 --> Language Class Initialized
ERROR - 2021-10-28 16:30:24 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:24 --> Config Class Initialized
INFO - 2021-10-28 16:30:24 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:24 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:24 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:24 --> URI Class Initialized
INFO - 2021-10-28 16:30:24 --> Router Class Initialized
INFO - 2021-10-28 16:30:24 --> Output Class Initialized
INFO - 2021-10-28 16:30:24 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:24 --> Input Class Initialized
INFO - 2021-10-28 16:30:24 --> Language Class Initialized
ERROR - 2021-10-28 16:30:24 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:24 --> Config Class Initialized
INFO - 2021-10-28 16:30:24 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:24 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:24 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:24 --> URI Class Initialized
INFO - 2021-10-28 16:30:24 --> Router Class Initialized
INFO - 2021-10-28 16:30:24 --> Output Class Initialized
INFO - 2021-10-28 16:30:24 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:24 --> Input Class Initialized
INFO - 2021-10-28 16:30:24 --> Language Class Initialized
ERROR - 2021-10-28 16:30:24 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:24 --> Config Class Initialized
INFO - 2021-10-28 16:30:24 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:24 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:24 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:24 --> URI Class Initialized
INFO - 2021-10-28 16:30:24 --> Router Class Initialized
INFO - 2021-10-28 16:30:24 --> Output Class Initialized
INFO - 2021-10-28 16:30:24 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:24 --> Input Class Initialized
INFO - 2021-10-28 16:30:24 --> Language Class Initialized
ERROR - 2021-10-28 16:30:24 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:24 --> Config Class Initialized
INFO - 2021-10-28 16:30:24 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:24 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:24 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:24 --> URI Class Initialized
INFO - 2021-10-28 16:30:24 --> Router Class Initialized
INFO - 2021-10-28 16:30:24 --> Output Class Initialized
INFO - 2021-10-28 16:30:24 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:24 --> Input Class Initialized
INFO - 2021-10-28 16:30:24 --> Language Class Initialized
ERROR - 2021-10-28 16:30:24 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:24 --> Config Class Initialized
INFO - 2021-10-28 16:30:24 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:24 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:24 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:24 --> URI Class Initialized
INFO - 2021-10-28 16:30:24 --> Router Class Initialized
INFO - 2021-10-28 16:30:24 --> Output Class Initialized
INFO - 2021-10-28 16:30:24 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:24 --> Input Class Initialized
INFO - 2021-10-28 16:30:24 --> Language Class Initialized
ERROR - 2021-10-28 16:30:24 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:24 --> Config Class Initialized
INFO - 2021-10-28 16:30:24 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:24 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:24 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:24 --> URI Class Initialized
INFO - 2021-10-28 16:30:24 --> Router Class Initialized
INFO - 2021-10-28 16:30:24 --> Output Class Initialized
INFO - 2021-10-28 16:30:24 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:24 --> Input Class Initialized
INFO - 2021-10-28 16:30:24 --> Language Class Initialized
ERROR - 2021-10-28 16:30:24 --> 404 Page Not Found: Assets/fonts
INFO - 2021-10-28 16:30:24 --> Config Class Initialized
INFO - 2021-10-28 16:30:24 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:24 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:24 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:24 --> URI Class Initialized
INFO - 2021-10-28 16:30:24 --> Router Class Initialized
INFO - 2021-10-28 16:30:24 --> Output Class Initialized
INFO - 2021-10-28 16:30:24 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:24 --> Input Class Initialized
INFO - 2021-10-28 16:30:24 --> Language Class Initialized
ERROR - 2021-10-28 16:30:24 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:24 --> Config Class Initialized
INFO - 2021-10-28 16:30:24 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:24 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:24 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:24 --> URI Class Initialized
INFO - 2021-10-28 16:30:24 --> Router Class Initialized
INFO - 2021-10-28 16:30:24 --> Output Class Initialized
INFO - 2021-10-28 16:30:24 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:24 --> Input Class Initialized
INFO - 2021-10-28 16:30:24 --> Language Class Initialized
ERROR - 2021-10-28 16:30:24 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:24 --> Config Class Initialized
INFO - 2021-10-28 16:30:24 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:24 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:24 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:24 --> URI Class Initialized
INFO - 2021-10-28 16:30:24 --> Router Class Initialized
INFO - 2021-10-28 16:30:24 --> Output Class Initialized
INFO - 2021-10-28 16:30:24 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:24 --> Input Class Initialized
INFO - 2021-10-28 16:30:24 --> Language Class Initialized
ERROR - 2021-10-28 16:30:24 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:35 --> Config Class Initialized
INFO - 2021-10-28 16:30:35 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:35 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:35 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:35 --> URI Class Initialized
DEBUG - 2021-10-28 16:30:35 --> No URI present. Default controller set.
INFO - 2021-10-28 16:30:35 --> Router Class Initialized
INFO - 2021-10-28 16:30:35 --> Output Class Initialized
INFO - 2021-10-28 16:30:35 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:35 --> Input Class Initialized
INFO - 2021-10-28 16:30:35 --> Language Class Initialized
INFO - 2021-10-28 16:30:35 --> Loader Class Initialized
INFO - 2021-10-28 16:30:35 --> Helper loaded: url_helper
INFO - 2021-10-28 16:30:35 --> Helper loaded: file_helper
DEBUG - 2021-10-28 16:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-28 16:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-28 16:30:35 --> Controller Class Initialized
INFO - 2021-10-28 16:30:35 --> Helper loaded: cookie_helper
INFO - 2021-10-28 16:30:35 --> Model "CookieModel" initialized
INFO - 2021-10-28 16:30:35 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-28 16:30:35 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-28 16:30:35 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-28 16:30:35 --> Final output sent to browser
DEBUG - 2021-10-28 16:30:35 --> Total execution time: 0.0304
INFO - 2021-10-28 16:30:35 --> Config Class Initialized
INFO - 2021-10-28 16:30:35 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:35 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:35 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:35 --> Config Class Initialized
INFO - 2021-10-28 16:30:35 --> Hooks Class Initialized
INFO - 2021-10-28 16:30:35 --> URI Class Initialized
INFO - 2021-10-28 16:30:35 --> Router Class Initialized
DEBUG - 2021-10-28 16:30:35 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:35 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:35 --> URI Class Initialized
INFO - 2021-10-28 16:30:35 --> Config Class Initialized
INFO - 2021-10-28 16:30:35 --> Hooks Class Initialized
INFO - 2021-10-28 16:30:35 --> Router Class Initialized
INFO - 2021-10-28 16:30:35 --> Output Class Initialized
DEBUG - 2021-10-28 16:30:35 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:35 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:35 --> Security Class Initialized
INFO - 2021-10-28 16:30:35 --> URI Class Initialized
INFO - 2021-10-28 16:30:35 --> Config Class Initialized
INFO - 2021-10-28 16:30:35 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:35 --> Input Class Initialized
INFO - 2021-10-28 16:30:35 --> Config Class Initialized
INFO - 2021-10-28 16:30:35 --> Output Class Initialized
INFO - 2021-10-28 16:30:35 --> Hooks Class Initialized
INFO - 2021-10-28 16:30:35 --> Router Class Initialized
INFO - 2021-10-28 16:30:35 --> Language Class Initialized
ERROR - 2021-10-28 16:30:35 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:35 --> Output Class Initialized
DEBUG - 2021-10-28 16:30:35 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:35 --> Utf8 Class Initialized
DEBUG - 2021-10-28 16:30:35 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:35 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:35 --> URI Class Initialized
INFO - 2021-10-28 16:30:35 --> Security Class Initialized
INFO - 2021-10-28 16:30:35 --> URI Class Initialized
INFO - 2021-10-28 16:30:35 --> Config Class Initialized
INFO - 2021-10-28 16:30:35 --> Hooks Class Initialized
INFO - 2021-10-28 16:30:35 --> Security Class Initialized
INFO - 2021-10-28 16:30:35 --> Router Class Initialized
DEBUG - 2021-10-28 16:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:35 --> Input Class Initialized
INFO - 2021-10-28 16:30:35 --> Router Class Initialized
DEBUG - 2021-10-28 16:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:35 --> Input Class Initialized
INFO - 2021-10-28 16:30:35 --> Language Class Initialized
INFO - 2021-10-28 16:30:35 --> Language Class Initialized
INFO - 2021-10-28 16:30:35 --> Output Class Initialized
INFO - 2021-10-28 16:30:35 --> Output Class Initialized
ERROR - 2021-10-28 16:30:35 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:35 --> Security Class Initialized
INFO - 2021-10-28 16:30:35 --> Security Class Initialized
ERROR - 2021-10-28 16:30:35 --> 404 Page Not Found: Assets/js
DEBUG - 2021-10-28 16:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-10-28 16:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:35 --> Input Class Initialized
INFO - 2021-10-28 16:30:35 --> Input Class Initialized
INFO - 2021-10-28 16:30:35 --> Language Class Initialized
INFO - 2021-10-28 16:30:35 --> Language Class Initialized
ERROR - 2021-10-28 16:30:35 --> 404 Page Not Found: Assets/js
ERROR - 2021-10-28 16:30:35 --> 404 Page Not Found: Assets/js
DEBUG - 2021-10-28 16:30:35 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:35 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:35 --> URI Class Initialized
INFO - 2021-10-28 16:30:35 --> Router Class Initialized
INFO - 2021-10-28 16:30:35 --> Config Class Initialized
INFO - 2021-10-28 16:30:35 --> Config Class Initialized
INFO - 2021-10-28 16:30:35 --> Hooks Class Initialized
INFO - 2021-10-28 16:30:35 --> Hooks Class Initialized
INFO - 2021-10-28 16:30:35 --> Config Class Initialized
INFO - 2021-10-28 16:30:35 --> Config Class Initialized
INFO - 2021-10-28 16:30:35 --> Hooks Class Initialized
INFO - 2021-10-28 16:30:35 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:35 --> UTF-8 Support Enabled
DEBUG - 2021-10-28 16:30:35 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:35 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:35 --> Utf8 Class Initialized
DEBUG - 2021-10-28 16:30:35 --> UTF-8 Support Enabled
DEBUG - 2021-10-28 16:30:35 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:35 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:35 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:35 --> URI Class Initialized
INFO - 2021-10-28 16:30:35 --> URI Class Initialized
INFO - 2021-10-28 16:30:35 --> URI Class Initialized
INFO - 2021-10-28 16:30:35 --> URI Class Initialized
INFO - 2021-10-28 16:30:35 --> Router Class Initialized
INFO - 2021-10-28 16:30:35 --> Router Class Initialized
INFO - 2021-10-28 16:30:35 --> Router Class Initialized
INFO - 2021-10-28 16:30:35 --> Router Class Initialized
INFO - 2021-10-28 16:30:35 --> Output Class Initialized
INFO - 2021-10-28 16:30:35 --> Output Class Initialized
INFO - 2021-10-28 16:30:35 --> Security Class Initialized
INFO - 2021-10-28 16:30:35 --> Output Class Initialized
INFO - 2021-10-28 16:30:35 --> Security Class Initialized
INFO - 2021-10-28 16:30:35 --> Output Class Initialized
DEBUG - 2021-10-28 16:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:35 --> Input Class Initialized
INFO - 2021-10-28 16:30:35 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:35 --> Language Class Initialized
INFO - 2021-10-28 16:30:35 --> Security Class Initialized
INFO - 2021-10-28 16:30:35 --> Input Class Initialized
DEBUG - 2021-10-28 16:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:35 --> Language Class Initialized
INFO - 2021-10-28 16:30:35 --> Input Class Initialized
ERROR - 2021-10-28 16:30:35 --> 404 Page Not Found: Assets/js
DEBUG - 2021-10-28 16:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:35 --> Input Class Initialized
INFO - 2021-10-28 16:30:35 --> Language Class Initialized
ERROR - 2021-10-28 16:30:35 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:35 --> Language Class Initialized
ERROR - 2021-10-28 16:30:35 --> 404 Page Not Found: Assets/js
ERROR - 2021-10-28 16:30:35 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:35 --> Output Class Initialized
INFO - 2021-10-28 16:30:35 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:35 --> Input Class Initialized
INFO - 2021-10-28 16:30:35 --> Language Class Initialized
ERROR - 2021-10-28 16:30:35 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:35 --> Config Class Initialized
INFO - 2021-10-28 16:30:35 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:35 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:35 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:35 --> URI Class Initialized
INFO - 2021-10-28 16:30:35 --> Router Class Initialized
INFO - 2021-10-28 16:30:35 --> Output Class Initialized
INFO - 2021-10-28 16:30:35 --> Config Class Initialized
INFO - 2021-10-28 16:30:35 --> Security Class Initialized
INFO - 2021-10-28 16:30:35 --> Hooks Class Initialized
INFO - 2021-10-28 16:30:35 --> Config Class Initialized
INFO - 2021-10-28 16:30:35 --> Hooks Class Initialized
INFO - 2021-10-28 16:30:35 --> Config Class Initialized
INFO - 2021-10-28 16:30:35 --> Hooks Class Initialized
INFO - 2021-10-28 16:30:35 --> Config Class Initialized
INFO - 2021-10-28 16:30:35 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:35 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:35 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:35 --> Config Class Initialized
INFO - 2021-10-28 16:30:35 --> URI Class Initialized
INFO - 2021-10-28 16:30:35 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:35 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:35 --> Utf8 Class Initialized
DEBUG - 2021-10-28 16:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:35 --> Input Class Initialized
INFO - 2021-10-28 16:30:35 --> Router Class Initialized
INFO - 2021-10-28 16:30:35 --> URI Class Initialized
INFO - 2021-10-28 16:30:35 --> Language Class Initialized
DEBUG - 2021-10-28 16:30:35 --> UTF-8 Support Enabled
ERROR - 2021-10-28 16:30:35 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:35 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:35 --> Router Class Initialized
INFO - 2021-10-28 16:30:35 --> Output Class Initialized
INFO - 2021-10-28 16:30:35 --> URI Class Initialized
INFO - 2021-10-28 16:30:35 --> Security Class Initialized
INFO - 2021-10-28 16:30:35 --> Router Class Initialized
INFO - 2021-10-28 16:30:35 --> Output Class Initialized
DEBUG - 2021-10-28 16:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:35 --> Input Class Initialized
INFO - 2021-10-28 16:30:35 --> Language Class Initialized
INFO - 2021-10-28 16:30:35 --> Output Class Initialized
INFO - 2021-10-28 16:30:35 --> Security Class Initialized
ERROR - 2021-10-28 16:30:35 --> 404 Page Not Found: Assets/js
DEBUG - 2021-10-28 16:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:35 --> Security Class Initialized
INFO - 2021-10-28 16:30:35 --> Input Class Initialized
DEBUG - 2021-10-28 16:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:35 --> Input Class Initialized
INFO - 2021-10-28 16:30:35 --> Language Class Initialized
INFO - 2021-10-28 16:30:35 --> Language Class Initialized
ERROR - 2021-10-28 16:30:35 --> 404 Page Not Found: Assets/js
ERROR - 2021-10-28 16:30:35 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:35 --> Config Class Initialized
INFO - 2021-10-28 16:30:35 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:35 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:35 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:35 --> URI Class Initialized
INFO - 2021-10-28 16:30:35 --> Router Class Initialized
INFO - 2021-10-28 16:30:35 --> Output Class Initialized
INFO - 2021-10-28 16:30:35 --> Config Class Initialized
INFO - 2021-10-28 16:30:35 --> Hooks Class Initialized
INFO - 2021-10-28 16:30:35 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:35 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:35 --> Utf8 Class Initialized
DEBUG - 2021-10-28 16:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:35 --> Input Class Initialized
INFO - 2021-10-28 16:30:35 --> URI Class Initialized
INFO - 2021-10-28 16:30:35 --> Language Class Initialized
ERROR - 2021-10-28 16:30:35 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:35 --> Router Class Initialized
DEBUG - 2021-10-28 16:30:35 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:35 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:35 --> Output Class Initialized
INFO - 2021-10-28 16:30:35 --> Security Class Initialized
INFO - 2021-10-28 16:30:35 --> URI Class Initialized
DEBUG - 2021-10-28 16:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:35 --> Input Class Initialized
INFO - 2021-10-28 16:30:35 --> Router Class Initialized
INFO - 2021-10-28 16:30:35 --> Language Class Initialized
ERROR - 2021-10-28 16:30:35 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:35 --> Output Class Initialized
INFO - 2021-10-28 16:30:35 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:35 --> Input Class Initialized
INFO - 2021-10-28 16:30:35 --> Language Class Initialized
ERROR - 2021-10-28 16:30:35 --> 404 Page Not Found: Assets/js
DEBUG - 2021-10-28 16:30:35 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:35 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:35 --> URI Class Initialized
INFO - 2021-10-28 16:30:35 --> Router Class Initialized
INFO - 2021-10-28 16:30:35 --> Output Class Initialized
INFO - 2021-10-28 16:30:35 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:35 --> Config Class Initialized
INFO - 2021-10-28 16:30:35 --> Hooks Class Initialized
INFO - 2021-10-28 16:30:35 --> Input Class Initialized
INFO - 2021-10-28 16:30:35 --> Language Class Initialized
ERROR - 2021-10-28 16:30:35 --> 404 Page Not Found: Assets/fonts
DEBUG - 2021-10-28 16:30:35 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:35 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:35 --> URI Class Initialized
INFO - 2021-10-28 16:30:35 --> Router Class Initialized
INFO - 2021-10-28 16:30:35 --> Output Class Initialized
INFO - 2021-10-28 16:30:35 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:35 --> Input Class Initialized
INFO - 2021-10-28 16:30:35 --> Language Class Initialized
ERROR - 2021-10-28 16:30:35 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:35 --> Config Class Initialized
INFO - 2021-10-28 16:30:35 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:35 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:35 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:35 --> URI Class Initialized
INFO - 2021-10-28 16:30:35 --> Router Class Initialized
INFO - 2021-10-28 16:30:36 --> Output Class Initialized
INFO - 2021-10-28 16:30:36 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:36 --> Input Class Initialized
INFO - 2021-10-28 16:30:36 --> Language Class Initialized
ERROR - 2021-10-28 16:30:36 --> 404 Page Not Found: Assets/images
INFO - 2021-10-28 16:30:36 --> Config Class Initialized
INFO - 2021-10-28 16:30:36 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:36 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:36 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:36 --> URI Class Initialized
INFO - 2021-10-28 16:30:36 --> Router Class Initialized
INFO - 2021-10-28 16:30:36 --> Output Class Initialized
INFO - 2021-10-28 16:30:36 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:36 --> Input Class Initialized
INFO - 2021-10-28 16:30:36 --> Language Class Initialized
ERROR - 2021-10-28 16:30:36 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:36 --> Config Class Initialized
INFO - 2021-10-28 16:30:36 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:36 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:36 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:36 --> URI Class Initialized
INFO - 2021-10-28 16:30:36 --> Router Class Initialized
INFO - 2021-10-28 16:30:36 --> Output Class Initialized
INFO - 2021-10-28 16:30:36 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:36 --> Input Class Initialized
INFO - 2021-10-28 16:30:36 --> Language Class Initialized
ERROR - 2021-10-28 16:30:36 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:36 --> Config Class Initialized
INFO - 2021-10-28 16:30:36 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:36 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:36 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:36 --> URI Class Initialized
INFO - 2021-10-28 16:30:36 --> Router Class Initialized
INFO - 2021-10-28 16:30:36 --> Output Class Initialized
INFO - 2021-10-28 16:30:36 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:36 --> Input Class Initialized
INFO - 2021-10-28 16:30:36 --> Language Class Initialized
ERROR - 2021-10-28 16:30:36 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:36 --> Config Class Initialized
INFO - 2021-10-28 16:30:36 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:36 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:36 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:36 --> URI Class Initialized
INFO - 2021-10-28 16:30:36 --> Router Class Initialized
INFO - 2021-10-28 16:30:36 --> Output Class Initialized
INFO - 2021-10-28 16:30:36 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:36 --> Input Class Initialized
INFO - 2021-10-28 16:30:36 --> Language Class Initialized
ERROR - 2021-10-28 16:30:36 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:36 --> Config Class Initialized
INFO - 2021-10-28 16:30:36 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:36 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:36 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:36 --> URI Class Initialized
INFO - 2021-10-28 16:30:36 --> Router Class Initialized
INFO - 2021-10-28 16:30:36 --> Output Class Initialized
INFO - 2021-10-28 16:30:36 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:36 --> Input Class Initialized
INFO - 2021-10-28 16:30:36 --> Language Class Initialized
ERROR - 2021-10-28 16:30:36 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:36 --> Config Class Initialized
INFO - 2021-10-28 16:30:36 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:36 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:36 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:36 --> URI Class Initialized
INFO - 2021-10-28 16:30:36 --> Router Class Initialized
INFO - 2021-10-28 16:30:36 --> Output Class Initialized
INFO - 2021-10-28 16:30:36 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:36 --> Input Class Initialized
INFO - 2021-10-28 16:30:36 --> Language Class Initialized
ERROR - 2021-10-28 16:30:36 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:36 --> Config Class Initialized
INFO - 2021-10-28 16:30:36 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:36 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:36 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:36 --> URI Class Initialized
INFO - 2021-10-28 16:30:36 --> Router Class Initialized
INFO - 2021-10-28 16:30:36 --> Output Class Initialized
INFO - 2021-10-28 16:30:36 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:36 --> Input Class Initialized
INFO - 2021-10-28 16:30:36 --> Language Class Initialized
ERROR - 2021-10-28 16:30:36 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:36 --> Config Class Initialized
INFO - 2021-10-28 16:30:36 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:36 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:36 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:36 --> URI Class Initialized
INFO - 2021-10-28 16:30:36 --> Router Class Initialized
INFO - 2021-10-28 16:30:36 --> Output Class Initialized
INFO - 2021-10-28 16:30:36 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:36 --> Input Class Initialized
INFO - 2021-10-28 16:30:36 --> Language Class Initialized
ERROR - 2021-10-28 16:30:36 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:36 --> Config Class Initialized
INFO - 2021-10-28 16:30:36 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:36 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:36 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:36 --> URI Class Initialized
INFO - 2021-10-28 16:30:36 --> Router Class Initialized
INFO - 2021-10-28 16:30:36 --> Output Class Initialized
INFO - 2021-10-28 16:30:36 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:36 --> Input Class Initialized
INFO - 2021-10-28 16:30:36 --> Language Class Initialized
ERROR - 2021-10-28 16:30:36 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:36 --> Config Class Initialized
INFO - 2021-10-28 16:30:36 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:36 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:36 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:36 --> URI Class Initialized
INFO - 2021-10-28 16:30:36 --> Router Class Initialized
INFO - 2021-10-28 16:30:36 --> Output Class Initialized
INFO - 2021-10-28 16:30:36 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:36 --> Input Class Initialized
INFO - 2021-10-28 16:30:36 --> Language Class Initialized
ERROR - 2021-10-28 16:30:36 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:36 --> Config Class Initialized
INFO - 2021-10-28 16:30:36 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:36 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:36 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:36 --> URI Class Initialized
INFO - 2021-10-28 16:30:36 --> Router Class Initialized
INFO - 2021-10-28 16:30:36 --> Output Class Initialized
INFO - 2021-10-28 16:30:36 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:36 --> Input Class Initialized
INFO - 2021-10-28 16:30:36 --> Language Class Initialized
ERROR - 2021-10-28 16:30:36 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:36 --> Config Class Initialized
INFO - 2021-10-28 16:30:36 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:36 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:36 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:36 --> URI Class Initialized
INFO - 2021-10-28 16:30:36 --> Router Class Initialized
INFO - 2021-10-28 16:30:36 --> Output Class Initialized
INFO - 2021-10-28 16:30:36 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:36 --> Input Class Initialized
INFO - 2021-10-28 16:30:36 --> Language Class Initialized
ERROR - 2021-10-28 16:30:36 --> 404 Page Not Found: Assets/fonts
INFO - 2021-10-28 16:30:36 --> Config Class Initialized
INFO - 2021-10-28 16:30:36 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:36 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:36 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:36 --> URI Class Initialized
INFO - 2021-10-28 16:30:36 --> Router Class Initialized
INFO - 2021-10-28 16:30:36 --> Output Class Initialized
INFO - 2021-10-28 16:30:36 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:36 --> Input Class Initialized
INFO - 2021-10-28 16:30:36 --> Language Class Initialized
ERROR - 2021-10-28 16:30:36 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:36 --> Config Class Initialized
INFO - 2021-10-28 16:30:36 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:36 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:36 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:36 --> URI Class Initialized
INFO - 2021-10-28 16:30:36 --> Router Class Initialized
INFO - 2021-10-28 16:30:36 --> Output Class Initialized
INFO - 2021-10-28 16:30:36 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:36 --> Input Class Initialized
INFO - 2021-10-28 16:30:36 --> Language Class Initialized
ERROR - 2021-10-28 16:30:36 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:30:36 --> Config Class Initialized
INFO - 2021-10-28 16:30:36 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:30:36 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:30:36 --> Utf8 Class Initialized
INFO - 2021-10-28 16:30:36 --> URI Class Initialized
INFO - 2021-10-28 16:30:36 --> Router Class Initialized
INFO - 2021-10-28 16:30:36 --> Output Class Initialized
INFO - 2021-10-28 16:30:36 --> Security Class Initialized
DEBUG - 2021-10-28 16:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:30:36 --> Input Class Initialized
INFO - 2021-10-28 16:30:36 --> Language Class Initialized
ERROR - 2021-10-28 16:30:36 --> 404 Page Not Found: Assets/js
INFO - 2021-10-28 16:31:15 --> Config Class Initialized
INFO - 2021-10-28 16:31:15 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:31:15 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:31:15 --> Utf8 Class Initialized
INFO - 2021-10-28 16:31:15 --> URI Class Initialized
DEBUG - 2021-10-28 16:31:15 --> No URI present. Default controller set.
INFO - 2021-10-28 16:31:15 --> Router Class Initialized
INFO - 2021-10-28 16:31:15 --> Output Class Initialized
INFO - 2021-10-28 16:31:15 --> Security Class Initialized
DEBUG - 2021-10-28 16:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:31:15 --> Input Class Initialized
INFO - 2021-10-28 16:31:15 --> Language Class Initialized
INFO - 2021-10-28 16:31:15 --> Loader Class Initialized
INFO - 2021-10-28 16:31:15 --> Helper loaded: url_helper
INFO - 2021-10-28 16:31:15 --> Helper loaded: file_helper
DEBUG - 2021-10-28 16:31:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-28 16:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-28 16:31:15 --> Controller Class Initialized
INFO - 2021-10-28 16:31:15 --> Helper loaded: cookie_helper
INFO - 2021-10-28 16:31:15 --> Model "CookieModel" initialized
INFO - 2021-10-28 16:31:15 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-28 16:31:15 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-28 16:31:15 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-28 16:31:15 --> Final output sent to browser
DEBUG - 2021-10-28 16:31:15 --> Total execution time: 0.0393
INFO - 2021-10-28 16:31:16 --> Config Class Initialized
INFO - 2021-10-28 16:31:16 --> Hooks Class Initialized
DEBUG - 2021-10-28 16:31:16 --> UTF-8 Support Enabled
INFO - 2021-10-28 16:31:16 --> Utf8 Class Initialized
INFO - 2021-10-28 16:31:16 --> URI Class Initialized
INFO - 2021-10-28 16:31:16 --> Router Class Initialized
INFO - 2021-10-28 16:31:16 --> Output Class Initialized
INFO - 2021-10-28 16:31:16 --> Security Class Initialized
DEBUG - 2021-10-28 16:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-28 16:31:16 --> Input Class Initialized
INFO - 2021-10-28 16:31:16 --> Language Class Initialized
ERROR - 2021-10-28 16:31:16 --> 404 Page Not Found: Assets/icons
