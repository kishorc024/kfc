<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-08-02 21:44:51 --> Config Class Initialized
INFO - 2021-08-02 21:44:51 --> Hooks Class Initialized
DEBUG - 2021-08-02 21:44:51 --> UTF-8 Support Enabled
INFO - 2021-08-02 21:44:51 --> Utf8 Class Initialized
INFO - 2021-08-02 21:44:51 --> URI Class Initialized
DEBUG - 2021-08-02 21:44:51 --> No URI present. Default controller set.
INFO - 2021-08-02 21:44:51 --> Router Class Initialized
INFO - 2021-08-02 21:44:51 --> Output Class Initialized
INFO - 2021-08-02 21:44:51 --> Security Class Initialized
DEBUG - 2021-08-02 21:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-02 21:44:51 --> Input Class Initialized
INFO - 2021-08-02 21:44:51 --> Language Class Initialized
INFO - 2021-08-02 21:44:51 --> Loader Class Initialized
INFO - 2021-08-02 21:44:51 --> Helper loaded: url_helper
INFO - 2021-08-02 21:44:51 --> Helper loaded: file_helper
INFO - 2021-08-02 21:44:51 --> Database Driver Class Initialized
DEBUG - 2021-08-02 21:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-02 21:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-02 21:44:51 --> Controller Class Initialized
INFO - 2021-08-02 21:44:51 --> Helper loaded: cookie_helper
INFO - 2021-08-02 21:44:51 --> Model "CookieModel" initialized
INFO - 2021-08-02 21:44:51 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-02 21:44:51 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-02 21:44:51 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-02 21:44:51 --> Final output sent to browser
DEBUG - 2021-08-02 21:44:51 --> Total execution time: 0.2271
INFO - 2021-08-02 21:46:17 --> Config Class Initialized
INFO - 2021-08-02 21:46:17 --> Hooks Class Initialized
DEBUG - 2021-08-02 21:46:17 --> UTF-8 Support Enabled
INFO - 2021-08-02 21:46:17 --> Utf8 Class Initialized
INFO - 2021-08-02 21:46:17 --> URI Class Initialized
INFO - 2021-08-02 21:46:17 --> Router Class Initialized
INFO - 2021-08-02 21:46:17 --> Output Class Initialized
INFO - 2021-08-02 21:46:17 --> Security Class Initialized
DEBUG - 2021-08-02 21:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-02 21:46:17 --> Input Class Initialized
INFO - 2021-08-02 21:46:17 --> Language Class Initialized
ERROR - 2021-08-02 21:46:17 --> 404 Page Not Found: Wp-content/uploads
INFO - 2021-08-02 21:51:28 --> Config Class Initialized
INFO - 2021-08-02 21:51:28 --> Hooks Class Initialized
DEBUG - 2021-08-02 21:51:28 --> UTF-8 Support Enabled
INFO - 2021-08-02 21:51:28 --> Utf8 Class Initialized
INFO - 2021-08-02 21:51:28 --> URI Class Initialized
DEBUG - 2021-08-02 21:51:28 --> No URI present. Default controller set.
INFO - 2021-08-02 21:51:28 --> Router Class Initialized
INFO - 2021-08-02 21:51:28 --> Output Class Initialized
INFO - 2021-08-02 21:51:28 --> Security Class Initialized
DEBUG - 2021-08-02 21:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-02 21:51:28 --> Input Class Initialized
INFO - 2021-08-02 21:51:28 --> Language Class Initialized
INFO - 2021-08-02 21:51:28 --> Loader Class Initialized
INFO - 2021-08-02 21:51:28 --> Helper loaded: url_helper
INFO - 2021-08-02 21:51:28 --> Helper loaded: file_helper
INFO - 2021-08-02 21:51:28 --> Database Driver Class Initialized
DEBUG - 2021-08-02 21:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-02 21:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-02 21:51:28 --> Controller Class Initialized
INFO - 2021-08-02 21:51:28 --> Helper loaded: cookie_helper
INFO - 2021-08-02 21:51:28 --> Model "CookieModel" initialized
INFO - 2021-08-02 21:51:28 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-02 21:51:28 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-02 21:51:28 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-02 21:51:28 --> Final output sent to browser
DEBUG - 2021-08-02 21:51:28 --> Total execution time: 0.0690
INFO - 2021-08-02 21:51:38 --> Config Class Initialized
INFO - 2021-08-02 21:51:38 --> Hooks Class Initialized
DEBUG - 2021-08-02 21:51:38 --> UTF-8 Support Enabled
INFO - 2021-08-02 21:51:38 --> Utf8 Class Initialized
INFO - 2021-08-02 21:51:38 --> URI Class Initialized
DEBUG - 2021-08-02 21:51:38 --> No URI present. Default controller set.
INFO - 2021-08-02 21:51:38 --> Router Class Initialized
INFO - 2021-08-02 21:51:38 --> Output Class Initialized
INFO - 2021-08-02 21:51:38 --> Security Class Initialized
DEBUG - 2021-08-02 21:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-02 21:51:38 --> Input Class Initialized
INFO - 2021-08-02 21:51:38 --> Language Class Initialized
INFO - 2021-08-02 21:51:38 --> Loader Class Initialized
INFO - 2021-08-02 21:51:38 --> Helper loaded: url_helper
INFO - 2021-08-02 21:51:38 --> Helper loaded: file_helper
INFO - 2021-08-02 21:51:38 --> Database Driver Class Initialized
DEBUG - 2021-08-02 21:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-02 21:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-02 21:51:38 --> Controller Class Initialized
INFO - 2021-08-02 21:51:38 --> Helper loaded: cookie_helper
INFO - 2021-08-02 21:51:38 --> Model "CookieModel" initialized
INFO - 2021-08-02 21:51:38 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-02 21:51:38 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-02 21:51:38 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-02 21:51:38 --> Final output sent to browser
DEBUG - 2021-08-02 21:51:38 --> Total execution time: 0.0621
INFO - 2021-08-02 21:51:39 --> Config Class Initialized
INFO - 2021-08-02 21:51:39 --> Hooks Class Initialized
DEBUG - 2021-08-02 21:51:39 --> UTF-8 Support Enabled
INFO - 2021-08-02 21:51:39 --> Utf8 Class Initialized
INFO - 2021-08-02 21:51:39 --> URI Class Initialized
INFO - 2021-08-02 21:51:39 --> Router Class Initialized
INFO - 2021-08-02 21:51:39 --> Output Class Initialized
INFO - 2021-08-02 21:51:39 --> Security Class Initialized
DEBUG - 2021-08-02 21:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-02 21:51:39 --> Input Class Initialized
INFO - 2021-08-02 21:51:39 --> Language Class Initialized
ERROR - 2021-08-02 21:51:39 --> 404 Page Not Found: Wp-content/uploads
INFO - 2021-08-02 21:53:13 --> Config Class Initialized
INFO - 2021-08-02 21:53:13 --> Hooks Class Initialized
DEBUG - 2021-08-02 21:53:13 --> UTF-8 Support Enabled
INFO - 2021-08-02 21:53:13 --> Utf8 Class Initialized
INFO - 2021-08-02 21:53:13 --> URI Class Initialized
DEBUG - 2021-08-02 21:53:13 --> No URI present. Default controller set.
INFO - 2021-08-02 21:53:13 --> Router Class Initialized
INFO - 2021-08-02 21:53:13 --> Output Class Initialized
INFO - 2021-08-02 21:53:13 --> Security Class Initialized
DEBUG - 2021-08-02 21:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-02 21:53:13 --> Input Class Initialized
INFO - 2021-08-02 21:53:13 --> Language Class Initialized
INFO - 2021-08-02 21:53:13 --> Loader Class Initialized
INFO - 2021-08-02 21:53:13 --> Helper loaded: url_helper
INFO - 2021-08-02 21:53:13 --> Helper loaded: file_helper
INFO - 2021-08-02 21:53:13 --> Database Driver Class Initialized
DEBUG - 2021-08-02 21:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-02 21:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-02 21:53:13 --> Controller Class Initialized
INFO - 2021-08-02 21:53:13 --> Helper loaded: cookie_helper
INFO - 2021-08-02 21:53:13 --> Model "CookieModel" initialized
INFO - 2021-08-02 21:53:13 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-02 21:53:13 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-02 21:53:13 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-02 21:53:13 --> Final output sent to browser
DEBUG - 2021-08-02 21:53:13 --> Total execution time: 0.0465
INFO - 2021-08-02 21:53:59 --> Config Class Initialized
INFO - 2021-08-02 21:53:59 --> Hooks Class Initialized
DEBUG - 2021-08-02 21:53:59 --> UTF-8 Support Enabled
INFO - 2021-08-02 21:53:59 --> Utf8 Class Initialized
INFO - 2021-08-02 21:53:59 --> URI Class Initialized
DEBUG - 2021-08-02 21:53:59 --> No URI present. Default controller set.
INFO - 2021-08-02 21:53:59 --> Router Class Initialized
INFO - 2021-08-02 21:53:59 --> Output Class Initialized
INFO - 2021-08-02 21:53:59 --> Security Class Initialized
DEBUG - 2021-08-02 21:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-02 21:53:59 --> Input Class Initialized
INFO - 2021-08-02 21:53:59 --> Language Class Initialized
INFO - 2021-08-02 21:53:59 --> Loader Class Initialized
INFO - 2021-08-02 21:53:59 --> Helper loaded: url_helper
INFO - 2021-08-02 21:53:59 --> Helper loaded: file_helper
INFO - 2021-08-02 21:53:59 --> Database Driver Class Initialized
DEBUG - 2021-08-02 21:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-02 21:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-02 21:53:59 --> Controller Class Initialized
INFO - 2021-08-02 21:53:59 --> Helper loaded: cookie_helper
INFO - 2021-08-02 21:53:59 --> Model "CookieModel" initialized
INFO - 2021-08-02 21:53:59 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-02 21:53:59 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-02 21:53:59 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-02 21:53:59 --> Final output sent to browser
DEBUG - 2021-08-02 21:53:59 --> Total execution time: 0.0417
INFO - 2021-08-02 21:54:14 --> Config Class Initialized
INFO - 2021-08-02 21:54:14 --> Hooks Class Initialized
DEBUG - 2021-08-02 21:54:14 --> UTF-8 Support Enabled
INFO - 2021-08-02 21:54:14 --> Utf8 Class Initialized
INFO - 2021-08-02 21:54:14 --> URI Class Initialized
DEBUG - 2021-08-02 21:54:14 --> No URI present. Default controller set.
INFO - 2021-08-02 21:54:14 --> Router Class Initialized
INFO - 2021-08-02 21:54:14 --> Output Class Initialized
INFO - 2021-08-02 21:54:14 --> Security Class Initialized
DEBUG - 2021-08-02 21:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-02 21:54:14 --> Input Class Initialized
INFO - 2021-08-02 21:54:14 --> Language Class Initialized
INFO - 2021-08-02 21:54:14 --> Loader Class Initialized
INFO - 2021-08-02 21:54:14 --> Helper loaded: url_helper
INFO - 2021-08-02 21:54:14 --> Helper loaded: file_helper
INFO - 2021-08-02 21:54:14 --> Database Driver Class Initialized
DEBUG - 2021-08-02 21:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-02 21:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-02 21:54:14 --> Controller Class Initialized
INFO - 2021-08-02 21:54:14 --> Helper loaded: cookie_helper
INFO - 2021-08-02 21:54:14 --> Model "CookieModel" initialized
INFO - 2021-08-02 21:54:14 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-02 21:54:14 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-02 21:54:14 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-02 21:54:14 --> Final output sent to browser
DEBUG - 2021-08-02 21:54:14 --> Total execution time: 0.0424
INFO - 2021-08-02 21:56:09 --> Config Class Initialized
INFO - 2021-08-02 21:56:09 --> Hooks Class Initialized
DEBUG - 2021-08-02 21:56:09 --> UTF-8 Support Enabled
INFO - 2021-08-02 21:56:09 --> Utf8 Class Initialized
INFO - 2021-08-02 21:56:09 --> URI Class Initialized
DEBUG - 2021-08-02 21:56:09 --> No URI present. Default controller set.
INFO - 2021-08-02 21:56:09 --> Router Class Initialized
INFO - 2021-08-02 21:56:09 --> Output Class Initialized
INFO - 2021-08-02 21:56:09 --> Security Class Initialized
DEBUG - 2021-08-02 21:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-02 21:56:09 --> Input Class Initialized
INFO - 2021-08-02 21:56:09 --> Language Class Initialized
INFO - 2021-08-02 21:56:09 --> Loader Class Initialized
INFO - 2021-08-02 21:56:09 --> Helper loaded: url_helper
INFO - 2021-08-02 21:56:09 --> Helper loaded: file_helper
INFO - 2021-08-02 21:56:09 --> Database Driver Class Initialized
DEBUG - 2021-08-02 21:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-02 21:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-02 21:56:09 --> Controller Class Initialized
INFO - 2021-08-02 21:56:09 --> Helper loaded: cookie_helper
INFO - 2021-08-02 21:56:09 --> Model "CookieModel" initialized
INFO - 2021-08-02 21:56:09 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-02 21:56:09 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-02 21:56:09 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-02 21:56:09 --> Final output sent to browser
DEBUG - 2021-08-02 21:56:09 --> Total execution time: 0.0406
INFO - 2021-08-02 21:56:54 --> Config Class Initialized
INFO - 2021-08-02 21:56:54 --> Hooks Class Initialized
DEBUG - 2021-08-02 21:56:54 --> UTF-8 Support Enabled
INFO - 2021-08-02 21:56:54 --> Utf8 Class Initialized
INFO - 2021-08-02 21:56:54 --> URI Class Initialized
DEBUG - 2021-08-02 21:56:54 --> No URI present. Default controller set.
INFO - 2021-08-02 21:56:54 --> Router Class Initialized
INFO - 2021-08-02 21:56:54 --> Output Class Initialized
INFO - 2021-08-02 21:56:54 --> Security Class Initialized
DEBUG - 2021-08-02 21:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-02 21:56:54 --> Input Class Initialized
INFO - 2021-08-02 21:56:54 --> Language Class Initialized
INFO - 2021-08-02 21:56:54 --> Loader Class Initialized
INFO - 2021-08-02 21:56:54 --> Helper loaded: url_helper
INFO - 2021-08-02 21:56:54 --> Helper loaded: file_helper
INFO - 2021-08-02 21:56:54 --> Database Driver Class Initialized
DEBUG - 2021-08-02 21:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-02 21:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-02 21:56:54 --> Controller Class Initialized
INFO - 2021-08-02 21:56:54 --> Helper loaded: cookie_helper
INFO - 2021-08-02 21:56:54 --> Model "CookieModel" initialized
INFO - 2021-08-02 21:56:54 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-02 21:56:54 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-02 21:56:54 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-02 21:56:54 --> Final output sent to browser
DEBUG - 2021-08-02 21:56:54 --> Total execution time: 0.0390
INFO - 2021-08-02 22:01:42 --> Config Class Initialized
INFO - 2021-08-02 22:01:42 --> Hooks Class Initialized
DEBUG - 2021-08-02 22:01:42 --> UTF-8 Support Enabled
INFO - 2021-08-02 22:01:42 --> Utf8 Class Initialized
INFO - 2021-08-02 22:01:42 --> URI Class Initialized
DEBUG - 2021-08-02 22:01:42 --> No URI present. Default controller set.
INFO - 2021-08-02 22:01:42 --> Router Class Initialized
INFO - 2021-08-02 22:01:42 --> Output Class Initialized
INFO - 2021-08-02 22:01:42 --> Security Class Initialized
DEBUG - 2021-08-02 22:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-02 22:01:42 --> Input Class Initialized
INFO - 2021-08-02 22:01:42 --> Language Class Initialized
INFO - 2021-08-02 22:01:42 --> Loader Class Initialized
INFO - 2021-08-02 22:01:42 --> Helper loaded: url_helper
INFO - 2021-08-02 22:01:42 --> Helper loaded: file_helper
INFO - 2021-08-02 22:01:42 --> Database Driver Class Initialized
DEBUG - 2021-08-02 22:01:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-02 22:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-02 22:01:42 --> Controller Class Initialized
INFO - 2021-08-02 22:01:42 --> Helper loaded: cookie_helper
INFO - 2021-08-02 22:01:42 --> Model "CookieModel" initialized
INFO - 2021-08-02 22:01:42 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-02 22:01:42 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-02 22:01:42 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-02 22:01:42 --> Final output sent to browser
DEBUG - 2021-08-02 22:01:42 --> Total execution time: 0.0426
INFO - 2021-08-02 22:02:00 --> Config Class Initialized
INFO - 2021-08-02 22:02:00 --> Hooks Class Initialized
DEBUG - 2021-08-02 22:02:00 --> UTF-8 Support Enabled
INFO - 2021-08-02 22:02:00 --> Utf8 Class Initialized
INFO - 2021-08-02 22:02:00 --> URI Class Initialized
DEBUG - 2021-08-02 22:02:00 --> No URI present. Default controller set.
INFO - 2021-08-02 22:02:00 --> Router Class Initialized
INFO - 2021-08-02 22:02:00 --> Output Class Initialized
INFO - 2021-08-02 22:02:00 --> Security Class Initialized
DEBUG - 2021-08-02 22:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-02 22:02:00 --> Input Class Initialized
INFO - 2021-08-02 22:02:00 --> Language Class Initialized
INFO - 2021-08-02 22:02:00 --> Loader Class Initialized
INFO - 2021-08-02 22:02:00 --> Helper loaded: url_helper
INFO - 2021-08-02 22:02:00 --> Helper loaded: file_helper
INFO - 2021-08-02 22:02:00 --> Database Driver Class Initialized
DEBUG - 2021-08-02 22:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-02 22:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-02 22:02:00 --> Controller Class Initialized
INFO - 2021-08-02 22:02:00 --> Helper loaded: cookie_helper
INFO - 2021-08-02 22:02:00 --> Model "CookieModel" initialized
INFO - 2021-08-02 22:02:00 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-02 22:02:00 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-02 22:02:00 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-02 22:02:00 --> Final output sent to browser
DEBUG - 2021-08-02 22:02:00 --> Total execution time: 0.0417
INFO - 2021-08-02 22:02:25 --> Config Class Initialized
INFO - 2021-08-02 22:02:25 --> Hooks Class Initialized
DEBUG - 2021-08-02 22:02:25 --> UTF-8 Support Enabled
INFO - 2021-08-02 22:02:25 --> Utf8 Class Initialized
INFO - 2021-08-02 22:02:25 --> URI Class Initialized
DEBUG - 2021-08-02 22:02:25 --> No URI present. Default controller set.
INFO - 2021-08-02 22:02:25 --> Router Class Initialized
INFO - 2021-08-02 22:02:25 --> Output Class Initialized
INFO - 2021-08-02 22:02:25 --> Security Class Initialized
DEBUG - 2021-08-02 22:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-02 22:02:25 --> Input Class Initialized
INFO - 2021-08-02 22:02:25 --> Language Class Initialized
INFO - 2021-08-02 22:02:25 --> Loader Class Initialized
INFO - 2021-08-02 22:02:25 --> Helper loaded: url_helper
INFO - 2021-08-02 22:02:25 --> Helper loaded: file_helper
INFO - 2021-08-02 22:02:25 --> Database Driver Class Initialized
DEBUG - 2021-08-02 22:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-02 22:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-02 22:02:25 --> Controller Class Initialized
INFO - 2021-08-02 22:02:25 --> Helper loaded: cookie_helper
INFO - 2021-08-02 22:02:25 --> Model "CookieModel" initialized
INFO - 2021-08-02 22:02:25 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-02 22:02:25 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-02 22:02:25 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-02 22:02:25 --> Final output sent to browser
DEBUG - 2021-08-02 22:02:25 --> Total execution time: 0.0671
INFO - 2021-08-02 22:04:47 --> Config Class Initialized
INFO - 2021-08-02 22:04:47 --> Hooks Class Initialized
DEBUG - 2021-08-02 22:04:47 --> UTF-8 Support Enabled
INFO - 2021-08-02 22:04:47 --> Utf8 Class Initialized
INFO - 2021-08-02 22:04:47 --> URI Class Initialized
DEBUG - 2021-08-02 22:04:47 --> No URI present. Default controller set.
INFO - 2021-08-02 22:04:47 --> Router Class Initialized
INFO - 2021-08-02 22:04:47 --> Output Class Initialized
INFO - 2021-08-02 22:04:47 --> Security Class Initialized
DEBUG - 2021-08-02 22:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-02 22:04:47 --> Input Class Initialized
INFO - 2021-08-02 22:04:47 --> Language Class Initialized
INFO - 2021-08-02 22:04:47 --> Loader Class Initialized
INFO - 2021-08-02 22:04:47 --> Helper loaded: url_helper
INFO - 2021-08-02 22:04:47 --> Helper loaded: file_helper
INFO - 2021-08-02 22:04:47 --> Database Driver Class Initialized
DEBUG - 2021-08-02 22:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-02 22:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-02 22:04:47 --> Controller Class Initialized
INFO - 2021-08-02 22:04:47 --> Helper loaded: cookie_helper
INFO - 2021-08-02 22:04:47 --> Model "CookieModel" initialized
INFO - 2021-08-02 22:04:47 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-02 22:04:47 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-02 22:04:47 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-02 22:04:47 --> Final output sent to browser
DEBUG - 2021-08-02 22:04:47 --> Total execution time: 0.0395
INFO - 2021-08-02 22:05:50 --> Config Class Initialized
INFO - 2021-08-02 22:05:50 --> Hooks Class Initialized
DEBUG - 2021-08-02 22:05:50 --> UTF-8 Support Enabled
INFO - 2021-08-02 22:05:50 --> Utf8 Class Initialized
INFO - 2021-08-02 22:05:50 --> URI Class Initialized
DEBUG - 2021-08-02 22:05:50 --> No URI present. Default controller set.
INFO - 2021-08-02 22:05:50 --> Router Class Initialized
INFO - 2021-08-02 22:05:50 --> Output Class Initialized
INFO - 2021-08-02 22:05:50 --> Security Class Initialized
DEBUG - 2021-08-02 22:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-02 22:05:50 --> Input Class Initialized
INFO - 2021-08-02 22:05:50 --> Language Class Initialized
INFO - 2021-08-02 22:05:50 --> Loader Class Initialized
INFO - 2021-08-02 22:05:50 --> Helper loaded: url_helper
INFO - 2021-08-02 22:05:50 --> Helper loaded: file_helper
INFO - 2021-08-02 22:05:50 --> Database Driver Class Initialized
DEBUG - 2021-08-02 22:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-02 22:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-02 22:05:50 --> Controller Class Initialized
INFO - 2021-08-02 22:05:50 --> Helper loaded: cookie_helper
INFO - 2021-08-02 22:05:50 --> Model "CookieModel" initialized
INFO - 2021-08-02 22:05:50 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-02 22:05:50 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-02 22:05:50 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-02 22:05:50 --> Final output sent to browser
DEBUG - 2021-08-02 22:05:50 --> Total execution time: 0.0363
INFO - 2021-08-02 22:07:02 --> Config Class Initialized
INFO - 2021-08-02 22:07:02 --> Hooks Class Initialized
DEBUG - 2021-08-02 22:07:02 --> UTF-8 Support Enabled
INFO - 2021-08-02 22:07:02 --> Utf8 Class Initialized
INFO - 2021-08-02 22:07:02 --> URI Class Initialized
DEBUG - 2021-08-02 22:07:02 --> No URI present. Default controller set.
INFO - 2021-08-02 22:07:02 --> Router Class Initialized
INFO - 2021-08-02 22:07:02 --> Output Class Initialized
INFO - 2021-08-02 22:07:02 --> Security Class Initialized
DEBUG - 2021-08-02 22:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-02 22:07:02 --> Input Class Initialized
INFO - 2021-08-02 22:07:02 --> Language Class Initialized
INFO - 2021-08-02 22:07:02 --> Loader Class Initialized
INFO - 2021-08-02 22:07:02 --> Helper loaded: url_helper
INFO - 2021-08-02 22:07:02 --> Helper loaded: file_helper
INFO - 2021-08-02 22:07:02 --> Database Driver Class Initialized
DEBUG - 2021-08-02 22:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-02 22:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-02 22:07:02 --> Controller Class Initialized
INFO - 2021-08-02 22:07:02 --> Helper loaded: cookie_helper
INFO - 2021-08-02 22:07:02 --> Model "CookieModel" initialized
INFO - 2021-08-02 22:07:02 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-02 22:07:02 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-02 22:07:02 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-02 22:07:02 --> Final output sent to browser
DEBUG - 2021-08-02 22:07:02 --> Total execution time: 0.0432
INFO - 2021-08-02 22:07:03 --> Config Class Initialized
INFO - 2021-08-02 22:07:03 --> Hooks Class Initialized
DEBUG - 2021-08-02 22:07:03 --> UTF-8 Support Enabled
INFO - 2021-08-02 22:07:03 --> Utf8 Class Initialized
INFO - 2021-08-02 22:07:03 --> URI Class Initialized
DEBUG - 2021-08-02 22:07:03 --> No URI present. Default controller set.
INFO - 2021-08-02 22:07:03 --> Router Class Initialized
INFO - 2021-08-02 22:07:03 --> Output Class Initialized
INFO - 2021-08-02 22:07:03 --> Security Class Initialized
DEBUG - 2021-08-02 22:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-02 22:07:03 --> Input Class Initialized
INFO - 2021-08-02 22:07:03 --> Language Class Initialized
INFO - 2021-08-02 22:07:03 --> Loader Class Initialized
INFO - 2021-08-02 22:07:03 --> Helper loaded: url_helper
INFO - 2021-08-02 22:07:03 --> Helper loaded: file_helper
INFO - 2021-08-02 22:07:03 --> Database Driver Class Initialized
DEBUG - 2021-08-02 22:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-02 22:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-02 22:07:03 --> Controller Class Initialized
INFO - 2021-08-02 22:07:03 --> Helper loaded: cookie_helper
INFO - 2021-08-02 22:07:03 --> Model "CookieModel" initialized
INFO - 2021-08-02 22:07:03 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-02 22:07:03 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-02 22:07:03 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-02 22:07:03 --> Final output sent to browser
DEBUG - 2021-08-02 22:07:03 --> Total execution time: 0.0454
INFO - 2021-08-02 22:07:13 --> Config Class Initialized
INFO - 2021-08-02 22:07:13 --> Hooks Class Initialized
DEBUG - 2021-08-02 22:07:13 --> UTF-8 Support Enabled
INFO - 2021-08-02 22:07:13 --> Utf8 Class Initialized
INFO - 2021-08-02 22:07:13 --> URI Class Initialized
DEBUG - 2021-08-02 22:07:13 --> No URI present. Default controller set.
INFO - 2021-08-02 22:07:13 --> Router Class Initialized
INFO - 2021-08-02 22:07:13 --> Output Class Initialized
INFO - 2021-08-02 22:07:13 --> Security Class Initialized
DEBUG - 2021-08-02 22:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-02 22:07:13 --> Input Class Initialized
INFO - 2021-08-02 22:07:13 --> Language Class Initialized
INFO - 2021-08-02 22:07:13 --> Loader Class Initialized
INFO - 2021-08-02 22:07:13 --> Helper loaded: url_helper
INFO - 2021-08-02 22:07:13 --> Helper loaded: file_helper
INFO - 2021-08-02 22:07:13 --> Database Driver Class Initialized
DEBUG - 2021-08-02 22:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-02 22:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-02 22:07:13 --> Controller Class Initialized
INFO - 2021-08-02 22:07:13 --> Helper loaded: cookie_helper
INFO - 2021-08-02 22:07:13 --> Model "CookieModel" initialized
INFO - 2021-08-02 22:07:13 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-02 22:07:13 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-02 22:07:13 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-02 22:07:13 --> Final output sent to browser
DEBUG - 2021-08-02 22:07:13 --> Total execution time: 0.0450
INFO - 2021-08-02 22:08:42 --> Config Class Initialized
INFO - 2021-08-02 22:08:42 --> Hooks Class Initialized
DEBUG - 2021-08-02 22:08:42 --> UTF-8 Support Enabled
INFO - 2021-08-02 22:08:42 --> Utf8 Class Initialized
INFO - 2021-08-02 22:08:42 --> URI Class Initialized
DEBUG - 2021-08-02 22:08:42 --> No URI present. Default controller set.
INFO - 2021-08-02 22:08:42 --> Router Class Initialized
INFO - 2021-08-02 22:08:42 --> Output Class Initialized
INFO - 2021-08-02 22:08:42 --> Security Class Initialized
DEBUG - 2021-08-02 22:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-02 22:08:42 --> Input Class Initialized
INFO - 2021-08-02 22:08:42 --> Language Class Initialized
INFO - 2021-08-02 22:08:42 --> Loader Class Initialized
INFO - 2021-08-02 22:08:42 --> Helper loaded: url_helper
INFO - 2021-08-02 22:08:42 --> Helper loaded: file_helper
INFO - 2021-08-02 22:08:42 --> Database Driver Class Initialized
DEBUG - 2021-08-02 22:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-02 22:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-02 22:08:42 --> Controller Class Initialized
INFO - 2021-08-02 22:08:42 --> Helper loaded: cookie_helper
INFO - 2021-08-02 22:08:42 --> Model "CookieModel" initialized
INFO - 2021-08-02 22:08:42 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-02 22:08:42 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-02 22:08:42 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-02 22:08:42 --> Final output sent to browser
DEBUG - 2021-08-02 22:08:42 --> Total execution time: 0.0404
