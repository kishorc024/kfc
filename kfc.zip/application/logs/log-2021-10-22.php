<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-10-22 11:01:54 --> Config Class Initialized
INFO - 2021-10-22 11:01:54 --> Hooks Class Initialized
DEBUG - 2021-10-22 11:01:54 --> UTF-8 Support Enabled
INFO - 2021-10-22 11:01:54 --> Utf8 Class Initialized
INFO - 2021-10-22 11:01:54 --> URI Class Initialized
DEBUG - 2021-10-22 11:01:54 --> No URI present. Default controller set.
INFO - 2021-10-22 11:01:54 --> Router Class Initialized
INFO - 2021-10-22 11:01:54 --> Output Class Initialized
INFO - 2021-10-22 11:01:54 --> Security Class Initialized
DEBUG - 2021-10-22 11:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-22 11:01:54 --> Input Class Initialized
INFO - 2021-10-22 11:01:54 --> Language Class Initialized
INFO - 2021-10-22 11:01:54 --> Loader Class Initialized
INFO - 2021-10-22 11:01:54 --> Helper loaded: url_helper
INFO - 2021-10-22 11:01:54 --> Helper loaded: file_helper
DEBUG - 2021-10-22 11:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-22 11:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-22 11:01:54 --> Controller Class Initialized
INFO - 2021-10-22 11:01:54 --> Helper loaded: cookie_helper
INFO - 2021-10-22 11:01:54 --> Model "CookieModel" initialized
INFO - 2021-10-22 11:01:54 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-10-22 11:01:54 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-10-22 11:01:54 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-10-22 11:01:54 --> Final output sent to browser
DEBUG - 2021-10-22 11:01:54 --> Total execution time: 0.0821
INFO - 2021-10-22 11:02:00 --> Config Class Initialized
INFO - 2021-10-22 11:02:00 --> Hooks Class Initialized
DEBUG - 2021-10-22 11:02:00 --> UTF-8 Support Enabled
INFO - 2021-10-22 11:02:00 --> Utf8 Class Initialized
INFO - 2021-10-22 11:02:00 --> URI Class Initialized
DEBUG - 2021-10-22 11:02:00 --> No URI present. Default controller set.
INFO - 2021-10-22 11:02:00 --> Router Class Initialized
INFO - 2021-10-22 11:02:00 --> Output Class Initialized
INFO - 2021-10-22 11:02:00 --> Security Class Initialized
DEBUG - 2021-10-22 11:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-22 11:02:00 --> Input Class Initialized
INFO - 2021-10-22 11:02:00 --> Language Class Initialized
INFO - 2021-10-22 11:02:00 --> Loader Class Initialized
INFO - 2021-10-22 11:02:00 --> Helper loaded: url_helper
INFO - 2021-10-22 11:02:00 --> Helper loaded: file_helper
DEBUG - 2021-10-22 11:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-22 11:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-22 11:02:00 --> Controller Class Initialized
INFO - 2021-10-22 11:02:00 --> Helper loaded: cookie_helper
INFO - 2021-10-22 11:02:00 --> Model "CookieModel" initialized
INFO - 2021-10-22 11:02:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-10-22 11:02:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-10-22 11:02:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-10-22 11:02:00 --> Final output sent to browser
DEBUG - 2021-10-22 11:02:00 --> Total execution time: 0.0450
INFO - 2021-10-22 11:02:01 --> Config Class Initialized
INFO - 2021-10-22 11:02:01 --> Hooks Class Initialized
DEBUG - 2021-10-22 11:02:01 --> UTF-8 Support Enabled
INFO - 2021-10-22 11:02:01 --> Utf8 Class Initialized
INFO - 2021-10-22 11:02:01 --> URI Class Initialized
DEBUG - 2021-10-22 11:02:01 --> No URI present. Default controller set.
INFO - 2021-10-22 11:02:01 --> Router Class Initialized
INFO - 2021-10-22 11:02:01 --> Output Class Initialized
INFO - 2021-10-22 11:02:01 --> Security Class Initialized
DEBUG - 2021-10-22 11:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-22 11:02:01 --> Input Class Initialized
INFO - 2021-10-22 11:02:01 --> Language Class Initialized
INFO - 2021-10-22 11:02:01 --> Loader Class Initialized
INFO - 2021-10-22 11:02:01 --> Helper loaded: url_helper
INFO - 2021-10-22 11:02:01 --> Helper loaded: file_helper
DEBUG - 2021-10-22 11:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-22 11:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-22 11:02:01 --> Controller Class Initialized
INFO - 2021-10-22 11:02:01 --> Helper loaded: cookie_helper
INFO - 2021-10-22 11:02:01 --> Model "CookieModel" initialized
INFO - 2021-10-22 11:02:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-10-22 11:02:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-10-22 11:02:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-10-22 11:02:01 --> Final output sent to browser
DEBUG - 2021-10-22 11:02:01 --> Total execution time: 0.0579
INFO - 2021-10-22 11:02:04 --> Config Class Initialized
INFO - 2021-10-22 11:02:04 --> Hooks Class Initialized
DEBUG - 2021-10-22 11:02:04 --> UTF-8 Support Enabled
INFO - 2021-10-22 11:02:04 --> Utf8 Class Initialized
INFO - 2021-10-22 11:02:04 --> URI Class Initialized
INFO - 2021-10-22 11:02:04 --> Router Class Initialized
INFO - 2021-10-22 11:02:04 --> Output Class Initialized
INFO - 2021-10-22 11:02:04 --> Security Class Initialized
DEBUG - 2021-10-22 11:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-22 11:02:04 --> Input Class Initialized
INFO - 2021-10-22 11:02:04 --> Language Class Initialized
INFO - 2021-10-22 11:02:04 --> Loader Class Initialized
INFO - 2021-10-22 11:02:04 --> Helper loaded: url_helper
INFO - 2021-10-22 11:02:04 --> Helper loaded: file_helper
DEBUG - 2021-10-22 11:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-22 11:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-22 11:02:04 --> Controller Class Initialized
INFO - 2021-10-22 11:02:04 --> Database Driver Class Initialized
INFO - 2021-10-22 11:02:04 --> Model "BlogModel" initialized
INFO - 2021-10-22 11:02:04 --> Helper loaded: cookie_helper
INFO - 2021-10-22 11:02:04 --> Model "CookieModel" initialized
INFO - 2021-10-22 11:02:04 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-10-22 11:02:04 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-10-22 11:02:04 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-10-22 11:02:04 --> Final output sent to browser
DEBUG - 2021-10-22 11:02:04 --> Total execution time: 0.1952
INFO - 2021-10-22 11:02:06 --> Config Class Initialized
INFO - 2021-10-22 11:02:06 --> Hooks Class Initialized
DEBUG - 2021-10-22 11:02:06 --> UTF-8 Support Enabled
INFO - 2021-10-22 11:02:06 --> Utf8 Class Initialized
INFO - 2021-10-22 11:02:06 --> URI Class Initialized
INFO - 2021-10-22 11:02:06 --> Router Class Initialized
INFO - 2021-10-22 11:02:06 --> Output Class Initialized
INFO - 2021-10-22 11:02:06 --> Security Class Initialized
DEBUG - 2021-10-22 11:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-22 11:02:06 --> Input Class Initialized
INFO - 2021-10-22 11:02:06 --> Language Class Initialized
INFO - 2021-10-22 11:02:06 --> Loader Class Initialized
INFO - 2021-10-22 11:02:06 --> Helper loaded: url_helper
INFO - 2021-10-22 11:02:06 --> Helper loaded: file_helper
DEBUG - 2021-10-22 11:02:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-22 11:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-22 11:02:06 --> Controller Class Initialized
INFO - 2021-10-22 11:02:06 --> Database Driver Class Initialized
INFO - 2021-10-22 11:02:06 --> Model "BlogModel" initialized
INFO - 2021-10-22 11:02:06 --> Helper loaded: cookie_helper
INFO - 2021-10-22 11:02:06 --> Model "CookieModel" initialized
INFO - 2021-10-22 11:02:06 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-10-22 11:02:06 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blog.php
INFO - 2021-10-22 11:02:06 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-10-22 11:02:06 --> Final output sent to browser
DEBUG - 2021-10-22 11:02:06 --> Total execution time: 0.0689
INFO - 2021-10-22 11:07:55 --> Config Class Initialized
INFO - 2021-10-22 11:07:55 --> Hooks Class Initialized
DEBUG - 2021-10-22 11:07:55 --> UTF-8 Support Enabled
INFO - 2021-10-22 11:07:55 --> Utf8 Class Initialized
INFO - 2021-10-22 11:07:55 --> URI Class Initialized
INFO - 2021-10-22 11:07:55 --> Router Class Initialized
INFO - 2021-10-22 11:07:55 --> Output Class Initialized
INFO - 2021-10-22 11:07:55 --> Security Class Initialized
DEBUG - 2021-10-22 11:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-22 11:07:55 --> Input Class Initialized
INFO - 2021-10-22 11:07:55 --> Language Class Initialized
INFO - 2021-10-22 11:07:55 --> Loader Class Initialized
INFO - 2021-10-22 11:07:55 --> Helper loaded: url_helper
INFO - 2021-10-22 11:07:55 --> Helper loaded: file_helper
DEBUG - 2021-10-22 11:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-22 11:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-22 11:07:55 --> Controller Class Initialized
INFO - 2021-10-22 11:07:55 --> Database Driver Class Initialized
INFO - 2021-10-22 11:07:55 --> Model "BlogModel" initialized
INFO - 2021-10-22 11:07:55 --> Helper loaded: cookie_helper
INFO - 2021-10-22 11:07:55 --> Model "CookieModel" initialized
INFO - 2021-10-22 11:07:55 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-10-22 11:07:55 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blog.php
INFO - 2021-10-22 11:07:55 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-10-22 11:07:55 --> Final output sent to browser
DEBUG - 2021-10-22 11:07:55 --> Total execution time: 0.0591
INFO - 2021-10-22 11:10:18 --> Config Class Initialized
INFO - 2021-10-22 11:10:18 --> Hooks Class Initialized
DEBUG - 2021-10-22 11:10:18 --> UTF-8 Support Enabled
INFO - 2021-10-22 11:10:18 --> Utf8 Class Initialized
INFO - 2021-10-22 11:10:18 --> URI Class Initialized
INFO - 2021-10-22 11:10:18 --> Router Class Initialized
INFO - 2021-10-22 11:10:18 --> Output Class Initialized
INFO - 2021-10-22 11:10:18 --> Security Class Initialized
DEBUG - 2021-10-22 11:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-22 11:10:18 --> Input Class Initialized
INFO - 2021-10-22 11:10:18 --> Language Class Initialized
INFO - 2021-10-22 11:10:18 --> Loader Class Initialized
INFO - 2021-10-22 11:10:18 --> Helper loaded: url_helper
INFO - 2021-10-22 11:10:18 --> Helper loaded: file_helper
DEBUG - 2021-10-22 11:10:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-22 11:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-22 11:10:18 --> Controller Class Initialized
INFO - 2021-10-22 11:10:18 --> Database Driver Class Initialized
INFO - 2021-10-22 11:10:18 --> Model "BlogModel" initialized
INFO - 2021-10-22 11:10:18 --> Helper loaded: cookie_helper
INFO - 2021-10-22 11:10:18 --> Model "CookieModel" initialized
INFO - 2021-10-22 11:10:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-10-22 11:10:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blog.php
INFO - 2021-10-22 11:10:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-10-22 11:10:18 --> Final output sent to browser
DEBUG - 2021-10-22 11:10:18 --> Total execution time: 0.0489
INFO - 2021-10-22 11:11:46 --> Config Class Initialized
INFO - 2021-10-22 11:11:46 --> Hooks Class Initialized
DEBUG - 2021-10-22 11:11:46 --> UTF-8 Support Enabled
INFO - 2021-10-22 11:11:46 --> Utf8 Class Initialized
INFO - 2021-10-22 11:11:46 --> URI Class Initialized
INFO - 2021-10-22 11:11:46 --> Router Class Initialized
INFO - 2021-10-22 11:11:46 --> Output Class Initialized
INFO - 2021-10-22 11:11:46 --> Security Class Initialized
DEBUG - 2021-10-22 11:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-22 11:11:46 --> Input Class Initialized
INFO - 2021-10-22 11:11:46 --> Language Class Initialized
INFO - 2021-10-22 11:11:46 --> Loader Class Initialized
INFO - 2021-10-22 11:11:46 --> Helper loaded: url_helper
INFO - 2021-10-22 11:11:46 --> Helper loaded: file_helper
DEBUG - 2021-10-22 11:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-22 11:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-22 11:11:46 --> Controller Class Initialized
INFO - 2021-10-22 11:11:46 --> Database Driver Class Initialized
INFO - 2021-10-22 11:11:46 --> Model "BlogModel" initialized
INFO - 2021-10-22 11:11:46 --> Helper loaded: cookie_helper
INFO - 2021-10-22 11:11:46 --> Model "CookieModel" initialized
INFO - 2021-10-22 11:11:46 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-10-22 11:11:46 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blog.php
INFO - 2021-10-22 11:11:46 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-10-22 11:11:46 --> Final output sent to browser
DEBUG - 2021-10-22 11:11:46 --> Total execution time: 0.0470
INFO - 2021-10-22 11:12:07 --> Config Class Initialized
INFO - 2021-10-22 11:12:07 --> Hooks Class Initialized
DEBUG - 2021-10-22 11:12:07 --> UTF-8 Support Enabled
INFO - 2021-10-22 11:12:07 --> Utf8 Class Initialized
INFO - 2021-10-22 11:12:07 --> URI Class Initialized
INFO - 2021-10-22 11:12:07 --> Router Class Initialized
INFO - 2021-10-22 11:12:07 --> Output Class Initialized
INFO - 2021-10-22 11:12:07 --> Security Class Initialized
DEBUG - 2021-10-22 11:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-22 11:12:07 --> Input Class Initialized
INFO - 2021-10-22 11:12:07 --> Language Class Initialized
INFO - 2021-10-22 11:12:07 --> Loader Class Initialized
INFO - 2021-10-22 11:12:07 --> Helper loaded: url_helper
INFO - 2021-10-22 11:12:07 --> Helper loaded: file_helper
DEBUG - 2021-10-22 11:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-22 11:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-22 11:12:07 --> Controller Class Initialized
INFO - 2021-10-22 11:12:07 --> Database Driver Class Initialized
INFO - 2021-10-22 11:12:07 --> Model "BlogModel" initialized
INFO - 2021-10-22 11:12:07 --> Helper loaded: cookie_helper
INFO - 2021-10-22 11:12:07 --> Model "CookieModel" initialized
INFO - 2021-10-22 11:12:07 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-10-22 11:12:07 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blog.php
INFO - 2021-10-22 11:12:07 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-10-22 11:12:07 --> Final output sent to browser
DEBUG - 2021-10-22 11:12:07 --> Total execution time: 0.0451
INFO - 2021-10-22 11:12:08 --> Config Class Initialized
INFO - 2021-10-22 11:12:08 --> Hooks Class Initialized
DEBUG - 2021-10-22 11:12:08 --> UTF-8 Support Enabled
INFO - 2021-10-22 11:12:08 --> Utf8 Class Initialized
INFO - 2021-10-22 11:12:08 --> URI Class Initialized
INFO - 2021-10-22 11:12:08 --> Router Class Initialized
INFO - 2021-10-22 11:12:08 --> Output Class Initialized
INFO - 2021-10-22 11:12:08 --> Security Class Initialized
DEBUG - 2021-10-22 11:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-22 11:12:08 --> Input Class Initialized
INFO - 2021-10-22 11:12:08 --> Language Class Initialized
INFO - 2021-10-22 11:12:08 --> Loader Class Initialized
INFO - 2021-10-22 11:12:08 --> Helper loaded: url_helper
INFO - 2021-10-22 11:12:08 --> Helper loaded: file_helper
DEBUG - 2021-10-22 11:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-22 11:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-22 11:12:08 --> Controller Class Initialized
INFO - 2021-10-22 11:12:08 --> Database Driver Class Initialized
INFO - 2021-10-22 11:12:08 --> Model "BlogModel" initialized
INFO - 2021-10-22 11:12:08 --> Helper loaded: cookie_helper
INFO - 2021-10-22 11:12:08 --> Model "CookieModel" initialized
INFO - 2021-10-22 11:12:08 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-10-22 11:12:08 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blog.php
INFO - 2021-10-22 11:12:08 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-10-22 11:12:08 --> Final output sent to browser
DEBUG - 2021-10-22 11:12:08 --> Total execution time: 0.0392
INFO - 2021-10-22 11:12:08 --> Config Class Initialized
INFO - 2021-10-22 11:12:08 --> Hooks Class Initialized
DEBUG - 2021-10-22 11:12:08 --> UTF-8 Support Enabled
INFO - 2021-10-22 11:12:08 --> Utf8 Class Initialized
INFO - 2021-10-22 11:12:08 --> URI Class Initialized
INFO - 2021-10-22 11:12:08 --> Router Class Initialized
INFO - 2021-10-22 11:12:08 --> Output Class Initialized
INFO - 2021-10-22 11:12:08 --> Security Class Initialized
DEBUG - 2021-10-22 11:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-22 11:12:08 --> Input Class Initialized
INFO - 2021-10-22 11:12:08 --> Language Class Initialized
INFO - 2021-10-22 11:12:08 --> Loader Class Initialized
INFO - 2021-10-22 11:12:08 --> Helper loaded: url_helper
INFO - 2021-10-22 11:12:08 --> Helper loaded: file_helper
DEBUG - 2021-10-22 11:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-22 11:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-22 11:12:08 --> Controller Class Initialized
INFO - 2021-10-22 11:12:08 --> Database Driver Class Initialized
INFO - 2021-10-22 11:12:08 --> Model "BlogModel" initialized
INFO - 2021-10-22 11:12:08 --> Helper loaded: cookie_helper
INFO - 2021-10-22 11:12:08 --> Model "CookieModel" initialized
INFO - 2021-10-22 11:12:08 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-10-22 11:12:08 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blog.php
INFO - 2021-10-22 11:12:08 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-10-22 11:12:08 --> Final output sent to browser
DEBUG - 2021-10-22 11:12:08 --> Total execution time: 0.0523
INFO - 2021-10-22 11:12:09 --> Config Class Initialized
INFO - 2021-10-22 11:12:09 --> Hooks Class Initialized
DEBUG - 2021-10-22 11:12:09 --> UTF-8 Support Enabled
INFO - 2021-10-22 11:12:09 --> Utf8 Class Initialized
INFO - 2021-10-22 11:12:09 --> URI Class Initialized
INFO - 2021-10-22 11:12:09 --> Router Class Initialized
INFO - 2021-10-22 11:12:09 --> Output Class Initialized
INFO - 2021-10-22 11:12:09 --> Security Class Initialized
DEBUG - 2021-10-22 11:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-22 11:12:09 --> Input Class Initialized
INFO - 2021-10-22 11:12:09 --> Language Class Initialized
INFO - 2021-10-22 11:12:09 --> Loader Class Initialized
INFO - 2021-10-22 11:12:09 --> Helper loaded: url_helper
INFO - 2021-10-22 11:12:09 --> Helper loaded: file_helper
DEBUG - 2021-10-22 11:12:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-22 11:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-22 11:12:09 --> Controller Class Initialized
INFO - 2021-10-22 11:12:09 --> Database Driver Class Initialized
INFO - 2021-10-22 11:12:09 --> Model "BlogModel" initialized
INFO - 2021-10-22 11:12:09 --> Helper loaded: cookie_helper
INFO - 2021-10-22 11:12:09 --> Model "CookieModel" initialized
INFO - 2021-10-22 11:12:09 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-10-22 11:12:09 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blog.php
INFO - 2021-10-22 11:12:09 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-10-22 11:12:09 --> Final output sent to browser
DEBUG - 2021-10-22 11:12:09 --> Total execution time: 0.0402
INFO - 2021-10-22 11:12:09 --> Config Class Initialized
INFO - 2021-10-22 11:12:09 --> Hooks Class Initialized
DEBUG - 2021-10-22 11:12:09 --> UTF-8 Support Enabled
INFO - 2021-10-22 11:12:09 --> Utf8 Class Initialized
INFO - 2021-10-22 11:12:09 --> URI Class Initialized
INFO - 2021-10-22 11:12:09 --> Router Class Initialized
INFO - 2021-10-22 11:12:09 --> Output Class Initialized
INFO - 2021-10-22 11:12:09 --> Security Class Initialized
DEBUG - 2021-10-22 11:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-22 11:12:09 --> Input Class Initialized
INFO - 2021-10-22 11:12:09 --> Language Class Initialized
INFO - 2021-10-22 11:12:09 --> Loader Class Initialized
INFO - 2021-10-22 11:12:09 --> Helper loaded: url_helper
INFO - 2021-10-22 11:12:09 --> Helper loaded: file_helper
DEBUG - 2021-10-22 11:12:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-22 11:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-22 11:12:09 --> Controller Class Initialized
INFO - 2021-10-22 11:12:09 --> Database Driver Class Initialized
INFO - 2021-10-22 11:12:09 --> Model "BlogModel" initialized
INFO - 2021-10-22 11:12:09 --> Helper loaded: cookie_helper
INFO - 2021-10-22 11:12:09 --> Model "CookieModel" initialized
INFO - 2021-10-22 11:12:09 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-10-22 11:12:09 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blog.php
INFO - 2021-10-22 11:12:09 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-10-22 11:12:09 --> Final output sent to browser
DEBUG - 2021-10-22 11:12:09 --> Total execution time: 0.0662
INFO - 2021-10-22 11:12:35 --> Config Class Initialized
INFO - 2021-10-22 11:12:35 --> Hooks Class Initialized
DEBUG - 2021-10-22 11:12:35 --> UTF-8 Support Enabled
INFO - 2021-10-22 11:12:35 --> Utf8 Class Initialized
INFO - 2021-10-22 11:12:35 --> URI Class Initialized
INFO - 2021-10-22 11:12:35 --> Router Class Initialized
INFO - 2021-10-22 11:12:35 --> Output Class Initialized
INFO - 2021-10-22 11:12:35 --> Security Class Initialized
DEBUG - 2021-10-22 11:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-22 11:12:35 --> Input Class Initialized
INFO - 2021-10-22 11:12:35 --> Language Class Initialized
INFO - 2021-10-22 11:12:35 --> Loader Class Initialized
INFO - 2021-10-22 11:12:35 --> Helper loaded: url_helper
INFO - 2021-10-22 11:12:35 --> Helper loaded: file_helper
DEBUG - 2021-10-22 11:12:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-22 11:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-22 11:12:35 --> Controller Class Initialized
INFO - 2021-10-22 11:12:35 --> Database Driver Class Initialized
INFO - 2021-10-22 11:12:35 --> Model "BlogModel" initialized
INFO - 2021-10-22 11:12:35 --> Helper loaded: cookie_helper
INFO - 2021-10-22 11:12:35 --> Model "CookieModel" initialized
INFO - 2021-10-22 11:12:35 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-10-22 11:12:35 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blog.php
INFO - 2021-10-22 11:12:35 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-10-22 11:12:35 --> Final output sent to browser
DEBUG - 2021-10-22 11:12:35 --> Total execution time: 0.0426
INFO - 2021-10-22 11:12:51 --> Config Class Initialized
INFO - 2021-10-22 11:12:51 --> Hooks Class Initialized
DEBUG - 2021-10-22 11:12:51 --> UTF-8 Support Enabled
INFO - 2021-10-22 11:12:51 --> Utf8 Class Initialized
INFO - 2021-10-22 11:12:51 --> URI Class Initialized
INFO - 2021-10-22 11:12:51 --> Router Class Initialized
INFO - 2021-10-22 11:12:51 --> Output Class Initialized
INFO - 2021-10-22 11:12:51 --> Security Class Initialized
DEBUG - 2021-10-22 11:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-22 11:12:51 --> Input Class Initialized
INFO - 2021-10-22 11:12:51 --> Language Class Initialized
INFO - 2021-10-22 11:12:51 --> Loader Class Initialized
INFO - 2021-10-22 11:12:51 --> Helper loaded: url_helper
INFO - 2021-10-22 11:12:51 --> Helper loaded: file_helper
DEBUG - 2021-10-22 11:12:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-22 11:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-22 11:12:51 --> Controller Class Initialized
INFO - 2021-10-22 11:12:51 --> Database Driver Class Initialized
INFO - 2021-10-22 11:12:51 --> Model "BlogModel" initialized
INFO - 2021-10-22 11:12:51 --> Helper loaded: cookie_helper
INFO - 2021-10-22 11:12:51 --> Model "CookieModel" initialized
INFO - 2021-10-22 11:12:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-10-22 11:12:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blog.php
INFO - 2021-10-22 11:12:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-10-22 11:12:51 --> Final output sent to browser
DEBUG - 2021-10-22 11:12:51 --> Total execution time: 0.0482
INFO - 2021-10-22 11:20:05 --> Config Class Initialized
INFO - 2021-10-22 11:20:05 --> Hooks Class Initialized
DEBUG - 2021-10-22 11:20:05 --> UTF-8 Support Enabled
INFO - 2021-10-22 11:20:05 --> Utf8 Class Initialized
INFO - 2021-10-22 11:20:05 --> URI Class Initialized
DEBUG - 2021-10-22 11:20:05 --> No URI present. Default controller set.
INFO - 2021-10-22 11:20:05 --> Router Class Initialized
INFO - 2021-10-22 11:20:05 --> Output Class Initialized
INFO - 2021-10-22 11:20:05 --> Security Class Initialized
DEBUG - 2021-10-22 11:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-22 11:20:05 --> Input Class Initialized
INFO - 2021-10-22 11:20:05 --> Language Class Initialized
INFO - 2021-10-22 11:20:05 --> Loader Class Initialized
INFO - 2021-10-22 11:20:05 --> Helper loaded: url_helper
INFO - 2021-10-22 11:20:05 --> Helper loaded: file_helper
DEBUG - 2021-10-22 11:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-22 11:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-22 11:20:05 --> Controller Class Initialized
INFO - 2021-10-22 11:20:05 --> Helper loaded: cookie_helper
INFO - 2021-10-22 11:20:05 --> Model "CookieModel" initialized
INFO - 2021-10-22 11:20:05 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-10-22 11:20:05 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-10-22 11:20:05 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-10-22 11:20:05 --> Final output sent to browser
DEBUG - 2021-10-22 11:20:05 --> Total execution time: 0.0461
INFO - 2021-10-22 11:20:27 --> Config Class Initialized
INFO - 2021-10-22 11:20:27 --> Hooks Class Initialized
DEBUG - 2021-10-22 11:20:27 --> UTF-8 Support Enabled
INFO - 2021-10-22 11:20:27 --> Utf8 Class Initialized
INFO - 2021-10-22 11:20:27 --> URI Class Initialized
INFO - 2021-10-22 11:20:27 --> Router Class Initialized
INFO - 2021-10-22 11:20:27 --> Output Class Initialized
INFO - 2021-10-22 11:20:27 --> Security Class Initialized
DEBUG - 2021-10-22 11:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-22 11:20:27 --> Input Class Initialized
INFO - 2021-10-22 11:20:27 --> Language Class Initialized
INFO - 2021-10-22 11:20:27 --> Loader Class Initialized
INFO - 2021-10-22 11:20:27 --> Helper loaded: url_helper
INFO - 2021-10-22 11:20:27 --> Helper loaded: file_helper
DEBUG - 2021-10-22 11:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-22 11:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-22 11:20:27 --> Controller Class Initialized
INFO - 2021-10-22 11:20:27 --> Helper loaded: cookie_helper
INFO - 2021-10-22 11:20:27 --> Model "CookieModel" initialized
INFO - 2021-10-22 11:20:27 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-10-22 11:20:27 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/team.php
INFO - 2021-10-22 11:20:27 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-10-22 11:20:27 --> Final output sent to browser
DEBUG - 2021-10-22 11:20:27 --> Total execution time: 0.0354
INFO - 2021-10-22 11:20:31 --> Config Class Initialized
INFO - 2021-10-22 11:20:31 --> Hooks Class Initialized
DEBUG - 2021-10-22 11:20:31 --> UTF-8 Support Enabled
INFO - 2021-10-22 11:20:31 --> Utf8 Class Initialized
INFO - 2021-10-22 11:20:31 --> URI Class Initialized
DEBUG - 2021-10-22 11:20:31 --> No URI present. Default controller set.
INFO - 2021-10-22 11:20:31 --> Router Class Initialized
INFO - 2021-10-22 11:20:31 --> Output Class Initialized
INFO - 2021-10-22 11:20:31 --> Security Class Initialized
DEBUG - 2021-10-22 11:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-22 11:20:31 --> Input Class Initialized
INFO - 2021-10-22 11:20:31 --> Language Class Initialized
INFO - 2021-10-22 11:20:31 --> Loader Class Initialized
INFO - 2021-10-22 11:20:31 --> Helper loaded: url_helper
INFO - 2021-10-22 11:20:31 --> Helper loaded: file_helper
DEBUG - 2021-10-22 11:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-22 11:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-22 11:20:31 --> Controller Class Initialized
INFO - 2021-10-22 11:20:31 --> Helper loaded: cookie_helper
INFO - 2021-10-22 11:20:31 --> Model "CookieModel" initialized
INFO - 2021-10-22 11:20:31 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-10-22 11:20:31 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-10-22 11:20:31 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-10-22 11:20:31 --> Final output sent to browser
DEBUG - 2021-10-22 11:20:31 --> Total execution time: 0.0379
INFO - 2021-10-22 11:20:42 --> Config Class Initialized
INFO - 2021-10-22 11:20:42 --> Hooks Class Initialized
DEBUG - 2021-10-22 11:20:42 --> UTF-8 Support Enabled
INFO - 2021-10-22 11:20:42 --> Utf8 Class Initialized
INFO - 2021-10-22 11:20:42 --> URI Class Initialized
INFO - 2021-10-22 11:20:42 --> Router Class Initialized
INFO - 2021-10-22 11:20:42 --> Output Class Initialized
INFO - 2021-10-22 11:20:42 --> Security Class Initialized
DEBUG - 2021-10-22 11:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-22 11:20:42 --> Input Class Initialized
INFO - 2021-10-22 11:20:42 --> Language Class Initialized
INFO - 2021-10-22 11:20:42 --> Loader Class Initialized
INFO - 2021-10-22 11:20:42 --> Helper loaded: url_helper
INFO - 2021-10-22 11:20:42 --> Helper loaded: file_helper
DEBUG - 2021-10-22 11:20:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-22 11:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-22 11:20:42 --> Controller Class Initialized
DEBUG - 2021-10-22 11:20:42 --> Session class already loaded. Second attempt ignored.
INFO - 2021-10-22 11:20:42 --> Helper loaded: cookie_helper
INFO - 2021-10-22 11:20:42 --> File loaded: E:\xampp\htdocs\changeme\application\views\login.php
INFO - 2021-10-22 11:20:42 --> Final output sent to browser
DEBUG - 2021-10-22 11:20:42 --> Total execution time: 0.0325
INFO - 2021-10-22 11:20:45 --> Config Class Initialized
INFO - 2021-10-22 11:20:45 --> Hooks Class Initialized
DEBUG - 2021-10-22 11:20:45 --> UTF-8 Support Enabled
INFO - 2021-10-22 11:20:45 --> Utf8 Class Initialized
INFO - 2021-10-22 11:20:45 --> URI Class Initialized
INFO - 2021-10-22 11:20:45 --> Router Class Initialized
INFO - 2021-10-22 11:20:45 --> Output Class Initialized
INFO - 2021-10-22 11:20:45 --> Security Class Initialized
DEBUG - 2021-10-22 11:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-22 11:20:45 --> Input Class Initialized
INFO - 2021-10-22 11:20:45 --> Language Class Initialized
INFO - 2021-10-22 11:20:45 --> Loader Class Initialized
INFO - 2021-10-22 11:20:45 --> Helper loaded: url_helper
INFO - 2021-10-22 11:20:45 --> Helper loaded: file_helper
DEBUG - 2021-10-22 11:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-22 11:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-22 11:20:45 --> Controller Class Initialized
DEBUG - 2021-10-22 11:20:45 --> Session class already loaded. Second attempt ignored.
INFO - 2021-10-22 11:20:45 --> Helper loaded: cookie_helper
INFO - 2021-10-22 11:20:45 --> Config Class Initialized
INFO - 2021-10-22 11:20:45 --> Hooks Class Initialized
DEBUG - 2021-10-22 11:20:45 --> UTF-8 Support Enabled
INFO - 2021-10-22 11:20:45 --> Utf8 Class Initialized
INFO - 2021-10-22 11:20:45 --> URI Class Initialized
INFO - 2021-10-22 11:20:45 --> Router Class Initialized
INFO - 2021-10-22 11:20:45 --> Output Class Initialized
INFO - 2021-10-22 11:20:45 --> Security Class Initialized
DEBUG - 2021-10-22 11:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-22 11:20:45 --> Input Class Initialized
INFO - 2021-10-22 11:20:45 --> Language Class Initialized
INFO - 2021-10-22 11:20:45 --> Loader Class Initialized
INFO - 2021-10-22 11:20:45 --> Helper loaded: url_helper
INFO - 2021-10-22 11:20:45 --> Helper loaded: file_helper
DEBUG - 2021-10-22 11:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-22 11:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-22 11:20:45 --> Controller Class Initialized
INFO - 2021-10-22 11:20:45 --> Model "DBModel" initialized
DEBUG - 2021-10-22 11:20:45 --> Session class already loaded. Second attempt ignored.
INFO - 2021-10-22 11:20:45 --> Helper loaded: cookie_helper
INFO - 2021-10-22 11:20:45 --> Database Driver Class Initialized
INFO - 2021-10-22 11:20:45 --> Helper loaded: string_helper
INFO - 2021-10-22 11:20:45 --> Model "TestimonialModel" initialized
INFO - 2021-10-22 11:20:45 --> Model "BlogModel" initialized
INFO - 2021-10-22 11:20:45 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-10-22 11:20:45 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-10-22 11:20:45 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-10-22 11:20:45 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/dashboard.php
INFO - 2021-10-22 11:20:45 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-10-22 11:20:45 --> Final output sent to browser
DEBUG - 2021-10-22 11:20:45 --> Total execution time: 0.0478
INFO - 2021-10-22 11:20:47 --> Config Class Initialized
INFO - 2021-10-22 11:20:47 --> Hooks Class Initialized
DEBUG - 2021-10-22 11:20:47 --> UTF-8 Support Enabled
INFO - 2021-10-22 11:20:47 --> Utf8 Class Initialized
INFO - 2021-10-22 11:20:47 --> URI Class Initialized
INFO - 2021-10-22 11:20:47 --> Router Class Initialized
INFO - 2021-10-22 11:20:47 --> Output Class Initialized
INFO - 2021-10-22 11:20:47 --> Security Class Initialized
DEBUG - 2021-10-22 11:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-22 11:20:47 --> Input Class Initialized
INFO - 2021-10-22 11:20:47 --> Language Class Initialized
INFO - 2021-10-22 11:20:47 --> Loader Class Initialized
INFO - 2021-10-22 11:20:47 --> Helper loaded: url_helper
INFO - 2021-10-22 11:20:47 --> Helper loaded: file_helper
DEBUG - 2021-10-22 11:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-22 11:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-22 11:20:47 --> Controller Class Initialized
INFO - 2021-10-22 11:20:47 --> Model "DBModel" initialized
DEBUG - 2021-10-22 11:20:47 --> Session class already loaded. Second attempt ignored.
INFO - 2021-10-22 11:20:47 --> Helper loaded: cookie_helper
INFO - 2021-10-22 11:20:47 --> Database Driver Class Initialized
INFO - 2021-10-22 11:20:47 --> Helper loaded: string_helper
INFO - 2021-10-22 11:20:47 --> Model "TestimonialModel" initialized
INFO - 2021-10-22 11:20:47 --> Model "BlogModel" initialized
INFO - 2021-10-22 11:20:47 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-10-22 11:20:47 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-10-22 11:20:47 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-10-22 11:20:47 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonials.php
INFO - 2021-10-22 11:20:47 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-10-22 11:20:47 --> Final output sent to browser
DEBUG - 2021-10-22 11:20:47 --> Total execution time: 0.0607
INFO - 2021-10-22 11:20:51 --> Config Class Initialized
INFO - 2021-10-22 11:20:51 --> Hooks Class Initialized
DEBUG - 2021-10-22 11:20:51 --> UTF-8 Support Enabled
INFO - 2021-10-22 11:20:51 --> Utf8 Class Initialized
INFO - 2021-10-22 11:20:51 --> URI Class Initialized
INFO - 2021-10-22 11:20:51 --> Router Class Initialized
INFO - 2021-10-22 11:20:51 --> Output Class Initialized
INFO - 2021-10-22 11:20:51 --> Security Class Initialized
DEBUG - 2021-10-22 11:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-22 11:20:51 --> Input Class Initialized
INFO - 2021-10-22 11:20:51 --> Language Class Initialized
INFO - 2021-10-22 11:20:51 --> Loader Class Initialized
INFO - 2021-10-22 11:20:51 --> Helper loaded: url_helper
INFO - 2021-10-22 11:20:51 --> Helper loaded: file_helper
DEBUG - 2021-10-22 11:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-22 11:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-22 11:20:51 --> Controller Class Initialized
INFO - 2021-10-22 11:20:51 --> Model "DBModel" initialized
DEBUG - 2021-10-22 11:20:51 --> Session class already loaded. Second attempt ignored.
INFO - 2021-10-22 11:20:51 --> Helper loaded: cookie_helper
INFO - 2021-10-22 11:20:51 --> Database Driver Class Initialized
INFO - 2021-10-22 11:20:51 --> Helper loaded: string_helper
INFO - 2021-10-22 11:20:51 --> Model "TestimonialModel" initialized
INFO - 2021-10-22 11:20:51 --> Model "BlogModel" initialized
INFO - 2021-10-22 11:20:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-10-22 11:20:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-10-22 11:20:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-10-22 11:20:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/blogs.php
INFO - 2021-10-22 11:20:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-10-22 11:20:51 --> Final output sent to browser
DEBUG - 2021-10-22 11:20:51 --> Total execution time: 0.0486
INFO - 2021-10-22 11:20:58 --> Config Class Initialized
INFO - 2021-10-22 11:20:58 --> Hooks Class Initialized
DEBUG - 2021-10-22 11:20:58 --> UTF-8 Support Enabled
INFO - 2021-10-22 11:20:58 --> Utf8 Class Initialized
INFO - 2021-10-22 11:20:58 --> URI Class Initialized
INFO - 2021-10-22 11:20:58 --> Router Class Initialized
INFO - 2021-10-22 11:20:58 --> Output Class Initialized
INFO - 2021-10-22 11:20:58 --> Security Class Initialized
DEBUG - 2021-10-22 11:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-22 11:20:58 --> Input Class Initialized
INFO - 2021-10-22 11:20:58 --> Language Class Initialized
INFO - 2021-10-22 11:20:58 --> Loader Class Initialized
INFO - 2021-10-22 11:20:58 --> Helper loaded: url_helper
INFO - 2021-10-22 11:20:58 --> Helper loaded: file_helper
DEBUG - 2021-10-22 11:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-22 11:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-22 11:20:58 --> Controller Class Initialized
INFO - 2021-10-22 11:20:58 --> Model "DBModel" initialized
DEBUG - 2021-10-22 11:20:58 --> Session class already loaded. Second attempt ignored.
INFO - 2021-10-22 11:20:58 --> Helper loaded: cookie_helper
INFO - 2021-10-22 11:20:58 --> Database Driver Class Initialized
INFO - 2021-10-22 11:20:58 --> Helper loaded: string_helper
INFO - 2021-10-22 11:20:58 --> Model "TestimonialModel" initialized
INFO - 2021-10-22 11:20:58 --> Model "BlogModel" initialized
INFO - 2021-10-22 11:20:58 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-10-22 11:20:58 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-10-22 11:20:58 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-10-22 11:20:58 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonials.php
INFO - 2021-10-22 11:20:58 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-10-22 11:20:58 --> Final output sent to browser
DEBUG - 2021-10-22 11:20:58 --> Total execution time: 0.0447
INFO - 2021-10-22 11:22:11 --> Config Class Initialized
INFO - 2021-10-22 11:22:11 --> Hooks Class Initialized
DEBUG - 2021-10-22 11:22:11 --> UTF-8 Support Enabled
INFO - 2021-10-22 11:22:11 --> Utf8 Class Initialized
INFO - 2021-10-22 11:22:11 --> URI Class Initialized
INFO - 2021-10-22 11:22:11 --> Router Class Initialized
INFO - 2021-10-22 11:22:11 --> Output Class Initialized
INFO - 2021-10-22 11:22:11 --> Security Class Initialized
DEBUG - 2021-10-22 11:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-22 11:22:11 --> Input Class Initialized
INFO - 2021-10-22 11:22:11 --> Language Class Initialized
INFO - 2021-10-22 11:22:11 --> Loader Class Initialized
INFO - 2021-10-22 11:22:11 --> Helper loaded: url_helper
INFO - 2021-10-22 11:22:11 --> Helper loaded: file_helper
DEBUG - 2021-10-22 11:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-22 11:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-22 11:22:11 --> Controller Class Initialized
INFO - 2021-10-22 11:22:11 --> Model "DBModel" initialized
DEBUG - 2021-10-22 11:22:11 --> Session class already loaded. Second attempt ignored.
INFO - 2021-10-22 11:22:11 --> Helper loaded: cookie_helper
INFO - 2021-10-22 11:22:11 --> Database Driver Class Initialized
INFO - 2021-10-22 11:22:11 --> Helper loaded: string_helper
INFO - 2021-10-22 11:22:11 --> Model "TestimonialModel" initialized
INFO - 2021-10-22 11:22:11 --> Model "BlogModel" initialized
INFO - 2021-10-22 11:22:11 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-10-22 11:22:11 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-10-22 11:22:11 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-10-22 11:22:11 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/blogs.php
INFO - 2021-10-22 11:22:11 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-10-22 11:22:11 --> Final output sent to browser
DEBUG - 2021-10-22 11:22:11 --> Total execution time: 0.0527
INFO - 2021-10-22 22:29:29 --> Config Class Initialized
INFO - 2021-10-22 22:29:29 --> Hooks Class Initialized
DEBUG - 2021-10-22 22:29:29 --> UTF-8 Support Enabled
INFO - 2021-10-22 22:29:29 --> Utf8 Class Initialized
INFO - 2021-10-22 22:29:29 --> URI Class Initialized
INFO - 2021-10-22 22:29:29 --> Router Class Initialized
INFO - 2021-10-22 22:29:29 --> Output Class Initialized
INFO - 2021-10-22 22:29:29 --> Security Class Initialized
DEBUG - 2021-10-22 22:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-22 22:29:29 --> Input Class Initialized
INFO - 2021-10-22 22:29:29 --> Language Class Initialized
INFO - 2021-10-22 22:29:29 --> Loader Class Initialized
INFO - 2021-10-22 22:29:29 --> Helper loaded: url_helper
INFO - 2021-10-22 22:29:29 --> Helper loaded: file_helper
DEBUG - 2021-10-22 22:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-22 22:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-22 22:29:29 --> Controller Class Initialized
INFO - 2021-10-22 22:29:29 --> Model "DBModel" initialized
DEBUG - 2021-10-22 22:29:29 --> Session class already loaded. Second attempt ignored.
INFO - 2021-10-22 22:29:29 --> Helper loaded: cookie_helper
INFO - 2021-10-22 22:29:29 --> Database Driver Class Initialized
INFO - 2021-10-22 22:29:29 --> Helper loaded: string_helper
INFO - 2021-10-22 22:29:29 --> Model "TestimonialModel" initialized
INFO - 2021-10-22 22:29:29 --> Model "BlogModel" initialized
INFO - 2021-10-22 22:29:29 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-10-22 22:29:29 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-10-22 22:29:29 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-10-22 22:29:29 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/blogs.php
INFO - 2021-10-22 22:29:29 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-10-22 22:29:29 --> Final output sent to browser
DEBUG - 2021-10-22 22:29:29 --> Total execution time: 0.1771
