<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-09-23 12:23:03 --> Config Class Initialized
INFO - 2021-09-23 12:23:03 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:23:03 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:23:03 --> Utf8 Class Initialized
INFO - 2021-09-23 12:23:03 --> URI Class Initialized
INFO - 2021-09-23 12:23:03 --> Router Class Initialized
INFO - 2021-09-23 12:23:03 --> Output Class Initialized
INFO - 2021-09-23 12:23:03 --> Security Class Initialized
DEBUG - 2021-09-23 12:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:23:03 --> Input Class Initialized
INFO - 2021-09-23 12:23:03 --> Language Class Initialized
INFO - 2021-09-23 12:23:03 --> Loader Class Initialized
INFO - 2021-09-23 12:23:03 --> Helper loaded: url_helper
INFO - 2021-09-23 12:23:03 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:23:03 --> Controller Class Initialized
DEBUG - 2021-09-23 12:23:03 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:23:03 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:23:03 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\login.php
INFO - 2021-09-23 12:23:03 --> Final output sent to browser
DEBUG - 2021-09-23 12:23:03 --> Total execution time: 0.0690
INFO - 2021-09-23 12:23:04 --> Config Class Initialized
INFO - 2021-09-23 12:23:04 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:23:04 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:23:04 --> Utf8 Class Initialized
INFO - 2021-09-23 12:23:04 --> URI Class Initialized
INFO - 2021-09-23 12:23:04 --> Router Class Initialized
INFO - 2021-09-23 12:23:04 --> Output Class Initialized
INFO - 2021-09-23 12:23:04 --> Security Class Initialized
DEBUG - 2021-09-23 12:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:23:04 --> Input Class Initialized
INFO - 2021-09-23 12:23:04 --> Language Class Initialized
INFO - 2021-09-23 12:23:04 --> Loader Class Initialized
INFO - 2021-09-23 12:23:04 --> Helper loaded: url_helper
INFO - 2021-09-23 12:23:04 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:23:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:23:04 --> Controller Class Initialized
DEBUG - 2021-09-23 12:23:04 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:23:04 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:23:04 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\login.php
INFO - 2021-09-23 12:23:04 --> Final output sent to browser
DEBUG - 2021-09-23 12:23:04 --> Total execution time: 0.0701
INFO - 2021-09-23 12:23:06 --> Config Class Initialized
INFO - 2021-09-23 12:23:06 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:23:06 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:23:06 --> Utf8 Class Initialized
INFO - 2021-09-23 12:23:06 --> URI Class Initialized
INFO - 2021-09-23 12:23:06 --> Router Class Initialized
INFO - 2021-09-23 12:23:06 --> Output Class Initialized
INFO - 2021-09-23 12:23:06 --> Security Class Initialized
DEBUG - 2021-09-23 12:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:23:06 --> Input Class Initialized
INFO - 2021-09-23 12:23:06 --> Language Class Initialized
INFO - 2021-09-23 12:23:06 --> Loader Class Initialized
INFO - 2021-09-23 12:23:06 --> Helper loaded: url_helper
INFO - 2021-09-23 12:23:06 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:23:06 --> Controller Class Initialized
DEBUG - 2021-09-23 12:23:06 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:23:06 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:23:06 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\login.php
INFO - 2021-09-23 12:23:06 --> Final output sent to browser
DEBUG - 2021-09-23 12:23:06 --> Total execution time: 0.0657
INFO - 2021-09-23 12:23:13 --> Config Class Initialized
INFO - 2021-09-23 12:23:13 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:23:13 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:23:13 --> Utf8 Class Initialized
INFO - 2021-09-23 12:23:13 --> URI Class Initialized
INFO - 2021-09-23 12:23:13 --> Router Class Initialized
INFO - 2021-09-23 12:23:13 --> Output Class Initialized
INFO - 2021-09-23 12:23:13 --> Security Class Initialized
DEBUG - 2021-09-23 12:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:23:13 --> Input Class Initialized
INFO - 2021-09-23 12:23:13 --> Language Class Initialized
INFO - 2021-09-23 12:23:13 --> Loader Class Initialized
INFO - 2021-09-23 12:23:13 --> Helper loaded: url_helper
INFO - 2021-09-23 12:23:13 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:23:13 --> Controller Class Initialized
DEBUG - 2021-09-23 12:23:13 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:23:13 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:23:13 --> Config Class Initialized
INFO - 2021-09-23 12:23:13 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:23:13 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:23:13 --> Utf8 Class Initialized
INFO - 2021-09-23 12:23:13 --> URI Class Initialized
INFO - 2021-09-23 12:23:13 --> Router Class Initialized
INFO - 2021-09-23 12:23:13 --> Output Class Initialized
INFO - 2021-09-23 12:23:13 --> Security Class Initialized
DEBUG - 2021-09-23 12:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:23:13 --> Input Class Initialized
INFO - 2021-09-23 12:23:13 --> Language Class Initialized
INFO - 2021-09-23 12:23:13 --> Loader Class Initialized
INFO - 2021-09-23 12:23:13 --> Helper loaded: url_helper
INFO - 2021-09-23 12:23:13 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:23:13 --> Controller Class Initialized
INFO - 2021-09-23 12:23:13 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:23:13 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:23:13 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:23:13 --> Database Driver Class Initialized
INFO - 2021-09-23 12:23:13 --> Helper loaded: string_helper
INFO - 2021-09-23 12:23:13 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:23:13 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:23:13 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-23 12:23:13 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-23 12:23:13 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-23 12:23:13 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/dashboard.php
INFO - 2021-09-23 12:23:13 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-23 12:23:13 --> Final output sent to browser
DEBUG - 2021-09-23 12:23:13 --> Total execution time: 0.0891
INFO - 2021-09-23 12:23:21 --> Config Class Initialized
INFO - 2021-09-23 12:23:21 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:23:21 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:23:21 --> Utf8 Class Initialized
INFO - 2021-09-23 12:23:21 --> URI Class Initialized
INFO - 2021-09-23 12:23:21 --> Router Class Initialized
INFO - 2021-09-23 12:23:21 --> Output Class Initialized
INFO - 2021-09-23 12:23:21 --> Security Class Initialized
DEBUG - 2021-09-23 12:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:23:21 --> Input Class Initialized
INFO - 2021-09-23 12:23:21 --> Language Class Initialized
INFO - 2021-09-23 12:23:21 --> Loader Class Initialized
INFO - 2021-09-23 12:23:21 --> Helper loaded: url_helper
INFO - 2021-09-23 12:23:21 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:23:21 --> Controller Class Initialized
INFO - 2021-09-23 12:23:21 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:23:21 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:23:21 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:23:21 --> Database Driver Class Initialized
INFO - 2021-09-23 12:23:21 --> Helper loaded: string_helper
INFO - 2021-09-23 12:23:21 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:23:21 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:23:21 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-23 12:23:21 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-23 12:23:21 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-23 12:23:21 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/testimonials.php
INFO - 2021-09-23 12:23:21 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-23 12:23:21 --> Final output sent to browser
DEBUG - 2021-09-23 12:23:21 --> Total execution time: 0.1002
INFO - 2021-09-23 12:23:24 --> Config Class Initialized
INFO - 2021-09-23 12:23:24 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:23:24 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:23:24 --> Utf8 Class Initialized
INFO - 2021-09-23 12:23:24 --> URI Class Initialized
INFO - 2021-09-23 12:23:24 --> Router Class Initialized
INFO - 2021-09-23 12:23:24 --> Output Class Initialized
INFO - 2021-09-23 12:23:24 --> Security Class Initialized
DEBUG - 2021-09-23 12:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:23:24 --> Input Class Initialized
INFO - 2021-09-23 12:23:24 --> Language Class Initialized
INFO - 2021-09-23 12:23:24 --> Loader Class Initialized
INFO - 2021-09-23 12:23:24 --> Helper loaded: url_helper
INFO - 2021-09-23 12:23:24 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:23:24 --> Controller Class Initialized
INFO - 2021-09-23 12:23:24 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:23:24 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:23:24 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:23:24 --> Database Driver Class Initialized
INFO - 2021-09-23 12:23:24 --> Helper loaded: string_helper
INFO - 2021-09-23 12:23:24 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:23:24 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:23:24 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-23 12:23:24 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-23 12:23:24 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-23 12:23:24 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/dashboard.php
INFO - 2021-09-23 12:23:24 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-23 12:23:24 --> Final output sent to browser
DEBUG - 2021-09-23 12:23:24 --> Total execution time: 0.0858
INFO - 2021-09-23 12:24:32 --> Config Class Initialized
INFO - 2021-09-23 12:24:32 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:24:32 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:24:32 --> Utf8 Class Initialized
INFO - 2021-09-23 12:24:32 --> URI Class Initialized
INFO - 2021-09-23 12:24:32 --> Router Class Initialized
INFO - 2021-09-23 12:24:32 --> Output Class Initialized
INFO - 2021-09-23 12:24:32 --> Security Class Initialized
DEBUG - 2021-09-23 12:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:24:32 --> Input Class Initialized
INFO - 2021-09-23 12:24:32 --> Language Class Initialized
INFO - 2021-09-23 12:24:32 --> Loader Class Initialized
INFO - 2021-09-23 12:24:32 --> Helper loaded: url_helper
INFO - 2021-09-23 12:24:32 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:24:32 --> Controller Class Initialized
INFO - 2021-09-23 12:24:32 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:24:32 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:24:32 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:24:32 --> Database Driver Class Initialized
INFO - 2021-09-23 12:24:32 --> Helper loaded: string_helper
INFO - 2021-09-23 12:24:32 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:24:32 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:24:32 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-23 12:24:32 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-23 12:24:32 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-23 12:24:32 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/dashboard.php
INFO - 2021-09-23 12:24:32 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-23 12:24:32 --> Final output sent to browser
DEBUG - 2021-09-23 12:24:32 --> Total execution time: 0.0908
INFO - 2021-09-23 12:24:53 --> Config Class Initialized
INFO - 2021-09-23 12:24:53 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:24:53 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:24:53 --> Utf8 Class Initialized
INFO - 2021-09-23 12:24:53 --> URI Class Initialized
INFO - 2021-09-23 12:24:53 --> Router Class Initialized
INFO - 2021-09-23 12:24:53 --> Output Class Initialized
INFO - 2021-09-23 12:24:53 --> Security Class Initialized
DEBUG - 2021-09-23 12:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:24:53 --> Input Class Initialized
INFO - 2021-09-23 12:24:53 --> Language Class Initialized
INFO - 2021-09-23 12:24:53 --> Loader Class Initialized
INFO - 2021-09-23 12:24:53 --> Helper loaded: url_helper
INFO - 2021-09-23 12:24:53 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:24:53 --> Controller Class Initialized
INFO - 2021-09-23 12:24:53 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:24:53 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:24:53 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:24:53 --> Database Driver Class Initialized
INFO - 2021-09-23 12:24:53 --> Helper loaded: string_helper
INFO - 2021-09-23 12:24:53 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:24:53 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:24:53 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-23 12:24:53 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-23 12:24:53 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-23 12:24:53 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/dashboard.php
INFO - 2021-09-23 12:24:53 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-23 12:24:53 --> Final output sent to browser
DEBUG - 2021-09-23 12:24:53 --> Total execution time: 0.0781
INFO - 2021-09-23 12:24:59 --> Config Class Initialized
INFO - 2021-09-23 12:24:59 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:24:59 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:24:59 --> Utf8 Class Initialized
INFO - 2021-09-23 12:24:59 --> URI Class Initialized
INFO - 2021-09-23 12:24:59 --> Router Class Initialized
INFO - 2021-09-23 12:24:59 --> Output Class Initialized
INFO - 2021-09-23 12:24:59 --> Security Class Initialized
DEBUG - 2021-09-23 12:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:24:59 --> Input Class Initialized
INFO - 2021-09-23 12:24:59 --> Language Class Initialized
INFO - 2021-09-23 12:24:59 --> Loader Class Initialized
INFO - 2021-09-23 12:24:59 --> Helper loaded: url_helper
INFO - 2021-09-23 12:24:59 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:24:59 --> Controller Class Initialized
INFO - 2021-09-23 12:24:59 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:24:59 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:24:59 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:24:59 --> Database Driver Class Initialized
INFO - 2021-09-23 12:24:59 --> Helper loaded: string_helper
INFO - 2021-09-23 12:24:59 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:24:59 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:24:59 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-23 12:24:59 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-23 12:24:59 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-23 12:24:59 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/testimonials.php
INFO - 2021-09-23 12:24:59 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-23 12:24:59 --> Final output sent to browser
DEBUG - 2021-09-23 12:24:59 --> Total execution time: 0.0814
INFO - 2021-09-23 12:25:01 --> Config Class Initialized
INFO - 2021-09-23 12:25:01 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:25:01 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:25:01 --> Utf8 Class Initialized
INFO - 2021-09-23 12:25:01 --> URI Class Initialized
INFO - 2021-09-23 12:25:01 --> Router Class Initialized
INFO - 2021-09-23 12:25:01 --> Output Class Initialized
INFO - 2021-09-23 12:25:01 --> Security Class Initialized
DEBUG - 2021-09-23 12:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:25:01 --> Input Class Initialized
INFO - 2021-09-23 12:25:01 --> Language Class Initialized
INFO - 2021-09-23 12:25:01 --> Loader Class Initialized
INFO - 2021-09-23 12:25:01 --> Helper loaded: url_helper
INFO - 2021-09-23 12:25:01 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:25:01 --> Controller Class Initialized
DEBUG - 2021-09-23 12:25:01 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:25:01 --> Config Class Initialized
INFO - 2021-09-23 12:25:01 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:25:01 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:25:01 --> Utf8 Class Initialized
INFO - 2021-09-23 12:25:01 --> URI Class Initialized
DEBUG - 2021-09-23 12:25:01 --> No URI present. Default controller set.
INFO - 2021-09-23 12:25:01 --> Router Class Initialized
INFO - 2021-09-23 12:25:01 --> Output Class Initialized
INFO - 2021-09-23 12:25:01 --> Security Class Initialized
DEBUG - 2021-09-23 12:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:25:01 --> Input Class Initialized
INFO - 2021-09-23 12:25:01 --> Language Class Initialized
INFO - 2021-09-23 12:25:01 --> Loader Class Initialized
INFO - 2021-09-23 12:25:01 --> Helper loaded: url_helper
INFO - 2021-09-23 12:25:01 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:25:01 --> Controller Class Initialized
INFO - 2021-09-23 12:25:01 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:25:01 --> Model "CookieModel" initialized
INFO - 2021-09-23 12:25:01 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 12:25:01 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/index.php
INFO - 2021-09-23 12:25:01 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 12:25:01 --> Final output sent to browser
DEBUG - 2021-09-23 12:25:01 --> Total execution time: 0.0540
INFO - 2021-09-23 12:25:08 --> Config Class Initialized
INFO - 2021-09-23 12:25:08 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:25:08 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:25:08 --> Utf8 Class Initialized
INFO - 2021-09-23 12:25:08 --> URI Class Initialized
INFO - 2021-09-23 12:25:08 --> Router Class Initialized
INFO - 2021-09-23 12:25:08 --> Output Class Initialized
INFO - 2021-09-23 12:25:08 --> Security Class Initialized
DEBUG - 2021-09-23 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:25:08 --> Input Class Initialized
INFO - 2021-09-23 12:25:08 --> Language Class Initialized
INFO - 2021-09-23 12:25:08 --> Loader Class Initialized
INFO - 2021-09-23 12:25:08 --> Helper loaded: url_helper
INFO - 2021-09-23 12:25:08 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:25:08 --> Controller Class Initialized
INFO - 2021-09-23 12:25:08 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:25:08 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:25:08 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:25:08 --> Database Driver Class Initialized
INFO - 2021-09-23 12:25:08 --> Helper loaded: string_helper
INFO - 2021-09-23 12:25:08 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:25:08 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:25:08 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-23 12:25:08 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-23 12:25:08 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-23 12:25:08 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/dashboard.php
INFO - 2021-09-23 12:25:08 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-23 12:25:08 --> Final output sent to browser
DEBUG - 2021-09-23 12:25:08 --> Total execution time: 0.0847
INFO - 2021-09-23 12:25:11 --> Config Class Initialized
INFO - 2021-09-23 12:25:11 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:25:11 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:25:11 --> Utf8 Class Initialized
INFO - 2021-09-23 12:25:11 --> URI Class Initialized
INFO - 2021-09-23 12:25:11 --> Router Class Initialized
INFO - 2021-09-23 12:25:11 --> Output Class Initialized
INFO - 2021-09-23 12:25:11 --> Security Class Initialized
DEBUG - 2021-09-23 12:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:25:11 --> Input Class Initialized
INFO - 2021-09-23 12:25:11 --> Language Class Initialized
INFO - 2021-09-23 12:25:11 --> Loader Class Initialized
INFO - 2021-09-23 12:25:11 --> Helper loaded: url_helper
INFO - 2021-09-23 12:25:11 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:25:11 --> Controller Class Initialized
DEBUG - 2021-09-23 12:25:11 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:25:11 --> Config Class Initialized
INFO - 2021-09-23 12:25:11 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:25:11 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:25:11 --> Utf8 Class Initialized
INFO - 2021-09-23 12:25:11 --> URI Class Initialized
DEBUG - 2021-09-23 12:25:11 --> No URI present. Default controller set.
INFO - 2021-09-23 12:25:11 --> Router Class Initialized
INFO - 2021-09-23 12:25:11 --> Output Class Initialized
INFO - 2021-09-23 12:25:11 --> Security Class Initialized
DEBUG - 2021-09-23 12:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:25:11 --> Input Class Initialized
INFO - 2021-09-23 12:25:11 --> Language Class Initialized
INFO - 2021-09-23 12:25:11 --> Loader Class Initialized
INFO - 2021-09-23 12:25:11 --> Helper loaded: url_helper
INFO - 2021-09-23 12:25:11 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:25:11 --> Controller Class Initialized
INFO - 2021-09-23 12:25:11 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:25:11 --> Model "CookieModel" initialized
INFO - 2021-09-23 12:25:11 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 12:25:11 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/index.php
INFO - 2021-09-23 12:25:11 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 12:25:11 --> Final output sent to browser
DEBUG - 2021-09-23 12:25:11 --> Total execution time: 0.0522
INFO - 2021-09-23 12:25:18 --> Config Class Initialized
INFO - 2021-09-23 12:25:18 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:25:18 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:25:18 --> Utf8 Class Initialized
INFO - 2021-09-23 12:25:18 --> URI Class Initialized
INFO - 2021-09-23 12:25:18 --> Router Class Initialized
INFO - 2021-09-23 12:25:18 --> Output Class Initialized
INFO - 2021-09-23 12:25:18 --> Security Class Initialized
DEBUG - 2021-09-23 12:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:25:18 --> Input Class Initialized
INFO - 2021-09-23 12:25:18 --> Language Class Initialized
INFO - 2021-09-23 12:25:18 --> Loader Class Initialized
INFO - 2021-09-23 12:25:18 --> Helper loaded: url_helper
INFO - 2021-09-23 12:25:18 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:25:18 --> Controller Class Initialized
INFO - 2021-09-23 12:25:18 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:25:18 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:25:18 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:25:18 --> Database Driver Class Initialized
INFO - 2021-09-23 12:25:18 --> Helper loaded: string_helper
INFO - 2021-09-23 12:25:18 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:25:18 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:25:18 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-23 12:25:18 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-23 12:25:18 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-23 12:25:18 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/dashboard.php
INFO - 2021-09-23 12:25:18 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-23 12:25:18 --> Final output sent to browser
DEBUG - 2021-09-23 12:25:18 --> Total execution time: 0.0819
INFO - 2021-09-23 12:25:22 --> Config Class Initialized
INFO - 2021-09-23 12:25:22 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:25:22 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:25:22 --> Utf8 Class Initialized
INFO - 2021-09-23 12:25:22 --> URI Class Initialized
INFO - 2021-09-23 12:25:22 --> Router Class Initialized
INFO - 2021-09-23 12:25:22 --> Output Class Initialized
INFO - 2021-09-23 12:25:22 --> Security Class Initialized
DEBUG - 2021-09-23 12:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:25:22 --> Input Class Initialized
INFO - 2021-09-23 12:25:22 --> Language Class Initialized
INFO - 2021-09-23 12:25:22 --> Loader Class Initialized
INFO - 2021-09-23 12:25:22 --> Helper loaded: url_helper
INFO - 2021-09-23 12:25:22 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:25:22 --> Controller Class Initialized
DEBUG - 2021-09-23 12:25:22 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:25:22 --> Config Class Initialized
INFO - 2021-09-23 12:25:22 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:25:22 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:25:22 --> Utf8 Class Initialized
INFO - 2021-09-23 12:25:22 --> URI Class Initialized
DEBUG - 2021-09-23 12:25:22 --> No URI present. Default controller set.
INFO - 2021-09-23 12:25:22 --> Router Class Initialized
INFO - 2021-09-23 12:25:22 --> Output Class Initialized
INFO - 2021-09-23 12:25:22 --> Security Class Initialized
DEBUG - 2021-09-23 12:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:25:22 --> Input Class Initialized
INFO - 2021-09-23 12:25:22 --> Language Class Initialized
INFO - 2021-09-23 12:25:22 --> Loader Class Initialized
INFO - 2021-09-23 12:25:22 --> Helper loaded: url_helper
INFO - 2021-09-23 12:25:22 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:25:22 --> Controller Class Initialized
INFO - 2021-09-23 12:25:22 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:25:22 --> Model "CookieModel" initialized
INFO - 2021-09-23 12:25:22 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 12:25:22 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/index.php
INFO - 2021-09-23 12:25:22 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 12:25:22 --> Final output sent to browser
DEBUG - 2021-09-23 12:25:22 --> Total execution time: 0.0688
INFO - 2021-09-23 12:25:57 --> Config Class Initialized
INFO - 2021-09-23 12:25:57 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:25:57 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:25:57 --> Utf8 Class Initialized
INFO - 2021-09-23 12:25:57 --> URI Class Initialized
INFO - 2021-09-23 12:25:57 --> Router Class Initialized
INFO - 2021-09-23 12:25:57 --> Output Class Initialized
INFO - 2021-09-23 12:25:57 --> Security Class Initialized
DEBUG - 2021-09-23 12:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:25:57 --> Input Class Initialized
INFO - 2021-09-23 12:25:57 --> Language Class Initialized
INFO - 2021-09-23 12:25:57 --> Loader Class Initialized
INFO - 2021-09-23 12:25:57 --> Helper loaded: url_helper
INFO - 2021-09-23 12:25:57 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:25:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:25:57 --> Controller Class Initialized
DEBUG - 2021-09-23 12:25:57 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:25:57 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:25:57 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\login.php
INFO - 2021-09-23 12:25:57 --> Final output sent to browser
DEBUG - 2021-09-23 12:25:57 --> Total execution time: 0.0551
INFO - 2021-09-23 12:26:03 --> Config Class Initialized
INFO - 2021-09-23 12:26:03 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:26:03 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:26:03 --> Utf8 Class Initialized
INFO - 2021-09-23 12:26:03 --> URI Class Initialized
INFO - 2021-09-23 12:26:03 --> Router Class Initialized
INFO - 2021-09-23 12:26:03 --> Output Class Initialized
INFO - 2021-09-23 12:26:03 --> Security Class Initialized
DEBUG - 2021-09-23 12:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:26:03 --> Input Class Initialized
INFO - 2021-09-23 12:26:03 --> Language Class Initialized
INFO - 2021-09-23 12:26:03 --> Loader Class Initialized
INFO - 2021-09-23 12:26:03 --> Helper loaded: url_helper
INFO - 2021-09-23 12:26:03 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:26:03 --> Controller Class Initialized
INFO - 2021-09-23 12:26:03 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:26:03 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:26:03 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:26:03 --> Database Driver Class Initialized
INFO - 2021-09-23 12:26:03 --> Helper loaded: string_helper
INFO - 2021-09-23 12:26:03 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:26:03 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:26:03 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-23 12:26:03 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-23 12:26:03 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-23 12:26:03 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/dashboard.php
INFO - 2021-09-23 12:26:03 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-23 12:26:03 --> Final output sent to browser
DEBUG - 2021-09-23 12:26:03 --> Total execution time: 0.0798
INFO - 2021-09-23 12:27:59 --> Config Class Initialized
INFO - 2021-09-23 12:27:59 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:27:59 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:27:59 --> Utf8 Class Initialized
INFO - 2021-09-23 12:27:59 --> URI Class Initialized
INFO - 2021-09-23 12:27:59 --> Router Class Initialized
INFO - 2021-09-23 12:27:59 --> Output Class Initialized
INFO - 2021-09-23 12:27:59 --> Security Class Initialized
DEBUG - 2021-09-23 12:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:27:59 --> Input Class Initialized
INFO - 2021-09-23 12:28:00 --> Language Class Initialized
INFO - 2021-09-23 12:28:00 --> Loader Class Initialized
INFO - 2021-09-23 12:28:00 --> Helper loaded: url_helper
INFO - 2021-09-23 12:28:00 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:28:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:28:00 --> Controller Class Initialized
INFO - 2021-09-23 12:28:00 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:28:00 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:28:00 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:28:00 --> Database Driver Class Initialized
INFO - 2021-09-23 12:28:00 --> Helper loaded: string_helper
INFO - 2021-09-23 12:28:00 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:28:00 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:28:00 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-23 12:28:00 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-23 12:28:00 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-23 12:28:00 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/dashboard.php
INFO - 2021-09-23 12:28:00 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-23 12:28:00 --> Final output sent to browser
DEBUG - 2021-09-23 12:28:00 --> Total execution time: 0.2191
INFO - 2021-09-23 12:28:07 --> Config Class Initialized
INFO - 2021-09-23 12:28:07 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:28:07 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:28:07 --> Utf8 Class Initialized
INFO - 2021-09-23 12:28:07 --> URI Class Initialized
INFO - 2021-09-23 12:28:07 --> Router Class Initialized
INFO - 2021-09-23 12:28:07 --> Output Class Initialized
INFO - 2021-09-23 12:28:07 --> Security Class Initialized
DEBUG - 2021-09-23 12:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:28:07 --> Input Class Initialized
INFO - 2021-09-23 12:28:07 --> Language Class Initialized
INFO - 2021-09-23 12:28:07 --> Loader Class Initialized
INFO - 2021-09-23 12:28:07 --> Helper loaded: url_helper
INFO - 2021-09-23 12:28:07 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:28:07 --> Controller Class Initialized
INFO - 2021-09-23 12:28:07 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:28:07 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:28:07 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:28:07 --> Database Driver Class Initialized
INFO - 2021-09-23 12:28:07 --> Helper loaded: string_helper
INFO - 2021-09-23 12:28:07 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:28:07 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:28:07 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-23 12:28:07 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-23 12:28:08 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-23 12:28:08 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/dashboard.php
INFO - 2021-09-23 12:28:08 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-23 12:28:08 --> Final output sent to browser
DEBUG - 2021-09-23 12:28:08 --> Total execution time: 0.0840
INFO - 2021-09-23 12:28:16 --> Config Class Initialized
INFO - 2021-09-23 12:28:16 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:28:16 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:28:16 --> Utf8 Class Initialized
INFO - 2021-09-23 12:28:16 --> URI Class Initialized
INFO - 2021-09-23 12:28:16 --> Router Class Initialized
INFO - 2021-09-23 12:28:16 --> Output Class Initialized
INFO - 2021-09-23 12:28:16 --> Security Class Initialized
DEBUG - 2021-09-23 12:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:28:16 --> Input Class Initialized
INFO - 2021-09-23 12:28:16 --> Language Class Initialized
INFO - 2021-09-23 12:28:16 --> Loader Class Initialized
INFO - 2021-09-23 12:28:16 --> Helper loaded: url_helper
INFO - 2021-09-23 12:28:16 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:28:16 --> Controller Class Initialized
DEBUG - 2021-09-23 12:28:16 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:28:16 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:28:16 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\login.php
INFO - 2021-09-23 12:28:16 --> Final output sent to browser
DEBUG - 2021-09-23 12:28:16 --> Total execution time: 0.0565
INFO - 2021-09-23 12:32:42 --> Config Class Initialized
INFO - 2021-09-23 12:32:42 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:32:42 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:32:42 --> Utf8 Class Initialized
INFO - 2021-09-23 12:32:42 --> URI Class Initialized
INFO - 2021-09-23 12:32:42 --> Router Class Initialized
INFO - 2021-09-23 12:32:42 --> Output Class Initialized
INFO - 2021-09-23 12:32:42 --> Security Class Initialized
DEBUG - 2021-09-23 12:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:32:42 --> Input Class Initialized
INFO - 2021-09-23 12:32:42 --> Language Class Initialized
INFO - 2021-09-23 12:32:42 --> Loader Class Initialized
INFO - 2021-09-23 12:32:42 --> Helper loaded: url_helper
INFO - 2021-09-23 12:32:42 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:32:42 --> Controller Class Initialized
DEBUG - 2021-09-23 12:32:42 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:32:42 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:32:42 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\login.php
INFO - 2021-09-23 12:32:42 --> Final output sent to browser
DEBUG - 2021-09-23 12:32:42 --> Total execution time: 0.0529
INFO - 2021-09-23 12:33:04 --> Config Class Initialized
INFO - 2021-09-23 12:33:04 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:33:04 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:33:04 --> Utf8 Class Initialized
INFO - 2021-09-23 12:33:04 --> URI Class Initialized
INFO - 2021-09-23 12:33:04 --> Router Class Initialized
INFO - 2021-09-23 12:33:04 --> Output Class Initialized
INFO - 2021-09-23 12:33:04 --> Security Class Initialized
DEBUG - 2021-09-23 12:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:33:04 --> Input Class Initialized
INFO - 2021-09-23 12:33:04 --> Language Class Initialized
INFO - 2021-09-23 12:33:04 --> Loader Class Initialized
INFO - 2021-09-23 12:33:04 --> Helper loaded: url_helper
INFO - 2021-09-23 12:33:04 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:33:04 --> Controller Class Initialized
INFO - 2021-09-23 12:33:04 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:33:04 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:33:04 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:33:04 --> Database Driver Class Initialized
INFO - 2021-09-23 12:33:04 --> Helper loaded: string_helper
INFO - 2021-09-23 12:33:04 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:33:04 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:33:04 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-23 12:33:04 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-23 12:33:04 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-23 12:33:04 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/dashboard.php
INFO - 2021-09-23 12:33:04 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-23 12:33:04 --> Final output sent to browser
DEBUG - 2021-09-23 12:33:04 --> Total execution time: 0.0916
INFO - 2021-09-23 12:33:06 --> Config Class Initialized
INFO - 2021-09-23 12:33:06 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:33:06 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:33:06 --> Utf8 Class Initialized
INFO - 2021-09-23 12:33:06 --> URI Class Initialized
DEBUG - 2021-09-23 12:33:06 --> No URI present. Default controller set.
INFO - 2021-09-23 12:33:06 --> Router Class Initialized
INFO - 2021-09-23 12:33:06 --> Output Class Initialized
INFO - 2021-09-23 12:33:06 --> Security Class Initialized
DEBUG - 2021-09-23 12:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:33:06 --> Input Class Initialized
INFO - 2021-09-23 12:33:06 --> Language Class Initialized
INFO - 2021-09-23 12:33:06 --> Loader Class Initialized
INFO - 2021-09-23 12:33:06 --> Helper loaded: url_helper
INFO - 2021-09-23 12:33:06 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:33:06 --> Controller Class Initialized
INFO - 2021-09-23 12:33:06 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:33:06 --> Model "CookieModel" initialized
INFO - 2021-09-23 12:33:06 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 12:33:06 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/index.php
INFO - 2021-09-23 12:33:06 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 12:33:06 --> Final output sent to browser
DEBUG - 2021-09-23 12:33:06 --> Total execution time: 0.0616
INFO - 2021-09-23 12:34:22 --> Config Class Initialized
INFO - 2021-09-23 12:34:22 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:34:22 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:34:22 --> Utf8 Class Initialized
INFO - 2021-09-23 12:34:22 --> URI Class Initialized
INFO - 2021-09-23 12:34:22 --> Router Class Initialized
INFO - 2021-09-23 12:34:22 --> Output Class Initialized
INFO - 2021-09-23 12:34:22 --> Security Class Initialized
DEBUG - 2021-09-23 12:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:34:22 --> Input Class Initialized
INFO - 2021-09-23 12:34:22 --> Language Class Initialized
INFO - 2021-09-23 12:34:22 --> Loader Class Initialized
INFO - 2021-09-23 12:34:22 --> Helper loaded: url_helper
INFO - 2021-09-23 12:34:22 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:34:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:34:22 --> Controller Class Initialized
INFO - 2021-09-23 12:34:22 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:34:22 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:34:22 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:34:22 --> Database Driver Class Initialized
INFO - 2021-09-23 12:34:22 --> Helper loaded: string_helper
INFO - 2021-09-23 12:34:22 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:34:22 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:34:22 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-23 12:34:22 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-23 12:34:22 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-23 12:34:22 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/dashboard.php
INFO - 2021-09-23 12:34:22 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-23 12:34:22 --> Final output sent to browser
DEBUG - 2021-09-23 12:34:22 --> Total execution time: 0.0798
INFO - 2021-09-23 12:34:28 --> Config Class Initialized
INFO - 2021-09-23 12:34:28 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:34:28 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:34:28 --> Utf8 Class Initialized
INFO - 2021-09-23 12:34:28 --> URI Class Initialized
INFO - 2021-09-23 12:34:28 --> Router Class Initialized
INFO - 2021-09-23 12:34:28 --> Output Class Initialized
INFO - 2021-09-23 12:34:28 --> Security Class Initialized
DEBUG - 2021-09-23 12:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:34:28 --> Input Class Initialized
INFO - 2021-09-23 12:34:28 --> Language Class Initialized
INFO - 2021-09-23 12:34:28 --> Loader Class Initialized
INFO - 2021-09-23 12:34:28 --> Helper loaded: url_helper
INFO - 2021-09-23 12:34:28 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:34:28 --> Controller Class Initialized
DEBUG - 2021-09-23 12:34:28 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:34:28 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:34:28 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\login.php
INFO - 2021-09-23 12:34:28 --> Final output sent to browser
DEBUG - 2021-09-23 12:34:28 --> Total execution time: 0.0552
INFO - 2021-09-23 12:38:50 --> Config Class Initialized
INFO - 2021-09-23 12:38:50 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:38:50 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:38:50 --> Utf8 Class Initialized
INFO - 2021-09-23 12:38:50 --> URI Class Initialized
INFO - 2021-09-23 12:38:50 --> Router Class Initialized
INFO - 2021-09-23 12:38:50 --> Output Class Initialized
INFO - 2021-09-23 12:38:50 --> Security Class Initialized
DEBUG - 2021-09-23 12:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:38:50 --> Input Class Initialized
INFO - 2021-09-23 12:38:50 --> Language Class Initialized
INFO - 2021-09-23 12:38:50 --> Loader Class Initialized
INFO - 2021-09-23 12:38:50 --> Helper loaded: url_helper
INFO - 2021-09-23 12:38:50 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:38:50 --> Controller Class Initialized
DEBUG - 2021-09-23 12:38:50 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:38:50 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:38:50 --> Config Class Initialized
INFO - 2021-09-23 12:38:50 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:38:50 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:38:50 --> Utf8 Class Initialized
INFO - 2021-09-23 12:38:50 --> URI Class Initialized
INFO - 2021-09-23 12:38:50 --> Router Class Initialized
INFO - 2021-09-23 12:38:50 --> Output Class Initialized
INFO - 2021-09-23 12:38:50 --> Security Class Initialized
DEBUG - 2021-09-23 12:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:38:50 --> Input Class Initialized
INFO - 2021-09-23 12:38:50 --> Language Class Initialized
INFO - 2021-09-23 12:38:50 --> Loader Class Initialized
INFO - 2021-09-23 12:38:50 --> Helper loaded: url_helper
INFO - 2021-09-23 12:38:50 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:38:50 --> Controller Class Initialized
INFO - 2021-09-23 12:38:50 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:38:50 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:38:50 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:38:50 --> Database Driver Class Initialized
INFO - 2021-09-23 12:38:50 --> Helper loaded: string_helper
INFO - 2021-09-23 12:38:50 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:38:50 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:38:50 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-23 12:38:50 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-23 12:38:50 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-23 12:38:50 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/dashboard.php
INFO - 2021-09-23 12:38:50 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-23 12:38:50 --> Final output sent to browser
DEBUG - 2021-09-23 12:38:50 --> Total execution time: 0.0972
INFO - 2021-09-23 12:40:28 --> Config Class Initialized
INFO - 2021-09-23 12:40:28 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:40:28 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:40:28 --> Utf8 Class Initialized
INFO - 2021-09-23 12:40:28 --> URI Class Initialized
INFO - 2021-09-23 12:40:28 --> Router Class Initialized
INFO - 2021-09-23 12:40:28 --> Output Class Initialized
INFO - 2021-09-23 12:40:28 --> Security Class Initialized
DEBUG - 2021-09-23 12:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:40:28 --> Input Class Initialized
INFO - 2021-09-23 12:40:28 --> Language Class Initialized
INFO - 2021-09-23 12:40:28 --> Loader Class Initialized
INFO - 2021-09-23 12:40:28 --> Helper loaded: url_helper
INFO - 2021-09-23 12:40:28 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:40:28 --> Controller Class Initialized
INFO - 2021-09-23 12:40:28 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:40:28 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:40:28 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:40:28 --> Database Driver Class Initialized
INFO - 2021-09-23 12:40:28 --> Helper loaded: string_helper
INFO - 2021-09-23 12:40:28 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:40:28 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:40:28 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-23 12:40:28 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-23 12:40:28 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-23 12:40:28 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/testimonials.php
INFO - 2021-09-23 12:40:28 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-23 12:40:28 --> Final output sent to browser
DEBUG - 2021-09-23 12:40:28 --> Total execution time: 0.0756
INFO - 2021-09-23 12:40:31 --> Config Class Initialized
INFO - 2021-09-23 12:40:31 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:40:31 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:40:31 --> Utf8 Class Initialized
INFO - 2021-09-23 12:40:31 --> URI Class Initialized
INFO - 2021-09-23 12:40:31 --> Router Class Initialized
INFO - 2021-09-23 12:40:31 --> Output Class Initialized
INFO - 2021-09-23 12:40:31 --> Security Class Initialized
DEBUG - 2021-09-23 12:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:40:31 --> Input Class Initialized
INFO - 2021-09-23 12:40:31 --> Language Class Initialized
INFO - 2021-09-23 12:40:31 --> Loader Class Initialized
INFO - 2021-09-23 12:40:31 --> Helper loaded: url_helper
INFO - 2021-09-23 12:40:31 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:40:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:40:31 --> Controller Class Initialized
INFO - 2021-09-23 12:40:31 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:40:31 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:40:31 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:40:31 --> Database Driver Class Initialized
INFO - 2021-09-23 12:40:31 --> Helper loaded: string_helper
INFO - 2021-09-23 12:40:31 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:40:31 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:40:31 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-23 12:40:31 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-23 12:40:31 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-23 12:40:31 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/testimonial.php
INFO - 2021-09-23 12:40:31 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-23 12:40:31 --> Final output sent to browser
DEBUG - 2021-09-23 12:40:31 --> Total execution time: 0.0789
INFO - 2021-09-23 12:48:09 --> Config Class Initialized
INFO - 2021-09-23 12:48:09 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:48:09 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:48:09 --> Utf8 Class Initialized
INFO - 2021-09-23 12:48:09 --> URI Class Initialized
INFO - 2021-09-23 12:48:09 --> Router Class Initialized
INFO - 2021-09-23 12:48:09 --> Output Class Initialized
INFO - 2021-09-23 12:48:09 --> Security Class Initialized
DEBUG - 2021-09-23 12:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:48:09 --> Input Class Initialized
INFO - 2021-09-23 12:48:09 --> Language Class Initialized
INFO - 2021-09-23 12:48:09 --> Loader Class Initialized
INFO - 2021-09-23 12:48:09 --> Helper loaded: url_helper
INFO - 2021-09-23 12:48:09 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:48:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:48:09 --> Controller Class Initialized
INFO - 2021-09-23 12:48:09 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:48:09 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:48:09 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:48:09 --> Database Driver Class Initialized
INFO - 2021-09-23 12:48:09 --> Helper loaded: string_helper
INFO - 2021-09-23 12:48:09 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:48:09 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:48:09 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-23 12:48:09 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-23 12:48:09 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-23 12:48:09 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/blogs.php
INFO - 2021-09-23 12:48:09 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-23 12:48:09 --> Final output sent to browser
DEBUG - 2021-09-23 12:48:09 --> Total execution time: 0.0796
INFO - 2021-09-23 12:48:10 --> Config Class Initialized
INFO - 2021-09-23 12:48:10 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:48:10 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:48:10 --> Utf8 Class Initialized
INFO - 2021-09-23 12:48:10 --> URI Class Initialized
INFO - 2021-09-23 12:48:10 --> Router Class Initialized
INFO - 2021-09-23 12:48:10 --> Output Class Initialized
INFO - 2021-09-23 12:48:10 --> Security Class Initialized
DEBUG - 2021-09-23 12:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:48:10 --> Input Class Initialized
INFO - 2021-09-23 12:48:10 --> Language Class Initialized
INFO - 2021-09-23 12:48:10 --> Loader Class Initialized
INFO - 2021-09-23 12:48:10 --> Helper loaded: url_helper
INFO - 2021-09-23 12:48:10 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:48:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:48:10 --> Controller Class Initialized
INFO - 2021-09-23 12:48:10 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:48:10 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:48:10 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:48:10 --> Database Driver Class Initialized
INFO - 2021-09-23 12:48:10 --> Helper loaded: string_helper
INFO - 2021-09-23 12:48:10 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:48:10 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:48:10 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-23 12:48:10 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-23 12:48:10 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-23 12:48:10 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/testimonials.php
INFO - 2021-09-23 12:48:10 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-23 12:48:10 --> Final output sent to browser
DEBUG - 2021-09-23 12:48:10 --> Total execution time: 0.0747
INFO - 2021-09-23 12:48:13 --> Config Class Initialized
INFO - 2021-09-23 12:48:13 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:48:13 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:48:13 --> Utf8 Class Initialized
INFO - 2021-09-23 12:48:13 --> URI Class Initialized
INFO - 2021-09-23 12:48:13 --> Router Class Initialized
INFO - 2021-09-23 12:48:13 --> Output Class Initialized
INFO - 2021-09-23 12:48:13 --> Security Class Initialized
DEBUG - 2021-09-23 12:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:48:13 --> Input Class Initialized
INFO - 2021-09-23 12:48:13 --> Language Class Initialized
INFO - 2021-09-23 12:48:13 --> Loader Class Initialized
INFO - 2021-09-23 12:48:13 --> Helper loaded: url_helper
INFO - 2021-09-23 12:48:13 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:48:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:48:13 --> Controller Class Initialized
INFO - 2021-09-23 12:48:13 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:48:13 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:48:13 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:48:13 --> Database Driver Class Initialized
INFO - 2021-09-23 12:48:13 --> Helper loaded: string_helper
INFO - 2021-09-23 12:48:13 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:48:13 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:48:13 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-23 12:48:13 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-23 12:48:13 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-23 12:48:13 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/testimonial.php
INFO - 2021-09-23 12:48:13 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-23 12:48:13 --> Final output sent to browser
DEBUG - 2021-09-23 12:48:13 --> Total execution time: 0.0795
INFO - 2021-09-23 12:48:37 --> Config Class Initialized
INFO - 2021-09-23 12:48:37 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:48:37 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:48:37 --> Utf8 Class Initialized
INFO - 2021-09-23 12:48:37 --> URI Class Initialized
INFO - 2021-09-23 12:48:37 --> Router Class Initialized
INFO - 2021-09-23 12:48:37 --> Output Class Initialized
INFO - 2021-09-23 12:48:37 --> Security Class Initialized
DEBUG - 2021-09-23 12:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:48:37 --> Input Class Initialized
INFO - 2021-09-23 12:48:37 --> Language Class Initialized
INFO - 2021-09-23 12:48:37 --> Loader Class Initialized
INFO - 2021-09-23 12:48:37 --> Helper loaded: url_helper
INFO - 2021-09-23 12:48:37 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:48:37 --> Controller Class Initialized
INFO - 2021-09-23 12:48:37 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:48:37 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:48:37 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:48:37 --> Database Driver Class Initialized
INFO - 2021-09-23 12:48:37 --> Helper loaded: string_helper
INFO - 2021-09-23 12:48:37 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:48:37 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:48:38 --> Config Class Initialized
INFO - 2021-09-23 12:48:38 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:48:38 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:48:38 --> Utf8 Class Initialized
INFO - 2021-09-23 12:48:38 --> URI Class Initialized
INFO - 2021-09-23 12:48:38 --> Router Class Initialized
INFO - 2021-09-23 12:48:38 --> Output Class Initialized
INFO - 2021-09-23 12:48:38 --> Security Class Initialized
DEBUG - 2021-09-23 12:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:48:38 --> Input Class Initialized
INFO - 2021-09-23 12:48:38 --> Language Class Initialized
INFO - 2021-09-23 12:48:38 --> Loader Class Initialized
INFO - 2021-09-23 12:48:38 --> Helper loaded: url_helper
INFO - 2021-09-23 12:48:38 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:48:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:48:38 --> Controller Class Initialized
INFO - 2021-09-23 12:48:38 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:48:38 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:48:38 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:48:38 --> Database Driver Class Initialized
INFO - 2021-09-23 12:48:38 --> Helper loaded: string_helper
INFO - 2021-09-23 12:48:38 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:48:38 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:48:38 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-23 12:48:38 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-23 12:48:38 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-23 12:48:38 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/testimonials.php
INFO - 2021-09-23 12:48:38 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-23 12:48:38 --> Final output sent to browser
DEBUG - 2021-09-23 12:48:38 --> Total execution time: 0.1667
INFO - 2021-09-23 12:48:51 --> Config Class Initialized
INFO - 2021-09-23 12:48:51 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:48:51 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:48:51 --> Utf8 Class Initialized
INFO - 2021-09-23 12:48:51 --> URI Class Initialized
INFO - 2021-09-23 12:48:51 --> Router Class Initialized
INFO - 2021-09-23 12:48:51 --> Output Class Initialized
INFO - 2021-09-23 12:48:51 --> Security Class Initialized
DEBUG - 2021-09-23 12:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:48:51 --> Input Class Initialized
INFO - 2021-09-23 12:48:51 --> Language Class Initialized
INFO - 2021-09-23 12:48:51 --> Loader Class Initialized
INFO - 2021-09-23 12:48:51 --> Helper loaded: url_helper
INFO - 2021-09-23 12:48:51 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:48:51 --> Controller Class Initialized
INFO - 2021-09-23 12:48:51 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:48:51 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:48:51 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:48:51 --> Database Driver Class Initialized
INFO - 2021-09-23 12:48:51 --> Helper loaded: string_helper
INFO - 2021-09-23 12:48:51 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:48:51 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:48:51 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-23 12:48:51 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-23 12:48:51 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-23 12:48:51 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/testimonial.php
INFO - 2021-09-23 12:48:51 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-23 12:48:51 --> Final output sent to browser
DEBUG - 2021-09-23 12:48:51 --> Total execution time: 0.0865
INFO - 2021-09-23 12:48:54 --> Config Class Initialized
INFO - 2021-09-23 12:48:54 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:48:54 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:48:54 --> Utf8 Class Initialized
INFO - 2021-09-23 12:48:54 --> URI Class Initialized
INFO - 2021-09-23 12:48:54 --> Router Class Initialized
INFO - 2021-09-23 12:48:54 --> Output Class Initialized
INFO - 2021-09-23 12:48:54 --> Security Class Initialized
DEBUG - 2021-09-23 12:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:48:54 --> Input Class Initialized
INFO - 2021-09-23 12:48:54 --> Language Class Initialized
INFO - 2021-09-23 12:48:54 --> Loader Class Initialized
INFO - 2021-09-23 12:48:54 --> Helper loaded: url_helper
INFO - 2021-09-23 12:48:54 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:48:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:48:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:48:54 --> Controller Class Initialized
INFO - 2021-09-23 12:48:54 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:48:54 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:48:54 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:48:54 --> Database Driver Class Initialized
INFO - 2021-09-23 12:48:54 --> Helper loaded: string_helper
INFO - 2021-09-23 12:48:54 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:48:54 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:48:54 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-23 12:48:54 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-23 12:48:54 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-23 12:48:54 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/testimonials.php
INFO - 2021-09-23 12:48:54 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-23 12:48:54 --> Final output sent to browser
DEBUG - 2021-09-23 12:48:54 --> Total execution time: 0.0710
INFO - 2021-09-23 12:48:57 --> Config Class Initialized
INFO - 2021-09-23 12:48:57 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:48:57 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:48:57 --> Utf8 Class Initialized
INFO - 2021-09-23 12:48:57 --> URI Class Initialized
INFO - 2021-09-23 12:48:57 --> Router Class Initialized
INFO - 2021-09-23 12:48:57 --> Output Class Initialized
INFO - 2021-09-23 12:48:57 --> Security Class Initialized
DEBUG - 2021-09-23 12:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:48:57 --> Input Class Initialized
INFO - 2021-09-23 12:48:57 --> Language Class Initialized
INFO - 2021-09-23 12:48:57 --> Loader Class Initialized
INFO - 2021-09-23 12:48:57 --> Helper loaded: url_helper
INFO - 2021-09-23 12:48:57 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:48:57 --> Controller Class Initialized
INFO - 2021-09-23 12:48:57 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:48:57 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:48:57 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:48:57 --> Database Driver Class Initialized
INFO - 2021-09-23 12:48:57 --> Helper loaded: string_helper
INFO - 2021-09-23 12:48:57 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:48:57 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:48:57 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-23 12:48:57 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-23 12:48:57 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-23 12:48:57 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/testimonial.php
INFO - 2021-09-23 12:48:57 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-23 12:48:57 --> Final output sent to browser
DEBUG - 2021-09-23 12:48:57 --> Total execution time: 0.0714
INFO - 2021-09-23 12:49:04 --> Config Class Initialized
INFO - 2021-09-23 12:49:04 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:49:04 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:49:04 --> Utf8 Class Initialized
INFO - 2021-09-23 12:49:04 --> URI Class Initialized
INFO - 2021-09-23 12:49:04 --> Router Class Initialized
INFO - 2021-09-23 12:49:04 --> Output Class Initialized
INFO - 2021-09-23 12:49:04 --> Security Class Initialized
DEBUG - 2021-09-23 12:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:49:04 --> Input Class Initialized
INFO - 2021-09-23 12:49:04 --> Language Class Initialized
INFO - 2021-09-23 12:49:04 --> Loader Class Initialized
INFO - 2021-09-23 12:49:04 --> Helper loaded: url_helper
INFO - 2021-09-23 12:49:04 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:49:04 --> Controller Class Initialized
INFO - 2021-09-23 12:49:04 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:49:04 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:49:04 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:49:04 --> Database Driver Class Initialized
INFO - 2021-09-23 12:49:04 --> Helper loaded: string_helper
INFO - 2021-09-23 12:49:04 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:49:04 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:49:04 --> Config Class Initialized
INFO - 2021-09-23 12:49:04 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:49:04 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:49:04 --> Utf8 Class Initialized
INFO - 2021-09-23 12:49:04 --> URI Class Initialized
INFO - 2021-09-23 12:49:04 --> Router Class Initialized
INFO - 2021-09-23 12:49:04 --> Output Class Initialized
INFO - 2021-09-23 12:49:04 --> Security Class Initialized
DEBUG - 2021-09-23 12:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:49:04 --> Input Class Initialized
INFO - 2021-09-23 12:49:04 --> Language Class Initialized
INFO - 2021-09-23 12:49:04 --> Loader Class Initialized
INFO - 2021-09-23 12:49:04 --> Helper loaded: url_helper
INFO - 2021-09-23 12:49:04 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:49:04 --> Controller Class Initialized
INFO - 2021-09-23 12:49:04 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:49:04 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:49:04 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:49:04 --> Database Driver Class Initialized
INFO - 2021-09-23 12:49:04 --> Helper loaded: string_helper
INFO - 2021-09-23 12:49:04 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:49:04 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:49:04 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-23 12:49:04 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-23 12:49:04 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-23 12:49:04 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/testimonials.php
INFO - 2021-09-23 12:49:04 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-23 12:49:04 --> Final output sent to browser
DEBUG - 2021-09-23 12:49:04 --> Total execution time: 0.1543
INFO - 2021-09-23 12:49:12 --> Config Class Initialized
INFO - 2021-09-23 12:49:12 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:49:12 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:49:12 --> Utf8 Class Initialized
INFO - 2021-09-23 12:49:12 --> URI Class Initialized
INFO - 2021-09-23 12:49:12 --> Router Class Initialized
INFO - 2021-09-23 12:49:12 --> Output Class Initialized
INFO - 2021-09-23 12:49:12 --> Security Class Initialized
DEBUG - 2021-09-23 12:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:49:12 --> Input Class Initialized
INFO - 2021-09-23 12:49:12 --> Language Class Initialized
INFO - 2021-09-23 12:49:12 --> Loader Class Initialized
INFO - 2021-09-23 12:49:12 --> Helper loaded: url_helper
INFO - 2021-09-23 12:49:12 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:49:12 --> Controller Class Initialized
INFO - 2021-09-23 12:49:12 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:49:12 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:49:12 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:49:12 --> Database Driver Class Initialized
INFO - 2021-09-23 12:49:12 --> Helper loaded: string_helper
INFO - 2021-09-23 12:49:12 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:49:12 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:49:12 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-23 12:49:12 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-23 12:49:12 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-23 12:49:12 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/testimonial.php
INFO - 2021-09-23 12:49:12 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-23 12:49:12 --> Final output sent to browser
DEBUG - 2021-09-23 12:49:12 --> Total execution time: 0.0808
INFO - 2021-09-23 12:49:17 --> Config Class Initialized
INFO - 2021-09-23 12:49:17 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:49:17 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:49:17 --> Utf8 Class Initialized
INFO - 2021-09-23 12:49:17 --> URI Class Initialized
INFO - 2021-09-23 12:49:17 --> Router Class Initialized
INFO - 2021-09-23 12:49:17 --> Output Class Initialized
INFO - 2021-09-23 12:49:17 --> Security Class Initialized
DEBUG - 2021-09-23 12:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:49:17 --> Input Class Initialized
INFO - 2021-09-23 12:49:17 --> Language Class Initialized
INFO - 2021-09-23 12:49:17 --> Loader Class Initialized
INFO - 2021-09-23 12:49:17 --> Helper loaded: url_helper
INFO - 2021-09-23 12:49:17 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:49:17 --> Controller Class Initialized
INFO - 2021-09-23 12:49:17 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:49:17 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:49:17 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:49:17 --> Database Driver Class Initialized
INFO - 2021-09-23 12:49:17 --> Helper loaded: string_helper
INFO - 2021-09-23 12:49:17 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:49:17 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:49:17 --> Config Class Initialized
INFO - 2021-09-23 12:49:17 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:49:17 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:49:17 --> Utf8 Class Initialized
INFO - 2021-09-23 12:49:17 --> URI Class Initialized
INFO - 2021-09-23 12:49:17 --> Router Class Initialized
INFO - 2021-09-23 12:49:17 --> Output Class Initialized
INFO - 2021-09-23 12:49:17 --> Security Class Initialized
DEBUG - 2021-09-23 12:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:49:17 --> Input Class Initialized
INFO - 2021-09-23 12:49:17 --> Language Class Initialized
INFO - 2021-09-23 12:49:17 --> Loader Class Initialized
INFO - 2021-09-23 12:49:17 --> Helper loaded: url_helper
INFO - 2021-09-23 12:49:17 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:49:17 --> Controller Class Initialized
INFO - 2021-09-23 12:49:17 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:49:17 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:49:17 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:49:17 --> Database Driver Class Initialized
INFO - 2021-09-23 12:49:17 --> Helper loaded: string_helper
INFO - 2021-09-23 12:49:17 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:49:17 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:49:17 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-23 12:49:17 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-23 12:49:17 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-23 12:49:17 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/testimonials.php
INFO - 2021-09-23 12:49:17 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-23 12:49:17 --> Final output sent to browser
DEBUG - 2021-09-23 12:49:17 --> Total execution time: 0.1648
INFO - 2021-09-23 12:49:20 --> Config Class Initialized
INFO - 2021-09-23 12:49:20 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:49:20 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:49:20 --> Utf8 Class Initialized
INFO - 2021-09-23 12:49:20 --> URI Class Initialized
INFO - 2021-09-23 12:49:20 --> Router Class Initialized
INFO - 2021-09-23 12:49:20 --> Output Class Initialized
INFO - 2021-09-23 12:49:20 --> Security Class Initialized
DEBUG - 2021-09-23 12:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:49:20 --> Input Class Initialized
INFO - 2021-09-23 12:49:20 --> Language Class Initialized
INFO - 2021-09-23 12:49:20 --> Loader Class Initialized
INFO - 2021-09-23 12:49:20 --> Helper loaded: url_helper
INFO - 2021-09-23 12:49:20 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:49:20 --> Controller Class Initialized
INFO - 2021-09-23 12:49:20 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:49:20 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:49:20 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:49:20 --> Database Driver Class Initialized
INFO - 2021-09-23 12:49:20 --> Helper loaded: string_helper
INFO - 2021-09-23 12:49:20 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:49:20 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:49:20 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-23 12:49:20 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-23 12:49:20 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-23 12:49:20 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/testimonial.php
INFO - 2021-09-23 12:49:20 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-23 12:49:20 --> Final output sent to browser
DEBUG - 2021-09-23 12:49:20 --> Total execution time: 0.0700
INFO - 2021-09-23 12:51:58 --> Config Class Initialized
INFO - 2021-09-23 12:51:58 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:51:58 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:51:58 --> Utf8 Class Initialized
INFO - 2021-09-23 12:51:58 --> URI Class Initialized
INFO - 2021-09-23 12:51:58 --> Router Class Initialized
INFO - 2021-09-23 12:51:58 --> Output Class Initialized
INFO - 2021-09-23 12:51:58 --> Security Class Initialized
DEBUG - 2021-09-23 12:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:51:58 --> Input Class Initialized
INFO - 2021-09-23 12:51:58 --> Language Class Initialized
INFO - 2021-09-23 12:51:58 --> Loader Class Initialized
INFO - 2021-09-23 12:51:58 --> Helper loaded: url_helper
INFO - 2021-09-23 12:51:58 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:51:58 --> Controller Class Initialized
INFO - 2021-09-23 12:51:58 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:51:58 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:51:58 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:51:58 --> Database Driver Class Initialized
INFO - 2021-09-23 12:51:58 --> Helper loaded: string_helper
INFO - 2021-09-23 12:51:58 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:51:58 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:51:58 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-23 12:51:58 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-23 12:51:58 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-23 12:51:58 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/testimonial.php
INFO - 2021-09-23 12:51:58 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-23 12:51:58 --> Final output sent to browser
DEBUG - 2021-09-23 12:51:58 --> Total execution time: 0.0798
INFO - 2021-09-23 12:55:27 --> Config Class Initialized
INFO - 2021-09-23 12:55:27 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:55:27 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:55:27 --> Utf8 Class Initialized
INFO - 2021-09-23 12:55:27 --> URI Class Initialized
INFO - 2021-09-23 12:55:27 --> Router Class Initialized
INFO - 2021-09-23 12:55:27 --> Output Class Initialized
INFO - 2021-09-23 12:55:27 --> Security Class Initialized
DEBUG - 2021-09-23 12:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:55:27 --> Input Class Initialized
INFO - 2021-09-23 12:55:27 --> Language Class Initialized
INFO - 2021-09-23 12:55:27 --> Loader Class Initialized
INFO - 2021-09-23 12:55:27 --> Helper loaded: url_helper
INFO - 2021-09-23 12:55:27 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:55:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:55:27 --> Controller Class Initialized
INFO - 2021-09-23 12:55:27 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:55:27 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:55:27 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:55:27 --> Database Driver Class Initialized
INFO - 2021-09-23 12:55:27 --> Helper loaded: string_helper
INFO - 2021-09-23 12:55:27 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:55:27 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:55:28 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-23 12:55:28 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-23 12:55:28 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-23 12:55:28 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/testimonial.php
INFO - 2021-09-23 12:55:28 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-23 12:55:28 --> Final output sent to browser
DEBUG - 2021-09-23 12:55:28 --> Total execution time: 0.0774
INFO - 2021-09-23 12:55:31 --> Config Class Initialized
INFO - 2021-09-23 12:55:31 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:55:31 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:55:31 --> Utf8 Class Initialized
INFO - 2021-09-23 12:55:31 --> URI Class Initialized
INFO - 2021-09-23 12:55:31 --> Router Class Initialized
INFO - 2021-09-23 12:55:31 --> Output Class Initialized
INFO - 2021-09-23 12:55:31 --> Security Class Initialized
DEBUG - 2021-09-23 12:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:55:31 --> Input Class Initialized
INFO - 2021-09-23 12:55:31 --> Language Class Initialized
INFO - 2021-09-23 12:55:31 --> Loader Class Initialized
INFO - 2021-09-23 12:55:31 --> Helper loaded: url_helper
INFO - 2021-09-23 12:55:31 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:55:31 --> Controller Class Initialized
INFO - 2021-09-23 12:55:31 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:55:31 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:55:31 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:55:31 --> Database Driver Class Initialized
INFO - 2021-09-23 12:55:31 --> Helper loaded: string_helper
INFO - 2021-09-23 12:55:31 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:55:31 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:55:31 --> Config Class Initialized
INFO - 2021-09-23 12:55:31 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:55:31 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:55:31 --> Utf8 Class Initialized
INFO - 2021-09-23 12:55:31 --> URI Class Initialized
INFO - 2021-09-23 12:55:31 --> Router Class Initialized
INFO - 2021-09-23 12:55:31 --> Output Class Initialized
INFO - 2021-09-23 12:55:31 --> Security Class Initialized
DEBUG - 2021-09-23 12:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:55:31 --> Input Class Initialized
INFO - 2021-09-23 12:55:31 --> Language Class Initialized
INFO - 2021-09-23 12:55:31 --> Loader Class Initialized
INFO - 2021-09-23 12:55:31 --> Helper loaded: url_helper
INFO - 2021-09-23 12:55:31 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:55:31 --> Controller Class Initialized
INFO - 2021-09-23 12:55:31 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:55:31 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:55:31 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:55:31 --> Database Driver Class Initialized
INFO - 2021-09-23 12:55:31 --> Helper loaded: string_helper
INFO - 2021-09-23 12:55:31 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:55:31 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:55:31 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-23 12:55:31 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-23 12:55:31 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-23 12:55:31 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/testimonials.php
INFO - 2021-09-23 12:55:31 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-23 12:55:31 --> Final output sent to browser
DEBUG - 2021-09-23 12:55:31 --> Total execution time: 0.0717
INFO - 2021-09-23 12:55:33 --> Config Class Initialized
INFO - 2021-09-23 12:55:33 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:55:33 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:55:33 --> Utf8 Class Initialized
INFO - 2021-09-23 12:55:33 --> URI Class Initialized
INFO - 2021-09-23 12:55:33 --> Router Class Initialized
INFO - 2021-09-23 12:55:33 --> Output Class Initialized
INFO - 2021-09-23 12:55:34 --> Security Class Initialized
DEBUG - 2021-09-23 12:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:55:34 --> Input Class Initialized
INFO - 2021-09-23 12:55:34 --> Language Class Initialized
INFO - 2021-09-23 12:55:34 --> Loader Class Initialized
INFO - 2021-09-23 12:55:34 --> Helper loaded: url_helper
INFO - 2021-09-23 12:55:34 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:55:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:55:34 --> Controller Class Initialized
INFO - 2021-09-23 12:55:34 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:55:34 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:55:34 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:55:34 --> Database Driver Class Initialized
INFO - 2021-09-23 12:55:34 --> Helper loaded: string_helper
INFO - 2021-09-23 12:55:34 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:55:34 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:55:34 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-23 12:55:34 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-23 12:55:34 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-23 12:55:34 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/testimonial.php
INFO - 2021-09-23 12:55:34 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-23 12:55:34 --> Final output sent to browser
DEBUG - 2021-09-23 12:55:34 --> Total execution time: 0.0907
INFO - 2021-09-23 12:56:00 --> Config Class Initialized
INFO - 2021-09-23 12:56:00 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:56:00 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:56:00 --> Utf8 Class Initialized
INFO - 2021-09-23 12:56:00 --> URI Class Initialized
INFO - 2021-09-23 12:56:00 --> Router Class Initialized
INFO - 2021-09-23 12:56:00 --> Output Class Initialized
INFO - 2021-09-23 12:56:00 --> Security Class Initialized
DEBUG - 2021-09-23 12:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:56:00 --> Input Class Initialized
INFO - 2021-09-23 12:56:00 --> Language Class Initialized
INFO - 2021-09-23 12:56:00 --> Loader Class Initialized
INFO - 2021-09-23 12:56:00 --> Helper loaded: url_helper
INFO - 2021-09-23 12:56:00 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:56:00 --> Controller Class Initialized
INFO - 2021-09-23 12:56:00 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:56:00 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:56:00 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:56:00 --> Database Driver Class Initialized
INFO - 2021-09-23 12:56:00 --> Helper loaded: string_helper
INFO - 2021-09-23 12:56:00 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:56:00 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:56:01 --> Config Class Initialized
INFO - 2021-09-23 12:56:01 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:56:01 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:56:01 --> Utf8 Class Initialized
INFO - 2021-09-23 12:56:01 --> URI Class Initialized
INFO - 2021-09-23 12:56:01 --> Router Class Initialized
INFO - 2021-09-23 12:56:01 --> Output Class Initialized
INFO - 2021-09-23 12:56:01 --> Security Class Initialized
DEBUG - 2021-09-23 12:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:56:01 --> Input Class Initialized
INFO - 2021-09-23 12:56:01 --> Language Class Initialized
INFO - 2021-09-23 12:56:01 --> Loader Class Initialized
INFO - 2021-09-23 12:56:01 --> Helper loaded: url_helper
INFO - 2021-09-23 12:56:01 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:56:01 --> Controller Class Initialized
INFO - 2021-09-23 12:56:01 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:56:01 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:56:01 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:56:01 --> Database Driver Class Initialized
INFO - 2021-09-23 12:56:01 --> Helper loaded: string_helper
INFO - 2021-09-23 12:56:01 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:56:01 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:56:01 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-23 12:56:01 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-23 12:56:01 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-23 12:56:01 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/testimonials.php
INFO - 2021-09-23 12:56:01 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-23 12:56:01 --> Final output sent to browser
DEBUG - 2021-09-23 12:56:01 --> Total execution time: 0.1037
INFO - 2021-09-23 12:56:21 --> Config Class Initialized
INFO - 2021-09-23 12:56:21 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:56:21 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:56:21 --> Utf8 Class Initialized
INFO - 2021-09-23 12:56:21 --> URI Class Initialized
INFO - 2021-09-23 12:56:21 --> Router Class Initialized
INFO - 2021-09-23 12:56:21 --> Output Class Initialized
INFO - 2021-09-23 12:56:21 --> Security Class Initialized
DEBUG - 2021-09-23 12:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:56:21 --> Input Class Initialized
INFO - 2021-09-23 12:56:21 --> Language Class Initialized
INFO - 2021-09-23 12:56:21 --> Loader Class Initialized
INFO - 2021-09-23 12:56:21 --> Helper loaded: url_helper
INFO - 2021-09-23 12:56:21 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:56:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:56:21 --> Controller Class Initialized
INFO - 2021-09-23 12:56:21 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:56:21 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:56:21 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:56:21 --> Database Driver Class Initialized
INFO - 2021-09-23 12:56:21 --> Helper loaded: string_helper
INFO - 2021-09-23 12:56:21 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:56:21 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:56:21 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-23 12:56:21 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-23 12:56:21 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-23 12:56:21 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/testimonials.php
INFO - 2021-09-23 12:56:21 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-23 12:56:21 --> Final output sent to browser
DEBUG - 2021-09-23 12:56:21 --> Total execution time: 0.0839
INFO - 2021-09-23 12:56:23 --> Config Class Initialized
INFO - 2021-09-23 12:56:23 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:56:23 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:56:23 --> Utf8 Class Initialized
INFO - 2021-09-23 12:56:23 --> URI Class Initialized
INFO - 2021-09-23 12:56:23 --> Router Class Initialized
INFO - 2021-09-23 12:56:23 --> Output Class Initialized
INFO - 2021-09-23 12:56:23 --> Security Class Initialized
DEBUG - 2021-09-23 12:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:56:23 --> Input Class Initialized
INFO - 2021-09-23 12:56:23 --> Language Class Initialized
INFO - 2021-09-23 12:56:24 --> Loader Class Initialized
INFO - 2021-09-23 12:56:24 --> Helper loaded: url_helper
INFO - 2021-09-23 12:56:24 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:56:24 --> Controller Class Initialized
INFO - 2021-09-23 12:56:24 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:56:24 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:56:24 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:56:24 --> Database Driver Class Initialized
INFO - 2021-09-23 12:56:24 --> Helper loaded: string_helper
INFO - 2021-09-23 12:56:24 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:56:24 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:56:24 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-23 12:56:24 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-23 12:56:24 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-23 12:56:24 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/testimonial.php
INFO - 2021-09-23 12:56:24 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-23 12:56:24 --> Final output sent to browser
DEBUG - 2021-09-23 12:56:24 --> Total execution time: 0.0692
INFO - 2021-09-23 12:56:28 --> Config Class Initialized
INFO - 2021-09-23 12:56:28 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:56:28 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:56:28 --> Utf8 Class Initialized
INFO - 2021-09-23 12:56:28 --> URI Class Initialized
INFO - 2021-09-23 12:56:28 --> Router Class Initialized
INFO - 2021-09-23 12:56:28 --> Output Class Initialized
INFO - 2021-09-23 12:56:28 --> Security Class Initialized
DEBUG - 2021-09-23 12:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:56:28 --> Input Class Initialized
INFO - 2021-09-23 12:56:28 --> Language Class Initialized
INFO - 2021-09-23 12:56:28 --> Loader Class Initialized
INFO - 2021-09-23 12:56:28 --> Helper loaded: url_helper
INFO - 2021-09-23 12:56:28 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:56:28 --> Controller Class Initialized
INFO - 2021-09-23 12:56:28 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:56:28 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:56:28 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:56:28 --> Database Driver Class Initialized
INFO - 2021-09-23 12:56:28 --> Helper loaded: string_helper
INFO - 2021-09-23 12:56:28 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:56:28 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:56:28 --> Config Class Initialized
INFO - 2021-09-23 12:56:28 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:56:28 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:56:28 --> Utf8 Class Initialized
INFO - 2021-09-23 12:56:28 --> URI Class Initialized
INFO - 2021-09-23 12:56:28 --> Router Class Initialized
INFO - 2021-09-23 12:56:28 --> Output Class Initialized
INFO - 2021-09-23 12:56:28 --> Security Class Initialized
DEBUG - 2021-09-23 12:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:56:28 --> Input Class Initialized
INFO - 2021-09-23 12:56:28 --> Language Class Initialized
INFO - 2021-09-23 12:56:28 --> Loader Class Initialized
INFO - 2021-09-23 12:56:28 --> Helper loaded: url_helper
INFO - 2021-09-23 12:56:28 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:56:28 --> Controller Class Initialized
INFO - 2021-09-23 12:56:28 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:56:28 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:56:28 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:56:28 --> Database Driver Class Initialized
INFO - 2021-09-23 12:56:28 --> Helper loaded: string_helper
INFO - 2021-09-23 12:56:28 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:56:28 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:56:28 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-23 12:56:28 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-23 12:56:28 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-23 12:56:28 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/testimonials.php
INFO - 2021-09-23 12:56:28 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-23 12:56:28 --> Final output sent to browser
DEBUG - 2021-09-23 12:56:28 --> Total execution time: 0.0971
INFO - 2021-09-23 12:57:14 --> Config Class Initialized
INFO - 2021-09-23 12:57:14 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:57:14 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:57:14 --> Utf8 Class Initialized
INFO - 2021-09-23 12:57:14 --> URI Class Initialized
INFO - 2021-09-23 12:57:14 --> Router Class Initialized
INFO - 2021-09-23 12:57:14 --> Output Class Initialized
INFO - 2021-09-23 12:57:14 --> Security Class Initialized
DEBUG - 2021-09-23 12:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:57:14 --> Input Class Initialized
INFO - 2021-09-23 12:57:14 --> Language Class Initialized
INFO - 2021-09-23 12:57:14 --> Loader Class Initialized
INFO - 2021-09-23 12:57:14 --> Helper loaded: url_helper
INFO - 2021-09-23 12:57:14 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:57:14 --> Controller Class Initialized
INFO - 2021-09-23 12:57:14 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:57:14 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:57:14 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:57:14 --> Database Driver Class Initialized
INFO - 2021-09-23 12:57:14 --> Helper loaded: string_helper
INFO - 2021-09-23 12:57:14 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:57:14 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:57:14 --> Config Class Initialized
INFO - 2021-09-23 12:57:14 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:57:14 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:57:14 --> Utf8 Class Initialized
INFO - 2021-09-23 12:57:14 --> URI Class Initialized
INFO - 2021-09-23 12:57:14 --> Router Class Initialized
INFO - 2021-09-23 12:57:14 --> Output Class Initialized
INFO - 2021-09-23 12:57:14 --> Security Class Initialized
DEBUG - 2021-09-23 12:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:57:14 --> Input Class Initialized
INFO - 2021-09-23 12:57:14 --> Language Class Initialized
INFO - 2021-09-23 12:57:14 --> Loader Class Initialized
INFO - 2021-09-23 12:57:14 --> Helper loaded: url_helper
INFO - 2021-09-23 12:57:14 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:57:14 --> Controller Class Initialized
INFO - 2021-09-23 12:57:14 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:57:14 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:57:14 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:57:14 --> Database Driver Class Initialized
INFO - 2021-09-23 12:57:14 --> Helper loaded: string_helper
INFO - 2021-09-23 12:57:14 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:57:14 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:57:14 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-23 12:57:14 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-23 12:57:14 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-23 12:57:14 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/testimonials.php
INFO - 2021-09-23 12:57:14 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-23 12:57:14 --> Final output sent to browser
DEBUG - 2021-09-23 12:57:14 --> Total execution time: 0.1014
INFO - 2021-09-23 12:57:18 --> Config Class Initialized
INFO - 2021-09-23 12:57:18 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:57:18 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:57:18 --> Utf8 Class Initialized
INFO - 2021-09-23 12:57:18 --> URI Class Initialized
INFO - 2021-09-23 12:57:18 --> Router Class Initialized
INFO - 2021-09-23 12:57:18 --> Output Class Initialized
INFO - 2021-09-23 12:57:18 --> Security Class Initialized
DEBUG - 2021-09-23 12:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:57:18 --> Input Class Initialized
INFO - 2021-09-23 12:57:18 --> Language Class Initialized
INFO - 2021-09-23 12:57:18 --> Loader Class Initialized
INFO - 2021-09-23 12:57:18 --> Helper loaded: url_helper
INFO - 2021-09-23 12:57:18 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:57:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:57:18 --> Controller Class Initialized
INFO - 2021-09-23 12:57:18 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:57:18 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:57:18 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:57:18 --> Database Driver Class Initialized
INFO - 2021-09-23 12:57:18 --> Helper loaded: string_helper
INFO - 2021-09-23 12:57:18 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:57:18 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:57:18 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-23 12:57:18 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-23 12:57:18 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-23 12:57:18 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/testimonial.php
INFO - 2021-09-23 12:57:18 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-23 12:57:18 --> Final output sent to browser
DEBUG - 2021-09-23 12:57:18 --> Total execution time: 0.0737
INFO - 2021-09-23 12:57:22 --> Config Class Initialized
INFO - 2021-09-23 12:57:22 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:57:22 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:57:22 --> Utf8 Class Initialized
INFO - 2021-09-23 12:57:22 --> URI Class Initialized
INFO - 2021-09-23 12:57:22 --> Router Class Initialized
INFO - 2021-09-23 12:57:22 --> Output Class Initialized
INFO - 2021-09-23 12:57:22 --> Security Class Initialized
DEBUG - 2021-09-23 12:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:57:22 --> Input Class Initialized
INFO - 2021-09-23 12:57:22 --> Language Class Initialized
INFO - 2021-09-23 12:57:22 --> Loader Class Initialized
INFO - 2021-09-23 12:57:22 --> Helper loaded: url_helper
INFO - 2021-09-23 12:57:22 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:57:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:57:22 --> Controller Class Initialized
INFO - 2021-09-23 12:57:22 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:57:22 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:57:22 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:57:23 --> Database Driver Class Initialized
INFO - 2021-09-23 12:57:23 --> Helper loaded: string_helper
INFO - 2021-09-23 12:57:23 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:57:23 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:57:23 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-23 12:57:23 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-23 12:57:23 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-23 12:57:23 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/testimonials.php
INFO - 2021-09-23 12:57:23 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-23 12:57:23 --> Final output sent to browser
DEBUG - 2021-09-23 12:57:23 --> Total execution time: 0.0813
INFO - 2021-09-23 12:57:40 --> Config Class Initialized
INFO - 2021-09-23 12:57:40 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:57:40 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:57:40 --> Utf8 Class Initialized
INFO - 2021-09-23 12:57:40 --> URI Class Initialized
INFO - 2021-09-23 12:57:40 --> Router Class Initialized
INFO - 2021-09-23 12:57:40 --> Output Class Initialized
INFO - 2021-09-23 12:57:40 --> Security Class Initialized
DEBUG - 2021-09-23 12:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:57:40 --> Input Class Initialized
INFO - 2021-09-23 12:57:40 --> Language Class Initialized
INFO - 2021-09-23 12:57:40 --> Loader Class Initialized
INFO - 2021-09-23 12:57:40 --> Helper loaded: url_helper
INFO - 2021-09-23 12:57:40 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:57:40 --> Controller Class Initialized
INFO - 2021-09-23 12:57:40 --> Model "DBModel" initialized
DEBUG - 2021-09-23 12:57:40 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 12:57:40 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:57:40 --> Database Driver Class Initialized
INFO - 2021-09-23 12:57:40 --> Helper loaded: string_helper
INFO - 2021-09-23 12:57:40 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 12:57:40 --> Model "BlogModel" initialized
INFO - 2021-09-23 12:57:40 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-23 12:57:40 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-23 12:57:40 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-23 12:57:40 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/dashboard.php
INFO - 2021-09-23 12:57:40 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-23 12:57:40 --> Final output sent to browser
DEBUG - 2021-09-23 12:57:40 --> Total execution time: 0.1120
INFO - 2021-09-23 12:57:42 --> Config Class Initialized
INFO - 2021-09-23 12:57:42 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:57:42 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:57:42 --> Utf8 Class Initialized
INFO - 2021-09-23 12:57:42 --> URI Class Initialized
DEBUG - 2021-09-23 12:57:42 --> No URI present. Default controller set.
INFO - 2021-09-23 12:57:42 --> Router Class Initialized
INFO - 2021-09-23 12:57:42 --> Output Class Initialized
INFO - 2021-09-23 12:57:42 --> Security Class Initialized
DEBUG - 2021-09-23 12:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:57:42 --> Input Class Initialized
INFO - 2021-09-23 12:57:42 --> Language Class Initialized
INFO - 2021-09-23 12:57:42 --> Loader Class Initialized
INFO - 2021-09-23 12:57:42 --> Helper loaded: url_helper
INFO - 2021-09-23 12:57:42 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:57:42 --> Controller Class Initialized
INFO - 2021-09-23 12:57:42 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:57:42 --> Model "CookieModel" initialized
INFO - 2021-09-23 12:57:42 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 12:57:42 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/index.php
INFO - 2021-09-23 12:57:42 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 12:57:42 --> Final output sent to browser
DEBUG - 2021-09-23 12:57:42 --> Total execution time: 0.0830
INFO - 2021-09-23 12:58:13 --> Config Class Initialized
INFO - 2021-09-23 12:58:13 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:58:13 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:58:13 --> Utf8 Class Initialized
INFO - 2021-09-23 12:58:13 --> URI Class Initialized
INFO - 2021-09-23 12:58:13 --> Router Class Initialized
INFO - 2021-09-23 12:58:13 --> Output Class Initialized
INFO - 2021-09-23 12:58:13 --> Security Class Initialized
DEBUG - 2021-09-23 12:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:58:13 --> Input Class Initialized
INFO - 2021-09-23 12:58:13 --> Language Class Initialized
INFO - 2021-09-23 12:58:13 --> Loader Class Initialized
INFO - 2021-09-23 12:58:13 --> Helper loaded: url_helper
INFO - 2021-09-23 12:58:13 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:58:13 --> Controller Class Initialized
INFO - 2021-09-23 12:58:13 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:58:13 --> Model "CookieModel" initialized
INFO - 2021-09-23 12:58:13 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 12:58:13 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/success_stories.php
INFO - 2021-09-23 12:58:13 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 12:58:13 --> Final output sent to browser
DEBUG - 2021-09-23 12:58:13 --> Total execution time: 0.0542
INFO - 2021-09-23 12:58:44 --> Config Class Initialized
INFO - 2021-09-23 12:58:44 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:58:44 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:58:44 --> Utf8 Class Initialized
INFO - 2021-09-23 12:58:44 --> URI Class Initialized
DEBUG - 2021-09-23 12:58:44 --> No URI present. Default controller set.
INFO - 2021-09-23 12:58:44 --> Router Class Initialized
INFO - 2021-09-23 12:58:44 --> Output Class Initialized
INFO - 2021-09-23 12:58:44 --> Security Class Initialized
DEBUG - 2021-09-23 12:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:58:44 --> Input Class Initialized
INFO - 2021-09-23 12:58:44 --> Language Class Initialized
INFO - 2021-09-23 12:58:44 --> Loader Class Initialized
INFO - 2021-09-23 12:58:44 --> Helper loaded: url_helper
INFO - 2021-09-23 12:58:44 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:58:44 --> Controller Class Initialized
INFO - 2021-09-23 12:58:44 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:58:44 --> Model "CookieModel" initialized
INFO - 2021-09-23 12:58:44 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 12:58:44 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/index.php
INFO - 2021-09-23 12:58:44 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 12:58:44 --> Final output sent to browser
DEBUG - 2021-09-23 12:58:44 --> Total execution time: 0.0548
INFO - 2021-09-23 12:59:06 --> Config Class Initialized
INFO - 2021-09-23 12:59:06 --> Hooks Class Initialized
DEBUG - 2021-09-23 12:59:06 --> UTF-8 Support Enabled
INFO - 2021-09-23 12:59:06 --> Utf8 Class Initialized
INFO - 2021-09-23 12:59:06 --> URI Class Initialized
INFO - 2021-09-23 12:59:06 --> Router Class Initialized
INFO - 2021-09-23 12:59:06 --> Output Class Initialized
INFO - 2021-09-23 12:59:06 --> Security Class Initialized
DEBUG - 2021-09-23 12:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 12:59:06 --> Input Class Initialized
INFO - 2021-09-23 12:59:06 --> Language Class Initialized
INFO - 2021-09-23 12:59:06 --> Loader Class Initialized
INFO - 2021-09-23 12:59:06 --> Helper loaded: url_helper
INFO - 2021-09-23 12:59:06 --> Helper loaded: file_helper
DEBUG - 2021-09-23 12:59:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 12:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 12:59:06 --> Controller Class Initialized
INFO - 2021-09-23 12:59:06 --> Helper loaded: cookie_helper
INFO - 2021-09-23 12:59:06 --> Model "CookieModel" initialized
INFO - 2021-09-23 12:59:06 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 12:59:06 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/success_stories.php
INFO - 2021-09-23 12:59:06 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 12:59:06 --> Final output sent to browser
DEBUG - 2021-09-23 12:59:06 --> Total execution time: 0.0548
INFO - 2021-09-23 13:00:56 --> Config Class Initialized
INFO - 2021-09-23 13:00:56 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:00:56 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:00:56 --> Utf8 Class Initialized
INFO - 2021-09-23 13:00:56 --> URI Class Initialized
INFO - 2021-09-23 13:00:56 --> Router Class Initialized
INFO - 2021-09-23 13:00:56 --> Output Class Initialized
INFO - 2021-09-23 13:00:56 --> Security Class Initialized
DEBUG - 2021-09-23 13:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:00:56 --> Input Class Initialized
INFO - 2021-09-23 13:00:56 --> Language Class Initialized
INFO - 2021-09-23 13:00:56 --> Loader Class Initialized
INFO - 2021-09-23 13:00:56 --> Helper loaded: url_helper
INFO - 2021-09-23 13:00:56 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:00:56 --> Controller Class Initialized
INFO - 2021-09-23 13:00:56 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:00:56 --> Model "CookieModel" initialized
INFO - 2021-09-23 13:00:56 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 13:00:56 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/success_stories.php
INFO - 2021-09-23 13:00:56 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 13:00:56 --> Final output sent to browser
DEBUG - 2021-09-23 13:00:56 --> Total execution time: 0.2442
INFO - 2021-09-23 13:02:33 --> Config Class Initialized
INFO - 2021-09-23 13:02:33 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:02:33 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:02:33 --> Utf8 Class Initialized
INFO - 2021-09-23 13:02:33 --> URI Class Initialized
DEBUG - 2021-09-23 13:02:33 --> No URI present. Default controller set.
INFO - 2021-09-23 13:02:33 --> Router Class Initialized
INFO - 2021-09-23 13:02:33 --> Output Class Initialized
INFO - 2021-09-23 13:02:33 --> Security Class Initialized
DEBUG - 2021-09-23 13:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:02:33 --> Input Class Initialized
INFO - 2021-09-23 13:02:33 --> Language Class Initialized
INFO - 2021-09-23 13:02:33 --> Loader Class Initialized
INFO - 2021-09-23 13:02:33 --> Helper loaded: url_helper
INFO - 2021-09-23 13:02:33 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:02:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:02:33 --> Controller Class Initialized
INFO - 2021-09-23 13:02:33 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:02:33 --> Model "CookieModel" initialized
INFO - 2021-09-23 13:02:33 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 13:02:33 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/index.php
INFO - 2021-09-23 13:02:33 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 13:02:33 --> Final output sent to browser
DEBUG - 2021-09-23 13:02:33 --> Total execution time: 0.0668
INFO - 2021-09-23 13:05:16 --> Config Class Initialized
INFO - 2021-09-23 13:05:16 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:05:16 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:05:16 --> Utf8 Class Initialized
INFO - 2021-09-23 13:05:16 --> URI Class Initialized
DEBUG - 2021-09-23 13:05:16 --> No URI present. Default controller set.
INFO - 2021-09-23 13:05:16 --> Router Class Initialized
INFO - 2021-09-23 13:05:16 --> Output Class Initialized
INFO - 2021-09-23 13:05:16 --> Security Class Initialized
DEBUG - 2021-09-23 13:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:05:16 --> Input Class Initialized
INFO - 2021-09-23 13:05:16 --> Language Class Initialized
INFO - 2021-09-23 13:05:16 --> Loader Class Initialized
INFO - 2021-09-23 13:05:16 --> Helper loaded: url_helper
INFO - 2021-09-23 13:05:16 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:05:16 --> Controller Class Initialized
INFO - 2021-09-23 13:05:16 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:05:16 --> Model "CookieModel" initialized
INFO - 2021-09-23 13:05:16 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 13:05:16 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/index.php
INFO - 2021-09-23 13:05:16 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 13:05:16 --> Final output sent to browser
DEBUG - 2021-09-23 13:05:16 --> Total execution time: 0.0477
INFO - 2021-09-23 13:05:27 --> Config Class Initialized
INFO - 2021-09-23 13:05:27 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:05:27 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:05:27 --> Utf8 Class Initialized
INFO - 2021-09-23 13:05:27 --> URI Class Initialized
INFO - 2021-09-23 13:05:27 --> Router Class Initialized
INFO - 2021-09-23 13:05:27 --> Output Class Initialized
INFO - 2021-09-23 13:05:27 --> Security Class Initialized
DEBUG - 2021-09-23 13:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:05:27 --> Input Class Initialized
INFO - 2021-09-23 13:05:27 --> Language Class Initialized
INFO - 2021-09-23 13:05:27 --> Loader Class Initialized
INFO - 2021-09-23 13:05:27 --> Helper loaded: url_helper
INFO - 2021-09-23 13:05:27 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:05:27 --> Controller Class Initialized
INFO - 2021-09-23 13:05:27 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:05:27 --> Model "CookieModel" initialized
INFO - 2021-09-23 13:05:27 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 13:05:27 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/testimonials.php
INFO - 2021-09-23 13:05:27 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 13:05:27 --> Final output sent to browser
DEBUG - 2021-09-23 13:05:27 --> Total execution time: 0.0510
INFO - 2021-09-23 13:15:57 --> Config Class Initialized
INFO - 2021-09-23 13:15:57 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:15:57 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:15:57 --> Utf8 Class Initialized
INFO - 2021-09-23 13:15:57 --> URI Class Initialized
DEBUG - 2021-09-23 13:15:57 --> No URI present. Default controller set.
INFO - 2021-09-23 13:15:57 --> Router Class Initialized
INFO - 2021-09-23 13:15:57 --> Output Class Initialized
INFO - 2021-09-23 13:15:57 --> Security Class Initialized
DEBUG - 2021-09-23 13:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:15:57 --> Input Class Initialized
INFO - 2021-09-23 13:15:57 --> Language Class Initialized
INFO - 2021-09-23 13:15:57 --> Loader Class Initialized
INFO - 2021-09-23 13:15:57 --> Helper loaded: url_helper
INFO - 2021-09-23 13:15:57 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:15:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:15:57 --> Controller Class Initialized
INFO - 2021-09-23 13:15:57 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:15:57 --> Model "CookieModel" initialized
INFO - 2021-09-23 13:15:57 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 13:15:57 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/index.php
INFO - 2021-09-23 13:15:57 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 13:15:57 --> Final output sent to browser
DEBUG - 2021-09-23 13:15:57 --> Total execution time: 0.0486
INFO - 2021-09-23 13:15:59 --> Config Class Initialized
INFO - 2021-09-23 13:15:59 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:15:59 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:15:59 --> Utf8 Class Initialized
INFO - 2021-09-23 13:15:59 --> URI Class Initialized
DEBUG - 2021-09-23 13:15:59 --> No URI present. Default controller set.
INFO - 2021-09-23 13:15:59 --> Router Class Initialized
INFO - 2021-09-23 13:15:59 --> Output Class Initialized
INFO - 2021-09-23 13:15:59 --> Security Class Initialized
DEBUG - 2021-09-23 13:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:15:59 --> Input Class Initialized
INFO - 2021-09-23 13:15:59 --> Language Class Initialized
INFO - 2021-09-23 13:15:59 --> Loader Class Initialized
INFO - 2021-09-23 13:15:59 --> Helper loaded: url_helper
INFO - 2021-09-23 13:15:59 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:15:59 --> Controller Class Initialized
INFO - 2021-09-23 13:15:59 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:15:59 --> Model "CookieModel" initialized
INFO - 2021-09-23 13:15:59 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 13:15:59 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/index.php
INFO - 2021-09-23 13:15:59 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 13:15:59 --> Final output sent to browser
DEBUG - 2021-09-23 13:15:59 --> Total execution time: 0.0542
INFO - 2021-09-23 13:16:02 --> Config Class Initialized
INFO - 2021-09-23 13:16:02 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:16:02 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:16:02 --> Utf8 Class Initialized
INFO - 2021-09-23 13:16:02 --> URI Class Initialized
INFO - 2021-09-23 13:16:02 --> Router Class Initialized
INFO - 2021-09-23 13:16:02 --> Output Class Initialized
INFO - 2021-09-23 13:16:02 --> Security Class Initialized
DEBUG - 2021-09-23 13:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:16:02 --> Input Class Initialized
INFO - 2021-09-23 13:16:02 --> Language Class Initialized
INFO - 2021-09-23 13:16:02 --> Loader Class Initialized
INFO - 2021-09-23 13:16:02 --> Helper loaded: url_helper
INFO - 2021-09-23 13:16:02 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:16:02 --> Controller Class Initialized
INFO - 2021-09-23 13:16:02 --> Database Driver Class Initialized
INFO - 2021-09-23 13:16:02 --> Helper loaded: string_helper
INFO - 2021-09-23 13:16:02 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 13:16:02 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:16:02 --> Model "CookieModel" initialized
INFO - 2021-09-23 13:16:02 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 13:16:02 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/testimonials.php
INFO - 2021-09-23 13:16:02 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 13:16:02 --> Final output sent to browser
DEBUG - 2021-09-23 13:16:02 --> Total execution time: 0.0741
INFO - 2021-09-23 13:22:32 --> Config Class Initialized
INFO - 2021-09-23 13:22:32 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:22:32 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:22:32 --> Utf8 Class Initialized
INFO - 2021-09-23 13:22:32 --> URI Class Initialized
INFO - 2021-09-23 13:22:32 --> Router Class Initialized
INFO - 2021-09-23 13:22:32 --> Output Class Initialized
INFO - 2021-09-23 13:22:32 --> Security Class Initialized
DEBUG - 2021-09-23 13:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:22:32 --> Input Class Initialized
INFO - 2021-09-23 13:22:32 --> Language Class Initialized
INFO - 2021-09-23 13:22:32 --> Loader Class Initialized
INFO - 2021-09-23 13:22:32 --> Helper loaded: url_helper
INFO - 2021-09-23 13:22:32 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:22:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:22:32 --> Controller Class Initialized
INFO - 2021-09-23 13:22:32 --> Model "DBModel" initialized
DEBUG - 2021-09-23 13:22:32 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 13:22:32 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:22:32 --> Database Driver Class Initialized
INFO - 2021-09-23 13:22:32 --> Helper loaded: string_helper
INFO - 2021-09-23 13:22:32 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 13:22:32 --> Model "BlogModel" initialized
INFO - 2021-09-23 13:22:32 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-23 13:22:32 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-23 13:22:32 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-23 13:22:32 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/dashboard.php
INFO - 2021-09-23 13:22:32 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-23 13:22:32 --> Final output sent to browser
DEBUG - 2021-09-23 13:22:32 --> Total execution time: 0.0794
INFO - 2021-09-23 13:22:37 --> Config Class Initialized
INFO - 2021-09-23 13:22:37 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:22:37 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:22:37 --> Utf8 Class Initialized
INFO - 2021-09-23 13:22:37 --> URI Class Initialized
INFO - 2021-09-23 13:22:37 --> Router Class Initialized
INFO - 2021-09-23 13:22:37 --> Output Class Initialized
INFO - 2021-09-23 13:22:37 --> Security Class Initialized
DEBUG - 2021-09-23 13:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:22:37 --> Input Class Initialized
INFO - 2021-09-23 13:22:37 --> Language Class Initialized
INFO - 2021-09-23 13:22:37 --> Loader Class Initialized
INFO - 2021-09-23 13:22:37 --> Helper loaded: url_helper
INFO - 2021-09-23 13:22:37 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:22:37 --> Controller Class Initialized
INFO - 2021-09-23 13:22:37 --> Database Driver Class Initialized
INFO - 2021-09-23 13:22:37 --> Helper loaded: string_helper
INFO - 2021-09-23 13:22:37 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 13:22:37 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:22:37 --> Model "CookieModel" initialized
INFO - 2021-09-23 13:22:37 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 13:22:37 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/testimonials.php
INFO - 2021-09-23 13:22:37 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 13:22:37 --> Final output sent to browser
DEBUG - 2021-09-23 13:22:37 --> Total execution time: 0.0842
INFO - 2021-09-23 13:27:34 --> Config Class Initialized
INFO - 2021-09-23 13:27:34 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:27:34 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:27:34 --> Utf8 Class Initialized
INFO - 2021-09-23 13:27:34 --> URI Class Initialized
INFO - 2021-09-23 13:27:34 --> Router Class Initialized
INFO - 2021-09-23 13:27:34 --> Output Class Initialized
INFO - 2021-09-23 13:27:34 --> Security Class Initialized
DEBUG - 2021-09-23 13:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:27:34 --> Input Class Initialized
INFO - 2021-09-23 13:27:34 --> Language Class Initialized
INFO - 2021-09-23 13:27:34 --> Loader Class Initialized
INFO - 2021-09-23 13:27:34 --> Helper loaded: url_helper
INFO - 2021-09-23 13:27:34 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:27:34 --> Controller Class Initialized
INFO - 2021-09-23 13:27:34 --> Database Driver Class Initialized
INFO - 2021-09-23 13:27:34 --> Helper loaded: string_helper
INFO - 2021-09-23 13:27:34 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 13:27:34 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:27:34 --> Model "CookieModel" initialized
INFO - 2021-09-23 13:27:34 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 13:27:34 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/testimonials.php
INFO - 2021-09-23 13:27:34 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 13:27:34 --> Final output sent to browser
DEBUG - 2021-09-23 13:27:34 --> Total execution time: 0.0726
INFO - 2021-09-23 13:28:02 --> Config Class Initialized
INFO - 2021-09-23 13:28:02 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:28:02 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:28:02 --> Utf8 Class Initialized
INFO - 2021-09-23 13:28:02 --> URI Class Initialized
DEBUG - 2021-09-23 13:28:02 --> No URI present. Default controller set.
INFO - 2021-09-23 13:28:02 --> Router Class Initialized
INFO - 2021-09-23 13:28:02 --> Output Class Initialized
INFO - 2021-09-23 13:28:02 --> Security Class Initialized
DEBUG - 2021-09-23 13:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:28:02 --> Input Class Initialized
INFO - 2021-09-23 13:28:02 --> Language Class Initialized
INFO - 2021-09-23 13:28:02 --> Loader Class Initialized
INFO - 2021-09-23 13:28:02 --> Helper loaded: url_helper
INFO - 2021-09-23 13:28:02 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:28:02 --> Controller Class Initialized
INFO - 2021-09-23 13:28:02 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:28:02 --> Model "CookieModel" initialized
INFO - 2021-09-23 13:28:02 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 13:28:02 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/index.php
INFO - 2021-09-23 13:28:02 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 13:28:02 --> Final output sent to browser
DEBUG - 2021-09-23 13:28:02 --> Total execution time: 0.0526
INFO - 2021-09-23 13:28:05 --> Config Class Initialized
INFO - 2021-09-23 13:28:05 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:28:05 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:28:05 --> Utf8 Class Initialized
INFO - 2021-09-23 13:28:05 --> URI Class Initialized
INFO - 2021-09-23 13:28:05 --> Router Class Initialized
INFO - 2021-09-23 13:28:05 --> Output Class Initialized
INFO - 2021-09-23 13:28:05 --> Security Class Initialized
DEBUG - 2021-09-23 13:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:28:05 --> Input Class Initialized
INFO - 2021-09-23 13:28:05 --> Language Class Initialized
INFO - 2021-09-23 13:28:05 --> Loader Class Initialized
INFO - 2021-09-23 13:28:05 --> Helper loaded: url_helper
INFO - 2021-09-23 13:28:05 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:28:05 --> Controller Class Initialized
INFO - 2021-09-23 13:28:05 --> Database Driver Class Initialized
INFO - 2021-09-23 13:28:05 --> Helper loaded: string_helper
INFO - 2021-09-23 13:28:05 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 13:28:05 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:28:05 --> Model "CookieModel" initialized
INFO - 2021-09-23 13:28:05 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 13:28:05 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/testimonials.php
INFO - 2021-09-23 13:28:05 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 13:28:05 --> Final output sent to browser
DEBUG - 2021-09-23 13:28:05 --> Total execution time: 0.0690
INFO - 2021-09-23 13:29:09 --> Config Class Initialized
INFO - 2021-09-23 13:29:09 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:29:09 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:29:09 --> Utf8 Class Initialized
INFO - 2021-09-23 13:29:09 --> URI Class Initialized
INFO - 2021-09-23 13:29:09 --> Router Class Initialized
INFO - 2021-09-23 13:29:09 --> Output Class Initialized
INFO - 2021-09-23 13:29:09 --> Security Class Initialized
DEBUG - 2021-09-23 13:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:29:09 --> Input Class Initialized
INFO - 2021-09-23 13:29:09 --> Language Class Initialized
INFO - 2021-09-23 13:29:09 --> Loader Class Initialized
INFO - 2021-09-23 13:29:09 --> Helper loaded: url_helper
INFO - 2021-09-23 13:29:09 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:29:09 --> Controller Class Initialized
INFO - 2021-09-23 13:29:09 --> Database Driver Class Initialized
INFO - 2021-09-23 13:29:09 --> Helper loaded: string_helper
INFO - 2021-09-23 13:29:09 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 13:29:09 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:29:09 --> Model "CookieModel" initialized
INFO - 2021-09-23 13:29:09 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 13:29:09 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/testimonials.php
INFO - 2021-09-23 13:29:09 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 13:29:09 --> Final output sent to browser
DEBUG - 2021-09-23 13:29:09 --> Total execution time: 0.0694
INFO - 2021-09-23 13:29:27 --> Config Class Initialized
INFO - 2021-09-23 13:29:27 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:29:27 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:29:27 --> Utf8 Class Initialized
INFO - 2021-09-23 13:29:27 --> URI Class Initialized
INFO - 2021-09-23 13:29:27 --> Router Class Initialized
INFO - 2021-09-23 13:29:27 --> Output Class Initialized
INFO - 2021-09-23 13:29:27 --> Security Class Initialized
DEBUG - 2021-09-23 13:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:29:27 --> Input Class Initialized
INFO - 2021-09-23 13:29:27 --> Language Class Initialized
INFO - 2021-09-23 13:29:27 --> Loader Class Initialized
INFO - 2021-09-23 13:29:27 --> Helper loaded: url_helper
INFO - 2021-09-23 13:29:27 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:29:27 --> Controller Class Initialized
INFO - 2021-09-23 13:29:27 --> Database Driver Class Initialized
INFO - 2021-09-23 13:29:27 --> Helper loaded: string_helper
INFO - 2021-09-23 13:29:28 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 13:29:28 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:29:28 --> Model "CookieModel" initialized
INFO - 2021-09-23 13:29:28 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 13:29:28 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/testimonials.php
INFO - 2021-09-23 13:29:28 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 13:29:28 --> Final output sent to browser
DEBUG - 2021-09-23 13:29:28 --> Total execution time: 0.0771
INFO - 2021-09-23 13:30:34 --> Config Class Initialized
INFO - 2021-09-23 13:30:34 --> Hooks Class Initialized
INFO - 2021-09-23 13:30:34 --> Config Class Initialized
DEBUG - 2021-09-23 13:30:34 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:30:34 --> Utf8 Class Initialized
INFO - 2021-09-23 13:30:34 --> Hooks Class Initialized
INFO - 2021-09-23 13:30:34 --> URI Class Initialized
INFO - 2021-09-23 13:30:34 --> Config Class Initialized
INFO - 2021-09-23 13:30:34 --> Hooks Class Initialized
INFO - 2021-09-23 13:30:34 --> Router Class Initialized
DEBUG - 2021-09-23 13:30:34 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:30:34 --> Utf8 Class Initialized
INFO - 2021-09-23 13:30:34 --> Output Class Initialized
DEBUG - 2021-09-23 13:30:34 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:30:34 --> URI Class Initialized
INFO - 2021-09-23 13:30:34 --> Utf8 Class Initialized
INFO - 2021-09-23 13:30:34 --> Security Class Initialized
INFO - 2021-09-23 13:30:34 --> URI Class Initialized
DEBUG - 2021-09-23 13:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:30:34 --> Input Class Initialized
INFO - 2021-09-23 13:30:34 --> Router Class Initialized
INFO - 2021-09-23 13:30:34 --> Language Class Initialized
ERROR - 2021-09-23 13:30:34 --> 404 Page Not Found: Assets/js
INFO - 2021-09-23 13:30:34 --> Router Class Initialized
INFO - 2021-09-23 13:30:34 --> Output Class Initialized
INFO - 2021-09-23 13:30:34 --> Output Class Initialized
INFO - 2021-09-23 13:30:34 --> Security Class Initialized
DEBUG - 2021-09-23 13:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:30:34 --> Security Class Initialized
INFO - 2021-09-23 13:30:34 --> Input Class Initialized
INFO - 2021-09-23 13:30:34 --> Language Class Initialized
DEBUG - 2021-09-23 13:30:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-09-23 13:30:34 --> 404 Page Not Found: Assets/js
INFO - 2021-09-23 13:30:34 --> Input Class Initialized
INFO - 2021-09-23 13:30:34 --> Language Class Initialized
ERROR - 2021-09-23 13:30:34 --> 404 Page Not Found: Assets/js
INFO - 2021-09-23 13:30:35 --> Config Class Initialized
INFO - 2021-09-23 13:30:35 --> Hooks Class Initialized
INFO - 2021-09-23 13:30:35 --> Config Class Initialized
DEBUG - 2021-09-23 13:30:35 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:30:35 --> Hooks Class Initialized
INFO - 2021-09-23 13:30:35 --> Utf8 Class Initialized
INFO - 2021-09-23 13:30:35 --> URI Class Initialized
DEBUG - 2021-09-23 13:30:35 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:30:35 --> Utf8 Class Initialized
INFO - 2021-09-23 13:30:35 --> Router Class Initialized
INFO - 2021-09-23 13:30:35 --> URI Class Initialized
INFO - 2021-09-23 13:30:35 --> Output Class Initialized
INFO - 2021-09-23 13:30:35 --> Router Class Initialized
INFO - 2021-09-23 13:30:35 --> Security Class Initialized
INFO - 2021-09-23 13:30:35 --> Output Class Initialized
DEBUG - 2021-09-23 13:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:30:35 --> Input Class Initialized
INFO - 2021-09-23 13:30:35 --> Security Class Initialized
INFO - 2021-09-23 13:30:35 --> Language Class Initialized
DEBUG - 2021-09-23 13:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:30:35 --> Input Class Initialized
ERROR - 2021-09-23 13:30:35 --> 404 Page Not Found: Assets/css
INFO - 2021-09-23 13:30:35 --> Language Class Initialized
ERROR - 2021-09-23 13:30:35 --> 404 Page Not Found: Assets/css
INFO - 2021-09-23 13:32:28 --> Config Class Initialized
INFO - 2021-09-23 13:32:28 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:32:28 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:32:28 --> Utf8 Class Initialized
INFO - 2021-09-23 13:32:28 --> URI Class Initialized
INFO - 2021-09-23 13:32:28 --> Router Class Initialized
INFO - 2021-09-23 13:32:28 --> Output Class Initialized
INFO - 2021-09-23 13:32:28 --> Security Class Initialized
DEBUG - 2021-09-23 13:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:32:28 --> Input Class Initialized
INFO - 2021-09-23 13:32:28 --> Language Class Initialized
INFO - 2021-09-23 13:32:28 --> Loader Class Initialized
INFO - 2021-09-23 13:32:28 --> Helper loaded: url_helper
INFO - 2021-09-23 13:32:28 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:32:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:32:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:32:28 --> Controller Class Initialized
INFO - 2021-09-23 13:32:28 --> Database Driver Class Initialized
INFO - 2021-09-23 13:32:28 --> Helper loaded: string_helper
INFO - 2021-09-23 13:32:28 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 13:32:28 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:32:28 --> Model "CookieModel" initialized
INFO - 2021-09-23 13:32:28 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 13:32:28 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/testimonials.php
INFO - 2021-09-23 13:32:28 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 13:32:28 --> Final output sent to browser
DEBUG - 2021-09-23 13:32:28 --> Total execution time: 0.0874
INFO - 2021-09-23 13:32:28 --> Config Class Initialized
INFO - 2021-09-23 13:32:28 --> Hooks Class Initialized
INFO - 2021-09-23 13:32:28 --> Config Class Initialized
INFO - 2021-09-23 13:32:28 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:32:28 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:32:28 --> Utf8 Class Initialized
DEBUG - 2021-09-23 13:32:28 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:32:28 --> Utf8 Class Initialized
INFO - 2021-09-23 13:32:28 --> URI Class Initialized
INFO - 2021-09-23 13:32:28 --> URI Class Initialized
INFO - 2021-09-23 13:32:28 --> Router Class Initialized
INFO - 2021-09-23 13:32:28 --> Router Class Initialized
INFO - 2021-09-23 13:32:28 --> Output Class Initialized
INFO - 2021-09-23 13:32:28 --> Output Class Initialized
INFO - 2021-09-23 13:32:28 --> Security Class Initialized
INFO - 2021-09-23 13:32:28 --> Security Class Initialized
DEBUG - 2021-09-23 13:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-09-23 13:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:32:28 --> Input Class Initialized
INFO - 2021-09-23 13:32:28 --> Input Class Initialized
INFO - 2021-09-23 13:32:28 --> Language Class Initialized
INFO - 2021-09-23 13:32:28 --> Language Class Initialized
ERROR - 2021-09-23 13:32:28 --> 404 Page Not Found: Assets/css
ERROR - 2021-09-23 13:32:28 --> 404 Page Not Found: Assets/css
INFO - 2021-09-23 13:32:28 --> Config Class Initialized
INFO - 2021-09-23 13:32:28 --> Hooks Class Initialized
INFO - 2021-09-23 13:32:28 --> Config Class Initialized
DEBUG - 2021-09-23 13:32:28 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:32:28 --> Hooks Class Initialized
INFO - 2021-09-23 13:32:28 --> Config Class Initialized
INFO - 2021-09-23 13:32:28 --> Utf8 Class Initialized
DEBUG - 2021-09-23 13:32:28 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:32:28 --> Hooks Class Initialized
INFO - 2021-09-23 13:32:28 --> Utf8 Class Initialized
INFO - 2021-09-23 13:32:28 --> URI Class Initialized
INFO - 2021-09-23 13:32:28 --> URI Class Initialized
DEBUG - 2021-09-23 13:32:28 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:32:28 --> Router Class Initialized
INFO - 2021-09-23 13:32:28 --> Router Class Initialized
INFO - 2021-09-23 13:32:28 --> Utf8 Class Initialized
INFO - 2021-09-23 13:32:28 --> Output Class Initialized
INFO - 2021-09-23 13:32:28 --> Output Class Initialized
INFO - 2021-09-23 13:32:28 --> Security Class Initialized
INFO - 2021-09-23 13:32:28 --> URI Class Initialized
DEBUG - 2021-09-23 13:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:32:28 --> Security Class Initialized
INFO - 2021-09-23 13:32:28 --> Input Class Initialized
INFO - 2021-09-23 13:32:28 --> Router Class Initialized
INFO - 2021-09-23 13:32:28 --> Language Class Initialized
DEBUG - 2021-09-23 13:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:32:28 --> Input Class Initialized
INFO - 2021-09-23 13:32:28 --> Output Class Initialized
ERROR - 2021-09-23 13:32:28 --> 404 Page Not Found: Assets/js
INFO - 2021-09-23 13:32:28 --> Language Class Initialized
INFO - 2021-09-23 13:32:28 --> Security Class Initialized
ERROR - 2021-09-23 13:32:28 --> 404 Page Not Found: Assets/js
DEBUG - 2021-09-23 13:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:32:28 --> Input Class Initialized
INFO - 2021-09-23 13:32:28 --> Language Class Initialized
ERROR - 2021-09-23 13:32:28 --> 404 Page Not Found: Assets/js
INFO - 2021-09-23 13:32:31 --> Config Class Initialized
INFO - 2021-09-23 13:32:31 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:32:31 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:32:31 --> Utf8 Class Initialized
INFO - 2021-09-23 13:32:31 --> URI Class Initialized
INFO - 2021-09-23 13:32:31 --> Router Class Initialized
INFO - 2021-09-23 13:32:31 --> Output Class Initialized
INFO - 2021-09-23 13:32:31 --> Security Class Initialized
DEBUG - 2021-09-23 13:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:32:31 --> Input Class Initialized
INFO - 2021-09-23 13:32:31 --> Language Class Initialized
INFO - 2021-09-23 13:32:31 --> Loader Class Initialized
INFO - 2021-09-23 13:32:31 --> Helper loaded: url_helper
INFO - 2021-09-23 13:32:31 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:32:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:32:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:32:31 --> Controller Class Initialized
INFO - 2021-09-23 13:32:31 --> Database Driver Class Initialized
INFO - 2021-09-23 13:32:31 --> Helper loaded: string_helper
INFO - 2021-09-23 13:32:31 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 13:32:31 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:32:31 --> Model "CookieModel" initialized
INFO - 2021-09-23 13:32:31 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 13:32:31 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/testimonials.php
INFO - 2021-09-23 13:32:31 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 13:32:31 --> Final output sent to browser
DEBUG - 2021-09-23 13:32:31 --> Total execution time: 0.0752
INFO - 2021-09-23 13:32:31 --> Config Class Initialized
INFO - 2021-09-23 13:32:31 --> Hooks Class Initialized
INFO - 2021-09-23 13:32:31 --> Config Class Initialized
DEBUG - 2021-09-23 13:32:31 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:32:31 --> Utf8 Class Initialized
INFO - 2021-09-23 13:32:31 --> Hooks Class Initialized
INFO - 2021-09-23 13:32:31 --> URI Class Initialized
INFO - 2021-09-23 13:32:31 --> Router Class Initialized
INFO - 2021-09-23 13:32:31 --> Output Class Initialized
DEBUG - 2021-09-23 13:32:31 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:32:31 --> Utf8 Class Initialized
INFO - 2021-09-23 13:32:31 --> Security Class Initialized
INFO - 2021-09-23 13:32:31 --> URI Class Initialized
DEBUG - 2021-09-23 13:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:32:31 --> Input Class Initialized
INFO - 2021-09-23 13:32:31 --> Language Class Initialized
INFO - 2021-09-23 13:32:31 --> Router Class Initialized
ERROR - 2021-09-23 13:32:31 --> 404 Page Not Found: Assets/css
INFO - 2021-09-23 13:32:31 --> Output Class Initialized
INFO - 2021-09-23 13:32:31 --> Security Class Initialized
DEBUG - 2021-09-23 13:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:32:31 --> Input Class Initialized
INFO - 2021-09-23 13:32:31 --> Language Class Initialized
ERROR - 2021-09-23 13:32:31 --> 404 Page Not Found: Assets/css
INFO - 2021-09-23 13:32:31 --> Config Class Initialized
INFO - 2021-09-23 13:32:31 --> Hooks Class Initialized
INFO - 2021-09-23 13:32:31 --> Config Class Initialized
INFO - 2021-09-23 13:32:31 --> Hooks Class Initialized
INFO - 2021-09-23 13:32:31 --> Config Class Initialized
DEBUG - 2021-09-23 13:32:31 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:32:31 --> Utf8 Class Initialized
INFO - 2021-09-23 13:32:31 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:32:31 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:32:31 --> Utf8 Class Initialized
INFO - 2021-09-23 13:32:31 --> URI Class Initialized
INFO - 2021-09-23 13:32:31 --> URI Class Initialized
DEBUG - 2021-09-23 13:32:31 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:32:31 --> Router Class Initialized
INFO - 2021-09-23 13:32:31 --> Output Class Initialized
INFO - 2021-09-23 13:32:31 --> Utf8 Class Initialized
INFO - 2021-09-23 13:32:31 --> Security Class Initialized
INFO - 2021-09-23 13:32:31 --> Router Class Initialized
DEBUG - 2021-09-23 13:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:32:31 --> URI Class Initialized
INFO - 2021-09-23 13:32:31 --> Output Class Initialized
INFO - 2021-09-23 13:32:31 --> Input Class Initialized
INFO - 2021-09-23 13:32:31 --> Router Class Initialized
INFO - 2021-09-23 13:32:31 --> Language Class Initialized
ERROR - 2021-09-23 13:32:31 --> 404 Page Not Found: Assets/js
INFO - 2021-09-23 13:32:31 --> Security Class Initialized
INFO - 2021-09-23 13:32:31 --> Output Class Initialized
DEBUG - 2021-09-23 13:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:32:31 --> Input Class Initialized
INFO - 2021-09-23 13:32:31 --> Security Class Initialized
INFO - 2021-09-23 13:32:31 --> Language Class Initialized
ERROR - 2021-09-23 13:32:31 --> 404 Page Not Found: Assets/js
DEBUG - 2021-09-23 13:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:32:31 --> Input Class Initialized
INFO - 2021-09-23 13:32:31 --> Language Class Initialized
ERROR - 2021-09-23 13:32:31 --> 404 Page Not Found: Assets/js
INFO - 2021-09-23 13:32:38 --> Config Class Initialized
INFO - 2021-09-23 13:32:38 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:32:38 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:32:38 --> Utf8 Class Initialized
INFO - 2021-09-23 13:32:38 --> URI Class Initialized
INFO - 2021-09-23 13:32:38 --> Router Class Initialized
INFO - 2021-09-23 13:32:38 --> Output Class Initialized
INFO - 2021-09-23 13:32:38 --> Security Class Initialized
DEBUG - 2021-09-23 13:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:32:38 --> Input Class Initialized
INFO - 2021-09-23 13:32:38 --> Language Class Initialized
INFO - 2021-09-23 13:32:38 --> Loader Class Initialized
INFO - 2021-09-23 13:32:38 --> Helper loaded: url_helper
INFO - 2021-09-23 13:32:38 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:32:38 --> Controller Class Initialized
INFO - 2021-09-23 13:32:38 --> Database Driver Class Initialized
INFO - 2021-09-23 13:32:38 --> Helper loaded: string_helper
INFO - 2021-09-23 13:32:38 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 13:32:38 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:32:38 --> Model "CookieModel" initialized
INFO - 2021-09-23 13:32:38 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 13:32:38 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/testimonials.php
INFO - 2021-09-23 13:32:38 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 13:32:38 --> Final output sent to browser
DEBUG - 2021-09-23 13:32:38 --> Total execution time: 0.0826
INFO - 2021-09-23 13:33:09 --> Config Class Initialized
INFO - 2021-09-23 13:33:09 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:33:09 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:33:09 --> Utf8 Class Initialized
INFO - 2021-09-23 13:33:09 --> URI Class Initialized
INFO - 2021-09-23 13:33:09 --> Router Class Initialized
INFO - 2021-09-23 13:33:09 --> Output Class Initialized
INFO - 2021-09-23 13:33:09 --> Security Class Initialized
DEBUG - 2021-09-23 13:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:33:09 --> Input Class Initialized
INFO - 2021-09-23 13:33:09 --> Language Class Initialized
INFO - 2021-09-23 13:33:09 --> Loader Class Initialized
INFO - 2021-09-23 13:33:09 --> Helper loaded: url_helper
INFO - 2021-09-23 13:33:09 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:33:09 --> Controller Class Initialized
INFO - 2021-09-23 13:33:09 --> Database Driver Class Initialized
INFO - 2021-09-23 13:33:09 --> Helper loaded: string_helper
INFO - 2021-09-23 13:33:09 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 13:33:09 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:33:09 --> Model "CookieModel" initialized
INFO - 2021-09-23 13:33:09 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 13:33:09 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/testimonials.php
INFO - 2021-09-23 13:33:09 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 13:33:09 --> Final output sent to browser
DEBUG - 2021-09-23 13:33:09 --> Total execution time: 0.0726
INFO - 2021-09-23 13:36:58 --> Config Class Initialized
INFO - 2021-09-23 13:36:58 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:36:58 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:36:58 --> Utf8 Class Initialized
INFO - 2021-09-23 13:36:58 --> URI Class Initialized
INFO - 2021-09-23 13:36:58 --> Router Class Initialized
INFO - 2021-09-23 13:36:58 --> Output Class Initialized
INFO - 2021-09-23 13:36:58 --> Security Class Initialized
DEBUG - 2021-09-23 13:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:36:58 --> Input Class Initialized
INFO - 2021-09-23 13:36:58 --> Language Class Initialized
INFO - 2021-09-23 13:36:58 --> Loader Class Initialized
INFO - 2021-09-23 13:36:58 --> Helper loaded: url_helper
INFO - 2021-09-23 13:36:58 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:36:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:36:58 --> Controller Class Initialized
INFO - 2021-09-23 13:36:58 --> Database Driver Class Initialized
INFO - 2021-09-23 13:36:58 --> Helper loaded: string_helper
INFO - 2021-09-23 13:36:58 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 13:36:58 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:36:58 --> Model "CookieModel" initialized
INFO - 2021-09-23 13:36:58 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 13:36:58 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/testimonials.php
INFO - 2021-09-23 13:36:58 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 13:36:58 --> Final output sent to browser
DEBUG - 2021-09-23 13:36:58 --> Total execution time: 0.0778
INFO - 2021-09-23 13:37:50 --> Config Class Initialized
INFO - 2021-09-23 13:37:50 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:37:50 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:37:50 --> Utf8 Class Initialized
INFO - 2021-09-23 13:37:50 --> URI Class Initialized
INFO - 2021-09-23 13:37:50 --> Router Class Initialized
INFO - 2021-09-23 13:37:50 --> Output Class Initialized
INFO - 2021-09-23 13:37:50 --> Security Class Initialized
DEBUG - 2021-09-23 13:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:37:50 --> Input Class Initialized
INFO - 2021-09-23 13:37:50 --> Language Class Initialized
ERROR - 2021-09-23 13:37:50 --> Severity: error --> Exception: syntax error, unexpected '$data' (T_VARIABLE) F:\xampp\htdocs\igapprojects\changeme\application\controllers\Testimonials.php 23
INFO - 2021-09-23 13:38:11 --> Config Class Initialized
INFO - 2021-09-23 13:38:11 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:38:11 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:38:11 --> Utf8 Class Initialized
INFO - 2021-09-23 13:38:11 --> URI Class Initialized
INFO - 2021-09-23 13:38:11 --> Router Class Initialized
INFO - 2021-09-23 13:38:11 --> Output Class Initialized
INFO - 2021-09-23 13:38:11 --> Security Class Initialized
DEBUG - 2021-09-23 13:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:38:11 --> Input Class Initialized
INFO - 2021-09-23 13:38:11 --> Language Class Initialized
ERROR - 2021-09-23 13:38:11 --> Severity: error --> Exception: syntax error, unexpected '$data' (T_VARIABLE) F:\xampp\htdocs\igapprojects\changeme\application\controllers\Testimonials.php 23
INFO - 2021-09-23 13:39:55 --> Config Class Initialized
INFO - 2021-09-23 13:39:55 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:39:55 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:39:55 --> Utf8 Class Initialized
INFO - 2021-09-23 13:39:55 --> URI Class Initialized
INFO - 2021-09-23 13:39:55 --> Router Class Initialized
INFO - 2021-09-23 13:39:55 --> Output Class Initialized
INFO - 2021-09-23 13:39:55 --> Security Class Initialized
DEBUG - 2021-09-23 13:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:39:55 --> Input Class Initialized
INFO - 2021-09-23 13:39:55 --> Language Class Initialized
ERROR - 2021-09-23 13:39:55 --> Severity: error --> Exception: syntax error, unexpected '$data' (T_VARIABLE) F:\xampp\htdocs\igapprojects\changeme\application\controllers\Testimonials.php 23
INFO - 2021-09-23 13:39:56 --> Config Class Initialized
INFO - 2021-09-23 13:39:56 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:39:56 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:39:56 --> Utf8 Class Initialized
INFO - 2021-09-23 13:39:56 --> URI Class Initialized
INFO - 2021-09-23 13:39:56 --> Router Class Initialized
INFO - 2021-09-23 13:39:56 --> Output Class Initialized
INFO - 2021-09-23 13:39:56 --> Security Class Initialized
DEBUG - 2021-09-23 13:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:39:56 --> Input Class Initialized
INFO - 2021-09-23 13:39:56 --> Language Class Initialized
ERROR - 2021-09-23 13:39:56 --> Severity: error --> Exception: syntax error, unexpected '$data' (T_VARIABLE) F:\xampp\htdocs\igapprojects\changeme\application\controllers\Testimonials.php 23
INFO - 2021-09-23 13:39:56 --> Config Class Initialized
INFO - 2021-09-23 13:39:56 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:39:56 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:39:56 --> Utf8 Class Initialized
INFO - 2021-09-23 13:39:56 --> URI Class Initialized
INFO - 2021-09-23 13:39:56 --> Router Class Initialized
INFO - 2021-09-23 13:39:56 --> Output Class Initialized
INFO - 2021-09-23 13:39:56 --> Security Class Initialized
DEBUG - 2021-09-23 13:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:39:56 --> Input Class Initialized
INFO - 2021-09-23 13:39:56 --> Language Class Initialized
ERROR - 2021-09-23 13:39:56 --> Severity: error --> Exception: syntax error, unexpected '$data' (T_VARIABLE) F:\xampp\htdocs\igapprojects\changeme\application\controllers\Testimonials.php 23
INFO - 2021-09-23 13:39:56 --> Config Class Initialized
INFO - 2021-09-23 13:39:56 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:39:56 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:39:56 --> Utf8 Class Initialized
INFO - 2021-09-23 13:39:56 --> URI Class Initialized
INFO - 2021-09-23 13:39:56 --> Router Class Initialized
INFO - 2021-09-23 13:39:56 --> Output Class Initialized
INFO - 2021-09-23 13:39:56 --> Security Class Initialized
DEBUG - 2021-09-23 13:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:39:56 --> Input Class Initialized
INFO - 2021-09-23 13:39:56 --> Language Class Initialized
ERROR - 2021-09-23 13:39:56 --> Severity: error --> Exception: syntax error, unexpected '$data' (T_VARIABLE) F:\xampp\htdocs\igapprojects\changeme\application\controllers\Testimonials.php 23
INFO - 2021-09-23 13:39:56 --> Config Class Initialized
INFO - 2021-09-23 13:39:56 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:39:56 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:39:56 --> Utf8 Class Initialized
INFO - 2021-09-23 13:39:56 --> URI Class Initialized
INFO - 2021-09-23 13:39:56 --> Router Class Initialized
INFO - 2021-09-23 13:39:56 --> Output Class Initialized
INFO - 2021-09-23 13:39:56 --> Security Class Initialized
DEBUG - 2021-09-23 13:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:39:56 --> Input Class Initialized
INFO - 2021-09-23 13:39:56 --> Language Class Initialized
ERROR - 2021-09-23 13:39:56 --> Severity: error --> Exception: syntax error, unexpected '$data' (T_VARIABLE) F:\xampp\htdocs\igapprojects\changeme\application\controllers\Testimonials.php 23
INFO - 2021-09-23 13:39:58 --> Config Class Initialized
INFO - 2021-09-23 13:39:58 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:39:58 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:39:58 --> Utf8 Class Initialized
INFO - 2021-09-23 13:39:58 --> URI Class Initialized
INFO - 2021-09-23 13:39:58 --> Router Class Initialized
INFO - 2021-09-23 13:39:58 --> Output Class Initialized
INFO - 2021-09-23 13:39:58 --> Security Class Initialized
DEBUG - 2021-09-23 13:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:39:58 --> Input Class Initialized
INFO - 2021-09-23 13:39:58 --> Language Class Initialized
ERROR - 2021-09-23 13:39:58 --> Severity: error --> Exception: syntax error, unexpected '$data' (T_VARIABLE) F:\xampp\htdocs\igapprojects\changeme\application\controllers\Testimonials.php 23
INFO - 2021-09-23 13:39:59 --> Config Class Initialized
INFO - 2021-09-23 13:39:59 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:39:59 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:39:59 --> Utf8 Class Initialized
INFO - 2021-09-23 13:39:59 --> URI Class Initialized
DEBUG - 2021-09-23 13:39:59 --> No URI present. Default controller set.
INFO - 2021-09-23 13:39:59 --> Router Class Initialized
INFO - 2021-09-23 13:39:59 --> Output Class Initialized
INFO - 2021-09-23 13:39:59 --> Security Class Initialized
DEBUG - 2021-09-23 13:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:39:59 --> Input Class Initialized
INFO - 2021-09-23 13:39:59 --> Language Class Initialized
INFO - 2021-09-23 13:39:59 --> Loader Class Initialized
INFO - 2021-09-23 13:39:59 --> Helper loaded: url_helper
INFO - 2021-09-23 13:39:59 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:39:59 --> Controller Class Initialized
INFO - 2021-09-23 13:39:59 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:39:59 --> Model "CookieModel" initialized
INFO - 2021-09-23 13:39:59 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 13:39:59 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/index.php
INFO - 2021-09-23 13:39:59 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 13:39:59 --> Final output sent to browser
DEBUG - 2021-09-23 13:39:59 --> Total execution time: 0.0552
INFO - 2021-09-23 13:40:02 --> Config Class Initialized
INFO - 2021-09-23 13:40:02 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:40:02 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:40:02 --> Utf8 Class Initialized
INFO - 2021-09-23 13:40:02 --> URI Class Initialized
INFO - 2021-09-23 13:40:02 --> Router Class Initialized
INFO - 2021-09-23 13:40:02 --> Output Class Initialized
INFO - 2021-09-23 13:40:02 --> Security Class Initialized
DEBUG - 2021-09-23 13:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:40:02 --> Input Class Initialized
INFO - 2021-09-23 13:40:02 --> Language Class Initialized
ERROR - 2021-09-23 13:40:02 --> Severity: error --> Exception: syntax error, unexpected '$data' (T_VARIABLE) F:\xampp\htdocs\igapprojects\changeme\application\controllers\Testimonials.php 23
INFO - 2021-09-23 13:40:33 --> Config Class Initialized
INFO - 2021-09-23 13:40:33 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:40:33 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:40:33 --> Utf8 Class Initialized
INFO - 2021-09-23 13:40:33 --> URI Class Initialized
INFO - 2021-09-23 13:40:33 --> Router Class Initialized
INFO - 2021-09-23 13:40:33 --> Output Class Initialized
INFO - 2021-09-23 13:40:33 --> Security Class Initialized
DEBUG - 2021-09-23 13:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:40:33 --> Input Class Initialized
INFO - 2021-09-23 13:40:33 --> Language Class Initialized
INFO - 2021-09-23 13:40:33 --> Loader Class Initialized
INFO - 2021-09-23 13:40:33 --> Helper loaded: url_helper
INFO - 2021-09-23 13:40:33 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:40:33 --> Controller Class Initialized
INFO - 2021-09-23 13:40:33 --> Database Driver Class Initialized
INFO - 2021-09-23 13:40:33 --> Helper loaded: string_helper
INFO - 2021-09-23 13:40:33 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 13:40:33 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:40:33 --> Model "CookieModel" initialized
INFO - 2021-09-23 13:40:33 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 13:40:33 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/testimonials.php
INFO - 2021-09-23 13:40:33 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 13:40:33 --> Final output sent to browser
DEBUG - 2021-09-23 13:40:33 --> Total execution time: 0.0714
INFO - 2021-09-23 13:40:36 --> Config Class Initialized
INFO - 2021-09-23 13:40:36 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:40:36 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:40:36 --> Utf8 Class Initialized
INFO - 2021-09-23 13:40:36 --> URI Class Initialized
INFO - 2021-09-23 13:40:36 --> Router Class Initialized
INFO - 2021-09-23 13:40:36 --> Output Class Initialized
INFO - 2021-09-23 13:40:36 --> Security Class Initialized
DEBUG - 2021-09-23 13:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:40:36 --> Input Class Initialized
INFO - 2021-09-23 13:40:36 --> Language Class Initialized
INFO - 2021-09-23 13:40:36 --> Loader Class Initialized
INFO - 2021-09-23 13:40:36 --> Helper loaded: url_helper
INFO - 2021-09-23 13:40:36 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:40:36 --> Controller Class Initialized
INFO - 2021-09-23 13:40:36 --> Database Driver Class Initialized
INFO - 2021-09-23 13:40:36 --> Helper loaded: string_helper
INFO - 2021-09-23 13:40:36 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 13:40:36 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:40:36 --> Model "CookieModel" initialized
INFO - 2021-09-23 13:40:36 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 13:40:36 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/testimonials.php
INFO - 2021-09-23 13:40:36 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 13:40:36 --> Final output sent to browser
DEBUG - 2021-09-23 13:40:36 --> Total execution time: 0.0693
INFO - 2021-09-23 13:41:40 --> Config Class Initialized
INFO - 2021-09-23 13:41:40 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:41:40 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:41:40 --> Utf8 Class Initialized
INFO - 2021-09-23 13:41:40 --> URI Class Initialized
INFO - 2021-09-23 13:41:40 --> Router Class Initialized
INFO - 2021-09-23 13:41:40 --> Output Class Initialized
INFO - 2021-09-23 13:41:40 --> Security Class Initialized
DEBUG - 2021-09-23 13:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:41:40 --> Input Class Initialized
INFO - 2021-09-23 13:41:40 --> Language Class Initialized
INFO - 2021-09-23 13:41:40 --> Loader Class Initialized
INFO - 2021-09-23 13:41:40 --> Helper loaded: url_helper
INFO - 2021-09-23 13:41:40 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:41:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:41:40 --> Controller Class Initialized
INFO - 2021-09-23 13:41:40 --> Database Driver Class Initialized
INFO - 2021-09-23 13:41:40 --> Helper loaded: string_helper
INFO - 2021-09-23 13:41:40 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 13:41:40 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:41:40 --> Model "CookieModel" initialized
ERROR - 2021-09-23 13:41:40 --> Severity: error --> Exception: Call to undefined method TestimonialModel::list() F:\xampp\htdocs\igapprojects\changeme\application\controllers\Testimonials.php 22
INFO - 2021-09-23 13:42:17 --> Config Class Initialized
INFO - 2021-09-23 13:42:17 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:42:17 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:42:17 --> Utf8 Class Initialized
INFO - 2021-09-23 13:42:17 --> URI Class Initialized
INFO - 2021-09-23 13:42:17 --> Router Class Initialized
INFO - 2021-09-23 13:42:17 --> Output Class Initialized
INFO - 2021-09-23 13:42:17 --> Security Class Initialized
DEBUG - 2021-09-23 13:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:42:17 --> Input Class Initialized
INFO - 2021-09-23 13:42:17 --> Language Class Initialized
INFO - 2021-09-23 13:42:17 --> Loader Class Initialized
INFO - 2021-09-23 13:42:17 --> Helper loaded: url_helper
INFO - 2021-09-23 13:42:17 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:42:17 --> Controller Class Initialized
INFO - 2021-09-23 13:42:17 --> Database Driver Class Initialized
INFO - 2021-09-23 13:42:17 --> Helper loaded: string_helper
INFO - 2021-09-23 13:42:17 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 13:42:17 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:42:17 --> Model "CookieModel" initialized
INFO - 2021-09-23 13:42:17 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 13:42:17 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/testimonials.php
INFO - 2021-09-23 13:42:17 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 13:42:17 --> Final output sent to browser
DEBUG - 2021-09-23 13:42:17 --> Total execution time: 0.0802
INFO - 2021-09-23 13:43:00 --> Config Class Initialized
INFO - 2021-09-23 13:43:00 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:43:00 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:43:00 --> Utf8 Class Initialized
INFO - 2021-09-23 13:43:00 --> URI Class Initialized
INFO - 2021-09-23 13:43:00 --> Router Class Initialized
INFO - 2021-09-23 13:43:00 --> Output Class Initialized
INFO - 2021-09-23 13:43:00 --> Security Class Initialized
DEBUG - 2021-09-23 13:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:43:00 --> Input Class Initialized
INFO - 2021-09-23 13:43:00 --> Language Class Initialized
INFO - 2021-09-23 13:43:00 --> Loader Class Initialized
INFO - 2021-09-23 13:43:00 --> Helper loaded: url_helper
INFO - 2021-09-23 13:43:00 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:43:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:43:00 --> Controller Class Initialized
INFO - 2021-09-23 13:43:00 --> Database Driver Class Initialized
INFO - 2021-09-23 13:43:00 --> Helper loaded: string_helper
INFO - 2021-09-23 13:43:00 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 13:43:00 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:43:00 --> Model "CookieModel" initialized
INFO - 2021-09-23 13:43:00 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 13:43:00 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/testimonials.php
INFO - 2021-09-23 13:43:00 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 13:43:00 --> Final output sent to browser
DEBUG - 2021-09-23 13:43:00 --> Total execution time: 0.0775
INFO - 2021-09-23 13:43:26 --> Config Class Initialized
INFO - 2021-09-23 13:43:26 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:43:26 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:43:26 --> Utf8 Class Initialized
INFO - 2021-09-23 13:43:26 --> URI Class Initialized
INFO - 2021-09-23 13:43:26 --> Router Class Initialized
INFO - 2021-09-23 13:43:26 --> Output Class Initialized
INFO - 2021-09-23 13:43:26 --> Security Class Initialized
DEBUG - 2021-09-23 13:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:43:26 --> Input Class Initialized
INFO - 2021-09-23 13:43:26 --> Language Class Initialized
INFO - 2021-09-23 13:43:26 --> Loader Class Initialized
INFO - 2021-09-23 13:43:26 --> Helper loaded: url_helper
INFO - 2021-09-23 13:43:26 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:43:26 --> Controller Class Initialized
INFO - 2021-09-23 13:43:26 --> Model "DBModel" initialized
DEBUG - 2021-09-23 13:43:26 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 13:43:26 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:43:26 --> Database Driver Class Initialized
INFO - 2021-09-23 13:43:26 --> Helper loaded: string_helper
INFO - 2021-09-23 13:43:26 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 13:43:26 --> Model "BlogModel" initialized
INFO - 2021-09-23 13:43:26 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-23 13:43:26 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-23 13:43:26 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-23 13:43:26 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/testimonials.php
INFO - 2021-09-23 13:43:26 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-23 13:43:26 --> Final output sent to browser
DEBUG - 2021-09-23 13:43:26 --> Total execution time: 0.0809
INFO - 2021-09-23 13:43:30 --> Config Class Initialized
INFO - 2021-09-23 13:43:30 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:43:30 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:43:30 --> Utf8 Class Initialized
INFO - 2021-09-23 13:43:30 --> URI Class Initialized
INFO - 2021-09-23 13:43:30 --> Router Class Initialized
INFO - 2021-09-23 13:43:30 --> Output Class Initialized
INFO - 2021-09-23 13:43:30 --> Security Class Initialized
DEBUG - 2021-09-23 13:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:43:30 --> Input Class Initialized
INFO - 2021-09-23 13:43:30 --> Language Class Initialized
INFO - 2021-09-23 13:43:30 --> Loader Class Initialized
INFO - 2021-09-23 13:43:30 --> Helper loaded: url_helper
INFO - 2021-09-23 13:43:30 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:43:30 --> Controller Class Initialized
INFO - 2021-09-23 13:43:30 --> Model "DBModel" initialized
DEBUG - 2021-09-23 13:43:30 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 13:43:30 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:43:30 --> Database Driver Class Initialized
INFO - 2021-09-23 13:43:30 --> Helper loaded: string_helper
INFO - 2021-09-23 13:43:30 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 13:43:30 --> Model "BlogModel" initialized
INFO - 2021-09-23 13:43:30 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-23 13:43:30 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-23 13:43:30 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-23 13:43:30 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/testimonial.php
INFO - 2021-09-23 13:43:30 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-23 13:43:30 --> Final output sent to browser
DEBUG - 2021-09-23 13:43:30 --> Total execution time: 0.0788
INFO - 2021-09-23 13:43:34 --> Config Class Initialized
INFO - 2021-09-23 13:43:34 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:43:34 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:43:34 --> Utf8 Class Initialized
INFO - 2021-09-23 13:43:34 --> URI Class Initialized
INFO - 2021-09-23 13:43:34 --> Router Class Initialized
INFO - 2021-09-23 13:43:34 --> Output Class Initialized
INFO - 2021-09-23 13:43:34 --> Security Class Initialized
DEBUG - 2021-09-23 13:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:43:34 --> Input Class Initialized
INFO - 2021-09-23 13:43:34 --> Language Class Initialized
INFO - 2021-09-23 13:43:34 --> Loader Class Initialized
INFO - 2021-09-23 13:43:34 --> Helper loaded: url_helper
INFO - 2021-09-23 13:43:34 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:43:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:43:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:43:34 --> Controller Class Initialized
INFO - 2021-09-23 13:43:34 --> Model "DBModel" initialized
DEBUG - 2021-09-23 13:43:34 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 13:43:34 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:43:34 --> Database Driver Class Initialized
INFO - 2021-09-23 13:43:34 --> Helper loaded: string_helper
INFO - 2021-09-23 13:43:34 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 13:43:34 --> Model "BlogModel" initialized
INFO - 2021-09-23 13:43:34 --> Config Class Initialized
INFO - 2021-09-23 13:43:34 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:43:34 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:43:34 --> Utf8 Class Initialized
INFO - 2021-09-23 13:43:34 --> URI Class Initialized
INFO - 2021-09-23 13:43:34 --> Router Class Initialized
INFO - 2021-09-23 13:43:34 --> Output Class Initialized
INFO - 2021-09-23 13:43:34 --> Security Class Initialized
DEBUG - 2021-09-23 13:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:43:34 --> Input Class Initialized
INFO - 2021-09-23 13:43:34 --> Language Class Initialized
INFO - 2021-09-23 13:43:34 --> Loader Class Initialized
INFO - 2021-09-23 13:43:34 --> Helper loaded: url_helper
INFO - 2021-09-23 13:43:34 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:43:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:43:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:43:34 --> Controller Class Initialized
INFO - 2021-09-23 13:43:34 --> Model "DBModel" initialized
DEBUG - 2021-09-23 13:43:34 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 13:43:34 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:43:34 --> Database Driver Class Initialized
INFO - 2021-09-23 13:43:34 --> Helper loaded: string_helper
INFO - 2021-09-23 13:43:34 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 13:43:34 --> Model "BlogModel" initialized
INFO - 2021-09-23 13:43:34 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-23 13:43:34 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-23 13:43:34 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-23 13:43:34 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/testimonials.php
INFO - 2021-09-23 13:43:34 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-23 13:43:34 --> Final output sent to browser
DEBUG - 2021-09-23 13:43:34 --> Total execution time: 0.0713
INFO - 2021-09-23 13:43:38 --> Config Class Initialized
INFO - 2021-09-23 13:43:38 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:43:38 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:43:38 --> Utf8 Class Initialized
INFO - 2021-09-23 13:43:38 --> URI Class Initialized
INFO - 2021-09-23 13:43:38 --> Router Class Initialized
INFO - 2021-09-23 13:43:38 --> Output Class Initialized
INFO - 2021-09-23 13:43:38 --> Security Class Initialized
DEBUG - 2021-09-23 13:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:43:38 --> Input Class Initialized
INFO - 2021-09-23 13:43:38 --> Language Class Initialized
INFO - 2021-09-23 13:43:38 --> Loader Class Initialized
INFO - 2021-09-23 13:43:38 --> Helper loaded: url_helper
INFO - 2021-09-23 13:43:38 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:43:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:43:38 --> Controller Class Initialized
INFO - 2021-09-23 13:43:38 --> Database Driver Class Initialized
INFO - 2021-09-23 13:43:38 --> Helper loaded: string_helper
INFO - 2021-09-23 13:43:38 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 13:43:38 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:43:38 --> Model "CookieModel" initialized
INFO - 2021-09-23 13:43:38 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 13:43:38 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/testimonials.php
INFO - 2021-09-23 13:43:38 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 13:43:38 --> Final output sent to browser
DEBUG - 2021-09-23 13:43:38 --> Total execution time: 0.0755
INFO - 2021-09-23 13:44:20 --> Config Class Initialized
INFO - 2021-09-23 13:44:20 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:44:20 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:44:20 --> Utf8 Class Initialized
INFO - 2021-09-23 13:44:20 --> URI Class Initialized
DEBUG - 2021-09-23 13:44:20 --> No URI present. Default controller set.
INFO - 2021-09-23 13:44:20 --> Router Class Initialized
INFO - 2021-09-23 13:44:20 --> Output Class Initialized
INFO - 2021-09-23 13:44:20 --> Security Class Initialized
DEBUG - 2021-09-23 13:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:44:20 --> Input Class Initialized
INFO - 2021-09-23 13:44:20 --> Language Class Initialized
INFO - 2021-09-23 13:44:20 --> Loader Class Initialized
INFO - 2021-09-23 13:44:20 --> Helper loaded: url_helper
INFO - 2021-09-23 13:44:20 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:44:20 --> Controller Class Initialized
INFO - 2021-09-23 13:44:20 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:44:20 --> Model "CookieModel" initialized
INFO - 2021-09-23 13:44:20 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 13:44:20 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/index.php
INFO - 2021-09-23 13:44:20 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 13:44:20 --> Final output sent to browser
DEBUG - 2021-09-23 13:44:20 --> Total execution time: 0.0510
INFO - 2021-09-23 13:49:40 --> Config Class Initialized
INFO - 2021-09-23 13:49:40 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:49:40 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:49:40 --> Utf8 Class Initialized
INFO - 2021-09-23 13:49:40 --> URI Class Initialized
INFO - 2021-09-23 13:49:40 --> Router Class Initialized
INFO - 2021-09-23 13:49:40 --> Output Class Initialized
INFO - 2021-09-23 13:49:40 --> Security Class Initialized
DEBUG - 2021-09-23 13:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:49:40 --> Input Class Initialized
INFO - 2021-09-23 13:49:40 --> Language Class Initialized
INFO - 2021-09-23 13:49:40 --> Loader Class Initialized
INFO - 2021-09-23 13:49:40 --> Helper loaded: url_helper
INFO - 2021-09-23 13:49:40 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:49:40 --> Controller Class Initialized
INFO - 2021-09-23 13:49:40 --> Model "DBModel" initialized
DEBUG - 2021-09-23 13:49:40 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 13:49:40 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:49:40 --> Database Driver Class Initialized
INFO - 2021-09-23 13:49:40 --> Helper loaded: string_helper
INFO - 2021-09-23 13:49:40 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 13:49:40 --> Model "BlogModel" initialized
INFO - 2021-09-23 13:49:40 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-23 13:49:40 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-23 13:49:40 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-23 13:49:40 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/testimonial.php
INFO - 2021-09-23 13:49:40 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-23 13:49:40 --> Final output sent to browser
DEBUG - 2021-09-23 13:49:40 --> Total execution time: 0.0812
INFO - 2021-09-23 13:49:54 --> Config Class Initialized
INFO - 2021-09-23 13:49:54 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:49:55 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:49:55 --> Utf8 Class Initialized
INFO - 2021-09-23 13:49:55 --> URI Class Initialized
INFO - 2021-09-23 13:49:55 --> Router Class Initialized
INFO - 2021-09-23 13:49:55 --> Output Class Initialized
INFO - 2021-09-23 13:49:55 --> Security Class Initialized
DEBUG - 2021-09-23 13:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:49:55 --> Input Class Initialized
INFO - 2021-09-23 13:49:55 --> Language Class Initialized
INFO - 2021-09-23 13:49:55 --> Loader Class Initialized
INFO - 2021-09-23 13:49:55 --> Helper loaded: url_helper
INFO - 2021-09-23 13:49:55 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:49:55 --> Controller Class Initialized
INFO - 2021-09-23 13:49:55 --> Model "DBModel" initialized
DEBUG - 2021-09-23 13:49:55 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 13:49:55 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:49:55 --> Database Driver Class Initialized
INFO - 2021-09-23 13:49:55 --> Helper loaded: string_helper
INFO - 2021-09-23 13:49:55 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 13:49:55 --> Model "BlogModel" initialized
INFO - 2021-09-23 13:49:55 --> Config Class Initialized
INFO - 2021-09-23 13:49:55 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:49:55 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:49:55 --> Utf8 Class Initialized
INFO - 2021-09-23 13:49:55 --> URI Class Initialized
INFO - 2021-09-23 13:49:55 --> Router Class Initialized
INFO - 2021-09-23 13:49:55 --> Output Class Initialized
INFO - 2021-09-23 13:49:55 --> Security Class Initialized
DEBUG - 2021-09-23 13:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:49:55 --> Input Class Initialized
INFO - 2021-09-23 13:49:55 --> Language Class Initialized
INFO - 2021-09-23 13:49:55 --> Loader Class Initialized
INFO - 2021-09-23 13:49:55 --> Helper loaded: url_helper
INFO - 2021-09-23 13:49:55 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:49:55 --> Controller Class Initialized
INFO - 2021-09-23 13:49:55 --> Model "DBModel" initialized
DEBUG - 2021-09-23 13:49:55 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-23 13:49:55 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:49:55 --> Database Driver Class Initialized
INFO - 2021-09-23 13:49:55 --> Helper loaded: string_helper
INFO - 2021-09-23 13:49:55 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 13:49:55 --> Model "BlogModel" initialized
INFO - 2021-09-23 13:49:55 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-23 13:49:55 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-23 13:49:55 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-23 13:49:55 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/testimonials.php
INFO - 2021-09-23 13:49:55 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-23 13:49:55 --> Final output sent to browser
DEBUG - 2021-09-23 13:49:55 --> Total execution time: 0.1431
INFO - 2021-09-23 13:49:55 --> Config Class Initialized
INFO - 2021-09-23 13:49:55 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:49:55 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:49:55 --> Utf8 Class Initialized
INFO - 2021-09-23 13:49:55 --> URI Class Initialized
INFO - 2021-09-23 13:49:55 --> Router Class Initialized
INFO - 2021-09-23 13:49:55 --> Output Class Initialized
INFO - 2021-09-23 13:49:55 --> Security Class Initialized
DEBUG - 2021-09-23 13:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:49:55 --> Input Class Initialized
INFO - 2021-09-23 13:49:55 --> Language Class Initialized
ERROR - 2021-09-23 13:49:55 --> 404 Page Not Found: Testimonialpics/.png
INFO - 2021-09-23 13:50:06 --> Config Class Initialized
INFO - 2021-09-23 13:50:06 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:50:06 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:50:06 --> Utf8 Class Initialized
INFO - 2021-09-23 13:50:06 --> URI Class Initialized
INFO - 2021-09-23 13:50:06 --> Router Class Initialized
INFO - 2021-09-23 13:50:06 --> Output Class Initialized
INFO - 2021-09-23 13:50:06 --> Security Class Initialized
DEBUG - 2021-09-23 13:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:50:06 --> Input Class Initialized
INFO - 2021-09-23 13:50:06 --> Language Class Initialized
INFO - 2021-09-23 13:50:06 --> Loader Class Initialized
INFO - 2021-09-23 13:50:06 --> Helper loaded: url_helper
INFO - 2021-09-23 13:50:06 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:50:06 --> Controller Class Initialized
INFO - 2021-09-23 13:50:06 --> Database Driver Class Initialized
INFO - 2021-09-23 13:50:06 --> Helper loaded: string_helper
INFO - 2021-09-23 13:50:06 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 13:50:06 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:50:06 --> Model "CookieModel" initialized
INFO - 2021-09-23 13:50:06 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 13:50:06 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/testimonials.php
INFO - 2021-09-23 13:50:06 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 13:50:06 --> Final output sent to browser
DEBUG - 2021-09-23 13:50:06 --> Total execution time: 0.0657
INFO - 2021-09-23 13:50:08 --> Config Class Initialized
INFO - 2021-09-23 13:50:08 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:50:08 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:50:08 --> Utf8 Class Initialized
INFO - 2021-09-23 13:50:08 --> URI Class Initialized
INFO - 2021-09-23 13:50:08 --> Router Class Initialized
INFO - 2021-09-23 13:50:08 --> Output Class Initialized
INFO - 2021-09-23 13:50:08 --> Security Class Initialized
DEBUG - 2021-09-23 13:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:50:08 --> Input Class Initialized
INFO - 2021-09-23 13:50:08 --> Language Class Initialized
INFO - 2021-09-23 13:50:08 --> Loader Class Initialized
INFO - 2021-09-23 13:50:08 --> Helper loaded: url_helper
INFO - 2021-09-23 13:50:08 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:50:08 --> Controller Class Initialized
INFO - 2021-09-23 13:50:08 --> Database Driver Class Initialized
INFO - 2021-09-23 13:50:08 --> Helper loaded: string_helper
INFO - 2021-09-23 13:50:08 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 13:50:08 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:50:08 --> Model "CookieModel" initialized
INFO - 2021-09-23 13:50:08 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 13:50:08 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/testimonials.php
INFO - 2021-09-23 13:50:08 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 13:50:08 --> Final output sent to browser
DEBUG - 2021-09-23 13:50:08 --> Total execution time: 0.0647
INFO - 2021-09-23 13:50:11 --> Config Class Initialized
INFO - 2021-09-23 13:50:11 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:50:11 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:50:11 --> Utf8 Class Initialized
INFO - 2021-09-23 13:50:11 --> URI Class Initialized
DEBUG - 2021-09-23 13:50:11 --> No URI present. Default controller set.
INFO - 2021-09-23 13:50:11 --> Router Class Initialized
INFO - 2021-09-23 13:50:11 --> Output Class Initialized
INFO - 2021-09-23 13:50:11 --> Security Class Initialized
DEBUG - 2021-09-23 13:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:50:11 --> Input Class Initialized
INFO - 2021-09-23 13:50:11 --> Language Class Initialized
INFO - 2021-09-23 13:50:11 --> Loader Class Initialized
INFO - 2021-09-23 13:50:11 --> Helper loaded: url_helper
INFO - 2021-09-23 13:50:11 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:50:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:50:11 --> Controller Class Initialized
INFO - 2021-09-23 13:50:11 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:50:11 --> Model "CookieModel" initialized
INFO - 2021-09-23 13:50:11 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 13:50:11 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/index.php
INFO - 2021-09-23 13:50:11 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 13:50:11 --> Final output sent to browser
DEBUG - 2021-09-23 13:50:11 --> Total execution time: 0.0533
INFO - 2021-09-23 13:50:54 --> Config Class Initialized
INFO - 2021-09-23 13:50:54 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:50:54 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:50:54 --> Utf8 Class Initialized
INFO - 2021-09-23 13:50:54 --> URI Class Initialized
DEBUG - 2021-09-23 13:50:54 --> No URI present. Default controller set.
INFO - 2021-09-23 13:50:54 --> Router Class Initialized
INFO - 2021-09-23 13:50:54 --> Output Class Initialized
INFO - 2021-09-23 13:50:54 --> Security Class Initialized
DEBUG - 2021-09-23 13:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:50:54 --> Input Class Initialized
INFO - 2021-09-23 13:50:54 --> Language Class Initialized
INFO - 2021-09-23 13:50:54 --> Loader Class Initialized
INFO - 2021-09-23 13:50:54 --> Helper loaded: url_helper
INFO - 2021-09-23 13:50:54 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:50:54 --> Controller Class Initialized
INFO - 2021-09-23 13:50:54 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:50:54 --> Model "CookieModel" initialized
INFO - 2021-09-23 13:50:54 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 13:50:54 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/index.php
INFO - 2021-09-23 13:50:54 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 13:50:54 --> Final output sent to browser
DEBUG - 2021-09-23 13:50:54 --> Total execution time: 0.0512
INFO - 2021-09-23 13:50:56 --> Config Class Initialized
INFO - 2021-09-23 13:50:56 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:50:56 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:50:56 --> Utf8 Class Initialized
INFO - 2021-09-23 13:50:56 --> URI Class Initialized
INFO - 2021-09-23 13:50:56 --> Router Class Initialized
INFO - 2021-09-23 13:50:56 --> Output Class Initialized
INFO - 2021-09-23 13:50:56 --> Security Class Initialized
DEBUG - 2021-09-23 13:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:50:56 --> Input Class Initialized
INFO - 2021-09-23 13:50:56 --> Language Class Initialized
INFO - 2021-09-23 13:50:56 --> Loader Class Initialized
INFO - 2021-09-23 13:50:56 --> Helper loaded: url_helper
INFO - 2021-09-23 13:50:56 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:50:56 --> Controller Class Initialized
INFO - 2021-09-23 13:50:56 --> Database Driver Class Initialized
INFO - 2021-09-23 13:50:56 --> Helper loaded: string_helper
INFO - 2021-09-23 13:50:56 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 13:50:56 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:50:56 --> Model "CookieModel" initialized
INFO - 2021-09-23 13:50:56 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 13:50:56 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/videotestimonials.php
INFO - 2021-09-23 13:50:56 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 13:50:56 --> Final output sent to browser
DEBUG - 2021-09-23 13:50:56 --> Total execution time: 0.0674
INFO - 2021-09-23 13:51:04 --> Config Class Initialized
INFO - 2021-09-23 13:51:04 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:51:04 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:51:04 --> Utf8 Class Initialized
INFO - 2021-09-23 13:51:04 --> URI Class Initialized
INFO - 2021-09-23 13:51:04 --> Router Class Initialized
INFO - 2021-09-23 13:51:04 --> Output Class Initialized
INFO - 2021-09-23 13:51:04 --> Security Class Initialized
DEBUG - 2021-09-23 13:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:51:04 --> Input Class Initialized
INFO - 2021-09-23 13:51:04 --> Language Class Initialized
INFO - 2021-09-23 13:51:04 --> Loader Class Initialized
INFO - 2021-09-23 13:51:04 --> Helper loaded: url_helper
INFO - 2021-09-23 13:51:04 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:51:04 --> Controller Class Initialized
INFO - 2021-09-23 13:51:04 --> Database Driver Class Initialized
INFO - 2021-09-23 13:51:04 --> Helper loaded: string_helper
INFO - 2021-09-23 13:51:04 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 13:51:04 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:51:04 --> Model "CookieModel" initialized
INFO - 2021-09-23 13:51:04 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 13:51:04 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/testimonials.php
INFO - 2021-09-23 13:51:04 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 13:51:04 --> Final output sent to browser
DEBUG - 2021-09-23 13:51:04 --> Total execution time: 0.0696
INFO - 2021-09-23 13:51:08 --> Config Class Initialized
INFO - 2021-09-23 13:51:08 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:51:08 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:51:08 --> Utf8 Class Initialized
INFO - 2021-09-23 13:51:08 --> URI Class Initialized
INFO - 2021-09-23 13:51:08 --> Router Class Initialized
INFO - 2021-09-23 13:51:08 --> Output Class Initialized
INFO - 2021-09-23 13:51:08 --> Security Class Initialized
DEBUG - 2021-09-23 13:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:51:08 --> Input Class Initialized
INFO - 2021-09-23 13:51:08 --> Language Class Initialized
INFO - 2021-09-23 13:51:08 --> Loader Class Initialized
INFO - 2021-09-23 13:51:08 --> Helper loaded: url_helper
INFO - 2021-09-23 13:51:08 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:51:08 --> Controller Class Initialized
INFO - 2021-09-23 13:51:08 --> Database Driver Class Initialized
INFO - 2021-09-23 13:51:08 --> Helper loaded: string_helper
INFO - 2021-09-23 13:51:08 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 13:51:08 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:51:08 --> Model "CookieModel" initialized
INFO - 2021-09-23 13:51:08 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 13:51:08 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/videotestimonials.php
INFO - 2021-09-23 13:51:08 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 13:51:08 --> Final output sent to browser
DEBUG - 2021-09-23 13:51:08 --> Total execution time: 0.0659
INFO - 2021-09-23 13:55:08 --> Config Class Initialized
INFO - 2021-09-23 13:55:08 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:55:08 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:55:08 --> Utf8 Class Initialized
INFO - 2021-09-23 13:55:08 --> URI Class Initialized
INFO - 2021-09-23 13:55:08 --> Router Class Initialized
INFO - 2021-09-23 13:55:08 --> Output Class Initialized
INFO - 2021-09-23 13:55:08 --> Security Class Initialized
DEBUG - 2021-09-23 13:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:55:08 --> Input Class Initialized
INFO - 2021-09-23 13:55:08 --> Language Class Initialized
INFO - 2021-09-23 13:55:08 --> Loader Class Initialized
INFO - 2021-09-23 13:55:08 --> Helper loaded: url_helper
INFO - 2021-09-23 13:55:08 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:55:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:55:08 --> Controller Class Initialized
INFO - 2021-09-23 13:55:09 --> Database Driver Class Initialized
INFO - 2021-09-23 13:55:09 --> Helper loaded: string_helper
INFO - 2021-09-23 13:55:09 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 13:55:09 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:55:09 --> Model "CookieModel" initialized
INFO - 2021-09-23 13:55:09 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 13:55:09 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/videotestimonials.php
INFO - 2021-09-23 13:55:09 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 13:55:09 --> Final output sent to browser
DEBUG - 2021-09-23 13:55:09 --> Total execution time: 0.4499
INFO - 2021-09-23 13:55:10 --> Config Class Initialized
INFO - 2021-09-23 13:55:10 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:55:10 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:55:10 --> Utf8 Class Initialized
INFO - 2021-09-23 13:55:10 --> URI Class Initialized
INFO - 2021-09-23 13:55:10 --> Router Class Initialized
INFO - 2021-09-23 13:55:10 --> Output Class Initialized
INFO - 2021-09-23 13:55:10 --> Security Class Initialized
DEBUG - 2021-09-23 13:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:55:10 --> Input Class Initialized
INFO - 2021-09-23 13:55:10 --> Language Class Initialized
INFO - 2021-09-23 13:55:10 --> Loader Class Initialized
INFO - 2021-09-23 13:55:10 --> Helper loaded: url_helper
INFO - 2021-09-23 13:55:10 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:55:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:55:10 --> Controller Class Initialized
INFO - 2021-09-23 13:55:10 --> Database Driver Class Initialized
INFO - 2021-09-23 13:55:10 --> Helper loaded: string_helper
INFO - 2021-09-23 13:55:10 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 13:55:10 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:55:10 --> Model "CookieModel" initialized
INFO - 2021-09-23 13:55:10 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 13:55:10 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/testimonials.php
INFO - 2021-09-23 13:55:10 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 13:55:10 --> Final output sent to browser
DEBUG - 2021-09-23 13:55:10 --> Total execution time: 0.0647
INFO - 2021-09-23 13:55:12 --> Config Class Initialized
INFO - 2021-09-23 13:55:12 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:55:12 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:55:12 --> Utf8 Class Initialized
INFO - 2021-09-23 13:55:12 --> URI Class Initialized
INFO - 2021-09-23 13:55:12 --> Router Class Initialized
INFO - 2021-09-23 13:55:12 --> Output Class Initialized
INFO - 2021-09-23 13:55:12 --> Security Class Initialized
DEBUG - 2021-09-23 13:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:55:12 --> Input Class Initialized
INFO - 2021-09-23 13:55:12 --> Language Class Initialized
INFO - 2021-09-23 13:55:12 --> Loader Class Initialized
INFO - 2021-09-23 13:55:12 --> Helper loaded: url_helper
INFO - 2021-09-23 13:55:12 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:55:12 --> Controller Class Initialized
INFO - 2021-09-23 13:55:12 --> Database Driver Class Initialized
INFO - 2021-09-23 13:55:12 --> Helper loaded: string_helper
INFO - 2021-09-23 13:55:12 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 13:55:12 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:55:12 --> Model "CookieModel" initialized
INFO - 2021-09-23 13:55:12 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 13:55:12 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/testimonials.php
INFO - 2021-09-23 13:55:12 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 13:55:12 --> Final output sent to browser
DEBUG - 2021-09-23 13:55:12 --> Total execution time: 0.0879
INFO - 2021-09-23 13:55:14 --> Config Class Initialized
INFO - 2021-09-23 13:55:14 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:55:14 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:55:14 --> Utf8 Class Initialized
INFO - 2021-09-23 13:55:14 --> URI Class Initialized
INFO - 2021-09-23 13:55:14 --> Router Class Initialized
INFO - 2021-09-23 13:55:14 --> Output Class Initialized
INFO - 2021-09-23 13:55:14 --> Security Class Initialized
DEBUG - 2021-09-23 13:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:55:14 --> Input Class Initialized
INFO - 2021-09-23 13:55:14 --> Language Class Initialized
INFO - 2021-09-23 13:55:14 --> Loader Class Initialized
INFO - 2021-09-23 13:55:14 --> Helper loaded: url_helper
INFO - 2021-09-23 13:55:14 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:55:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:55:14 --> Controller Class Initialized
INFO - 2021-09-23 13:55:14 --> Database Driver Class Initialized
INFO - 2021-09-23 13:55:14 --> Helper loaded: string_helper
INFO - 2021-09-23 13:55:14 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 13:55:14 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:55:14 --> Model "CookieModel" initialized
INFO - 2021-09-23 13:55:14 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 13:55:14 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/testimonials.php
INFO - 2021-09-23 13:55:14 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 13:55:14 --> Final output sent to browser
DEBUG - 2021-09-23 13:55:14 --> Total execution time: 0.0763
INFO - 2021-09-23 13:55:15 --> Config Class Initialized
INFO - 2021-09-23 13:55:15 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:55:15 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:55:15 --> Utf8 Class Initialized
INFO - 2021-09-23 13:55:15 --> URI Class Initialized
INFO - 2021-09-23 13:55:15 --> Router Class Initialized
INFO - 2021-09-23 13:55:15 --> Output Class Initialized
INFO - 2021-09-23 13:55:15 --> Security Class Initialized
DEBUG - 2021-09-23 13:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:55:15 --> Input Class Initialized
INFO - 2021-09-23 13:55:15 --> Language Class Initialized
INFO - 2021-09-23 13:55:15 --> Loader Class Initialized
INFO - 2021-09-23 13:55:15 --> Helper loaded: url_helper
INFO - 2021-09-23 13:55:15 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:55:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:55:15 --> Controller Class Initialized
INFO - 2021-09-23 13:55:15 --> Database Driver Class Initialized
INFO - 2021-09-23 13:55:15 --> Helper loaded: string_helper
INFO - 2021-09-23 13:55:15 --> Model "TestimonialModel" initialized
INFO - 2021-09-23 13:55:15 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:55:15 --> Model "CookieModel" initialized
INFO - 2021-09-23 13:55:15 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 13:55:15 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/videotestimonials.php
INFO - 2021-09-23 13:55:15 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 13:55:15 --> Final output sent to browser
DEBUG - 2021-09-23 13:55:15 --> Total execution time: 0.0654
INFO - 2021-09-23 13:55:29 --> Config Class Initialized
INFO - 2021-09-23 13:55:29 --> Hooks Class Initialized
DEBUG - 2021-09-23 13:55:29 --> UTF-8 Support Enabled
INFO - 2021-09-23 13:55:29 --> Utf8 Class Initialized
INFO - 2021-09-23 13:55:29 --> URI Class Initialized
INFO - 2021-09-23 13:55:29 --> Router Class Initialized
INFO - 2021-09-23 13:55:29 --> Output Class Initialized
INFO - 2021-09-23 13:55:29 --> Security Class Initialized
DEBUG - 2021-09-23 13:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-23 13:55:29 --> Input Class Initialized
INFO - 2021-09-23 13:55:29 --> Language Class Initialized
INFO - 2021-09-23 13:55:29 --> Loader Class Initialized
INFO - 2021-09-23 13:55:29 --> Helper loaded: url_helper
INFO - 2021-09-23 13:55:29 --> Helper loaded: file_helper
DEBUG - 2021-09-23 13:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-23 13:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-23 13:55:29 --> Controller Class Initialized
INFO - 2021-09-23 13:55:29 --> Helper loaded: cookie_helper
INFO - 2021-09-23 13:55:29 --> Model "CookieModel" initialized
INFO - 2021-09-23 13:55:29 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-23 13:55:29 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/team.php
INFO - 2021-09-23 13:55:29 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-23 13:55:29 --> Final output sent to browser
DEBUG - 2021-09-23 13:55:29 --> Total execution time: 0.0700
