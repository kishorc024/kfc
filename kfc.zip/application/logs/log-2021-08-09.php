<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-08-09 10:48:35 --> Config Class Initialized
INFO - 2021-08-09 10:48:35 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:48:36 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:48:36 --> Utf8 Class Initialized
INFO - 2021-08-09 10:48:36 --> URI Class Initialized
DEBUG - 2021-08-09 10:48:36 --> No URI present. Default controller set.
INFO - 2021-08-09 10:48:36 --> Router Class Initialized
INFO - 2021-08-09 10:48:36 --> Output Class Initialized
INFO - 2021-08-09 10:48:36 --> Security Class Initialized
DEBUG - 2021-08-09 10:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:48:36 --> Input Class Initialized
INFO - 2021-08-09 10:48:36 --> Language Class Initialized
INFO - 2021-08-09 10:48:36 --> Loader Class Initialized
INFO - 2021-08-09 10:48:36 --> Helper loaded: url_helper
INFO - 2021-08-09 10:48:36 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:48:36 --> Controller Class Initialized
INFO - 2021-08-09 10:48:36 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:48:36 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:48:36 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:48:36 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-09 10:48:36 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:48:36 --> Final output sent to browser
DEBUG - 2021-08-09 10:48:36 --> Total execution time: 0.0762
INFO - 2021-08-09 10:48:38 --> Config Class Initialized
INFO - 2021-08-09 10:48:38 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:48:38 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:48:38 --> Utf8 Class Initialized
INFO - 2021-08-09 10:48:38 --> URI Class Initialized
INFO - 2021-08-09 10:48:38 --> Router Class Initialized
INFO - 2021-08-09 10:48:38 --> Output Class Initialized
INFO - 2021-08-09 10:48:38 --> Security Class Initialized
DEBUG - 2021-08-09 10:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:48:38 --> Input Class Initialized
INFO - 2021-08-09 10:48:38 --> Language Class Initialized
INFO - 2021-08-09 10:48:38 --> Loader Class Initialized
INFO - 2021-08-09 10:48:38 --> Helper loaded: url_helper
INFO - 2021-08-09 10:48:38 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:48:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:48:38 --> Controller Class Initialized
INFO - 2021-08-09 10:48:38 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:48:38 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:48:38 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:48:38 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-09 10:48:38 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:48:38 --> Final output sent to browser
DEBUG - 2021-08-09 10:48:38 --> Total execution time: 0.0509
INFO - 2021-08-09 10:48:42 --> Config Class Initialized
INFO - 2021-08-09 10:48:42 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:48:42 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:48:42 --> Utf8 Class Initialized
INFO - 2021-08-09 10:48:42 --> URI Class Initialized
INFO - 2021-08-09 10:48:42 --> Router Class Initialized
INFO - 2021-08-09 10:48:42 --> Output Class Initialized
INFO - 2021-08-09 10:48:42 --> Security Class Initialized
DEBUG - 2021-08-09 10:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:48:42 --> Input Class Initialized
INFO - 2021-08-09 10:48:42 --> Language Class Initialized
INFO - 2021-08-09 10:48:42 --> Loader Class Initialized
INFO - 2021-08-09 10:48:42 --> Helper loaded: url_helper
INFO - 2021-08-09 10:48:42 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:48:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:48:42 --> Controller Class Initialized
INFO - 2021-08-09 10:48:42 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:48:42 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:48:42 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:48:42 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-09 10:48:42 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:48:42 --> Final output sent to browser
DEBUG - 2021-08-09 10:48:42 --> Total execution time: 0.0479
INFO - 2021-08-09 10:48:45 --> Config Class Initialized
INFO - 2021-08-09 10:48:45 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:48:45 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:48:45 --> Utf8 Class Initialized
INFO - 2021-08-09 10:48:45 --> URI Class Initialized
DEBUG - 2021-08-09 10:48:45 --> No URI present. Default controller set.
INFO - 2021-08-09 10:48:45 --> Router Class Initialized
INFO - 2021-08-09 10:48:45 --> Output Class Initialized
INFO - 2021-08-09 10:48:45 --> Security Class Initialized
DEBUG - 2021-08-09 10:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:48:45 --> Input Class Initialized
INFO - 2021-08-09 10:48:45 --> Language Class Initialized
INFO - 2021-08-09 10:48:45 --> Loader Class Initialized
INFO - 2021-08-09 10:48:45 --> Helper loaded: url_helper
INFO - 2021-08-09 10:48:45 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:48:45 --> Controller Class Initialized
INFO - 2021-08-09 10:48:45 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:48:45 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:48:45 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:48:45 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-09 10:48:45 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:48:45 --> Final output sent to browser
DEBUG - 2021-08-09 10:48:45 --> Total execution time: 0.0490
INFO - 2021-08-09 10:48:46 --> Config Class Initialized
INFO - 2021-08-09 10:48:46 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:48:46 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:48:46 --> Utf8 Class Initialized
INFO - 2021-08-09 10:48:46 --> URI Class Initialized
INFO - 2021-08-09 10:48:46 --> Router Class Initialized
INFO - 2021-08-09 10:48:46 --> Output Class Initialized
INFO - 2021-08-09 10:48:46 --> Security Class Initialized
DEBUG - 2021-08-09 10:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:48:46 --> Input Class Initialized
INFO - 2021-08-09 10:48:46 --> Language Class Initialized
INFO - 2021-08-09 10:48:46 --> Loader Class Initialized
INFO - 2021-08-09 10:48:47 --> Helper loaded: url_helper
INFO - 2021-08-09 10:48:47 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:48:47 --> Controller Class Initialized
INFO - 2021-08-09 10:48:47 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:48:47 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:48:47 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:48:47 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/pilates.php
INFO - 2021-08-09 10:48:47 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:48:47 --> Final output sent to browser
DEBUG - 2021-08-09 10:48:47 --> Total execution time: 0.0359
INFO - 2021-08-09 10:48:49 --> Config Class Initialized
INFO - 2021-08-09 10:48:49 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:48:49 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:48:49 --> Utf8 Class Initialized
INFO - 2021-08-09 10:48:49 --> URI Class Initialized
DEBUG - 2021-08-09 10:48:49 --> No URI present. Default controller set.
INFO - 2021-08-09 10:48:49 --> Router Class Initialized
INFO - 2021-08-09 10:48:49 --> Output Class Initialized
INFO - 2021-08-09 10:48:49 --> Security Class Initialized
DEBUG - 2021-08-09 10:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:48:49 --> Input Class Initialized
INFO - 2021-08-09 10:48:49 --> Language Class Initialized
INFO - 2021-08-09 10:48:49 --> Loader Class Initialized
INFO - 2021-08-09 10:48:49 --> Helper loaded: url_helper
INFO - 2021-08-09 10:48:49 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:48:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:48:49 --> Controller Class Initialized
INFO - 2021-08-09 10:48:49 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:48:49 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:48:49 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:48:49 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-09 10:48:49 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:48:49 --> Final output sent to browser
DEBUG - 2021-08-09 10:48:49 --> Total execution time: 0.0388
INFO - 2021-08-09 10:48:50 --> Config Class Initialized
INFO - 2021-08-09 10:48:50 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:48:50 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:48:50 --> Utf8 Class Initialized
INFO - 2021-08-09 10:48:50 --> URI Class Initialized
INFO - 2021-08-09 10:48:50 --> Router Class Initialized
INFO - 2021-08-09 10:48:50 --> Output Class Initialized
INFO - 2021-08-09 10:48:50 --> Security Class Initialized
DEBUG - 2021-08-09 10:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:48:50 --> Input Class Initialized
INFO - 2021-08-09 10:48:50 --> Language Class Initialized
INFO - 2021-08-09 10:48:50 --> Loader Class Initialized
INFO - 2021-08-09 10:48:50 --> Helper loaded: url_helper
INFO - 2021-08-09 10:48:50 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:48:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:48:50 --> Controller Class Initialized
INFO - 2021-08-09 10:48:50 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:48:50 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:48:50 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:48:50 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/pilates.php
INFO - 2021-08-09 10:48:50 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:48:50 --> Final output sent to browser
DEBUG - 2021-08-09 10:48:50 --> Total execution time: 0.0380
INFO - 2021-08-09 10:49:13 --> Config Class Initialized
INFO - 2021-08-09 10:49:13 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:49:13 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:49:13 --> Utf8 Class Initialized
INFO - 2021-08-09 10:49:13 --> URI Class Initialized
INFO - 2021-08-09 10:49:13 --> Router Class Initialized
INFO - 2021-08-09 10:49:13 --> Output Class Initialized
INFO - 2021-08-09 10:49:13 --> Security Class Initialized
DEBUG - 2021-08-09 10:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:49:13 --> Input Class Initialized
INFO - 2021-08-09 10:49:13 --> Language Class Initialized
INFO - 2021-08-09 10:49:13 --> Loader Class Initialized
INFO - 2021-08-09 10:49:13 --> Helper loaded: url_helper
INFO - 2021-08-09 10:49:13 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:49:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:49:13 --> Controller Class Initialized
INFO - 2021-08-09 10:49:13 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:49:13 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:49:13 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:49:13 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/pilates.php
INFO - 2021-08-09 10:49:13 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:49:13 --> Final output sent to browser
DEBUG - 2021-08-09 10:49:13 --> Total execution time: 0.0574
INFO - 2021-08-09 10:49:15 --> Config Class Initialized
INFO - 2021-08-09 10:49:15 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:49:15 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:49:15 --> Utf8 Class Initialized
INFO - 2021-08-09 10:49:15 --> URI Class Initialized
INFO - 2021-08-09 10:49:15 --> Router Class Initialized
INFO - 2021-08-09 10:49:15 --> Output Class Initialized
INFO - 2021-08-09 10:49:15 --> Security Class Initialized
DEBUG - 2021-08-09 10:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:49:15 --> Input Class Initialized
INFO - 2021-08-09 10:49:15 --> Language Class Initialized
INFO - 2021-08-09 10:49:15 --> Loader Class Initialized
INFO - 2021-08-09 10:49:15 --> Helper loaded: url_helper
INFO - 2021-08-09 10:49:15 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:49:15 --> Controller Class Initialized
INFO - 2021-08-09 10:49:15 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:49:15 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:49:15 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:49:15 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/pilates.php
INFO - 2021-08-09 10:49:15 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:49:15 --> Final output sent to browser
DEBUG - 2021-08-09 10:49:15 --> Total execution time: 0.0425
INFO - 2021-08-09 10:49:22 --> Config Class Initialized
INFO - 2021-08-09 10:49:22 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:49:22 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:49:22 --> Utf8 Class Initialized
INFO - 2021-08-09 10:49:22 --> URI Class Initialized
INFO - 2021-08-09 10:49:22 --> Router Class Initialized
INFO - 2021-08-09 10:49:22 --> Output Class Initialized
INFO - 2021-08-09 10:49:22 --> Security Class Initialized
DEBUG - 2021-08-09 10:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:49:22 --> Input Class Initialized
INFO - 2021-08-09 10:49:22 --> Language Class Initialized
INFO - 2021-08-09 10:49:22 --> Loader Class Initialized
INFO - 2021-08-09 10:49:22 --> Helper loaded: url_helper
INFO - 2021-08-09 10:49:22 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:49:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:49:22 --> Controller Class Initialized
INFO - 2021-08-09 10:49:22 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:49:22 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:49:22 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:49:22 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/pilates.php
INFO - 2021-08-09 10:49:22 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:49:22 --> Final output sent to browser
DEBUG - 2021-08-09 10:49:22 --> Total execution time: 0.0397
INFO - 2021-08-09 10:49:29 --> Config Class Initialized
INFO - 2021-08-09 10:49:29 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:49:29 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:49:29 --> Utf8 Class Initialized
INFO - 2021-08-09 10:49:29 --> URI Class Initialized
DEBUG - 2021-08-09 10:49:29 --> No URI present. Default controller set.
INFO - 2021-08-09 10:49:29 --> Router Class Initialized
INFO - 2021-08-09 10:49:29 --> Output Class Initialized
INFO - 2021-08-09 10:49:29 --> Security Class Initialized
DEBUG - 2021-08-09 10:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:49:29 --> Input Class Initialized
INFO - 2021-08-09 10:49:29 --> Language Class Initialized
INFO - 2021-08-09 10:49:29 --> Loader Class Initialized
INFO - 2021-08-09 10:49:29 --> Helper loaded: url_helper
INFO - 2021-08-09 10:49:29 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:49:29 --> Controller Class Initialized
INFO - 2021-08-09 10:49:29 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:49:29 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:49:29 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:49:29 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-09 10:49:29 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:49:29 --> Final output sent to browser
DEBUG - 2021-08-09 10:49:29 --> Total execution time: 0.0547
INFO - 2021-08-09 10:50:03 --> Config Class Initialized
INFO - 2021-08-09 10:50:03 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:50:03 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:50:03 --> Utf8 Class Initialized
INFO - 2021-08-09 10:50:03 --> URI Class Initialized
INFO - 2021-08-09 10:50:03 --> Router Class Initialized
INFO - 2021-08-09 10:50:03 --> Output Class Initialized
INFO - 2021-08-09 10:50:03 --> Security Class Initialized
DEBUG - 2021-08-09 10:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:50:03 --> Input Class Initialized
INFO - 2021-08-09 10:50:03 --> Language Class Initialized
INFO - 2021-08-09 10:50:03 --> Loader Class Initialized
INFO - 2021-08-09 10:50:03 --> Helper loaded: url_helper
INFO - 2021-08-09 10:50:03 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:50:03 --> Controller Class Initialized
INFO - 2021-08-09 10:50:03 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:50:03 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:50:03 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:50:03 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/pilates.php
INFO - 2021-08-09 10:50:03 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:50:03 --> Final output sent to browser
DEBUG - 2021-08-09 10:50:03 --> Total execution time: 0.0443
INFO - 2021-08-09 10:50:14 --> Config Class Initialized
INFO - 2021-08-09 10:50:14 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:50:14 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:50:14 --> Utf8 Class Initialized
INFO - 2021-08-09 10:50:14 --> URI Class Initialized
INFO - 2021-08-09 10:50:14 --> Router Class Initialized
INFO - 2021-08-09 10:50:14 --> Output Class Initialized
INFO - 2021-08-09 10:50:14 --> Security Class Initialized
DEBUG - 2021-08-09 10:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:50:14 --> Input Class Initialized
INFO - 2021-08-09 10:50:14 --> Language Class Initialized
INFO - 2021-08-09 10:50:14 --> Loader Class Initialized
INFO - 2021-08-09 10:50:14 --> Helper loaded: url_helper
INFO - 2021-08-09 10:50:14 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:50:14 --> Controller Class Initialized
INFO - 2021-08-09 10:50:14 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:50:14 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:50:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:50:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/pilates.php
INFO - 2021-08-09 10:50:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:50:14 --> Final output sent to browser
DEBUG - 2021-08-09 10:50:14 --> Total execution time: 0.0365
INFO - 2021-08-09 10:50:18 --> Config Class Initialized
INFO - 2021-08-09 10:50:18 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:50:18 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:50:18 --> Utf8 Class Initialized
INFO - 2021-08-09 10:50:18 --> URI Class Initialized
INFO - 2021-08-09 10:50:18 --> Router Class Initialized
INFO - 2021-08-09 10:50:18 --> Output Class Initialized
INFO - 2021-08-09 10:50:18 --> Security Class Initialized
DEBUG - 2021-08-09 10:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:50:18 --> Input Class Initialized
INFO - 2021-08-09 10:50:18 --> Language Class Initialized
INFO - 2021-08-09 10:50:18 --> Loader Class Initialized
INFO - 2021-08-09 10:50:18 --> Helper loaded: url_helper
INFO - 2021-08-09 10:50:18 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:50:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:50:18 --> Controller Class Initialized
INFO - 2021-08-09 10:50:18 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:50:18 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:50:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:50:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/pilates.php
INFO - 2021-08-09 10:50:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:50:18 --> Final output sent to browser
DEBUG - 2021-08-09 10:50:18 --> Total execution time: 0.0670
INFO - 2021-08-09 10:50:24 --> Config Class Initialized
INFO - 2021-08-09 10:50:24 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:50:24 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:50:24 --> Utf8 Class Initialized
INFO - 2021-08-09 10:50:24 --> URI Class Initialized
INFO - 2021-08-09 10:50:24 --> Router Class Initialized
INFO - 2021-08-09 10:50:24 --> Output Class Initialized
INFO - 2021-08-09 10:50:24 --> Security Class Initialized
DEBUG - 2021-08-09 10:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:50:24 --> Input Class Initialized
INFO - 2021-08-09 10:50:24 --> Language Class Initialized
INFO - 2021-08-09 10:50:24 --> Loader Class Initialized
INFO - 2021-08-09 10:50:24 --> Helper loaded: url_helper
INFO - 2021-08-09 10:50:24 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:50:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:50:24 --> Controller Class Initialized
INFO - 2021-08-09 10:50:24 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:50:24 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:50:24 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:50:24 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/pilates.php
INFO - 2021-08-09 10:50:24 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:50:24 --> Final output sent to browser
DEBUG - 2021-08-09 10:50:24 --> Total execution time: 0.0416
INFO - 2021-08-09 10:50:36 --> Config Class Initialized
INFO - 2021-08-09 10:50:36 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:50:36 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:50:36 --> Utf8 Class Initialized
INFO - 2021-08-09 10:50:36 --> URI Class Initialized
INFO - 2021-08-09 10:50:36 --> Router Class Initialized
INFO - 2021-08-09 10:50:36 --> Output Class Initialized
INFO - 2021-08-09 10:50:36 --> Security Class Initialized
DEBUG - 2021-08-09 10:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:50:36 --> Input Class Initialized
INFO - 2021-08-09 10:50:36 --> Language Class Initialized
INFO - 2021-08-09 10:50:36 --> Loader Class Initialized
INFO - 2021-08-09 10:50:36 --> Helper loaded: url_helper
INFO - 2021-08-09 10:50:36 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:50:36 --> Controller Class Initialized
INFO - 2021-08-09 10:50:36 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:50:36 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:50:36 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:50:36 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/pilates.php
INFO - 2021-08-09 10:50:36 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:50:36 --> Final output sent to browser
DEBUG - 2021-08-09 10:50:36 --> Total execution time: 0.0379
INFO - 2021-08-09 10:50:36 --> Config Class Initialized
INFO - 2021-08-09 10:50:36 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:50:36 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:50:36 --> Utf8 Class Initialized
INFO - 2021-08-09 10:50:36 --> URI Class Initialized
INFO - 2021-08-09 10:50:36 --> Router Class Initialized
INFO - 2021-08-09 10:50:36 --> Output Class Initialized
INFO - 2021-08-09 10:50:36 --> Security Class Initialized
DEBUG - 2021-08-09 10:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:50:36 --> Input Class Initialized
INFO - 2021-08-09 10:50:36 --> Language Class Initialized
INFO - 2021-08-09 10:50:36 --> Loader Class Initialized
INFO - 2021-08-09 10:50:36 --> Helper loaded: url_helper
INFO - 2021-08-09 10:50:36 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:50:36 --> Controller Class Initialized
INFO - 2021-08-09 10:50:36 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:50:36 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:50:36 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:50:36 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/pilates.php
INFO - 2021-08-09 10:50:36 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:50:36 --> Final output sent to browser
DEBUG - 2021-08-09 10:50:36 --> Total execution time: 0.0395
INFO - 2021-08-09 10:50:42 --> Config Class Initialized
INFO - 2021-08-09 10:50:42 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:50:42 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:50:42 --> Utf8 Class Initialized
INFO - 2021-08-09 10:50:42 --> URI Class Initialized
INFO - 2021-08-09 10:50:42 --> Router Class Initialized
INFO - 2021-08-09 10:50:42 --> Output Class Initialized
INFO - 2021-08-09 10:50:42 --> Security Class Initialized
DEBUG - 2021-08-09 10:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:50:42 --> Input Class Initialized
INFO - 2021-08-09 10:50:42 --> Language Class Initialized
INFO - 2021-08-09 10:50:42 --> Loader Class Initialized
INFO - 2021-08-09 10:50:42 --> Helper loaded: url_helper
INFO - 2021-08-09 10:50:42 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:50:42 --> Controller Class Initialized
INFO - 2021-08-09 10:50:42 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:50:42 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:50:42 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:50:42 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/pilates.php
INFO - 2021-08-09 10:50:42 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:50:42 --> Final output sent to browser
DEBUG - 2021-08-09 10:50:42 --> Total execution time: 0.0360
INFO - 2021-08-09 10:50:43 --> Config Class Initialized
INFO - 2021-08-09 10:50:43 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:50:43 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:50:43 --> Utf8 Class Initialized
INFO - 2021-08-09 10:50:43 --> URI Class Initialized
INFO - 2021-08-09 10:50:43 --> Router Class Initialized
INFO - 2021-08-09 10:50:43 --> Output Class Initialized
INFO - 2021-08-09 10:50:43 --> Security Class Initialized
DEBUG - 2021-08-09 10:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:50:43 --> Input Class Initialized
INFO - 2021-08-09 10:50:43 --> Language Class Initialized
INFO - 2021-08-09 10:50:43 --> Loader Class Initialized
INFO - 2021-08-09 10:50:43 --> Helper loaded: url_helper
INFO - 2021-08-09 10:50:43 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:50:43 --> Controller Class Initialized
INFO - 2021-08-09 10:50:43 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:50:43 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:50:43 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:50:43 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/pilates.php
INFO - 2021-08-09 10:50:43 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:50:43 --> Final output sent to browser
DEBUG - 2021-08-09 10:50:43 --> Total execution time: 0.0368
INFO - 2021-08-09 10:51:08 --> Config Class Initialized
INFO - 2021-08-09 10:51:08 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:51:08 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:51:08 --> Utf8 Class Initialized
INFO - 2021-08-09 10:51:08 --> URI Class Initialized
DEBUG - 2021-08-09 10:51:08 --> No URI present. Default controller set.
INFO - 2021-08-09 10:51:08 --> Router Class Initialized
INFO - 2021-08-09 10:51:08 --> Output Class Initialized
INFO - 2021-08-09 10:51:08 --> Security Class Initialized
DEBUG - 2021-08-09 10:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:51:08 --> Input Class Initialized
INFO - 2021-08-09 10:51:08 --> Language Class Initialized
INFO - 2021-08-09 10:51:08 --> Loader Class Initialized
INFO - 2021-08-09 10:51:08 --> Helper loaded: url_helper
INFO - 2021-08-09 10:51:08 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:51:08 --> Controller Class Initialized
INFO - 2021-08-09 10:51:08 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:51:08 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:51:09 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:51:09 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-09 10:51:09 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:51:09 --> Final output sent to browser
DEBUG - 2021-08-09 10:51:09 --> Total execution time: 0.0376
INFO - 2021-08-09 10:52:03 --> Config Class Initialized
INFO - 2021-08-09 10:52:03 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:52:03 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:52:03 --> Utf8 Class Initialized
INFO - 2021-08-09 10:52:03 --> URI Class Initialized
DEBUG - 2021-08-09 10:52:03 --> No URI present. Default controller set.
INFO - 2021-08-09 10:52:03 --> Router Class Initialized
INFO - 2021-08-09 10:52:03 --> Output Class Initialized
INFO - 2021-08-09 10:52:03 --> Security Class Initialized
DEBUG - 2021-08-09 10:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:52:03 --> Input Class Initialized
INFO - 2021-08-09 10:52:03 --> Language Class Initialized
INFO - 2021-08-09 10:52:03 --> Loader Class Initialized
INFO - 2021-08-09 10:52:03 --> Helper loaded: url_helper
INFO - 2021-08-09 10:52:03 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:52:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:52:03 --> Controller Class Initialized
INFO - 2021-08-09 10:52:03 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:52:03 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:52:03 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:52:03 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-09 10:52:03 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:52:03 --> Final output sent to browser
DEBUG - 2021-08-09 10:52:03 --> Total execution time: 0.0600
INFO - 2021-08-09 10:52:19 --> Config Class Initialized
INFO - 2021-08-09 10:52:19 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:52:19 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:52:19 --> Utf8 Class Initialized
INFO - 2021-08-09 10:52:19 --> URI Class Initialized
DEBUG - 2021-08-09 10:52:19 --> No URI present. Default controller set.
INFO - 2021-08-09 10:52:19 --> Router Class Initialized
INFO - 2021-08-09 10:52:19 --> Output Class Initialized
INFO - 2021-08-09 10:52:19 --> Security Class Initialized
DEBUG - 2021-08-09 10:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:52:19 --> Input Class Initialized
INFO - 2021-08-09 10:52:19 --> Language Class Initialized
INFO - 2021-08-09 10:52:19 --> Loader Class Initialized
INFO - 2021-08-09 10:52:19 --> Helper loaded: url_helper
INFO - 2021-08-09 10:52:19 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:52:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:52:19 --> Controller Class Initialized
INFO - 2021-08-09 10:52:19 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:52:19 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:52:19 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:52:19 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-09 10:52:19 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:52:19 --> Final output sent to browser
DEBUG - 2021-08-09 10:52:19 --> Total execution time: 0.0411
INFO - 2021-08-09 10:52:20 --> Config Class Initialized
INFO - 2021-08-09 10:52:20 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:52:20 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:52:20 --> Utf8 Class Initialized
INFO - 2021-08-09 10:52:20 --> URI Class Initialized
DEBUG - 2021-08-09 10:52:20 --> No URI present. Default controller set.
INFO - 2021-08-09 10:52:20 --> Router Class Initialized
INFO - 2021-08-09 10:52:20 --> Output Class Initialized
INFO - 2021-08-09 10:52:20 --> Security Class Initialized
DEBUG - 2021-08-09 10:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:52:20 --> Input Class Initialized
INFO - 2021-08-09 10:52:20 --> Language Class Initialized
INFO - 2021-08-09 10:52:20 --> Loader Class Initialized
INFO - 2021-08-09 10:52:20 --> Helper loaded: url_helper
INFO - 2021-08-09 10:52:20 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:52:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:52:20 --> Controller Class Initialized
INFO - 2021-08-09 10:52:20 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:52:20 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:52:20 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:52:20 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-09 10:52:20 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:52:20 --> Final output sent to browser
DEBUG - 2021-08-09 10:52:20 --> Total execution time: 0.0338
INFO - 2021-08-09 10:52:22 --> Config Class Initialized
INFO - 2021-08-09 10:52:22 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:52:22 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:52:22 --> Utf8 Class Initialized
INFO - 2021-08-09 10:52:22 --> URI Class Initialized
DEBUG - 2021-08-09 10:52:22 --> No URI present. Default controller set.
INFO - 2021-08-09 10:52:22 --> Router Class Initialized
INFO - 2021-08-09 10:52:22 --> Output Class Initialized
INFO - 2021-08-09 10:52:22 --> Security Class Initialized
DEBUG - 2021-08-09 10:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:52:22 --> Input Class Initialized
INFO - 2021-08-09 10:52:22 --> Language Class Initialized
INFO - 2021-08-09 10:52:22 --> Loader Class Initialized
INFO - 2021-08-09 10:52:22 --> Helper loaded: url_helper
INFO - 2021-08-09 10:52:22 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:52:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:52:22 --> Controller Class Initialized
INFO - 2021-08-09 10:52:22 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:52:22 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:52:22 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:52:22 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-09 10:52:22 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:52:22 --> Final output sent to browser
DEBUG - 2021-08-09 10:52:22 --> Total execution time: 0.0336
INFO - 2021-08-09 10:52:32 --> Config Class Initialized
INFO - 2021-08-09 10:52:32 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:52:32 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:52:32 --> Utf8 Class Initialized
INFO - 2021-08-09 10:52:32 --> URI Class Initialized
DEBUG - 2021-08-09 10:52:32 --> No URI present. Default controller set.
INFO - 2021-08-09 10:52:32 --> Router Class Initialized
INFO - 2021-08-09 10:52:32 --> Output Class Initialized
INFO - 2021-08-09 10:52:32 --> Security Class Initialized
DEBUG - 2021-08-09 10:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:52:32 --> Input Class Initialized
INFO - 2021-08-09 10:52:32 --> Language Class Initialized
INFO - 2021-08-09 10:52:32 --> Loader Class Initialized
INFO - 2021-08-09 10:52:32 --> Helper loaded: url_helper
INFO - 2021-08-09 10:52:32 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:52:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:52:32 --> Controller Class Initialized
INFO - 2021-08-09 10:52:32 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:52:32 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:52:32 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:52:32 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-09 10:52:32 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:52:32 --> Final output sent to browser
DEBUG - 2021-08-09 10:52:32 --> Total execution time: 0.0927
INFO - 2021-08-09 10:54:05 --> Config Class Initialized
INFO - 2021-08-09 10:54:05 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:54:05 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:54:05 --> Utf8 Class Initialized
INFO - 2021-08-09 10:54:05 --> URI Class Initialized
DEBUG - 2021-08-09 10:54:05 --> No URI present. Default controller set.
INFO - 2021-08-09 10:54:05 --> Router Class Initialized
INFO - 2021-08-09 10:54:05 --> Output Class Initialized
INFO - 2021-08-09 10:54:05 --> Security Class Initialized
DEBUG - 2021-08-09 10:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:54:05 --> Input Class Initialized
INFO - 2021-08-09 10:54:05 --> Language Class Initialized
INFO - 2021-08-09 10:54:05 --> Loader Class Initialized
INFO - 2021-08-09 10:54:05 --> Helper loaded: url_helper
INFO - 2021-08-09 10:54:05 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:54:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:54:05 --> Controller Class Initialized
INFO - 2021-08-09 10:54:05 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:54:05 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:54:05 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:54:05 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-09 10:54:05 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:54:05 --> Final output sent to browser
DEBUG - 2021-08-09 10:54:05 --> Total execution time: 0.0425
INFO - 2021-08-09 10:54:39 --> Config Class Initialized
INFO - 2021-08-09 10:54:39 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:54:39 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:54:39 --> Utf8 Class Initialized
INFO - 2021-08-09 10:54:39 --> URI Class Initialized
DEBUG - 2021-08-09 10:54:39 --> No URI present. Default controller set.
INFO - 2021-08-09 10:54:39 --> Router Class Initialized
INFO - 2021-08-09 10:54:39 --> Output Class Initialized
INFO - 2021-08-09 10:54:39 --> Security Class Initialized
DEBUG - 2021-08-09 10:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:54:39 --> Input Class Initialized
INFO - 2021-08-09 10:54:39 --> Language Class Initialized
INFO - 2021-08-09 10:54:39 --> Loader Class Initialized
INFO - 2021-08-09 10:54:39 --> Helper loaded: url_helper
INFO - 2021-08-09 10:54:39 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:54:39 --> Controller Class Initialized
INFO - 2021-08-09 10:54:39 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:54:39 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:54:39 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:54:39 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-09 10:54:39 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:54:39 --> Final output sent to browser
DEBUG - 2021-08-09 10:54:39 --> Total execution time: 0.0358
INFO - 2021-08-09 10:54:41 --> Config Class Initialized
INFO - 2021-08-09 10:54:41 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:54:41 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:54:41 --> Utf8 Class Initialized
INFO - 2021-08-09 10:54:41 --> URI Class Initialized
DEBUG - 2021-08-09 10:54:41 --> No URI present. Default controller set.
INFO - 2021-08-09 10:54:41 --> Router Class Initialized
INFO - 2021-08-09 10:54:41 --> Output Class Initialized
INFO - 2021-08-09 10:54:41 --> Security Class Initialized
DEBUG - 2021-08-09 10:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:54:41 --> Input Class Initialized
INFO - 2021-08-09 10:54:41 --> Language Class Initialized
INFO - 2021-08-09 10:54:41 --> Loader Class Initialized
INFO - 2021-08-09 10:54:41 --> Helper loaded: url_helper
INFO - 2021-08-09 10:54:41 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:54:41 --> Controller Class Initialized
INFO - 2021-08-09 10:54:41 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:54:41 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:54:41 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:54:41 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-09 10:54:41 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:54:41 --> Final output sent to browser
DEBUG - 2021-08-09 10:54:41 --> Total execution time: 0.0371
INFO - 2021-08-09 10:54:42 --> Config Class Initialized
INFO - 2021-08-09 10:54:42 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:54:42 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:54:42 --> Utf8 Class Initialized
INFO - 2021-08-09 10:54:42 --> URI Class Initialized
DEBUG - 2021-08-09 10:54:42 --> No URI present. Default controller set.
INFO - 2021-08-09 10:54:42 --> Router Class Initialized
INFO - 2021-08-09 10:54:42 --> Output Class Initialized
INFO - 2021-08-09 10:54:42 --> Security Class Initialized
DEBUG - 2021-08-09 10:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:54:42 --> Input Class Initialized
INFO - 2021-08-09 10:54:42 --> Language Class Initialized
INFO - 2021-08-09 10:54:42 --> Loader Class Initialized
INFO - 2021-08-09 10:54:42 --> Helper loaded: url_helper
INFO - 2021-08-09 10:54:42 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:54:42 --> Controller Class Initialized
INFO - 2021-08-09 10:54:42 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:54:42 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:54:42 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:54:42 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-09 10:54:42 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:54:42 --> Final output sent to browser
DEBUG - 2021-08-09 10:54:42 --> Total execution time: 0.0535
INFO - 2021-08-09 10:54:43 --> Config Class Initialized
INFO - 2021-08-09 10:54:43 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:54:43 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:54:43 --> Utf8 Class Initialized
INFO - 2021-08-09 10:54:43 --> URI Class Initialized
DEBUG - 2021-08-09 10:54:43 --> No URI present. Default controller set.
INFO - 2021-08-09 10:54:43 --> Router Class Initialized
INFO - 2021-08-09 10:54:43 --> Output Class Initialized
INFO - 2021-08-09 10:54:43 --> Security Class Initialized
DEBUG - 2021-08-09 10:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:54:43 --> Input Class Initialized
INFO - 2021-08-09 10:54:43 --> Language Class Initialized
INFO - 2021-08-09 10:54:43 --> Loader Class Initialized
INFO - 2021-08-09 10:54:43 --> Helper loaded: url_helper
INFO - 2021-08-09 10:54:43 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:54:43 --> Controller Class Initialized
INFO - 2021-08-09 10:54:43 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:54:43 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:54:43 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:54:43 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-09 10:54:43 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:54:43 --> Final output sent to browser
DEBUG - 2021-08-09 10:54:43 --> Total execution time: 0.0726
INFO - 2021-08-09 10:54:43 --> Config Class Initialized
INFO - 2021-08-09 10:54:43 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:54:43 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:54:43 --> Utf8 Class Initialized
INFO - 2021-08-09 10:54:43 --> URI Class Initialized
DEBUG - 2021-08-09 10:54:43 --> No URI present. Default controller set.
INFO - 2021-08-09 10:54:43 --> Router Class Initialized
INFO - 2021-08-09 10:54:43 --> Output Class Initialized
INFO - 2021-08-09 10:54:43 --> Security Class Initialized
DEBUG - 2021-08-09 10:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:54:43 --> Input Class Initialized
INFO - 2021-08-09 10:54:43 --> Language Class Initialized
INFO - 2021-08-09 10:54:43 --> Loader Class Initialized
INFO - 2021-08-09 10:54:43 --> Helper loaded: url_helper
INFO - 2021-08-09 10:54:43 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:54:43 --> Controller Class Initialized
INFO - 2021-08-09 10:54:43 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:54:43 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:54:43 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:54:43 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-09 10:54:43 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:54:43 --> Final output sent to browser
DEBUG - 2021-08-09 10:54:43 --> Total execution time: 0.0588
INFO - 2021-08-09 10:54:44 --> Config Class Initialized
INFO - 2021-08-09 10:54:44 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:54:44 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:54:44 --> Utf8 Class Initialized
INFO - 2021-08-09 10:54:44 --> URI Class Initialized
DEBUG - 2021-08-09 10:54:44 --> No URI present. Default controller set.
INFO - 2021-08-09 10:54:44 --> Router Class Initialized
INFO - 2021-08-09 10:54:44 --> Output Class Initialized
INFO - 2021-08-09 10:54:44 --> Security Class Initialized
DEBUG - 2021-08-09 10:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:54:44 --> Input Class Initialized
INFO - 2021-08-09 10:54:44 --> Language Class Initialized
INFO - 2021-08-09 10:54:44 --> Loader Class Initialized
INFO - 2021-08-09 10:54:44 --> Helper loaded: url_helper
INFO - 2021-08-09 10:54:44 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:54:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:54:44 --> Controller Class Initialized
INFO - 2021-08-09 10:54:44 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:54:44 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:54:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:54:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-09 10:54:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:54:44 --> Final output sent to browser
DEBUG - 2021-08-09 10:54:44 --> Total execution time: 0.0550
INFO - 2021-08-09 10:55:39 --> Config Class Initialized
INFO - 2021-08-09 10:55:39 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:55:39 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:55:39 --> Utf8 Class Initialized
INFO - 2021-08-09 10:55:39 --> URI Class Initialized
DEBUG - 2021-08-09 10:55:39 --> No URI present. Default controller set.
INFO - 2021-08-09 10:55:39 --> Router Class Initialized
INFO - 2021-08-09 10:55:39 --> Output Class Initialized
INFO - 2021-08-09 10:55:39 --> Security Class Initialized
DEBUG - 2021-08-09 10:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:55:39 --> Input Class Initialized
INFO - 2021-08-09 10:55:39 --> Language Class Initialized
INFO - 2021-08-09 10:55:39 --> Loader Class Initialized
INFO - 2021-08-09 10:55:39 --> Helper loaded: url_helper
INFO - 2021-08-09 10:55:39 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:55:39 --> Controller Class Initialized
INFO - 2021-08-09 10:55:39 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:55:39 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:55:39 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:55:39 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-09 10:55:39 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:55:39 --> Final output sent to browser
DEBUG - 2021-08-09 10:55:39 --> Total execution time: 0.0405
INFO - 2021-08-09 10:55:42 --> Config Class Initialized
INFO - 2021-08-09 10:55:42 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:55:42 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:55:42 --> Utf8 Class Initialized
INFO - 2021-08-09 10:55:42 --> URI Class Initialized
DEBUG - 2021-08-09 10:55:42 --> No URI present. Default controller set.
INFO - 2021-08-09 10:55:42 --> Router Class Initialized
INFO - 2021-08-09 10:55:42 --> Output Class Initialized
INFO - 2021-08-09 10:55:42 --> Security Class Initialized
DEBUG - 2021-08-09 10:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:55:42 --> Input Class Initialized
INFO - 2021-08-09 10:55:42 --> Language Class Initialized
INFO - 2021-08-09 10:55:42 --> Loader Class Initialized
INFO - 2021-08-09 10:55:42 --> Helper loaded: url_helper
INFO - 2021-08-09 10:55:42 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:55:42 --> Controller Class Initialized
INFO - 2021-08-09 10:55:42 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:55:42 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:55:42 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:55:42 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-09 10:55:42 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:55:42 --> Final output sent to browser
DEBUG - 2021-08-09 10:55:42 --> Total execution time: 0.0346
INFO - 2021-08-09 10:55:43 --> Config Class Initialized
INFO - 2021-08-09 10:55:43 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:55:43 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:55:43 --> Utf8 Class Initialized
INFO - 2021-08-09 10:55:43 --> URI Class Initialized
DEBUG - 2021-08-09 10:55:43 --> No URI present. Default controller set.
INFO - 2021-08-09 10:55:43 --> Router Class Initialized
INFO - 2021-08-09 10:55:43 --> Output Class Initialized
INFO - 2021-08-09 10:55:43 --> Security Class Initialized
DEBUG - 2021-08-09 10:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:55:43 --> Input Class Initialized
INFO - 2021-08-09 10:55:43 --> Language Class Initialized
INFO - 2021-08-09 10:55:43 --> Loader Class Initialized
INFO - 2021-08-09 10:55:43 --> Helper loaded: url_helper
INFO - 2021-08-09 10:55:43 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:55:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:55:43 --> Controller Class Initialized
INFO - 2021-08-09 10:55:43 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:55:43 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:55:43 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:55:43 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-09 10:55:43 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:55:43 --> Final output sent to browser
DEBUG - 2021-08-09 10:55:43 --> Total execution time: 0.0536
INFO - 2021-08-09 10:56:00 --> Config Class Initialized
INFO - 2021-08-09 10:56:00 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:56:00 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:56:00 --> Utf8 Class Initialized
INFO - 2021-08-09 10:56:00 --> URI Class Initialized
DEBUG - 2021-08-09 10:56:00 --> No URI present. Default controller set.
INFO - 2021-08-09 10:56:00 --> Router Class Initialized
INFO - 2021-08-09 10:56:00 --> Output Class Initialized
INFO - 2021-08-09 10:56:00 --> Security Class Initialized
DEBUG - 2021-08-09 10:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:56:00 --> Input Class Initialized
INFO - 2021-08-09 10:56:00 --> Language Class Initialized
INFO - 2021-08-09 10:56:00 --> Loader Class Initialized
INFO - 2021-08-09 10:56:00 --> Helper loaded: url_helper
INFO - 2021-08-09 10:56:00 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:56:00 --> Controller Class Initialized
INFO - 2021-08-09 10:56:00 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:56:00 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:56:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:56:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-09 10:56:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:56:00 --> Final output sent to browser
DEBUG - 2021-08-09 10:56:00 --> Total execution time: 0.0422
INFO - 2021-08-09 10:56:17 --> Config Class Initialized
INFO - 2021-08-09 10:56:17 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:56:17 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:56:17 --> Utf8 Class Initialized
INFO - 2021-08-09 10:56:17 --> URI Class Initialized
DEBUG - 2021-08-09 10:56:17 --> No URI present. Default controller set.
INFO - 2021-08-09 10:56:17 --> Router Class Initialized
INFO - 2021-08-09 10:56:17 --> Output Class Initialized
INFO - 2021-08-09 10:56:17 --> Security Class Initialized
DEBUG - 2021-08-09 10:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:56:17 --> Input Class Initialized
INFO - 2021-08-09 10:56:17 --> Language Class Initialized
INFO - 2021-08-09 10:56:17 --> Loader Class Initialized
INFO - 2021-08-09 10:56:17 --> Helper loaded: url_helper
INFO - 2021-08-09 10:56:17 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:56:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:56:17 --> Controller Class Initialized
INFO - 2021-08-09 10:56:17 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:56:17 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:56:17 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:56:17 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-09 10:56:17 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:56:17 --> Final output sent to browser
DEBUG - 2021-08-09 10:56:17 --> Total execution time: 0.0425
INFO - 2021-08-09 10:56:26 --> Config Class Initialized
INFO - 2021-08-09 10:56:26 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:56:26 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:56:26 --> Utf8 Class Initialized
INFO - 2021-08-09 10:56:26 --> URI Class Initialized
DEBUG - 2021-08-09 10:56:26 --> No URI present. Default controller set.
INFO - 2021-08-09 10:56:26 --> Router Class Initialized
INFO - 2021-08-09 10:56:26 --> Output Class Initialized
INFO - 2021-08-09 10:56:26 --> Security Class Initialized
DEBUG - 2021-08-09 10:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:56:26 --> Input Class Initialized
INFO - 2021-08-09 10:56:26 --> Language Class Initialized
INFO - 2021-08-09 10:56:26 --> Loader Class Initialized
INFO - 2021-08-09 10:56:26 --> Helper loaded: url_helper
INFO - 2021-08-09 10:56:26 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:56:26 --> Controller Class Initialized
INFO - 2021-08-09 10:56:26 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:56:26 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:56:26 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:56:26 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-09 10:56:26 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:56:26 --> Final output sent to browser
DEBUG - 2021-08-09 10:56:26 --> Total execution time: 0.0508
INFO - 2021-08-09 10:56:40 --> Config Class Initialized
INFO - 2021-08-09 10:56:40 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:56:40 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:56:40 --> Utf8 Class Initialized
INFO - 2021-08-09 10:56:40 --> URI Class Initialized
DEBUG - 2021-08-09 10:56:40 --> No URI present. Default controller set.
INFO - 2021-08-09 10:56:40 --> Router Class Initialized
INFO - 2021-08-09 10:56:40 --> Output Class Initialized
INFO - 2021-08-09 10:56:40 --> Security Class Initialized
DEBUG - 2021-08-09 10:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:56:40 --> Input Class Initialized
INFO - 2021-08-09 10:56:40 --> Language Class Initialized
INFO - 2021-08-09 10:56:40 --> Loader Class Initialized
INFO - 2021-08-09 10:56:40 --> Helper loaded: url_helper
INFO - 2021-08-09 10:56:40 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:56:40 --> Controller Class Initialized
INFO - 2021-08-09 10:56:40 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:56:40 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:56:40 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:56:40 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-09 10:56:40 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:56:40 --> Final output sent to browser
DEBUG - 2021-08-09 10:56:40 --> Total execution time: 0.0362
INFO - 2021-08-09 10:56:51 --> Config Class Initialized
INFO - 2021-08-09 10:56:51 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:56:51 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:56:51 --> Utf8 Class Initialized
INFO - 2021-08-09 10:56:51 --> URI Class Initialized
DEBUG - 2021-08-09 10:56:51 --> No URI present. Default controller set.
INFO - 2021-08-09 10:56:51 --> Router Class Initialized
INFO - 2021-08-09 10:56:51 --> Output Class Initialized
INFO - 2021-08-09 10:56:51 --> Security Class Initialized
DEBUG - 2021-08-09 10:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:56:51 --> Input Class Initialized
INFO - 2021-08-09 10:56:51 --> Language Class Initialized
INFO - 2021-08-09 10:56:51 --> Loader Class Initialized
INFO - 2021-08-09 10:56:51 --> Helper loaded: url_helper
INFO - 2021-08-09 10:56:51 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:56:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:56:51 --> Controller Class Initialized
INFO - 2021-08-09 10:56:51 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:56:51 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:56:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:56:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-09 10:56:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:56:51 --> Final output sent to browser
DEBUG - 2021-08-09 10:56:51 --> Total execution time: 0.0374
INFO - 2021-08-09 10:56:57 --> Config Class Initialized
INFO - 2021-08-09 10:56:57 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:56:57 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:56:57 --> Utf8 Class Initialized
INFO - 2021-08-09 10:56:57 --> URI Class Initialized
DEBUG - 2021-08-09 10:56:57 --> No URI present. Default controller set.
INFO - 2021-08-09 10:56:57 --> Router Class Initialized
INFO - 2021-08-09 10:56:57 --> Output Class Initialized
INFO - 2021-08-09 10:56:57 --> Security Class Initialized
DEBUG - 2021-08-09 10:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:56:57 --> Input Class Initialized
INFO - 2021-08-09 10:56:57 --> Language Class Initialized
INFO - 2021-08-09 10:56:57 --> Loader Class Initialized
INFO - 2021-08-09 10:56:57 --> Helper loaded: url_helper
INFO - 2021-08-09 10:56:57 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:56:57 --> Controller Class Initialized
INFO - 2021-08-09 10:56:57 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:56:57 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:56:57 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:56:57 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-09 10:56:57 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:56:57 --> Final output sent to browser
DEBUG - 2021-08-09 10:56:57 --> Total execution time: 0.0473
INFO - 2021-08-09 10:57:18 --> Config Class Initialized
INFO - 2021-08-09 10:57:18 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:57:18 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:57:18 --> Utf8 Class Initialized
INFO - 2021-08-09 10:57:18 --> URI Class Initialized
DEBUG - 2021-08-09 10:57:18 --> No URI present. Default controller set.
INFO - 2021-08-09 10:57:18 --> Router Class Initialized
INFO - 2021-08-09 10:57:18 --> Output Class Initialized
INFO - 2021-08-09 10:57:18 --> Security Class Initialized
DEBUG - 2021-08-09 10:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:57:18 --> Input Class Initialized
INFO - 2021-08-09 10:57:18 --> Language Class Initialized
INFO - 2021-08-09 10:57:18 --> Loader Class Initialized
INFO - 2021-08-09 10:57:18 --> Helper loaded: url_helper
INFO - 2021-08-09 10:57:18 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:57:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:57:18 --> Controller Class Initialized
INFO - 2021-08-09 10:57:18 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:57:18 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:57:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:57:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-09 10:57:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:57:18 --> Final output sent to browser
DEBUG - 2021-08-09 10:57:18 --> Total execution time: 0.0375
INFO - 2021-08-09 10:57:26 --> Config Class Initialized
INFO - 2021-08-09 10:57:26 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:57:26 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:57:26 --> Utf8 Class Initialized
INFO - 2021-08-09 10:57:26 --> URI Class Initialized
DEBUG - 2021-08-09 10:57:26 --> No URI present. Default controller set.
INFO - 2021-08-09 10:57:26 --> Router Class Initialized
INFO - 2021-08-09 10:57:26 --> Output Class Initialized
INFO - 2021-08-09 10:57:26 --> Security Class Initialized
DEBUG - 2021-08-09 10:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:57:26 --> Input Class Initialized
INFO - 2021-08-09 10:57:26 --> Language Class Initialized
INFO - 2021-08-09 10:57:26 --> Loader Class Initialized
INFO - 2021-08-09 10:57:26 --> Helper loaded: url_helper
INFO - 2021-08-09 10:57:26 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:57:26 --> Controller Class Initialized
INFO - 2021-08-09 10:57:26 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:57:26 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:57:26 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:57:26 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-09 10:57:26 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:57:26 --> Final output sent to browser
DEBUG - 2021-08-09 10:57:26 --> Total execution time: 0.0374
INFO - 2021-08-09 10:57:48 --> Config Class Initialized
INFO - 2021-08-09 10:57:48 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:57:48 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:57:48 --> Utf8 Class Initialized
INFO - 2021-08-09 10:57:48 --> URI Class Initialized
DEBUG - 2021-08-09 10:57:48 --> No URI present. Default controller set.
INFO - 2021-08-09 10:57:48 --> Router Class Initialized
INFO - 2021-08-09 10:57:48 --> Output Class Initialized
INFO - 2021-08-09 10:57:48 --> Security Class Initialized
DEBUG - 2021-08-09 10:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:57:48 --> Input Class Initialized
INFO - 2021-08-09 10:57:48 --> Language Class Initialized
INFO - 2021-08-09 10:57:48 --> Loader Class Initialized
INFO - 2021-08-09 10:57:48 --> Helper loaded: url_helper
INFO - 2021-08-09 10:57:48 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:57:48 --> Controller Class Initialized
INFO - 2021-08-09 10:57:48 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:57:48 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:57:48 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:57:48 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-09 10:57:48 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:57:48 --> Final output sent to browser
DEBUG - 2021-08-09 10:57:48 --> Total execution time: 0.0381
INFO - 2021-08-09 10:58:13 --> Config Class Initialized
INFO - 2021-08-09 10:58:13 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:58:13 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:58:13 --> Utf8 Class Initialized
INFO - 2021-08-09 10:58:13 --> URI Class Initialized
INFO - 2021-08-09 10:58:13 --> Router Class Initialized
INFO - 2021-08-09 10:58:13 --> Output Class Initialized
INFO - 2021-08-09 10:58:13 --> Security Class Initialized
DEBUG - 2021-08-09 10:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:58:13 --> Input Class Initialized
INFO - 2021-08-09 10:58:13 --> Language Class Initialized
INFO - 2021-08-09 10:58:13 --> Loader Class Initialized
INFO - 2021-08-09 10:58:13 --> Helper loaded: url_helper
INFO - 2021-08-09 10:58:13 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:58:13 --> Controller Class Initialized
INFO - 2021-08-09 10:58:13 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:58:13 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:58:13 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:58:13 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-09 10:58:13 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:58:13 --> Final output sent to browser
DEBUG - 2021-08-09 10:58:13 --> Total execution time: 0.0427
INFO - 2021-08-09 10:58:23 --> Config Class Initialized
INFO - 2021-08-09 10:58:23 --> Hooks Class Initialized
DEBUG - 2021-08-09 10:58:23 --> UTF-8 Support Enabled
INFO - 2021-08-09 10:58:23 --> Utf8 Class Initialized
INFO - 2021-08-09 10:58:23 --> URI Class Initialized
INFO - 2021-08-09 10:58:23 --> Router Class Initialized
INFO - 2021-08-09 10:58:23 --> Output Class Initialized
INFO - 2021-08-09 10:58:23 --> Security Class Initialized
DEBUG - 2021-08-09 10:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 10:58:23 --> Input Class Initialized
INFO - 2021-08-09 10:58:23 --> Language Class Initialized
INFO - 2021-08-09 10:58:23 --> Loader Class Initialized
INFO - 2021-08-09 10:58:23 --> Helper loaded: url_helper
INFO - 2021-08-09 10:58:23 --> Helper loaded: file_helper
DEBUG - 2021-08-09 10:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 10:58:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 10:58:23 --> Controller Class Initialized
INFO - 2021-08-09 10:58:23 --> Helper loaded: cookie_helper
INFO - 2021-08-09 10:58:23 --> Model "CookieModel" initialized
INFO - 2021-08-09 10:58:23 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 10:58:23 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/team.php
INFO - 2021-08-09 10:58:23 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 10:58:23 --> Final output sent to browser
DEBUG - 2021-08-09 10:58:23 --> Total execution time: 0.0391
INFO - 2021-08-09 11:00:28 --> Config Class Initialized
INFO - 2021-08-09 11:00:28 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:00:28 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:00:28 --> Utf8 Class Initialized
INFO - 2021-08-09 11:00:28 --> URI Class Initialized
INFO - 2021-08-09 11:00:28 --> Router Class Initialized
INFO - 2021-08-09 11:00:28 --> Output Class Initialized
INFO - 2021-08-09 11:00:28 --> Security Class Initialized
DEBUG - 2021-08-09 11:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:00:28 --> Input Class Initialized
INFO - 2021-08-09 11:00:28 --> Language Class Initialized
INFO - 2021-08-09 11:00:28 --> Loader Class Initialized
INFO - 2021-08-09 11:00:28 --> Helper loaded: url_helper
INFO - 2021-08-09 11:00:28 --> Helper loaded: file_helper
DEBUG - 2021-08-09 11:00:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 11:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 11:00:28 --> Controller Class Initialized
INFO - 2021-08-09 11:00:28 --> Helper loaded: cookie_helper
INFO - 2021-08-09 11:00:28 --> Model "CookieModel" initialized
INFO - 2021-08-09 11:00:28 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 11:00:28 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/team.php
INFO - 2021-08-09 11:00:28 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 11:00:28 --> Final output sent to browser
DEBUG - 2021-08-09 11:00:28 --> Total execution time: 0.0393
INFO - 2021-08-09 11:01:44 --> Config Class Initialized
INFO - 2021-08-09 11:01:44 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:01:44 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:01:44 --> Utf8 Class Initialized
INFO - 2021-08-09 11:01:44 --> URI Class Initialized
INFO - 2021-08-09 11:01:44 --> Router Class Initialized
INFO - 2021-08-09 11:01:44 --> Output Class Initialized
INFO - 2021-08-09 11:01:44 --> Security Class Initialized
DEBUG - 2021-08-09 11:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:01:44 --> Input Class Initialized
INFO - 2021-08-09 11:01:44 --> Language Class Initialized
INFO - 2021-08-09 11:01:44 --> Loader Class Initialized
INFO - 2021-08-09 11:01:44 --> Helper loaded: url_helper
INFO - 2021-08-09 11:01:44 --> Helper loaded: file_helper
DEBUG - 2021-08-09 11:01:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 11:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 11:01:44 --> Controller Class Initialized
INFO - 2021-08-09 11:01:44 --> Helper loaded: cookie_helper
INFO - 2021-08-09 11:01:44 --> Model "CookieModel" initialized
INFO - 2021-08-09 11:01:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 11:01:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/team.php
INFO - 2021-08-09 11:01:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 11:01:44 --> Final output sent to browser
DEBUG - 2021-08-09 11:01:44 --> Total execution time: 0.0380
INFO - 2021-08-09 11:01:48 --> Config Class Initialized
INFO - 2021-08-09 11:01:48 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:01:48 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:01:48 --> Utf8 Class Initialized
INFO - 2021-08-09 11:01:48 --> URI Class Initialized
INFO - 2021-08-09 11:01:48 --> Router Class Initialized
INFO - 2021-08-09 11:01:48 --> Output Class Initialized
INFO - 2021-08-09 11:01:48 --> Security Class Initialized
DEBUG - 2021-08-09 11:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:01:48 --> Input Class Initialized
INFO - 2021-08-09 11:01:48 --> Language Class Initialized
INFO - 2021-08-09 11:01:48 --> Loader Class Initialized
INFO - 2021-08-09 11:01:48 --> Helper loaded: url_helper
INFO - 2021-08-09 11:01:48 --> Helper loaded: file_helper
DEBUG - 2021-08-09 11:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 11:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 11:01:48 --> Controller Class Initialized
INFO - 2021-08-09 11:01:48 --> Helper loaded: cookie_helper
INFO - 2021-08-09 11:01:48 --> Model "CookieModel" initialized
INFO - 2021-08-09 11:01:48 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 11:01:48 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/team.php
INFO - 2021-08-09 11:01:48 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 11:01:48 --> Final output sent to browser
DEBUG - 2021-08-09 11:01:48 --> Total execution time: 0.0337
INFO - 2021-08-09 11:01:51 --> Config Class Initialized
INFO - 2021-08-09 11:01:51 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:01:51 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:01:51 --> Utf8 Class Initialized
INFO - 2021-08-09 11:01:51 --> URI Class Initialized
INFO - 2021-08-09 11:01:51 --> Router Class Initialized
INFO - 2021-08-09 11:01:51 --> Output Class Initialized
INFO - 2021-08-09 11:01:51 --> Security Class Initialized
DEBUG - 2021-08-09 11:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:01:51 --> Input Class Initialized
INFO - 2021-08-09 11:01:51 --> Language Class Initialized
INFO - 2021-08-09 11:01:51 --> Loader Class Initialized
INFO - 2021-08-09 11:01:51 --> Helper loaded: url_helper
INFO - 2021-08-09 11:01:51 --> Helper loaded: file_helper
DEBUG - 2021-08-09 11:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 11:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 11:01:51 --> Controller Class Initialized
INFO - 2021-08-09 11:01:51 --> Helper loaded: cookie_helper
INFO - 2021-08-09 11:01:51 --> Model "CookieModel" initialized
INFO - 2021-08-09 11:01:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 11:01:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/team.php
INFO - 2021-08-09 11:01:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 11:01:51 --> Final output sent to browser
DEBUG - 2021-08-09 11:01:51 --> Total execution time: 0.0404
INFO - 2021-08-09 11:03:12 --> Config Class Initialized
INFO - 2021-08-09 11:03:12 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:03:12 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:03:12 --> Utf8 Class Initialized
INFO - 2021-08-09 11:03:12 --> URI Class Initialized
INFO - 2021-08-09 11:03:12 --> Router Class Initialized
INFO - 2021-08-09 11:03:12 --> Output Class Initialized
INFO - 2021-08-09 11:03:12 --> Security Class Initialized
DEBUG - 2021-08-09 11:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:03:12 --> Input Class Initialized
INFO - 2021-08-09 11:03:12 --> Language Class Initialized
INFO - 2021-08-09 11:03:12 --> Loader Class Initialized
INFO - 2021-08-09 11:03:12 --> Helper loaded: url_helper
INFO - 2021-08-09 11:03:12 --> Helper loaded: file_helper
DEBUG - 2021-08-09 11:03:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 11:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 11:03:12 --> Controller Class Initialized
INFO - 2021-08-09 11:03:12 --> Helper loaded: cookie_helper
INFO - 2021-08-09 11:03:12 --> Model "CookieModel" initialized
INFO - 2021-08-09 11:03:12 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 11:03:12 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/team.php
INFO - 2021-08-09 11:03:12 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 11:03:12 --> Final output sent to browser
DEBUG - 2021-08-09 11:03:12 --> Total execution time: 0.0427
INFO - 2021-08-09 11:03:55 --> Config Class Initialized
INFO - 2021-08-09 11:03:55 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:03:55 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:03:55 --> Utf8 Class Initialized
INFO - 2021-08-09 11:03:55 --> URI Class Initialized
INFO - 2021-08-09 11:03:55 --> Router Class Initialized
INFO - 2021-08-09 11:03:55 --> Output Class Initialized
INFO - 2021-08-09 11:03:55 --> Security Class Initialized
DEBUG - 2021-08-09 11:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:03:55 --> Input Class Initialized
INFO - 2021-08-09 11:03:55 --> Language Class Initialized
INFO - 2021-08-09 11:03:55 --> Loader Class Initialized
INFO - 2021-08-09 11:03:55 --> Helper loaded: url_helper
INFO - 2021-08-09 11:03:55 --> Helper loaded: file_helper
DEBUG - 2021-08-09 11:03:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 11:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 11:03:55 --> Controller Class Initialized
INFO - 2021-08-09 11:03:55 --> Helper loaded: cookie_helper
INFO - 2021-08-09 11:03:55 --> Model "CookieModel" initialized
INFO - 2021-08-09 11:03:55 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 11:03:55 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/team.php
INFO - 2021-08-09 11:03:55 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 11:03:55 --> Final output sent to browser
DEBUG - 2021-08-09 11:03:55 --> Total execution time: 0.0416
INFO - 2021-08-09 11:04:28 --> Config Class Initialized
INFO - 2021-08-09 11:04:28 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:04:28 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:04:28 --> Utf8 Class Initialized
INFO - 2021-08-09 11:04:28 --> URI Class Initialized
INFO - 2021-08-09 11:04:28 --> Router Class Initialized
INFO - 2021-08-09 11:04:28 --> Output Class Initialized
INFO - 2021-08-09 11:04:28 --> Security Class Initialized
DEBUG - 2021-08-09 11:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:04:28 --> Input Class Initialized
INFO - 2021-08-09 11:04:28 --> Language Class Initialized
INFO - 2021-08-09 11:04:28 --> Loader Class Initialized
INFO - 2021-08-09 11:04:28 --> Helper loaded: url_helper
INFO - 2021-08-09 11:04:28 --> Helper loaded: file_helper
DEBUG - 2021-08-09 11:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 11:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 11:04:28 --> Controller Class Initialized
INFO - 2021-08-09 11:04:28 --> Helper loaded: cookie_helper
INFO - 2021-08-09 11:04:28 --> Model "CookieModel" initialized
INFO - 2021-08-09 11:04:28 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 11:04:28 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/team.php
INFO - 2021-08-09 11:04:28 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 11:04:28 --> Final output sent to browser
DEBUG - 2021-08-09 11:04:28 --> Total execution time: 0.0352
INFO - 2021-08-09 11:04:30 --> Config Class Initialized
INFO - 2021-08-09 11:04:30 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:04:30 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:04:30 --> Utf8 Class Initialized
INFO - 2021-08-09 11:04:30 --> URI Class Initialized
INFO - 2021-08-09 11:04:30 --> Router Class Initialized
INFO - 2021-08-09 11:04:30 --> Output Class Initialized
INFO - 2021-08-09 11:04:30 --> Security Class Initialized
DEBUG - 2021-08-09 11:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:04:30 --> Input Class Initialized
INFO - 2021-08-09 11:04:30 --> Language Class Initialized
INFO - 2021-08-09 11:04:30 --> Loader Class Initialized
INFO - 2021-08-09 11:04:30 --> Helper loaded: url_helper
INFO - 2021-08-09 11:04:30 --> Helper loaded: file_helper
DEBUG - 2021-08-09 11:04:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 11:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 11:04:30 --> Controller Class Initialized
INFO - 2021-08-09 11:04:30 --> Helper loaded: cookie_helper
INFO - 2021-08-09 11:04:30 --> Model "CookieModel" initialized
INFO - 2021-08-09 11:04:30 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 11:04:30 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/team.php
INFO - 2021-08-09 11:04:30 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 11:04:30 --> Final output sent to browser
DEBUG - 2021-08-09 11:04:30 --> Total execution time: 0.0384
INFO - 2021-08-09 11:05:49 --> Config Class Initialized
INFO - 2021-08-09 11:05:49 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:05:49 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:05:49 --> Utf8 Class Initialized
INFO - 2021-08-09 11:05:49 --> URI Class Initialized
INFO - 2021-08-09 11:05:49 --> Router Class Initialized
INFO - 2021-08-09 11:05:49 --> Output Class Initialized
INFO - 2021-08-09 11:05:49 --> Security Class Initialized
DEBUG - 2021-08-09 11:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:05:49 --> Input Class Initialized
INFO - 2021-08-09 11:05:49 --> Language Class Initialized
INFO - 2021-08-09 11:05:49 --> Loader Class Initialized
INFO - 2021-08-09 11:05:49 --> Helper loaded: url_helper
INFO - 2021-08-09 11:05:49 --> Helper loaded: file_helper
DEBUG - 2021-08-09 11:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 11:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 11:05:49 --> Controller Class Initialized
INFO - 2021-08-09 11:05:49 --> Helper loaded: cookie_helper
INFO - 2021-08-09 11:05:49 --> Model "CookieModel" initialized
INFO - 2021-08-09 11:05:49 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 11:05:49 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/team.php
INFO - 2021-08-09 11:05:49 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 11:05:49 --> Final output sent to browser
DEBUG - 2021-08-09 11:05:49 --> Total execution time: 0.0419
INFO - 2021-08-09 11:05:51 --> Config Class Initialized
INFO - 2021-08-09 11:05:51 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:05:51 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:05:51 --> Utf8 Class Initialized
INFO - 2021-08-09 11:05:51 --> URI Class Initialized
INFO - 2021-08-09 11:05:51 --> Router Class Initialized
INFO - 2021-08-09 11:05:51 --> Output Class Initialized
INFO - 2021-08-09 11:05:51 --> Security Class Initialized
DEBUG - 2021-08-09 11:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:05:51 --> Input Class Initialized
INFO - 2021-08-09 11:05:51 --> Language Class Initialized
INFO - 2021-08-09 11:05:51 --> Loader Class Initialized
INFO - 2021-08-09 11:05:51 --> Helper loaded: url_helper
INFO - 2021-08-09 11:05:51 --> Helper loaded: file_helper
DEBUG - 2021-08-09 11:05:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 11:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 11:05:51 --> Controller Class Initialized
INFO - 2021-08-09 11:05:51 --> Helper loaded: cookie_helper
INFO - 2021-08-09 11:05:51 --> Model "CookieModel" initialized
INFO - 2021-08-09 11:05:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 11:05:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/team.php
INFO - 2021-08-09 11:05:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 11:05:51 --> Final output sent to browser
DEBUG - 2021-08-09 11:05:51 --> Total execution time: 0.0344
INFO - 2021-08-09 11:06:13 --> Config Class Initialized
INFO - 2021-08-09 11:06:13 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:06:13 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:06:13 --> Utf8 Class Initialized
INFO - 2021-08-09 11:06:13 --> URI Class Initialized
INFO - 2021-08-09 11:06:13 --> Router Class Initialized
INFO - 2021-08-09 11:06:13 --> Output Class Initialized
INFO - 2021-08-09 11:06:13 --> Security Class Initialized
DEBUG - 2021-08-09 11:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:06:13 --> Input Class Initialized
INFO - 2021-08-09 11:06:13 --> Language Class Initialized
INFO - 2021-08-09 11:06:13 --> Loader Class Initialized
INFO - 2021-08-09 11:06:13 --> Helper loaded: url_helper
INFO - 2021-08-09 11:06:13 --> Helper loaded: file_helper
DEBUG - 2021-08-09 11:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 11:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 11:06:13 --> Controller Class Initialized
INFO - 2021-08-09 11:06:13 --> Helper loaded: cookie_helper
INFO - 2021-08-09 11:06:13 --> Model "CookieModel" initialized
INFO - 2021-08-09 11:06:13 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 11:06:13 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/team.php
INFO - 2021-08-09 11:06:13 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 11:06:13 --> Final output sent to browser
DEBUG - 2021-08-09 11:06:13 --> Total execution time: 0.0349
INFO - 2021-08-09 11:06:13 --> Config Class Initialized
INFO - 2021-08-09 11:06:13 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:06:13 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:06:13 --> Utf8 Class Initialized
INFO - 2021-08-09 11:06:13 --> URI Class Initialized
INFO - 2021-08-09 11:06:13 --> Router Class Initialized
INFO - 2021-08-09 11:06:13 --> Output Class Initialized
INFO - 2021-08-09 11:06:13 --> Security Class Initialized
DEBUG - 2021-08-09 11:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:06:13 --> Input Class Initialized
INFO - 2021-08-09 11:06:13 --> Language Class Initialized
INFO - 2021-08-09 11:06:13 --> Loader Class Initialized
INFO - 2021-08-09 11:06:13 --> Helper loaded: url_helper
INFO - 2021-08-09 11:06:13 --> Helper loaded: file_helper
DEBUG - 2021-08-09 11:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 11:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 11:06:13 --> Controller Class Initialized
INFO - 2021-08-09 11:06:13 --> Helper loaded: cookie_helper
INFO - 2021-08-09 11:06:13 --> Model "CookieModel" initialized
INFO - 2021-08-09 11:06:13 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 11:06:13 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/team.php
INFO - 2021-08-09 11:06:13 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 11:06:13 --> Final output sent to browser
DEBUG - 2021-08-09 11:06:13 --> Total execution time: 0.0343
INFO - 2021-08-09 11:06:14 --> Config Class Initialized
INFO - 2021-08-09 11:06:14 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:06:14 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:06:14 --> Utf8 Class Initialized
INFO - 2021-08-09 11:06:14 --> URI Class Initialized
INFO - 2021-08-09 11:06:14 --> Router Class Initialized
INFO - 2021-08-09 11:06:14 --> Output Class Initialized
INFO - 2021-08-09 11:06:14 --> Security Class Initialized
DEBUG - 2021-08-09 11:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:06:14 --> Input Class Initialized
INFO - 2021-08-09 11:06:14 --> Language Class Initialized
INFO - 2021-08-09 11:06:14 --> Loader Class Initialized
INFO - 2021-08-09 11:06:14 --> Helper loaded: url_helper
INFO - 2021-08-09 11:06:14 --> Helper loaded: file_helper
DEBUG - 2021-08-09 11:06:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 11:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 11:06:14 --> Controller Class Initialized
INFO - 2021-08-09 11:06:14 --> Helper loaded: cookie_helper
INFO - 2021-08-09 11:06:14 --> Model "CookieModel" initialized
INFO - 2021-08-09 11:06:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 11:06:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/team.php
INFO - 2021-08-09 11:06:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 11:06:14 --> Final output sent to browser
DEBUG - 2021-08-09 11:06:14 --> Total execution time: 0.0402
INFO - 2021-08-09 11:06:26 --> Config Class Initialized
INFO - 2021-08-09 11:06:26 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:06:26 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:06:26 --> Utf8 Class Initialized
INFO - 2021-08-09 11:06:26 --> URI Class Initialized
INFO - 2021-08-09 11:06:26 --> Router Class Initialized
INFO - 2021-08-09 11:06:26 --> Output Class Initialized
INFO - 2021-08-09 11:06:26 --> Security Class Initialized
DEBUG - 2021-08-09 11:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:06:26 --> Input Class Initialized
INFO - 2021-08-09 11:06:26 --> Language Class Initialized
INFO - 2021-08-09 11:06:26 --> Loader Class Initialized
INFO - 2021-08-09 11:06:26 --> Helper loaded: url_helper
INFO - 2021-08-09 11:06:26 --> Helper loaded: file_helper
DEBUG - 2021-08-09 11:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 11:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 11:06:26 --> Controller Class Initialized
INFO - 2021-08-09 11:06:26 --> Helper loaded: cookie_helper
INFO - 2021-08-09 11:06:26 --> Model "CookieModel" initialized
INFO - 2021-08-09 11:06:26 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 11:06:26 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/team.php
INFO - 2021-08-09 11:06:26 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 11:06:26 --> Final output sent to browser
DEBUG - 2021-08-09 11:06:26 --> Total execution time: 0.0368
INFO - 2021-08-09 11:06:27 --> Config Class Initialized
INFO - 2021-08-09 11:06:27 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:06:27 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:06:27 --> Utf8 Class Initialized
INFO - 2021-08-09 11:06:27 --> URI Class Initialized
INFO - 2021-08-09 11:06:27 --> Router Class Initialized
INFO - 2021-08-09 11:06:27 --> Output Class Initialized
INFO - 2021-08-09 11:06:27 --> Security Class Initialized
DEBUG - 2021-08-09 11:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:06:27 --> Input Class Initialized
INFO - 2021-08-09 11:06:27 --> Language Class Initialized
INFO - 2021-08-09 11:06:27 --> Loader Class Initialized
INFO - 2021-08-09 11:06:27 --> Helper loaded: url_helper
INFO - 2021-08-09 11:06:27 --> Helper loaded: file_helper
DEBUG - 2021-08-09 11:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 11:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 11:06:27 --> Controller Class Initialized
INFO - 2021-08-09 11:06:27 --> Helper loaded: cookie_helper
INFO - 2021-08-09 11:06:27 --> Model "CookieModel" initialized
INFO - 2021-08-09 11:06:27 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 11:06:27 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/team.php
INFO - 2021-08-09 11:06:27 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 11:06:27 --> Final output sent to browser
DEBUG - 2021-08-09 11:06:27 --> Total execution time: 0.0331
INFO - 2021-08-09 11:08:21 --> Config Class Initialized
INFO - 2021-08-09 11:08:21 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:08:21 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:08:21 --> Utf8 Class Initialized
INFO - 2021-08-09 11:08:21 --> URI Class Initialized
INFO - 2021-08-09 11:08:21 --> Router Class Initialized
INFO - 2021-08-09 11:08:21 --> Output Class Initialized
INFO - 2021-08-09 11:08:21 --> Security Class Initialized
DEBUG - 2021-08-09 11:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:08:21 --> Input Class Initialized
INFO - 2021-08-09 11:08:21 --> Language Class Initialized
INFO - 2021-08-09 11:08:21 --> Loader Class Initialized
INFO - 2021-08-09 11:08:21 --> Helper loaded: url_helper
INFO - 2021-08-09 11:08:21 --> Helper loaded: file_helper
DEBUG - 2021-08-09 11:08:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 11:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 11:08:21 --> Controller Class Initialized
INFO - 2021-08-09 11:08:21 --> Helper loaded: cookie_helper
INFO - 2021-08-09 11:08:21 --> Model "CookieModel" initialized
INFO - 2021-08-09 11:08:21 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 11:08:21 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/team.php
INFO - 2021-08-09 11:08:21 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 11:08:21 --> Final output sent to browser
DEBUG - 2021-08-09 11:08:21 --> Total execution time: 0.0368
INFO - 2021-08-09 11:08:40 --> Config Class Initialized
INFO - 2021-08-09 11:08:40 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:08:40 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:08:40 --> Utf8 Class Initialized
INFO - 2021-08-09 11:08:40 --> URI Class Initialized
INFO - 2021-08-09 11:08:40 --> Router Class Initialized
INFO - 2021-08-09 11:08:40 --> Output Class Initialized
INFO - 2021-08-09 11:08:40 --> Security Class Initialized
DEBUG - 2021-08-09 11:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:08:40 --> Input Class Initialized
INFO - 2021-08-09 11:08:40 --> Language Class Initialized
INFO - 2021-08-09 11:08:40 --> Loader Class Initialized
INFO - 2021-08-09 11:08:40 --> Helper loaded: url_helper
INFO - 2021-08-09 11:08:40 --> Helper loaded: file_helper
DEBUG - 2021-08-09 11:08:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 11:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 11:08:40 --> Controller Class Initialized
INFO - 2021-08-09 11:08:40 --> Helper loaded: cookie_helper
INFO - 2021-08-09 11:08:40 --> Model "CookieModel" initialized
INFO - 2021-08-09 11:08:40 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 11:08:40 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/team.php
INFO - 2021-08-09 11:08:40 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 11:08:40 --> Final output sent to browser
DEBUG - 2021-08-09 11:08:40 --> Total execution time: 0.0419
INFO - 2021-08-09 11:13:58 --> Config Class Initialized
INFO - 2021-08-09 11:13:58 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:13:58 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:13:58 --> Utf8 Class Initialized
INFO - 2021-08-09 11:13:58 --> URI Class Initialized
INFO - 2021-08-09 11:13:58 --> Router Class Initialized
INFO - 2021-08-09 11:13:58 --> Output Class Initialized
INFO - 2021-08-09 11:13:58 --> Security Class Initialized
DEBUG - 2021-08-09 11:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:13:58 --> Input Class Initialized
INFO - 2021-08-09 11:13:58 --> Language Class Initialized
INFO - 2021-08-09 11:13:58 --> Loader Class Initialized
INFO - 2021-08-09 11:13:58 --> Helper loaded: url_helper
INFO - 2021-08-09 11:13:58 --> Helper loaded: file_helper
DEBUG - 2021-08-09 11:13:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 11:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 11:13:58 --> Controller Class Initialized
INFO - 2021-08-09 11:13:58 --> Helper loaded: cookie_helper
INFO - 2021-08-09 11:13:58 --> Model "CookieModel" initialized
INFO - 2021-08-09 11:13:58 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 11:13:58 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/team.php
INFO - 2021-08-09 11:13:58 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 11:13:58 --> Final output sent to browser
DEBUG - 2021-08-09 11:13:58 --> Total execution time: 0.0469
INFO - 2021-08-09 11:14:11 --> Config Class Initialized
INFO - 2021-08-09 11:14:11 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:14:11 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:14:11 --> Utf8 Class Initialized
INFO - 2021-08-09 11:14:11 --> URI Class Initialized
INFO - 2021-08-09 11:14:11 --> Router Class Initialized
INFO - 2021-08-09 11:14:11 --> Output Class Initialized
INFO - 2021-08-09 11:14:11 --> Security Class Initialized
DEBUG - 2021-08-09 11:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:14:11 --> Input Class Initialized
INFO - 2021-08-09 11:14:11 --> Language Class Initialized
INFO - 2021-08-09 11:14:11 --> Loader Class Initialized
INFO - 2021-08-09 11:14:11 --> Helper loaded: url_helper
INFO - 2021-08-09 11:14:11 --> Helper loaded: file_helper
DEBUG - 2021-08-09 11:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 11:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 11:14:11 --> Controller Class Initialized
INFO - 2021-08-09 11:14:11 --> Helper loaded: cookie_helper
INFO - 2021-08-09 11:14:11 --> Model "CookieModel" initialized
INFO - 2021-08-09 11:14:11 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 11:14:11 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/team.php
INFO - 2021-08-09 11:14:11 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 11:14:11 --> Final output sent to browser
DEBUG - 2021-08-09 11:14:11 --> Total execution time: 0.0375
INFO - 2021-08-09 11:14:13 --> Config Class Initialized
INFO - 2021-08-09 11:14:13 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:14:13 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:14:13 --> Utf8 Class Initialized
INFO - 2021-08-09 11:14:13 --> URI Class Initialized
INFO - 2021-08-09 11:14:13 --> Router Class Initialized
INFO - 2021-08-09 11:14:13 --> Output Class Initialized
INFO - 2021-08-09 11:14:13 --> Security Class Initialized
DEBUG - 2021-08-09 11:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:14:13 --> Input Class Initialized
INFO - 2021-08-09 11:14:13 --> Language Class Initialized
INFO - 2021-08-09 11:14:13 --> Loader Class Initialized
INFO - 2021-08-09 11:14:13 --> Helper loaded: url_helper
INFO - 2021-08-09 11:14:13 --> Helper loaded: file_helper
DEBUG - 2021-08-09 11:14:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 11:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 11:14:13 --> Controller Class Initialized
INFO - 2021-08-09 11:14:13 --> Helper loaded: cookie_helper
INFO - 2021-08-09 11:14:13 --> Model "CookieModel" initialized
INFO - 2021-08-09 11:14:13 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 11:14:13 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/team.php
INFO - 2021-08-09 11:14:13 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 11:14:13 --> Final output sent to browser
DEBUG - 2021-08-09 11:14:13 --> Total execution time: 0.0405
INFO - 2021-08-09 11:14:37 --> Config Class Initialized
INFO - 2021-08-09 11:14:37 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:14:37 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:14:37 --> Utf8 Class Initialized
INFO - 2021-08-09 11:14:37 --> URI Class Initialized
INFO - 2021-08-09 11:14:37 --> Config Class Initialized
INFO - 2021-08-09 11:14:37 --> Hooks Class Initialized
INFO - 2021-08-09 11:14:37 --> Router Class Initialized
DEBUG - 2021-08-09 11:14:37 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:14:37 --> Config Class Initialized
INFO - 2021-08-09 11:14:37 --> Utf8 Class Initialized
INFO - 2021-08-09 11:14:37 --> Hooks Class Initialized
INFO - 2021-08-09 11:14:37 --> Output Class Initialized
INFO - 2021-08-09 11:14:37 --> URI Class Initialized
INFO - 2021-08-09 11:14:37 --> Security Class Initialized
DEBUG - 2021-08-09 11:14:37 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:14:37 --> Router Class Initialized
DEBUG - 2021-08-09 11:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:14:37 --> Utf8 Class Initialized
INFO - 2021-08-09 11:14:37 --> Input Class Initialized
INFO - 2021-08-09 11:14:37 --> Language Class Initialized
INFO - 2021-08-09 11:14:37 --> URI Class Initialized
INFO - 2021-08-09 11:14:37 --> Output Class Initialized
ERROR - 2021-08-09 11:14:37 --> 404 Page Not Found: Assets/js
INFO - 2021-08-09 11:14:37 --> Router Class Initialized
INFO - 2021-08-09 11:14:37 --> Security Class Initialized
INFO - 2021-08-09 11:14:37 --> Output Class Initialized
DEBUG - 2021-08-09 11:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:14:37 --> Input Class Initialized
INFO - 2021-08-09 11:14:37 --> Security Class Initialized
INFO - 2021-08-09 11:14:37 --> Language Class Initialized
ERROR - 2021-08-09 11:14:37 --> 404 Page Not Found: Assets/js
DEBUG - 2021-08-09 11:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:14:37 --> Input Class Initialized
INFO - 2021-08-09 11:14:37 --> Language Class Initialized
ERROR - 2021-08-09 11:14:37 --> 404 Page Not Found: Assets/js
INFO - 2021-08-09 11:14:37 --> Config Class Initialized
INFO - 2021-08-09 11:14:37 --> Hooks Class Initialized
INFO - 2021-08-09 11:14:37 --> Config Class Initialized
INFO - 2021-08-09 11:14:37 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:14:37 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:14:37 --> Utf8 Class Initialized
INFO - 2021-08-09 11:14:37 --> URI Class Initialized
DEBUG - 2021-08-09 11:14:37 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:14:37 --> Utf8 Class Initialized
INFO - 2021-08-09 11:14:37 --> Router Class Initialized
INFO - 2021-08-09 11:14:37 --> URI Class Initialized
INFO - 2021-08-09 11:14:37 --> Output Class Initialized
INFO - 2021-08-09 11:14:37 --> Router Class Initialized
INFO - 2021-08-09 11:14:37 --> Security Class Initialized
INFO - 2021-08-09 11:14:38 --> Output Class Initialized
DEBUG - 2021-08-09 11:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:14:38 --> Input Class Initialized
INFO - 2021-08-09 11:14:38 --> Language Class Initialized
INFO - 2021-08-09 11:14:38 --> Security Class Initialized
ERROR - 2021-08-09 11:14:38 --> 404 Page Not Found: Assets/css
DEBUG - 2021-08-09 11:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:14:38 --> Input Class Initialized
INFO - 2021-08-09 11:14:38 --> Language Class Initialized
ERROR - 2021-08-09 11:14:38 --> 404 Page Not Found: Assets/css
INFO - 2021-08-09 11:14:42 --> Config Class Initialized
INFO - 2021-08-09 11:14:42 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:14:42 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:14:42 --> Utf8 Class Initialized
INFO - 2021-08-09 11:14:42 --> Config Class Initialized
INFO - 2021-08-09 11:14:42 --> Hooks Class Initialized
INFO - 2021-08-09 11:14:42 --> URI Class Initialized
INFO - 2021-08-09 11:14:42 --> Router Class Initialized
DEBUG - 2021-08-09 11:14:42 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:14:42 --> Utf8 Class Initialized
INFO - 2021-08-09 11:14:42 --> URI Class Initialized
INFO - 2021-08-09 11:14:42 --> Output Class Initialized
INFO - 2021-08-09 11:14:42 --> Router Class Initialized
INFO - 2021-08-09 11:14:42 --> Security Class Initialized
DEBUG - 2021-08-09 11:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:14:42 --> Input Class Initialized
INFO - 2021-08-09 11:14:42 --> Output Class Initialized
INFO - 2021-08-09 11:14:42 --> Language Class Initialized
INFO - 2021-08-09 11:14:42 --> Security Class Initialized
ERROR - 2021-08-09 11:14:42 --> 404 Page Not Found: Assets/css
DEBUG - 2021-08-09 11:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:14:42 --> Input Class Initialized
INFO - 2021-08-09 11:14:42 --> Language Class Initialized
ERROR - 2021-08-09 11:14:42 --> 404 Page Not Found: Assets/css
INFO - 2021-08-09 11:14:42 --> Config Class Initialized
INFO - 2021-08-09 11:14:42 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:14:42 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:14:42 --> Utf8 Class Initialized
INFO - 2021-08-09 11:14:42 --> Config Class Initialized
INFO - 2021-08-09 11:14:42 --> URI Class Initialized
INFO - 2021-08-09 11:14:42 --> Hooks Class Initialized
INFO - 2021-08-09 11:14:42 --> Router Class Initialized
DEBUG - 2021-08-09 11:14:42 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:14:42 --> Config Class Initialized
INFO - 2021-08-09 11:14:42 --> Utf8 Class Initialized
INFO - 2021-08-09 11:14:42 --> Hooks Class Initialized
INFO - 2021-08-09 11:14:42 --> Output Class Initialized
INFO - 2021-08-09 11:14:42 --> URI Class Initialized
INFO - 2021-08-09 11:14:42 --> Router Class Initialized
INFO - 2021-08-09 11:14:42 --> Security Class Initialized
DEBUG - 2021-08-09 11:14:42 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:14:42 --> Utf8 Class Initialized
INFO - 2021-08-09 11:14:42 --> URI Class Initialized
INFO - 2021-08-09 11:14:42 --> Output Class Initialized
INFO - 2021-08-09 11:14:42 --> Router Class Initialized
INFO - 2021-08-09 11:14:42 --> Security Class Initialized
DEBUG - 2021-08-09 11:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-08-09 11:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:14:42 --> Input Class Initialized
INFO - 2021-08-09 11:14:42 --> Input Class Initialized
INFO - 2021-08-09 11:14:42 --> Output Class Initialized
INFO - 2021-08-09 11:14:42 --> Language Class Initialized
INFO - 2021-08-09 11:14:42 --> Language Class Initialized
INFO - 2021-08-09 11:14:42 --> Security Class Initialized
ERROR - 2021-08-09 11:14:42 --> 404 Page Not Found: Assets/js
ERROR - 2021-08-09 11:14:42 --> 404 Page Not Found: Assets/js
DEBUG - 2021-08-09 11:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:14:42 --> Input Class Initialized
INFO - 2021-08-09 11:14:42 --> Language Class Initialized
ERROR - 2021-08-09 11:14:42 --> 404 Page Not Found: Assets/js
INFO - 2021-08-09 11:15:32 --> Config Class Initialized
INFO - 2021-08-09 11:15:32 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:15:32 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:15:32 --> Utf8 Class Initialized
INFO - 2021-08-09 11:15:32 --> URI Class Initialized
INFO - 2021-08-09 11:15:32 --> Router Class Initialized
INFO - 2021-08-09 11:15:32 --> Output Class Initialized
INFO - 2021-08-09 11:15:32 --> Security Class Initialized
DEBUG - 2021-08-09 11:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:15:32 --> Input Class Initialized
INFO - 2021-08-09 11:15:32 --> Language Class Initialized
INFO - 2021-08-09 11:15:32 --> Loader Class Initialized
INFO - 2021-08-09 11:15:32 --> Helper loaded: url_helper
INFO - 2021-08-09 11:15:32 --> Helper loaded: file_helper
DEBUG - 2021-08-09 11:15:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 11:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 11:15:32 --> Controller Class Initialized
INFO - 2021-08-09 11:15:32 --> Helper loaded: cookie_helper
INFO - 2021-08-09 11:15:32 --> Model "CookieModel" initialized
INFO - 2021-08-09 11:15:32 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 11:15:32 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/team.php
INFO - 2021-08-09 11:15:32 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 11:15:32 --> Final output sent to browser
DEBUG - 2021-08-09 11:15:32 --> Total execution time: 0.0372
INFO - 2021-08-09 11:15:33 --> Config Class Initialized
INFO - 2021-08-09 11:15:33 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:15:33 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:15:33 --> Utf8 Class Initialized
INFO - 2021-08-09 11:15:33 --> Config Class Initialized
INFO - 2021-08-09 11:15:33 --> Hooks Class Initialized
INFO - 2021-08-09 11:15:33 --> URI Class Initialized
INFO - 2021-08-09 11:15:33 --> Router Class Initialized
DEBUG - 2021-08-09 11:15:33 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:15:33 --> Utf8 Class Initialized
INFO - 2021-08-09 11:15:33 --> Output Class Initialized
INFO - 2021-08-09 11:15:33 --> URI Class Initialized
INFO - 2021-08-09 11:15:33 --> Router Class Initialized
INFO - 2021-08-09 11:15:33 --> Security Class Initialized
DEBUG - 2021-08-09 11:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:15:33 --> Input Class Initialized
INFO - 2021-08-09 11:15:33 --> Output Class Initialized
INFO - 2021-08-09 11:15:33 --> Language Class Initialized
INFO - 2021-08-09 11:15:33 --> Security Class Initialized
ERROR - 2021-08-09 11:15:33 --> 404 Page Not Found: Assets/css
DEBUG - 2021-08-09 11:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:15:33 --> Input Class Initialized
INFO - 2021-08-09 11:15:33 --> Language Class Initialized
ERROR - 2021-08-09 11:15:33 --> 404 Page Not Found: Assets/css
INFO - 2021-08-09 11:15:33 --> Config Class Initialized
INFO - 2021-08-09 11:15:33 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:15:33 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:15:33 --> Utf8 Class Initialized
INFO - 2021-08-09 11:15:33 --> URI Class Initialized
INFO - 2021-08-09 11:15:33 --> Router Class Initialized
INFO - 2021-08-09 11:15:33 --> Output Class Initialized
INFO - 2021-08-09 11:15:33 --> Security Class Initialized
INFO - 2021-08-09 11:15:33 --> Config Class Initialized
INFO - 2021-08-09 11:15:33 --> Config Class Initialized
INFO - 2021-08-09 11:15:33 --> Hooks Class Initialized
INFO - 2021-08-09 11:15:33 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:15:33 --> Input Class Initialized
INFO - 2021-08-09 11:15:33 --> Language Class Initialized
DEBUG - 2021-08-09 11:15:33 --> UTF-8 Support Enabled
DEBUG - 2021-08-09 11:15:33 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:15:33 --> Utf8 Class Initialized
INFO - 2021-08-09 11:15:33 --> Utf8 Class Initialized
INFO - 2021-08-09 11:15:33 --> URI Class Initialized
INFO - 2021-08-09 11:15:33 --> URI Class Initialized
INFO - 2021-08-09 11:15:33 --> Router Class Initialized
ERROR - 2021-08-09 11:15:33 --> 404 Page Not Found: Assets/js
INFO - 2021-08-09 11:15:33 --> Router Class Initialized
INFO - 2021-08-09 11:15:33 --> Output Class Initialized
INFO - 2021-08-09 11:15:33 --> Output Class Initialized
INFO - 2021-08-09 11:15:33 --> Security Class Initialized
INFO - 2021-08-09 11:15:33 --> Security Class Initialized
DEBUG - 2021-08-09 11:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:15:33 --> Input Class Initialized
INFO - 2021-08-09 11:15:33 --> Language Class Initialized
DEBUG - 2021-08-09 11:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:15:33 --> Input Class Initialized
INFO - 2021-08-09 11:15:33 --> Language Class Initialized
ERROR - 2021-08-09 11:15:33 --> 404 Page Not Found: Assets/js
ERROR - 2021-08-09 11:15:33 --> 404 Page Not Found: Assets/js
INFO - 2021-08-09 11:16:03 --> Config Class Initialized
INFO - 2021-08-09 11:16:03 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:16:03 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:16:03 --> Utf8 Class Initialized
INFO - 2021-08-09 11:16:03 --> URI Class Initialized
INFO - 2021-08-09 11:16:03 --> Router Class Initialized
INFO - 2021-08-09 11:16:03 --> Output Class Initialized
INFO - 2021-08-09 11:16:03 --> Security Class Initialized
DEBUG - 2021-08-09 11:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:16:03 --> Input Class Initialized
INFO - 2021-08-09 11:16:03 --> Language Class Initialized
INFO - 2021-08-09 11:16:03 --> Loader Class Initialized
INFO - 2021-08-09 11:16:03 --> Helper loaded: url_helper
INFO - 2021-08-09 11:16:03 --> Helper loaded: file_helper
DEBUG - 2021-08-09 11:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 11:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 11:16:03 --> Controller Class Initialized
INFO - 2021-08-09 11:16:03 --> Helper loaded: cookie_helper
INFO - 2021-08-09 11:16:03 --> Model "CookieModel" initialized
INFO - 2021-08-09 11:16:03 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 11:16:03 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/pilates.php
INFO - 2021-08-09 11:16:03 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 11:16:03 --> Final output sent to browser
DEBUG - 2021-08-09 11:16:03 --> Total execution time: 0.0388
INFO - 2021-08-09 11:16:12 --> Config Class Initialized
INFO - 2021-08-09 11:16:12 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:16:12 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:16:12 --> Utf8 Class Initialized
INFO - 2021-08-09 11:16:12 --> URI Class Initialized
DEBUG - 2021-08-09 11:16:13 --> No URI present. Default controller set.
INFO - 2021-08-09 11:16:13 --> Router Class Initialized
INFO - 2021-08-09 11:16:13 --> Output Class Initialized
INFO - 2021-08-09 11:16:13 --> Security Class Initialized
DEBUG - 2021-08-09 11:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:16:13 --> Input Class Initialized
INFO - 2021-08-09 11:16:13 --> Language Class Initialized
INFO - 2021-08-09 11:16:13 --> Loader Class Initialized
INFO - 2021-08-09 11:16:13 --> Helper loaded: url_helper
INFO - 2021-08-09 11:16:13 --> Helper loaded: file_helper
DEBUG - 2021-08-09 11:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 11:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 11:16:13 --> Controller Class Initialized
INFO - 2021-08-09 11:16:13 --> Helper loaded: cookie_helper
INFO - 2021-08-09 11:16:13 --> Model "CookieModel" initialized
INFO - 2021-08-09 11:16:13 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 11:16:13 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-09 11:16:13 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 11:16:13 --> Final output sent to browser
DEBUG - 2021-08-09 11:16:13 --> Total execution time: 0.0451
INFO - 2021-08-09 11:16:28 --> Config Class Initialized
INFO - 2021-08-09 11:16:28 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:16:28 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:16:28 --> Utf8 Class Initialized
INFO - 2021-08-09 11:16:28 --> URI Class Initialized
INFO - 2021-08-09 11:16:28 --> Router Class Initialized
INFO - 2021-08-09 11:16:28 --> Output Class Initialized
INFO - 2021-08-09 11:16:28 --> Security Class Initialized
DEBUG - 2021-08-09 11:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:16:28 --> Input Class Initialized
INFO - 2021-08-09 11:16:28 --> Language Class Initialized
INFO - 2021-08-09 11:16:28 --> Loader Class Initialized
INFO - 2021-08-09 11:16:28 --> Helper loaded: url_helper
INFO - 2021-08-09 11:16:28 --> Helper loaded: file_helper
DEBUG - 2021-08-09 11:16:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 11:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 11:16:28 --> Controller Class Initialized
INFO - 2021-08-09 11:16:28 --> Helper loaded: cookie_helper
INFO - 2021-08-09 11:16:28 --> Model "CookieModel" initialized
INFO - 2021-08-09 11:16:28 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 11:16:28 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/pilates.php
INFO - 2021-08-09 11:16:28 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 11:16:28 --> Final output sent to browser
DEBUG - 2021-08-09 11:16:28 --> Total execution time: 0.0358
INFO - 2021-08-09 11:16:33 --> Config Class Initialized
INFO - 2021-08-09 11:16:33 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:16:33 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:16:33 --> Utf8 Class Initialized
INFO - 2021-08-09 11:16:33 --> URI Class Initialized
INFO - 2021-08-09 11:16:33 --> Router Class Initialized
INFO - 2021-08-09 11:16:33 --> Output Class Initialized
INFO - 2021-08-09 11:16:33 --> Security Class Initialized
DEBUG - 2021-08-09 11:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:16:33 --> Input Class Initialized
INFO - 2021-08-09 11:16:33 --> Language Class Initialized
INFO - 2021-08-09 11:16:33 --> Loader Class Initialized
INFO - 2021-08-09 11:16:33 --> Helper loaded: url_helper
INFO - 2021-08-09 11:16:33 --> Helper loaded: file_helper
DEBUG - 2021-08-09 11:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 11:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 11:16:33 --> Controller Class Initialized
INFO - 2021-08-09 11:16:33 --> Helper loaded: cookie_helper
INFO - 2021-08-09 11:16:33 --> Model "CookieModel" initialized
INFO - 2021-08-09 11:16:33 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 11:16:33 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-09 11:16:33 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 11:16:33 --> Final output sent to browser
DEBUG - 2021-08-09 11:16:33 --> Total execution time: 0.0403
INFO - 2021-08-09 11:17:37 --> Config Class Initialized
INFO - 2021-08-09 11:17:37 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:17:37 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:17:37 --> Utf8 Class Initialized
INFO - 2021-08-09 11:17:37 --> URI Class Initialized
INFO - 2021-08-09 11:17:37 --> Router Class Initialized
INFO - 2021-08-09 11:17:37 --> Output Class Initialized
INFO - 2021-08-09 11:17:37 --> Security Class Initialized
DEBUG - 2021-08-09 11:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:17:37 --> Input Class Initialized
INFO - 2021-08-09 11:17:37 --> Language Class Initialized
INFO - 2021-08-09 11:17:37 --> Loader Class Initialized
INFO - 2021-08-09 11:17:37 --> Helper loaded: url_helper
INFO - 2021-08-09 11:17:37 --> Helper loaded: file_helper
DEBUG - 2021-08-09 11:17:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 11:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 11:17:37 --> Controller Class Initialized
INFO - 2021-08-09 11:17:37 --> Helper loaded: cookie_helper
INFO - 2021-08-09 11:17:37 --> Model "CookieModel" initialized
INFO - 2021-08-09 11:17:37 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 11:17:37 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/pilates.php
INFO - 2021-08-09 11:17:37 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 11:17:37 --> Final output sent to browser
DEBUG - 2021-08-09 11:17:37 --> Total execution time: 0.0414
INFO - 2021-08-09 11:18:26 --> Config Class Initialized
INFO - 2021-08-09 11:18:26 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:18:26 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:18:26 --> Utf8 Class Initialized
INFO - 2021-08-09 11:18:26 --> URI Class Initialized
INFO - 2021-08-09 11:18:26 --> Router Class Initialized
INFO - 2021-08-09 11:18:26 --> Output Class Initialized
INFO - 2021-08-09 11:18:26 --> Security Class Initialized
DEBUG - 2021-08-09 11:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:18:26 --> Input Class Initialized
INFO - 2021-08-09 11:18:26 --> Language Class Initialized
INFO - 2021-08-09 11:18:26 --> Loader Class Initialized
INFO - 2021-08-09 11:18:26 --> Helper loaded: url_helper
INFO - 2021-08-09 11:18:26 --> Helper loaded: file_helper
DEBUG - 2021-08-09 11:18:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 11:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 11:18:26 --> Controller Class Initialized
INFO - 2021-08-09 11:18:26 --> Helper loaded: cookie_helper
INFO - 2021-08-09 11:18:26 --> Model "CookieModel" initialized
INFO - 2021-08-09 11:18:26 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 11:18:26 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/pilates.php
INFO - 2021-08-09 11:18:26 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 11:18:26 --> Final output sent to browser
DEBUG - 2021-08-09 11:18:26 --> Total execution time: 0.0500
INFO - 2021-08-09 11:18:36 --> Config Class Initialized
INFO - 2021-08-09 11:18:36 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:18:36 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:18:36 --> Utf8 Class Initialized
INFO - 2021-08-09 11:18:36 --> URI Class Initialized
INFO - 2021-08-09 11:18:36 --> Router Class Initialized
INFO - 2021-08-09 11:18:36 --> Output Class Initialized
INFO - 2021-08-09 11:18:36 --> Security Class Initialized
DEBUG - 2021-08-09 11:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:18:36 --> Input Class Initialized
INFO - 2021-08-09 11:18:36 --> Language Class Initialized
INFO - 2021-08-09 11:18:36 --> Loader Class Initialized
INFO - 2021-08-09 11:18:36 --> Helper loaded: url_helper
INFO - 2021-08-09 11:18:36 --> Helper loaded: file_helper
DEBUG - 2021-08-09 11:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 11:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 11:18:36 --> Controller Class Initialized
INFO - 2021-08-09 11:18:36 --> Helper loaded: cookie_helper
INFO - 2021-08-09 11:18:36 --> Model "CookieModel" initialized
INFO - 2021-08-09 11:18:36 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 11:18:36 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-09 11:18:36 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 11:18:36 --> Final output sent to browser
DEBUG - 2021-08-09 11:18:36 --> Total execution time: 0.0392
INFO - 2021-08-09 11:19:03 --> Config Class Initialized
INFO - 2021-08-09 11:19:03 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:19:03 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:19:03 --> Utf8 Class Initialized
INFO - 2021-08-09 11:19:03 --> URI Class Initialized
DEBUG - 2021-08-09 11:19:03 --> No URI present. Default controller set.
INFO - 2021-08-09 11:19:03 --> Router Class Initialized
INFO - 2021-08-09 11:19:03 --> Output Class Initialized
INFO - 2021-08-09 11:19:03 --> Security Class Initialized
DEBUG - 2021-08-09 11:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:19:03 --> Input Class Initialized
INFO - 2021-08-09 11:19:03 --> Language Class Initialized
INFO - 2021-08-09 11:19:03 --> Loader Class Initialized
INFO - 2021-08-09 11:19:03 --> Helper loaded: url_helper
INFO - 2021-08-09 11:19:03 --> Helper loaded: file_helper
DEBUG - 2021-08-09 11:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 11:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 11:19:03 --> Controller Class Initialized
INFO - 2021-08-09 11:19:03 --> Helper loaded: cookie_helper
INFO - 2021-08-09 11:19:03 --> Model "CookieModel" initialized
INFO - 2021-08-09 11:19:03 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 11:19:03 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-09 11:19:03 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 11:19:03 --> Final output sent to browser
DEBUG - 2021-08-09 11:19:03 --> Total execution time: 0.0389
INFO - 2021-08-09 11:19:07 --> Config Class Initialized
INFO - 2021-08-09 11:19:07 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:19:07 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:19:07 --> Utf8 Class Initialized
INFO - 2021-08-09 11:19:07 --> URI Class Initialized
INFO - 2021-08-09 11:19:07 --> Router Class Initialized
INFO - 2021-08-09 11:19:07 --> Output Class Initialized
INFO - 2021-08-09 11:19:07 --> Security Class Initialized
DEBUG - 2021-08-09 11:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:19:07 --> Input Class Initialized
INFO - 2021-08-09 11:19:07 --> Language Class Initialized
INFO - 2021-08-09 11:19:07 --> Loader Class Initialized
INFO - 2021-08-09 11:19:07 --> Helper loaded: url_helper
INFO - 2021-08-09 11:19:07 --> Helper loaded: file_helper
DEBUG - 2021-08-09 11:19:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 11:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 11:19:07 --> Controller Class Initialized
INFO - 2021-08-09 11:19:07 --> Helper loaded: cookie_helper
INFO - 2021-08-09 11:19:07 --> Model "CookieModel" initialized
INFO - 2021-08-09 11:19:07 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 11:19:07 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-09 11:19:07 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 11:19:07 --> Final output sent to browser
DEBUG - 2021-08-09 11:19:07 --> Total execution time: 0.0402
INFO - 2021-08-09 11:19:40 --> Config Class Initialized
INFO - 2021-08-09 11:19:40 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:19:40 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:19:40 --> Utf8 Class Initialized
INFO - 2021-08-09 11:19:40 --> URI Class Initialized
INFO - 2021-08-09 11:19:40 --> Router Class Initialized
INFO - 2021-08-09 11:19:40 --> Output Class Initialized
INFO - 2021-08-09 11:19:40 --> Security Class Initialized
DEBUG - 2021-08-09 11:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:19:40 --> Input Class Initialized
INFO - 2021-08-09 11:19:40 --> Language Class Initialized
INFO - 2021-08-09 11:19:40 --> Loader Class Initialized
INFO - 2021-08-09 11:19:40 --> Helper loaded: url_helper
INFO - 2021-08-09 11:19:40 --> Helper loaded: file_helper
DEBUG - 2021-08-09 11:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 11:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 11:19:40 --> Controller Class Initialized
INFO - 2021-08-09 11:19:40 --> Helper loaded: cookie_helper
INFO - 2021-08-09 11:19:40 --> Model "CookieModel" initialized
INFO - 2021-08-09 11:19:40 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 11:19:40 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-09 11:19:40 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 11:19:40 --> Final output sent to browser
DEBUG - 2021-08-09 11:19:40 --> Total execution time: 0.0457
INFO - 2021-08-09 11:19:56 --> Config Class Initialized
INFO - 2021-08-09 11:19:56 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:19:56 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:19:56 --> Utf8 Class Initialized
INFO - 2021-08-09 11:19:56 --> URI Class Initialized
INFO - 2021-08-09 11:19:56 --> Router Class Initialized
INFO - 2021-08-09 11:19:56 --> Output Class Initialized
INFO - 2021-08-09 11:19:56 --> Config Class Initialized
INFO - 2021-08-09 11:19:56 --> Security Class Initialized
INFO - 2021-08-09 11:19:56 --> Hooks Class Initialized
INFO - 2021-08-09 11:19:56 --> Config Class Initialized
INFO - 2021-08-09 11:19:56 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:19:56 --> Input Class Initialized
INFO - 2021-08-09 11:19:56 --> Language Class Initialized
DEBUG - 2021-08-09 11:19:56 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:19:56 --> Utf8 Class Initialized
ERROR - 2021-08-09 11:19:56 --> 404 Page Not Found: Assets/js
DEBUG - 2021-08-09 11:19:56 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:19:56 --> Utf8 Class Initialized
INFO - 2021-08-09 11:19:56 --> URI Class Initialized
INFO - 2021-08-09 11:19:56 --> URI Class Initialized
INFO - 2021-08-09 11:19:56 --> Router Class Initialized
INFO - 2021-08-09 11:19:56 --> Router Class Initialized
INFO - 2021-08-09 11:19:56 --> Output Class Initialized
INFO - 2021-08-09 11:19:56 --> Security Class Initialized
INFO - 2021-08-09 11:19:56 --> Output Class Initialized
DEBUG - 2021-08-09 11:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:19:56 --> Input Class Initialized
INFO - 2021-08-09 11:19:56 --> Security Class Initialized
INFO - 2021-08-09 11:19:56 --> Language Class Initialized
DEBUG - 2021-08-09 11:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:19:56 --> Input Class Initialized
ERROR - 2021-08-09 11:19:56 --> 404 Page Not Found: Assets/js
INFO - 2021-08-09 11:19:56 --> Language Class Initialized
ERROR - 2021-08-09 11:19:56 --> 404 Page Not Found: Assets/js
INFO - 2021-08-09 11:19:56 --> Config Class Initialized
INFO - 2021-08-09 11:19:56 --> Hooks Class Initialized
INFO - 2021-08-09 11:19:56 --> Config Class Initialized
INFO - 2021-08-09 11:19:56 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:19:56 --> UTF-8 Support Enabled
DEBUG - 2021-08-09 11:19:56 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:19:56 --> Utf8 Class Initialized
INFO - 2021-08-09 11:19:56 --> Utf8 Class Initialized
INFO - 2021-08-09 11:19:56 --> URI Class Initialized
INFO - 2021-08-09 11:19:56 --> URI Class Initialized
INFO - 2021-08-09 11:19:56 --> Router Class Initialized
INFO - 2021-08-09 11:19:56 --> Router Class Initialized
INFO - 2021-08-09 11:19:56 --> Output Class Initialized
INFO - 2021-08-09 11:19:56 --> Output Class Initialized
INFO - 2021-08-09 11:19:56 --> Security Class Initialized
INFO - 2021-08-09 11:19:56 --> Security Class Initialized
DEBUG - 2021-08-09 11:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-08-09 11:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:19:56 --> Input Class Initialized
INFO - 2021-08-09 11:19:56 --> Input Class Initialized
INFO - 2021-08-09 11:19:56 --> Language Class Initialized
INFO - 2021-08-09 11:19:56 --> Language Class Initialized
ERROR - 2021-08-09 11:19:56 --> 404 Page Not Found: Assets/css
ERROR - 2021-08-09 11:19:56 --> 404 Page Not Found: Assets/css
INFO - 2021-08-09 11:19:59 --> Config Class Initialized
INFO - 2021-08-09 11:19:59 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:19:59 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:19:59 --> Utf8 Class Initialized
INFO - 2021-08-09 11:19:59 --> URI Class Initialized
INFO - 2021-08-09 11:19:59 --> Router Class Initialized
INFO - 2021-08-09 11:19:59 --> Output Class Initialized
INFO - 2021-08-09 11:19:59 --> Security Class Initialized
DEBUG - 2021-08-09 11:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:19:59 --> Input Class Initialized
INFO - 2021-08-09 11:19:59 --> Language Class Initialized
INFO - 2021-08-09 11:19:59 --> Loader Class Initialized
INFO - 2021-08-09 11:19:59 --> Helper loaded: url_helper
INFO - 2021-08-09 11:19:59 --> Helper loaded: file_helper
DEBUG - 2021-08-09 11:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 11:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 11:19:59 --> Controller Class Initialized
INFO - 2021-08-09 11:19:59 --> Helper loaded: cookie_helper
INFO - 2021-08-09 11:19:59 --> Model "CookieModel" initialized
INFO - 2021-08-09 11:19:59 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 11:19:59 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-09 11:19:59 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 11:19:59 --> Final output sent to browser
DEBUG - 2021-08-09 11:19:59 --> Total execution time: 0.0390
INFO - 2021-08-09 11:20:00 --> Config Class Initialized
INFO - 2021-08-09 11:20:00 --> Config Class Initialized
INFO - 2021-08-09 11:20:00 --> Hooks Class Initialized
INFO - 2021-08-09 11:20:00 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:20:00 --> UTF-8 Support Enabled
DEBUG - 2021-08-09 11:20:00 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:20:00 --> Utf8 Class Initialized
INFO - 2021-08-09 11:20:00 --> Utf8 Class Initialized
INFO - 2021-08-09 11:20:00 --> URI Class Initialized
INFO - 2021-08-09 11:20:00 --> URI Class Initialized
INFO - 2021-08-09 11:20:00 --> Router Class Initialized
INFO - 2021-08-09 11:20:00 --> Router Class Initialized
INFO - 2021-08-09 11:20:00 --> Output Class Initialized
INFO - 2021-08-09 11:20:00 --> Output Class Initialized
INFO - 2021-08-09 11:20:00 --> Security Class Initialized
INFO - 2021-08-09 11:20:00 --> Security Class Initialized
DEBUG - 2021-08-09 11:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-08-09 11:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:20:00 --> Input Class Initialized
INFO - 2021-08-09 11:20:00 --> Language Class Initialized
ERROR - 2021-08-09 11:20:00 --> 404 Page Not Found: Assets/css
INFO - 2021-08-09 11:20:00 --> Input Class Initialized
INFO - 2021-08-09 11:20:00 --> Language Class Initialized
ERROR - 2021-08-09 11:20:00 --> 404 Page Not Found: Assets/css
INFO - 2021-08-09 11:20:00 --> Config Class Initialized
INFO - 2021-08-09 11:20:00 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:20:00 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:20:00 --> Utf8 Class Initialized
INFO - 2021-08-09 11:20:00 --> URI Class Initialized
INFO - 2021-08-09 11:20:00 --> Router Class Initialized
INFO - 2021-08-09 11:20:00 --> Config Class Initialized
INFO - 2021-08-09 11:20:00 --> Hooks Class Initialized
INFO - 2021-08-09 11:20:00 --> Config Class Initialized
INFO - 2021-08-09 11:20:00 --> Hooks Class Initialized
INFO - 2021-08-09 11:20:00 --> Output Class Initialized
INFO - 2021-08-09 11:20:00 --> Security Class Initialized
DEBUG - 2021-08-09 11:20:00 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:20:00 --> Utf8 Class Initialized
DEBUG - 2021-08-09 11:20:00 --> UTF-8 Support Enabled
DEBUG - 2021-08-09 11:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:20:00 --> Utf8 Class Initialized
INFO - 2021-08-09 11:20:00 --> Input Class Initialized
INFO - 2021-08-09 11:20:00 --> URI Class Initialized
INFO - 2021-08-09 11:20:00 --> Language Class Initialized
INFO - 2021-08-09 11:20:00 --> URI Class Initialized
ERROR - 2021-08-09 11:20:00 --> 404 Page Not Found: Assets/js
INFO - 2021-08-09 11:20:00 --> Router Class Initialized
INFO - 2021-08-09 11:20:00 --> Router Class Initialized
INFO - 2021-08-09 11:20:00 --> Output Class Initialized
INFO - 2021-08-09 11:20:00 --> Output Class Initialized
INFO - 2021-08-09 11:20:00 --> Security Class Initialized
INFO - 2021-08-09 11:20:00 --> Security Class Initialized
DEBUG - 2021-08-09 11:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-08-09 11:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:20:00 --> Input Class Initialized
INFO - 2021-08-09 11:20:00 --> Input Class Initialized
INFO - 2021-08-09 11:20:00 --> Language Class Initialized
INFO - 2021-08-09 11:20:00 --> Language Class Initialized
ERROR - 2021-08-09 11:20:00 --> 404 Page Not Found: Assets/js
ERROR - 2021-08-09 11:20:00 --> 404 Page Not Found: Assets/js
INFO - 2021-08-09 11:20:31 --> Config Class Initialized
INFO - 2021-08-09 11:20:31 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:20:31 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:20:31 --> Utf8 Class Initialized
INFO - 2021-08-09 11:20:31 --> URI Class Initialized
INFO - 2021-08-09 11:20:31 --> Router Class Initialized
INFO - 2021-08-09 11:20:31 --> Output Class Initialized
INFO - 2021-08-09 11:20:31 --> Security Class Initialized
DEBUG - 2021-08-09 11:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:20:31 --> Input Class Initialized
INFO - 2021-08-09 11:20:31 --> Language Class Initialized
INFO - 2021-08-09 11:20:31 --> Loader Class Initialized
INFO - 2021-08-09 11:20:31 --> Helper loaded: url_helper
INFO - 2021-08-09 11:20:31 --> Helper loaded: file_helper
DEBUG - 2021-08-09 11:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 11:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 11:20:31 --> Controller Class Initialized
INFO - 2021-08-09 11:20:31 --> Helper loaded: cookie_helper
INFO - 2021-08-09 11:20:31 --> Model "CookieModel" initialized
INFO - 2021-08-09 11:20:31 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 11:20:31 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-09 11:20:31 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 11:20:31 --> Final output sent to browser
DEBUG - 2021-08-09 11:20:31 --> Total execution time: 0.0390
INFO - 2021-08-09 11:21:00 --> Config Class Initialized
INFO - 2021-08-09 11:21:00 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:21:00 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:21:00 --> Utf8 Class Initialized
INFO - 2021-08-09 11:21:00 --> URI Class Initialized
INFO - 2021-08-09 11:21:00 --> Router Class Initialized
INFO - 2021-08-09 11:21:00 --> Output Class Initialized
INFO - 2021-08-09 11:21:00 --> Security Class Initialized
DEBUG - 2021-08-09 11:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:21:00 --> Input Class Initialized
INFO - 2021-08-09 11:21:00 --> Language Class Initialized
INFO - 2021-08-09 11:21:00 --> Loader Class Initialized
INFO - 2021-08-09 11:21:00 --> Helper loaded: url_helper
INFO - 2021-08-09 11:21:00 --> Helper loaded: file_helper
DEBUG - 2021-08-09 11:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 11:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 11:21:00 --> Controller Class Initialized
INFO - 2021-08-09 11:21:00 --> Helper loaded: cookie_helper
INFO - 2021-08-09 11:21:00 --> Model "CookieModel" initialized
INFO - 2021-08-09 11:21:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 11:21:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-09 11:21:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 11:21:00 --> Final output sent to browser
DEBUG - 2021-08-09 11:21:00 --> Total execution time: 0.0448
INFO - 2021-08-09 11:23:17 --> Config Class Initialized
INFO - 2021-08-09 11:23:17 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:23:17 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:23:17 --> Utf8 Class Initialized
INFO - 2021-08-09 11:23:17 --> URI Class Initialized
INFO - 2021-08-09 11:23:17 --> Router Class Initialized
INFO - 2021-08-09 11:23:17 --> Output Class Initialized
INFO - 2021-08-09 11:23:17 --> Security Class Initialized
DEBUG - 2021-08-09 11:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:23:17 --> Input Class Initialized
INFO - 2021-08-09 11:23:17 --> Language Class Initialized
INFO - 2021-08-09 11:23:17 --> Loader Class Initialized
INFO - 2021-08-09 11:23:17 --> Helper loaded: url_helper
INFO - 2021-08-09 11:23:17 --> Helper loaded: file_helper
DEBUG - 2021-08-09 11:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 11:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 11:23:17 --> Controller Class Initialized
INFO - 2021-08-09 11:23:17 --> Helper loaded: cookie_helper
INFO - 2021-08-09 11:23:17 --> Model "CookieModel" initialized
INFO - 2021-08-09 11:23:17 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 11:23:17 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-09 11:23:17 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 11:23:17 --> Final output sent to browser
DEBUG - 2021-08-09 11:23:17 --> Total execution time: 0.0348
INFO - 2021-08-09 11:23:48 --> Config Class Initialized
INFO - 2021-08-09 11:23:48 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:23:48 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:23:48 --> Utf8 Class Initialized
INFO - 2021-08-09 11:23:48 --> URI Class Initialized
INFO - 2021-08-09 11:23:48 --> Router Class Initialized
INFO - 2021-08-09 11:23:48 --> Output Class Initialized
INFO - 2021-08-09 11:23:48 --> Security Class Initialized
DEBUG - 2021-08-09 11:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:23:48 --> Input Class Initialized
INFO - 2021-08-09 11:23:48 --> Language Class Initialized
INFO - 2021-08-09 11:23:48 --> Loader Class Initialized
INFO - 2021-08-09 11:23:48 --> Helper loaded: url_helper
INFO - 2021-08-09 11:23:48 --> Helper loaded: file_helper
DEBUG - 2021-08-09 11:23:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 11:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 11:23:48 --> Controller Class Initialized
INFO - 2021-08-09 11:23:48 --> Helper loaded: cookie_helper
INFO - 2021-08-09 11:23:48 --> Model "CookieModel" initialized
INFO - 2021-08-09 11:23:48 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 11:23:48 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-09 11:23:48 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 11:23:48 --> Final output sent to browser
DEBUG - 2021-08-09 11:23:48 --> Total execution time: 0.0340
INFO - 2021-08-09 11:24:16 --> Config Class Initialized
INFO - 2021-08-09 11:24:16 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:24:16 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:24:16 --> Utf8 Class Initialized
INFO - 2021-08-09 11:24:16 --> URI Class Initialized
INFO - 2021-08-09 11:24:16 --> Router Class Initialized
INFO - 2021-08-09 11:24:16 --> Output Class Initialized
INFO - 2021-08-09 11:24:16 --> Security Class Initialized
DEBUG - 2021-08-09 11:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:24:16 --> Input Class Initialized
INFO - 2021-08-09 11:24:16 --> Language Class Initialized
INFO - 2021-08-09 11:24:16 --> Loader Class Initialized
INFO - 2021-08-09 11:24:16 --> Helper loaded: url_helper
INFO - 2021-08-09 11:24:16 --> Helper loaded: file_helper
DEBUG - 2021-08-09 11:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 11:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 11:24:16 --> Controller Class Initialized
INFO - 2021-08-09 11:24:16 --> Helper loaded: cookie_helper
INFO - 2021-08-09 11:24:16 --> Model "CookieModel" initialized
INFO - 2021-08-09 11:24:16 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 11:24:16 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-09 11:24:16 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 11:24:16 --> Final output sent to browser
DEBUG - 2021-08-09 11:24:16 --> Total execution time: 0.0366
INFO - 2021-08-09 11:24:37 --> Config Class Initialized
INFO - 2021-08-09 11:24:37 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:24:37 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:24:37 --> Utf8 Class Initialized
INFO - 2021-08-09 11:24:37 --> URI Class Initialized
INFO - 2021-08-09 11:24:37 --> Router Class Initialized
INFO - 2021-08-09 11:24:37 --> Output Class Initialized
INFO - 2021-08-09 11:24:37 --> Security Class Initialized
DEBUG - 2021-08-09 11:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:24:37 --> Input Class Initialized
INFO - 2021-08-09 11:24:37 --> Language Class Initialized
INFO - 2021-08-09 11:24:37 --> Loader Class Initialized
INFO - 2021-08-09 11:24:37 --> Helper loaded: url_helper
INFO - 2021-08-09 11:24:37 --> Helper loaded: file_helper
DEBUG - 2021-08-09 11:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 11:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 11:24:37 --> Controller Class Initialized
INFO - 2021-08-09 11:24:37 --> Helper loaded: cookie_helper
INFO - 2021-08-09 11:24:37 --> Model "CookieModel" initialized
INFO - 2021-08-09 11:24:37 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 11:24:37 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/pilates.php
INFO - 2021-08-09 11:24:37 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 11:24:37 --> Final output sent to browser
DEBUG - 2021-08-09 11:24:37 --> Total execution time: 0.0389
INFO - 2021-08-09 11:24:39 --> Config Class Initialized
INFO - 2021-08-09 11:24:39 --> Hooks Class Initialized
DEBUG - 2021-08-09 11:24:39 --> UTF-8 Support Enabled
INFO - 2021-08-09 11:24:39 --> Utf8 Class Initialized
INFO - 2021-08-09 11:24:39 --> URI Class Initialized
DEBUG - 2021-08-09 11:24:39 --> No URI present. Default controller set.
INFO - 2021-08-09 11:24:39 --> Router Class Initialized
INFO - 2021-08-09 11:24:39 --> Output Class Initialized
INFO - 2021-08-09 11:24:39 --> Security Class Initialized
DEBUG - 2021-08-09 11:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-09 11:24:39 --> Input Class Initialized
INFO - 2021-08-09 11:24:39 --> Language Class Initialized
INFO - 2021-08-09 11:24:39 --> Loader Class Initialized
INFO - 2021-08-09 11:24:39 --> Helper loaded: url_helper
INFO - 2021-08-09 11:24:39 --> Helper loaded: file_helper
DEBUG - 2021-08-09 11:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-09 11:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-09 11:24:39 --> Controller Class Initialized
INFO - 2021-08-09 11:24:39 --> Helper loaded: cookie_helper
INFO - 2021-08-09 11:24:39 --> Model "CookieModel" initialized
INFO - 2021-08-09 11:24:39 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-09 11:24:39 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-09 11:24:39 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-09 11:24:39 --> Final output sent to browser
DEBUG - 2021-08-09 11:24:39 --> Total execution time: 0.0368
