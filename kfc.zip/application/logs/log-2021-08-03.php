<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-08-03 08:47:50 --> Config Class Initialized
INFO - 2021-08-03 08:47:50 --> Hooks Class Initialized
DEBUG - 2021-08-03 08:47:50 --> UTF-8 Support Enabled
INFO - 2021-08-03 08:47:50 --> Utf8 Class Initialized
INFO - 2021-08-03 08:47:50 --> URI Class Initialized
INFO - 2021-08-03 08:47:50 --> Router Class Initialized
INFO - 2021-08-03 08:47:50 --> Output Class Initialized
INFO - 2021-08-03 08:47:50 --> Security Class Initialized
DEBUG - 2021-08-03 08:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 08:47:50 --> Input Class Initialized
INFO - 2021-08-03 08:47:50 --> Language Class Initialized
ERROR - 2021-08-03 08:47:51 --> 404 Page Not Found: Undefined/index
INFO - 2021-08-03 08:47:51 --> Config Class Initialized
INFO - 2021-08-03 08:47:51 --> Hooks Class Initialized
DEBUG - 2021-08-03 08:47:51 --> UTF-8 Support Enabled
INFO - 2021-08-03 08:47:51 --> Utf8 Class Initialized
INFO - 2021-08-03 08:47:51 --> URI Class Initialized
INFO - 2021-08-03 08:47:51 --> Router Class Initialized
INFO - 2021-08-03 08:47:51 --> Output Class Initialized
INFO - 2021-08-03 08:47:51 --> Security Class Initialized
DEBUG - 2021-08-03 08:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 08:47:51 --> Input Class Initialized
INFO - 2021-08-03 08:47:51 --> Language Class Initialized
ERROR - 2021-08-03 08:47:51 --> 404 Page Not Found: Undefined/index
INFO - 2021-08-03 08:49:55 --> Config Class Initialized
INFO - 2021-08-03 08:49:55 --> Hooks Class Initialized
DEBUG - 2021-08-03 08:49:55 --> UTF-8 Support Enabled
INFO - 2021-08-03 08:49:55 --> Utf8 Class Initialized
INFO - 2021-08-03 08:49:55 --> URI Class Initialized
DEBUG - 2021-08-03 08:49:55 --> No URI present. Default controller set.
INFO - 2021-08-03 08:49:55 --> Router Class Initialized
INFO - 2021-08-03 08:49:55 --> Output Class Initialized
INFO - 2021-08-03 08:49:55 --> Security Class Initialized
DEBUG - 2021-08-03 08:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 08:49:55 --> Input Class Initialized
INFO - 2021-08-03 08:49:55 --> Language Class Initialized
INFO - 2021-08-03 08:49:55 --> Loader Class Initialized
INFO - 2021-08-03 08:49:56 --> Helper loaded: url_helper
INFO - 2021-08-03 08:49:56 --> Helper loaded: file_helper
INFO - 2021-08-03 08:49:56 --> Database Driver Class Initialized
DEBUG - 2021-08-03 08:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 08:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 08:49:56 --> Controller Class Initialized
INFO - 2021-08-03 08:49:56 --> Helper loaded: cookie_helper
INFO - 2021-08-03 08:49:56 --> Model "CookieModel" initialized
INFO - 2021-08-03 08:49:56 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 08:49:56 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-03 08:49:56 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 08:49:56 --> Final output sent to browser
DEBUG - 2021-08-03 08:49:56 --> Total execution time: 0.5139
INFO - 2021-08-03 08:51:33 --> Config Class Initialized
INFO - 2021-08-03 08:51:33 --> Hooks Class Initialized
DEBUG - 2021-08-03 08:51:33 --> UTF-8 Support Enabled
INFO - 2021-08-03 08:51:33 --> Utf8 Class Initialized
INFO - 2021-08-03 08:51:33 --> URI Class Initialized
INFO - 2021-08-03 08:51:33 --> Router Class Initialized
INFO - 2021-08-03 08:51:33 --> Output Class Initialized
INFO - 2021-08-03 08:51:33 --> Security Class Initialized
DEBUG - 2021-08-03 08:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 08:51:33 --> Input Class Initialized
INFO - 2021-08-03 08:51:33 --> Language Class Initialized
ERROR - 2021-08-03 08:51:33 --> 404 Page Not Found: Serviceshtml/index
INFO - 2021-08-03 08:51:35 --> Config Class Initialized
INFO - 2021-08-03 08:51:35 --> Hooks Class Initialized
DEBUG - 2021-08-03 08:51:35 --> UTF-8 Support Enabled
INFO - 2021-08-03 08:51:35 --> Utf8 Class Initialized
INFO - 2021-08-03 08:51:35 --> URI Class Initialized
DEBUG - 2021-08-03 08:51:35 --> No URI present. Default controller set.
INFO - 2021-08-03 08:51:35 --> Router Class Initialized
INFO - 2021-08-03 08:51:35 --> Output Class Initialized
INFO - 2021-08-03 08:51:35 --> Security Class Initialized
DEBUG - 2021-08-03 08:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 08:51:35 --> Input Class Initialized
INFO - 2021-08-03 08:51:35 --> Language Class Initialized
INFO - 2021-08-03 08:51:35 --> Loader Class Initialized
INFO - 2021-08-03 08:51:35 --> Helper loaded: url_helper
INFO - 2021-08-03 08:51:35 --> Helper loaded: file_helper
INFO - 2021-08-03 08:51:35 --> Database Driver Class Initialized
DEBUG - 2021-08-03 08:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 08:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 08:51:35 --> Controller Class Initialized
INFO - 2021-08-03 08:51:35 --> Helper loaded: cookie_helper
INFO - 2021-08-03 08:51:35 --> Model "CookieModel" initialized
INFO - 2021-08-03 08:51:35 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 08:51:35 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-03 08:51:35 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 08:51:35 --> Final output sent to browser
DEBUG - 2021-08-03 08:51:35 --> Total execution time: 0.0440
INFO - 2021-08-03 09:25:32 --> Config Class Initialized
INFO - 2021-08-03 09:25:32 --> Hooks Class Initialized
DEBUG - 2021-08-03 09:25:32 --> UTF-8 Support Enabled
INFO - 2021-08-03 09:25:32 --> Utf8 Class Initialized
INFO - 2021-08-03 09:25:32 --> URI Class Initialized
DEBUG - 2021-08-03 09:25:32 --> No URI present. Default controller set.
INFO - 2021-08-03 09:25:32 --> Router Class Initialized
INFO - 2021-08-03 09:25:32 --> Output Class Initialized
INFO - 2021-08-03 09:25:32 --> Security Class Initialized
DEBUG - 2021-08-03 09:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 09:25:32 --> Input Class Initialized
INFO - 2021-08-03 09:25:32 --> Language Class Initialized
INFO - 2021-08-03 09:25:32 --> Loader Class Initialized
INFO - 2021-08-03 09:25:32 --> Helper loaded: url_helper
INFO - 2021-08-03 09:25:32 --> Helper loaded: file_helper
INFO - 2021-08-03 09:25:32 --> Database Driver Class Initialized
DEBUG - 2021-08-03 09:25:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 09:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 09:25:32 --> Controller Class Initialized
INFO - 2021-08-03 09:25:32 --> Helper loaded: cookie_helper
INFO - 2021-08-03 09:25:32 --> Model "CookieModel" initialized
INFO - 2021-08-03 09:25:32 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 09:25:32 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-03 09:25:32 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 09:25:32 --> Final output sent to browser
DEBUG - 2021-08-03 09:25:32 --> Total execution time: 0.0943
INFO - 2021-08-03 09:25:34 --> Config Class Initialized
INFO - 2021-08-03 09:25:34 --> Hooks Class Initialized
DEBUG - 2021-08-03 09:25:34 --> UTF-8 Support Enabled
INFO - 2021-08-03 09:25:34 --> Utf8 Class Initialized
INFO - 2021-08-03 09:25:34 --> URI Class Initialized
INFO - 2021-08-03 09:25:34 --> Router Class Initialized
INFO - 2021-08-03 09:25:34 --> Output Class Initialized
INFO - 2021-08-03 09:25:34 --> Security Class Initialized
DEBUG - 2021-08-03 09:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 09:25:34 --> Input Class Initialized
INFO - 2021-08-03 09:25:34 --> Language Class Initialized
INFO - 2021-08-03 09:25:34 --> Loader Class Initialized
INFO - 2021-08-03 09:25:34 --> Helper loaded: url_helper
INFO - 2021-08-03 09:25:34 --> Helper loaded: file_helper
INFO - 2021-08-03 09:25:34 --> Database Driver Class Initialized
DEBUG - 2021-08-03 09:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 09:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 09:25:34 --> Controller Class Initialized
INFO - 2021-08-03 09:25:34 --> Helper loaded: cookie_helper
INFO - 2021-08-03 09:25:34 --> Model "CookieModel" initialized
INFO - 2021-08-03 09:25:34 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 09:25:34 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-03 09:25:34 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 09:25:34 --> Final output sent to browser
DEBUG - 2021-08-03 09:25:34 --> Total execution time: 0.0419
INFO - 2021-08-03 09:27:13 --> Config Class Initialized
INFO - 2021-08-03 09:27:13 --> Hooks Class Initialized
DEBUG - 2021-08-03 09:27:13 --> UTF-8 Support Enabled
INFO - 2021-08-03 09:27:13 --> Utf8 Class Initialized
INFO - 2021-08-03 09:27:13 --> URI Class Initialized
INFO - 2021-08-03 09:27:13 --> Router Class Initialized
INFO - 2021-08-03 09:27:13 --> Output Class Initialized
INFO - 2021-08-03 09:27:13 --> Security Class Initialized
DEBUG - 2021-08-03 09:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 09:27:13 --> Input Class Initialized
INFO - 2021-08-03 09:27:13 --> Language Class Initialized
INFO - 2021-08-03 09:27:13 --> Loader Class Initialized
INFO - 2021-08-03 09:27:13 --> Helper loaded: url_helper
INFO - 2021-08-03 09:27:13 --> Helper loaded: file_helper
INFO - 2021-08-03 09:27:13 --> Database Driver Class Initialized
DEBUG - 2021-08-03 09:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 09:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 09:27:13 --> Controller Class Initialized
INFO - 2021-08-03 09:27:13 --> Helper loaded: cookie_helper
INFO - 2021-08-03 09:27:13 --> Model "CookieModel" initialized
INFO - 2021-08-03 09:27:13 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 09:27:13 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-03 09:27:13 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 09:27:13 --> Final output sent to browser
DEBUG - 2021-08-03 09:27:13 --> Total execution time: 0.0597
INFO - 2021-08-03 09:27:15 --> Config Class Initialized
INFO - 2021-08-03 09:27:15 --> Hooks Class Initialized
DEBUG - 2021-08-03 09:27:15 --> UTF-8 Support Enabled
INFO - 2021-08-03 09:27:15 --> Utf8 Class Initialized
INFO - 2021-08-03 09:27:15 --> URI Class Initialized
DEBUG - 2021-08-03 09:27:15 --> No URI present. Default controller set.
INFO - 2021-08-03 09:27:15 --> Router Class Initialized
INFO - 2021-08-03 09:27:15 --> Output Class Initialized
INFO - 2021-08-03 09:27:15 --> Security Class Initialized
DEBUG - 2021-08-03 09:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 09:27:15 --> Input Class Initialized
INFO - 2021-08-03 09:27:15 --> Language Class Initialized
INFO - 2021-08-03 09:27:15 --> Loader Class Initialized
INFO - 2021-08-03 09:27:15 --> Helper loaded: url_helper
INFO - 2021-08-03 09:27:15 --> Helper loaded: file_helper
INFO - 2021-08-03 09:27:15 --> Database Driver Class Initialized
DEBUG - 2021-08-03 09:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 09:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 09:27:15 --> Controller Class Initialized
INFO - 2021-08-03 09:27:15 --> Helper loaded: cookie_helper
INFO - 2021-08-03 09:27:15 --> Model "CookieModel" initialized
INFO - 2021-08-03 09:27:15 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 09:27:15 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-03 09:27:15 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 09:27:15 --> Final output sent to browser
DEBUG - 2021-08-03 09:27:15 --> Total execution time: 0.0505
INFO - 2021-08-03 09:27:16 --> Config Class Initialized
INFO - 2021-08-03 09:27:16 --> Hooks Class Initialized
DEBUG - 2021-08-03 09:27:16 --> UTF-8 Support Enabled
INFO - 2021-08-03 09:27:16 --> Utf8 Class Initialized
INFO - 2021-08-03 09:27:16 --> URI Class Initialized
INFO - 2021-08-03 09:27:16 --> Router Class Initialized
INFO - 2021-08-03 09:27:16 --> Output Class Initialized
INFO - 2021-08-03 09:27:16 --> Security Class Initialized
DEBUG - 2021-08-03 09:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 09:27:16 --> Input Class Initialized
INFO - 2021-08-03 09:27:16 --> Language Class Initialized
INFO - 2021-08-03 09:27:16 --> Loader Class Initialized
INFO - 2021-08-03 09:27:16 --> Helper loaded: url_helper
INFO - 2021-08-03 09:27:16 --> Helper loaded: file_helper
INFO - 2021-08-03 09:27:16 --> Database Driver Class Initialized
DEBUG - 2021-08-03 09:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 09:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 09:27:16 --> Controller Class Initialized
INFO - 2021-08-03 09:27:16 --> Helper loaded: cookie_helper
INFO - 2021-08-03 09:27:16 --> Model "CookieModel" initialized
INFO - 2021-08-03 09:27:16 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 09:27:16 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-03 09:27:16 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 09:27:16 --> Final output sent to browser
DEBUG - 2021-08-03 09:27:16 --> Total execution time: 0.0446
INFO - 2021-08-03 09:27:26 --> Config Class Initialized
INFO - 2021-08-03 09:27:26 --> Hooks Class Initialized
INFO - 2021-08-03 09:27:26 --> Config Class Initialized
INFO - 2021-08-03 09:27:26 --> Hooks Class Initialized
DEBUG - 2021-08-03 09:27:26 --> UTF-8 Support Enabled
INFO - 2021-08-03 09:27:26 --> Utf8 Class Initialized
DEBUG - 2021-08-03 09:27:26 --> UTF-8 Support Enabled
INFO - 2021-08-03 09:27:26 --> Utf8 Class Initialized
INFO - 2021-08-03 09:27:26 --> URI Class Initialized
INFO - 2021-08-03 09:27:26 --> URI Class Initialized
INFO - 2021-08-03 09:27:26 --> Router Class Initialized
INFO - 2021-08-03 09:27:26 --> Router Class Initialized
INFO - 2021-08-03 09:27:26 --> Output Class Initialized
INFO - 2021-08-03 09:27:26 --> Output Class Initialized
INFO - 2021-08-03 09:27:26 --> Security Class Initialized
INFO - 2021-08-03 09:27:26 --> Config Class Initialized
INFO - 2021-08-03 09:27:26 --> Hooks Class Initialized
INFO - 2021-08-03 09:27:26 --> Security Class Initialized
DEBUG - 2021-08-03 09:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 09:27:26 --> Input Class Initialized
INFO - 2021-08-03 09:27:26 --> Language Class Initialized
DEBUG - 2021-08-03 09:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 09:27:26 --> Input Class Initialized
DEBUG - 2021-08-03 09:27:26 --> UTF-8 Support Enabled
INFO - 2021-08-03 09:27:26 --> Utf8 Class Initialized
INFO - 2021-08-03 09:27:26 --> Language Class Initialized
ERROR - 2021-08-03 09:27:26 --> 404 Page Not Found: Assets/js
INFO - 2021-08-03 09:27:26 --> URI Class Initialized
INFO - 2021-08-03 09:27:26 --> Router Class Initialized
INFO - 2021-08-03 09:27:26 --> Output Class Initialized
ERROR - 2021-08-03 09:27:26 --> 404 Page Not Found: Assets/js
INFO - 2021-08-03 09:27:26 --> Security Class Initialized
DEBUG - 2021-08-03 09:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 09:27:26 --> Input Class Initialized
INFO - 2021-08-03 09:27:26 --> Language Class Initialized
ERROR - 2021-08-03 09:27:26 --> 404 Page Not Found: Assets/js
INFO - 2021-08-03 09:27:26 --> Config Class Initialized
INFO - 2021-08-03 09:27:26 --> Hooks Class Initialized
INFO - 2021-08-03 09:27:26 --> Config Class Initialized
INFO - 2021-08-03 09:27:26 --> Hooks Class Initialized
DEBUG - 2021-08-03 09:27:26 --> UTF-8 Support Enabled
INFO - 2021-08-03 09:27:26 --> Utf8 Class Initialized
INFO - 2021-08-03 09:27:26 --> URI Class Initialized
DEBUG - 2021-08-03 09:27:26 --> UTF-8 Support Enabled
INFO - 2021-08-03 09:27:26 --> Utf8 Class Initialized
INFO - 2021-08-03 09:27:26 --> Router Class Initialized
INFO - 2021-08-03 09:27:26 --> URI Class Initialized
INFO - 2021-08-03 09:27:26 --> Router Class Initialized
INFO - 2021-08-03 09:27:26 --> Output Class Initialized
INFO - 2021-08-03 09:27:26 --> Security Class Initialized
INFO - 2021-08-03 09:27:26 --> Output Class Initialized
DEBUG - 2021-08-03 09:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 09:27:26 --> Input Class Initialized
INFO - 2021-08-03 09:27:26 --> Security Class Initialized
INFO - 2021-08-03 09:27:26 --> Language Class Initialized
DEBUG - 2021-08-03 09:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 09:27:26 --> Input Class Initialized
ERROR - 2021-08-03 09:27:26 --> 404 Page Not Found: Assets/css
INFO - 2021-08-03 09:27:26 --> Language Class Initialized
ERROR - 2021-08-03 09:27:26 --> 404 Page Not Found: Assets/css
INFO - 2021-08-03 10:15:19 --> Config Class Initialized
INFO - 2021-08-03 10:15:19 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:15:19 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:15:19 --> Utf8 Class Initialized
INFO - 2021-08-03 10:15:19 --> URI Class Initialized
INFO - 2021-08-03 10:15:19 --> Router Class Initialized
INFO - 2021-08-03 10:15:19 --> Output Class Initialized
INFO - 2021-08-03 10:15:19 --> Security Class Initialized
DEBUG - 2021-08-03 10:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:15:19 --> Input Class Initialized
INFO - 2021-08-03 10:15:19 --> Language Class Initialized
ERROR - 2021-08-03 10:15:19 --> 404 Page Not Found: About/index
INFO - 2021-08-03 10:15:21 --> Config Class Initialized
INFO - 2021-08-03 10:15:21 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:15:21 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:15:21 --> Utf8 Class Initialized
INFO - 2021-08-03 10:15:21 --> URI Class Initialized
INFO - 2021-08-03 10:15:21 --> Router Class Initialized
INFO - 2021-08-03 10:15:21 --> Output Class Initialized
INFO - 2021-08-03 10:15:21 --> Security Class Initialized
DEBUG - 2021-08-03 10:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:15:21 --> Input Class Initialized
INFO - 2021-08-03 10:15:21 --> Language Class Initialized
INFO - 2021-08-03 10:15:21 --> Loader Class Initialized
INFO - 2021-08-03 10:15:21 --> Helper loaded: url_helper
INFO - 2021-08-03 10:15:21 --> Helper loaded: file_helper
INFO - 2021-08-03 10:15:21 --> Database Driver Class Initialized
DEBUG - 2021-08-03 10:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 10:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 10:15:21 --> Controller Class Initialized
INFO - 2021-08-03 10:15:21 --> Helper loaded: cookie_helper
INFO - 2021-08-03 10:15:21 --> Model "CookieModel" initialized
INFO - 2021-08-03 10:15:21 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 10:15:21 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-03 10:15:21 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 10:15:21 --> Final output sent to browser
DEBUG - 2021-08-03 10:15:21 --> Total execution time: 0.0720
INFO - 2021-08-03 10:17:27 --> Config Class Initialized
INFO - 2021-08-03 10:17:27 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:17:27 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:17:27 --> Utf8 Class Initialized
INFO - 2021-08-03 10:17:27 --> URI Class Initialized
INFO - 2021-08-03 10:17:27 --> Router Class Initialized
INFO - 2021-08-03 10:17:27 --> Output Class Initialized
INFO - 2021-08-03 10:17:27 --> Security Class Initialized
DEBUG - 2021-08-03 10:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:17:27 --> Input Class Initialized
INFO - 2021-08-03 10:17:27 --> Language Class Initialized
INFO - 2021-08-03 10:17:27 --> Loader Class Initialized
INFO - 2021-08-03 10:17:27 --> Helper loaded: url_helper
INFO - 2021-08-03 10:17:27 --> Helper loaded: file_helper
INFO - 2021-08-03 10:17:27 --> Database Driver Class Initialized
DEBUG - 2021-08-03 10:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 10:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 10:17:27 --> Controller Class Initialized
INFO - 2021-08-03 10:17:27 --> Helper loaded: cookie_helper
INFO - 2021-08-03 10:17:27 --> Model "CookieModel" initialized
INFO - 2021-08-03 10:17:27 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 10:17:27 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/about.php
INFO - 2021-08-03 10:17:27 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 10:17:27 --> Final output sent to browser
DEBUG - 2021-08-03 10:17:27 --> Total execution time: 0.0592
INFO - 2021-08-03 10:20:18 --> Config Class Initialized
INFO - 2021-08-03 10:20:18 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:20:18 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:20:18 --> Utf8 Class Initialized
INFO - 2021-08-03 10:20:18 --> URI Class Initialized
INFO - 2021-08-03 10:20:18 --> Router Class Initialized
INFO - 2021-08-03 10:20:18 --> Output Class Initialized
INFO - 2021-08-03 10:20:18 --> Security Class Initialized
DEBUG - 2021-08-03 10:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:20:18 --> Input Class Initialized
INFO - 2021-08-03 10:20:18 --> Language Class Initialized
INFO - 2021-08-03 10:20:18 --> Loader Class Initialized
INFO - 2021-08-03 10:20:18 --> Helper loaded: url_helper
INFO - 2021-08-03 10:20:18 --> Helper loaded: file_helper
INFO - 2021-08-03 10:20:18 --> Database Driver Class Initialized
DEBUG - 2021-08-03 10:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 10:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 10:20:18 --> Controller Class Initialized
INFO - 2021-08-03 10:20:18 --> Helper loaded: cookie_helper
INFO - 2021-08-03 10:20:18 --> Model "CookieModel" initialized
INFO - 2021-08-03 10:20:18 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 10:20:18 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/about.php
INFO - 2021-08-03 10:20:18 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 10:20:18 --> Final output sent to browser
DEBUG - 2021-08-03 10:20:18 --> Total execution time: 0.0408
INFO - 2021-08-03 10:21:36 --> Config Class Initialized
INFO - 2021-08-03 10:21:36 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:21:36 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:36 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:36 --> URI Class Initialized
INFO - 2021-08-03 10:21:36 --> Router Class Initialized
INFO - 2021-08-03 10:21:36 --> Output Class Initialized
INFO - 2021-08-03 10:21:36 --> Security Class Initialized
DEBUG - 2021-08-03 10:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:36 --> Input Class Initialized
INFO - 2021-08-03 10:21:36 --> Language Class Initialized
INFO - 2021-08-03 10:21:36 --> Loader Class Initialized
INFO - 2021-08-03 10:21:36 --> Helper loaded: url_helper
INFO - 2021-08-03 10:21:36 --> Helper loaded: file_helper
INFO - 2021-08-03 10:21:36 --> Database Driver Class Initialized
DEBUG - 2021-08-03 10:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 10:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 10:21:36 --> Controller Class Initialized
INFO - 2021-08-03 10:21:36 --> Helper loaded: cookie_helper
INFO - 2021-08-03 10:21:36 --> Model "CookieModel" initialized
INFO - 2021-08-03 10:21:36 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 10:21:36 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/about.php
INFO - 2021-08-03 10:21:36 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 10:21:36 --> Final output sent to browser
DEBUG - 2021-08-03 10:21:36 --> Total execution time: 0.0464
INFO - 2021-08-03 10:21:49 --> Config Class Initialized
INFO - 2021-08-03 10:21:49 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:21:49 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:49 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:49 --> URI Class Initialized
INFO - 2021-08-03 10:21:49 --> Router Class Initialized
INFO - 2021-08-03 10:21:49 --> Output Class Initialized
INFO - 2021-08-03 10:21:49 --> Security Class Initialized
DEBUG - 2021-08-03 10:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:49 --> Input Class Initialized
INFO - 2021-08-03 10:21:49 --> Language Class Initialized
INFO - 2021-08-03 10:21:49 --> Loader Class Initialized
INFO - 2021-08-03 10:21:49 --> Helper loaded: url_helper
INFO - 2021-08-03 10:21:49 --> Helper loaded: file_helper
INFO - 2021-08-03 10:21:49 --> Database Driver Class Initialized
DEBUG - 2021-08-03 10:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 10:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 10:21:49 --> Controller Class Initialized
INFO - 2021-08-03 10:21:49 --> Helper loaded: cookie_helper
INFO - 2021-08-03 10:21:49 --> Model "CookieModel" initialized
INFO - 2021-08-03 10:21:49 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 10:21:49 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/about.php
INFO - 2021-08-03 10:21:49 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 10:21:49 --> Final output sent to browser
DEBUG - 2021-08-03 10:21:49 --> Total execution time: 0.0411
INFO - 2021-08-03 10:21:52 --> Config Class Initialized
INFO - 2021-08-03 10:21:52 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:21:52 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:52 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:52 --> URI Class Initialized
INFO - 2021-08-03 10:21:52 --> Router Class Initialized
INFO - 2021-08-03 10:21:52 --> Output Class Initialized
INFO - 2021-08-03 10:21:52 --> Security Class Initialized
DEBUG - 2021-08-03 10:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:52 --> Input Class Initialized
INFO - 2021-08-03 10:21:52 --> Language Class Initialized
INFO - 2021-08-03 10:21:52 --> Loader Class Initialized
INFO - 2021-08-03 10:21:52 --> Helper loaded: url_helper
INFO - 2021-08-03 10:21:52 --> Helper loaded: file_helper
INFO - 2021-08-03 10:21:52 --> Database Driver Class Initialized
DEBUG - 2021-08-03 10:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 10:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 10:21:52 --> Controller Class Initialized
INFO - 2021-08-03 10:21:52 --> Helper loaded: cookie_helper
INFO - 2021-08-03 10:21:52 --> Model "CookieModel" initialized
INFO - 2021-08-03 10:21:52 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 10:21:52 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/team.php
INFO - 2021-08-03 10:21:52 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 10:21:52 --> Final output sent to browser
DEBUG - 2021-08-03 10:21:52 --> Total execution time: 0.0398
INFO - 2021-08-03 10:21:52 --> Config Class Initialized
INFO - 2021-08-03 10:21:52 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:21:52 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:52 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:52 --> URI Class Initialized
INFO - 2021-08-03 10:21:52 --> Router Class Initialized
INFO - 2021-08-03 10:21:52 --> Output Class Initialized
INFO - 2021-08-03 10:21:52 --> Security Class Initialized
INFO - 2021-08-03 10:21:52 --> Config Class Initialized
INFO - 2021-08-03 10:21:52 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:52 --> Input Class Initialized
INFO - 2021-08-03 10:21:52 --> Language Class Initialized
INFO - 2021-08-03 10:21:52 --> Config Class Initialized
INFO - 2021-08-03 10:21:52 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:21:52 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:52 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:52 --> URI Class Initialized
DEBUG - 2021-08-03 10:21:52 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:52 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:52 --> Router Class Initialized
INFO - 2021-08-03 10:21:52 --> Config Class Initialized
INFO - 2021-08-03 10:21:52 --> Hooks Class Initialized
INFO - 2021-08-03 10:21:52 --> URI Class Initialized
INFO - 2021-08-03 10:21:52 --> Router Class Initialized
INFO - 2021-08-03 10:21:52 --> Config Class Initialized
INFO - 2021-08-03 10:21:52 --> Output Class Initialized
INFO - 2021-08-03 10:21:52 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:21:52 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:52 --> Utf8 Class Initialized
ERROR - 2021-08-03 10:21:52 --> 404 Page Not Found: About/assets
INFO - 2021-08-03 10:21:52 --> Security Class Initialized
INFO - 2021-08-03 10:21:52 --> Output Class Initialized
INFO - 2021-08-03 10:21:52 --> URI Class Initialized
DEBUG - 2021-08-03 10:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:52 --> Input Class Initialized
DEBUG - 2021-08-03 10:21:52 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:52 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:52 --> Language Class Initialized
INFO - 2021-08-03 10:21:52 --> Router Class Initialized
INFO - 2021-08-03 10:21:52 --> Security Class Initialized
INFO - 2021-08-03 10:21:52 --> URI Class Initialized
ERROR - 2021-08-03 10:21:52 --> 404 Page Not Found: About/assets
DEBUG - 2021-08-03 10:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:52 --> Input Class Initialized
INFO - 2021-08-03 10:21:52 --> Router Class Initialized
INFO - 2021-08-03 10:21:52 --> Output Class Initialized
INFO - 2021-08-03 10:21:52 --> Language Class Initialized
ERROR - 2021-08-03 10:21:52 --> 404 Page Not Found: About/assets
INFO - 2021-08-03 10:21:52 --> Output Class Initialized
INFO - 2021-08-03 10:21:52 --> Security Class Initialized
INFO - 2021-08-03 10:21:52 --> Security Class Initialized
DEBUG - 2021-08-03 10:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:52 --> Input Class Initialized
DEBUG - 2021-08-03 10:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:52 --> Input Class Initialized
INFO - 2021-08-03 10:21:52 --> Language Class Initialized
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
INFO - 2021-08-03 10:21:53 --> Config Class Initialized
INFO - 2021-08-03 10:21:53 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:21:53 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:21:53 --> Utf8 Class Initialized
INFO - 2021-08-03 10:21:53 --> URI Class Initialized
INFO - 2021-08-03 10:21:53 --> Router Class Initialized
INFO - 2021-08-03 10:21:53 --> Output Class Initialized
INFO - 2021-08-03 10:21:53 --> Security Class Initialized
DEBUG - 2021-08-03 10:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:21:53 --> Input Class Initialized
INFO - 2021-08-03 10:21:53 --> Language Class Initialized
ERROR - 2021-08-03 10:21:53 --> 404 Page Not Found: About/assets
INFO - 2021-08-03 10:23:31 --> Config Class Initialized
INFO - 2021-08-03 10:23:31 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:23:31 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:23:31 --> Utf8 Class Initialized
INFO - 2021-08-03 10:23:31 --> URI Class Initialized
INFO - 2021-08-03 10:23:31 --> Router Class Initialized
INFO - 2021-08-03 10:23:31 --> Output Class Initialized
INFO - 2021-08-03 10:23:31 --> Security Class Initialized
DEBUG - 2021-08-03 10:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:23:31 --> Input Class Initialized
INFO - 2021-08-03 10:23:31 --> Language Class Initialized
INFO - 2021-08-03 10:23:31 --> Loader Class Initialized
INFO - 2021-08-03 10:23:31 --> Helper loaded: url_helper
INFO - 2021-08-03 10:23:31 --> Helper loaded: file_helper
INFO - 2021-08-03 10:23:31 --> Database Driver Class Initialized
DEBUG - 2021-08-03 10:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 10:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 10:23:31 --> Controller Class Initialized
INFO - 2021-08-03 10:23:31 --> Helper loaded: cookie_helper
INFO - 2021-08-03 10:23:31 --> Model "CookieModel" initialized
INFO - 2021-08-03 10:23:31 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 10:23:31 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/team.php
INFO - 2021-08-03 10:23:31 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 10:23:31 --> Final output sent to browser
DEBUG - 2021-08-03 10:23:31 --> Total execution time: 0.0495
INFO - 2021-08-03 10:23:41 --> Config Class Initialized
INFO - 2021-08-03 10:23:41 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:23:41 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:23:41 --> Utf8 Class Initialized
INFO - 2021-08-03 10:23:41 --> URI Class Initialized
INFO - 2021-08-03 10:23:41 --> Router Class Initialized
INFO - 2021-08-03 10:23:41 --> Output Class Initialized
INFO - 2021-08-03 10:23:41 --> Security Class Initialized
DEBUG - 2021-08-03 10:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:23:41 --> Input Class Initialized
INFO - 2021-08-03 10:23:41 --> Language Class Initialized
INFO - 2021-08-03 10:23:41 --> Loader Class Initialized
INFO - 2021-08-03 10:23:41 --> Helper loaded: url_helper
INFO - 2021-08-03 10:23:41 --> Helper loaded: file_helper
INFO - 2021-08-03 10:23:41 --> Database Driver Class Initialized
DEBUG - 2021-08-03 10:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 10:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 10:23:41 --> Controller Class Initialized
INFO - 2021-08-03 10:23:41 --> Helper loaded: cookie_helper
INFO - 2021-08-03 10:23:41 --> Model "CookieModel" initialized
INFO - 2021-08-03 10:23:41 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 10:23:41 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/team.php
INFO - 2021-08-03 10:23:41 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 10:23:41 --> Final output sent to browser
DEBUG - 2021-08-03 10:23:41 --> Total execution time: 0.0674
INFO - 2021-08-03 10:24:06 --> Config Class Initialized
INFO - 2021-08-03 10:24:06 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:24:06 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:24:06 --> Utf8 Class Initialized
INFO - 2021-08-03 10:24:06 --> URI Class Initialized
INFO - 2021-08-03 10:24:06 --> Router Class Initialized
INFO - 2021-08-03 10:24:06 --> Output Class Initialized
INFO - 2021-08-03 10:24:06 --> Security Class Initialized
DEBUG - 2021-08-03 10:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:24:06 --> Input Class Initialized
INFO - 2021-08-03 10:24:06 --> Language Class Initialized
INFO - 2021-08-03 10:24:06 --> Loader Class Initialized
INFO - 2021-08-03 10:24:06 --> Helper loaded: url_helper
INFO - 2021-08-03 10:24:06 --> Helper loaded: file_helper
INFO - 2021-08-03 10:24:06 --> Database Driver Class Initialized
DEBUG - 2021-08-03 10:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 10:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 10:24:06 --> Controller Class Initialized
INFO - 2021-08-03 10:24:06 --> Helper loaded: cookie_helper
INFO - 2021-08-03 10:24:06 --> Model "CookieModel" initialized
INFO - 2021-08-03 10:24:06 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 10:24:06 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/team.php
INFO - 2021-08-03 10:24:06 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 10:24:06 --> Final output sent to browser
DEBUG - 2021-08-03 10:24:06 --> Total execution time: 0.0394
INFO - 2021-08-03 10:24:29 --> Config Class Initialized
INFO - 2021-08-03 10:24:29 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:24:29 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:24:29 --> Utf8 Class Initialized
INFO - 2021-08-03 10:24:29 --> Config Class Initialized
INFO - 2021-08-03 10:24:29 --> Hooks Class Initialized
INFO - 2021-08-03 10:24:29 --> URI Class Initialized
INFO - 2021-08-03 10:24:29 --> Router Class Initialized
DEBUG - 2021-08-03 10:24:29 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:24:29 --> Utf8 Class Initialized
INFO - 2021-08-03 10:24:29 --> Output Class Initialized
INFO - 2021-08-03 10:24:29 --> URI Class Initialized
INFO - 2021-08-03 10:24:29 --> Security Class Initialized
DEBUG - 2021-08-03 10:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:24:29 --> Router Class Initialized
INFO - 2021-08-03 10:24:29 --> Input Class Initialized
INFO - 2021-08-03 10:24:29 --> Language Class Initialized
INFO - 2021-08-03 10:24:29 --> Output Class Initialized
ERROR - 2021-08-03 10:24:29 --> 404 Page Not Found: Assets/js
INFO - 2021-08-03 10:24:29 --> Security Class Initialized
DEBUG - 2021-08-03 10:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:24:29 --> Input Class Initialized
INFO - 2021-08-03 10:24:29 --> Language Class Initialized
ERROR - 2021-08-03 10:24:29 --> 404 Page Not Found: Assets/js
INFO - 2021-08-03 10:24:29 --> Config Class Initialized
INFO - 2021-08-03 10:24:29 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:24:29 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:24:29 --> Utf8 Class Initialized
INFO - 2021-08-03 10:24:29 --> URI Class Initialized
INFO - 2021-08-03 10:24:29 --> Router Class Initialized
INFO - 2021-08-03 10:24:29 --> Output Class Initialized
INFO - 2021-08-03 10:24:29 --> Security Class Initialized
DEBUG - 2021-08-03 10:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:24:29 --> Input Class Initialized
INFO - 2021-08-03 10:24:29 --> Language Class Initialized
ERROR - 2021-08-03 10:24:29 --> 404 Page Not Found: Assets/js
INFO - 2021-08-03 10:24:29 --> Config Class Initialized
INFO - 2021-08-03 10:24:29 --> Hooks Class Initialized
INFO - 2021-08-03 10:24:29 --> Config Class Initialized
INFO - 2021-08-03 10:24:29 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:24:29 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:24:29 --> Utf8 Class Initialized
INFO - 2021-08-03 10:24:29 --> URI Class Initialized
DEBUG - 2021-08-03 10:24:29 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:24:29 --> Utf8 Class Initialized
INFO - 2021-08-03 10:24:29 --> Router Class Initialized
INFO - 2021-08-03 10:24:29 --> URI Class Initialized
INFO - 2021-08-03 10:24:29 --> Output Class Initialized
INFO - 2021-08-03 10:24:29 --> Router Class Initialized
INFO - 2021-08-03 10:24:29 --> Security Class Initialized
INFO - 2021-08-03 10:24:29 --> Output Class Initialized
DEBUG - 2021-08-03 10:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:24:29 --> Input Class Initialized
INFO - 2021-08-03 10:24:29 --> Security Class Initialized
INFO - 2021-08-03 10:24:29 --> Language Class Initialized
ERROR - 2021-08-03 10:24:29 --> 404 Page Not Found: Assets/css
DEBUG - 2021-08-03 10:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:24:29 --> Input Class Initialized
INFO - 2021-08-03 10:24:29 --> Language Class Initialized
ERROR - 2021-08-03 10:24:29 --> 404 Page Not Found: Assets/css
INFO - 2021-08-03 10:27:11 --> Config Class Initialized
INFO - 2021-08-03 10:27:11 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:27:11 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:27:11 --> Utf8 Class Initialized
INFO - 2021-08-03 10:27:11 --> URI Class Initialized
INFO - 2021-08-03 10:27:11 --> Router Class Initialized
INFO - 2021-08-03 10:27:11 --> Output Class Initialized
INFO - 2021-08-03 10:27:11 --> Security Class Initialized
DEBUG - 2021-08-03 10:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:27:11 --> Input Class Initialized
INFO - 2021-08-03 10:27:11 --> Language Class Initialized
INFO - 2021-08-03 10:27:11 --> Loader Class Initialized
INFO - 2021-08-03 10:27:11 --> Helper loaded: url_helper
INFO - 2021-08-03 10:27:11 --> Helper loaded: file_helper
INFO - 2021-08-03 10:27:11 --> Database Driver Class Initialized
DEBUG - 2021-08-03 10:27:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 10:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 10:27:11 --> Controller Class Initialized
INFO - 2021-08-03 10:27:11 --> Helper loaded: cookie_helper
INFO - 2021-08-03 10:27:11 --> Model "CookieModel" initialized
INFO - 2021-08-03 10:27:11 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 10:27:11 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/team.php
INFO - 2021-08-03 10:27:11 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 10:27:11 --> Final output sent to browser
DEBUG - 2021-08-03 10:27:11 --> Total execution time: 0.0557
INFO - 2021-08-03 10:27:13 --> Config Class Initialized
INFO - 2021-08-03 10:27:13 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:27:13 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:27:13 --> Utf8 Class Initialized
INFO - 2021-08-03 10:27:13 --> URI Class Initialized
INFO - 2021-08-03 10:27:13 --> Router Class Initialized
INFO - 2021-08-03 10:27:13 --> Output Class Initialized
INFO - 2021-08-03 10:27:13 --> Security Class Initialized
DEBUG - 2021-08-03 10:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:27:13 --> Input Class Initialized
INFO - 2021-08-03 10:27:13 --> Language Class Initialized
INFO - 2021-08-03 10:27:13 --> Loader Class Initialized
INFO - 2021-08-03 10:27:13 --> Helper loaded: url_helper
INFO - 2021-08-03 10:27:13 --> Helper loaded: file_helper
INFO - 2021-08-03 10:27:13 --> Database Driver Class Initialized
DEBUG - 2021-08-03 10:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 10:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 10:27:13 --> Controller Class Initialized
INFO - 2021-08-03 10:27:13 --> Helper loaded: cookie_helper
INFO - 2021-08-03 10:27:13 --> Model "CookieModel" initialized
INFO - 2021-08-03 10:27:13 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 10:27:13 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/team.php
INFO - 2021-08-03 10:27:13 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 10:27:13 --> Final output sent to browser
DEBUG - 2021-08-03 10:27:13 --> Total execution time: 0.0385
INFO - 2021-08-03 10:32:39 --> Config Class Initialized
INFO - 2021-08-03 10:32:39 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:32:39 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:32:39 --> Utf8 Class Initialized
INFO - 2021-08-03 10:32:39 --> URI Class Initialized
INFO - 2021-08-03 10:32:39 --> Router Class Initialized
INFO - 2021-08-03 10:32:39 --> Output Class Initialized
INFO - 2021-08-03 10:32:39 --> Security Class Initialized
DEBUG - 2021-08-03 10:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:32:39 --> Input Class Initialized
INFO - 2021-08-03 10:32:39 --> Language Class Initialized
INFO - 2021-08-03 10:32:39 --> Loader Class Initialized
INFO - 2021-08-03 10:32:39 --> Helper loaded: url_helper
INFO - 2021-08-03 10:32:39 --> Helper loaded: file_helper
INFO - 2021-08-03 10:32:39 --> Database Driver Class Initialized
DEBUG - 2021-08-03 10:32:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 10:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 10:32:39 --> Controller Class Initialized
INFO - 2021-08-03 10:32:39 --> Helper loaded: cookie_helper
INFO - 2021-08-03 10:32:39 --> Model "CookieModel" initialized
INFO - 2021-08-03 10:32:39 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 10:33:28 --> Config Class Initialized
INFO - 2021-08-03 10:33:28 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:33:28 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:33:28 --> Utf8 Class Initialized
INFO - 2021-08-03 10:33:28 --> URI Class Initialized
INFO - 2021-08-03 10:33:28 --> Router Class Initialized
INFO - 2021-08-03 10:33:28 --> Output Class Initialized
INFO - 2021-08-03 10:33:28 --> Security Class Initialized
DEBUG - 2021-08-03 10:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:33:28 --> Input Class Initialized
INFO - 2021-08-03 10:33:28 --> Language Class Initialized
INFO - 2021-08-03 10:33:28 --> Loader Class Initialized
INFO - 2021-08-03 10:33:28 --> Helper loaded: url_helper
INFO - 2021-08-03 10:33:28 --> Helper loaded: file_helper
INFO - 2021-08-03 10:33:28 --> Database Driver Class Initialized
DEBUG - 2021-08-03 10:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 10:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 10:33:28 --> Controller Class Initialized
INFO - 2021-08-03 10:33:28 --> Helper loaded: cookie_helper
INFO - 2021-08-03 10:33:28 --> Model "CookieModel" initialized
INFO - 2021-08-03 10:33:28 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 10:33:28 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/gallery.php
INFO - 2021-08-03 10:33:28 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 10:33:28 --> Final output sent to browser
DEBUG - 2021-08-03 10:33:28 --> Total execution time: 0.0417
INFO - 2021-08-03 10:36:19 --> Config Class Initialized
INFO - 2021-08-03 10:36:19 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:36:19 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:36:19 --> Utf8 Class Initialized
INFO - 2021-08-03 10:36:19 --> URI Class Initialized
INFO - 2021-08-03 10:36:19 --> Router Class Initialized
INFO - 2021-08-03 10:36:19 --> Output Class Initialized
INFO - 2021-08-03 10:36:19 --> Security Class Initialized
DEBUG - 2021-08-03 10:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:36:19 --> Input Class Initialized
INFO - 2021-08-03 10:36:19 --> Language Class Initialized
INFO - 2021-08-03 10:36:19 --> Loader Class Initialized
INFO - 2021-08-03 10:36:19 --> Helper loaded: url_helper
INFO - 2021-08-03 10:36:19 --> Helper loaded: file_helper
INFO - 2021-08-03 10:36:19 --> Database Driver Class Initialized
DEBUG - 2021-08-03 10:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 10:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 10:36:19 --> Controller Class Initialized
INFO - 2021-08-03 10:36:19 --> Helper loaded: cookie_helper
INFO - 2021-08-03 10:36:19 --> Model "CookieModel" initialized
INFO - 2021-08-03 10:36:19 --> Model "ContactModel" initialized
INFO - 2021-08-03 10:36:19 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 10:36:19 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/contact.php
INFO - 2021-08-03 10:36:19 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 10:36:19 --> Final output sent to browser
DEBUG - 2021-08-03 10:36:19 --> Total execution time: 0.1124
INFO - 2021-08-03 10:37:43 --> Config Class Initialized
INFO - 2021-08-03 10:37:43 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:37:43 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:37:43 --> Utf8 Class Initialized
INFO - 2021-08-03 10:37:43 --> URI Class Initialized
INFO - 2021-08-03 10:37:43 --> Router Class Initialized
INFO - 2021-08-03 10:37:43 --> Output Class Initialized
INFO - 2021-08-03 10:37:43 --> Security Class Initialized
DEBUG - 2021-08-03 10:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:37:43 --> Input Class Initialized
INFO - 2021-08-03 10:37:43 --> Language Class Initialized
INFO - 2021-08-03 10:37:43 --> Loader Class Initialized
INFO - 2021-08-03 10:37:43 --> Helper loaded: url_helper
INFO - 2021-08-03 10:37:43 --> Helper loaded: file_helper
INFO - 2021-08-03 10:37:43 --> Database Driver Class Initialized
DEBUG - 2021-08-03 10:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 10:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 10:37:43 --> Controller Class Initialized
INFO - 2021-08-03 10:37:43 --> Helper loaded: cookie_helper
INFO - 2021-08-03 10:37:43 --> Model "CookieModel" initialized
INFO - 2021-08-03 10:37:43 --> Model "ContactModel" initialized
INFO - 2021-08-03 10:37:43 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 10:37:43 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/contact.php
INFO - 2021-08-03 10:37:43 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 10:37:43 --> Final output sent to browser
DEBUG - 2021-08-03 10:37:43 --> Total execution time: 0.0477
INFO - 2021-08-03 10:39:26 --> Config Class Initialized
INFO - 2021-08-03 10:39:26 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:39:26 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:39:26 --> Utf8 Class Initialized
INFO - 2021-08-03 10:39:26 --> URI Class Initialized
INFO - 2021-08-03 10:39:26 --> Router Class Initialized
INFO - 2021-08-03 10:39:26 --> Output Class Initialized
INFO - 2021-08-03 10:39:26 --> Security Class Initialized
DEBUG - 2021-08-03 10:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:39:26 --> Input Class Initialized
INFO - 2021-08-03 10:39:26 --> Language Class Initialized
INFO - 2021-08-03 10:39:26 --> Loader Class Initialized
INFO - 2021-08-03 10:39:26 --> Helper loaded: url_helper
INFO - 2021-08-03 10:39:26 --> Helper loaded: file_helper
INFO - 2021-08-03 10:39:26 --> Database Driver Class Initialized
DEBUG - 2021-08-03 10:39:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 10:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 10:39:26 --> Controller Class Initialized
INFO - 2021-08-03 10:39:26 --> Helper loaded: cookie_helper
INFO - 2021-08-03 10:39:26 --> Model "CookieModel" initialized
INFO - 2021-08-03 10:39:26 --> Model "ContactModel" initialized
INFO - 2021-08-03 10:39:26 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 10:39:26 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/contact.php
INFO - 2021-08-03 10:39:26 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 10:39:26 --> Final output sent to browser
DEBUG - 2021-08-03 10:39:26 --> Total execution time: 0.0468
INFO - 2021-08-03 10:40:11 --> Config Class Initialized
INFO - 2021-08-03 10:40:11 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:40:11 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:40:11 --> Utf8 Class Initialized
INFO - 2021-08-03 10:40:11 --> URI Class Initialized
INFO - 2021-08-03 10:40:11 --> Router Class Initialized
INFO - 2021-08-03 10:40:11 --> Output Class Initialized
INFO - 2021-08-03 10:40:11 --> Security Class Initialized
DEBUG - 2021-08-03 10:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:40:12 --> Input Class Initialized
INFO - 2021-08-03 10:40:12 --> Language Class Initialized
ERROR - 2021-08-03 10:40:12 --> 404 Page Not Found: Wp-content/uploads
INFO - 2021-08-03 10:40:27 --> Config Class Initialized
INFO - 2021-08-03 10:40:27 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:40:27 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:40:27 --> Utf8 Class Initialized
INFO - 2021-08-03 10:40:27 --> URI Class Initialized
INFO - 2021-08-03 10:40:27 --> Router Class Initialized
INFO - 2021-08-03 10:40:27 --> Output Class Initialized
INFO - 2021-08-03 10:40:27 --> Security Class Initialized
DEBUG - 2021-08-03 10:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:40:27 --> Input Class Initialized
INFO - 2021-08-03 10:40:27 --> Language Class Initialized
INFO - 2021-08-03 10:40:27 --> Loader Class Initialized
INFO - 2021-08-03 10:40:27 --> Helper loaded: url_helper
INFO - 2021-08-03 10:40:27 --> Helper loaded: file_helper
INFO - 2021-08-03 10:40:27 --> Database Driver Class Initialized
DEBUG - 2021-08-03 10:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 10:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 10:40:27 --> Controller Class Initialized
INFO - 2021-08-03 10:40:27 --> Helper loaded: cookie_helper
INFO - 2021-08-03 10:40:27 --> Model "CookieModel" initialized
INFO - 2021-08-03 10:40:27 --> Model "ContactModel" initialized
INFO - 2021-08-03 10:40:27 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 10:40:27 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/contact.php
INFO - 2021-08-03 10:40:27 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 10:40:27 --> Final output sent to browser
DEBUG - 2021-08-03 10:40:27 --> Total execution time: 0.0437
INFO - 2021-08-03 10:40:55 --> Config Class Initialized
INFO - 2021-08-03 10:40:55 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:40:55 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:40:55 --> Utf8 Class Initialized
INFO - 2021-08-03 10:40:55 --> URI Class Initialized
INFO - 2021-08-03 10:40:55 --> Router Class Initialized
INFO - 2021-08-03 10:40:55 --> Output Class Initialized
INFO - 2021-08-03 10:40:55 --> Security Class Initialized
DEBUG - 2021-08-03 10:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:40:55 --> Input Class Initialized
INFO - 2021-08-03 10:40:55 --> Language Class Initialized
INFO - 2021-08-03 10:40:55 --> Loader Class Initialized
INFO - 2021-08-03 10:40:55 --> Helper loaded: url_helper
INFO - 2021-08-03 10:40:55 --> Helper loaded: file_helper
INFO - 2021-08-03 10:40:55 --> Database Driver Class Initialized
DEBUG - 2021-08-03 10:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 10:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 10:40:55 --> Controller Class Initialized
INFO - 2021-08-03 10:40:55 --> Helper loaded: cookie_helper
INFO - 2021-08-03 10:40:55 --> Model "CookieModel" initialized
INFO - 2021-08-03 10:40:55 --> Model "ContactModel" initialized
INFO - 2021-08-03 10:40:55 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 10:40:55 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/contact.php
INFO - 2021-08-03 10:40:55 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 10:40:55 --> Final output sent to browser
DEBUG - 2021-08-03 10:40:55 --> Total execution time: 0.0416
INFO - 2021-08-03 10:40:55 --> Config Class Initialized
INFO - 2021-08-03 10:40:55 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:40:55 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:40:55 --> Utf8 Class Initialized
INFO - 2021-08-03 10:40:55 --> URI Class Initialized
INFO - 2021-08-03 10:40:55 --> Router Class Initialized
INFO - 2021-08-03 10:40:55 --> Output Class Initialized
INFO - 2021-08-03 10:40:55 --> Security Class Initialized
DEBUG - 2021-08-03 10:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:40:55 --> Input Class Initialized
INFO - 2021-08-03 10:40:55 --> Language Class Initialized
ERROR - 2021-08-03 10:40:55 --> 404 Page Not Found: Wp-content/uploads
INFO - 2021-08-03 10:44:00 --> Config Class Initialized
INFO - 2021-08-03 10:44:00 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:44:00 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:44:00 --> Utf8 Class Initialized
INFO - 2021-08-03 10:44:00 --> URI Class Initialized
INFO - 2021-08-03 10:44:00 --> Router Class Initialized
INFO - 2021-08-03 10:44:00 --> Output Class Initialized
INFO - 2021-08-03 10:44:00 --> Security Class Initialized
DEBUG - 2021-08-03 10:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:44:00 --> Input Class Initialized
INFO - 2021-08-03 10:44:00 --> Language Class Initialized
INFO - 2021-08-03 10:44:00 --> Loader Class Initialized
INFO - 2021-08-03 10:44:00 --> Helper loaded: url_helper
INFO - 2021-08-03 10:44:00 --> Helper loaded: file_helper
INFO - 2021-08-03 10:44:00 --> Database Driver Class Initialized
DEBUG - 2021-08-03 10:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 10:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 10:44:00 --> Controller Class Initialized
INFO - 2021-08-03 10:44:00 --> Helper loaded: cookie_helper
INFO - 2021-08-03 10:44:00 --> Model "CookieModel" initialized
INFO - 2021-08-03 10:44:00 --> Model "ContactModel" initialized
INFO - 2021-08-03 10:44:00 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 10:44:00 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/contact.php
INFO - 2021-08-03 10:44:00 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 10:44:00 --> Final output sent to browser
DEBUG - 2021-08-03 10:44:00 --> Total execution time: 0.0638
INFO - 2021-08-03 10:47:35 --> Config Class Initialized
INFO - 2021-08-03 10:47:35 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:47:35 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:47:35 --> Utf8 Class Initialized
INFO - 2021-08-03 10:47:35 --> URI Class Initialized
INFO - 2021-08-03 10:47:35 --> Router Class Initialized
INFO - 2021-08-03 10:47:35 --> Output Class Initialized
INFO - 2021-08-03 10:47:35 --> Security Class Initialized
DEBUG - 2021-08-03 10:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:47:35 --> Input Class Initialized
INFO - 2021-08-03 10:47:35 --> Language Class Initialized
INFO - 2021-08-03 10:47:35 --> Loader Class Initialized
INFO - 2021-08-03 10:47:35 --> Helper loaded: url_helper
INFO - 2021-08-03 10:47:35 --> Helper loaded: file_helper
INFO - 2021-08-03 10:47:35 --> Database Driver Class Initialized
DEBUG - 2021-08-03 10:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 10:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 10:47:35 --> Controller Class Initialized
INFO - 2021-08-03 10:47:35 --> Helper loaded: cookie_helper
INFO - 2021-08-03 10:47:35 --> Model "CookieModel" initialized
INFO - 2021-08-03 10:47:35 --> Model "ContactModel" initialized
INFO - 2021-08-03 10:47:35 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 10:47:35 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/contact.php
INFO - 2021-08-03 10:47:35 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 10:47:35 --> Final output sent to browser
DEBUG - 2021-08-03 10:47:35 --> Total execution time: 0.0520
INFO - 2021-08-03 10:48:07 --> Config Class Initialized
INFO - 2021-08-03 10:48:07 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:48:07 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:48:07 --> Utf8 Class Initialized
INFO - 2021-08-03 10:48:07 --> URI Class Initialized
INFO - 2021-08-03 10:48:07 --> Router Class Initialized
INFO - 2021-08-03 10:48:07 --> Output Class Initialized
INFO - 2021-08-03 10:48:07 --> Security Class Initialized
DEBUG - 2021-08-03 10:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:48:07 --> Input Class Initialized
INFO - 2021-08-03 10:48:07 --> Language Class Initialized
INFO - 2021-08-03 10:48:07 --> Loader Class Initialized
INFO - 2021-08-03 10:48:07 --> Helper loaded: url_helper
INFO - 2021-08-03 10:48:07 --> Helper loaded: file_helper
INFO - 2021-08-03 10:48:07 --> Database Driver Class Initialized
DEBUG - 2021-08-03 10:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 10:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 10:48:07 --> Controller Class Initialized
INFO - 2021-08-03 10:48:07 --> Helper loaded: cookie_helper
INFO - 2021-08-03 10:48:07 --> Model "CookieModel" initialized
INFO - 2021-08-03 10:48:07 --> Model "ContactModel" initialized
INFO - 2021-08-03 10:48:07 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 10:48:07 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/contact.php
INFO - 2021-08-03 10:48:07 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 10:48:07 --> Final output sent to browser
DEBUG - 2021-08-03 10:48:07 --> Total execution time: 0.0472
INFO - 2021-08-03 10:48:19 --> Config Class Initialized
INFO - 2021-08-03 10:48:19 --> Hooks Class Initialized
INFO - 2021-08-03 10:48:19 --> Config Class Initialized
INFO - 2021-08-03 10:48:19 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:48:19 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:48:19 --> Utf8 Class Initialized
INFO - 2021-08-03 10:48:19 --> URI Class Initialized
DEBUG - 2021-08-03 10:48:19 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:48:19 --> Utf8 Class Initialized
INFO - 2021-08-03 10:48:19 --> Router Class Initialized
INFO - 2021-08-03 10:48:19 --> URI Class Initialized
INFO - 2021-08-03 10:48:19 --> Output Class Initialized
INFO - 2021-08-03 10:48:19 --> Router Class Initialized
INFO - 2021-08-03 10:48:19 --> Security Class Initialized
INFO - 2021-08-03 10:48:19 --> Output Class Initialized
INFO - 2021-08-03 10:48:19 --> Config Class Initialized
INFO - 2021-08-03 10:48:19 --> Hooks Class Initialized
DEBUG - 2021-08-03 10:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:48:19 --> Input Class Initialized
INFO - 2021-08-03 10:48:19 --> Security Class Initialized
INFO - 2021-08-03 10:48:19 --> Language Class Initialized
DEBUG - 2021-08-03 10:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:48:19 --> Input Class Initialized
ERROR - 2021-08-03 10:48:19 --> 404 Page Not Found: Assets/js
DEBUG - 2021-08-03 10:48:19 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:48:19 --> Language Class Initialized
INFO - 2021-08-03 10:48:19 --> Utf8 Class Initialized
ERROR - 2021-08-03 10:48:19 --> 404 Page Not Found: Assets/js
INFO - 2021-08-03 10:48:19 --> URI Class Initialized
INFO - 2021-08-03 10:48:19 --> Router Class Initialized
INFO - 2021-08-03 10:48:19 --> Output Class Initialized
INFO - 2021-08-03 10:48:19 --> Security Class Initialized
DEBUG - 2021-08-03 10:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:48:19 --> Input Class Initialized
INFO - 2021-08-03 10:48:19 --> Language Class Initialized
ERROR - 2021-08-03 10:48:19 --> 404 Page Not Found: Assets/js
INFO - 2021-08-03 10:48:19 --> Config Class Initialized
INFO - 2021-08-03 10:48:19 --> Hooks Class Initialized
INFO - 2021-08-03 10:48:19 --> Config Class Initialized
DEBUG - 2021-08-03 10:48:19 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:48:19 --> Hooks Class Initialized
INFO - 2021-08-03 10:48:19 --> Utf8 Class Initialized
INFO - 2021-08-03 10:48:19 --> URI Class Initialized
DEBUG - 2021-08-03 10:48:19 --> UTF-8 Support Enabled
INFO - 2021-08-03 10:48:19 --> Router Class Initialized
INFO - 2021-08-03 10:48:19 --> Utf8 Class Initialized
INFO - 2021-08-03 10:48:19 --> URI Class Initialized
INFO - 2021-08-03 10:48:19 --> Router Class Initialized
INFO - 2021-08-03 10:48:19 --> Output Class Initialized
INFO - 2021-08-03 10:48:19 --> Output Class Initialized
INFO - 2021-08-03 10:48:19 --> Security Class Initialized
INFO - 2021-08-03 10:48:19 --> Security Class Initialized
DEBUG - 2021-08-03 10:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:48:19 --> Input Class Initialized
DEBUG - 2021-08-03 10:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 10:48:19 --> Language Class Initialized
INFO - 2021-08-03 10:48:19 --> Input Class Initialized
INFO - 2021-08-03 10:48:19 --> Language Class Initialized
ERROR - 2021-08-03 10:48:19 --> 404 Page Not Found: Assets/css
ERROR - 2021-08-03 10:48:19 --> 404 Page Not Found: Assets/css
INFO - 2021-08-03 11:41:02 --> Config Class Initialized
INFO - 2021-08-03 11:41:02 --> Hooks Class Initialized
DEBUG - 2021-08-03 11:41:02 --> UTF-8 Support Enabled
INFO - 2021-08-03 11:41:02 --> Utf8 Class Initialized
INFO - 2021-08-03 11:41:02 --> URI Class Initialized
INFO - 2021-08-03 11:41:02 --> Router Class Initialized
INFO - 2021-08-03 11:41:02 --> Output Class Initialized
INFO - 2021-08-03 11:41:02 --> Security Class Initialized
DEBUG - 2021-08-03 11:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 11:41:02 --> Input Class Initialized
INFO - 2021-08-03 11:41:02 --> Language Class Initialized
INFO - 2021-08-03 11:41:02 --> Loader Class Initialized
INFO - 2021-08-03 11:41:02 --> Helper loaded: url_helper
INFO - 2021-08-03 11:41:02 --> Helper loaded: file_helper
INFO - 2021-08-03 11:41:02 --> Database Driver Class Initialized
DEBUG - 2021-08-03 11:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 11:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 11:41:02 --> Controller Class Initialized
INFO - 2021-08-03 11:41:02 --> Helper loaded: cookie_helper
INFO - 2021-08-03 11:41:02 --> Model "CookieModel" initialized
INFO - 2021-08-03 11:41:02 --> Model "ContactModel" initialized
INFO - 2021-08-03 11:41:02 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 11:41:02 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/contact.php
INFO - 2021-08-03 11:41:02 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 11:41:02 --> Final output sent to browser
DEBUG - 2021-08-03 11:41:02 --> Total execution time: 0.0927
INFO - 2021-08-03 11:41:07 --> Config Class Initialized
INFO - 2021-08-03 11:41:07 --> Hooks Class Initialized
DEBUG - 2021-08-03 11:41:07 --> UTF-8 Support Enabled
INFO - 2021-08-03 11:41:07 --> Utf8 Class Initialized
INFO - 2021-08-03 11:41:07 --> URI Class Initialized
DEBUG - 2021-08-03 11:41:07 --> No URI present. Default controller set.
INFO - 2021-08-03 11:41:07 --> Router Class Initialized
INFO - 2021-08-03 11:41:07 --> Output Class Initialized
INFO - 2021-08-03 11:41:07 --> Security Class Initialized
DEBUG - 2021-08-03 11:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 11:41:07 --> Input Class Initialized
INFO - 2021-08-03 11:41:07 --> Language Class Initialized
INFO - 2021-08-03 11:41:07 --> Loader Class Initialized
INFO - 2021-08-03 11:41:07 --> Helper loaded: url_helper
INFO - 2021-08-03 11:41:07 --> Helper loaded: file_helper
INFO - 2021-08-03 11:41:07 --> Database Driver Class Initialized
DEBUG - 2021-08-03 11:41:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 11:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 11:41:07 --> Controller Class Initialized
INFO - 2021-08-03 11:41:07 --> Helper loaded: cookie_helper
INFO - 2021-08-03 11:41:07 --> Model "CookieModel" initialized
INFO - 2021-08-03 11:41:07 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 11:41:07 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-03 11:41:07 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 11:41:07 --> Final output sent to browser
DEBUG - 2021-08-03 11:41:07 --> Total execution time: 0.0498
INFO - 2021-08-03 11:55:05 --> Config Class Initialized
INFO - 2021-08-03 11:55:05 --> Hooks Class Initialized
DEBUG - 2021-08-03 11:55:05 --> UTF-8 Support Enabled
INFO - 2021-08-03 11:55:05 --> Utf8 Class Initialized
INFO - 2021-08-03 11:55:05 --> URI Class Initialized
INFO - 2021-08-03 11:55:05 --> Router Class Initialized
INFO - 2021-08-03 11:55:05 --> Output Class Initialized
INFO - 2021-08-03 11:55:05 --> Security Class Initialized
DEBUG - 2021-08-03 11:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 11:55:05 --> Input Class Initialized
INFO - 2021-08-03 11:55:05 --> Language Class Initialized
ERROR - 2021-08-03 11:55:05 --> 404 Page Not Found: Undefined/index
INFO - 2021-08-03 12:02:20 --> Config Class Initialized
INFO - 2021-08-03 12:02:20 --> Hooks Class Initialized
DEBUG - 2021-08-03 12:02:20 --> UTF-8 Support Enabled
INFO - 2021-08-03 12:02:20 --> Utf8 Class Initialized
INFO - 2021-08-03 12:02:20 --> URI Class Initialized
INFO - 2021-08-03 12:02:20 --> Router Class Initialized
INFO - 2021-08-03 12:02:20 --> Output Class Initialized
INFO - 2021-08-03 12:02:20 --> Security Class Initialized
DEBUG - 2021-08-03 12:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 12:02:20 --> Input Class Initialized
INFO - 2021-08-03 12:02:20 --> Language Class Initialized
INFO - 2021-08-03 12:02:20 --> Loader Class Initialized
INFO - 2021-08-03 12:02:20 --> Helper loaded: url_helper
INFO - 2021-08-03 12:02:20 --> Helper loaded: file_helper
INFO - 2021-08-03 12:02:20 --> Database Driver Class Initialized
DEBUG - 2021-08-03 12:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 12:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 12:02:20 --> Controller Class Initialized
INFO - 2021-08-03 12:02:20 --> Helper loaded: cookie_helper
INFO - 2021-08-03 12:02:20 --> Model "CookieModel" initialized
INFO - 2021-08-03 12:02:20 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 12:02:20 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-03 12:02:20 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 12:02:20 --> Final output sent to browser
DEBUG - 2021-08-03 12:02:20 --> Total execution time: 0.1475
INFO - 2021-08-03 12:02:35 --> Config Class Initialized
INFO - 2021-08-03 12:02:35 --> Hooks Class Initialized
DEBUG - 2021-08-03 12:02:35 --> UTF-8 Support Enabled
INFO - 2021-08-03 12:02:35 --> Utf8 Class Initialized
INFO - 2021-08-03 12:02:35 --> URI Class Initialized
INFO - 2021-08-03 12:02:35 --> Router Class Initialized
INFO - 2021-08-03 12:02:35 --> Output Class Initialized
INFO - 2021-08-03 12:02:35 --> Security Class Initialized
DEBUG - 2021-08-03 12:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 12:02:35 --> Input Class Initialized
INFO - 2021-08-03 12:02:35 --> Language Class Initialized
INFO - 2021-08-03 12:02:35 --> Loader Class Initialized
INFO - 2021-08-03 12:02:35 --> Helper loaded: url_helper
INFO - 2021-08-03 12:02:35 --> Helper loaded: file_helper
INFO - 2021-08-03 12:02:35 --> Database Driver Class Initialized
DEBUG - 2021-08-03 12:02:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 12:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 12:02:35 --> Controller Class Initialized
INFO - 2021-08-03 12:02:35 --> Helper loaded: cookie_helper
INFO - 2021-08-03 12:02:35 --> Model "CookieModel" initialized
INFO - 2021-08-03 12:02:35 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 12:02:35 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-03 12:02:35 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 12:02:35 --> Final output sent to browser
DEBUG - 2021-08-03 12:02:35 --> Total execution time: 0.0559
INFO - 2021-08-03 12:46:57 --> Config Class Initialized
INFO - 2021-08-03 12:46:57 --> Hooks Class Initialized
DEBUG - 2021-08-03 12:46:57 --> UTF-8 Support Enabled
INFO - 2021-08-03 12:46:57 --> Utf8 Class Initialized
INFO - 2021-08-03 12:46:57 --> URI Class Initialized
DEBUG - 2021-08-03 12:46:57 --> No URI present. Default controller set.
INFO - 2021-08-03 12:46:57 --> Router Class Initialized
INFO - 2021-08-03 12:46:57 --> Output Class Initialized
INFO - 2021-08-03 12:46:57 --> Security Class Initialized
DEBUG - 2021-08-03 12:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 12:46:57 --> Input Class Initialized
INFO - 2021-08-03 12:46:57 --> Language Class Initialized
INFO - 2021-08-03 12:46:57 --> Loader Class Initialized
INFO - 2021-08-03 12:46:57 --> Helper loaded: url_helper
INFO - 2021-08-03 12:46:57 --> Helper loaded: file_helper
INFO - 2021-08-03 12:46:57 --> Database Driver Class Initialized
DEBUG - 2021-08-03 12:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 12:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 12:46:57 --> Controller Class Initialized
INFO - 2021-08-03 12:46:57 --> Helper loaded: cookie_helper
INFO - 2021-08-03 12:46:57 --> Model "CookieModel" initialized
INFO - 2021-08-03 12:46:57 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 12:46:57 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-03 12:46:57 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 12:46:57 --> Final output sent to browser
DEBUG - 2021-08-03 12:46:57 --> Total execution time: 0.1490
INFO - 2021-08-03 13:04:52 --> Config Class Initialized
INFO - 2021-08-03 13:04:52 --> Hooks Class Initialized
DEBUG - 2021-08-03 13:04:52 --> UTF-8 Support Enabled
INFO - 2021-08-03 13:04:52 --> Utf8 Class Initialized
INFO - 2021-08-03 13:04:52 --> URI Class Initialized
DEBUG - 2021-08-03 13:04:52 --> No URI present. Default controller set.
INFO - 2021-08-03 13:04:52 --> Router Class Initialized
INFO - 2021-08-03 13:04:52 --> Output Class Initialized
INFO - 2021-08-03 13:04:52 --> Security Class Initialized
DEBUG - 2021-08-03 13:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 13:04:52 --> Input Class Initialized
INFO - 2021-08-03 13:04:52 --> Language Class Initialized
INFO - 2021-08-03 13:04:52 --> Loader Class Initialized
INFO - 2021-08-03 13:04:52 --> Helper loaded: url_helper
INFO - 2021-08-03 13:04:52 --> Helper loaded: file_helper
INFO - 2021-08-03 13:04:52 --> Database Driver Class Initialized
DEBUG - 2021-08-03 13:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 13:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 13:04:52 --> Controller Class Initialized
INFO - 2021-08-03 13:04:52 --> Helper loaded: cookie_helper
INFO - 2021-08-03 13:04:52 --> Model "CookieModel" initialized
INFO - 2021-08-03 13:04:52 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 13:04:52 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-03 13:04:52 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 13:04:52 --> Final output sent to browser
DEBUG - 2021-08-03 13:04:52 --> Total execution time: 0.1110
INFO - 2021-08-03 13:06:37 --> Config Class Initialized
INFO - 2021-08-03 13:06:37 --> Hooks Class Initialized
DEBUG - 2021-08-03 13:06:37 --> UTF-8 Support Enabled
INFO - 2021-08-03 13:06:37 --> Utf8 Class Initialized
INFO - 2021-08-03 13:06:37 --> URI Class Initialized
DEBUG - 2021-08-03 13:06:37 --> No URI present. Default controller set.
INFO - 2021-08-03 13:06:37 --> Router Class Initialized
INFO - 2021-08-03 13:06:37 --> Output Class Initialized
INFO - 2021-08-03 13:06:37 --> Security Class Initialized
DEBUG - 2021-08-03 13:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 13:06:37 --> Input Class Initialized
INFO - 2021-08-03 13:06:37 --> Language Class Initialized
INFO - 2021-08-03 13:06:37 --> Loader Class Initialized
INFO - 2021-08-03 13:06:37 --> Helper loaded: url_helper
INFO - 2021-08-03 13:06:37 --> Helper loaded: file_helper
INFO - 2021-08-03 13:06:37 --> Database Driver Class Initialized
DEBUG - 2021-08-03 13:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 13:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 13:06:37 --> Controller Class Initialized
INFO - 2021-08-03 13:06:37 --> Helper loaded: cookie_helper
INFO - 2021-08-03 13:06:37 --> Model "CookieModel" initialized
INFO - 2021-08-03 13:06:37 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 13:06:37 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-03 13:06:37 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 13:06:37 --> Final output sent to browser
DEBUG - 2021-08-03 13:06:37 --> Total execution time: 0.0654
INFO - 2021-08-03 13:06:58 --> Config Class Initialized
INFO - 2021-08-03 13:06:58 --> Hooks Class Initialized
DEBUG - 2021-08-03 13:06:58 --> UTF-8 Support Enabled
INFO - 2021-08-03 13:06:58 --> Utf8 Class Initialized
INFO - 2021-08-03 13:06:58 --> URI Class Initialized
DEBUG - 2021-08-03 13:06:58 --> No URI present. Default controller set.
INFO - 2021-08-03 13:06:58 --> Router Class Initialized
INFO - 2021-08-03 13:06:58 --> Output Class Initialized
INFO - 2021-08-03 13:06:58 --> Security Class Initialized
DEBUG - 2021-08-03 13:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 13:06:58 --> Input Class Initialized
INFO - 2021-08-03 13:06:58 --> Language Class Initialized
INFO - 2021-08-03 13:06:58 --> Loader Class Initialized
INFO - 2021-08-03 13:06:58 --> Helper loaded: url_helper
INFO - 2021-08-03 13:06:58 --> Helper loaded: file_helper
INFO - 2021-08-03 13:06:58 --> Database Driver Class Initialized
DEBUG - 2021-08-03 13:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 13:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 13:06:58 --> Controller Class Initialized
INFO - 2021-08-03 13:06:58 --> Helper loaded: cookie_helper
INFO - 2021-08-03 13:06:58 --> Model "CookieModel" initialized
INFO - 2021-08-03 13:06:58 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 13:06:58 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-03 13:06:58 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 13:06:58 --> Final output sent to browser
DEBUG - 2021-08-03 13:06:58 --> Total execution time: 0.0464
INFO - 2021-08-03 13:07:09 --> Config Class Initialized
INFO - 2021-08-03 13:07:09 --> Hooks Class Initialized
DEBUG - 2021-08-03 13:07:09 --> UTF-8 Support Enabled
INFO - 2021-08-03 13:07:09 --> Utf8 Class Initialized
INFO - 2021-08-03 13:07:09 --> URI Class Initialized
DEBUG - 2021-08-03 13:07:09 --> No URI present. Default controller set.
INFO - 2021-08-03 13:07:09 --> Router Class Initialized
INFO - 2021-08-03 13:07:09 --> Output Class Initialized
INFO - 2021-08-03 13:07:09 --> Security Class Initialized
DEBUG - 2021-08-03 13:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 13:07:09 --> Input Class Initialized
INFO - 2021-08-03 13:07:09 --> Language Class Initialized
INFO - 2021-08-03 13:07:09 --> Loader Class Initialized
INFO - 2021-08-03 13:07:09 --> Helper loaded: url_helper
INFO - 2021-08-03 13:07:09 --> Helper loaded: file_helper
INFO - 2021-08-03 13:07:09 --> Database Driver Class Initialized
DEBUG - 2021-08-03 13:07:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 13:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 13:07:09 --> Controller Class Initialized
INFO - 2021-08-03 13:07:09 --> Helper loaded: cookie_helper
INFO - 2021-08-03 13:07:09 --> Model "CookieModel" initialized
INFO - 2021-08-03 13:07:09 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 13:07:09 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-03 13:07:09 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 13:07:09 --> Final output sent to browser
DEBUG - 2021-08-03 13:07:09 --> Total execution time: 0.0457
INFO - 2021-08-03 13:07:16 --> Config Class Initialized
INFO - 2021-08-03 13:07:16 --> Hooks Class Initialized
DEBUG - 2021-08-03 13:07:16 --> UTF-8 Support Enabled
INFO - 2021-08-03 13:07:16 --> Utf8 Class Initialized
INFO - 2021-08-03 13:07:16 --> URI Class Initialized
DEBUG - 2021-08-03 13:07:16 --> No URI present. Default controller set.
INFO - 2021-08-03 13:07:16 --> Router Class Initialized
INFO - 2021-08-03 13:07:16 --> Output Class Initialized
INFO - 2021-08-03 13:07:16 --> Security Class Initialized
DEBUG - 2021-08-03 13:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 13:07:16 --> Input Class Initialized
INFO - 2021-08-03 13:07:16 --> Language Class Initialized
INFO - 2021-08-03 13:07:16 --> Loader Class Initialized
INFO - 2021-08-03 13:07:16 --> Helper loaded: url_helper
INFO - 2021-08-03 13:07:16 --> Helper loaded: file_helper
INFO - 2021-08-03 13:07:16 --> Database Driver Class Initialized
DEBUG - 2021-08-03 13:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 13:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 13:07:16 --> Controller Class Initialized
INFO - 2021-08-03 13:07:16 --> Helper loaded: cookie_helper
INFO - 2021-08-03 13:07:16 --> Model "CookieModel" initialized
INFO - 2021-08-03 13:07:16 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 13:07:16 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-03 13:07:16 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 13:07:16 --> Final output sent to browser
DEBUG - 2021-08-03 13:07:16 --> Total execution time: 0.0434
INFO - 2021-08-03 13:10:19 --> Config Class Initialized
INFO - 2021-08-03 13:10:19 --> Hooks Class Initialized
DEBUG - 2021-08-03 13:10:19 --> UTF-8 Support Enabled
INFO - 2021-08-03 13:10:19 --> Utf8 Class Initialized
INFO - 2021-08-03 13:10:19 --> URI Class Initialized
DEBUG - 2021-08-03 13:10:19 --> No URI present. Default controller set.
INFO - 2021-08-03 13:10:19 --> Router Class Initialized
INFO - 2021-08-03 13:10:19 --> Output Class Initialized
INFO - 2021-08-03 13:10:19 --> Security Class Initialized
DEBUG - 2021-08-03 13:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 13:10:19 --> Input Class Initialized
INFO - 2021-08-03 13:10:19 --> Language Class Initialized
INFO - 2021-08-03 13:10:19 --> Loader Class Initialized
INFO - 2021-08-03 13:10:19 --> Helper loaded: url_helper
INFO - 2021-08-03 13:10:19 --> Helper loaded: file_helper
INFO - 2021-08-03 13:10:19 --> Database Driver Class Initialized
DEBUG - 2021-08-03 13:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 13:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 13:10:19 --> Controller Class Initialized
INFO - 2021-08-03 13:10:19 --> Helper loaded: cookie_helper
INFO - 2021-08-03 13:10:19 --> Model "CookieModel" initialized
INFO - 2021-08-03 13:10:19 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 13:10:19 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-03 13:10:19 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 13:10:19 --> Final output sent to browser
DEBUG - 2021-08-03 13:10:19 --> Total execution time: 0.0434
INFO - 2021-08-03 13:10:20 --> Config Class Initialized
INFO - 2021-08-03 13:10:20 --> Hooks Class Initialized
DEBUG - 2021-08-03 13:10:20 --> UTF-8 Support Enabled
INFO - 2021-08-03 13:10:20 --> Utf8 Class Initialized
INFO - 2021-08-03 13:10:20 --> URI Class Initialized
DEBUG - 2021-08-03 13:10:20 --> No URI present. Default controller set.
INFO - 2021-08-03 13:10:20 --> Router Class Initialized
INFO - 2021-08-03 13:10:20 --> Output Class Initialized
INFO - 2021-08-03 13:10:20 --> Security Class Initialized
DEBUG - 2021-08-03 13:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 13:10:20 --> Input Class Initialized
INFO - 2021-08-03 13:10:20 --> Language Class Initialized
INFO - 2021-08-03 13:10:20 --> Loader Class Initialized
INFO - 2021-08-03 13:10:20 --> Helper loaded: url_helper
INFO - 2021-08-03 13:10:20 --> Helper loaded: file_helper
INFO - 2021-08-03 13:10:20 --> Database Driver Class Initialized
DEBUG - 2021-08-03 13:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 13:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 13:10:20 --> Controller Class Initialized
INFO - 2021-08-03 13:10:20 --> Helper loaded: cookie_helper
INFO - 2021-08-03 13:10:20 --> Model "CookieModel" initialized
INFO - 2021-08-03 13:10:20 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 13:10:20 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-03 13:10:20 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 13:10:20 --> Final output sent to browser
DEBUG - 2021-08-03 13:10:20 --> Total execution time: 0.0410
INFO - 2021-08-03 13:12:04 --> Config Class Initialized
INFO - 2021-08-03 13:12:04 --> Hooks Class Initialized
DEBUG - 2021-08-03 13:12:04 --> UTF-8 Support Enabled
INFO - 2021-08-03 13:12:04 --> Utf8 Class Initialized
INFO - 2021-08-03 13:12:04 --> URI Class Initialized
DEBUG - 2021-08-03 13:12:04 --> No URI present. Default controller set.
INFO - 2021-08-03 13:12:04 --> Router Class Initialized
INFO - 2021-08-03 13:12:04 --> Output Class Initialized
INFO - 2021-08-03 13:12:04 --> Security Class Initialized
DEBUG - 2021-08-03 13:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 13:12:04 --> Input Class Initialized
INFO - 2021-08-03 13:12:04 --> Language Class Initialized
INFO - 2021-08-03 13:12:04 --> Loader Class Initialized
INFO - 2021-08-03 13:12:04 --> Helper loaded: url_helper
INFO - 2021-08-03 13:12:04 --> Helper loaded: file_helper
INFO - 2021-08-03 13:12:04 --> Database Driver Class Initialized
DEBUG - 2021-08-03 13:12:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 13:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 13:12:04 --> Controller Class Initialized
INFO - 2021-08-03 13:12:04 --> Helper loaded: cookie_helper
INFO - 2021-08-03 13:12:04 --> Model "CookieModel" initialized
INFO - 2021-08-03 13:12:04 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 13:12:04 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-03 13:12:04 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 13:12:04 --> Final output sent to browser
DEBUG - 2021-08-03 13:12:04 --> Total execution time: 0.0610
INFO - 2021-08-03 13:13:29 --> Config Class Initialized
INFO - 2021-08-03 13:13:29 --> Hooks Class Initialized
DEBUG - 2021-08-03 13:13:29 --> UTF-8 Support Enabled
INFO - 2021-08-03 13:13:29 --> Utf8 Class Initialized
INFO - 2021-08-03 13:13:29 --> URI Class Initialized
DEBUG - 2021-08-03 13:13:29 --> No URI present. Default controller set.
INFO - 2021-08-03 13:13:29 --> Router Class Initialized
INFO - 2021-08-03 13:13:29 --> Output Class Initialized
INFO - 2021-08-03 13:13:29 --> Security Class Initialized
DEBUG - 2021-08-03 13:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 13:13:29 --> Input Class Initialized
INFO - 2021-08-03 13:13:29 --> Language Class Initialized
INFO - 2021-08-03 13:13:29 --> Loader Class Initialized
INFO - 2021-08-03 13:13:29 --> Helper loaded: url_helper
INFO - 2021-08-03 13:13:29 --> Helper loaded: file_helper
INFO - 2021-08-03 13:13:29 --> Database Driver Class Initialized
DEBUG - 2021-08-03 13:13:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 13:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 13:13:29 --> Controller Class Initialized
INFO - 2021-08-03 13:13:29 --> Helper loaded: cookie_helper
INFO - 2021-08-03 13:13:29 --> Model "CookieModel" initialized
INFO - 2021-08-03 13:13:29 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 13:13:29 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-03 13:13:29 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 13:13:29 --> Final output sent to browser
DEBUG - 2021-08-03 13:13:29 --> Total execution time: 0.0470
INFO - 2021-08-03 13:14:09 --> Config Class Initialized
INFO - 2021-08-03 13:14:09 --> Hooks Class Initialized
DEBUG - 2021-08-03 13:14:09 --> UTF-8 Support Enabled
INFO - 2021-08-03 13:14:09 --> Utf8 Class Initialized
INFO - 2021-08-03 13:14:09 --> URI Class Initialized
DEBUG - 2021-08-03 13:14:09 --> No URI present. Default controller set.
INFO - 2021-08-03 13:14:09 --> Router Class Initialized
INFO - 2021-08-03 13:14:09 --> Output Class Initialized
INFO - 2021-08-03 13:14:09 --> Security Class Initialized
DEBUG - 2021-08-03 13:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 13:14:09 --> Input Class Initialized
INFO - 2021-08-03 13:14:09 --> Language Class Initialized
INFO - 2021-08-03 13:14:09 --> Loader Class Initialized
INFO - 2021-08-03 13:14:09 --> Helper loaded: url_helper
INFO - 2021-08-03 13:14:09 --> Helper loaded: file_helper
INFO - 2021-08-03 13:14:09 --> Database Driver Class Initialized
DEBUG - 2021-08-03 13:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 13:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 13:14:09 --> Controller Class Initialized
INFO - 2021-08-03 13:14:09 --> Helper loaded: cookie_helper
INFO - 2021-08-03 13:14:09 --> Model "CookieModel" initialized
INFO - 2021-08-03 13:14:09 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 13:14:09 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-03 13:14:09 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 13:14:09 --> Final output sent to browser
DEBUG - 2021-08-03 13:14:09 --> Total execution time: 0.0449
INFO - 2021-08-03 13:32:44 --> Config Class Initialized
INFO - 2021-08-03 13:32:44 --> Hooks Class Initialized
DEBUG - 2021-08-03 13:32:44 --> UTF-8 Support Enabled
INFO - 2021-08-03 13:32:44 --> Utf8 Class Initialized
INFO - 2021-08-03 13:32:44 --> URI Class Initialized
DEBUG - 2021-08-03 13:32:44 --> No URI present. Default controller set.
INFO - 2021-08-03 13:32:44 --> Router Class Initialized
INFO - 2021-08-03 13:32:44 --> Output Class Initialized
INFO - 2021-08-03 13:32:44 --> Security Class Initialized
DEBUG - 2021-08-03 13:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 13:32:44 --> Input Class Initialized
INFO - 2021-08-03 13:32:44 --> Language Class Initialized
INFO - 2021-08-03 13:32:44 --> Loader Class Initialized
INFO - 2021-08-03 13:32:44 --> Helper loaded: url_helper
INFO - 2021-08-03 13:32:44 --> Helper loaded: file_helper
INFO - 2021-08-03 13:32:44 --> Database Driver Class Initialized
DEBUG - 2021-08-03 13:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 13:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 13:32:44 --> Controller Class Initialized
INFO - 2021-08-03 13:32:44 --> Helper loaded: cookie_helper
INFO - 2021-08-03 13:32:44 --> Model "CookieModel" initialized
INFO - 2021-08-03 13:32:44 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 13:32:44 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-03 13:32:44 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 13:32:44 --> Final output sent to browser
DEBUG - 2021-08-03 13:32:44 --> Total execution time: 0.0622
INFO - 2021-08-03 13:33:50 --> Config Class Initialized
INFO - 2021-08-03 13:33:50 --> Hooks Class Initialized
DEBUG - 2021-08-03 13:33:50 --> UTF-8 Support Enabled
INFO - 2021-08-03 13:33:50 --> Utf8 Class Initialized
INFO - 2021-08-03 13:33:50 --> URI Class Initialized
DEBUG - 2021-08-03 13:33:50 --> No URI present. Default controller set.
INFO - 2021-08-03 13:33:50 --> Router Class Initialized
INFO - 2021-08-03 13:33:50 --> Output Class Initialized
INFO - 2021-08-03 13:33:50 --> Security Class Initialized
DEBUG - 2021-08-03 13:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 13:33:50 --> Input Class Initialized
INFO - 2021-08-03 13:33:50 --> Language Class Initialized
INFO - 2021-08-03 13:33:50 --> Loader Class Initialized
INFO - 2021-08-03 13:33:50 --> Helper loaded: url_helper
INFO - 2021-08-03 13:33:50 --> Helper loaded: file_helper
INFO - 2021-08-03 13:33:51 --> Database Driver Class Initialized
DEBUG - 2021-08-03 13:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 13:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 13:33:51 --> Controller Class Initialized
INFO - 2021-08-03 13:33:51 --> Helper loaded: cookie_helper
INFO - 2021-08-03 13:33:51 --> Model "CookieModel" initialized
INFO - 2021-08-03 13:33:51 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 13:33:51 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-03 13:33:51 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 13:33:51 --> Final output sent to browser
DEBUG - 2021-08-03 13:33:51 --> Total execution time: 0.0475
INFO - 2021-08-03 13:39:01 --> Config Class Initialized
INFO - 2021-08-03 13:39:01 --> Hooks Class Initialized
DEBUG - 2021-08-03 13:39:01 --> UTF-8 Support Enabled
INFO - 2021-08-03 13:39:01 --> Utf8 Class Initialized
INFO - 2021-08-03 13:39:01 --> URI Class Initialized
DEBUG - 2021-08-03 13:39:01 --> No URI present. Default controller set.
INFO - 2021-08-03 13:39:01 --> Router Class Initialized
INFO - 2021-08-03 13:39:01 --> Output Class Initialized
INFO - 2021-08-03 13:39:01 --> Security Class Initialized
DEBUG - 2021-08-03 13:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 13:39:01 --> Input Class Initialized
INFO - 2021-08-03 13:39:01 --> Language Class Initialized
INFO - 2021-08-03 13:39:01 --> Loader Class Initialized
INFO - 2021-08-03 13:39:01 --> Helper loaded: url_helper
INFO - 2021-08-03 13:39:01 --> Helper loaded: file_helper
INFO - 2021-08-03 13:39:01 --> Database Driver Class Initialized
DEBUG - 2021-08-03 13:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 13:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 13:39:01 --> Controller Class Initialized
INFO - 2021-08-03 13:39:01 --> Helper loaded: cookie_helper
INFO - 2021-08-03 13:39:01 --> Model "CookieModel" initialized
INFO - 2021-08-03 13:39:01 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 13:39:01 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-03 13:39:01 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 13:39:01 --> Final output sent to browser
DEBUG - 2021-08-03 13:39:01 --> Total execution time: 0.0567
INFO - 2021-08-03 13:42:24 --> Config Class Initialized
INFO - 2021-08-03 13:42:24 --> Hooks Class Initialized
DEBUG - 2021-08-03 13:42:24 --> UTF-8 Support Enabled
INFO - 2021-08-03 13:42:24 --> Utf8 Class Initialized
INFO - 2021-08-03 13:42:24 --> URI Class Initialized
DEBUG - 2021-08-03 13:42:24 --> No URI present. Default controller set.
INFO - 2021-08-03 13:42:24 --> Router Class Initialized
INFO - 2021-08-03 13:42:24 --> Output Class Initialized
INFO - 2021-08-03 13:42:24 --> Security Class Initialized
DEBUG - 2021-08-03 13:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 13:42:24 --> Input Class Initialized
INFO - 2021-08-03 13:42:24 --> Language Class Initialized
INFO - 2021-08-03 13:42:24 --> Loader Class Initialized
INFO - 2021-08-03 13:42:24 --> Helper loaded: url_helper
INFO - 2021-08-03 13:42:24 --> Helper loaded: file_helper
INFO - 2021-08-03 13:42:24 --> Database Driver Class Initialized
DEBUG - 2021-08-03 13:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 13:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 13:42:24 --> Controller Class Initialized
INFO - 2021-08-03 13:42:24 --> Helper loaded: cookie_helper
INFO - 2021-08-03 13:42:24 --> Model "CookieModel" initialized
INFO - 2021-08-03 13:42:24 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 13:42:24 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-03 13:42:24 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 13:42:24 --> Final output sent to browser
DEBUG - 2021-08-03 13:42:24 --> Total execution time: 0.0395
INFO - 2021-08-03 13:46:07 --> Config Class Initialized
INFO - 2021-08-03 13:46:07 --> Hooks Class Initialized
DEBUG - 2021-08-03 13:46:07 --> UTF-8 Support Enabled
INFO - 2021-08-03 13:46:07 --> Utf8 Class Initialized
INFO - 2021-08-03 13:46:07 --> URI Class Initialized
DEBUG - 2021-08-03 13:46:07 --> No URI present. Default controller set.
INFO - 2021-08-03 13:46:07 --> Router Class Initialized
INFO - 2021-08-03 13:46:07 --> Output Class Initialized
INFO - 2021-08-03 13:46:07 --> Security Class Initialized
DEBUG - 2021-08-03 13:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 13:46:07 --> Input Class Initialized
INFO - 2021-08-03 13:46:07 --> Language Class Initialized
INFO - 2021-08-03 13:46:07 --> Loader Class Initialized
INFO - 2021-08-03 13:46:07 --> Helper loaded: url_helper
INFO - 2021-08-03 13:46:07 --> Helper loaded: file_helper
INFO - 2021-08-03 13:46:07 --> Database Driver Class Initialized
DEBUG - 2021-08-03 13:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 13:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 13:46:07 --> Controller Class Initialized
INFO - 2021-08-03 13:46:07 --> Helper loaded: cookie_helper
INFO - 2021-08-03 13:46:07 --> Model "CookieModel" initialized
INFO - 2021-08-03 13:46:07 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 13:46:07 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-03 13:46:07 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 13:46:07 --> Final output sent to browser
DEBUG - 2021-08-03 13:46:07 --> Total execution time: 0.0504
INFO - 2021-08-03 13:47:47 --> Config Class Initialized
INFO - 2021-08-03 13:47:47 --> Hooks Class Initialized
DEBUG - 2021-08-03 13:47:47 --> UTF-8 Support Enabled
INFO - 2021-08-03 13:47:47 --> Utf8 Class Initialized
INFO - 2021-08-03 13:47:47 --> URI Class Initialized
DEBUG - 2021-08-03 13:47:47 --> No URI present. Default controller set.
INFO - 2021-08-03 13:47:47 --> Router Class Initialized
INFO - 2021-08-03 13:47:47 --> Output Class Initialized
INFO - 2021-08-03 13:47:47 --> Security Class Initialized
DEBUG - 2021-08-03 13:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 13:47:47 --> Input Class Initialized
INFO - 2021-08-03 13:47:47 --> Language Class Initialized
INFO - 2021-08-03 13:47:47 --> Loader Class Initialized
INFO - 2021-08-03 13:47:47 --> Helper loaded: url_helper
INFO - 2021-08-03 13:47:47 --> Helper loaded: file_helper
INFO - 2021-08-03 13:47:47 --> Database Driver Class Initialized
DEBUG - 2021-08-03 13:47:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 13:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 13:47:47 --> Controller Class Initialized
INFO - 2021-08-03 13:47:47 --> Helper loaded: cookie_helper
INFO - 2021-08-03 13:47:47 --> Model "CookieModel" initialized
INFO - 2021-08-03 13:47:47 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 13:47:47 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-03 13:47:47 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 13:47:47 --> Final output sent to browser
DEBUG - 2021-08-03 13:47:47 --> Total execution time: 0.0453
INFO - 2021-08-03 13:50:12 --> Config Class Initialized
INFO - 2021-08-03 13:50:12 --> Hooks Class Initialized
DEBUG - 2021-08-03 13:50:12 --> UTF-8 Support Enabled
INFO - 2021-08-03 13:50:12 --> Utf8 Class Initialized
INFO - 2021-08-03 13:50:12 --> URI Class Initialized
DEBUG - 2021-08-03 13:50:12 --> No URI present. Default controller set.
INFO - 2021-08-03 13:50:12 --> Router Class Initialized
INFO - 2021-08-03 13:50:12 --> Output Class Initialized
INFO - 2021-08-03 13:50:12 --> Security Class Initialized
DEBUG - 2021-08-03 13:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 13:50:12 --> Input Class Initialized
INFO - 2021-08-03 13:50:12 --> Language Class Initialized
INFO - 2021-08-03 13:50:12 --> Loader Class Initialized
INFO - 2021-08-03 13:50:12 --> Helper loaded: url_helper
INFO - 2021-08-03 13:50:12 --> Helper loaded: file_helper
INFO - 2021-08-03 13:50:12 --> Database Driver Class Initialized
DEBUG - 2021-08-03 13:50:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 13:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 13:50:12 --> Controller Class Initialized
INFO - 2021-08-03 13:50:12 --> Helper loaded: cookie_helper
INFO - 2021-08-03 13:50:12 --> Model "CookieModel" initialized
INFO - 2021-08-03 13:50:12 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 13:50:12 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-03 13:50:12 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 13:50:12 --> Final output sent to browser
DEBUG - 2021-08-03 13:50:12 --> Total execution time: 0.0425
INFO - 2021-08-03 13:50:51 --> Config Class Initialized
INFO - 2021-08-03 13:50:51 --> Hooks Class Initialized
DEBUG - 2021-08-03 13:50:51 --> UTF-8 Support Enabled
INFO - 2021-08-03 13:50:51 --> Utf8 Class Initialized
INFO - 2021-08-03 13:50:52 --> URI Class Initialized
DEBUG - 2021-08-03 13:50:52 --> No URI present. Default controller set.
INFO - 2021-08-03 13:50:52 --> Router Class Initialized
INFO - 2021-08-03 13:50:52 --> Output Class Initialized
INFO - 2021-08-03 13:50:52 --> Security Class Initialized
DEBUG - 2021-08-03 13:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 13:50:52 --> Input Class Initialized
INFO - 2021-08-03 13:50:52 --> Language Class Initialized
INFO - 2021-08-03 13:50:52 --> Loader Class Initialized
INFO - 2021-08-03 13:50:52 --> Helper loaded: url_helper
INFO - 2021-08-03 13:50:52 --> Helper loaded: file_helper
INFO - 2021-08-03 13:50:52 --> Database Driver Class Initialized
DEBUG - 2021-08-03 13:50:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 13:50:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 13:50:52 --> Controller Class Initialized
INFO - 2021-08-03 13:50:52 --> Helper loaded: cookie_helper
INFO - 2021-08-03 13:50:52 --> Model "CookieModel" initialized
INFO - 2021-08-03 13:50:52 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 13:50:52 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-03 13:50:52 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 13:50:52 --> Final output sent to browser
DEBUG - 2021-08-03 13:50:52 --> Total execution time: 0.0497
INFO - 2021-08-03 14:06:05 --> Config Class Initialized
INFO - 2021-08-03 14:06:05 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:06:05 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:06:05 --> Utf8 Class Initialized
INFO - 2021-08-03 14:06:05 --> URI Class Initialized
DEBUG - 2021-08-03 14:06:05 --> No URI present. Default controller set.
INFO - 2021-08-03 14:06:05 --> Router Class Initialized
INFO - 2021-08-03 14:06:05 --> Output Class Initialized
INFO - 2021-08-03 14:06:05 --> Security Class Initialized
DEBUG - 2021-08-03 14:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:06:05 --> Input Class Initialized
INFO - 2021-08-03 14:06:05 --> Language Class Initialized
INFO - 2021-08-03 14:06:05 --> Loader Class Initialized
INFO - 2021-08-03 14:06:05 --> Helper loaded: url_helper
INFO - 2021-08-03 14:06:05 --> Helper loaded: file_helper
INFO - 2021-08-03 14:06:05 --> Database Driver Class Initialized
DEBUG - 2021-08-03 14:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 14:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 14:06:05 --> Controller Class Initialized
INFO - 2021-08-03 14:06:05 --> Helper loaded: cookie_helper
INFO - 2021-08-03 14:06:05 --> Model "CookieModel" initialized
INFO - 2021-08-03 14:06:05 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 14:06:05 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-03 14:06:05 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 14:06:05 --> Final output sent to browser
DEBUG - 2021-08-03 14:06:05 --> Total execution time: 0.0620
INFO - 2021-08-03 14:08:46 --> Config Class Initialized
INFO - 2021-08-03 14:08:46 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:08:46 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:08:46 --> Utf8 Class Initialized
INFO - 2021-08-03 14:08:46 --> URI Class Initialized
DEBUG - 2021-08-03 14:08:46 --> No URI present. Default controller set.
INFO - 2021-08-03 14:08:46 --> Router Class Initialized
INFO - 2021-08-03 14:08:46 --> Output Class Initialized
INFO - 2021-08-03 14:08:46 --> Security Class Initialized
DEBUG - 2021-08-03 14:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:08:46 --> Input Class Initialized
INFO - 2021-08-03 14:08:46 --> Language Class Initialized
INFO - 2021-08-03 14:08:46 --> Loader Class Initialized
INFO - 2021-08-03 14:08:46 --> Helper loaded: url_helper
INFO - 2021-08-03 14:08:46 --> Helper loaded: file_helper
INFO - 2021-08-03 14:08:46 --> Database Driver Class Initialized
DEBUG - 2021-08-03 14:08:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 14:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 14:08:46 --> Controller Class Initialized
INFO - 2021-08-03 14:08:46 --> Helper loaded: cookie_helper
INFO - 2021-08-03 14:08:46 --> Model "CookieModel" initialized
INFO - 2021-08-03 14:08:46 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 14:08:46 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-03 14:08:46 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 14:08:46 --> Final output sent to browser
DEBUG - 2021-08-03 14:08:46 --> Total execution time: 0.0505
INFO - 2021-08-03 14:09:08 --> Config Class Initialized
INFO - 2021-08-03 14:09:08 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:09:08 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:09:08 --> Utf8 Class Initialized
INFO - 2021-08-03 14:09:08 --> URI Class Initialized
DEBUG - 2021-08-03 14:09:08 --> No URI present. Default controller set.
INFO - 2021-08-03 14:09:08 --> Router Class Initialized
INFO - 2021-08-03 14:09:08 --> Output Class Initialized
INFO - 2021-08-03 14:09:08 --> Security Class Initialized
DEBUG - 2021-08-03 14:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:09:08 --> Input Class Initialized
INFO - 2021-08-03 14:09:08 --> Language Class Initialized
INFO - 2021-08-03 14:09:08 --> Loader Class Initialized
INFO - 2021-08-03 14:09:08 --> Helper loaded: url_helper
INFO - 2021-08-03 14:09:08 --> Helper loaded: file_helper
INFO - 2021-08-03 14:09:08 --> Database Driver Class Initialized
DEBUG - 2021-08-03 14:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 14:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 14:09:08 --> Controller Class Initialized
INFO - 2021-08-03 14:09:08 --> Helper loaded: cookie_helper
INFO - 2021-08-03 14:09:08 --> Model "CookieModel" initialized
INFO - 2021-08-03 14:09:08 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 14:09:08 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-03 14:09:08 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 14:09:08 --> Final output sent to browser
DEBUG - 2021-08-03 14:09:08 --> Total execution time: 0.1013
INFO - 2021-08-03 14:09:33 --> Config Class Initialized
INFO - 2021-08-03 14:09:33 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:09:33 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:09:33 --> Utf8 Class Initialized
INFO - 2021-08-03 14:09:33 --> URI Class Initialized
DEBUG - 2021-08-03 14:09:33 --> No URI present. Default controller set.
INFO - 2021-08-03 14:09:33 --> Router Class Initialized
INFO - 2021-08-03 14:09:33 --> Output Class Initialized
INFO - 2021-08-03 14:09:33 --> Security Class Initialized
DEBUG - 2021-08-03 14:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:09:33 --> Input Class Initialized
INFO - 2021-08-03 14:09:33 --> Language Class Initialized
INFO - 2021-08-03 14:09:33 --> Loader Class Initialized
INFO - 2021-08-03 14:09:33 --> Helper loaded: url_helper
INFO - 2021-08-03 14:09:33 --> Helper loaded: file_helper
INFO - 2021-08-03 14:09:33 --> Database Driver Class Initialized
DEBUG - 2021-08-03 14:09:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 14:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 14:09:33 --> Controller Class Initialized
INFO - 2021-08-03 14:09:33 --> Helper loaded: cookie_helper
INFO - 2021-08-03 14:09:33 --> Model "CookieModel" initialized
INFO - 2021-08-03 14:09:33 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 14:09:33 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-03 14:09:33 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 14:09:33 --> Final output sent to browser
DEBUG - 2021-08-03 14:09:33 --> Total execution time: 0.0446
INFO - 2021-08-03 14:09:54 --> Config Class Initialized
INFO - 2021-08-03 14:09:54 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:09:54 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:09:54 --> Utf8 Class Initialized
INFO - 2021-08-03 14:09:54 --> URI Class Initialized
INFO - 2021-08-03 14:09:54 --> Router Class Initialized
INFO - 2021-08-03 14:09:54 --> Output Class Initialized
INFO - 2021-08-03 14:09:54 --> Security Class Initialized
DEBUG - 2021-08-03 14:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:09:54 --> Input Class Initialized
INFO - 2021-08-03 14:09:54 --> Language Class Initialized
INFO - 2021-08-03 14:09:54 --> Loader Class Initialized
INFO - 2021-08-03 14:09:54 --> Helper loaded: url_helper
INFO - 2021-08-03 14:09:54 --> Helper loaded: file_helper
INFO - 2021-08-03 14:09:54 --> Database Driver Class Initialized
DEBUG - 2021-08-03 14:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 14:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 14:09:54 --> Controller Class Initialized
INFO - 2021-08-03 14:09:54 --> Helper loaded: cookie_helper
INFO - 2021-08-03 14:09:54 --> Model "CookieModel" initialized
INFO - 2021-08-03 14:09:54 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 14:09:54 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-03 14:09:54 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 14:09:54 --> Final output sent to browser
DEBUG - 2021-08-03 14:09:54 --> Total execution time: 0.0477
INFO - 2021-08-03 14:10:14 --> Config Class Initialized
INFO - 2021-08-03 14:10:14 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:10:14 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:10:14 --> Utf8 Class Initialized
INFO - 2021-08-03 14:10:14 --> URI Class Initialized
INFO - 2021-08-03 14:10:14 --> Router Class Initialized
INFO - 2021-08-03 14:10:14 --> Output Class Initialized
INFO - 2021-08-03 14:10:14 --> Security Class Initialized
DEBUG - 2021-08-03 14:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:10:14 --> Input Class Initialized
INFO - 2021-08-03 14:10:14 --> Language Class Initialized
INFO - 2021-08-03 14:10:14 --> Loader Class Initialized
INFO - 2021-08-03 14:10:14 --> Helper loaded: url_helper
INFO - 2021-08-03 14:10:14 --> Helper loaded: file_helper
INFO - 2021-08-03 14:10:14 --> Database Driver Class Initialized
DEBUG - 2021-08-03 14:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 14:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 14:10:14 --> Controller Class Initialized
INFO - 2021-08-03 14:10:14 --> Helper loaded: cookie_helper
INFO - 2021-08-03 14:10:14 --> Model "CookieModel" initialized
INFO - 2021-08-03 14:10:14 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 14:10:14 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-03 14:10:14 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 14:10:14 --> Final output sent to browser
DEBUG - 2021-08-03 14:10:14 --> Total execution time: 0.0401
INFO - 2021-08-03 14:13:08 --> Config Class Initialized
INFO - 2021-08-03 14:13:08 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:13:08 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:13:08 --> Utf8 Class Initialized
INFO - 2021-08-03 14:13:08 --> URI Class Initialized
INFO - 2021-08-03 14:13:08 --> Router Class Initialized
INFO - 2021-08-03 14:13:08 --> Output Class Initialized
INFO - 2021-08-03 14:13:08 --> Security Class Initialized
DEBUG - 2021-08-03 14:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:13:08 --> Input Class Initialized
INFO - 2021-08-03 14:13:08 --> Language Class Initialized
ERROR - 2021-08-03 14:13:08 --> 404 Page Not Found: Functional_training/index
INFO - 2021-08-03 14:13:10 --> Config Class Initialized
INFO - 2021-08-03 14:13:10 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:13:10 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:13:10 --> Utf8 Class Initialized
INFO - 2021-08-03 14:13:10 --> URI Class Initialized
INFO - 2021-08-03 14:13:10 --> Router Class Initialized
INFO - 2021-08-03 14:13:10 --> Output Class Initialized
INFO - 2021-08-03 14:13:10 --> Security Class Initialized
DEBUG - 2021-08-03 14:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:13:10 --> Input Class Initialized
INFO - 2021-08-03 14:13:10 --> Language Class Initialized
INFO - 2021-08-03 14:13:10 --> Loader Class Initialized
INFO - 2021-08-03 14:13:10 --> Helper loaded: url_helper
INFO - 2021-08-03 14:13:10 --> Helper loaded: file_helper
INFO - 2021-08-03 14:13:10 --> Database Driver Class Initialized
DEBUG - 2021-08-03 14:13:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 14:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 14:13:10 --> Controller Class Initialized
INFO - 2021-08-03 14:13:10 --> Helper loaded: cookie_helper
INFO - 2021-08-03 14:13:10 --> Model "CookieModel" initialized
INFO - 2021-08-03 14:13:10 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 14:13:10 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-03 14:13:10 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 14:13:10 --> Final output sent to browser
DEBUG - 2021-08-03 14:13:10 --> Total execution time: 0.0488
INFO - 2021-08-03 14:13:43 --> Config Class Initialized
INFO - 2021-08-03 14:13:43 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:13:43 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:13:43 --> Utf8 Class Initialized
INFO - 2021-08-03 14:13:43 --> URI Class Initialized
INFO - 2021-08-03 14:13:43 --> Router Class Initialized
INFO - 2021-08-03 14:13:43 --> Output Class Initialized
INFO - 2021-08-03 14:13:43 --> Security Class Initialized
DEBUG - 2021-08-03 14:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:13:43 --> Input Class Initialized
INFO - 2021-08-03 14:13:43 --> Language Class Initialized
INFO - 2021-08-03 14:13:43 --> Loader Class Initialized
INFO - 2021-08-03 14:13:43 --> Helper loaded: url_helper
INFO - 2021-08-03 14:13:43 --> Helper loaded: file_helper
INFO - 2021-08-03 14:13:43 --> Database Driver Class Initialized
DEBUG - 2021-08-03 14:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 14:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 14:13:43 --> Controller Class Initialized
INFO - 2021-08-03 14:13:43 --> Helper loaded: cookie_helper
INFO - 2021-08-03 14:13:43 --> Model "CookieModel" initialized
INFO - 2021-08-03 14:13:43 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 14:13:43 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-03 14:13:43 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 14:13:43 --> Final output sent to browser
DEBUG - 2021-08-03 14:13:43 --> Total execution time: 0.0410
INFO - 2021-08-03 14:15:11 --> Config Class Initialized
INFO - 2021-08-03 14:15:11 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:15:11 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:15:11 --> Utf8 Class Initialized
INFO - 2021-08-03 14:15:11 --> URI Class Initialized
INFO - 2021-08-03 14:15:11 --> Router Class Initialized
INFO - 2021-08-03 14:15:11 --> Output Class Initialized
INFO - 2021-08-03 14:15:11 --> Security Class Initialized
DEBUG - 2021-08-03 14:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:15:11 --> Input Class Initialized
INFO - 2021-08-03 14:15:11 --> Language Class Initialized
INFO - 2021-08-03 14:15:11 --> Loader Class Initialized
INFO - 2021-08-03 14:15:11 --> Helper loaded: url_helper
INFO - 2021-08-03 14:15:11 --> Helper loaded: file_helper
INFO - 2021-08-03 14:15:11 --> Database Driver Class Initialized
DEBUG - 2021-08-03 14:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 14:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 14:15:11 --> Controller Class Initialized
INFO - 2021-08-03 14:15:11 --> Helper loaded: cookie_helper
INFO - 2021-08-03 14:15:11 --> Model "CookieModel" initialized
INFO - 2021-08-03 14:15:11 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 14:15:11 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-03 14:15:11 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 14:15:11 --> Final output sent to browser
DEBUG - 2021-08-03 14:15:11 --> Total execution time: 0.0409
INFO - 2021-08-03 14:15:45 --> Config Class Initialized
INFO - 2021-08-03 14:15:45 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:15:45 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:15:45 --> Utf8 Class Initialized
INFO - 2021-08-03 14:15:45 --> URI Class Initialized
INFO - 2021-08-03 14:15:45 --> Router Class Initialized
INFO - 2021-08-03 14:15:45 --> Output Class Initialized
INFO - 2021-08-03 14:15:45 --> Security Class Initialized
DEBUG - 2021-08-03 14:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:15:45 --> Input Class Initialized
INFO - 2021-08-03 14:15:45 --> Language Class Initialized
INFO - 2021-08-03 14:15:45 --> Loader Class Initialized
INFO - 2021-08-03 14:15:45 --> Helper loaded: url_helper
INFO - 2021-08-03 14:15:45 --> Helper loaded: file_helper
INFO - 2021-08-03 14:15:45 --> Database Driver Class Initialized
DEBUG - 2021-08-03 14:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 14:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 14:15:45 --> Controller Class Initialized
INFO - 2021-08-03 14:15:45 --> Helper loaded: cookie_helper
INFO - 2021-08-03 14:15:45 --> Model "CookieModel" initialized
INFO - 2021-08-03 14:15:45 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 14:15:45 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-03 14:15:45 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 14:15:45 --> Final output sent to browser
DEBUG - 2021-08-03 14:15:45 --> Total execution time: 0.0460
INFO - 2021-08-03 14:16:34 --> Config Class Initialized
INFO - 2021-08-03 14:16:34 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:16:34 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:16:34 --> Utf8 Class Initialized
INFO - 2021-08-03 14:16:34 --> URI Class Initialized
INFO - 2021-08-03 14:16:34 --> Router Class Initialized
INFO - 2021-08-03 14:16:34 --> Output Class Initialized
INFO - 2021-08-03 14:16:34 --> Security Class Initialized
DEBUG - 2021-08-03 14:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:16:34 --> Input Class Initialized
INFO - 2021-08-03 14:16:34 --> Language Class Initialized
INFO - 2021-08-03 14:16:34 --> Loader Class Initialized
INFO - 2021-08-03 14:16:34 --> Helper loaded: url_helper
INFO - 2021-08-03 14:16:34 --> Helper loaded: file_helper
INFO - 2021-08-03 14:16:34 --> Database Driver Class Initialized
DEBUG - 2021-08-03 14:16:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 14:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 14:16:34 --> Controller Class Initialized
INFO - 2021-08-03 14:16:34 --> Helper loaded: cookie_helper
INFO - 2021-08-03 14:16:34 --> Model "CookieModel" initialized
INFO - 2021-08-03 14:16:34 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 14:16:34 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-03 14:16:34 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 14:16:34 --> Final output sent to browser
DEBUG - 2021-08-03 14:16:34 --> Total execution time: 0.0505
INFO - 2021-08-03 14:18:57 --> Config Class Initialized
INFO - 2021-08-03 14:18:57 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:18:57 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:18:57 --> Utf8 Class Initialized
INFO - 2021-08-03 14:18:57 --> URI Class Initialized
DEBUG - 2021-08-03 14:18:57 --> No URI present. Default controller set.
INFO - 2021-08-03 14:18:57 --> Router Class Initialized
INFO - 2021-08-03 14:18:57 --> Output Class Initialized
INFO - 2021-08-03 14:18:57 --> Security Class Initialized
DEBUG - 2021-08-03 14:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:18:57 --> Input Class Initialized
INFO - 2021-08-03 14:18:57 --> Language Class Initialized
INFO - 2021-08-03 14:18:57 --> Loader Class Initialized
INFO - 2021-08-03 14:18:57 --> Helper loaded: url_helper
INFO - 2021-08-03 14:18:57 --> Helper loaded: file_helper
INFO - 2021-08-03 14:18:57 --> Database Driver Class Initialized
DEBUG - 2021-08-03 14:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 14:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 14:18:57 --> Controller Class Initialized
INFO - 2021-08-03 14:18:57 --> Helper loaded: cookie_helper
INFO - 2021-08-03 14:18:57 --> Model "CookieModel" initialized
INFO - 2021-08-03 14:18:57 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 14:18:57 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-03 14:18:57 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 14:18:57 --> Final output sent to browser
DEBUG - 2021-08-03 14:18:57 --> Total execution time: 0.0443
INFO - 2021-08-03 14:20:11 --> Config Class Initialized
INFO - 2021-08-03 14:20:11 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:20:11 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:20:11 --> Utf8 Class Initialized
INFO - 2021-08-03 14:20:11 --> URI Class Initialized
DEBUG - 2021-08-03 14:20:11 --> No URI present. Default controller set.
INFO - 2021-08-03 14:20:11 --> Router Class Initialized
INFO - 2021-08-03 14:20:11 --> Output Class Initialized
INFO - 2021-08-03 14:20:11 --> Security Class Initialized
DEBUG - 2021-08-03 14:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:20:11 --> Input Class Initialized
INFO - 2021-08-03 14:20:11 --> Language Class Initialized
INFO - 2021-08-03 14:20:11 --> Loader Class Initialized
INFO - 2021-08-03 14:20:11 --> Helper loaded: url_helper
INFO - 2021-08-03 14:20:11 --> Helper loaded: file_helper
INFO - 2021-08-03 14:20:11 --> Database Driver Class Initialized
DEBUG - 2021-08-03 14:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 14:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 14:20:11 --> Controller Class Initialized
INFO - 2021-08-03 14:20:11 --> Helper loaded: cookie_helper
INFO - 2021-08-03 14:20:11 --> Model "CookieModel" initialized
INFO - 2021-08-03 14:20:11 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 14:20:11 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-03 14:20:11 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 14:20:11 --> Final output sent to browser
DEBUG - 2021-08-03 14:20:11 --> Total execution time: 0.0423
INFO - 2021-08-03 14:20:24 --> Config Class Initialized
INFO - 2021-08-03 14:20:24 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:20:24 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:20:24 --> Utf8 Class Initialized
INFO - 2021-08-03 14:20:24 --> URI Class Initialized
INFO - 2021-08-03 14:20:24 --> Router Class Initialized
INFO - 2021-08-03 14:20:24 --> Output Class Initialized
INFO - 2021-08-03 14:20:24 --> Security Class Initialized
DEBUG - 2021-08-03 14:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:20:24 --> Input Class Initialized
INFO - 2021-08-03 14:20:24 --> Language Class Initialized
ERROR - 2021-08-03 14:20:24 --> 404 Page Not Found: Success_stories/index
INFO - 2021-08-03 14:20:25 --> Config Class Initialized
INFO - 2021-08-03 14:20:25 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:20:25 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:20:25 --> Utf8 Class Initialized
INFO - 2021-08-03 14:20:25 --> URI Class Initialized
DEBUG - 2021-08-03 14:20:25 --> No URI present. Default controller set.
INFO - 2021-08-03 14:20:25 --> Router Class Initialized
INFO - 2021-08-03 14:20:25 --> Output Class Initialized
INFO - 2021-08-03 14:20:25 --> Security Class Initialized
DEBUG - 2021-08-03 14:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:20:25 --> Input Class Initialized
INFO - 2021-08-03 14:20:25 --> Language Class Initialized
INFO - 2021-08-03 14:20:25 --> Loader Class Initialized
INFO - 2021-08-03 14:20:25 --> Helper loaded: url_helper
INFO - 2021-08-03 14:20:25 --> Helper loaded: file_helper
INFO - 2021-08-03 14:20:25 --> Database Driver Class Initialized
DEBUG - 2021-08-03 14:20:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 14:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 14:20:25 --> Controller Class Initialized
INFO - 2021-08-03 14:20:25 --> Helper loaded: cookie_helper
INFO - 2021-08-03 14:20:25 --> Model "CookieModel" initialized
INFO - 2021-08-03 14:20:25 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 14:20:25 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-03 14:20:25 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 14:20:25 --> Final output sent to browser
DEBUG - 2021-08-03 14:20:25 --> Total execution time: 0.0538
INFO - 2021-08-03 14:24:13 --> Config Class Initialized
INFO - 2021-08-03 14:24:13 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:24:13 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:24:13 --> Utf8 Class Initialized
INFO - 2021-08-03 14:24:13 --> URI Class Initialized
DEBUG - 2021-08-03 14:24:13 --> No URI present. Default controller set.
INFO - 2021-08-03 14:24:13 --> Router Class Initialized
INFO - 2021-08-03 14:24:13 --> Output Class Initialized
INFO - 2021-08-03 14:24:13 --> Security Class Initialized
DEBUG - 2021-08-03 14:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:24:13 --> Input Class Initialized
INFO - 2021-08-03 14:24:13 --> Language Class Initialized
INFO - 2021-08-03 14:24:13 --> Loader Class Initialized
INFO - 2021-08-03 14:24:13 --> Helper loaded: url_helper
INFO - 2021-08-03 14:24:13 --> Helper loaded: file_helper
INFO - 2021-08-03 14:24:13 --> Database Driver Class Initialized
DEBUG - 2021-08-03 14:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 14:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 14:24:13 --> Controller Class Initialized
INFO - 2021-08-03 14:24:13 --> Helper loaded: cookie_helper
INFO - 2021-08-03 14:24:13 --> Model "CookieModel" initialized
INFO - 2021-08-03 14:24:13 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 14:24:13 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-03 14:24:13 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 14:24:13 --> Final output sent to browser
DEBUG - 2021-08-03 14:24:13 --> Total execution time: 0.0465
INFO - 2021-08-03 14:24:14 --> Config Class Initialized
INFO - 2021-08-03 14:24:14 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:24:14 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:24:14 --> Utf8 Class Initialized
INFO - 2021-08-03 14:24:14 --> URI Class Initialized
INFO - 2021-08-03 14:24:14 --> Router Class Initialized
INFO - 2021-08-03 14:24:14 --> Output Class Initialized
INFO - 2021-08-03 14:24:14 --> Security Class Initialized
DEBUG - 2021-08-03 14:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:24:14 --> Input Class Initialized
INFO - 2021-08-03 14:24:14 --> Language Class Initialized
INFO - 2021-08-03 14:24:14 --> Loader Class Initialized
INFO - 2021-08-03 14:24:14 --> Helper loaded: url_helper
INFO - 2021-08-03 14:24:14 --> Helper loaded: file_helper
INFO - 2021-08-03 14:24:14 --> Database Driver Class Initialized
DEBUG - 2021-08-03 14:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 14:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 14:24:14 --> Controller Class Initialized
INFO - 2021-08-03 14:24:14 --> Helper loaded: cookie_helper
INFO - 2021-08-03 14:24:14 --> Model "CookieModel" initialized
INFO - 2021-08-03 14:24:14 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 14:24:14 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/functional_training.php
INFO - 2021-08-03 14:24:14 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 14:24:14 --> Final output sent to browser
DEBUG - 2021-08-03 14:24:14 --> Total execution time: 0.0412
INFO - 2021-08-03 14:24:18 --> Config Class Initialized
INFO - 2021-08-03 14:24:18 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:24:18 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:24:18 --> Utf8 Class Initialized
INFO - 2021-08-03 14:24:18 --> URI Class Initialized
INFO - 2021-08-03 14:24:18 --> Router Class Initialized
INFO - 2021-08-03 14:24:18 --> Output Class Initialized
INFO - 2021-08-03 14:24:18 --> Security Class Initialized
DEBUG - 2021-08-03 14:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:24:18 --> Input Class Initialized
INFO - 2021-08-03 14:24:18 --> Language Class Initialized
INFO - 2021-08-03 14:24:18 --> Loader Class Initialized
INFO - 2021-08-03 14:24:18 --> Helper loaded: url_helper
INFO - 2021-08-03 14:24:18 --> Helper loaded: file_helper
INFO - 2021-08-03 14:24:18 --> Database Driver Class Initialized
DEBUG - 2021-08-03 14:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 14:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 14:24:18 --> Controller Class Initialized
INFO - 2021-08-03 14:24:18 --> Helper loaded: cookie_helper
INFO - 2021-08-03 14:24:18 --> Model "CookieModel" initialized
INFO - 2021-08-03 14:24:18 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 14:24:18 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/nutrition_coaching.php
INFO - 2021-08-03 14:24:18 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 14:24:18 --> Final output sent to browser
DEBUG - 2021-08-03 14:24:18 --> Total execution time: 0.0419
INFO - 2021-08-03 14:26:19 --> Config Class Initialized
INFO - 2021-08-03 14:26:19 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:26:19 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:26:19 --> Utf8 Class Initialized
INFO - 2021-08-03 14:26:19 --> URI Class Initialized
INFO - 2021-08-03 14:26:19 --> Router Class Initialized
INFO - 2021-08-03 14:26:19 --> Output Class Initialized
INFO - 2021-08-03 14:26:19 --> Security Class Initialized
DEBUG - 2021-08-03 14:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:26:19 --> Input Class Initialized
INFO - 2021-08-03 14:26:19 --> Language Class Initialized
INFO - 2021-08-03 14:26:19 --> Loader Class Initialized
INFO - 2021-08-03 14:26:19 --> Helper loaded: url_helper
INFO - 2021-08-03 14:26:19 --> Helper loaded: file_helper
INFO - 2021-08-03 14:26:19 --> Database Driver Class Initialized
DEBUG - 2021-08-03 14:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 14:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 14:26:19 --> Controller Class Initialized
INFO - 2021-08-03 14:26:19 --> Helper loaded: cookie_helper
INFO - 2021-08-03 14:26:19 --> Model "CookieModel" initialized
INFO - 2021-08-03 14:26:19 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 14:26:19 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/team.php
INFO - 2021-08-03 14:26:19 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 14:26:19 --> Final output sent to browser
DEBUG - 2021-08-03 14:26:19 --> Total execution time: 0.1189
INFO - 2021-08-03 14:26:47 --> Config Class Initialized
INFO - 2021-08-03 14:26:47 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:26:47 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:26:47 --> Utf8 Class Initialized
INFO - 2021-08-03 14:26:47 --> URI Class Initialized
INFO - 2021-08-03 14:26:47 --> Router Class Initialized
INFO - 2021-08-03 14:26:47 --> Output Class Initialized
INFO - 2021-08-03 14:26:47 --> Security Class Initialized
DEBUG - 2021-08-03 14:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:26:47 --> Input Class Initialized
INFO - 2021-08-03 14:26:47 --> Language Class Initialized
INFO - 2021-08-03 14:26:47 --> Loader Class Initialized
INFO - 2021-08-03 14:26:47 --> Helper loaded: url_helper
INFO - 2021-08-03 14:26:47 --> Helper loaded: file_helper
INFO - 2021-08-03 14:26:47 --> Database Driver Class Initialized
DEBUG - 2021-08-03 14:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 14:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 14:26:47 --> Controller Class Initialized
INFO - 2021-08-03 14:26:47 --> Helper loaded: cookie_helper
INFO - 2021-08-03 14:26:47 --> Model "CookieModel" initialized
INFO - 2021-08-03 14:26:47 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 14:26:47 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/team.php
INFO - 2021-08-03 14:26:47 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 14:26:47 --> Final output sent to browser
DEBUG - 2021-08-03 14:26:47 --> Total execution time: 0.0417
INFO - 2021-08-03 14:26:59 --> Config Class Initialized
INFO - 2021-08-03 14:26:59 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:26:59 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:26:59 --> Utf8 Class Initialized
INFO - 2021-08-03 14:26:59 --> URI Class Initialized
INFO - 2021-08-03 14:26:59 --> Router Class Initialized
INFO - 2021-08-03 14:26:59 --> Output Class Initialized
INFO - 2021-08-03 14:26:59 --> Security Class Initialized
DEBUG - 2021-08-03 14:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:26:59 --> Input Class Initialized
INFO - 2021-08-03 14:26:59 --> Language Class Initialized
INFO - 2021-08-03 14:26:59 --> Loader Class Initialized
INFO - 2021-08-03 14:26:59 --> Helper loaded: url_helper
INFO - 2021-08-03 14:26:59 --> Helper loaded: file_helper
INFO - 2021-08-03 14:26:59 --> Database Driver Class Initialized
DEBUG - 2021-08-03 14:26:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 14:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 14:26:59 --> Controller Class Initialized
INFO - 2021-08-03 14:26:59 --> Helper loaded: cookie_helper
INFO - 2021-08-03 14:26:59 --> Model "CookieModel" initialized
INFO - 2021-08-03 14:26:59 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 14:26:59 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/team.php
INFO - 2021-08-03 14:26:59 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 14:26:59 --> Final output sent to browser
DEBUG - 2021-08-03 14:26:59 --> Total execution time: 0.0397
INFO - 2021-08-03 14:27:09 --> Config Class Initialized
INFO - 2021-08-03 14:27:09 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:27:09 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:27:09 --> Utf8 Class Initialized
INFO - 2021-08-03 14:27:09 --> URI Class Initialized
INFO - 2021-08-03 14:27:09 --> Router Class Initialized
INFO - 2021-08-03 14:27:09 --> Output Class Initialized
INFO - 2021-08-03 14:27:09 --> Security Class Initialized
DEBUG - 2021-08-03 14:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:27:09 --> Input Class Initialized
INFO - 2021-08-03 14:27:09 --> Language Class Initialized
INFO - 2021-08-03 14:27:09 --> Loader Class Initialized
INFO - 2021-08-03 14:27:09 --> Helper loaded: url_helper
INFO - 2021-08-03 14:27:09 --> Helper loaded: file_helper
INFO - 2021-08-03 14:27:09 --> Database Driver Class Initialized
DEBUG - 2021-08-03 14:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 14:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 14:27:09 --> Controller Class Initialized
INFO - 2021-08-03 14:27:09 --> Helper loaded: cookie_helper
INFO - 2021-08-03 14:27:09 --> Model "CookieModel" initialized
INFO - 2021-08-03 14:27:09 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 14:27:09 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/gallery.php
INFO - 2021-08-03 14:27:09 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 14:27:09 --> Final output sent to browser
DEBUG - 2021-08-03 14:27:09 --> Total execution time: 0.0421
INFO - 2021-08-03 14:27:14 --> Config Class Initialized
INFO - 2021-08-03 14:27:14 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:27:14 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:27:14 --> Utf8 Class Initialized
INFO - 2021-08-03 14:27:14 --> URI Class Initialized
INFO - 2021-08-03 14:27:14 --> Router Class Initialized
INFO - 2021-08-03 14:27:14 --> Output Class Initialized
INFO - 2021-08-03 14:27:14 --> Security Class Initialized
DEBUG - 2021-08-03 14:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:27:14 --> Input Class Initialized
INFO - 2021-08-03 14:27:14 --> Language Class Initialized
INFO - 2021-08-03 14:27:14 --> Loader Class Initialized
INFO - 2021-08-03 14:27:14 --> Helper loaded: url_helper
INFO - 2021-08-03 14:27:14 --> Helper loaded: file_helper
INFO - 2021-08-03 14:27:14 --> Database Driver Class Initialized
DEBUG - 2021-08-03 14:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 14:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 14:27:14 --> Controller Class Initialized
INFO - 2021-08-03 14:27:14 --> Helper loaded: cookie_helper
INFO - 2021-08-03 14:27:14 --> Model "CookieModel" initialized
INFO - 2021-08-03 14:27:14 --> Model "ContactModel" initialized
INFO - 2021-08-03 14:27:14 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 14:27:14 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/contact.php
INFO - 2021-08-03 14:27:14 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 14:27:14 --> Final output sent to browser
DEBUG - 2021-08-03 14:27:14 --> Total execution time: 0.0461
INFO - 2021-08-03 14:28:49 --> Config Class Initialized
INFO - 2021-08-03 14:28:49 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:28:49 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:28:49 --> Utf8 Class Initialized
INFO - 2021-08-03 14:28:49 --> URI Class Initialized
INFO - 2021-08-03 14:28:49 --> Router Class Initialized
INFO - 2021-08-03 14:28:49 --> Output Class Initialized
INFO - 2021-08-03 14:28:49 --> Security Class Initialized
DEBUG - 2021-08-03 14:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:28:49 --> Input Class Initialized
INFO - 2021-08-03 14:28:49 --> Language Class Initialized
INFO - 2021-08-03 14:28:49 --> Loader Class Initialized
INFO - 2021-08-03 14:28:49 --> Helper loaded: url_helper
INFO - 2021-08-03 14:28:49 --> Helper loaded: file_helper
INFO - 2021-08-03 14:28:49 --> Database Driver Class Initialized
DEBUG - 2021-08-03 14:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 14:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 14:28:49 --> Controller Class Initialized
INFO - 2021-08-03 14:28:49 --> Helper loaded: cookie_helper
INFO - 2021-08-03 14:28:49 --> Model "CookieModel" initialized
INFO - 2021-08-03 14:28:49 --> Model "ContactModel" initialized
INFO - 2021-08-03 14:28:49 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 14:28:49 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/contact.php
INFO - 2021-08-03 14:28:49 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 14:28:49 --> Final output sent to browser
DEBUG - 2021-08-03 14:28:49 --> Total execution time: 0.0386
INFO - 2021-08-03 14:28:52 --> Config Class Initialized
INFO - 2021-08-03 14:28:52 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:28:52 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:28:52 --> Utf8 Class Initialized
INFO - 2021-08-03 14:28:52 --> URI Class Initialized
INFO - 2021-08-03 14:28:52 --> Router Class Initialized
INFO - 2021-08-03 14:28:52 --> Output Class Initialized
INFO - 2021-08-03 14:28:52 --> Security Class Initialized
DEBUG - 2021-08-03 14:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:28:52 --> Input Class Initialized
INFO - 2021-08-03 14:28:52 --> Language Class Initialized
INFO - 2021-08-03 14:28:52 --> Loader Class Initialized
INFO - 2021-08-03 14:28:52 --> Helper loaded: url_helper
INFO - 2021-08-03 14:28:52 --> Helper loaded: file_helper
INFO - 2021-08-03 14:28:52 --> Database Driver Class Initialized
DEBUG - 2021-08-03 14:28:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 14:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 14:28:53 --> Controller Class Initialized
INFO - 2021-08-03 14:28:53 --> Helper loaded: cookie_helper
INFO - 2021-08-03 14:28:53 --> Model "CookieModel" initialized
INFO - 2021-08-03 14:28:53 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 14:28:53 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-03 14:28:53 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 14:28:53 --> Final output sent to browser
DEBUG - 2021-08-03 14:28:53 --> Total execution time: 0.0428
INFO - 2021-08-03 14:28:56 --> Config Class Initialized
INFO - 2021-08-03 14:28:56 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:28:56 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:28:56 --> Utf8 Class Initialized
INFO - 2021-08-03 14:28:56 --> URI Class Initialized
INFO - 2021-08-03 14:28:56 --> Router Class Initialized
INFO - 2021-08-03 14:28:56 --> Output Class Initialized
INFO - 2021-08-03 14:28:56 --> Security Class Initialized
DEBUG - 2021-08-03 14:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:28:56 --> Input Class Initialized
INFO - 2021-08-03 14:28:56 --> Language Class Initialized
INFO - 2021-08-03 14:28:56 --> Loader Class Initialized
INFO - 2021-08-03 14:28:56 --> Helper loaded: url_helper
INFO - 2021-08-03 14:28:56 --> Helper loaded: file_helper
INFO - 2021-08-03 14:28:56 --> Database Driver Class Initialized
DEBUG - 2021-08-03 14:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 14:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 14:28:56 --> Controller Class Initialized
INFO - 2021-08-03 14:28:56 --> Helper loaded: cookie_helper
INFO - 2021-08-03 14:28:56 --> Model "CookieModel" initialized
INFO - 2021-08-03 14:28:56 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 14:28:56 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/functional_training.php
INFO - 2021-08-03 14:28:56 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 14:28:56 --> Final output sent to browser
DEBUG - 2021-08-03 14:28:56 --> Total execution time: 0.0450
INFO - 2021-08-03 14:30:03 --> Config Class Initialized
INFO - 2021-08-03 14:30:03 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:30:03 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:30:03 --> Utf8 Class Initialized
INFO - 2021-08-03 14:30:03 --> URI Class Initialized
INFO - 2021-08-03 14:30:03 --> Router Class Initialized
INFO - 2021-08-03 14:30:03 --> Output Class Initialized
INFO - 2021-08-03 14:30:03 --> Security Class Initialized
DEBUG - 2021-08-03 14:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:30:03 --> Input Class Initialized
INFO - 2021-08-03 14:30:03 --> Language Class Initialized
INFO - 2021-08-03 14:30:03 --> Loader Class Initialized
INFO - 2021-08-03 14:30:03 --> Helper loaded: url_helper
INFO - 2021-08-03 14:30:03 --> Helper loaded: file_helper
INFO - 2021-08-03 14:30:03 --> Database Driver Class Initialized
DEBUG - 2021-08-03 14:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 14:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 14:30:03 --> Controller Class Initialized
INFO - 2021-08-03 14:30:03 --> Helper loaded: cookie_helper
INFO - 2021-08-03 14:30:03 --> Model "CookieModel" initialized
INFO - 2021-08-03 14:30:03 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 14:30:03 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/functional_training.php
INFO - 2021-08-03 14:30:03 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 14:30:03 --> Final output sent to browser
DEBUG - 2021-08-03 14:30:03 --> Total execution time: 0.0431
INFO - 2021-08-03 14:31:12 --> Config Class Initialized
INFO - 2021-08-03 14:31:12 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:31:12 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:31:12 --> Utf8 Class Initialized
INFO - 2021-08-03 14:31:12 --> URI Class Initialized
INFO - 2021-08-03 14:31:12 --> Router Class Initialized
INFO - 2021-08-03 14:31:12 --> Output Class Initialized
INFO - 2021-08-03 14:31:12 --> Security Class Initialized
DEBUG - 2021-08-03 14:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:31:12 --> Input Class Initialized
INFO - 2021-08-03 14:31:12 --> Language Class Initialized
INFO - 2021-08-03 14:31:12 --> Loader Class Initialized
INFO - 2021-08-03 14:31:12 --> Helper loaded: url_helper
INFO - 2021-08-03 14:31:12 --> Helper loaded: file_helper
INFO - 2021-08-03 14:31:12 --> Database Driver Class Initialized
DEBUG - 2021-08-03 14:31:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 14:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 14:31:12 --> Controller Class Initialized
INFO - 2021-08-03 14:31:12 --> Helper loaded: cookie_helper
INFO - 2021-08-03 14:31:12 --> Model "CookieModel" initialized
INFO - 2021-08-03 14:31:12 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 14:31:12 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/functional_training.php
INFO - 2021-08-03 14:31:12 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 14:31:12 --> Final output sent to browser
DEBUG - 2021-08-03 14:31:12 --> Total execution time: 0.0416
INFO - 2021-08-03 14:37:40 --> Config Class Initialized
INFO - 2021-08-03 14:37:40 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:37:40 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:37:40 --> Utf8 Class Initialized
INFO - 2021-08-03 14:37:40 --> URI Class Initialized
INFO - 2021-08-03 14:37:40 --> Router Class Initialized
INFO - 2021-08-03 14:37:40 --> Output Class Initialized
INFO - 2021-08-03 14:37:40 --> Security Class Initialized
DEBUG - 2021-08-03 14:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:37:40 --> Input Class Initialized
INFO - 2021-08-03 14:37:40 --> Language Class Initialized
INFO - 2021-08-03 14:37:40 --> Loader Class Initialized
INFO - 2021-08-03 14:37:40 --> Helper loaded: url_helper
INFO - 2021-08-03 14:37:40 --> Helper loaded: file_helper
INFO - 2021-08-03 14:37:40 --> Database Driver Class Initialized
DEBUG - 2021-08-03 14:37:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 14:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 14:37:40 --> Controller Class Initialized
INFO - 2021-08-03 14:37:40 --> Helper loaded: cookie_helper
INFO - 2021-08-03 14:37:40 --> Model "CookieModel" initialized
INFO - 2021-08-03 14:37:40 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 14:37:40 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/functional_training.php
INFO - 2021-08-03 14:37:40 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 14:37:40 --> Final output sent to browser
DEBUG - 2021-08-03 14:37:40 --> Total execution time: 0.0582
INFO - 2021-08-03 14:38:54 --> Config Class Initialized
INFO - 2021-08-03 14:38:54 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:38:54 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:38:54 --> Utf8 Class Initialized
INFO - 2021-08-03 14:38:54 --> URI Class Initialized
INFO - 2021-08-03 14:38:54 --> Router Class Initialized
INFO - 2021-08-03 14:38:54 --> Output Class Initialized
INFO - 2021-08-03 14:38:54 --> Security Class Initialized
DEBUG - 2021-08-03 14:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:38:54 --> Input Class Initialized
INFO - 2021-08-03 14:38:54 --> Language Class Initialized
INFO - 2021-08-03 14:38:54 --> Loader Class Initialized
INFO - 2021-08-03 14:38:54 --> Helper loaded: url_helper
INFO - 2021-08-03 14:38:54 --> Helper loaded: file_helper
INFO - 2021-08-03 14:38:54 --> Database Driver Class Initialized
DEBUG - 2021-08-03 14:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 14:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 14:38:54 --> Controller Class Initialized
INFO - 2021-08-03 14:38:54 --> Helper loaded: cookie_helper
INFO - 2021-08-03 14:38:54 --> Model "CookieModel" initialized
INFO - 2021-08-03 14:38:54 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 14:38:54 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/functional_training.php
INFO - 2021-08-03 14:38:54 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 14:38:54 --> Final output sent to browser
DEBUG - 2021-08-03 14:38:54 --> Total execution time: 0.0531
INFO - 2021-08-03 14:39:24 --> Config Class Initialized
INFO - 2021-08-03 14:39:24 --> Hooks Class Initialized
INFO - 2021-08-03 14:39:24 --> Config Class Initialized
INFO - 2021-08-03 14:39:24 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:39:24 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:39:24 --> Utf8 Class Initialized
DEBUG - 2021-08-03 14:39:24 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:39:24 --> Utf8 Class Initialized
INFO - 2021-08-03 14:39:24 --> URI Class Initialized
INFO - 2021-08-03 14:39:24 --> URI Class Initialized
INFO - 2021-08-03 14:39:24 --> Router Class Initialized
INFO - 2021-08-03 14:39:24 --> Router Class Initialized
INFO - 2021-08-03 14:39:24 --> Output Class Initialized
INFO - 2021-08-03 14:39:24 --> Output Class Initialized
INFO - 2021-08-03 14:39:24 --> Security Class Initialized
INFO - 2021-08-03 14:39:24 --> Security Class Initialized
DEBUG - 2021-08-03 14:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:39:24 --> Config Class Initialized
INFO - 2021-08-03 14:39:24 --> Input Class Initialized
INFO - 2021-08-03 14:39:24 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:39:24 --> Input Class Initialized
INFO - 2021-08-03 14:39:24 --> Language Class Initialized
INFO - 2021-08-03 14:39:24 --> Language Class Initialized
ERROR - 2021-08-03 14:39:24 --> 404 Page Not Found: Assets/js
ERROR - 2021-08-03 14:39:24 --> 404 Page Not Found: Assets/js
DEBUG - 2021-08-03 14:39:24 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:39:24 --> Utf8 Class Initialized
INFO - 2021-08-03 14:39:24 --> URI Class Initialized
INFO - 2021-08-03 14:39:24 --> Router Class Initialized
INFO - 2021-08-03 14:39:24 --> Output Class Initialized
INFO - 2021-08-03 14:39:24 --> Security Class Initialized
DEBUG - 2021-08-03 14:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:39:24 --> Input Class Initialized
INFO - 2021-08-03 14:39:24 --> Language Class Initialized
ERROR - 2021-08-03 14:39:24 --> 404 Page Not Found: Assets/js
INFO - 2021-08-03 14:39:24 --> Config Class Initialized
INFO - 2021-08-03 14:39:24 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:39:24 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:39:24 --> Utf8 Class Initialized
INFO - 2021-08-03 14:39:24 --> Config Class Initialized
INFO - 2021-08-03 14:39:24 --> Hooks Class Initialized
INFO - 2021-08-03 14:39:24 --> URI Class Initialized
INFO - 2021-08-03 14:39:24 --> Router Class Initialized
DEBUG - 2021-08-03 14:39:24 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:39:24 --> Utf8 Class Initialized
INFO - 2021-08-03 14:39:24 --> Output Class Initialized
INFO - 2021-08-03 14:39:24 --> URI Class Initialized
INFO - 2021-08-03 14:39:24 --> Security Class Initialized
INFO - 2021-08-03 14:39:24 --> Router Class Initialized
DEBUG - 2021-08-03 14:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:39:24 --> Input Class Initialized
INFO - 2021-08-03 14:39:24 --> Output Class Initialized
INFO - 2021-08-03 14:39:24 --> Language Class Initialized
INFO - 2021-08-03 14:39:24 --> Security Class Initialized
ERROR - 2021-08-03 14:39:24 --> 404 Page Not Found: Assets/css
DEBUG - 2021-08-03 14:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:39:24 --> Input Class Initialized
INFO - 2021-08-03 14:39:24 --> Language Class Initialized
ERROR - 2021-08-03 14:39:24 --> 404 Page Not Found: Assets/css
INFO - 2021-08-03 14:40:48 --> Config Class Initialized
INFO - 2021-08-03 14:40:48 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:40:48 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:40:48 --> Utf8 Class Initialized
INFO - 2021-08-03 14:40:48 --> URI Class Initialized
INFO - 2021-08-03 14:40:48 --> Router Class Initialized
INFO - 2021-08-03 14:40:48 --> Output Class Initialized
INFO - 2021-08-03 14:40:48 --> Security Class Initialized
DEBUG - 2021-08-03 14:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:40:48 --> Input Class Initialized
INFO - 2021-08-03 14:40:48 --> Language Class Initialized
INFO - 2021-08-03 14:40:48 --> Loader Class Initialized
INFO - 2021-08-03 14:40:48 --> Helper loaded: url_helper
INFO - 2021-08-03 14:40:48 --> Helper loaded: file_helper
INFO - 2021-08-03 14:40:48 --> Database Driver Class Initialized
DEBUG - 2021-08-03 14:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 14:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 14:40:48 --> Controller Class Initialized
INFO - 2021-08-03 14:40:48 --> Helper loaded: cookie_helper
INFO - 2021-08-03 14:40:48 --> Model "CookieModel" initialized
INFO - 2021-08-03 14:40:48 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 14:40:48 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/functional_training.php
INFO - 2021-08-03 14:40:48 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 14:40:48 --> Final output sent to browser
DEBUG - 2021-08-03 14:40:48 --> Total execution time: 0.0679
INFO - 2021-08-03 14:40:48 --> Config Class Initialized
INFO - 2021-08-03 14:40:48 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:40:48 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:40:48 --> Utf8 Class Initialized
INFO - 2021-08-03 14:40:48 --> Config Class Initialized
INFO - 2021-08-03 14:40:48 --> URI Class Initialized
INFO - 2021-08-03 14:40:48 --> Hooks Class Initialized
INFO - 2021-08-03 14:40:48 --> Router Class Initialized
INFO - 2021-08-03 14:40:48 --> Output Class Initialized
DEBUG - 2021-08-03 14:40:48 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:40:48 --> Utf8 Class Initialized
INFO - 2021-08-03 14:40:48 --> Security Class Initialized
INFO - 2021-08-03 14:40:48 --> URI Class Initialized
DEBUG - 2021-08-03 14:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:40:48 --> Router Class Initialized
INFO - 2021-08-03 14:40:48 --> Input Class Initialized
INFO - 2021-08-03 14:40:48 --> Language Class Initialized
ERROR - 2021-08-03 14:40:48 --> 404 Page Not Found: Assets/css
INFO - 2021-08-03 14:40:48 --> Output Class Initialized
INFO - 2021-08-03 14:40:49 --> Security Class Initialized
DEBUG - 2021-08-03 14:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:40:49 --> Input Class Initialized
INFO - 2021-08-03 14:40:49 --> Language Class Initialized
ERROR - 2021-08-03 14:40:49 --> 404 Page Not Found: Assets/css
INFO - 2021-08-03 14:40:49 --> Config Class Initialized
INFO - 2021-08-03 14:40:49 --> Hooks Class Initialized
INFO - 2021-08-03 14:40:49 --> Config Class Initialized
INFO - 2021-08-03 14:40:49 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:40:49 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:40:49 --> Utf8 Class Initialized
DEBUG - 2021-08-03 14:40:49 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:40:49 --> Utf8 Class Initialized
INFO - 2021-08-03 14:40:49 --> URI Class Initialized
INFO - 2021-08-03 14:40:49 --> URI Class Initialized
INFO - 2021-08-03 14:40:49 --> Router Class Initialized
INFO - 2021-08-03 14:40:49 --> Router Class Initialized
INFO - 2021-08-03 14:40:49 --> Output Class Initialized
INFO - 2021-08-03 14:40:49 --> Output Class Initialized
INFO - 2021-08-03 14:40:49 --> Security Class Initialized
INFO - 2021-08-03 14:40:49 --> Security Class Initialized
DEBUG - 2021-08-03 14:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-08-03 14:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:40:49 --> Input Class Initialized
INFO - 2021-08-03 14:40:49 --> Input Class Initialized
INFO - 2021-08-03 14:40:49 --> Language Class Initialized
INFO - 2021-08-03 14:40:49 --> Language Class Initialized
ERROR - 2021-08-03 14:40:49 --> 404 Page Not Found: Assets/js
ERROR - 2021-08-03 14:40:49 --> 404 Page Not Found: Assets/js
INFO - 2021-08-03 14:40:49 --> Config Class Initialized
INFO - 2021-08-03 14:40:49 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:40:49 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:40:49 --> Utf8 Class Initialized
INFO - 2021-08-03 14:40:49 --> URI Class Initialized
INFO - 2021-08-03 14:40:49 --> Router Class Initialized
INFO - 2021-08-03 14:40:49 --> Output Class Initialized
INFO - 2021-08-03 14:40:49 --> Security Class Initialized
DEBUG - 2021-08-03 14:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:40:49 --> Input Class Initialized
INFO - 2021-08-03 14:40:49 --> Language Class Initialized
ERROR - 2021-08-03 14:40:49 --> 404 Page Not Found: Assets/js
INFO - 2021-08-03 14:42:15 --> Config Class Initialized
INFO - 2021-08-03 14:42:15 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:42:15 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:42:15 --> Utf8 Class Initialized
INFO - 2021-08-03 14:42:15 --> URI Class Initialized
INFO - 2021-08-03 14:42:15 --> Router Class Initialized
INFO - 2021-08-03 14:42:15 --> Output Class Initialized
INFO - 2021-08-03 14:42:15 --> Security Class Initialized
DEBUG - 2021-08-03 14:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:42:15 --> Input Class Initialized
INFO - 2021-08-03 14:42:15 --> Language Class Initialized
INFO - 2021-08-03 14:42:15 --> Loader Class Initialized
INFO - 2021-08-03 14:42:15 --> Helper loaded: url_helper
INFO - 2021-08-03 14:42:15 --> Helper loaded: file_helper
INFO - 2021-08-03 14:42:15 --> Database Driver Class Initialized
DEBUG - 2021-08-03 14:42:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 14:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 14:42:15 --> Controller Class Initialized
INFO - 2021-08-03 14:42:15 --> Helper loaded: cookie_helper
INFO - 2021-08-03 14:42:15 --> Model "CookieModel" initialized
INFO - 2021-08-03 14:42:15 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 14:42:15 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/functional_training.php
INFO - 2021-08-03 14:42:15 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 14:42:15 --> Final output sent to browser
DEBUG - 2021-08-03 14:42:15 --> Total execution time: 0.0555
INFO - 2021-08-03 14:42:17 --> Config Class Initialized
INFO - 2021-08-03 14:42:17 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:42:17 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:42:17 --> Utf8 Class Initialized
INFO - 2021-08-03 14:42:17 --> URI Class Initialized
INFO - 2021-08-03 14:42:17 --> Router Class Initialized
INFO - 2021-08-03 14:42:17 --> Output Class Initialized
INFO - 2021-08-03 14:42:17 --> Security Class Initialized
DEBUG - 2021-08-03 14:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:42:17 --> Input Class Initialized
INFO - 2021-08-03 14:42:17 --> Language Class Initialized
INFO - 2021-08-03 14:42:17 --> Loader Class Initialized
INFO - 2021-08-03 14:42:17 --> Helper loaded: url_helper
INFO - 2021-08-03 14:42:17 --> Helper loaded: file_helper
INFO - 2021-08-03 14:42:17 --> Database Driver Class Initialized
DEBUG - 2021-08-03 14:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 14:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 14:42:17 --> Controller Class Initialized
INFO - 2021-08-03 14:42:17 --> Helper loaded: cookie_helper
INFO - 2021-08-03 14:42:17 --> Model "CookieModel" initialized
INFO - 2021-08-03 14:42:17 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 14:42:17 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/nutrition_coaching.php
INFO - 2021-08-03 14:42:17 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 14:42:17 --> Final output sent to browser
DEBUG - 2021-08-03 14:42:17 --> Total execution time: 0.0587
INFO - 2021-08-03 14:42:28 --> Config Class Initialized
INFO - 2021-08-03 14:42:28 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:42:28 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:42:28 --> Utf8 Class Initialized
INFO - 2021-08-03 14:42:28 --> URI Class Initialized
INFO - 2021-08-03 14:42:28 --> Router Class Initialized
INFO - 2021-08-03 14:42:28 --> Output Class Initialized
INFO - 2021-08-03 14:42:28 --> Security Class Initialized
DEBUG - 2021-08-03 14:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:42:28 --> Input Class Initialized
INFO - 2021-08-03 14:42:28 --> Language Class Initialized
INFO - 2021-08-03 14:42:28 --> Loader Class Initialized
INFO - 2021-08-03 14:42:28 --> Helper loaded: url_helper
INFO - 2021-08-03 14:42:28 --> Helper loaded: file_helper
INFO - 2021-08-03 14:42:28 --> Database Driver Class Initialized
DEBUG - 2021-08-03 14:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 14:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 14:42:28 --> Controller Class Initialized
INFO - 2021-08-03 14:42:28 --> Helper loaded: cookie_helper
INFO - 2021-08-03 14:42:28 --> Model "CookieModel" initialized
INFO - 2021-08-03 14:42:28 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 14:42:28 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-03 14:42:28 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 14:42:28 --> Final output sent to browser
DEBUG - 2021-08-03 14:42:28 --> Total execution time: 0.0475
INFO - 2021-08-03 14:42:40 --> Config Class Initialized
INFO - 2021-08-03 14:42:40 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:42:40 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:42:40 --> Utf8 Class Initialized
INFO - 2021-08-03 14:42:40 --> URI Class Initialized
DEBUG - 2021-08-03 14:42:40 --> No URI present. Default controller set.
INFO - 2021-08-03 14:42:40 --> Router Class Initialized
INFO - 2021-08-03 14:42:40 --> Output Class Initialized
INFO - 2021-08-03 14:42:40 --> Security Class Initialized
DEBUG - 2021-08-03 14:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:42:40 --> Input Class Initialized
INFO - 2021-08-03 14:42:40 --> Language Class Initialized
INFO - 2021-08-03 14:42:40 --> Loader Class Initialized
INFO - 2021-08-03 14:42:40 --> Helper loaded: url_helper
INFO - 2021-08-03 14:42:40 --> Helper loaded: file_helper
INFO - 2021-08-03 14:42:40 --> Database Driver Class Initialized
DEBUG - 2021-08-03 14:42:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 14:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 14:42:40 --> Controller Class Initialized
INFO - 2021-08-03 14:42:40 --> Helper loaded: cookie_helper
INFO - 2021-08-03 14:42:40 --> Model "CookieModel" initialized
INFO - 2021-08-03 14:42:40 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 14:42:40 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-03 14:42:40 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 14:42:40 --> Final output sent to browser
DEBUG - 2021-08-03 14:42:40 --> Total execution time: 0.0484
INFO - 2021-08-03 14:52:01 --> Config Class Initialized
INFO - 2021-08-03 14:52:01 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:52:01 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:52:01 --> Utf8 Class Initialized
INFO - 2021-08-03 14:52:01 --> URI Class Initialized
DEBUG - 2021-08-03 14:52:01 --> No URI present. Default controller set.
INFO - 2021-08-03 14:52:01 --> Router Class Initialized
INFO - 2021-08-03 14:52:01 --> Output Class Initialized
INFO - 2021-08-03 14:52:01 --> Security Class Initialized
DEBUG - 2021-08-03 14:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:52:01 --> Input Class Initialized
INFO - 2021-08-03 14:52:01 --> Language Class Initialized
INFO - 2021-08-03 14:52:01 --> Loader Class Initialized
INFO - 2021-08-03 14:52:01 --> Helper loaded: url_helper
INFO - 2021-08-03 14:52:01 --> Helper loaded: file_helper
INFO - 2021-08-03 14:52:01 --> Database Driver Class Initialized
DEBUG - 2021-08-03 14:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 14:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 14:52:01 --> Controller Class Initialized
INFO - 2021-08-03 14:52:01 --> Helper loaded: cookie_helper
INFO - 2021-08-03 14:52:01 --> Model "CookieModel" initialized
INFO - 2021-08-03 14:52:01 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 14:52:01 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-03 14:52:01 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 14:52:01 --> Final output sent to browser
DEBUG - 2021-08-03 14:52:01 --> Total execution time: 0.0738
INFO - 2021-08-03 14:52:03 --> Config Class Initialized
INFO - 2021-08-03 14:52:03 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:52:03 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:52:03 --> Utf8 Class Initialized
INFO - 2021-08-03 14:52:03 --> URI Class Initialized
INFO - 2021-08-03 14:52:03 --> Router Class Initialized
INFO - 2021-08-03 14:52:03 --> Output Class Initialized
INFO - 2021-08-03 14:52:03 --> Security Class Initialized
DEBUG - 2021-08-03 14:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:52:03 --> Input Class Initialized
INFO - 2021-08-03 14:52:03 --> Language Class Initialized
INFO - 2021-08-03 14:52:03 --> Loader Class Initialized
INFO - 2021-08-03 14:52:03 --> Helper loaded: url_helper
INFO - 2021-08-03 14:52:03 --> Helper loaded: file_helper
INFO - 2021-08-03 14:52:03 --> Database Driver Class Initialized
DEBUG - 2021-08-03 14:52:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 14:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 14:52:03 --> Controller Class Initialized
INFO - 2021-08-03 14:52:03 --> Helper loaded: cookie_helper
INFO - 2021-08-03 14:52:03 --> Model "CookieModel" initialized
INFO - 2021-08-03 14:52:03 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 14:52:03 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/functional_training.php
INFO - 2021-08-03 14:52:03 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 14:52:03 --> Final output sent to browser
DEBUG - 2021-08-03 14:52:03 --> Total execution time: 0.0479
INFO - 2021-08-03 14:52:08 --> Config Class Initialized
INFO - 2021-08-03 14:52:08 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:52:08 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:52:08 --> Utf8 Class Initialized
INFO - 2021-08-03 14:52:08 --> URI Class Initialized
INFO - 2021-08-03 14:52:08 --> Router Class Initialized
INFO - 2021-08-03 14:52:08 --> Output Class Initialized
INFO - 2021-08-03 14:52:08 --> Security Class Initialized
DEBUG - 2021-08-03 14:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:52:08 --> Input Class Initialized
INFO - 2021-08-03 14:52:08 --> Language Class Initialized
INFO - 2021-08-03 14:52:08 --> Loader Class Initialized
INFO - 2021-08-03 14:52:08 --> Helper loaded: url_helper
INFO - 2021-08-03 14:52:08 --> Helper loaded: file_helper
INFO - 2021-08-03 14:52:08 --> Database Driver Class Initialized
DEBUG - 2021-08-03 14:52:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 14:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 14:52:08 --> Controller Class Initialized
INFO - 2021-08-03 14:52:08 --> Helper loaded: cookie_helper
INFO - 2021-08-03 14:52:08 --> Model "CookieModel" initialized
INFO - 2021-08-03 14:52:08 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 14:52:08 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/nutrition_coaching.php
INFO - 2021-08-03 14:52:08 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 14:52:08 --> Final output sent to browser
DEBUG - 2021-08-03 14:52:08 --> Total execution time: 0.0522
INFO - 2021-08-03 14:52:08 --> Config Class Initialized
INFO - 2021-08-03 14:52:08 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:52:08 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:52:08 --> Utf8 Class Initialized
INFO - 2021-08-03 14:52:08 --> URI Class Initialized
INFO - 2021-08-03 14:52:08 --> Router Class Initialized
INFO - 2021-08-03 14:52:08 --> Output Class Initialized
INFO - 2021-08-03 14:52:08 --> Security Class Initialized
DEBUG - 2021-08-03 14:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:52:08 --> Input Class Initialized
INFO - 2021-08-03 14:52:08 --> Language Class Initialized
INFO - 2021-08-03 14:52:08 --> Loader Class Initialized
INFO - 2021-08-03 14:52:08 --> Helper loaded: url_helper
INFO - 2021-08-03 14:52:08 --> Helper loaded: file_helper
INFO - 2021-08-03 14:52:08 --> Database Driver Class Initialized
DEBUG - 2021-08-03 14:52:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 14:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 14:52:08 --> Controller Class Initialized
INFO - 2021-08-03 14:52:08 --> Helper loaded: cookie_helper
INFO - 2021-08-03 14:52:08 --> Model "CookieModel" initialized
INFO - 2021-08-03 14:52:08 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 14:52:08 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/success_stories.php
INFO - 2021-08-03 14:52:08 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 14:52:08 --> Final output sent to browser
DEBUG - 2021-08-03 14:52:08 --> Total execution time: 0.0488
INFO - 2021-08-03 14:52:12 --> Config Class Initialized
INFO - 2021-08-03 14:52:12 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:52:12 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:52:12 --> Utf8 Class Initialized
INFO - 2021-08-03 14:52:12 --> URI Class Initialized
INFO - 2021-08-03 14:52:12 --> Router Class Initialized
INFO - 2021-08-03 14:52:12 --> Output Class Initialized
INFO - 2021-08-03 14:52:12 --> Security Class Initialized
DEBUG - 2021-08-03 14:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:52:12 --> Input Class Initialized
INFO - 2021-08-03 14:52:12 --> Language Class Initialized
INFO - 2021-08-03 14:52:12 --> Loader Class Initialized
INFO - 2021-08-03 14:52:12 --> Helper loaded: url_helper
INFO - 2021-08-03 14:52:12 --> Helper loaded: file_helper
INFO - 2021-08-03 14:52:12 --> Database Driver Class Initialized
DEBUG - 2021-08-03 14:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 14:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 14:52:12 --> Controller Class Initialized
INFO - 2021-08-03 14:52:12 --> Helper loaded: cookie_helper
INFO - 2021-08-03 14:52:12 --> Model "CookieModel" initialized
INFO - 2021-08-03 14:52:12 --> Model "ContactModel" initialized
INFO - 2021-08-03 14:52:12 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 14:52:12 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/contact.php
INFO - 2021-08-03 14:52:12 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 14:52:12 --> Final output sent to browser
DEBUG - 2021-08-03 14:52:12 --> Total execution time: 0.0494
INFO - 2021-08-03 14:52:13 --> Config Class Initialized
INFO - 2021-08-03 14:52:13 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:52:13 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:52:13 --> Utf8 Class Initialized
INFO - 2021-08-03 14:52:13 --> URI Class Initialized
INFO - 2021-08-03 14:52:13 --> Router Class Initialized
INFO - 2021-08-03 14:52:13 --> Output Class Initialized
INFO - 2021-08-03 14:52:13 --> Security Class Initialized
DEBUG - 2021-08-03 14:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:52:13 --> Input Class Initialized
INFO - 2021-08-03 14:52:13 --> Language Class Initialized
INFO - 2021-08-03 14:52:13 --> Loader Class Initialized
INFO - 2021-08-03 14:52:13 --> Helper loaded: url_helper
INFO - 2021-08-03 14:52:13 --> Helper loaded: file_helper
INFO - 2021-08-03 14:52:13 --> Database Driver Class Initialized
DEBUG - 2021-08-03 14:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 14:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 14:52:13 --> Controller Class Initialized
INFO - 2021-08-03 14:52:13 --> Helper loaded: cookie_helper
INFO - 2021-08-03 14:52:13 --> Model "CookieModel" initialized
INFO - 2021-08-03 14:52:13 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 14:52:13 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/about.php
INFO - 2021-08-03 14:52:13 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 14:52:13 --> Final output sent to browser
DEBUG - 2021-08-03 14:52:13 --> Total execution time: 0.0516
INFO - 2021-08-03 14:52:15 --> Config Class Initialized
INFO - 2021-08-03 14:52:15 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:52:15 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:52:15 --> Utf8 Class Initialized
INFO - 2021-08-03 14:52:15 --> URI Class Initialized
INFO - 2021-08-03 14:52:15 --> Router Class Initialized
INFO - 2021-08-03 14:52:15 --> Output Class Initialized
INFO - 2021-08-03 14:52:15 --> Security Class Initialized
DEBUG - 2021-08-03 14:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:52:15 --> Input Class Initialized
INFO - 2021-08-03 14:52:15 --> Language Class Initialized
INFO - 2021-08-03 14:52:15 --> Loader Class Initialized
INFO - 2021-08-03 14:52:15 --> Helper loaded: url_helper
INFO - 2021-08-03 14:52:15 --> Helper loaded: file_helper
INFO - 2021-08-03 14:52:15 --> Database Driver Class Initialized
DEBUG - 2021-08-03 14:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 14:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 14:52:15 --> Controller Class Initialized
INFO - 2021-08-03 14:52:15 --> Helper loaded: cookie_helper
INFO - 2021-08-03 14:52:15 --> Model "CookieModel" initialized
INFO - 2021-08-03 14:52:15 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 14:52:15 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/about.php
INFO - 2021-08-03 14:52:15 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 14:52:15 --> Final output sent to browser
DEBUG - 2021-08-03 14:52:15 --> Total execution time: 0.0512
INFO - 2021-08-03 14:52:17 --> Config Class Initialized
INFO - 2021-08-03 14:52:17 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:52:17 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:52:17 --> Utf8 Class Initialized
INFO - 2021-08-03 14:52:17 --> URI Class Initialized
INFO - 2021-08-03 14:52:17 --> Router Class Initialized
INFO - 2021-08-03 14:52:17 --> Output Class Initialized
INFO - 2021-08-03 14:52:17 --> Security Class Initialized
DEBUG - 2021-08-03 14:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:52:17 --> Input Class Initialized
INFO - 2021-08-03 14:52:17 --> Language Class Initialized
INFO - 2021-08-03 14:52:17 --> Loader Class Initialized
INFO - 2021-08-03 14:52:17 --> Helper loaded: url_helper
INFO - 2021-08-03 14:52:17 --> Helper loaded: file_helper
INFO - 2021-08-03 14:52:17 --> Database Driver Class Initialized
DEBUG - 2021-08-03 14:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 14:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 14:52:17 --> Controller Class Initialized
INFO - 2021-08-03 14:52:17 --> Helper loaded: cookie_helper
INFO - 2021-08-03 14:52:17 --> Model "CookieModel" initialized
INFO - 2021-08-03 14:52:17 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 14:52:17 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/about.php
INFO - 2021-08-03 14:52:17 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 14:52:17 --> Final output sent to browser
DEBUG - 2021-08-03 14:52:17 --> Total execution time: 0.0467
INFO - 2021-08-03 14:53:06 --> Config Class Initialized
INFO - 2021-08-03 14:53:06 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:53:06 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:53:06 --> Utf8 Class Initialized
INFO - 2021-08-03 14:53:06 --> URI Class Initialized
INFO - 2021-08-03 14:53:06 --> Router Class Initialized
INFO - 2021-08-03 14:53:06 --> Output Class Initialized
INFO - 2021-08-03 14:53:06 --> Security Class Initialized
DEBUG - 2021-08-03 14:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:53:06 --> Input Class Initialized
INFO - 2021-08-03 14:53:06 --> Language Class Initialized
INFO - 2021-08-03 14:53:06 --> Loader Class Initialized
INFO - 2021-08-03 14:53:06 --> Helper loaded: url_helper
INFO - 2021-08-03 14:53:06 --> Helper loaded: file_helper
INFO - 2021-08-03 14:53:06 --> Database Driver Class Initialized
DEBUG - 2021-08-03 14:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 14:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 14:53:06 --> Controller Class Initialized
INFO - 2021-08-03 14:53:06 --> Helper loaded: cookie_helper
INFO - 2021-08-03 14:53:06 --> Model "CookieModel" initialized
INFO - 2021-08-03 14:53:06 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 14:53:06 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/about.php
INFO - 2021-08-03 14:53:06 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 14:53:06 --> Final output sent to browser
DEBUG - 2021-08-03 14:53:06 --> Total execution time: 0.0493
INFO - 2021-08-03 14:53:08 --> Config Class Initialized
INFO - 2021-08-03 14:53:08 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:53:08 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:53:08 --> Utf8 Class Initialized
INFO - 2021-08-03 14:53:08 --> URI Class Initialized
INFO - 2021-08-03 14:53:08 --> Router Class Initialized
INFO - 2021-08-03 14:53:08 --> Output Class Initialized
INFO - 2021-08-03 14:53:08 --> Security Class Initialized
DEBUG - 2021-08-03 14:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:53:08 --> Input Class Initialized
INFO - 2021-08-03 14:53:08 --> Language Class Initialized
INFO - 2021-08-03 14:53:08 --> Loader Class Initialized
INFO - 2021-08-03 14:53:08 --> Helper loaded: url_helper
INFO - 2021-08-03 14:53:08 --> Helper loaded: file_helper
INFO - 2021-08-03 14:53:08 --> Database Driver Class Initialized
DEBUG - 2021-08-03 14:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 14:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 14:53:08 --> Controller Class Initialized
INFO - 2021-08-03 14:53:08 --> Helper loaded: cookie_helper
INFO - 2021-08-03 14:53:08 --> Model "CookieModel" initialized
INFO - 2021-08-03 14:53:08 --> Model "ContactModel" initialized
INFO - 2021-08-03 14:53:08 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 14:53:08 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/contact.php
INFO - 2021-08-03 14:53:08 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 14:53:08 --> Final output sent to browser
DEBUG - 2021-08-03 14:53:08 --> Total execution time: 0.0520
INFO - 2021-08-03 14:53:24 --> Config Class Initialized
INFO - 2021-08-03 14:53:24 --> Hooks Class Initialized
DEBUG - 2021-08-03 14:53:24 --> UTF-8 Support Enabled
INFO - 2021-08-03 14:53:24 --> Utf8 Class Initialized
INFO - 2021-08-03 14:53:24 --> URI Class Initialized
DEBUG - 2021-08-03 14:53:24 --> No URI present. Default controller set.
INFO - 2021-08-03 14:53:24 --> Router Class Initialized
INFO - 2021-08-03 14:53:24 --> Output Class Initialized
INFO - 2021-08-03 14:53:24 --> Security Class Initialized
DEBUG - 2021-08-03 14:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 14:53:24 --> Input Class Initialized
INFO - 2021-08-03 14:53:24 --> Language Class Initialized
INFO - 2021-08-03 14:53:24 --> Loader Class Initialized
INFO - 2021-08-03 14:53:25 --> Helper loaded: url_helper
INFO - 2021-08-03 14:53:25 --> Helper loaded: file_helper
INFO - 2021-08-03 14:53:25 --> Database Driver Class Initialized
DEBUG - 2021-08-03 14:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 14:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 14:53:25 --> Controller Class Initialized
INFO - 2021-08-03 14:53:25 --> Helper loaded: cookie_helper
INFO - 2021-08-03 14:53:25 --> Model "CookieModel" initialized
INFO - 2021-08-03 14:53:25 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 14:53:25 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-03 14:53:25 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 14:53:25 --> Final output sent to browser
DEBUG - 2021-08-03 14:53:25 --> Total execution time: 0.0459
INFO - 2021-08-03 15:18:35 --> Config Class Initialized
INFO - 2021-08-03 15:18:35 --> Hooks Class Initialized
DEBUG - 2021-08-03 15:18:35 --> UTF-8 Support Enabled
INFO - 2021-08-03 15:18:35 --> Utf8 Class Initialized
INFO - 2021-08-03 15:18:35 --> URI Class Initialized
DEBUG - 2021-08-03 15:18:35 --> No URI present. Default controller set.
INFO - 2021-08-03 15:18:35 --> Router Class Initialized
INFO - 2021-08-03 15:18:35 --> Output Class Initialized
INFO - 2021-08-03 15:18:35 --> Security Class Initialized
DEBUG - 2021-08-03 15:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 15:18:35 --> Input Class Initialized
INFO - 2021-08-03 15:18:35 --> Language Class Initialized
INFO - 2021-08-03 15:18:35 --> Loader Class Initialized
INFO - 2021-08-03 15:18:35 --> Helper loaded: url_helper
INFO - 2021-08-03 15:18:35 --> Helper loaded: file_helper
INFO - 2021-08-03 15:18:35 --> Database Driver Class Initialized
DEBUG - 2021-08-03 15:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 15:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 15:18:35 --> Controller Class Initialized
INFO - 2021-08-03 15:18:35 --> Helper loaded: cookie_helper
INFO - 2021-08-03 15:18:35 --> Model "CookieModel" initialized
INFO - 2021-08-03 15:18:35 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 15:18:35 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-03 15:18:35 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 15:18:35 --> Final output sent to browser
DEBUG - 2021-08-03 15:18:35 --> Total execution time: 0.1139
INFO - 2021-08-03 15:18:52 --> Config Class Initialized
INFO - 2021-08-03 15:18:52 --> Hooks Class Initialized
DEBUG - 2021-08-03 15:18:52 --> UTF-8 Support Enabled
INFO - 2021-08-03 15:18:52 --> Utf8 Class Initialized
INFO - 2021-08-03 15:18:52 --> URI Class Initialized
DEBUG - 2021-08-03 15:18:52 --> No URI present. Default controller set.
INFO - 2021-08-03 15:18:52 --> Router Class Initialized
INFO - 2021-08-03 15:18:52 --> Output Class Initialized
INFO - 2021-08-03 15:18:52 --> Security Class Initialized
DEBUG - 2021-08-03 15:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 15:18:52 --> Input Class Initialized
INFO - 2021-08-03 15:18:52 --> Language Class Initialized
INFO - 2021-08-03 15:18:52 --> Loader Class Initialized
INFO - 2021-08-03 15:18:52 --> Helper loaded: url_helper
INFO - 2021-08-03 15:18:52 --> Helper loaded: file_helper
INFO - 2021-08-03 15:18:52 --> Database Driver Class Initialized
DEBUG - 2021-08-03 15:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 15:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 15:18:52 --> Controller Class Initialized
INFO - 2021-08-03 15:18:52 --> Helper loaded: cookie_helper
INFO - 2021-08-03 15:18:52 --> Model "CookieModel" initialized
INFO - 2021-08-03 15:18:52 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 15:18:52 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-03 15:18:52 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 15:18:52 --> Final output sent to browser
DEBUG - 2021-08-03 15:18:52 --> Total execution time: 0.0566
INFO - 2021-08-03 15:20:56 --> Config Class Initialized
INFO - 2021-08-03 15:20:56 --> Hooks Class Initialized
DEBUG - 2021-08-03 15:20:56 --> UTF-8 Support Enabled
INFO - 2021-08-03 15:20:56 --> Utf8 Class Initialized
INFO - 2021-08-03 15:20:56 --> URI Class Initialized
DEBUG - 2021-08-03 15:20:56 --> No URI present. Default controller set.
INFO - 2021-08-03 15:20:56 --> Router Class Initialized
INFO - 2021-08-03 15:20:56 --> Output Class Initialized
INFO - 2021-08-03 15:20:56 --> Security Class Initialized
DEBUG - 2021-08-03 15:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-03 15:20:56 --> Input Class Initialized
INFO - 2021-08-03 15:20:56 --> Language Class Initialized
INFO - 2021-08-03 15:20:56 --> Loader Class Initialized
INFO - 2021-08-03 15:20:56 --> Helper loaded: url_helper
INFO - 2021-08-03 15:20:56 --> Helper loaded: file_helper
INFO - 2021-08-03 15:20:56 --> Database Driver Class Initialized
DEBUG - 2021-08-03 15:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-03 15:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-03 15:20:56 --> Controller Class Initialized
INFO - 2021-08-03 15:20:56 --> Helper loaded: cookie_helper
INFO - 2021-08-03 15:20:56 --> Model "CookieModel" initialized
INFO - 2021-08-03 15:20:56 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-03 15:20:56 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-03 15:20:56 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-03 15:20:56 --> Final output sent to browser
DEBUG - 2021-08-03 15:20:56 --> Total execution time: 0.0435
