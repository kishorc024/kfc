<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-09-24 11:36:01 --> Config Class Initialized
INFO - 2021-09-24 11:36:01 --> Hooks Class Initialized
DEBUG - 2021-09-24 11:36:01 --> UTF-8 Support Enabled
INFO - 2021-09-24 11:36:01 --> Utf8 Class Initialized
INFO - 2021-09-24 11:36:01 --> URI Class Initialized
INFO - 2021-09-24 11:36:01 --> Router Class Initialized
INFO - 2021-09-24 11:36:01 --> Output Class Initialized
INFO - 2021-09-24 11:36:01 --> Security Class Initialized
DEBUG - 2021-09-24 11:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 11:36:01 --> Input Class Initialized
INFO - 2021-09-24 11:36:01 --> Language Class Initialized
INFO - 2021-09-24 11:36:01 --> Loader Class Initialized
INFO - 2021-09-24 11:36:01 --> Helper loaded: url_helper
INFO - 2021-09-24 11:36:01 --> Helper loaded: file_helper
DEBUG - 2021-09-24 11:36:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 11:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 11:36:02 --> Controller Class Initialized
INFO - 2021-09-24 11:36:02 --> Model "DBModel" initialized
DEBUG - 2021-09-24 11:36:02 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 11:36:02 --> Helper loaded: cookie_helper
INFO - 2021-09-24 11:36:02 --> Database Driver Class Initialized
INFO - 2021-09-24 11:36:02 --> Helper loaded: string_helper
INFO - 2021-09-24 11:36:02 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 11:36:02 --> Model "BlogModel" initialized
INFO - 2021-09-24 11:36:02 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-24 11:36:02 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 11:36:02 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 11:36:02 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/testimonials.php
INFO - 2021-09-24 11:36:02 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 11:36:02 --> Final output sent to browser
DEBUG - 2021-09-24 11:36:02 --> Total execution time: 1.4231
INFO - 2021-09-24 11:36:03 --> Config Class Initialized
INFO - 2021-09-24 11:36:03 --> Hooks Class Initialized
DEBUG - 2021-09-24 11:36:03 --> UTF-8 Support Enabled
INFO - 2021-09-24 11:36:03 --> Utf8 Class Initialized
INFO - 2021-09-24 11:36:03 --> URI Class Initialized
INFO - 2021-09-24 11:36:03 --> Router Class Initialized
INFO - 2021-09-24 11:36:03 --> Output Class Initialized
INFO - 2021-09-24 11:36:03 --> Security Class Initialized
DEBUG - 2021-09-24 11:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 11:36:03 --> Input Class Initialized
INFO - 2021-09-24 11:36:03 --> Language Class Initialized
ERROR - 2021-09-24 11:36:04 --> 404 Page Not Found: Testimonialpics/.png
INFO - 2021-09-24 11:36:19 --> Config Class Initialized
INFO - 2021-09-24 11:36:19 --> Hooks Class Initialized
DEBUG - 2021-09-24 11:36:19 --> UTF-8 Support Enabled
INFO - 2021-09-24 11:36:19 --> Utf8 Class Initialized
INFO - 2021-09-24 11:36:19 --> URI Class Initialized
INFO - 2021-09-24 11:36:19 --> Router Class Initialized
INFO - 2021-09-24 11:36:19 --> Output Class Initialized
INFO - 2021-09-24 11:36:19 --> Security Class Initialized
DEBUG - 2021-09-24 11:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 11:36:19 --> Input Class Initialized
INFO - 2021-09-24 11:36:19 --> Language Class Initialized
INFO - 2021-09-24 11:36:19 --> Loader Class Initialized
INFO - 2021-09-24 11:36:19 --> Helper loaded: url_helper
INFO - 2021-09-24 11:36:19 --> Helper loaded: file_helper
DEBUG - 2021-09-24 11:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 11:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 11:36:19 --> Controller Class Initialized
DEBUG - 2021-09-24 11:36:19 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 11:36:19 --> Helper loaded: cookie_helper
INFO - 2021-09-24 11:36:19 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\login.php
INFO - 2021-09-24 11:36:19 --> Final output sent to browser
DEBUG - 2021-09-24 11:36:19 --> Total execution time: 0.1170
INFO - 2021-09-24 11:36:20 --> Config Class Initialized
INFO - 2021-09-24 11:36:20 --> Hooks Class Initialized
DEBUG - 2021-09-24 11:36:20 --> UTF-8 Support Enabled
INFO - 2021-09-24 11:36:20 --> Utf8 Class Initialized
INFO - 2021-09-24 11:36:20 --> URI Class Initialized
INFO - 2021-09-24 11:36:20 --> Router Class Initialized
INFO - 2021-09-24 11:36:20 --> Output Class Initialized
INFO - 2021-09-24 11:36:20 --> Security Class Initialized
DEBUG - 2021-09-24 11:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 11:36:20 --> Input Class Initialized
INFO - 2021-09-24 11:36:20 --> Language Class Initialized
INFO - 2021-09-24 11:36:20 --> Loader Class Initialized
INFO - 2021-09-24 11:36:20 --> Helper loaded: url_helper
INFO - 2021-09-24 11:36:20 --> Helper loaded: file_helper
DEBUG - 2021-09-24 11:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 11:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 11:36:20 --> Controller Class Initialized
INFO - 2021-09-24 11:36:20 --> Helper loaded: cookie_helper
INFO - 2021-09-24 11:36:20 --> Model "CookieModel" initialized
INFO - 2021-09-24 11:36:20 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 11:36:20 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/team.php
INFO - 2021-09-24 11:36:20 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 11:36:20 --> Final output sent to browser
DEBUG - 2021-09-24 11:36:20 --> Total execution time: 0.1691
INFO - 2021-09-24 11:36:41 --> Config Class Initialized
INFO - 2021-09-24 11:36:41 --> Hooks Class Initialized
DEBUG - 2021-09-24 11:36:41 --> UTF-8 Support Enabled
INFO - 2021-09-24 11:36:41 --> Utf8 Class Initialized
INFO - 2021-09-24 11:36:41 --> URI Class Initialized
INFO - 2021-09-24 11:36:41 --> Router Class Initialized
INFO - 2021-09-24 11:36:41 --> Output Class Initialized
INFO - 2021-09-24 11:36:41 --> Security Class Initialized
DEBUG - 2021-09-24 11:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 11:36:41 --> Input Class Initialized
INFO - 2021-09-24 11:36:41 --> Language Class Initialized
INFO - 2021-09-24 11:36:41 --> Loader Class Initialized
INFO - 2021-09-24 11:36:41 --> Helper loaded: url_helper
INFO - 2021-09-24 11:36:41 --> Helper loaded: file_helper
DEBUG - 2021-09-24 11:36:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 11:36:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 11:36:41 --> Controller Class Initialized
INFO - 2021-09-24 11:36:41 --> Model "DBModel" initialized
DEBUG - 2021-09-24 11:36:41 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 11:36:41 --> Helper loaded: cookie_helper
INFO - 2021-09-24 11:36:41 --> Database Driver Class Initialized
INFO - 2021-09-24 11:36:41 --> Helper loaded: string_helper
INFO - 2021-09-24 11:36:41 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 11:36:41 --> Model "BlogModel" initialized
INFO - 2021-09-24 11:36:41 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-24 11:36:41 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 11:36:41 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 11:36:41 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/testimonials.php
INFO - 2021-09-24 11:36:41 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 11:36:41 --> Final output sent to browser
DEBUG - 2021-09-24 11:36:41 --> Total execution time: 0.0857
INFO - 2021-09-24 11:36:41 --> Config Class Initialized
INFO - 2021-09-24 11:36:41 --> Hooks Class Initialized
DEBUG - 2021-09-24 11:36:41 --> UTF-8 Support Enabled
INFO - 2021-09-24 11:36:41 --> Utf8 Class Initialized
INFO - 2021-09-24 11:36:41 --> URI Class Initialized
INFO - 2021-09-24 11:36:41 --> Router Class Initialized
INFO - 2021-09-24 11:36:41 --> Output Class Initialized
INFO - 2021-09-24 11:36:41 --> Security Class Initialized
DEBUG - 2021-09-24 11:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 11:36:41 --> Input Class Initialized
INFO - 2021-09-24 11:36:41 --> Language Class Initialized
ERROR - 2021-09-24 11:36:41 --> 404 Page Not Found: Testimonialpics/.png
INFO - 2021-09-24 12:16:12 --> Config Class Initialized
INFO - 2021-09-24 12:16:12 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:16:12 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:16:12 --> Utf8 Class Initialized
INFO - 2021-09-24 12:16:12 --> URI Class Initialized
INFO - 2021-09-24 12:16:12 --> Router Class Initialized
INFO - 2021-09-24 12:16:12 --> Output Class Initialized
INFO - 2021-09-24 12:16:12 --> Security Class Initialized
DEBUG - 2021-09-24 12:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:16:12 --> Input Class Initialized
INFO - 2021-09-24 12:16:12 --> Language Class Initialized
INFO - 2021-09-24 12:16:12 --> Loader Class Initialized
INFO - 2021-09-24 12:16:12 --> Helper loaded: url_helper
INFO - 2021-09-24 12:16:12 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:16:12 --> Controller Class Initialized
INFO - 2021-09-24 12:16:12 --> Database Driver Class Initialized
INFO - 2021-09-24 12:16:12 --> Helper loaded: string_helper
INFO - 2021-09-24 12:16:12 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 12:16:12 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:16:12 --> Model "CookieModel" initialized
INFO - 2021-09-24 12:16:12 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 12:16:12 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/testimonials.php
INFO - 2021-09-24 12:16:12 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 12:16:12 --> Final output sent to browser
DEBUG - 2021-09-24 12:16:12 --> Total execution time: 0.0967
INFO - 2021-09-24 12:16:17 --> Config Class Initialized
INFO - 2021-09-24 12:16:17 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:16:17 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:16:17 --> Utf8 Class Initialized
INFO - 2021-09-24 12:16:17 --> URI Class Initialized
INFO - 2021-09-24 12:16:17 --> Router Class Initialized
INFO - 2021-09-24 12:16:17 --> Output Class Initialized
INFO - 2021-09-24 12:16:17 --> Security Class Initialized
DEBUG - 2021-09-24 12:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:16:17 --> Input Class Initialized
INFO - 2021-09-24 12:16:17 --> Language Class Initialized
INFO - 2021-09-24 12:16:17 --> Loader Class Initialized
INFO - 2021-09-24 12:16:17 --> Helper loaded: url_helper
INFO - 2021-09-24 12:16:17 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:16:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:16:17 --> Controller Class Initialized
INFO - 2021-09-24 12:16:17 --> Database Driver Class Initialized
INFO - 2021-09-24 12:16:17 --> Helper loaded: string_helper
INFO - 2021-09-24 12:16:17 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 12:16:17 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:16:17 --> Model "CookieModel" initialized
INFO - 2021-09-24 12:16:17 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 12:16:17 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/videotestimonials.php
INFO - 2021-09-24 12:16:17 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 12:16:17 --> Final output sent to browser
DEBUG - 2021-09-24 12:16:17 --> Total execution time: 0.1149
INFO - 2021-09-24 12:16:27 --> Config Class Initialized
INFO - 2021-09-24 12:16:27 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:16:27 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:16:27 --> Utf8 Class Initialized
INFO - 2021-09-24 12:16:27 --> URI Class Initialized
INFO - 2021-09-24 12:16:27 --> Router Class Initialized
INFO - 2021-09-24 12:16:27 --> Output Class Initialized
INFO - 2021-09-24 12:16:27 --> Security Class Initialized
DEBUG - 2021-09-24 12:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:16:27 --> Input Class Initialized
INFO - 2021-09-24 12:16:27 --> Language Class Initialized
INFO - 2021-09-24 12:16:27 --> Loader Class Initialized
INFO - 2021-09-24 12:16:27 --> Helper loaded: url_helper
INFO - 2021-09-24 12:16:27 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:16:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:16:27 --> Controller Class Initialized
INFO - 2021-09-24 12:16:27 --> Database Driver Class Initialized
INFO - 2021-09-24 12:16:27 --> Helper loaded: string_helper
INFO - 2021-09-24 12:16:27 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 12:16:27 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:16:27 --> Model "CookieModel" initialized
INFO - 2021-09-24 12:16:27 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 12:16:27 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/testimonials.php
INFO - 2021-09-24 12:16:27 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 12:16:27 --> Final output sent to browser
DEBUG - 2021-09-24 12:16:27 --> Total execution time: 0.0738
INFO - 2021-09-24 12:16:35 --> Config Class Initialized
INFO - 2021-09-24 12:16:35 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:16:35 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:16:35 --> Utf8 Class Initialized
INFO - 2021-09-24 12:16:35 --> URI Class Initialized
INFO - 2021-09-24 12:16:35 --> Router Class Initialized
INFO - 2021-09-24 12:16:35 --> Output Class Initialized
INFO - 2021-09-24 12:16:35 --> Security Class Initialized
DEBUG - 2021-09-24 12:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:16:35 --> Input Class Initialized
INFO - 2021-09-24 12:16:35 --> Language Class Initialized
INFO - 2021-09-24 12:16:35 --> Loader Class Initialized
INFO - 2021-09-24 12:16:35 --> Helper loaded: url_helper
INFO - 2021-09-24 12:16:35 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:16:35 --> Controller Class Initialized
INFO - 2021-09-24 12:16:35 --> Database Driver Class Initialized
INFO - 2021-09-24 12:16:35 --> Helper loaded: string_helper
INFO - 2021-09-24 12:16:35 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 12:16:35 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:16:35 --> Model "CookieModel" initialized
INFO - 2021-09-24 12:16:35 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 12:16:35 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/videotestimonials.php
INFO - 2021-09-24 12:16:35 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 12:16:35 --> Final output sent to browser
DEBUG - 2021-09-24 12:16:35 --> Total execution time: 0.0688
INFO - 2021-09-24 12:16:59 --> Config Class Initialized
INFO - 2021-09-24 12:16:59 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:16:59 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:16:59 --> Utf8 Class Initialized
INFO - 2021-09-24 12:16:59 --> URI Class Initialized
INFO - 2021-09-24 12:16:59 --> Router Class Initialized
INFO - 2021-09-24 12:16:59 --> Output Class Initialized
INFO - 2021-09-24 12:16:59 --> Security Class Initialized
DEBUG - 2021-09-24 12:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:16:59 --> Input Class Initialized
INFO - 2021-09-24 12:16:59 --> Language Class Initialized
INFO - 2021-09-24 12:16:59 --> Loader Class Initialized
INFO - 2021-09-24 12:16:59 --> Helper loaded: url_helper
INFO - 2021-09-24 12:16:59 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:16:59 --> Controller Class Initialized
INFO - 2021-09-24 12:16:59 --> Model "DBModel" initialized
DEBUG - 2021-09-24 12:16:59 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 12:16:59 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:16:59 --> Database Driver Class Initialized
INFO - 2021-09-24 12:16:59 --> Helper loaded: string_helper
INFO - 2021-09-24 12:16:59 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 12:16:59 --> Model "BlogModel" initialized
INFO - 2021-09-24 12:16:59 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-24 12:16:59 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 12:16:59 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 12:16:59 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/blogs.php
INFO - 2021-09-24 12:16:59 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 12:16:59 --> Final output sent to browser
DEBUG - 2021-09-24 12:16:59 --> Total execution time: 0.1391
INFO - 2021-09-24 12:17:03 --> Config Class Initialized
INFO - 2021-09-24 12:17:03 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:17:03 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:17:03 --> Utf8 Class Initialized
INFO - 2021-09-24 12:17:03 --> URI Class Initialized
INFO - 2021-09-24 12:17:03 --> Router Class Initialized
INFO - 2021-09-24 12:17:03 --> Output Class Initialized
INFO - 2021-09-24 12:17:03 --> Security Class Initialized
DEBUG - 2021-09-24 12:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:17:03 --> Input Class Initialized
INFO - 2021-09-24 12:17:03 --> Language Class Initialized
INFO - 2021-09-24 12:17:03 --> Loader Class Initialized
INFO - 2021-09-24 12:17:03 --> Helper loaded: url_helper
INFO - 2021-09-24 12:17:03 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:17:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:17:03 --> Controller Class Initialized
INFO - 2021-09-24 12:17:03 --> Model "DBModel" initialized
DEBUG - 2021-09-24 12:17:03 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 12:17:03 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:17:03 --> Database Driver Class Initialized
INFO - 2021-09-24 12:17:03 --> Helper loaded: string_helper
INFO - 2021-09-24 12:17:03 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 12:17:03 --> Model "BlogModel" initialized
INFO - 2021-09-24 12:17:03 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-24 12:17:03 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 12:17:03 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 12:17:03 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/blog.php
INFO - 2021-09-24 12:17:03 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 12:17:03 --> Final output sent to browser
DEBUG - 2021-09-24 12:17:03 --> Total execution time: 0.0815
INFO - 2021-09-24 12:17:33 --> Config Class Initialized
INFO - 2021-09-24 12:17:33 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:17:33 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:17:33 --> Utf8 Class Initialized
INFO - 2021-09-24 12:17:33 --> URI Class Initialized
INFO - 2021-09-24 12:17:33 --> Router Class Initialized
INFO - 2021-09-24 12:17:33 --> Output Class Initialized
INFO - 2021-09-24 12:17:33 --> Security Class Initialized
DEBUG - 2021-09-24 12:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:17:33 --> Input Class Initialized
INFO - 2021-09-24 12:17:33 --> Language Class Initialized
INFO - 2021-09-24 12:17:33 --> Loader Class Initialized
INFO - 2021-09-24 12:17:33 --> Helper loaded: url_helper
INFO - 2021-09-24 12:17:33 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:17:33 --> Controller Class Initialized
INFO - 2021-09-24 12:17:33 --> Model "DBModel" initialized
DEBUG - 2021-09-24 12:17:33 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 12:17:33 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:17:33 --> Database Driver Class Initialized
INFO - 2021-09-24 12:17:33 --> Helper loaded: string_helper
INFO - 2021-09-24 12:17:33 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 12:17:33 --> Model "BlogModel" initialized
INFO - 2021-09-24 12:17:33 --> Config Class Initialized
INFO - 2021-09-24 12:17:33 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:17:33 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:17:33 --> Utf8 Class Initialized
INFO - 2021-09-24 12:17:33 --> URI Class Initialized
INFO - 2021-09-24 12:17:33 --> Router Class Initialized
INFO - 2021-09-24 12:17:33 --> Output Class Initialized
INFO - 2021-09-24 12:17:33 --> Security Class Initialized
DEBUG - 2021-09-24 12:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:17:33 --> Input Class Initialized
INFO - 2021-09-24 12:17:33 --> Language Class Initialized
INFO - 2021-09-24 12:17:33 --> Loader Class Initialized
INFO - 2021-09-24 12:17:33 --> Helper loaded: url_helper
INFO - 2021-09-24 12:17:33 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:17:33 --> Controller Class Initialized
INFO - 2021-09-24 12:17:33 --> Model "DBModel" initialized
DEBUG - 2021-09-24 12:17:33 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 12:17:33 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:17:33 --> Database Driver Class Initialized
INFO - 2021-09-24 12:17:33 --> Helper loaded: string_helper
INFO - 2021-09-24 12:17:33 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 12:17:33 --> Model "BlogModel" initialized
INFO - 2021-09-24 12:17:33 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-24 12:17:33 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 12:17:33 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 12:17:33 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/blogs.php
INFO - 2021-09-24 12:17:33 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 12:17:33 --> Final output sent to browser
DEBUG - 2021-09-24 12:17:33 --> Total execution time: 0.0773
INFO - 2021-09-24 12:24:43 --> Config Class Initialized
INFO - 2021-09-24 12:24:43 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:24:43 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:24:43 --> Utf8 Class Initialized
INFO - 2021-09-24 12:24:43 --> URI Class Initialized
INFO - 2021-09-24 12:24:43 --> Router Class Initialized
INFO - 2021-09-24 12:24:43 --> Output Class Initialized
INFO - 2021-09-24 12:24:43 --> Security Class Initialized
DEBUG - 2021-09-24 12:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:24:43 --> Input Class Initialized
INFO - 2021-09-24 12:24:43 --> Language Class Initialized
INFO - 2021-09-24 12:24:43 --> Loader Class Initialized
INFO - 2021-09-24 12:24:43 --> Helper loaded: url_helper
INFO - 2021-09-24 12:24:43 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:24:43 --> Controller Class Initialized
DEBUG - 2021-09-24 12:24:43 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 12:24:43 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:24:43 --> Config Class Initialized
INFO - 2021-09-24 12:24:43 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:24:43 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:24:43 --> Utf8 Class Initialized
INFO - 2021-09-24 12:24:43 --> URI Class Initialized
INFO - 2021-09-24 12:24:43 --> Router Class Initialized
INFO - 2021-09-24 12:24:43 --> Output Class Initialized
INFO - 2021-09-24 12:24:43 --> Security Class Initialized
DEBUG - 2021-09-24 12:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:24:43 --> Input Class Initialized
INFO - 2021-09-24 12:24:43 --> Language Class Initialized
INFO - 2021-09-24 12:24:43 --> Loader Class Initialized
INFO - 2021-09-24 12:24:43 --> Helper loaded: url_helper
INFO - 2021-09-24 12:24:43 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:24:43 --> Controller Class Initialized
INFO - 2021-09-24 12:24:43 --> Model "DBModel" initialized
DEBUG - 2021-09-24 12:24:43 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 12:24:43 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:24:43 --> Database Driver Class Initialized
INFO - 2021-09-24 12:24:43 --> Helper loaded: string_helper
INFO - 2021-09-24 12:24:43 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 12:24:43 --> Model "BlogModel" initialized
INFO - 2021-09-24 12:24:43 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-24 12:24:43 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 12:24:43 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 12:24:43 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/dashboard.php
INFO - 2021-09-24 12:24:43 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 12:24:43 --> Final output sent to browser
DEBUG - 2021-09-24 12:24:43 --> Total execution time: 0.1037
INFO - 2021-09-24 12:24:46 --> Config Class Initialized
INFO - 2021-09-24 12:24:46 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:24:46 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:24:46 --> Utf8 Class Initialized
INFO - 2021-09-24 12:24:46 --> URI Class Initialized
INFO - 2021-09-24 12:24:46 --> Router Class Initialized
INFO - 2021-09-24 12:24:46 --> Output Class Initialized
INFO - 2021-09-24 12:24:46 --> Security Class Initialized
DEBUG - 2021-09-24 12:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:24:46 --> Input Class Initialized
INFO - 2021-09-24 12:24:46 --> Language Class Initialized
INFO - 2021-09-24 12:24:46 --> Loader Class Initialized
INFO - 2021-09-24 12:24:46 --> Helper loaded: url_helper
INFO - 2021-09-24 12:24:46 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:24:46 --> Controller Class Initialized
INFO - 2021-09-24 12:24:46 --> Model "DBModel" initialized
DEBUG - 2021-09-24 12:24:46 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 12:24:46 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:24:46 --> Database Driver Class Initialized
INFO - 2021-09-24 12:24:46 --> Helper loaded: string_helper
INFO - 2021-09-24 12:24:46 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 12:24:46 --> Model "BlogModel" initialized
INFO - 2021-09-24 12:24:46 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-24 12:24:46 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 12:24:46 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 12:24:46 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/blogs.php
INFO - 2021-09-24 12:24:46 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 12:24:46 --> Final output sent to browser
DEBUG - 2021-09-24 12:24:46 --> Total execution time: 0.0750
INFO - 2021-09-24 12:24:48 --> Config Class Initialized
INFO - 2021-09-24 12:24:48 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:24:48 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:24:48 --> Utf8 Class Initialized
INFO - 2021-09-24 12:24:48 --> URI Class Initialized
INFO - 2021-09-24 12:24:48 --> Router Class Initialized
INFO - 2021-09-24 12:24:48 --> Output Class Initialized
INFO - 2021-09-24 12:24:48 --> Security Class Initialized
DEBUG - 2021-09-24 12:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:24:48 --> Input Class Initialized
INFO - 2021-09-24 12:24:48 --> Language Class Initialized
INFO - 2021-09-24 12:24:48 --> Loader Class Initialized
INFO - 2021-09-24 12:24:48 --> Helper loaded: url_helper
INFO - 2021-09-24 12:24:48 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:24:48 --> Controller Class Initialized
INFO - 2021-09-24 12:24:48 --> Model "DBModel" initialized
DEBUG - 2021-09-24 12:24:48 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 12:24:48 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:24:48 --> Database Driver Class Initialized
INFO - 2021-09-24 12:24:48 --> Helper loaded: string_helper
INFO - 2021-09-24 12:24:48 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 12:24:48 --> Model "BlogModel" initialized
INFO - 2021-09-24 12:24:48 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-24 12:24:48 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 12:24:48 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 12:24:48 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/blog.php
INFO - 2021-09-24 12:24:48 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 12:24:48 --> Final output sent to browser
DEBUG - 2021-09-24 12:24:48 --> Total execution time: 0.0757
INFO - 2021-09-24 12:26:23 --> Config Class Initialized
INFO - 2021-09-24 12:26:23 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:26:23 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:26:23 --> Utf8 Class Initialized
INFO - 2021-09-24 12:26:23 --> URI Class Initialized
INFO - 2021-09-24 12:26:23 --> Router Class Initialized
INFO - 2021-09-24 12:26:23 --> Output Class Initialized
INFO - 2021-09-24 12:26:23 --> Security Class Initialized
DEBUG - 2021-09-24 12:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:26:23 --> Input Class Initialized
INFO - 2021-09-24 12:26:23 --> Language Class Initialized
INFO - 2021-09-24 12:26:23 --> Loader Class Initialized
INFO - 2021-09-24 12:26:23 --> Helper loaded: url_helper
INFO - 2021-09-24 12:26:23 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:26:23 --> Controller Class Initialized
INFO - 2021-09-24 12:26:23 --> Model "DBModel" initialized
DEBUG - 2021-09-24 12:26:23 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 12:26:23 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:26:23 --> Database Driver Class Initialized
INFO - 2021-09-24 12:26:23 --> Helper loaded: string_helper
INFO - 2021-09-24 12:26:23 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 12:26:23 --> Model "BlogModel" initialized
INFO - 2021-09-24 12:26:23 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-24 12:26:23 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 12:26:23 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 12:26:23 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/blog.php
INFO - 2021-09-24 12:26:23 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 12:26:23 --> Final output sent to browser
DEBUG - 2021-09-24 12:26:23 --> Total execution time: 0.0771
INFO - 2021-09-24 12:28:42 --> Config Class Initialized
INFO - 2021-09-24 12:28:42 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:28:42 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:28:42 --> Utf8 Class Initialized
INFO - 2021-09-24 12:28:42 --> URI Class Initialized
INFO - 2021-09-24 12:28:42 --> Router Class Initialized
INFO - 2021-09-24 12:28:42 --> Output Class Initialized
INFO - 2021-09-24 12:28:42 --> Security Class Initialized
DEBUG - 2021-09-24 12:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:28:42 --> Input Class Initialized
INFO - 2021-09-24 12:28:42 --> Language Class Initialized
INFO - 2021-09-24 12:28:43 --> Loader Class Initialized
INFO - 2021-09-24 12:28:43 --> Helper loaded: url_helper
INFO - 2021-09-24 12:28:43 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:28:43 --> Controller Class Initialized
INFO - 2021-09-24 12:28:43 --> Model "DBModel" initialized
DEBUG - 2021-09-24 12:28:43 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 12:28:43 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:28:43 --> Database Driver Class Initialized
INFO - 2021-09-24 12:28:43 --> Helper loaded: string_helper
INFO - 2021-09-24 12:28:43 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 12:28:43 --> Model "BlogModel" initialized
INFO - 2021-09-24 12:28:43 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-24 12:28:43 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 12:28:43 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 12:28:43 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/blog.php
INFO - 2021-09-24 12:28:43 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 12:28:43 --> Final output sent to browser
DEBUG - 2021-09-24 12:28:43 --> Total execution time: 0.0814
INFO - 2021-09-24 12:32:00 --> Config Class Initialized
INFO - 2021-09-24 12:32:00 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:32:00 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:32:00 --> Utf8 Class Initialized
INFO - 2021-09-24 12:32:00 --> URI Class Initialized
INFO - 2021-09-24 12:32:00 --> Router Class Initialized
INFO - 2021-09-24 12:32:00 --> Output Class Initialized
INFO - 2021-09-24 12:32:00 --> Security Class Initialized
DEBUG - 2021-09-24 12:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:32:00 --> Input Class Initialized
INFO - 2021-09-24 12:32:00 --> Language Class Initialized
INFO - 2021-09-24 12:32:00 --> Loader Class Initialized
INFO - 2021-09-24 12:32:00 --> Helper loaded: url_helper
INFO - 2021-09-24 12:32:00 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:32:00 --> Controller Class Initialized
INFO - 2021-09-24 12:32:01 --> Database Driver Class Initialized
INFO - 2021-09-24 12:32:01 --> Helper loaded: string_helper
INFO - 2021-09-24 12:32:01 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 12:32:01 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:32:01 --> Model "CookieModel" initialized
INFO - 2021-09-24 12:32:01 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 12:32:01 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/videotestimonials.php
INFO - 2021-09-24 12:32:01 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 12:32:01 --> Final output sent to browser
DEBUG - 2021-09-24 12:32:01 --> Total execution time: 0.0956
INFO - 2021-09-24 12:32:04 --> Config Class Initialized
INFO - 2021-09-24 12:32:04 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:32:04 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:32:04 --> Utf8 Class Initialized
INFO - 2021-09-24 12:32:04 --> URI Class Initialized
INFO - 2021-09-24 12:32:04 --> Router Class Initialized
INFO - 2021-09-24 12:32:04 --> Output Class Initialized
INFO - 2021-09-24 12:32:04 --> Security Class Initialized
DEBUG - 2021-09-24 12:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:32:04 --> Input Class Initialized
INFO - 2021-09-24 12:32:04 --> Language Class Initialized
INFO - 2021-09-24 12:32:04 --> Loader Class Initialized
INFO - 2021-09-24 12:32:04 --> Helper loaded: url_helper
INFO - 2021-09-24 12:32:04 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:32:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:32:04 --> Controller Class Initialized
INFO - 2021-09-24 12:32:04 --> Model "DBModel" initialized
DEBUG - 2021-09-24 12:32:04 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 12:32:04 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:32:04 --> Database Driver Class Initialized
INFO - 2021-09-24 12:32:04 --> Helper loaded: string_helper
INFO - 2021-09-24 12:32:04 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 12:32:04 --> Model "BlogModel" initialized
INFO - 2021-09-24 12:32:04 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-24 12:32:04 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 12:32:04 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 12:32:04 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/blogs.php
INFO - 2021-09-24 12:32:04 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 12:32:04 --> Final output sent to browser
DEBUG - 2021-09-24 12:32:04 --> Total execution time: 0.0774
INFO - 2021-09-24 12:32:05 --> Config Class Initialized
INFO - 2021-09-24 12:32:05 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:32:05 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:32:05 --> Utf8 Class Initialized
INFO - 2021-09-24 12:32:05 --> URI Class Initialized
INFO - 2021-09-24 12:32:05 --> Router Class Initialized
INFO - 2021-09-24 12:32:05 --> Output Class Initialized
INFO - 2021-09-24 12:32:05 --> Security Class Initialized
DEBUG - 2021-09-24 12:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:32:05 --> Input Class Initialized
INFO - 2021-09-24 12:32:05 --> Language Class Initialized
INFO - 2021-09-24 12:32:05 --> Loader Class Initialized
INFO - 2021-09-24 12:32:05 --> Helper loaded: url_helper
INFO - 2021-09-24 12:32:05 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:32:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:32:05 --> Controller Class Initialized
INFO - 2021-09-24 12:32:05 --> Model "DBModel" initialized
DEBUG - 2021-09-24 12:32:05 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 12:32:05 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:32:05 --> Database Driver Class Initialized
INFO - 2021-09-24 12:32:05 --> Helper loaded: string_helper
INFO - 2021-09-24 12:32:05 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 12:32:05 --> Model "BlogModel" initialized
INFO - 2021-09-24 12:32:05 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-24 12:32:05 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 12:32:05 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 12:32:05 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/blogs.php
INFO - 2021-09-24 12:32:05 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 12:32:05 --> Final output sent to browser
DEBUG - 2021-09-24 12:32:05 --> Total execution time: 0.0747
INFO - 2021-09-24 12:32:08 --> Config Class Initialized
INFO - 2021-09-24 12:32:08 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:32:08 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:32:08 --> Utf8 Class Initialized
INFO - 2021-09-24 12:32:08 --> URI Class Initialized
INFO - 2021-09-24 12:32:08 --> Router Class Initialized
INFO - 2021-09-24 12:32:08 --> Output Class Initialized
INFO - 2021-09-24 12:32:08 --> Security Class Initialized
DEBUG - 2021-09-24 12:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:32:08 --> Input Class Initialized
INFO - 2021-09-24 12:32:08 --> Language Class Initialized
INFO - 2021-09-24 12:32:08 --> Loader Class Initialized
INFO - 2021-09-24 12:32:08 --> Helper loaded: url_helper
INFO - 2021-09-24 12:32:08 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:32:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:32:08 --> Controller Class Initialized
INFO - 2021-09-24 12:32:08 --> Model "DBModel" initialized
DEBUG - 2021-09-24 12:32:08 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 12:32:08 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:32:08 --> Database Driver Class Initialized
INFO - 2021-09-24 12:32:08 --> Helper loaded: string_helper
INFO - 2021-09-24 12:32:08 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 12:32:08 --> Model "BlogModel" initialized
INFO - 2021-09-24 12:32:08 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-24 12:32:08 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 12:32:08 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 12:32:08 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/blog.php
INFO - 2021-09-24 12:32:08 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 12:32:08 --> Final output sent to browser
DEBUG - 2021-09-24 12:32:08 --> Total execution time: 0.0765
INFO - 2021-09-24 12:32:10 --> Config Class Initialized
INFO - 2021-09-24 12:32:10 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:32:10 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:32:10 --> Utf8 Class Initialized
INFO - 2021-09-24 12:32:10 --> URI Class Initialized
INFO - 2021-09-24 12:32:10 --> Router Class Initialized
INFO - 2021-09-24 12:32:10 --> Output Class Initialized
INFO - 2021-09-24 12:32:10 --> Security Class Initialized
DEBUG - 2021-09-24 12:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:32:10 --> Input Class Initialized
INFO - 2021-09-24 12:32:10 --> Language Class Initialized
INFO - 2021-09-24 12:32:10 --> Loader Class Initialized
INFO - 2021-09-24 12:32:10 --> Helper loaded: url_helper
INFO - 2021-09-24 12:32:10 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:32:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:32:10 --> Controller Class Initialized
INFO - 2021-09-24 12:32:10 --> Model "DBModel" initialized
DEBUG - 2021-09-24 12:32:10 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 12:32:10 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:32:10 --> Database Driver Class Initialized
INFO - 2021-09-24 12:32:10 --> Helper loaded: string_helper
INFO - 2021-09-24 12:32:10 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 12:32:10 --> Model "BlogModel" initialized
INFO - 2021-09-24 12:32:10 --> Config Class Initialized
INFO - 2021-09-24 12:32:10 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:32:10 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:32:10 --> Utf8 Class Initialized
INFO - 2021-09-24 12:32:10 --> URI Class Initialized
INFO - 2021-09-24 12:32:10 --> Router Class Initialized
INFO - 2021-09-24 12:32:10 --> Output Class Initialized
INFO - 2021-09-24 12:32:10 --> Security Class Initialized
DEBUG - 2021-09-24 12:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:32:10 --> Input Class Initialized
INFO - 2021-09-24 12:32:10 --> Language Class Initialized
INFO - 2021-09-24 12:32:10 --> Loader Class Initialized
INFO - 2021-09-24 12:32:10 --> Helper loaded: url_helper
INFO - 2021-09-24 12:32:10 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:32:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:32:10 --> Controller Class Initialized
INFO - 2021-09-24 12:32:10 --> Model "DBModel" initialized
DEBUG - 2021-09-24 12:32:10 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 12:32:10 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:32:10 --> Database Driver Class Initialized
INFO - 2021-09-24 12:32:10 --> Helper loaded: string_helper
INFO - 2021-09-24 12:32:10 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 12:32:10 --> Model "BlogModel" initialized
INFO - 2021-09-24 12:32:10 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-24 12:32:10 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 12:32:10 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 12:32:10 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/blogs.php
INFO - 2021-09-24 12:32:10 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 12:32:10 --> Final output sent to browser
DEBUG - 2021-09-24 12:32:10 --> Total execution time: 0.1705
INFO - 2021-09-24 12:32:49 --> Config Class Initialized
INFO - 2021-09-24 12:32:49 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:32:49 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:32:49 --> Utf8 Class Initialized
INFO - 2021-09-24 12:32:49 --> URI Class Initialized
INFO - 2021-09-24 12:32:49 --> Router Class Initialized
INFO - 2021-09-24 12:32:49 --> Output Class Initialized
INFO - 2021-09-24 12:32:49 --> Security Class Initialized
DEBUG - 2021-09-24 12:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:32:49 --> Input Class Initialized
INFO - 2021-09-24 12:32:49 --> Language Class Initialized
INFO - 2021-09-24 12:32:49 --> Loader Class Initialized
INFO - 2021-09-24 12:32:49 --> Helper loaded: url_helper
INFO - 2021-09-24 12:32:49 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:32:49 --> Controller Class Initialized
INFO - 2021-09-24 12:32:49 --> Model "DBModel" initialized
DEBUG - 2021-09-24 12:32:49 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 12:32:49 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:32:49 --> Database Driver Class Initialized
INFO - 2021-09-24 12:32:49 --> Helper loaded: string_helper
INFO - 2021-09-24 12:32:49 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 12:32:49 --> Model "BlogModel" initialized
INFO - 2021-09-24 12:32:49 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-24 12:32:49 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 12:32:49 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 12:32:49 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/blogs.php
INFO - 2021-09-24 12:32:49 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 12:32:49 --> Final output sent to browser
DEBUG - 2021-09-24 12:32:49 --> Total execution time: 0.0722
INFO - 2021-09-24 12:32:51 --> Config Class Initialized
INFO - 2021-09-24 12:32:51 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:32:51 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:32:51 --> Utf8 Class Initialized
INFO - 2021-09-24 12:32:51 --> URI Class Initialized
INFO - 2021-09-24 12:32:51 --> Router Class Initialized
INFO - 2021-09-24 12:32:51 --> Output Class Initialized
INFO - 2021-09-24 12:32:51 --> Security Class Initialized
DEBUG - 2021-09-24 12:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:32:51 --> Input Class Initialized
INFO - 2021-09-24 12:32:51 --> Language Class Initialized
INFO - 2021-09-24 12:32:51 --> Loader Class Initialized
INFO - 2021-09-24 12:32:51 --> Helper loaded: url_helper
INFO - 2021-09-24 12:32:51 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:32:51 --> Controller Class Initialized
INFO - 2021-09-24 12:32:51 --> Model "DBModel" initialized
DEBUG - 2021-09-24 12:32:51 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 12:32:51 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:32:51 --> Database Driver Class Initialized
INFO - 2021-09-24 12:32:51 --> Helper loaded: string_helper
INFO - 2021-09-24 12:32:51 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 12:32:51 --> Model "BlogModel" initialized
INFO - 2021-09-24 12:32:51 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-24 12:32:51 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 12:32:51 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 12:32:51 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/blog.php
INFO - 2021-09-24 12:32:51 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 12:32:51 --> Final output sent to browser
DEBUG - 2021-09-24 12:32:51 --> Total execution time: 0.0754
INFO - 2021-09-24 12:32:53 --> Config Class Initialized
INFO - 2021-09-24 12:32:53 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:32:53 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:32:53 --> Utf8 Class Initialized
INFO - 2021-09-24 12:32:53 --> URI Class Initialized
INFO - 2021-09-24 12:32:53 --> Router Class Initialized
INFO - 2021-09-24 12:32:53 --> Output Class Initialized
INFO - 2021-09-24 12:32:53 --> Security Class Initialized
DEBUG - 2021-09-24 12:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:32:53 --> Input Class Initialized
INFO - 2021-09-24 12:32:53 --> Language Class Initialized
INFO - 2021-09-24 12:32:53 --> Loader Class Initialized
INFO - 2021-09-24 12:32:53 --> Helper loaded: url_helper
INFO - 2021-09-24 12:32:53 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:32:53 --> Controller Class Initialized
INFO - 2021-09-24 12:32:53 --> Model "DBModel" initialized
DEBUG - 2021-09-24 12:32:53 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 12:32:53 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:32:53 --> Database Driver Class Initialized
INFO - 2021-09-24 12:32:53 --> Helper loaded: string_helper
INFO - 2021-09-24 12:32:53 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 12:32:53 --> Model "BlogModel" initialized
INFO - 2021-09-24 12:32:53 --> Config Class Initialized
INFO - 2021-09-24 12:32:53 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:32:53 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:32:53 --> Utf8 Class Initialized
INFO - 2021-09-24 12:32:53 --> URI Class Initialized
INFO - 2021-09-24 12:32:53 --> Router Class Initialized
INFO - 2021-09-24 12:32:53 --> Output Class Initialized
INFO - 2021-09-24 12:32:53 --> Security Class Initialized
DEBUG - 2021-09-24 12:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:32:53 --> Input Class Initialized
INFO - 2021-09-24 12:32:53 --> Language Class Initialized
INFO - 2021-09-24 12:32:53 --> Loader Class Initialized
INFO - 2021-09-24 12:32:53 --> Helper loaded: url_helper
INFO - 2021-09-24 12:32:53 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:32:53 --> Controller Class Initialized
INFO - 2021-09-24 12:32:53 --> Model "DBModel" initialized
DEBUG - 2021-09-24 12:32:53 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 12:32:53 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:32:53 --> Database Driver Class Initialized
INFO - 2021-09-24 12:32:53 --> Helper loaded: string_helper
INFO - 2021-09-24 12:32:53 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 12:32:53 --> Model "BlogModel" initialized
INFO - 2021-09-24 12:32:53 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-24 12:32:53 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 12:32:53 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 12:32:53 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/blogs.php
INFO - 2021-09-24 12:32:53 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 12:32:53 --> Final output sent to browser
DEBUG - 2021-09-24 12:32:53 --> Total execution time: 0.1499
INFO - 2021-09-24 12:35:48 --> Config Class Initialized
INFO - 2021-09-24 12:35:48 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:35:48 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:35:48 --> Utf8 Class Initialized
INFO - 2021-09-24 12:35:48 --> URI Class Initialized
DEBUG - 2021-09-24 12:35:48 --> No URI present. Default controller set.
INFO - 2021-09-24 12:35:48 --> Router Class Initialized
INFO - 2021-09-24 12:35:48 --> Output Class Initialized
INFO - 2021-09-24 12:35:48 --> Security Class Initialized
DEBUG - 2021-09-24 12:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:35:48 --> Input Class Initialized
INFO - 2021-09-24 12:35:48 --> Language Class Initialized
INFO - 2021-09-24 12:35:48 --> Loader Class Initialized
INFO - 2021-09-24 12:35:48 --> Helper loaded: url_helper
INFO - 2021-09-24 12:35:48 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:35:48 --> Controller Class Initialized
INFO - 2021-09-24 12:35:48 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:35:48 --> Model "CookieModel" initialized
INFO - 2021-09-24 12:35:48 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 12:35:48 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/index.php
INFO - 2021-09-24 12:35:48 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 12:35:48 --> Final output sent to browser
DEBUG - 2021-09-24 12:35:48 --> Total execution time: 0.0604
INFO - 2021-09-24 12:40:22 --> Config Class Initialized
INFO - 2021-09-24 12:40:22 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:40:22 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:40:22 --> Utf8 Class Initialized
INFO - 2021-09-24 12:40:22 --> URI Class Initialized
DEBUG - 2021-09-24 12:40:22 --> No URI present. Default controller set.
INFO - 2021-09-24 12:40:22 --> Router Class Initialized
INFO - 2021-09-24 12:40:22 --> Output Class Initialized
INFO - 2021-09-24 12:40:22 --> Security Class Initialized
DEBUG - 2021-09-24 12:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:40:22 --> Input Class Initialized
INFO - 2021-09-24 12:40:22 --> Language Class Initialized
INFO - 2021-09-24 12:40:22 --> Loader Class Initialized
INFO - 2021-09-24 12:40:22 --> Helper loaded: url_helper
INFO - 2021-09-24 12:40:22 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:40:22 --> Controller Class Initialized
INFO - 2021-09-24 12:40:22 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:40:22 --> Model "CookieModel" initialized
INFO - 2021-09-24 12:40:22 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 12:40:22 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/index.php
INFO - 2021-09-24 12:40:22 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 12:40:22 --> Final output sent to browser
DEBUG - 2021-09-24 12:40:22 --> Total execution time: 0.0971
INFO - 2021-09-24 12:41:25 --> Config Class Initialized
INFO - 2021-09-24 12:41:25 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:41:25 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:41:25 --> Utf8 Class Initialized
INFO - 2021-09-24 12:41:25 --> URI Class Initialized
DEBUG - 2021-09-24 12:41:25 --> No URI present. Default controller set.
INFO - 2021-09-24 12:41:25 --> Router Class Initialized
INFO - 2021-09-24 12:41:25 --> Output Class Initialized
INFO - 2021-09-24 12:41:25 --> Security Class Initialized
DEBUG - 2021-09-24 12:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:41:25 --> Input Class Initialized
INFO - 2021-09-24 12:41:25 --> Language Class Initialized
INFO - 2021-09-24 12:41:25 --> Loader Class Initialized
INFO - 2021-09-24 12:41:25 --> Helper loaded: url_helper
INFO - 2021-09-24 12:41:25 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:41:25 --> Controller Class Initialized
INFO - 2021-09-24 12:41:25 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:41:25 --> Model "CookieModel" initialized
INFO - 2021-09-24 12:41:25 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 12:41:25 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/index.php
INFO - 2021-09-24 12:41:25 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 12:41:25 --> Final output sent to browser
DEBUG - 2021-09-24 12:41:25 --> Total execution time: 0.0579
INFO - 2021-09-24 12:41:33 --> Config Class Initialized
INFO - 2021-09-24 12:41:33 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:41:33 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:41:33 --> Utf8 Class Initialized
INFO - 2021-09-24 12:41:33 --> URI Class Initialized
INFO - 2021-09-24 12:41:33 --> Router Class Initialized
INFO - 2021-09-24 12:41:33 --> Output Class Initialized
INFO - 2021-09-24 12:41:33 --> Security Class Initialized
DEBUG - 2021-09-24 12:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:41:33 --> Input Class Initialized
INFO - 2021-09-24 12:41:33 --> Language Class Initialized
INFO - 2021-09-24 12:41:33 --> Loader Class Initialized
INFO - 2021-09-24 12:41:33 --> Helper loaded: url_helper
INFO - 2021-09-24 12:41:33 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:41:33 --> Controller Class Initialized
DEBUG - 2021-09-24 12:41:33 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 12:41:33 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:41:33 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\login.php
INFO - 2021-09-24 12:41:33 --> Final output sent to browser
DEBUG - 2021-09-24 12:41:33 --> Total execution time: 0.0543
INFO - 2021-09-24 12:41:37 --> Config Class Initialized
INFO - 2021-09-24 12:41:37 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:41:37 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:41:37 --> Utf8 Class Initialized
INFO - 2021-09-24 12:41:37 --> URI Class Initialized
INFO - 2021-09-24 12:41:37 --> Router Class Initialized
INFO - 2021-09-24 12:41:37 --> Output Class Initialized
INFO - 2021-09-24 12:41:37 --> Security Class Initialized
DEBUG - 2021-09-24 12:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:41:37 --> Input Class Initialized
INFO - 2021-09-24 12:41:37 --> Language Class Initialized
INFO - 2021-09-24 12:41:37 --> Loader Class Initialized
INFO - 2021-09-24 12:41:37 --> Helper loaded: url_helper
INFO - 2021-09-24 12:41:37 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:41:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:41:37 --> Controller Class Initialized
DEBUG - 2021-09-24 12:41:37 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 12:41:37 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:41:37 --> Config Class Initialized
INFO - 2021-09-24 12:41:37 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:41:37 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:41:37 --> Utf8 Class Initialized
INFO - 2021-09-24 12:41:37 --> URI Class Initialized
INFO - 2021-09-24 12:41:37 --> Router Class Initialized
INFO - 2021-09-24 12:41:37 --> Output Class Initialized
INFO - 2021-09-24 12:41:37 --> Security Class Initialized
DEBUG - 2021-09-24 12:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:41:37 --> Input Class Initialized
INFO - 2021-09-24 12:41:37 --> Language Class Initialized
INFO - 2021-09-24 12:41:37 --> Loader Class Initialized
INFO - 2021-09-24 12:41:37 --> Helper loaded: url_helper
INFO - 2021-09-24 12:41:37 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:41:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:41:37 --> Controller Class Initialized
INFO - 2021-09-24 12:41:37 --> Model "DBModel" initialized
DEBUG - 2021-09-24 12:41:37 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 12:41:37 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:41:37 --> Database Driver Class Initialized
INFO - 2021-09-24 12:41:37 --> Helper loaded: string_helper
INFO - 2021-09-24 12:41:37 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 12:41:37 --> Model "BlogModel" initialized
INFO - 2021-09-24 12:41:37 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-24 12:41:37 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 12:41:37 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 12:41:37 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/dashboard.php
INFO - 2021-09-24 12:41:37 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 12:41:37 --> Final output sent to browser
DEBUG - 2021-09-24 12:41:37 --> Total execution time: 0.0707
INFO - 2021-09-24 12:41:40 --> Config Class Initialized
INFO - 2021-09-24 12:41:40 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:41:40 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:41:40 --> Utf8 Class Initialized
INFO - 2021-09-24 12:41:40 --> URI Class Initialized
INFO - 2021-09-24 12:41:40 --> Router Class Initialized
INFO - 2021-09-24 12:41:40 --> Output Class Initialized
INFO - 2021-09-24 12:41:40 --> Security Class Initialized
DEBUG - 2021-09-24 12:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:41:40 --> Input Class Initialized
INFO - 2021-09-24 12:41:40 --> Language Class Initialized
INFO - 2021-09-24 12:41:40 --> Loader Class Initialized
INFO - 2021-09-24 12:41:40 --> Helper loaded: url_helper
INFO - 2021-09-24 12:41:40 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:41:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:41:40 --> Controller Class Initialized
INFO - 2021-09-24 12:41:40 --> Model "DBModel" initialized
DEBUG - 2021-09-24 12:41:40 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 12:41:40 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:41:40 --> Database Driver Class Initialized
INFO - 2021-09-24 12:41:40 --> Helper loaded: string_helper
INFO - 2021-09-24 12:41:40 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 12:41:40 --> Model "BlogModel" initialized
INFO - 2021-09-24 12:41:40 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-24 12:41:40 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 12:41:40 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 12:41:40 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/blogs.php
INFO - 2021-09-24 12:41:40 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 12:41:40 --> Final output sent to browser
DEBUG - 2021-09-24 12:41:40 --> Total execution time: 0.0742
INFO - 2021-09-24 12:41:44 --> Config Class Initialized
INFO - 2021-09-24 12:41:44 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:41:44 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:41:44 --> Utf8 Class Initialized
INFO - 2021-09-24 12:41:44 --> URI Class Initialized
INFO - 2021-09-24 12:41:44 --> Router Class Initialized
INFO - 2021-09-24 12:41:44 --> Output Class Initialized
INFO - 2021-09-24 12:41:44 --> Security Class Initialized
DEBUG - 2021-09-24 12:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:41:44 --> Input Class Initialized
INFO - 2021-09-24 12:41:44 --> Language Class Initialized
INFO - 2021-09-24 12:41:44 --> Loader Class Initialized
INFO - 2021-09-24 12:41:44 --> Helper loaded: url_helper
INFO - 2021-09-24 12:41:44 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:41:44 --> Controller Class Initialized
INFO - 2021-09-24 12:41:44 --> Model "DBModel" initialized
DEBUG - 2021-09-24 12:41:44 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 12:41:44 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:41:44 --> Database Driver Class Initialized
INFO - 2021-09-24 12:41:44 --> Helper loaded: string_helper
INFO - 2021-09-24 12:41:44 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 12:41:44 --> Model "BlogModel" initialized
INFO - 2021-09-24 12:41:44 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-24 12:41:44 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 12:41:44 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 12:41:44 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/blog.php
INFO - 2021-09-24 12:41:44 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 12:41:44 --> Final output sent to browser
DEBUG - 2021-09-24 12:41:44 --> Total execution time: 0.0799
INFO - 2021-09-24 12:42:30 --> Config Class Initialized
INFO - 2021-09-24 12:42:30 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:42:30 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:42:30 --> Utf8 Class Initialized
INFO - 2021-09-24 12:42:30 --> URI Class Initialized
INFO - 2021-09-24 12:42:30 --> Router Class Initialized
INFO - 2021-09-24 12:42:30 --> Output Class Initialized
INFO - 2021-09-24 12:42:30 --> Security Class Initialized
DEBUG - 2021-09-24 12:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:42:30 --> Input Class Initialized
INFO - 2021-09-24 12:42:30 --> Language Class Initialized
INFO - 2021-09-24 12:42:30 --> Loader Class Initialized
INFO - 2021-09-24 12:42:30 --> Helper loaded: url_helper
INFO - 2021-09-24 12:42:30 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:42:30 --> Controller Class Initialized
INFO - 2021-09-24 12:42:30 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:42:30 --> Model "CookieModel" initialized
INFO - 2021-09-24 12:42:30 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 12:42:31 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/services.php
INFO - 2021-09-24 12:42:31 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 12:42:31 --> Final output sent to browser
DEBUG - 2021-09-24 12:42:31 --> Total execution time: 0.2308
INFO - 2021-09-24 12:42:42 --> Config Class Initialized
INFO - 2021-09-24 12:42:42 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:42:42 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:42:42 --> Utf8 Class Initialized
INFO - 2021-09-24 12:42:42 --> URI Class Initialized
INFO - 2021-09-24 12:42:42 --> Router Class Initialized
INFO - 2021-09-24 12:42:42 --> Output Class Initialized
INFO - 2021-09-24 12:42:42 --> Security Class Initialized
DEBUG - 2021-09-24 12:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:42:42 --> Input Class Initialized
INFO - 2021-09-24 12:42:42 --> Language Class Initialized
INFO - 2021-09-24 12:42:42 --> Loader Class Initialized
INFO - 2021-09-24 12:42:42 --> Helper loaded: url_helper
INFO - 2021-09-24 12:42:42 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:42:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:42:42 --> Controller Class Initialized
INFO - 2021-09-24 12:42:42 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:42:42 --> Model "CookieModel" initialized
INFO - 2021-09-24 12:42:42 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 12:42:42 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/pilates.php
INFO - 2021-09-24 12:42:42 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 12:42:42 --> Final output sent to browser
DEBUG - 2021-09-24 12:42:42 --> Total execution time: 0.2599
INFO - 2021-09-24 12:42:48 --> Config Class Initialized
INFO - 2021-09-24 12:42:48 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:42:48 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:42:48 --> Utf8 Class Initialized
INFO - 2021-09-24 12:42:48 --> URI Class Initialized
INFO - 2021-09-24 12:42:48 --> Router Class Initialized
INFO - 2021-09-24 12:42:48 --> Output Class Initialized
INFO - 2021-09-24 12:42:48 --> Security Class Initialized
DEBUG - 2021-09-24 12:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:42:48 --> Input Class Initialized
INFO - 2021-09-24 12:42:48 --> Language Class Initialized
INFO - 2021-09-24 12:42:48 --> Loader Class Initialized
INFO - 2021-09-24 12:42:48 --> Helper loaded: url_helper
INFO - 2021-09-24 12:42:48 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:42:48 --> Controller Class Initialized
INFO - 2021-09-24 12:42:48 --> Model "DBModel" initialized
DEBUG - 2021-09-24 12:42:48 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 12:42:48 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:42:48 --> Database Driver Class Initialized
INFO - 2021-09-24 12:42:48 --> Helper loaded: string_helper
INFO - 2021-09-24 12:42:48 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 12:42:48 --> Model "BlogModel" initialized
INFO - 2021-09-24 12:42:48 --> Config Class Initialized
INFO - 2021-09-24 12:42:48 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:42:48 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:42:48 --> Utf8 Class Initialized
INFO - 2021-09-24 12:42:48 --> URI Class Initialized
INFO - 2021-09-24 12:42:48 --> Router Class Initialized
INFO - 2021-09-24 12:42:48 --> Output Class Initialized
INFO - 2021-09-24 12:42:48 --> Security Class Initialized
DEBUG - 2021-09-24 12:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:42:48 --> Input Class Initialized
INFO - 2021-09-24 12:42:48 --> Language Class Initialized
INFO - 2021-09-24 12:42:48 --> Loader Class Initialized
INFO - 2021-09-24 12:42:48 --> Helper loaded: url_helper
INFO - 2021-09-24 12:42:48 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:42:48 --> Controller Class Initialized
INFO - 2021-09-24 12:42:48 --> Model "DBModel" initialized
DEBUG - 2021-09-24 12:42:48 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 12:42:48 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:42:48 --> Database Driver Class Initialized
INFO - 2021-09-24 12:42:48 --> Helper loaded: string_helper
INFO - 2021-09-24 12:42:48 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 12:42:48 --> Model "BlogModel" initialized
INFO - 2021-09-24 12:42:48 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-24 12:42:48 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 12:42:48 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 12:42:48 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/blogs.php
INFO - 2021-09-24 12:42:48 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 12:42:48 --> Final output sent to browser
DEBUG - 2021-09-24 12:42:48 --> Total execution time: 0.0823
INFO - 2021-09-24 12:42:59 --> Config Class Initialized
INFO - 2021-09-24 12:42:59 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:42:59 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:42:59 --> Utf8 Class Initialized
INFO - 2021-09-24 12:42:59 --> URI Class Initialized
INFO - 2021-09-24 12:42:59 --> Router Class Initialized
INFO - 2021-09-24 12:42:59 --> Output Class Initialized
INFO - 2021-09-24 12:42:59 --> Security Class Initialized
DEBUG - 2021-09-24 12:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:42:59 --> Input Class Initialized
INFO - 2021-09-24 12:42:59 --> Language Class Initialized
INFO - 2021-09-24 12:42:59 --> Loader Class Initialized
INFO - 2021-09-24 12:42:59 --> Helper loaded: url_helper
INFO - 2021-09-24 12:42:59 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:42:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:42:59 --> Controller Class Initialized
INFO - 2021-09-24 12:42:59 --> Model "DBModel" initialized
DEBUG - 2021-09-24 12:42:59 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 12:42:59 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:42:59 --> Database Driver Class Initialized
INFO - 2021-09-24 12:42:59 --> Helper loaded: string_helper
INFO - 2021-09-24 12:42:59 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 12:42:59 --> Model "BlogModel" initialized
INFO - 2021-09-24 12:42:59 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-24 12:42:59 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 12:42:59 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 12:42:59 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/blog.php
INFO - 2021-09-24 12:42:59 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 12:42:59 --> Final output sent to browser
DEBUG - 2021-09-24 12:42:59 --> Total execution time: 0.0703
INFO - 2021-09-24 12:43:16 --> Config Class Initialized
INFO - 2021-09-24 12:43:16 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:43:16 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:43:16 --> Utf8 Class Initialized
INFO - 2021-09-24 12:43:16 --> URI Class Initialized
INFO - 2021-09-24 12:43:16 --> Router Class Initialized
INFO - 2021-09-24 12:43:16 --> Output Class Initialized
INFO - 2021-09-24 12:43:16 --> Security Class Initialized
DEBUG - 2021-09-24 12:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:43:16 --> Input Class Initialized
INFO - 2021-09-24 12:43:16 --> Language Class Initialized
INFO - 2021-09-24 12:43:16 --> Loader Class Initialized
INFO - 2021-09-24 12:43:16 --> Helper loaded: url_helper
INFO - 2021-09-24 12:43:16 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:43:16 --> Controller Class Initialized
INFO - 2021-09-24 12:43:16 --> Model "DBModel" initialized
DEBUG - 2021-09-24 12:43:16 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 12:43:16 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:43:16 --> Database Driver Class Initialized
INFO - 2021-09-24 12:43:16 --> Helper loaded: string_helper
INFO - 2021-09-24 12:43:16 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 12:43:16 --> Model "BlogModel" initialized
INFO - 2021-09-24 12:43:16 --> Config Class Initialized
INFO - 2021-09-24 12:43:16 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:43:16 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:43:16 --> Utf8 Class Initialized
INFO - 2021-09-24 12:43:16 --> URI Class Initialized
INFO - 2021-09-24 12:43:16 --> Router Class Initialized
INFO - 2021-09-24 12:43:16 --> Output Class Initialized
INFO - 2021-09-24 12:43:16 --> Security Class Initialized
DEBUG - 2021-09-24 12:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:43:16 --> Input Class Initialized
INFO - 2021-09-24 12:43:16 --> Language Class Initialized
INFO - 2021-09-24 12:43:16 --> Loader Class Initialized
INFO - 2021-09-24 12:43:16 --> Helper loaded: url_helper
INFO - 2021-09-24 12:43:16 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:43:16 --> Controller Class Initialized
INFO - 2021-09-24 12:43:16 --> Model "DBModel" initialized
DEBUG - 2021-09-24 12:43:16 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 12:43:16 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:43:16 --> Database Driver Class Initialized
INFO - 2021-09-24 12:43:16 --> Helper loaded: string_helper
INFO - 2021-09-24 12:43:16 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 12:43:16 --> Model "BlogModel" initialized
INFO - 2021-09-24 12:43:16 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-24 12:43:16 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 12:43:16 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 12:43:16 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/blogs.php
INFO - 2021-09-24 12:43:16 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 12:43:16 --> Final output sent to browser
DEBUG - 2021-09-24 12:43:16 --> Total execution time: 0.0702
INFO - 2021-09-24 12:43:28 --> Config Class Initialized
INFO - 2021-09-24 12:43:28 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:43:28 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:43:28 --> Utf8 Class Initialized
INFO - 2021-09-24 12:43:28 --> URI Class Initialized
INFO - 2021-09-24 12:43:28 --> Router Class Initialized
INFO - 2021-09-24 12:43:28 --> Output Class Initialized
INFO - 2021-09-24 12:43:28 --> Security Class Initialized
DEBUG - 2021-09-24 12:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:43:28 --> Input Class Initialized
INFO - 2021-09-24 12:43:28 --> Language Class Initialized
INFO - 2021-09-24 12:43:28 --> Loader Class Initialized
INFO - 2021-09-24 12:43:28 --> Helper loaded: url_helper
INFO - 2021-09-24 12:43:28 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:43:28 --> Controller Class Initialized
INFO - 2021-09-24 12:43:28 --> Model "DBModel" initialized
DEBUG - 2021-09-24 12:43:28 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 12:43:28 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:43:28 --> Database Driver Class Initialized
INFO - 2021-09-24 12:43:28 --> Helper loaded: string_helper
INFO - 2021-09-24 12:43:28 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 12:43:28 --> Model "BlogModel" initialized
INFO - 2021-09-24 12:43:28 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-24 12:43:28 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 12:43:28 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 12:43:28 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/blog.php
INFO - 2021-09-24 12:43:28 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 12:43:28 --> Final output sent to browser
DEBUG - 2021-09-24 12:43:28 --> Total execution time: 0.0639
INFO - 2021-09-24 12:43:57 --> Config Class Initialized
INFO - 2021-09-24 12:43:57 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:43:57 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:43:57 --> Utf8 Class Initialized
INFO - 2021-09-24 12:43:57 --> URI Class Initialized
INFO - 2021-09-24 12:43:57 --> Router Class Initialized
INFO - 2021-09-24 12:43:57 --> Output Class Initialized
INFO - 2021-09-24 12:43:57 --> Security Class Initialized
DEBUG - 2021-09-24 12:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:43:57 --> Input Class Initialized
INFO - 2021-09-24 12:43:57 --> Language Class Initialized
INFO - 2021-09-24 12:43:57 --> Loader Class Initialized
INFO - 2021-09-24 12:43:57 --> Helper loaded: url_helper
INFO - 2021-09-24 12:43:57 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:43:57 --> Controller Class Initialized
INFO - 2021-09-24 12:43:57 --> Model "DBModel" initialized
DEBUG - 2021-09-24 12:43:57 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 12:43:57 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:43:57 --> Database Driver Class Initialized
INFO - 2021-09-24 12:43:57 --> Helper loaded: string_helper
INFO - 2021-09-24 12:43:57 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 12:43:57 --> Model "BlogModel" initialized
INFO - 2021-09-24 12:43:58 --> Config Class Initialized
INFO - 2021-09-24 12:43:58 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:43:58 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:43:58 --> Utf8 Class Initialized
INFO - 2021-09-24 12:43:58 --> URI Class Initialized
INFO - 2021-09-24 12:43:58 --> Router Class Initialized
INFO - 2021-09-24 12:43:58 --> Output Class Initialized
INFO - 2021-09-24 12:43:58 --> Security Class Initialized
DEBUG - 2021-09-24 12:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:43:58 --> Input Class Initialized
INFO - 2021-09-24 12:43:58 --> Language Class Initialized
INFO - 2021-09-24 12:43:58 --> Loader Class Initialized
INFO - 2021-09-24 12:43:58 --> Helper loaded: url_helper
INFO - 2021-09-24 12:43:58 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:43:58 --> Controller Class Initialized
INFO - 2021-09-24 12:43:58 --> Model "DBModel" initialized
DEBUG - 2021-09-24 12:43:58 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 12:43:58 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:43:58 --> Database Driver Class Initialized
INFO - 2021-09-24 12:43:58 --> Helper loaded: string_helper
INFO - 2021-09-24 12:43:58 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 12:43:58 --> Model "BlogModel" initialized
INFO - 2021-09-24 12:43:58 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-24 12:43:58 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 12:43:58 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 12:43:58 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/blogs.php
INFO - 2021-09-24 12:43:58 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 12:43:58 --> Final output sent to browser
DEBUG - 2021-09-24 12:43:58 --> Total execution time: 0.0729
INFO - 2021-09-24 12:44:00 --> Config Class Initialized
INFO - 2021-09-24 12:44:00 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:44:00 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:44:00 --> Utf8 Class Initialized
INFO - 2021-09-24 12:44:00 --> URI Class Initialized
INFO - 2021-09-24 12:44:00 --> Router Class Initialized
INFO - 2021-09-24 12:44:00 --> Output Class Initialized
INFO - 2021-09-24 12:44:00 --> Security Class Initialized
DEBUG - 2021-09-24 12:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:44:00 --> Input Class Initialized
INFO - 2021-09-24 12:44:00 --> Language Class Initialized
INFO - 2021-09-24 12:44:00 --> Loader Class Initialized
INFO - 2021-09-24 12:44:00 --> Helper loaded: url_helper
INFO - 2021-09-24 12:44:00 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:44:00 --> Controller Class Initialized
INFO - 2021-09-24 12:44:00 --> Model "DBModel" initialized
DEBUG - 2021-09-24 12:44:00 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 12:44:00 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:44:00 --> Database Driver Class Initialized
INFO - 2021-09-24 12:44:00 --> Helper loaded: string_helper
INFO - 2021-09-24 12:44:00 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 12:44:00 --> Model "BlogModel" initialized
INFO - 2021-09-24 12:44:00 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-24 12:44:00 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 12:44:00 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 12:44:00 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/blog.php
INFO - 2021-09-24 12:44:00 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 12:44:00 --> Final output sent to browser
DEBUG - 2021-09-24 12:44:00 --> Total execution time: 0.0700
INFO - 2021-09-24 12:44:03 --> Config Class Initialized
INFO - 2021-09-24 12:44:03 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:44:03 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:44:03 --> Utf8 Class Initialized
INFO - 2021-09-24 12:44:03 --> URI Class Initialized
INFO - 2021-09-24 12:44:03 --> Router Class Initialized
INFO - 2021-09-24 12:44:03 --> Output Class Initialized
INFO - 2021-09-24 12:44:03 --> Security Class Initialized
DEBUG - 2021-09-24 12:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:44:03 --> Input Class Initialized
INFO - 2021-09-24 12:44:03 --> Language Class Initialized
INFO - 2021-09-24 12:44:03 --> Loader Class Initialized
INFO - 2021-09-24 12:44:03 --> Helper loaded: url_helper
INFO - 2021-09-24 12:44:03 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:44:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:44:03 --> Controller Class Initialized
INFO - 2021-09-24 12:44:03 --> Model "DBModel" initialized
DEBUG - 2021-09-24 12:44:03 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 12:44:03 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:44:03 --> Database Driver Class Initialized
INFO - 2021-09-24 12:44:03 --> Helper loaded: string_helper
INFO - 2021-09-24 12:44:03 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 12:44:03 --> Model "BlogModel" initialized
INFO - 2021-09-24 12:44:03 --> Config Class Initialized
INFO - 2021-09-24 12:44:03 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:44:03 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:44:03 --> Utf8 Class Initialized
INFO - 2021-09-24 12:44:03 --> URI Class Initialized
INFO - 2021-09-24 12:44:03 --> Router Class Initialized
INFO - 2021-09-24 12:44:03 --> Output Class Initialized
INFO - 2021-09-24 12:44:03 --> Security Class Initialized
DEBUG - 2021-09-24 12:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:44:03 --> Input Class Initialized
INFO - 2021-09-24 12:44:03 --> Language Class Initialized
INFO - 2021-09-24 12:44:03 --> Loader Class Initialized
INFO - 2021-09-24 12:44:03 --> Helper loaded: url_helper
INFO - 2021-09-24 12:44:03 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:44:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:44:03 --> Controller Class Initialized
INFO - 2021-09-24 12:44:03 --> Model "DBModel" initialized
DEBUG - 2021-09-24 12:44:03 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 12:44:03 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:44:03 --> Database Driver Class Initialized
INFO - 2021-09-24 12:44:03 --> Helper loaded: string_helper
INFO - 2021-09-24 12:44:03 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 12:44:03 --> Model "BlogModel" initialized
INFO - 2021-09-24 12:44:03 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-24 12:44:03 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 12:44:03 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 12:44:03 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/blogs.php
INFO - 2021-09-24 12:44:03 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 12:44:03 --> Final output sent to browser
DEBUG - 2021-09-24 12:44:03 --> Total execution time: 0.0912
INFO - 2021-09-24 12:44:54 --> Config Class Initialized
INFO - 2021-09-24 12:44:54 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:44:54 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:44:54 --> Utf8 Class Initialized
INFO - 2021-09-24 12:44:54 --> URI Class Initialized
INFO - 2021-09-24 12:44:54 --> Router Class Initialized
INFO - 2021-09-24 12:44:54 --> Output Class Initialized
INFO - 2021-09-24 12:44:54 --> Security Class Initialized
DEBUG - 2021-09-24 12:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:44:54 --> Input Class Initialized
INFO - 2021-09-24 12:44:54 --> Language Class Initialized
INFO - 2021-09-24 12:44:54 --> Loader Class Initialized
INFO - 2021-09-24 12:44:54 --> Helper loaded: url_helper
INFO - 2021-09-24 12:44:54 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:44:54 --> Controller Class Initialized
INFO - 2021-09-24 12:44:54 --> Model "DBModel" initialized
DEBUG - 2021-09-24 12:44:54 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 12:44:54 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:44:54 --> Database Driver Class Initialized
INFO - 2021-09-24 12:44:54 --> Helper loaded: string_helper
INFO - 2021-09-24 12:44:54 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 12:44:54 --> Model "BlogModel" initialized
INFO - 2021-09-24 12:44:54 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-24 12:44:54 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 12:44:54 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 12:44:54 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/testimonials.php
INFO - 2021-09-24 12:44:54 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 12:44:54 --> Final output sent to browser
DEBUG - 2021-09-24 12:44:54 --> Total execution time: 0.0911
INFO - 2021-09-24 12:44:54 --> Config Class Initialized
INFO - 2021-09-24 12:44:54 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:44:54 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:44:54 --> Utf8 Class Initialized
INFO - 2021-09-24 12:44:54 --> URI Class Initialized
INFO - 2021-09-24 12:44:54 --> Router Class Initialized
INFO - 2021-09-24 12:44:54 --> Output Class Initialized
INFO - 2021-09-24 12:44:54 --> Security Class Initialized
DEBUG - 2021-09-24 12:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:44:54 --> Input Class Initialized
INFO - 2021-09-24 12:44:54 --> Language Class Initialized
ERROR - 2021-09-24 12:44:54 --> 404 Page Not Found: Testimonialpics/.png
INFO - 2021-09-24 12:44:59 --> Config Class Initialized
INFO - 2021-09-24 12:44:59 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:44:59 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:44:59 --> Utf8 Class Initialized
INFO - 2021-09-24 12:44:59 --> URI Class Initialized
INFO - 2021-09-24 12:44:59 --> Router Class Initialized
INFO - 2021-09-24 12:44:59 --> Output Class Initialized
INFO - 2021-09-24 12:44:59 --> Security Class Initialized
DEBUG - 2021-09-24 12:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:44:59 --> Input Class Initialized
INFO - 2021-09-24 12:44:59 --> Language Class Initialized
INFO - 2021-09-24 12:44:59 --> Loader Class Initialized
INFO - 2021-09-24 12:44:59 --> Helper loaded: url_helper
INFO - 2021-09-24 12:44:59 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:44:59 --> Controller Class Initialized
INFO - 2021-09-24 12:44:59 --> Model "DBModel" initialized
DEBUG - 2021-09-24 12:44:59 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 12:44:59 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:44:59 --> Database Driver Class Initialized
INFO - 2021-09-24 12:44:59 --> Helper loaded: string_helper
INFO - 2021-09-24 12:44:59 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 12:44:59 --> Model "BlogModel" initialized
INFO - 2021-09-24 12:44:59 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-24 12:44:59 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 12:44:59 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 12:44:59 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/testimonials.php
INFO - 2021-09-24 12:44:59 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 12:44:59 --> Final output sent to browser
DEBUG - 2021-09-24 12:44:59 --> Total execution time: 0.0841
INFO - 2021-09-24 12:44:59 --> Config Class Initialized
INFO - 2021-09-24 12:44:59 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:44:59 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:44:59 --> Utf8 Class Initialized
INFO - 2021-09-24 12:44:59 --> URI Class Initialized
INFO - 2021-09-24 12:44:59 --> Router Class Initialized
INFO - 2021-09-24 12:44:59 --> Output Class Initialized
INFO - 2021-09-24 12:44:59 --> Security Class Initialized
DEBUG - 2021-09-24 12:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:44:59 --> Input Class Initialized
INFO - 2021-09-24 12:44:59 --> Language Class Initialized
ERROR - 2021-09-24 12:44:59 --> 404 Page Not Found: Testimonialpics/.png
INFO - 2021-09-24 12:45:02 --> Config Class Initialized
INFO - 2021-09-24 12:45:02 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:45:02 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:45:02 --> Utf8 Class Initialized
INFO - 2021-09-24 12:45:02 --> URI Class Initialized
INFO - 2021-09-24 12:45:02 --> Router Class Initialized
INFO - 2021-09-24 12:45:02 --> Output Class Initialized
INFO - 2021-09-24 12:45:02 --> Security Class Initialized
DEBUG - 2021-09-24 12:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:45:02 --> Input Class Initialized
INFO - 2021-09-24 12:45:02 --> Language Class Initialized
INFO - 2021-09-24 12:45:02 --> Loader Class Initialized
INFO - 2021-09-24 12:45:02 --> Helper loaded: url_helper
INFO - 2021-09-24 12:45:02 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:45:02 --> Controller Class Initialized
INFO - 2021-09-24 12:45:02 --> Model "DBModel" initialized
DEBUG - 2021-09-24 12:45:02 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 12:45:02 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:45:02 --> Database Driver Class Initialized
INFO - 2021-09-24 12:45:02 --> Helper loaded: string_helper
INFO - 2021-09-24 12:45:02 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 12:45:02 --> Model "BlogModel" initialized
INFO - 2021-09-24 12:45:02 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-24 12:45:02 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 12:45:02 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 12:45:02 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/testimonials.php
INFO - 2021-09-24 12:45:02 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 12:45:02 --> Final output sent to browser
DEBUG - 2021-09-24 12:45:02 --> Total execution time: 0.0839
INFO - 2021-09-24 12:45:02 --> Config Class Initialized
INFO - 2021-09-24 12:45:02 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:45:02 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:45:02 --> Utf8 Class Initialized
INFO - 2021-09-24 12:45:02 --> URI Class Initialized
INFO - 2021-09-24 12:45:02 --> Router Class Initialized
INFO - 2021-09-24 12:45:02 --> Output Class Initialized
INFO - 2021-09-24 12:45:02 --> Security Class Initialized
DEBUG - 2021-09-24 12:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:45:02 --> Input Class Initialized
INFO - 2021-09-24 12:45:02 --> Language Class Initialized
ERROR - 2021-09-24 12:45:02 --> 404 Page Not Found: Testimonialpics/.png
INFO - 2021-09-24 12:45:29 --> Config Class Initialized
INFO - 2021-09-24 12:45:29 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:45:29 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:45:29 --> Utf8 Class Initialized
INFO - 2021-09-24 12:45:29 --> URI Class Initialized
INFO - 2021-09-24 12:45:29 --> Router Class Initialized
INFO - 2021-09-24 12:45:29 --> Output Class Initialized
INFO - 2021-09-24 12:45:29 --> Security Class Initialized
DEBUG - 2021-09-24 12:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:45:29 --> Input Class Initialized
INFO - 2021-09-24 12:45:29 --> Language Class Initialized
ERROR - 2021-09-24 12:45:29 --> 404 Page Not Found: Igapprojects/changeme
INFO - 2021-09-24 12:45:35 --> Config Class Initialized
INFO - 2021-09-24 12:45:35 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:45:35 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:45:35 --> Utf8 Class Initialized
INFO - 2021-09-24 12:45:35 --> URI Class Initialized
INFO - 2021-09-24 12:45:35 --> Router Class Initialized
INFO - 2021-09-24 12:45:35 --> Output Class Initialized
INFO - 2021-09-24 12:45:35 --> Security Class Initialized
DEBUG - 2021-09-24 12:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:45:35 --> Input Class Initialized
INFO - 2021-09-24 12:45:35 --> Language Class Initialized
INFO - 2021-09-24 12:45:35 --> Loader Class Initialized
INFO - 2021-09-24 12:45:35 --> Helper loaded: url_helper
INFO - 2021-09-24 12:45:35 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:45:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:45:35 --> Controller Class Initialized
INFO - 2021-09-24 12:45:35 --> Model "DBModel" initialized
DEBUG - 2021-09-24 12:45:35 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 12:45:35 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:45:35 --> Database Driver Class Initialized
INFO - 2021-09-24 12:45:35 --> Helper loaded: string_helper
INFO - 2021-09-24 12:45:35 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 12:45:35 --> Model "BlogModel" initialized
INFO - 2021-09-24 12:45:35 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\snackbar.php
INFO - 2021-09-24 12:45:35 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 12:45:35 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 12:45:35 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/testimonials.php
INFO - 2021-09-24 12:45:35 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 12:45:35 --> Final output sent to browser
DEBUG - 2021-09-24 12:45:35 --> Total execution time: 0.0820
INFO - 2021-09-24 12:45:36 --> Config Class Initialized
INFO - 2021-09-24 12:45:36 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:45:36 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:45:36 --> Utf8 Class Initialized
INFO - 2021-09-24 12:45:36 --> URI Class Initialized
INFO - 2021-09-24 12:45:36 --> Router Class Initialized
INFO - 2021-09-24 12:45:36 --> Output Class Initialized
INFO - 2021-09-24 12:45:36 --> Security Class Initialized
DEBUG - 2021-09-24 12:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:45:36 --> Input Class Initialized
INFO - 2021-09-24 12:45:36 --> Language Class Initialized
ERROR - 2021-09-24 12:45:36 --> 404 Page Not Found: Testimonialpics/.png
INFO - 2021-09-24 12:47:44 --> Config Class Initialized
INFO - 2021-09-24 12:47:44 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:47:44 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:47:44 --> Utf8 Class Initialized
INFO - 2021-09-24 12:47:44 --> URI Class Initialized
INFO - 2021-09-24 12:47:44 --> Router Class Initialized
INFO - 2021-09-24 12:47:44 --> Output Class Initialized
INFO - 2021-09-24 12:47:44 --> Security Class Initialized
DEBUG - 2021-09-24 12:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:47:44 --> Input Class Initialized
INFO - 2021-09-24 12:47:44 --> Language Class Initialized
INFO - 2021-09-24 12:47:44 --> Loader Class Initialized
INFO - 2021-09-24 12:47:44 --> Helper loaded: url_helper
INFO - 2021-09-24 12:47:44 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:47:44 --> Controller Class Initialized
INFO - 2021-09-24 12:47:44 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:47:44 --> Model "CookieModel" initialized
INFO - 2021-09-24 12:47:44 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 12:47:44 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/pilates.php
INFO - 2021-09-24 12:47:44 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 12:47:44 --> Final output sent to browser
DEBUG - 2021-09-24 12:47:44 --> Total execution time: 0.0532
INFO - 2021-09-24 12:58:08 --> Config Class Initialized
INFO - 2021-09-24 12:58:08 --> Hooks Class Initialized
DEBUG - 2021-09-24 12:58:08 --> UTF-8 Support Enabled
INFO - 2021-09-24 12:58:08 --> Utf8 Class Initialized
INFO - 2021-09-24 12:58:08 --> URI Class Initialized
INFO - 2021-09-24 12:58:08 --> Router Class Initialized
INFO - 2021-09-24 12:58:08 --> Output Class Initialized
INFO - 2021-09-24 12:58:08 --> Security Class Initialized
DEBUG - 2021-09-24 12:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 12:58:08 --> Input Class Initialized
INFO - 2021-09-24 12:58:08 --> Language Class Initialized
INFO - 2021-09-24 12:58:08 --> Loader Class Initialized
INFO - 2021-09-24 12:58:08 --> Helper loaded: url_helper
INFO - 2021-09-24 12:58:08 --> Helper loaded: file_helper
DEBUG - 2021-09-24 12:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 12:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 12:58:08 --> Controller Class Initialized
INFO - 2021-09-24 12:58:08 --> Database Driver Class Initialized
INFO - 2021-09-24 12:58:08 --> Helper loaded: string_helper
INFO - 2021-09-24 12:58:08 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 12:58:08 --> Helper loaded: cookie_helper
INFO - 2021-09-24 12:58:08 --> Model "CookieModel" initialized
INFO - 2021-09-24 12:58:08 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 12:58:08 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/testimonials.php
INFO - 2021-09-24 12:58:08 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 12:58:08 --> Final output sent to browser
DEBUG - 2021-09-24 12:58:08 --> Total execution time: 0.0833
INFO - 2021-09-24 13:01:05 --> Config Class Initialized
INFO - 2021-09-24 13:01:05 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:01:05 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:01:05 --> Utf8 Class Initialized
INFO - 2021-09-24 13:01:05 --> URI Class Initialized
INFO - 2021-09-24 13:01:05 --> Router Class Initialized
INFO - 2021-09-24 13:01:05 --> Output Class Initialized
INFO - 2021-09-24 13:01:05 --> Security Class Initialized
DEBUG - 2021-09-24 13:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:01:05 --> Input Class Initialized
INFO - 2021-09-24 13:01:05 --> Language Class Initialized
INFO - 2021-09-24 13:01:05 --> Loader Class Initialized
INFO - 2021-09-24 13:01:05 --> Helper loaded: url_helper
INFO - 2021-09-24 13:01:05 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:01:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:01:05 --> Controller Class Initialized
INFO - 2021-09-24 13:01:05 --> Database Driver Class Initialized
INFO - 2021-09-24 13:01:05 --> Helper loaded: string_helper
INFO - 2021-09-24 13:01:05 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 13:01:05 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:01:05 --> Model "CookieModel" initialized
INFO - 2021-09-24 13:01:05 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 13:01:05 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/testimonials.php
INFO - 2021-09-24 13:01:05 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 13:01:05 --> Final output sent to browser
DEBUG - 2021-09-24 13:01:05 --> Total execution time: 0.0844
INFO - 2021-09-24 13:01:08 --> Config Class Initialized
INFO - 2021-09-24 13:01:08 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:01:08 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:01:08 --> Utf8 Class Initialized
INFO - 2021-09-24 13:01:08 --> URI Class Initialized
INFO - 2021-09-24 13:01:08 --> Router Class Initialized
INFO - 2021-09-24 13:01:08 --> Output Class Initialized
INFO - 2021-09-24 13:01:08 --> Security Class Initialized
DEBUG - 2021-09-24 13:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:01:08 --> Input Class Initialized
INFO - 2021-09-24 13:01:08 --> Language Class Initialized
INFO - 2021-09-24 13:01:08 --> Loader Class Initialized
INFO - 2021-09-24 13:01:08 --> Helper loaded: url_helper
INFO - 2021-09-24 13:01:08 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:01:08 --> Controller Class Initialized
INFO - 2021-09-24 13:01:08 --> Database Driver Class Initialized
INFO - 2021-09-24 13:01:08 --> Model "BlogModel" initialized
INFO - 2021-09-24 13:01:08 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:01:08 --> Model "CookieModel" initialized
INFO - 2021-09-24 13:01:08 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 13:01:08 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/blogs.php
INFO - 2021-09-24 13:01:08 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 13:01:08 --> Final output sent to browser
DEBUG - 2021-09-24 13:01:08 --> Total execution time: 0.0651
INFO - 2021-09-24 13:03:13 --> Config Class Initialized
INFO - 2021-09-24 13:03:13 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:03:13 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:03:13 --> Utf8 Class Initialized
INFO - 2021-09-24 13:03:13 --> URI Class Initialized
INFO - 2021-09-24 13:03:13 --> Router Class Initialized
INFO - 2021-09-24 13:03:13 --> Output Class Initialized
INFO - 2021-09-24 13:03:13 --> Security Class Initialized
DEBUG - 2021-09-24 13:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:03:13 --> Input Class Initialized
INFO - 2021-09-24 13:03:13 --> Language Class Initialized
INFO - 2021-09-24 13:03:13 --> Loader Class Initialized
INFO - 2021-09-24 13:03:13 --> Helper loaded: url_helper
INFO - 2021-09-24 13:03:13 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:03:13 --> Controller Class Initialized
INFO - 2021-09-24 13:03:13 --> Database Driver Class Initialized
INFO - 2021-09-24 13:03:13 --> Model "BlogModel" initialized
INFO - 2021-09-24 13:03:13 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:03:13 --> Model "CookieModel" initialized
INFO - 2021-09-24 13:03:13 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 13:03:13 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/blogs.php
INFO - 2021-09-24 13:03:13 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 13:03:13 --> Final output sent to browser
DEBUG - 2021-09-24 13:03:13 --> Total execution time: 0.0928
INFO - 2021-09-24 13:04:30 --> Config Class Initialized
INFO - 2021-09-24 13:04:30 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:04:30 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:04:30 --> Utf8 Class Initialized
INFO - 2021-09-24 13:04:30 --> URI Class Initialized
INFO - 2021-09-24 13:04:30 --> Router Class Initialized
INFO - 2021-09-24 13:04:30 --> Output Class Initialized
INFO - 2021-09-24 13:04:30 --> Security Class Initialized
DEBUG - 2021-09-24 13:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:04:30 --> Input Class Initialized
INFO - 2021-09-24 13:04:30 --> Language Class Initialized
INFO - 2021-09-24 13:04:30 --> Loader Class Initialized
INFO - 2021-09-24 13:04:30 --> Helper loaded: url_helper
INFO - 2021-09-24 13:04:30 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:04:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:04:30 --> Controller Class Initialized
INFO - 2021-09-24 13:04:30 --> Database Driver Class Initialized
INFO - 2021-09-24 13:04:30 --> Model "BlogModel" initialized
INFO - 2021-09-24 13:04:30 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:04:30 --> Model "CookieModel" initialized
INFO - 2021-09-24 13:04:30 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 13:04:30 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/blogs.php
INFO - 2021-09-24 13:04:30 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 13:04:30 --> Final output sent to browser
DEBUG - 2021-09-24 13:04:30 --> Total execution time: 0.0759
INFO - 2021-09-24 13:05:56 --> Config Class Initialized
INFO - 2021-09-24 13:05:56 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:05:56 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:05:56 --> Utf8 Class Initialized
INFO - 2021-09-24 13:05:56 --> URI Class Initialized
INFO - 2021-09-24 13:05:56 --> Router Class Initialized
INFO - 2021-09-24 13:05:56 --> Output Class Initialized
INFO - 2021-09-24 13:05:56 --> Security Class Initialized
DEBUG - 2021-09-24 13:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:05:56 --> Input Class Initialized
INFO - 2021-09-24 13:05:56 --> Language Class Initialized
INFO - 2021-09-24 13:05:56 --> Loader Class Initialized
INFO - 2021-09-24 13:05:56 --> Helper loaded: url_helper
INFO - 2021-09-24 13:05:56 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:05:56 --> Controller Class Initialized
INFO - 2021-09-24 13:05:56 --> Database Driver Class Initialized
INFO - 2021-09-24 13:05:56 --> Model "BlogModel" initialized
INFO - 2021-09-24 13:05:56 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:05:56 --> Model "CookieModel" initialized
INFO - 2021-09-24 13:05:56 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 13:05:56 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/blogs.php
INFO - 2021-09-24 13:05:56 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 13:05:56 --> Final output sent to browser
DEBUG - 2021-09-24 13:05:56 --> Total execution time: 0.0748
INFO - 2021-09-24 13:06:46 --> Config Class Initialized
INFO - 2021-09-24 13:06:46 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:06:46 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:06:46 --> Utf8 Class Initialized
INFO - 2021-09-24 13:06:46 --> URI Class Initialized
INFO - 2021-09-24 13:06:46 --> Router Class Initialized
INFO - 2021-09-24 13:06:46 --> Output Class Initialized
INFO - 2021-09-24 13:06:46 --> Security Class Initialized
DEBUG - 2021-09-24 13:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:06:46 --> Input Class Initialized
INFO - 2021-09-24 13:06:46 --> Language Class Initialized
INFO - 2021-09-24 13:06:47 --> Loader Class Initialized
INFO - 2021-09-24 13:06:47 --> Helper loaded: url_helper
INFO - 2021-09-24 13:06:47 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:06:47 --> Controller Class Initialized
INFO - 2021-09-24 13:06:47 --> Database Driver Class Initialized
INFO - 2021-09-24 13:06:47 --> Model "BlogModel" initialized
INFO - 2021-09-24 13:06:47 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:06:47 --> Model "CookieModel" initialized
INFO - 2021-09-24 13:06:47 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 13:06:47 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/blogs.php
INFO - 2021-09-24 13:06:47 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 13:06:47 --> Final output sent to browser
DEBUG - 2021-09-24 13:06:47 --> Total execution time: 0.0722
INFO - 2021-09-24 13:07:07 --> Config Class Initialized
INFO - 2021-09-24 13:07:07 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:07:07 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:07:07 --> Utf8 Class Initialized
INFO - 2021-09-24 13:07:07 --> URI Class Initialized
INFO - 2021-09-24 13:07:07 --> Router Class Initialized
INFO - 2021-09-24 13:07:07 --> Output Class Initialized
INFO - 2021-09-24 13:07:07 --> Security Class Initialized
DEBUG - 2021-09-24 13:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:07:07 --> Input Class Initialized
INFO - 2021-09-24 13:07:07 --> Language Class Initialized
INFO - 2021-09-24 13:07:07 --> Loader Class Initialized
INFO - 2021-09-24 13:07:07 --> Helper loaded: url_helper
INFO - 2021-09-24 13:07:07 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:07:07 --> Controller Class Initialized
INFO - 2021-09-24 13:07:07 --> Database Driver Class Initialized
INFO - 2021-09-24 13:07:07 --> Model "BlogModel" initialized
INFO - 2021-09-24 13:07:07 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:07:07 --> Model "CookieModel" initialized
INFO - 2021-09-24 13:07:07 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 13:07:07 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/blogs.php
INFO - 2021-09-24 13:07:07 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 13:07:07 --> Final output sent to browser
DEBUG - 2021-09-24 13:07:07 --> Total execution time: 0.0723
INFO - 2021-09-24 13:07:26 --> Config Class Initialized
INFO - 2021-09-24 13:07:26 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:07:26 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:07:26 --> Utf8 Class Initialized
INFO - 2021-09-24 13:07:26 --> URI Class Initialized
INFO - 2021-09-24 13:07:26 --> Router Class Initialized
INFO - 2021-09-24 13:07:26 --> Output Class Initialized
INFO - 2021-09-24 13:07:26 --> Security Class Initialized
DEBUG - 2021-09-24 13:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:07:26 --> Input Class Initialized
INFO - 2021-09-24 13:07:26 --> Language Class Initialized
INFO - 2021-09-24 13:07:26 --> Loader Class Initialized
INFO - 2021-09-24 13:07:26 --> Helper loaded: url_helper
INFO - 2021-09-24 13:07:26 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:07:26 --> Controller Class Initialized
INFO - 2021-09-24 13:07:26 --> Database Driver Class Initialized
INFO - 2021-09-24 13:07:26 --> Model "BlogModel" initialized
INFO - 2021-09-24 13:07:26 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:07:26 --> Model "CookieModel" initialized
INFO - 2021-09-24 13:07:26 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 13:07:26 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/blogs.php
INFO - 2021-09-24 13:07:26 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 13:07:26 --> Final output sent to browser
DEBUG - 2021-09-24 13:07:26 --> Total execution time: 0.0908
INFO - 2021-09-24 13:08:39 --> Config Class Initialized
INFO - 2021-09-24 13:08:39 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:08:39 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:08:39 --> Utf8 Class Initialized
INFO - 2021-09-24 13:08:39 --> URI Class Initialized
INFO - 2021-09-24 13:08:39 --> Router Class Initialized
INFO - 2021-09-24 13:08:39 --> Output Class Initialized
INFO - 2021-09-24 13:08:39 --> Security Class Initialized
DEBUG - 2021-09-24 13:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:08:39 --> Input Class Initialized
INFO - 2021-09-24 13:08:39 --> Language Class Initialized
INFO - 2021-09-24 13:08:39 --> Loader Class Initialized
INFO - 2021-09-24 13:08:39 --> Helper loaded: url_helper
INFO - 2021-09-24 13:08:39 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:08:39 --> Controller Class Initialized
INFO - 2021-09-24 13:08:40 --> Database Driver Class Initialized
INFO - 2021-09-24 13:08:40 --> Model "BlogModel" initialized
INFO - 2021-09-24 13:08:40 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:08:40 --> Model "CookieModel" initialized
INFO - 2021-09-24 13:08:40 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 13:08:40 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/blogs.php
INFO - 2021-09-24 13:08:40 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 13:08:40 --> Final output sent to browser
DEBUG - 2021-09-24 13:08:40 --> Total execution time: 0.0686
INFO - 2021-09-24 13:09:51 --> Config Class Initialized
INFO - 2021-09-24 13:09:51 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:09:51 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:09:51 --> Utf8 Class Initialized
INFO - 2021-09-24 13:09:51 --> URI Class Initialized
INFO - 2021-09-24 13:09:51 --> Router Class Initialized
INFO - 2021-09-24 13:09:51 --> Output Class Initialized
INFO - 2021-09-24 13:09:51 --> Security Class Initialized
DEBUG - 2021-09-24 13:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:09:51 --> Input Class Initialized
INFO - 2021-09-24 13:09:51 --> Language Class Initialized
INFO - 2021-09-24 13:09:51 --> Loader Class Initialized
INFO - 2021-09-24 13:09:51 --> Helper loaded: url_helper
INFO - 2021-09-24 13:09:51 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:09:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:09:51 --> Controller Class Initialized
INFO - 2021-09-24 13:09:51 --> Database Driver Class Initialized
INFO - 2021-09-24 13:09:51 --> Model "BlogModel" initialized
INFO - 2021-09-24 13:09:51 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:09:51 --> Model "CookieModel" initialized
INFO - 2021-09-24 13:09:51 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 13:09:51 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/blogs.php
INFO - 2021-09-24 13:09:51 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 13:09:51 --> Final output sent to browser
DEBUG - 2021-09-24 13:09:51 --> Total execution time: 0.0790
INFO - 2021-09-24 13:10:17 --> Config Class Initialized
INFO - 2021-09-24 13:10:17 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:10:17 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:10:17 --> Utf8 Class Initialized
INFO - 2021-09-24 13:10:17 --> URI Class Initialized
INFO - 2021-09-24 13:10:17 --> Router Class Initialized
INFO - 2021-09-24 13:10:17 --> Output Class Initialized
INFO - 2021-09-24 13:10:17 --> Security Class Initialized
DEBUG - 2021-09-24 13:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:10:17 --> Input Class Initialized
INFO - 2021-09-24 13:10:17 --> Language Class Initialized
INFO - 2021-09-24 13:10:17 --> Loader Class Initialized
INFO - 2021-09-24 13:10:17 --> Helper loaded: url_helper
INFO - 2021-09-24 13:10:17 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:10:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:10:17 --> Controller Class Initialized
INFO - 2021-09-24 13:10:17 --> Database Driver Class Initialized
INFO - 2021-09-24 13:10:17 --> Model "BlogModel" initialized
INFO - 2021-09-24 13:10:17 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:10:17 --> Model "CookieModel" initialized
INFO - 2021-09-24 13:10:17 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 13:10:17 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/blogs.php
INFO - 2021-09-24 13:10:17 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 13:10:17 --> Final output sent to browser
DEBUG - 2021-09-24 13:10:17 --> Total execution time: 0.0639
INFO - 2021-09-24 13:10:53 --> Config Class Initialized
INFO - 2021-09-24 13:10:53 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:10:53 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:10:53 --> Utf8 Class Initialized
INFO - 2021-09-24 13:10:53 --> URI Class Initialized
INFO - 2021-09-24 13:10:53 --> Router Class Initialized
INFO - 2021-09-24 13:10:53 --> Output Class Initialized
INFO - 2021-09-24 13:10:53 --> Security Class Initialized
DEBUG - 2021-09-24 13:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:10:53 --> Input Class Initialized
INFO - 2021-09-24 13:10:53 --> Language Class Initialized
INFO - 2021-09-24 13:10:53 --> Loader Class Initialized
INFO - 2021-09-24 13:10:53 --> Helper loaded: url_helper
INFO - 2021-09-24 13:10:53 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:10:53 --> Controller Class Initialized
INFO - 2021-09-24 13:10:53 --> Database Driver Class Initialized
INFO - 2021-09-24 13:10:53 --> Model "BlogModel" initialized
INFO - 2021-09-24 13:10:53 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:10:53 --> Model "CookieModel" initialized
INFO - 2021-09-24 13:10:53 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 13:10:53 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/blogs.php
INFO - 2021-09-24 13:10:53 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 13:10:53 --> Final output sent to browser
DEBUG - 2021-09-24 13:10:53 --> Total execution time: 0.0755
INFO - 2021-09-24 13:11:33 --> Config Class Initialized
INFO - 2021-09-24 13:11:33 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:11:33 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:11:33 --> Utf8 Class Initialized
INFO - 2021-09-24 13:11:33 --> URI Class Initialized
INFO - 2021-09-24 13:11:33 --> Router Class Initialized
INFO - 2021-09-24 13:11:33 --> Output Class Initialized
INFO - 2021-09-24 13:11:33 --> Security Class Initialized
DEBUG - 2021-09-24 13:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:11:33 --> Input Class Initialized
INFO - 2021-09-24 13:11:33 --> Language Class Initialized
INFO - 2021-09-24 13:11:33 --> Loader Class Initialized
INFO - 2021-09-24 13:11:33 --> Helper loaded: url_helper
INFO - 2021-09-24 13:11:33 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:11:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:11:33 --> Controller Class Initialized
INFO - 2021-09-24 13:11:33 --> Database Driver Class Initialized
INFO - 2021-09-24 13:11:33 --> Model "BlogModel" initialized
INFO - 2021-09-24 13:11:33 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:11:33 --> Model "CookieModel" initialized
INFO - 2021-09-24 13:11:33 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 13:11:33 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/blogs.php
INFO - 2021-09-24 13:11:33 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 13:11:33 --> Final output sent to browser
DEBUG - 2021-09-24 13:11:33 --> Total execution time: 0.0736
INFO - 2021-09-24 13:14:22 --> Config Class Initialized
INFO - 2021-09-24 13:14:22 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:14:22 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:14:22 --> Utf8 Class Initialized
INFO - 2021-09-24 13:14:22 --> URI Class Initialized
INFO - 2021-09-24 13:14:22 --> Router Class Initialized
INFO - 2021-09-24 13:14:22 --> Output Class Initialized
INFO - 2021-09-24 13:14:22 --> Security Class Initialized
DEBUG - 2021-09-24 13:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:14:23 --> Input Class Initialized
INFO - 2021-09-24 13:14:23 --> Language Class Initialized
INFO - 2021-09-24 13:14:23 --> Loader Class Initialized
INFO - 2021-09-24 13:14:23 --> Helper loaded: url_helper
INFO - 2021-09-24 13:14:23 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:14:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:14:23 --> Controller Class Initialized
INFO - 2021-09-24 13:14:23 --> Database Driver Class Initialized
INFO - 2021-09-24 13:14:23 --> Model "BlogModel" initialized
INFO - 2021-09-24 13:14:23 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:14:23 --> Model "CookieModel" initialized
INFO - 2021-09-24 13:14:23 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
ERROR - 2021-09-24 13:14:23 --> Severity: Notice --> Undefined variable: row F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 27
ERROR - 2021-09-24 13:14:23 --> Severity: Notice --> Trying to get property 'createdon' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 27
INFO - 2021-09-24 13:14:23 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/blogs.php
INFO - 2021-09-24 13:14:23 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 13:14:23 --> Final output sent to browser
DEBUG - 2021-09-24 13:14:23 --> Total execution time: 0.1231
INFO - 2021-09-24 13:23:40 --> Config Class Initialized
INFO - 2021-09-24 13:23:40 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:23:40 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:23:40 --> Utf8 Class Initialized
INFO - 2021-09-24 13:23:40 --> URI Class Initialized
INFO - 2021-09-24 13:23:40 --> Router Class Initialized
INFO - 2021-09-24 13:23:40 --> Output Class Initialized
INFO - 2021-09-24 13:23:40 --> Security Class Initialized
DEBUG - 2021-09-24 13:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:23:40 --> Input Class Initialized
INFO - 2021-09-24 13:23:40 --> Language Class Initialized
INFO - 2021-09-24 13:23:40 --> Loader Class Initialized
INFO - 2021-09-24 13:23:40 --> Helper loaded: url_helper
INFO - 2021-09-24 13:23:40 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:23:40 --> Controller Class Initialized
INFO - 2021-09-24 13:23:40 --> Database Driver Class Initialized
INFO - 2021-09-24 13:23:40 --> Model "BlogModel" initialized
INFO - 2021-09-24 13:23:40 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:23:40 --> Model "CookieModel" initialized
INFO - 2021-09-24 13:23:40 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 13:23:40 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/blogs.php
INFO - 2021-09-24 13:23:40 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 13:23:40 --> Final output sent to browser
DEBUG - 2021-09-24 13:23:40 --> Total execution time: 0.0791
INFO - 2021-09-24 13:26:48 --> Config Class Initialized
INFO - 2021-09-24 13:26:48 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:26:48 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:26:48 --> Utf8 Class Initialized
INFO - 2021-09-24 13:26:48 --> URI Class Initialized
INFO - 2021-09-24 13:26:48 --> Router Class Initialized
INFO - 2021-09-24 13:26:48 --> Output Class Initialized
INFO - 2021-09-24 13:26:48 --> Security Class Initialized
DEBUG - 2021-09-24 13:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:26:48 --> Input Class Initialized
INFO - 2021-09-24 13:26:48 --> Language Class Initialized
INFO - 2021-09-24 13:26:48 --> Loader Class Initialized
INFO - 2021-09-24 13:26:48 --> Helper loaded: url_helper
INFO - 2021-09-24 13:26:48 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:26:48 --> Controller Class Initialized
INFO - 2021-09-24 13:26:48 --> Database Driver Class Initialized
INFO - 2021-09-24 13:26:48 --> Model "BlogModel" initialized
INFO - 2021-09-24 13:26:48 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:26:48 --> Model "CookieModel" initialized
INFO - 2021-09-24 13:26:48 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 13:26:48 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/blogs.php
INFO - 2021-09-24 13:26:48 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 13:26:48 --> Final output sent to browser
DEBUG - 2021-09-24 13:26:48 --> Total execution time: 0.0944
INFO - 2021-09-24 13:27:24 --> Config Class Initialized
INFO - 2021-09-24 13:27:24 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:27:24 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:27:24 --> Utf8 Class Initialized
INFO - 2021-09-24 13:27:24 --> URI Class Initialized
INFO - 2021-09-24 13:27:24 --> Router Class Initialized
INFO - 2021-09-24 13:27:24 --> Output Class Initialized
INFO - 2021-09-24 13:27:24 --> Security Class Initialized
DEBUG - 2021-09-24 13:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:27:24 --> Input Class Initialized
INFO - 2021-09-24 13:27:24 --> Language Class Initialized
INFO - 2021-09-24 13:27:24 --> Loader Class Initialized
INFO - 2021-09-24 13:27:24 --> Helper loaded: url_helper
INFO - 2021-09-24 13:27:24 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:27:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:27:24 --> Controller Class Initialized
INFO - 2021-09-24 13:27:24 --> Database Driver Class Initialized
INFO - 2021-09-24 13:27:24 --> Model "BlogModel" initialized
INFO - 2021-09-24 13:27:24 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:27:24 --> Model "CookieModel" initialized
INFO - 2021-09-24 13:27:24 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 13:27:24 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/blogs.php
INFO - 2021-09-24 13:27:24 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 13:27:24 --> Final output sent to browser
DEBUG - 2021-09-24 13:27:24 --> Total execution time: 0.0680
INFO - 2021-09-24 13:27:42 --> Config Class Initialized
INFO - 2021-09-24 13:27:42 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:27:42 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:27:42 --> Utf8 Class Initialized
INFO - 2021-09-24 13:27:42 --> URI Class Initialized
INFO - 2021-09-24 13:27:42 --> Router Class Initialized
INFO - 2021-09-24 13:27:42 --> Output Class Initialized
INFO - 2021-09-24 13:27:42 --> Security Class Initialized
DEBUG - 2021-09-24 13:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:27:42 --> Input Class Initialized
INFO - 2021-09-24 13:27:42 --> Language Class Initialized
INFO - 2021-09-24 13:27:42 --> Loader Class Initialized
INFO - 2021-09-24 13:27:42 --> Helper loaded: url_helper
INFO - 2021-09-24 13:27:42 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:27:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:27:42 --> Controller Class Initialized
INFO - 2021-09-24 13:27:42 --> Database Driver Class Initialized
INFO - 2021-09-24 13:27:42 --> Model "BlogModel" initialized
INFO - 2021-09-24 13:27:42 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:27:42 --> Model "CookieModel" initialized
INFO - 2021-09-24 13:27:42 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 13:27:42 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/blogs.php
INFO - 2021-09-24 13:27:42 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 13:27:42 --> Final output sent to browser
DEBUG - 2021-09-24 13:27:42 --> Total execution time: 0.0713
INFO - 2021-09-24 13:27:45 --> Config Class Initialized
INFO - 2021-09-24 13:27:45 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:27:45 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:27:45 --> Utf8 Class Initialized
INFO - 2021-09-24 13:27:45 --> URI Class Initialized
INFO - 2021-09-24 13:27:45 --> Router Class Initialized
INFO - 2021-09-24 13:27:45 --> Output Class Initialized
INFO - 2021-09-24 13:27:45 --> Security Class Initialized
DEBUG - 2021-09-24 13:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:27:45 --> Input Class Initialized
INFO - 2021-09-24 13:27:45 --> Language Class Initialized
ERROR - 2021-09-24 13:27:45 --> 404 Page Not Found: Blog-details-1html/index
INFO - 2021-09-24 13:31:33 --> Config Class Initialized
INFO - 2021-09-24 13:31:33 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:31:33 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:31:33 --> Utf8 Class Initialized
INFO - 2021-09-24 13:31:33 --> URI Class Initialized
INFO - 2021-09-24 13:31:33 --> Router Class Initialized
INFO - 2021-09-24 13:31:33 --> Output Class Initialized
INFO - 2021-09-24 13:31:33 --> Security Class Initialized
DEBUG - 2021-09-24 13:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:31:33 --> Input Class Initialized
INFO - 2021-09-24 13:31:33 --> Language Class Initialized
ERROR - 2021-09-24 13:31:33 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) F:\xampp\htdocs\igapprojects\changeme\application\controllers\Blog.php 28
INFO - 2021-09-24 13:31:35 --> Config Class Initialized
INFO - 2021-09-24 13:31:35 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:31:35 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:31:35 --> Utf8 Class Initialized
INFO - 2021-09-24 13:31:35 --> URI Class Initialized
INFO - 2021-09-24 13:31:35 --> Router Class Initialized
INFO - 2021-09-24 13:31:35 --> Output Class Initialized
INFO - 2021-09-24 13:31:35 --> Security Class Initialized
DEBUG - 2021-09-24 13:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:31:35 --> Input Class Initialized
INFO - 2021-09-24 13:31:35 --> Language Class Initialized
ERROR - 2021-09-24 13:31:35 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) F:\xampp\htdocs\igapprojects\changeme\application\controllers\Blog.php 28
INFO - 2021-09-24 13:31:38 --> Config Class Initialized
INFO - 2021-09-24 13:31:38 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:31:38 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:31:38 --> Utf8 Class Initialized
INFO - 2021-09-24 13:31:38 --> URI Class Initialized
INFO - 2021-09-24 13:31:38 --> Router Class Initialized
INFO - 2021-09-24 13:31:38 --> Output Class Initialized
INFO - 2021-09-24 13:31:38 --> Security Class Initialized
DEBUG - 2021-09-24 13:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:31:38 --> Input Class Initialized
INFO - 2021-09-24 13:31:38 --> Language Class Initialized
INFO - 2021-09-24 13:31:38 --> Loader Class Initialized
INFO - 2021-09-24 13:31:38 --> Helper loaded: url_helper
INFO - 2021-09-24 13:31:38 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:31:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:31:38 --> Controller Class Initialized
INFO - 2021-09-24 13:31:38 --> Database Driver Class Initialized
INFO - 2021-09-24 13:31:38 --> Helper loaded: string_helper
INFO - 2021-09-24 13:31:38 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 13:31:38 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:31:38 --> Model "CookieModel" initialized
INFO - 2021-09-24 13:31:38 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 13:31:38 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/testimonials.php
INFO - 2021-09-24 13:31:38 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 13:31:38 --> Final output sent to browser
DEBUG - 2021-09-24 13:31:38 --> Total execution time: 0.0757
INFO - 2021-09-24 13:32:57 --> Config Class Initialized
INFO - 2021-09-24 13:32:57 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:32:57 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:32:57 --> Utf8 Class Initialized
INFO - 2021-09-24 13:32:57 --> URI Class Initialized
INFO - 2021-09-24 13:32:57 --> Router Class Initialized
INFO - 2021-09-24 13:32:57 --> Output Class Initialized
INFO - 2021-09-24 13:32:57 --> Security Class Initialized
DEBUG - 2021-09-24 13:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:32:57 --> Input Class Initialized
INFO - 2021-09-24 13:32:57 --> Language Class Initialized
INFO - 2021-09-24 13:32:57 --> Loader Class Initialized
INFO - 2021-09-24 13:32:57 --> Helper loaded: url_helper
INFO - 2021-09-24 13:32:57 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:32:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:32:57 --> Controller Class Initialized
INFO - 2021-09-24 13:32:57 --> Database Driver Class Initialized
INFO - 2021-09-24 13:32:57 --> Helper loaded: string_helper
INFO - 2021-09-24 13:32:57 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 13:32:57 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:32:57 --> Model "CookieModel" initialized
INFO - 2021-09-24 13:32:57 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 13:32:57 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/testimonials.php
INFO - 2021-09-24 13:32:57 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 13:32:57 --> Final output sent to browser
DEBUG - 2021-09-24 13:32:57 --> Total execution time: 0.0967
INFO - 2021-09-24 13:33:01 --> Config Class Initialized
INFO - 2021-09-24 13:33:01 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:33:01 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:33:01 --> Utf8 Class Initialized
INFO - 2021-09-24 13:33:01 --> URI Class Initialized
INFO - 2021-09-24 13:33:01 --> Router Class Initialized
INFO - 2021-09-24 13:33:01 --> Output Class Initialized
INFO - 2021-09-24 13:33:01 --> Security Class Initialized
DEBUG - 2021-09-24 13:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:33:01 --> Input Class Initialized
INFO - 2021-09-24 13:33:01 --> Language Class Initialized
ERROR - 2021-09-24 13:33:01 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC) F:\xampp\htdocs\igapprojects\changeme\application\controllers\Blog.php 28
INFO - 2021-09-24 13:33:29 --> Config Class Initialized
INFO - 2021-09-24 13:33:29 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:33:29 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:33:29 --> Utf8 Class Initialized
INFO - 2021-09-24 13:33:29 --> URI Class Initialized
INFO - 2021-09-24 13:33:29 --> Router Class Initialized
INFO - 2021-09-24 13:33:29 --> Output Class Initialized
INFO - 2021-09-24 13:33:29 --> Security Class Initialized
DEBUG - 2021-09-24 13:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:33:29 --> Input Class Initialized
INFO - 2021-09-24 13:33:29 --> Language Class Initialized
INFO - 2021-09-24 13:33:29 --> Loader Class Initialized
INFO - 2021-09-24 13:33:29 --> Helper loaded: url_helper
INFO - 2021-09-24 13:33:29 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:33:29 --> Controller Class Initialized
INFO - 2021-09-24 13:33:29 --> Database Driver Class Initialized
INFO - 2021-09-24 13:33:29 --> Model "BlogModel" initialized
INFO - 2021-09-24 13:33:29 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:33:29 --> Model "CookieModel" initialized
INFO - 2021-09-24 13:33:29 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 13:33:29 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/blogs.php
INFO - 2021-09-24 13:33:29 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 13:33:29 --> Final output sent to browser
DEBUG - 2021-09-24 13:33:29 --> Total execution time: 0.0966
INFO - 2021-09-24 13:34:00 --> Config Class Initialized
INFO - 2021-09-24 13:34:00 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:34:00 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:34:00 --> Utf8 Class Initialized
INFO - 2021-09-24 13:34:00 --> URI Class Initialized
INFO - 2021-09-24 13:34:00 --> Router Class Initialized
INFO - 2021-09-24 13:34:00 --> Output Class Initialized
INFO - 2021-09-24 13:34:00 --> Security Class Initialized
DEBUG - 2021-09-24 13:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:34:00 --> Input Class Initialized
INFO - 2021-09-24 13:34:00 --> Language Class Initialized
ERROR - 2021-09-24 13:34:00 --> 404 Page Not Found: Blogs/view
INFO - 2021-09-24 13:34:42 --> Config Class Initialized
INFO - 2021-09-24 13:34:42 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:34:42 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:34:42 --> Utf8 Class Initialized
INFO - 2021-09-24 13:34:42 --> URI Class Initialized
INFO - 2021-09-24 13:34:42 --> Router Class Initialized
INFO - 2021-09-24 13:34:42 --> Output Class Initialized
INFO - 2021-09-24 13:34:42 --> Security Class Initialized
DEBUG - 2021-09-24 13:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:34:42 --> Input Class Initialized
INFO - 2021-09-24 13:34:42 --> Language Class Initialized
INFO - 2021-09-24 13:34:42 --> Loader Class Initialized
INFO - 2021-09-24 13:34:42 --> Helper loaded: url_helper
INFO - 2021-09-24 13:34:42 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:34:42 --> Controller Class Initialized
INFO - 2021-09-24 13:34:42 --> Database Driver Class Initialized
INFO - 2021-09-24 13:34:42 --> Model "BlogModel" initialized
INFO - 2021-09-24 13:34:42 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:34:42 --> Model "CookieModel" initialized
INFO - 2021-09-24 13:34:42 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 13:34:42 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/blogs.php
INFO - 2021-09-24 13:34:42 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 13:34:42 --> Final output sent to browser
DEBUG - 2021-09-24 13:34:42 --> Total execution time: 0.0936
INFO - 2021-09-24 13:34:43 --> Config Class Initialized
INFO - 2021-09-24 13:34:43 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:34:43 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:34:43 --> Utf8 Class Initialized
INFO - 2021-09-24 13:34:43 --> URI Class Initialized
INFO - 2021-09-24 13:34:43 --> Router Class Initialized
INFO - 2021-09-24 13:34:43 --> Output Class Initialized
INFO - 2021-09-24 13:34:43 --> Security Class Initialized
DEBUG - 2021-09-24 13:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:34:43 --> Input Class Initialized
INFO - 2021-09-24 13:34:43 --> Language Class Initialized
INFO - 2021-09-24 13:34:43 --> Loader Class Initialized
INFO - 2021-09-24 13:34:43 --> Helper loaded: url_helper
INFO - 2021-09-24 13:34:43 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:34:43 --> Controller Class Initialized
INFO - 2021-09-24 13:34:43 --> Database Driver Class Initialized
INFO - 2021-09-24 13:34:43 --> Model "BlogModel" initialized
INFO - 2021-09-24 13:34:43 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:34:43 --> Model "CookieModel" initialized
INFO - 2021-09-24 13:34:43 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 13:34:43 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/blogs.php
INFO - 2021-09-24 13:34:43 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 13:34:43 --> Final output sent to browser
DEBUG - 2021-09-24 13:34:43 --> Total execution time: 0.0627
INFO - 2021-09-24 13:34:45 --> Config Class Initialized
INFO - 2021-09-24 13:34:45 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:34:45 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:34:45 --> Utf8 Class Initialized
INFO - 2021-09-24 13:34:45 --> URI Class Initialized
INFO - 2021-09-24 13:34:45 --> Router Class Initialized
INFO - 2021-09-24 13:34:45 --> Output Class Initialized
INFO - 2021-09-24 13:34:45 --> Security Class Initialized
DEBUG - 2021-09-24 13:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:34:45 --> Input Class Initialized
INFO - 2021-09-24 13:34:45 --> Language Class Initialized
INFO - 2021-09-24 13:34:45 --> Loader Class Initialized
INFO - 2021-09-24 13:34:45 --> Helper loaded: url_helper
INFO - 2021-09-24 13:34:45 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:34:45 --> Controller Class Initialized
INFO - 2021-09-24 13:34:45 --> Database Driver Class Initialized
INFO - 2021-09-24 13:34:45 --> Model "BlogModel" initialized
INFO - 2021-09-24 13:34:45 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:34:45 --> Model "CookieModel" initialized
INFO - 2021-09-24 13:34:45 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
ERROR - 2021-09-24 13:34:45 --> Severity: Notice --> Trying to get property 'createdon' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 32
ERROR - 2021-09-24 13:34:45 --> Severity: Notice --> Trying to get property 'urltitle' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 35
ERROR - 2021-09-24 13:34:45 --> Severity: Notice --> Trying to get property 'title' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 35
ERROR - 2021-09-24 13:34:45 --> Severity: Notice --> Trying to get property 'description' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 36
ERROR - 2021-09-24 13:34:45 --> Severity: Notice --> Trying to get property 'description' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 36
ERROR - 2021-09-24 13:34:45 --> Severity: Notice --> Trying to get property 'createdon' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 32
ERROR - 2021-09-24 13:34:45 --> Severity: Notice --> Trying to get property 'urltitle' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 35
ERROR - 2021-09-24 13:34:45 --> Severity: Notice --> Trying to get property 'title' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 35
ERROR - 2021-09-24 13:34:45 --> Severity: Notice --> Trying to get property 'description' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 36
ERROR - 2021-09-24 13:34:45 --> Severity: Notice --> Trying to get property 'description' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 36
ERROR - 2021-09-24 13:34:45 --> Severity: Notice --> Trying to get property 'createdon' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 32
ERROR - 2021-09-24 13:34:45 --> Severity: Notice --> Trying to get property 'urltitle' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 35
ERROR - 2021-09-24 13:34:45 --> Severity: Notice --> Trying to get property 'title' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 35
ERROR - 2021-09-24 13:34:45 --> Severity: Notice --> Trying to get property 'description' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 36
ERROR - 2021-09-24 13:34:45 --> Severity: Notice --> Trying to get property 'description' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 36
ERROR - 2021-09-24 13:34:45 --> Severity: Notice --> Trying to get property 'createdon' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 32
ERROR - 2021-09-24 13:34:45 --> Severity: Notice --> Trying to get property 'urltitle' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 35
ERROR - 2021-09-24 13:34:45 --> Severity: Notice --> Trying to get property 'title' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 35
ERROR - 2021-09-24 13:34:45 --> Severity: Notice --> Trying to get property 'description' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 36
ERROR - 2021-09-24 13:34:45 --> Severity: Notice --> Trying to get property 'description' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 36
ERROR - 2021-09-24 13:34:45 --> Severity: Notice --> Trying to get property 'createdon' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 32
ERROR - 2021-09-24 13:34:45 --> Severity: Notice --> Trying to get property 'urltitle' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 35
ERROR - 2021-09-24 13:34:45 --> Severity: Notice --> Trying to get property 'title' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 35
ERROR - 2021-09-24 13:34:45 --> Severity: Notice --> Trying to get property 'description' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 36
ERROR - 2021-09-24 13:34:45 --> Severity: Notice --> Trying to get property 'description' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 36
ERROR - 2021-09-24 13:34:45 --> Severity: Notice --> Trying to get property 'createdon' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 32
ERROR - 2021-09-24 13:34:45 --> Severity: Notice --> Trying to get property 'urltitle' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 35
ERROR - 2021-09-24 13:34:45 --> Severity: Notice --> Trying to get property 'title' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 35
ERROR - 2021-09-24 13:34:45 --> Severity: Notice --> Trying to get property 'description' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 36
ERROR - 2021-09-24 13:34:45 --> Severity: Notice --> Trying to get property 'description' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 36
INFO - 2021-09-24 13:34:45 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/blogs.php
INFO - 2021-09-24 13:34:45 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 13:34:45 --> Final output sent to browser
DEBUG - 2021-09-24 13:34:45 --> Total execution time: 0.1481
INFO - 2021-09-24 13:36:02 --> Config Class Initialized
INFO - 2021-09-24 13:36:02 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:36:02 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:36:02 --> Utf8 Class Initialized
INFO - 2021-09-24 13:36:02 --> URI Class Initialized
INFO - 2021-09-24 13:36:02 --> Router Class Initialized
INFO - 2021-09-24 13:36:02 --> Output Class Initialized
INFO - 2021-09-24 13:36:02 --> Security Class Initialized
DEBUG - 2021-09-24 13:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:36:02 --> Input Class Initialized
INFO - 2021-09-24 13:36:02 --> Language Class Initialized
INFO - 2021-09-24 13:36:02 --> Loader Class Initialized
INFO - 2021-09-24 13:36:02 --> Helper loaded: url_helper
INFO - 2021-09-24 13:36:02 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:36:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:36:02 --> Controller Class Initialized
INFO - 2021-09-24 13:36:02 --> Database Driver Class Initialized
INFO - 2021-09-24 13:36:02 --> Model "BlogModel" initialized
INFO - 2021-09-24 13:36:02 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:36:02 --> Model "CookieModel" initialized
INFO - 2021-09-24 13:36:02 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 13:36:02 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/blogs.php
INFO - 2021-09-24 13:36:02 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 13:36:02 --> Final output sent to browser
DEBUG - 2021-09-24 13:36:02 --> Total execution time: 0.0698
INFO - 2021-09-24 13:36:09 --> Config Class Initialized
INFO - 2021-09-24 13:36:09 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:36:09 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:36:09 --> Utf8 Class Initialized
INFO - 2021-09-24 13:36:09 --> URI Class Initialized
INFO - 2021-09-24 13:36:09 --> Router Class Initialized
INFO - 2021-09-24 13:36:09 --> Output Class Initialized
INFO - 2021-09-24 13:36:09 --> Security Class Initialized
DEBUG - 2021-09-24 13:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:36:09 --> Input Class Initialized
INFO - 2021-09-24 13:36:09 --> Language Class Initialized
INFO - 2021-09-24 13:36:09 --> Loader Class Initialized
INFO - 2021-09-24 13:36:09 --> Helper loaded: url_helper
INFO - 2021-09-24 13:36:09 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:36:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:36:09 --> Controller Class Initialized
INFO - 2021-09-24 13:36:09 --> Database Driver Class Initialized
INFO - 2021-09-24 13:36:09 --> Model "BlogModel" initialized
INFO - 2021-09-24 13:36:09 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:36:09 --> Model "CookieModel" initialized
INFO - 2021-09-24 13:36:09 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
ERROR - 2021-09-24 13:36:09 --> Severity: Notice --> Trying to get property 'createdon' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 32
ERROR - 2021-09-24 13:36:09 --> Severity: Notice --> Trying to get property 'urltitle' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 35
ERROR - 2021-09-24 13:36:09 --> Severity: Notice --> Trying to get property 'title' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 35
ERROR - 2021-09-24 13:36:09 --> Severity: Notice --> Trying to get property 'description' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 36
ERROR - 2021-09-24 13:36:09 --> Severity: Notice --> Trying to get property 'description' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 36
ERROR - 2021-09-24 13:36:09 --> Severity: Notice --> Trying to get property 'createdon' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 32
ERROR - 2021-09-24 13:36:09 --> Severity: Notice --> Trying to get property 'urltitle' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 35
ERROR - 2021-09-24 13:36:09 --> Severity: Notice --> Trying to get property 'title' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 35
ERROR - 2021-09-24 13:36:09 --> Severity: Notice --> Trying to get property 'description' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 36
ERROR - 2021-09-24 13:36:09 --> Severity: Notice --> Trying to get property 'description' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 36
ERROR - 2021-09-24 13:36:09 --> Severity: Notice --> Trying to get property 'createdon' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 32
ERROR - 2021-09-24 13:36:09 --> Severity: Notice --> Trying to get property 'urltitle' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 35
ERROR - 2021-09-24 13:36:09 --> Severity: Notice --> Trying to get property 'title' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 35
ERROR - 2021-09-24 13:36:09 --> Severity: Notice --> Trying to get property 'description' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 36
ERROR - 2021-09-24 13:36:09 --> Severity: Notice --> Trying to get property 'description' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 36
ERROR - 2021-09-24 13:36:09 --> Severity: Notice --> Trying to get property 'createdon' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 32
ERROR - 2021-09-24 13:36:09 --> Severity: Notice --> Trying to get property 'urltitle' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 35
ERROR - 2021-09-24 13:36:09 --> Severity: Notice --> Trying to get property 'title' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 35
ERROR - 2021-09-24 13:36:09 --> Severity: Notice --> Trying to get property 'description' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 36
ERROR - 2021-09-24 13:36:09 --> Severity: Notice --> Trying to get property 'description' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 36
ERROR - 2021-09-24 13:36:09 --> Severity: Notice --> Trying to get property 'createdon' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 32
ERROR - 2021-09-24 13:36:09 --> Severity: Notice --> Trying to get property 'urltitle' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 35
ERROR - 2021-09-24 13:36:09 --> Severity: Notice --> Trying to get property 'title' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 35
ERROR - 2021-09-24 13:36:09 --> Severity: Notice --> Trying to get property 'description' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 36
ERROR - 2021-09-24 13:36:09 --> Severity: Notice --> Trying to get property 'description' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 36
ERROR - 2021-09-24 13:36:09 --> Severity: Notice --> Trying to get property 'createdon' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 32
ERROR - 2021-09-24 13:36:09 --> Severity: Notice --> Trying to get property 'urltitle' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 35
ERROR - 2021-09-24 13:36:09 --> Severity: Notice --> Trying to get property 'title' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 35
ERROR - 2021-09-24 13:36:09 --> Severity: Notice --> Trying to get property 'description' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 36
ERROR - 2021-09-24 13:36:09 --> Severity: Notice --> Trying to get property 'description' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 36
INFO - 2021-09-24 13:36:09 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/blogs.php
INFO - 2021-09-24 13:36:09 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 13:36:09 --> Final output sent to browser
DEBUG - 2021-09-24 13:36:09 --> Total execution time: 0.1112
INFO - 2021-09-24 13:36:39 --> Config Class Initialized
INFO - 2021-09-24 13:36:39 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:36:39 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:36:39 --> Utf8 Class Initialized
INFO - 2021-09-24 13:36:39 --> URI Class Initialized
INFO - 2021-09-24 13:36:39 --> Router Class Initialized
INFO - 2021-09-24 13:36:39 --> Output Class Initialized
INFO - 2021-09-24 13:36:39 --> Security Class Initialized
DEBUG - 2021-09-24 13:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:36:39 --> Input Class Initialized
INFO - 2021-09-24 13:36:39 --> Language Class Initialized
INFO - 2021-09-24 13:36:39 --> Loader Class Initialized
INFO - 2021-09-24 13:36:39 --> Helper loaded: url_helper
INFO - 2021-09-24 13:36:39 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:36:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:36:39 --> Controller Class Initialized
INFO - 2021-09-24 13:36:39 --> Database Driver Class Initialized
INFO - 2021-09-24 13:36:39 --> Model "BlogModel" initialized
INFO - 2021-09-24 13:36:39 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:36:39 --> Model "CookieModel" initialized
INFO - 2021-09-24 13:36:39 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 13:36:39 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/blogs.php
INFO - 2021-09-24 13:36:39 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 13:36:39 --> Final output sent to browser
DEBUG - 2021-09-24 13:36:39 --> Total execution time: 0.0724
INFO - 2021-09-24 13:37:08 --> Config Class Initialized
INFO - 2021-09-24 13:37:08 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:37:08 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:37:08 --> Utf8 Class Initialized
INFO - 2021-09-24 13:37:08 --> URI Class Initialized
INFO - 2021-09-24 13:37:08 --> Router Class Initialized
INFO - 2021-09-24 13:37:08 --> Output Class Initialized
INFO - 2021-09-24 13:37:08 --> Security Class Initialized
DEBUG - 2021-09-24 13:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:37:08 --> Input Class Initialized
INFO - 2021-09-24 13:37:09 --> Language Class Initialized
ERROR - 2021-09-24 13:37:09 --> Severity: error --> Exception: syntax error, unexpected '$data' (T_VARIABLE) F:\xampp\htdocs\igapprojects\changeme\application\controllers\Blog.php 38
INFO - 2021-09-24 13:37:28 --> Config Class Initialized
INFO - 2021-09-24 13:37:28 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:37:28 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:37:28 --> Utf8 Class Initialized
INFO - 2021-09-24 13:37:28 --> URI Class Initialized
INFO - 2021-09-24 13:37:28 --> Router Class Initialized
INFO - 2021-09-24 13:37:28 --> Output Class Initialized
INFO - 2021-09-24 13:37:28 --> Security Class Initialized
DEBUG - 2021-09-24 13:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:37:28 --> Input Class Initialized
INFO - 2021-09-24 13:37:28 --> Language Class Initialized
INFO - 2021-09-24 13:37:28 --> Loader Class Initialized
INFO - 2021-09-24 13:37:28 --> Helper loaded: url_helper
INFO - 2021-09-24 13:37:28 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:37:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:37:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:37:28 --> Controller Class Initialized
INFO - 2021-09-24 13:37:28 --> Database Driver Class Initialized
INFO - 2021-09-24 13:37:28 --> Helper loaded: string_helper
INFO - 2021-09-24 13:37:28 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 13:37:28 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:37:28 --> Model "CookieModel" initialized
INFO - 2021-09-24 13:37:28 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 13:37:28 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/testimonials.php
INFO - 2021-09-24 13:37:28 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 13:37:28 --> Final output sent to browser
DEBUG - 2021-09-24 13:37:28 --> Total execution time: 0.0725
INFO - 2021-09-24 13:37:30 --> Config Class Initialized
INFO - 2021-09-24 13:37:30 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:37:30 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:37:30 --> Utf8 Class Initialized
INFO - 2021-09-24 13:37:30 --> URI Class Initialized
INFO - 2021-09-24 13:37:30 --> Router Class Initialized
INFO - 2021-09-24 13:37:30 --> Output Class Initialized
INFO - 2021-09-24 13:37:30 --> Security Class Initialized
DEBUG - 2021-09-24 13:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:37:30 --> Input Class Initialized
INFO - 2021-09-24 13:37:30 --> Language Class Initialized
INFO - 2021-09-24 13:37:30 --> Loader Class Initialized
INFO - 2021-09-24 13:37:30 --> Helper loaded: url_helper
INFO - 2021-09-24 13:37:30 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:37:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:37:30 --> Controller Class Initialized
INFO - 2021-09-24 13:37:30 --> Database Driver Class Initialized
INFO - 2021-09-24 13:37:30 --> Helper loaded: string_helper
INFO - 2021-09-24 13:37:30 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 13:37:30 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:37:30 --> Model "CookieModel" initialized
INFO - 2021-09-24 13:37:30 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 13:37:30 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/testimonials.php
INFO - 2021-09-24 13:37:30 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 13:37:30 --> Final output sent to browser
DEBUG - 2021-09-24 13:37:30 --> Total execution time: 0.0708
INFO - 2021-09-24 13:37:32 --> Config Class Initialized
INFO - 2021-09-24 13:37:32 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:37:32 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:37:32 --> Utf8 Class Initialized
INFO - 2021-09-24 13:37:32 --> URI Class Initialized
INFO - 2021-09-24 13:37:32 --> Router Class Initialized
INFO - 2021-09-24 13:37:32 --> Output Class Initialized
INFO - 2021-09-24 13:37:32 --> Security Class Initialized
DEBUG - 2021-09-24 13:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:37:32 --> Input Class Initialized
INFO - 2021-09-24 13:37:32 --> Language Class Initialized
ERROR - 2021-09-24 13:37:32 --> Severity: error --> Exception: syntax error, unexpected '$data' (T_VARIABLE) F:\xampp\htdocs\igapprojects\changeme\application\controllers\Blog.php 38
INFO - 2021-09-24 13:37:46 --> Config Class Initialized
INFO - 2021-09-24 13:37:46 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:37:46 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:37:46 --> Utf8 Class Initialized
INFO - 2021-09-24 13:37:46 --> URI Class Initialized
INFO - 2021-09-24 13:37:46 --> Router Class Initialized
INFO - 2021-09-24 13:37:46 --> Output Class Initialized
INFO - 2021-09-24 13:37:46 --> Security Class Initialized
DEBUG - 2021-09-24 13:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:37:46 --> Input Class Initialized
INFO - 2021-09-24 13:37:46 --> Language Class Initialized
INFO - 2021-09-24 13:37:46 --> Loader Class Initialized
INFO - 2021-09-24 13:37:46 --> Helper loaded: url_helper
INFO - 2021-09-24 13:37:46 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:37:46 --> Controller Class Initialized
INFO - 2021-09-24 13:37:46 --> Database Driver Class Initialized
INFO - 2021-09-24 13:37:46 --> Model "BlogModel" initialized
INFO - 2021-09-24 13:37:46 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:37:46 --> Model "CookieModel" initialized
INFO - 2021-09-24 13:37:46 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 13:37:46 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/blogs.php
INFO - 2021-09-24 13:37:46 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 13:37:46 --> Final output sent to browser
DEBUG - 2021-09-24 13:37:46 --> Total execution time: 0.0647
INFO - 2021-09-24 13:37:49 --> Config Class Initialized
INFO - 2021-09-24 13:37:49 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:37:49 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:37:49 --> Utf8 Class Initialized
INFO - 2021-09-24 13:37:49 --> URI Class Initialized
INFO - 2021-09-24 13:37:49 --> Router Class Initialized
INFO - 2021-09-24 13:37:49 --> Output Class Initialized
INFO - 2021-09-24 13:37:49 --> Security Class Initialized
DEBUG - 2021-09-24 13:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:37:49 --> Input Class Initialized
INFO - 2021-09-24 13:37:49 --> Language Class Initialized
INFO - 2021-09-24 13:37:49 --> Loader Class Initialized
INFO - 2021-09-24 13:37:49 --> Helper loaded: url_helper
INFO - 2021-09-24 13:37:49 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:37:49 --> Controller Class Initialized
INFO - 2021-09-24 13:37:49 --> Database Driver Class Initialized
INFO - 2021-09-24 13:37:49 --> Model "BlogModel" initialized
INFO - 2021-09-24 13:37:49 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:37:49 --> Model "CookieModel" initialized
INFO - 2021-09-24 13:37:49 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
ERROR - 2021-09-24 13:37:49 --> Severity: Notice --> Trying to get property 'createdon' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 32
ERROR - 2021-09-24 13:37:49 --> Severity: Notice --> Trying to get property 'urltitle' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 35
ERROR - 2021-09-24 13:37:49 --> Severity: Notice --> Trying to get property 'title' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 35
ERROR - 2021-09-24 13:37:49 --> Severity: Notice --> Trying to get property 'description' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 36
ERROR - 2021-09-24 13:37:49 --> Severity: Notice --> Trying to get property 'description' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 36
ERROR - 2021-09-24 13:37:49 --> Severity: Notice --> Trying to get property 'createdon' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 32
ERROR - 2021-09-24 13:37:49 --> Severity: Notice --> Trying to get property 'urltitle' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 35
ERROR - 2021-09-24 13:37:49 --> Severity: Notice --> Trying to get property 'title' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 35
ERROR - 2021-09-24 13:37:49 --> Severity: Notice --> Trying to get property 'description' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 36
ERROR - 2021-09-24 13:37:49 --> Severity: Notice --> Trying to get property 'description' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 36
ERROR - 2021-09-24 13:37:49 --> Severity: Notice --> Trying to get property 'createdon' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 32
ERROR - 2021-09-24 13:37:49 --> Severity: Notice --> Trying to get property 'urltitle' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 35
ERROR - 2021-09-24 13:37:49 --> Severity: Notice --> Trying to get property 'title' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 35
ERROR - 2021-09-24 13:37:49 --> Severity: Notice --> Trying to get property 'description' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 36
ERROR - 2021-09-24 13:37:49 --> Severity: Notice --> Trying to get property 'description' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 36
ERROR - 2021-09-24 13:37:49 --> Severity: Notice --> Trying to get property 'createdon' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 32
ERROR - 2021-09-24 13:37:49 --> Severity: Notice --> Trying to get property 'urltitle' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 35
ERROR - 2021-09-24 13:37:49 --> Severity: Notice --> Trying to get property 'title' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 35
ERROR - 2021-09-24 13:37:49 --> Severity: Notice --> Trying to get property 'description' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 36
ERROR - 2021-09-24 13:37:49 --> Severity: Notice --> Trying to get property 'description' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 36
ERROR - 2021-09-24 13:37:49 --> Severity: Notice --> Trying to get property 'createdon' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 32
ERROR - 2021-09-24 13:37:49 --> Severity: Notice --> Trying to get property 'urltitle' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 35
ERROR - 2021-09-24 13:37:49 --> Severity: Notice --> Trying to get property 'title' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 35
ERROR - 2021-09-24 13:37:49 --> Severity: Notice --> Trying to get property 'description' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 36
ERROR - 2021-09-24 13:37:49 --> Severity: Notice --> Trying to get property 'description' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 36
ERROR - 2021-09-24 13:37:49 --> Severity: Notice --> Trying to get property 'createdon' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 32
ERROR - 2021-09-24 13:37:49 --> Severity: Notice --> Trying to get property 'urltitle' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 35
ERROR - 2021-09-24 13:37:49 --> Severity: Notice --> Trying to get property 'title' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 35
ERROR - 2021-09-24 13:37:49 --> Severity: Notice --> Trying to get property 'description' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 36
ERROR - 2021-09-24 13:37:49 --> Severity: Notice --> Trying to get property 'description' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blogs.php 36
INFO - 2021-09-24 13:37:49 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/blogs.php
INFO - 2021-09-24 13:37:49 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 13:37:49 --> Final output sent to browser
DEBUG - 2021-09-24 13:37:49 --> Total execution time: 0.1314
INFO - 2021-09-24 13:38:25 --> Config Class Initialized
INFO - 2021-09-24 13:38:25 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:38:25 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:38:25 --> Utf8 Class Initialized
INFO - 2021-09-24 13:38:25 --> URI Class Initialized
INFO - 2021-09-24 13:38:25 --> Router Class Initialized
INFO - 2021-09-24 13:38:25 --> Output Class Initialized
INFO - 2021-09-24 13:38:25 --> Security Class Initialized
DEBUG - 2021-09-24 13:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:38:25 --> Input Class Initialized
INFO - 2021-09-24 13:38:25 --> Language Class Initialized
INFO - 2021-09-24 13:38:25 --> Loader Class Initialized
INFO - 2021-09-24 13:38:25 --> Helper loaded: url_helper
INFO - 2021-09-24 13:38:25 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:38:25 --> Controller Class Initialized
INFO - 2021-09-24 13:38:25 --> Database Driver Class Initialized
INFO - 2021-09-24 13:38:25 --> Model "BlogModel" initialized
INFO - 2021-09-24 13:38:25 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:38:25 --> Model "CookieModel" initialized
ERROR - 2021-09-24 13:38:25 --> Severity: Notice --> Array to string conversion F:\xampp\htdocs\igapprojects\changeme\application\controllers\Blog.php 38
INFO - 2021-09-24 13:38:30 --> Config Class Initialized
INFO - 2021-09-24 13:38:30 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:38:30 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:38:30 --> Utf8 Class Initialized
INFO - 2021-09-24 13:38:30 --> URI Class Initialized
INFO - 2021-09-24 13:38:30 --> Router Class Initialized
INFO - 2021-09-24 13:38:30 --> Output Class Initialized
INFO - 2021-09-24 13:38:30 --> Security Class Initialized
DEBUG - 2021-09-24 13:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:38:30 --> Input Class Initialized
INFO - 2021-09-24 13:38:30 --> Language Class Initialized
INFO - 2021-09-24 13:38:30 --> Loader Class Initialized
INFO - 2021-09-24 13:38:30 --> Helper loaded: url_helper
INFO - 2021-09-24 13:38:30 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:38:30 --> Controller Class Initialized
INFO - 2021-09-24 13:38:30 --> Database Driver Class Initialized
INFO - 2021-09-24 13:38:30 --> Model "BlogModel" initialized
INFO - 2021-09-24 13:38:30 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:38:30 --> Model "CookieModel" initialized
INFO - 2021-09-24 13:38:30 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 13:38:30 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/blogs.php
INFO - 2021-09-24 13:38:30 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 13:38:30 --> Final output sent to browser
DEBUG - 2021-09-24 13:38:30 --> Total execution time: 0.0786
INFO - 2021-09-24 13:38:33 --> Config Class Initialized
INFO - 2021-09-24 13:38:33 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:38:33 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:38:33 --> Utf8 Class Initialized
INFO - 2021-09-24 13:38:33 --> URI Class Initialized
INFO - 2021-09-24 13:38:33 --> Router Class Initialized
INFO - 2021-09-24 13:38:33 --> Output Class Initialized
INFO - 2021-09-24 13:38:33 --> Security Class Initialized
DEBUG - 2021-09-24 13:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:38:33 --> Input Class Initialized
INFO - 2021-09-24 13:38:33 --> Language Class Initialized
INFO - 2021-09-24 13:38:33 --> Loader Class Initialized
INFO - 2021-09-24 13:38:33 --> Helper loaded: url_helper
INFO - 2021-09-24 13:38:33 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:38:33 --> Controller Class Initialized
INFO - 2021-09-24 13:38:33 --> Database Driver Class Initialized
INFO - 2021-09-24 13:38:33 --> Model "BlogModel" initialized
INFO - 2021-09-24 13:38:33 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:38:33 --> Model "CookieModel" initialized
ERROR - 2021-09-24 13:38:33 --> Severity: Notice --> Array to string conversion F:\xampp\htdocs\igapprojects\changeme\application\controllers\Blog.php 38
INFO - 2021-09-24 13:40:12 --> Config Class Initialized
INFO - 2021-09-24 13:40:12 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:40:12 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:40:12 --> Utf8 Class Initialized
INFO - 2021-09-24 13:40:12 --> URI Class Initialized
INFO - 2021-09-24 13:40:12 --> Router Class Initialized
INFO - 2021-09-24 13:40:12 --> Output Class Initialized
INFO - 2021-09-24 13:40:12 --> Security Class Initialized
DEBUG - 2021-09-24 13:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:40:12 --> Input Class Initialized
INFO - 2021-09-24 13:40:12 --> Language Class Initialized
INFO - 2021-09-24 13:40:12 --> Loader Class Initialized
INFO - 2021-09-24 13:40:12 --> Helper loaded: url_helper
INFO - 2021-09-24 13:40:12 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:40:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:40:12 --> Controller Class Initialized
INFO - 2021-09-24 13:40:13 --> Database Driver Class Initialized
INFO - 2021-09-24 13:40:13 --> Model "BlogModel" initialized
INFO - 2021-09-24 13:40:13 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:40:13 --> Model "CookieModel" initialized
INFO - 2021-09-24 13:40:55 --> Config Class Initialized
INFO - 2021-09-24 13:40:55 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:40:55 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:40:55 --> Utf8 Class Initialized
INFO - 2021-09-24 13:40:55 --> URI Class Initialized
INFO - 2021-09-24 13:40:55 --> Router Class Initialized
INFO - 2021-09-24 13:40:55 --> Output Class Initialized
INFO - 2021-09-24 13:40:55 --> Security Class Initialized
DEBUG - 2021-09-24 13:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:40:55 --> Input Class Initialized
INFO - 2021-09-24 13:40:55 --> Language Class Initialized
INFO - 2021-09-24 13:40:55 --> Loader Class Initialized
INFO - 2021-09-24 13:40:55 --> Helper loaded: url_helper
INFO - 2021-09-24 13:40:55 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:40:55 --> Controller Class Initialized
INFO - 2021-09-24 13:40:55 --> Database Driver Class Initialized
INFO - 2021-09-24 13:40:55 --> Model "BlogModel" initialized
INFO - 2021-09-24 13:40:55 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:40:55 --> Model "CookieModel" initialized
INFO - 2021-09-24 13:40:55 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 13:40:55 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/blogs.php
INFO - 2021-09-24 13:40:55 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 13:40:55 --> Final output sent to browser
DEBUG - 2021-09-24 13:40:55 --> Total execution time: 0.2010
INFO - 2021-09-24 13:41:04 --> Config Class Initialized
INFO - 2021-09-24 13:41:04 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:41:04 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:41:04 --> Utf8 Class Initialized
INFO - 2021-09-24 13:41:04 --> URI Class Initialized
INFO - 2021-09-24 13:41:04 --> Router Class Initialized
INFO - 2021-09-24 13:41:04 --> Output Class Initialized
INFO - 2021-09-24 13:41:04 --> Security Class Initialized
DEBUG - 2021-09-24 13:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:41:04 --> Input Class Initialized
INFO - 2021-09-24 13:41:04 --> Language Class Initialized
INFO - 2021-09-24 13:41:04 --> Loader Class Initialized
INFO - 2021-09-24 13:41:04 --> Helper loaded: url_helper
INFO - 2021-09-24 13:41:04 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:41:04 --> Controller Class Initialized
INFO - 2021-09-24 13:41:04 --> Database Driver Class Initialized
INFO - 2021-09-24 13:41:04 --> Helper loaded: string_helper
INFO - 2021-09-24 13:41:04 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 13:41:04 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:41:04 --> Model "CookieModel" initialized
INFO - 2021-09-24 13:41:04 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 13:41:04 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/testimonials.php
INFO - 2021-09-24 13:41:04 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 13:41:04 --> Final output sent to browser
DEBUG - 2021-09-24 13:41:04 --> Total execution time: 0.0991
INFO - 2021-09-24 13:41:06 --> Config Class Initialized
INFO - 2021-09-24 13:41:06 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:41:06 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:41:06 --> Utf8 Class Initialized
INFO - 2021-09-24 13:41:06 --> URI Class Initialized
INFO - 2021-09-24 13:41:06 --> Router Class Initialized
INFO - 2021-09-24 13:41:06 --> Output Class Initialized
INFO - 2021-09-24 13:41:06 --> Security Class Initialized
DEBUG - 2021-09-24 13:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:41:06 --> Input Class Initialized
INFO - 2021-09-24 13:41:06 --> Language Class Initialized
INFO - 2021-09-24 13:41:06 --> Loader Class Initialized
INFO - 2021-09-24 13:41:06 --> Helper loaded: url_helper
INFO - 2021-09-24 13:41:06 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:41:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:41:06 --> Controller Class Initialized
INFO - 2021-09-24 13:41:06 --> Database Driver Class Initialized
INFO - 2021-09-24 13:41:06 --> Model "BlogModel" initialized
INFO - 2021-09-24 13:41:06 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:41:06 --> Model "CookieModel" initialized
INFO - 2021-09-24 13:41:06 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 13:41:06 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/blogs.php
INFO - 2021-09-24 13:41:06 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 13:41:06 --> Final output sent to browser
DEBUG - 2021-09-24 13:41:06 --> Total execution time: 0.0838
INFO - 2021-09-24 13:41:08 --> Config Class Initialized
INFO - 2021-09-24 13:41:08 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:41:08 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:41:08 --> Utf8 Class Initialized
INFO - 2021-09-24 13:41:08 --> URI Class Initialized
INFO - 2021-09-24 13:41:08 --> Router Class Initialized
INFO - 2021-09-24 13:41:08 --> Output Class Initialized
INFO - 2021-09-24 13:41:08 --> Security Class Initialized
DEBUG - 2021-09-24 13:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:41:08 --> Input Class Initialized
INFO - 2021-09-24 13:41:08 --> Language Class Initialized
INFO - 2021-09-24 13:41:08 --> Loader Class Initialized
INFO - 2021-09-24 13:41:08 --> Helper loaded: url_helper
INFO - 2021-09-24 13:41:08 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:41:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:41:08 --> Controller Class Initialized
INFO - 2021-09-24 13:41:08 --> Database Driver Class Initialized
INFO - 2021-09-24 13:41:08 --> Model "BlogModel" initialized
INFO - 2021-09-24 13:41:08 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:41:08 --> Model "CookieModel" initialized
INFO - 2021-09-24 13:42:23 --> Config Class Initialized
INFO - 2021-09-24 13:42:23 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:42:23 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:42:23 --> Utf8 Class Initialized
INFO - 2021-09-24 13:42:23 --> URI Class Initialized
INFO - 2021-09-24 13:42:23 --> Router Class Initialized
INFO - 2021-09-24 13:42:23 --> Output Class Initialized
INFO - 2021-09-24 13:42:23 --> Security Class Initialized
DEBUG - 2021-09-24 13:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:42:23 --> Input Class Initialized
INFO - 2021-09-24 13:42:23 --> Language Class Initialized
INFO - 2021-09-24 13:42:23 --> Loader Class Initialized
INFO - 2021-09-24 13:42:23 --> Helper loaded: url_helper
INFO - 2021-09-24 13:42:23 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:42:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:42:23 --> Controller Class Initialized
INFO - 2021-09-24 13:42:23 --> Database Driver Class Initialized
INFO - 2021-09-24 13:42:23 --> Model "BlogModel" initialized
INFO - 2021-09-24 13:42:23 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:42:23 --> Model "CookieModel" initialized
INFO - 2021-09-24 13:42:23 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 13:42:23 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/blogs.php
INFO - 2021-09-24 13:42:23 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 13:42:23 --> Final output sent to browser
DEBUG - 2021-09-24 13:42:23 --> Total execution time: 0.0753
INFO - 2021-09-24 13:43:39 --> Config Class Initialized
INFO - 2021-09-24 13:43:39 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:43:39 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:43:39 --> Utf8 Class Initialized
INFO - 2021-09-24 13:43:39 --> URI Class Initialized
INFO - 2021-09-24 13:43:39 --> Router Class Initialized
INFO - 2021-09-24 13:43:39 --> Output Class Initialized
INFO - 2021-09-24 13:43:39 --> Security Class Initialized
DEBUG - 2021-09-24 13:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:43:39 --> Input Class Initialized
INFO - 2021-09-24 13:43:39 --> Language Class Initialized
INFO - 2021-09-24 13:43:39 --> Loader Class Initialized
INFO - 2021-09-24 13:43:39 --> Helper loaded: url_helper
INFO - 2021-09-24 13:43:39 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:43:39 --> Controller Class Initialized
INFO - 2021-09-24 13:43:39 --> Database Driver Class Initialized
INFO - 2021-09-24 13:43:39 --> Model "BlogModel" initialized
INFO - 2021-09-24 13:43:39 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:43:39 --> Model "CookieModel" initialized
INFO - 2021-09-24 13:43:39 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 13:43:39 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/blogs.php
INFO - 2021-09-24 13:43:39 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 13:43:39 --> Final output sent to browser
DEBUG - 2021-09-24 13:43:39 --> Total execution time: 0.1453
INFO - 2021-09-24 13:43:40 --> Config Class Initialized
INFO - 2021-09-24 13:43:40 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:43:40 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:43:40 --> Utf8 Class Initialized
INFO - 2021-09-24 13:43:40 --> URI Class Initialized
INFO - 2021-09-24 13:43:40 --> Router Class Initialized
INFO - 2021-09-24 13:43:40 --> Output Class Initialized
INFO - 2021-09-24 13:43:40 --> Security Class Initialized
DEBUG - 2021-09-24 13:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:43:40 --> Input Class Initialized
INFO - 2021-09-24 13:43:40 --> Language Class Initialized
INFO - 2021-09-24 13:43:40 --> Loader Class Initialized
INFO - 2021-09-24 13:43:40 --> Helper loaded: url_helper
INFO - 2021-09-24 13:43:40 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:43:40 --> Controller Class Initialized
INFO - 2021-09-24 13:43:40 --> Database Driver Class Initialized
INFO - 2021-09-24 13:43:40 --> Model "BlogModel" initialized
INFO - 2021-09-24 13:43:40 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:43:40 --> Model "CookieModel" initialized
INFO - 2021-09-24 13:43:40 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
ERROR - 2021-09-24 13:43:40 --> Severity: Notice --> Trying to get property 'createdon' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blog.php 32
ERROR - 2021-09-24 13:43:40 --> Severity: Notice --> Trying to get property 'urltitle' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blog.php 35
ERROR - 2021-09-24 13:43:40 --> Severity: Notice --> Trying to get property 'title' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blog.php 35
ERROR - 2021-09-24 13:43:40 --> Severity: Notice --> Trying to get property 'description' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blog.php 36
ERROR - 2021-09-24 13:43:40 --> Severity: Notice --> Trying to get property 'createdon' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blog.php 32
ERROR - 2021-09-24 13:43:40 --> Severity: Notice --> Trying to get property 'urltitle' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blog.php 35
ERROR - 2021-09-24 13:43:40 --> Severity: Notice --> Trying to get property 'title' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blog.php 35
ERROR - 2021-09-24 13:43:40 --> Severity: Notice --> Trying to get property 'description' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blog.php 36
ERROR - 2021-09-24 13:43:40 --> Severity: Notice --> Trying to get property 'createdon' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blog.php 32
ERROR - 2021-09-24 13:43:40 --> Severity: Notice --> Trying to get property 'urltitle' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blog.php 35
ERROR - 2021-09-24 13:43:40 --> Severity: Notice --> Trying to get property 'title' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blog.php 35
ERROR - 2021-09-24 13:43:40 --> Severity: Notice --> Trying to get property 'description' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blog.php 36
ERROR - 2021-09-24 13:43:40 --> Severity: Notice --> Trying to get property 'createdon' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blog.php 32
ERROR - 2021-09-24 13:43:40 --> Severity: Notice --> Trying to get property 'urltitle' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blog.php 35
ERROR - 2021-09-24 13:43:40 --> Severity: Notice --> Trying to get property 'title' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blog.php 35
ERROR - 2021-09-24 13:43:40 --> Severity: Notice --> Trying to get property 'description' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blog.php 36
ERROR - 2021-09-24 13:43:40 --> Severity: Notice --> Trying to get property 'createdon' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blog.php 32
ERROR - 2021-09-24 13:43:40 --> Severity: Notice --> Trying to get property 'urltitle' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blog.php 35
ERROR - 2021-09-24 13:43:40 --> Severity: Notice --> Trying to get property 'title' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blog.php 35
ERROR - 2021-09-24 13:43:40 --> Severity: Notice --> Trying to get property 'description' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blog.php 36
ERROR - 2021-09-24 13:43:40 --> Severity: Notice --> Trying to get property 'createdon' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blog.php 32
ERROR - 2021-09-24 13:43:40 --> Severity: Notice --> Trying to get property 'urltitle' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blog.php 35
ERROR - 2021-09-24 13:43:40 --> Severity: Notice --> Trying to get property 'title' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blog.php 35
ERROR - 2021-09-24 13:43:40 --> Severity: Notice --> Trying to get property 'description' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blog.php 36
INFO - 2021-09-24 13:43:40 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/blog.php
INFO - 2021-09-24 13:43:40 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 13:43:40 --> Final output sent to browser
DEBUG - 2021-09-24 13:43:40 --> Total execution time: 0.1071
INFO - 2021-09-24 13:44:21 --> Config Class Initialized
INFO - 2021-09-24 13:44:21 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:44:21 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:44:21 --> Utf8 Class Initialized
INFO - 2021-09-24 13:44:21 --> URI Class Initialized
INFO - 2021-09-24 13:44:21 --> Router Class Initialized
INFO - 2021-09-24 13:44:21 --> Output Class Initialized
INFO - 2021-09-24 13:44:21 --> Security Class Initialized
DEBUG - 2021-09-24 13:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:44:21 --> Input Class Initialized
INFO - 2021-09-24 13:44:21 --> Language Class Initialized
INFO - 2021-09-24 13:44:21 --> Loader Class Initialized
INFO - 2021-09-24 13:44:21 --> Helper loaded: url_helper
INFO - 2021-09-24 13:44:21 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:44:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:44:21 --> Controller Class Initialized
INFO - 2021-09-24 13:44:21 --> Database Driver Class Initialized
INFO - 2021-09-24 13:44:21 --> Model "BlogModel" initialized
INFO - 2021-09-24 13:44:21 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:44:21 --> Model "CookieModel" initialized
INFO - 2021-09-24 13:44:21 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
ERROR - 2021-09-24 13:44:21 --> Severity: Notice --> Undefined variable: row F:\xampp\htdocs\igapprojects\changeme\application\views\user\blog.php 31
ERROR - 2021-09-24 13:44:21 --> Severity: Notice --> Trying to get property 'title' of non-object F:\xampp\htdocs\igapprojects\changeme\application\views\user\blog.php 31
INFO - 2021-09-24 13:44:21 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/blog.php
INFO - 2021-09-24 13:44:21 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 13:44:21 --> Final output sent to browser
DEBUG - 2021-09-24 13:44:21 --> Total execution time: 0.0825
INFO - 2021-09-24 13:46:09 --> Config Class Initialized
INFO - 2021-09-24 13:46:09 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:46:09 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:46:09 --> Utf8 Class Initialized
INFO - 2021-09-24 13:46:09 --> URI Class Initialized
INFO - 2021-09-24 13:46:09 --> Router Class Initialized
INFO - 2021-09-24 13:46:09 --> Output Class Initialized
INFO - 2021-09-24 13:46:09 --> Security Class Initialized
DEBUG - 2021-09-24 13:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:46:09 --> Input Class Initialized
INFO - 2021-09-24 13:46:09 --> Language Class Initialized
INFO - 2021-09-24 13:46:09 --> Loader Class Initialized
INFO - 2021-09-24 13:46:09 --> Helper loaded: url_helper
INFO - 2021-09-24 13:46:09 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:46:09 --> Controller Class Initialized
INFO - 2021-09-24 13:46:09 --> Database Driver Class Initialized
INFO - 2021-09-24 13:46:09 --> Model "BlogModel" initialized
INFO - 2021-09-24 13:46:09 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:46:09 --> Model "CookieModel" initialized
INFO - 2021-09-24 13:46:09 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 13:46:09 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/blog.php
INFO - 2021-09-24 13:46:09 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 13:46:09 --> Final output sent to browser
DEBUG - 2021-09-24 13:46:09 --> Total execution time: 0.0714
INFO - 2021-09-24 13:46:38 --> Config Class Initialized
INFO - 2021-09-24 13:46:38 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:46:38 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:46:38 --> Utf8 Class Initialized
INFO - 2021-09-24 13:46:38 --> URI Class Initialized
INFO - 2021-09-24 13:46:38 --> Router Class Initialized
INFO - 2021-09-24 13:46:38 --> Output Class Initialized
INFO - 2021-09-24 13:46:38 --> Security Class Initialized
DEBUG - 2021-09-24 13:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:46:38 --> Input Class Initialized
INFO - 2021-09-24 13:46:38 --> Language Class Initialized
INFO - 2021-09-24 13:46:38 --> Loader Class Initialized
INFO - 2021-09-24 13:46:38 --> Helper loaded: url_helper
INFO - 2021-09-24 13:46:38 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:46:38 --> Controller Class Initialized
INFO - 2021-09-24 13:46:38 --> Database Driver Class Initialized
INFO - 2021-09-24 13:46:38 --> Model "BlogModel" initialized
INFO - 2021-09-24 13:46:38 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:46:38 --> Model "CookieModel" initialized
INFO - 2021-09-24 13:46:38 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 13:46:38 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/blog.php
INFO - 2021-09-24 13:46:38 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 13:46:38 --> Final output sent to browser
DEBUG - 2021-09-24 13:46:38 --> Total execution time: 0.0829
INFO - 2021-09-24 13:49:09 --> Config Class Initialized
INFO - 2021-09-24 13:49:09 --> Hooks Class Initialized
DEBUG - 2021-09-24 13:49:09 --> UTF-8 Support Enabled
INFO - 2021-09-24 13:49:09 --> Utf8 Class Initialized
INFO - 2021-09-24 13:49:09 --> URI Class Initialized
INFO - 2021-09-24 13:49:09 --> Router Class Initialized
INFO - 2021-09-24 13:49:09 --> Output Class Initialized
INFO - 2021-09-24 13:49:09 --> Security Class Initialized
DEBUG - 2021-09-24 13:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 13:49:09 --> Input Class Initialized
INFO - 2021-09-24 13:49:09 --> Language Class Initialized
INFO - 2021-09-24 13:49:09 --> Loader Class Initialized
INFO - 2021-09-24 13:49:09 --> Helper loaded: url_helper
INFO - 2021-09-24 13:49:09 --> Helper loaded: file_helper
DEBUG - 2021-09-24 13:49:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 13:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 13:49:09 --> Controller Class Initialized
INFO - 2021-09-24 13:49:09 --> Database Driver Class Initialized
INFO - 2021-09-24 13:49:09 --> Model "BlogModel" initialized
INFO - 2021-09-24 13:49:09 --> Helper loaded: cookie_helper
INFO - 2021-09-24 13:49:09 --> Model "CookieModel" initialized
INFO - 2021-09-24 13:49:09 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/header.php
INFO - 2021-09-24 13:49:09 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\user/blog.php
INFO - 2021-09-24 13:49:09 --> File loaded: F:\xampp\htdocs\igapprojects\changeme\application\views\layout/footer.php
INFO - 2021-09-24 13:49:09 --> Final output sent to browser
DEBUG - 2021-09-24 13:49:09 --> Total execution time: 0.0711
INFO - 2021-09-24 15:18:33 --> Config Class Initialized
INFO - 2021-09-24 15:18:33 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:18:33 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:18:33 --> Utf8 Class Initialized
INFO - 2021-09-24 15:18:33 --> URI Class Initialized
DEBUG - 2021-09-24 15:18:33 --> No URI present. Default controller set.
INFO - 2021-09-24 15:18:33 --> Router Class Initialized
INFO - 2021-09-24 15:18:33 --> Output Class Initialized
INFO - 2021-09-24 15:18:33 --> Security Class Initialized
DEBUG - 2021-09-24 15:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:18:33 --> Input Class Initialized
INFO - 2021-09-24 15:18:33 --> Language Class Initialized
INFO - 2021-09-24 15:18:33 --> Loader Class Initialized
INFO - 2021-09-24 15:18:33 --> Helper loaded: url_helper
INFO - 2021-09-24 15:18:33 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:18:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:18:33 --> Controller Class Initialized
INFO - 2021-09-24 15:18:33 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:18:33 --> Model "CookieModel" initialized
INFO - 2021-09-24 15:18:33 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 15:18:33 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-09-24 15:18:33 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 15:18:33 --> Final output sent to browser
DEBUG - 2021-09-24 15:18:33 --> Total execution time: 0.0618
INFO - 2021-09-24 15:18:47 --> Config Class Initialized
INFO - 2021-09-24 15:18:47 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:18:47 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:18:47 --> Utf8 Class Initialized
INFO - 2021-09-24 15:18:47 --> URI Class Initialized
INFO - 2021-09-24 15:18:47 --> Router Class Initialized
INFO - 2021-09-24 15:18:47 --> Output Class Initialized
INFO - 2021-09-24 15:18:47 --> Security Class Initialized
DEBUG - 2021-09-24 15:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:18:47 --> Input Class Initialized
INFO - 2021-09-24 15:18:47 --> Language Class Initialized
INFO - 2021-09-24 15:18:47 --> Loader Class Initialized
INFO - 2021-09-24 15:18:47 --> Helper loaded: url_helper
INFO - 2021-09-24 15:18:47 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:18:47 --> Controller Class Initialized
INFO - 2021-09-24 15:18:47 --> Database Driver Class Initialized
INFO - 2021-09-24 15:18:47 --> Helper loaded: string_helper
INFO - 2021-09-24 15:18:47 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:18:47 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:18:47 --> Model "CookieModel" initialized
INFO - 2021-09-24 15:18:47 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 15:18:47 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/videotestimonials.php
INFO - 2021-09-24 15:18:47 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 15:18:47 --> Final output sent to browser
DEBUG - 2021-09-24 15:18:47 --> Total execution time: 0.1342
INFO - 2021-09-24 15:18:54 --> Config Class Initialized
INFO - 2021-09-24 15:18:54 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:18:54 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:18:54 --> Utf8 Class Initialized
INFO - 2021-09-24 15:18:54 --> URI Class Initialized
INFO - 2021-09-24 15:18:54 --> Router Class Initialized
INFO - 2021-09-24 15:18:54 --> Output Class Initialized
INFO - 2021-09-24 15:18:54 --> Security Class Initialized
DEBUG - 2021-09-24 15:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:18:54 --> Input Class Initialized
INFO - 2021-09-24 15:18:54 --> Language Class Initialized
INFO - 2021-09-24 15:18:54 --> Loader Class Initialized
INFO - 2021-09-24 15:18:54 --> Helper loaded: url_helper
INFO - 2021-09-24 15:18:54 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:18:54 --> Controller Class Initialized
INFO - 2021-09-24 15:18:54 --> Database Driver Class Initialized
INFO - 2021-09-24 15:18:54 --> Helper loaded: string_helper
INFO - 2021-09-24 15:18:54 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:18:54 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:18:54 --> Model "CookieModel" initialized
INFO - 2021-09-24 15:18:54 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 15:18:54 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/testimonials.php
INFO - 2021-09-24 15:18:54 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 15:18:54 --> Final output sent to browser
DEBUG - 2021-09-24 15:18:54 --> Total execution time: 0.0715
INFO - 2021-09-24 15:19:47 --> Config Class Initialized
INFO - 2021-09-24 15:19:47 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:19:47 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:19:47 --> Utf8 Class Initialized
INFO - 2021-09-24 15:19:47 --> URI Class Initialized
INFO - 2021-09-24 15:19:47 --> Router Class Initialized
INFO - 2021-09-24 15:19:47 --> Output Class Initialized
INFO - 2021-09-24 15:19:47 --> Security Class Initialized
DEBUG - 2021-09-24 15:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:19:47 --> Input Class Initialized
INFO - 2021-09-24 15:19:47 --> Language Class Initialized
INFO - 2021-09-24 15:19:47 --> Loader Class Initialized
INFO - 2021-09-24 15:19:47 --> Helper loaded: url_helper
INFO - 2021-09-24 15:19:47 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:19:47 --> Controller Class Initialized
DEBUG - 2021-09-24 15:19:47 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:19:47 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:19:47 --> File loaded: E:\xampp\htdocs\changeme\application\views\login.php
INFO - 2021-09-24 15:19:47 --> Final output sent to browser
DEBUG - 2021-09-24 15:19:47 --> Total execution time: 0.0408
INFO - 2021-09-24 15:23:36 --> Config Class Initialized
INFO - 2021-09-24 15:23:36 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:23:36 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:23:36 --> Utf8 Class Initialized
INFO - 2021-09-24 15:23:36 --> URI Class Initialized
INFO - 2021-09-24 15:23:36 --> Router Class Initialized
INFO - 2021-09-24 15:23:36 --> Output Class Initialized
INFO - 2021-09-24 15:23:36 --> Security Class Initialized
DEBUG - 2021-09-24 15:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:23:36 --> Input Class Initialized
INFO - 2021-09-24 15:23:36 --> Language Class Initialized
INFO - 2021-09-24 15:23:36 --> Loader Class Initialized
INFO - 2021-09-24 15:23:36 --> Helper loaded: url_helper
INFO - 2021-09-24 15:23:36 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:23:36 --> Controller Class Initialized
DEBUG - 2021-09-24 15:23:36 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:23:36 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:23:36 --> File loaded: E:\xampp\htdocs\changeme\application\views\login.php
INFO - 2021-09-24 15:23:36 --> Final output sent to browser
DEBUG - 2021-09-24 15:23:36 --> Total execution time: 0.0297
INFO - 2021-09-24 15:23:54 --> Config Class Initialized
INFO - 2021-09-24 15:23:54 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:23:54 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:23:54 --> Utf8 Class Initialized
INFO - 2021-09-24 15:23:54 --> URI Class Initialized
INFO - 2021-09-24 15:23:54 --> Router Class Initialized
INFO - 2021-09-24 15:23:54 --> Output Class Initialized
INFO - 2021-09-24 15:23:54 --> Security Class Initialized
DEBUG - 2021-09-24 15:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:23:54 --> Input Class Initialized
INFO - 2021-09-24 15:23:54 --> Language Class Initialized
INFO - 2021-09-24 15:23:54 --> Loader Class Initialized
INFO - 2021-09-24 15:23:54 --> Helper loaded: url_helper
INFO - 2021-09-24 15:23:54 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:23:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:23:54 --> Controller Class Initialized
INFO - 2021-09-24 15:23:54 --> Database Driver Class Initialized
INFO - 2021-09-24 15:23:54 --> Helper loaded: string_helper
INFO - 2021-09-24 15:23:54 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:23:54 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:23:54 --> Model "CookieModel" initialized
INFO - 2021-09-24 15:23:54 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 15:23:54 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/testimonials.php
INFO - 2021-09-24 15:23:54 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 15:23:54 --> Final output sent to browser
DEBUG - 2021-09-24 15:23:54 --> Total execution time: 0.0472
INFO - 2021-09-24 15:25:06 --> Config Class Initialized
INFO - 2021-09-24 15:25:06 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:25:06 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:25:06 --> Utf8 Class Initialized
INFO - 2021-09-24 15:25:06 --> URI Class Initialized
INFO - 2021-09-24 15:25:06 --> Router Class Initialized
INFO - 2021-09-24 15:25:06 --> Output Class Initialized
INFO - 2021-09-24 15:25:06 --> Security Class Initialized
DEBUG - 2021-09-24 15:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:25:06 --> Input Class Initialized
INFO - 2021-09-24 15:25:06 --> Language Class Initialized
INFO - 2021-09-24 15:25:06 --> Loader Class Initialized
INFO - 2021-09-24 15:25:06 --> Helper loaded: url_helper
INFO - 2021-09-24 15:25:06 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:25:06 --> Controller Class Initialized
DEBUG - 2021-09-24 15:25:06 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:25:06 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:25:06 --> File loaded: E:\xampp\htdocs\changeme\application\views\login.php
INFO - 2021-09-24 15:25:06 --> Final output sent to browser
DEBUG - 2021-09-24 15:25:06 --> Total execution time: 0.0448
INFO - 2021-09-24 15:25:08 --> Config Class Initialized
INFO - 2021-09-24 15:25:08 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:25:08 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:25:08 --> Utf8 Class Initialized
INFO - 2021-09-24 15:25:08 --> URI Class Initialized
INFO - 2021-09-24 15:25:08 --> Router Class Initialized
INFO - 2021-09-24 15:25:08 --> Output Class Initialized
INFO - 2021-09-24 15:25:08 --> Security Class Initialized
DEBUG - 2021-09-24 15:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:25:08 --> Input Class Initialized
INFO - 2021-09-24 15:25:08 --> Language Class Initialized
INFO - 2021-09-24 15:25:08 --> Loader Class Initialized
INFO - 2021-09-24 15:25:08 --> Helper loaded: url_helper
INFO - 2021-09-24 15:25:08 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:25:08 --> Controller Class Initialized
DEBUG - 2021-09-24 15:25:08 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:25:08 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:25:08 --> File loaded: E:\xampp\htdocs\changeme\application\views\login.php
INFO - 2021-09-24 15:25:08 --> Final output sent to browser
DEBUG - 2021-09-24 15:25:08 --> Total execution time: 0.0314
INFO - 2021-09-24 15:25:19 --> Config Class Initialized
INFO - 2021-09-24 15:25:19 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:25:19 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:25:19 --> Utf8 Class Initialized
INFO - 2021-09-24 15:25:19 --> URI Class Initialized
INFO - 2021-09-24 15:25:19 --> Router Class Initialized
INFO - 2021-09-24 15:25:19 --> Output Class Initialized
INFO - 2021-09-24 15:25:19 --> Security Class Initialized
DEBUG - 2021-09-24 15:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:25:19 --> Input Class Initialized
INFO - 2021-09-24 15:25:19 --> Language Class Initialized
INFO - 2021-09-24 15:25:19 --> Loader Class Initialized
INFO - 2021-09-24 15:25:19 --> Helper loaded: url_helper
INFO - 2021-09-24 15:25:19 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:25:19 --> Controller Class Initialized
INFO - 2021-09-24 15:25:19 --> Database Driver Class Initialized
INFO - 2021-09-24 15:25:19 --> Helper loaded: string_helper
INFO - 2021-09-24 15:25:19 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:25:19 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:25:19 --> Model "CookieModel" initialized
INFO - 2021-09-24 15:25:19 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 15:25:19 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/testimonials.php
INFO - 2021-09-24 15:25:19 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 15:25:19 --> Final output sent to browser
DEBUG - 2021-09-24 15:25:19 --> Total execution time: 0.0483
INFO - 2021-09-24 15:25:37 --> Config Class Initialized
INFO - 2021-09-24 15:25:37 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:25:37 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:25:37 --> Utf8 Class Initialized
INFO - 2021-09-24 15:25:37 --> URI Class Initialized
INFO - 2021-09-24 15:25:37 --> Router Class Initialized
INFO - 2021-09-24 15:25:37 --> Output Class Initialized
INFO - 2021-09-24 15:25:37 --> Security Class Initialized
DEBUG - 2021-09-24 15:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:25:37 --> Input Class Initialized
INFO - 2021-09-24 15:25:37 --> Language Class Initialized
INFO - 2021-09-24 15:25:37 --> Loader Class Initialized
INFO - 2021-09-24 15:25:37 --> Helper loaded: url_helper
INFO - 2021-09-24 15:25:37 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:25:37 --> Controller Class Initialized
DEBUG - 2021-09-24 15:25:37 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:25:37 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:25:37 --> File loaded: E:\xampp\htdocs\changeme\application\views\login.php
INFO - 2021-09-24 15:25:37 --> Final output sent to browser
DEBUG - 2021-09-24 15:25:37 --> Total execution time: 0.0320
INFO - 2021-09-24 15:34:19 --> Config Class Initialized
INFO - 2021-09-24 15:34:19 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:34:19 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:34:19 --> Utf8 Class Initialized
INFO - 2021-09-24 15:34:19 --> URI Class Initialized
INFO - 2021-09-24 15:34:19 --> Router Class Initialized
INFO - 2021-09-24 15:34:19 --> Output Class Initialized
INFO - 2021-09-24 15:34:19 --> Security Class Initialized
DEBUG - 2021-09-24 15:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:34:19 --> Input Class Initialized
INFO - 2021-09-24 15:34:19 --> Language Class Initialized
INFO - 2021-09-24 15:34:19 --> Loader Class Initialized
INFO - 2021-09-24 15:34:19 --> Helper loaded: url_helper
INFO - 2021-09-24 15:34:19 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:34:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:34:19 --> Controller Class Initialized
DEBUG - 2021-09-24 15:34:19 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:34:19 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:34:19 --> Config Class Initialized
INFO - 2021-09-24 15:34:19 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:34:19 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:34:19 --> Utf8 Class Initialized
INFO - 2021-09-24 15:34:19 --> URI Class Initialized
INFO - 2021-09-24 15:34:19 --> Router Class Initialized
INFO - 2021-09-24 15:34:19 --> Output Class Initialized
INFO - 2021-09-24 15:34:19 --> Security Class Initialized
DEBUG - 2021-09-24 15:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:34:19 --> Input Class Initialized
INFO - 2021-09-24 15:34:19 --> Language Class Initialized
INFO - 2021-09-24 15:34:19 --> Loader Class Initialized
INFO - 2021-09-24 15:34:19 --> Helper loaded: url_helper
INFO - 2021-09-24 15:34:19 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:34:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:34:19 --> Controller Class Initialized
INFO - 2021-09-24 15:34:19 --> Model "DBModel" initialized
DEBUG - 2021-09-24 15:34:19 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:34:19 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:34:19 --> Database Driver Class Initialized
INFO - 2021-09-24 15:34:19 --> Helper loaded: string_helper
INFO - 2021-09-24 15:34:19 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:34:19 --> Model "BlogModel" initialized
INFO - 2021-09-24 15:34:19 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 15:34:19 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 15:34:19 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 15:34:19 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/dashboard.php
INFO - 2021-09-24 15:34:19 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 15:34:19 --> Final output sent to browser
DEBUG - 2021-09-24 15:34:19 --> Total execution time: 0.0485
INFO - 2021-09-24 15:34:59 --> Config Class Initialized
INFO - 2021-09-24 15:34:59 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:34:59 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:34:59 --> Utf8 Class Initialized
INFO - 2021-09-24 15:34:59 --> URI Class Initialized
INFO - 2021-09-24 15:34:59 --> Router Class Initialized
INFO - 2021-09-24 15:34:59 --> Output Class Initialized
INFO - 2021-09-24 15:34:59 --> Security Class Initialized
DEBUG - 2021-09-24 15:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:34:59 --> Input Class Initialized
INFO - 2021-09-24 15:34:59 --> Language Class Initialized
INFO - 2021-09-24 15:34:59 --> Loader Class Initialized
INFO - 2021-09-24 15:34:59 --> Helper loaded: url_helper
INFO - 2021-09-24 15:34:59 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:34:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:34:59 --> Controller Class Initialized
INFO - 2021-09-24 15:34:59 --> Model "DBModel" initialized
DEBUG - 2021-09-24 15:34:59 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:34:59 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:34:59 --> Database Driver Class Initialized
INFO - 2021-09-24 15:34:59 --> Helper loaded: string_helper
INFO - 2021-09-24 15:34:59 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:34:59 --> Model "BlogModel" initialized
INFO - 2021-09-24 15:34:59 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 15:34:59 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 15:34:59 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 15:34:59 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/dashboard.php
INFO - 2021-09-24 15:34:59 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 15:34:59 --> Final output sent to browser
DEBUG - 2021-09-24 15:34:59 --> Total execution time: 0.0522
INFO - 2021-09-24 15:35:03 --> Config Class Initialized
INFO - 2021-09-24 15:35:03 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:35:03 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:35:03 --> Utf8 Class Initialized
INFO - 2021-09-24 15:35:03 --> URI Class Initialized
INFO - 2021-09-24 15:35:03 --> Router Class Initialized
INFO - 2021-09-24 15:35:03 --> Output Class Initialized
INFO - 2021-09-24 15:35:03 --> Security Class Initialized
DEBUG - 2021-09-24 15:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:35:03 --> Input Class Initialized
INFO - 2021-09-24 15:35:03 --> Language Class Initialized
INFO - 2021-09-24 15:35:03 --> Loader Class Initialized
INFO - 2021-09-24 15:35:03 --> Helper loaded: url_helper
INFO - 2021-09-24 15:35:03 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:35:03 --> Controller Class Initialized
INFO - 2021-09-24 15:35:03 --> Model "DBModel" initialized
DEBUG - 2021-09-24 15:35:03 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:35:03 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:35:03 --> Database Driver Class Initialized
INFO - 2021-09-24 15:35:03 --> Helper loaded: string_helper
INFO - 2021-09-24 15:35:03 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:35:03 --> Model "BlogModel" initialized
INFO - 2021-09-24 15:35:03 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 15:35:03 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 15:35:03 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 15:35:03 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonials.php
INFO - 2021-09-24 15:35:03 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 15:35:03 --> Final output sent to browser
DEBUG - 2021-09-24 15:35:03 --> Total execution time: 0.0480
INFO - 2021-09-24 15:35:04 --> Config Class Initialized
INFO - 2021-09-24 15:35:04 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:35:04 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:35:04 --> Utf8 Class Initialized
INFO - 2021-09-24 15:35:04 --> URI Class Initialized
INFO - 2021-09-24 15:35:04 --> Router Class Initialized
INFO - 2021-09-24 15:35:04 --> Output Class Initialized
INFO - 2021-09-24 15:35:04 --> Security Class Initialized
DEBUG - 2021-09-24 15:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:35:04 --> Input Class Initialized
INFO - 2021-09-24 15:35:04 --> Language Class Initialized
INFO - 2021-09-24 15:35:04 --> Loader Class Initialized
INFO - 2021-09-24 15:35:04 --> Helper loaded: url_helper
INFO - 2021-09-24 15:35:04 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:35:04 --> Controller Class Initialized
INFO - 2021-09-24 15:35:04 --> Model "DBModel" initialized
DEBUG - 2021-09-24 15:35:04 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:35:04 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:35:04 --> Database Driver Class Initialized
INFO - 2021-09-24 15:35:04 --> Helper loaded: string_helper
INFO - 2021-09-24 15:35:04 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:35:04 --> Model "BlogModel" initialized
INFO - 2021-09-24 15:35:04 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 15:35:04 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 15:35:04 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 15:35:04 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/blogs.php
INFO - 2021-09-24 15:35:04 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 15:35:04 --> Final output sent to browser
DEBUG - 2021-09-24 15:35:04 --> Total execution time: 0.0464
INFO - 2021-09-24 15:35:05 --> Config Class Initialized
INFO - 2021-09-24 15:35:05 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:35:05 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:35:05 --> Utf8 Class Initialized
INFO - 2021-09-24 15:35:05 --> URI Class Initialized
INFO - 2021-09-24 15:35:05 --> Router Class Initialized
INFO - 2021-09-24 15:35:05 --> Output Class Initialized
INFO - 2021-09-24 15:35:05 --> Security Class Initialized
DEBUG - 2021-09-24 15:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:35:05 --> Input Class Initialized
INFO - 2021-09-24 15:35:05 --> Language Class Initialized
INFO - 2021-09-24 15:35:05 --> Loader Class Initialized
INFO - 2021-09-24 15:35:05 --> Helper loaded: url_helper
INFO - 2021-09-24 15:35:05 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:35:05 --> Controller Class Initialized
INFO - 2021-09-24 15:35:05 --> Model "DBModel" initialized
DEBUG - 2021-09-24 15:35:05 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:35:05 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:35:05 --> Database Driver Class Initialized
INFO - 2021-09-24 15:35:05 --> Helper loaded: string_helper
INFO - 2021-09-24 15:35:05 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:35:05 --> Model "BlogModel" initialized
INFO - 2021-09-24 15:35:05 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 15:35:05 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 15:35:05 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 15:35:05 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonials.php
INFO - 2021-09-24 15:35:05 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 15:35:05 --> Final output sent to browser
DEBUG - 2021-09-24 15:35:05 --> Total execution time: 0.0432
INFO - 2021-09-24 15:35:05 --> Config Class Initialized
INFO - 2021-09-24 15:35:05 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:35:05 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:35:05 --> Utf8 Class Initialized
INFO - 2021-09-24 15:35:05 --> URI Class Initialized
INFO - 2021-09-24 15:35:05 --> Router Class Initialized
INFO - 2021-09-24 15:35:05 --> Output Class Initialized
INFO - 2021-09-24 15:35:05 --> Security Class Initialized
DEBUG - 2021-09-24 15:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:35:05 --> Input Class Initialized
INFO - 2021-09-24 15:35:05 --> Language Class Initialized
INFO - 2021-09-24 15:35:05 --> Loader Class Initialized
INFO - 2021-09-24 15:35:05 --> Helper loaded: url_helper
INFO - 2021-09-24 15:35:05 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:35:05 --> Controller Class Initialized
INFO - 2021-09-24 15:35:05 --> Model "DBModel" initialized
DEBUG - 2021-09-24 15:35:05 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:35:05 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:35:05 --> Database Driver Class Initialized
INFO - 2021-09-24 15:35:05 --> Helper loaded: string_helper
INFO - 2021-09-24 15:35:05 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:35:05 --> Model "BlogModel" initialized
INFO - 2021-09-24 15:35:05 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 15:35:05 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 15:35:05 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 15:35:05 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/blogs.php
INFO - 2021-09-24 15:35:05 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 15:35:05 --> Final output sent to browser
DEBUG - 2021-09-24 15:35:05 --> Total execution time: 0.0440
INFO - 2021-09-24 15:35:06 --> Config Class Initialized
INFO - 2021-09-24 15:35:06 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:35:06 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:35:06 --> Utf8 Class Initialized
INFO - 2021-09-24 15:35:06 --> URI Class Initialized
INFO - 2021-09-24 15:35:06 --> Router Class Initialized
INFO - 2021-09-24 15:35:06 --> Output Class Initialized
INFO - 2021-09-24 15:35:06 --> Security Class Initialized
DEBUG - 2021-09-24 15:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:35:06 --> Input Class Initialized
INFO - 2021-09-24 15:35:06 --> Language Class Initialized
INFO - 2021-09-24 15:35:06 --> Loader Class Initialized
INFO - 2021-09-24 15:35:06 --> Helper loaded: url_helper
INFO - 2021-09-24 15:35:06 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:35:06 --> Controller Class Initialized
INFO - 2021-09-24 15:35:06 --> Model "DBModel" initialized
DEBUG - 2021-09-24 15:35:06 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:35:06 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:35:06 --> Database Driver Class Initialized
INFO - 2021-09-24 15:35:06 --> Helper loaded: string_helper
INFO - 2021-09-24 15:35:06 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:35:06 --> Model "BlogModel" initialized
INFO - 2021-09-24 15:35:06 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 15:35:06 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 15:35:06 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 15:35:06 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonials.php
INFO - 2021-09-24 15:35:06 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 15:35:06 --> Final output sent to browser
DEBUG - 2021-09-24 15:35:06 --> Total execution time: 0.0460
INFO - 2021-09-24 15:36:24 --> Config Class Initialized
INFO - 2021-09-24 15:36:24 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:36:24 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:36:24 --> Utf8 Class Initialized
INFO - 2021-09-24 15:36:24 --> URI Class Initialized
INFO - 2021-09-24 15:36:24 --> Router Class Initialized
INFO - 2021-09-24 15:36:24 --> Output Class Initialized
INFO - 2021-09-24 15:36:24 --> Security Class Initialized
DEBUG - 2021-09-24 15:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:36:24 --> Input Class Initialized
INFO - 2021-09-24 15:36:24 --> Language Class Initialized
INFO - 2021-09-24 15:36:24 --> Loader Class Initialized
INFO - 2021-09-24 15:36:24 --> Helper loaded: url_helper
INFO - 2021-09-24 15:36:24 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:36:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:36:24 --> Controller Class Initialized
INFO - 2021-09-24 15:36:24 --> Model "DBModel" initialized
DEBUG - 2021-09-24 15:36:24 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:36:24 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:36:24 --> Database Driver Class Initialized
INFO - 2021-09-24 15:36:24 --> Helper loaded: string_helper
INFO - 2021-09-24 15:36:24 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:36:24 --> Model "BlogModel" initialized
INFO - 2021-09-24 15:36:24 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 15:36:24 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 15:36:24 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 15:36:24 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonials.php
INFO - 2021-09-24 15:36:24 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 15:36:24 --> Final output sent to browser
DEBUG - 2021-09-24 15:36:24 --> Total execution time: 0.0430
INFO - 2021-09-24 15:37:01 --> Config Class Initialized
INFO - 2021-09-24 15:37:01 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:37:01 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:37:01 --> Utf8 Class Initialized
INFO - 2021-09-24 15:37:01 --> URI Class Initialized
INFO - 2021-09-24 15:37:01 --> Router Class Initialized
INFO - 2021-09-24 15:37:01 --> Output Class Initialized
INFO - 2021-09-24 15:37:01 --> Security Class Initialized
DEBUG - 2021-09-24 15:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:37:01 --> Input Class Initialized
INFO - 2021-09-24 15:37:01 --> Language Class Initialized
INFO - 2021-09-24 15:37:01 --> Loader Class Initialized
INFO - 2021-09-24 15:37:01 --> Helper loaded: url_helper
INFO - 2021-09-24 15:37:01 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:37:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:37:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:37:01 --> Controller Class Initialized
INFO - 2021-09-24 15:37:01 --> Model "DBModel" initialized
DEBUG - 2021-09-24 15:37:01 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:37:01 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:37:01 --> Database Driver Class Initialized
INFO - 2021-09-24 15:37:01 --> Helper loaded: string_helper
INFO - 2021-09-24 15:37:01 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:37:01 --> Model "BlogModel" initialized
INFO - 2021-09-24 15:37:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 15:37:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 15:37:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 15:37:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonials.php
INFO - 2021-09-24 15:37:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 15:37:01 --> Final output sent to browser
DEBUG - 2021-09-24 15:37:01 --> Total execution time: 0.0551
INFO - 2021-09-24 15:37:04 --> Config Class Initialized
INFO - 2021-09-24 15:37:04 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:37:04 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:37:04 --> Utf8 Class Initialized
INFO - 2021-09-24 15:37:04 --> URI Class Initialized
INFO - 2021-09-24 15:37:04 --> Router Class Initialized
INFO - 2021-09-24 15:37:04 --> Output Class Initialized
INFO - 2021-09-24 15:37:04 --> Security Class Initialized
DEBUG - 2021-09-24 15:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:37:04 --> Input Class Initialized
INFO - 2021-09-24 15:37:04 --> Language Class Initialized
INFO - 2021-09-24 15:37:04 --> Loader Class Initialized
INFO - 2021-09-24 15:37:04 --> Helper loaded: url_helper
INFO - 2021-09-24 15:37:04 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:37:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:37:04 --> Controller Class Initialized
INFO - 2021-09-24 15:37:04 --> Model "DBModel" initialized
DEBUG - 2021-09-24 15:37:04 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:37:04 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:37:04 --> Database Driver Class Initialized
INFO - 2021-09-24 15:37:04 --> Helper loaded: string_helper
INFO - 2021-09-24 15:37:04 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:37:04 --> Model "BlogModel" initialized
INFO - 2021-09-24 15:37:04 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 15:37:04 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 15:37:04 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 15:37:04 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonials.php
INFO - 2021-09-24 15:37:04 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 15:37:04 --> Final output sent to browser
DEBUG - 2021-09-24 15:37:04 --> Total execution time: 0.0447
INFO - 2021-09-24 15:38:15 --> Config Class Initialized
INFO - 2021-09-24 15:38:15 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:38:15 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:38:15 --> Utf8 Class Initialized
INFO - 2021-09-24 15:38:15 --> URI Class Initialized
INFO - 2021-09-24 15:38:15 --> Router Class Initialized
INFO - 2021-09-24 15:38:15 --> Output Class Initialized
INFO - 2021-09-24 15:38:15 --> Security Class Initialized
DEBUG - 2021-09-24 15:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:38:15 --> Input Class Initialized
INFO - 2021-09-24 15:38:15 --> Language Class Initialized
INFO - 2021-09-24 15:38:15 --> Loader Class Initialized
INFO - 2021-09-24 15:38:15 --> Helper loaded: url_helper
INFO - 2021-09-24 15:38:15 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:38:15 --> Controller Class Initialized
INFO - 2021-09-24 15:38:15 --> Model "DBModel" initialized
DEBUG - 2021-09-24 15:38:15 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:38:15 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:38:15 --> Database Driver Class Initialized
INFO - 2021-09-24 15:38:15 --> Helper loaded: string_helper
INFO - 2021-09-24 15:38:15 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:38:15 --> Model "BlogModel" initialized
INFO - 2021-09-24 15:38:15 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 15:38:15 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 15:38:15 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 15:38:15 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonials.php
INFO - 2021-09-24 15:38:15 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 15:38:15 --> Final output sent to browser
DEBUG - 2021-09-24 15:38:15 --> Total execution time: 0.0497
INFO - 2021-09-24 15:38:23 --> Config Class Initialized
INFO - 2021-09-24 15:38:23 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:38:23 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:38:23 --> Utf8 Class Initialized
INFO - 2021-09-24 15:38:23 --> URI Class Initialized
INFO - 2021-09-24 15:38:23 --> Router Class Initialized
INFO - 2021-09-24 15:38:23 --> Output Class Initialized
INFO - 2021-09-24 15:38:23 --> Security Class Initialized
DEBUG - 2021-09-24 15:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:38:23 --> Input Class Initialized
INFO - 2021-09-24 15:38:23 --> Language Class Initialized
INFO - 2021-09-24 15:38:23 --> Loader Class Initialized
INFO - 2021-09-24 15:38:23 --> Helper loaded: url_helper
INFO - 2021-09-24 15:38:23 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:38:23 --> Controller Class Initialized
INFO - 2021-09-24 15:38:23 --> Model "DBModel" initialized
DEBUG - 2021-09-24 15:38:23 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:38:23 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:38:23 --> Database Driver Class Initialized
INFO - 2021-09-24 15:38:23 --> Helper loaded: string_helper
INFO - 2021-09-24 15:38:23 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:38:23 --> Model "BlogModel" initialized
INFO - 2021-09-24 15:38:23 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 15:38:23 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 15:38:23 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 15:38:23 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonials.php
INFO - 2021-09-24 15:38:23 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 15:38:23 --> Final output sent to browser
DEBUG - 2021-09-24 15:38:23 --> Total execution time: 0.0530
INFO - 2021-09-24 15:38:24 --> Config Class Initialized
INFO - 2021-09-24 15:38:24 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:38:24 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:38:24 --> Utf8 Class Initialized
INFO - 2021-09-24 15:38:24 --> URI Class Initialized
INFO - 2021-09-24 15:38:24 --> Router Class Initialized
INFO - 2021-09-24 15:38:24 --> Output Class Initialized
INFO - 2021-09-24 15:38:24 --> Security Class Initialized
DEBUG - 2021-09-24 15:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:38:24 --> Input Class Initialized
INFO - 2021-09-24 15:38:24 --> Language Class Initialized
INFO - 2021-09-24 15:38:24 --> Loader Class Initialized
INFO - 2021-09-24 15:38:24 --> Helper loaded: url_helper
INFO - 2021-09-24 15:38:24 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:38:24 --> Controller Class Initialized
INFO - 2021-09-24 15:38:24 --> Model "DBModel" initialized
DEBUG - 2021-09-24 15:38:24 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:38:24 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:38:24 --> Database Driver Class Initialized
INFO - 2021-09-24 15:38:24 --> Helper loaded: string_helper
INFO - 2021-09-24 15:38:24 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:38:24 --> Model "BlogModel" initialized
INFO - 2021-09-24 15:38:24 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 15:38:24 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 15:38:24 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 15:38:24 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/dashboard.php
INFO - 2021-09-24 15:38:24 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 15:38:24 --> Final output sent to browser
DEBUG - 2021-09-24 15:38:24 --> Total execution time: 0.0420
INFO - 2021-09-24 15:38:25 --> Config Class Initialized
INFO - 2021-09-24 15:38:25 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:38:25 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:38:25 --> Utf8 Class Initialized
INFO - 2021-09-24 15:38:25 --> URI Class Initialized
INFO - 2021-09-24 15:38:25 --> Router Class Initialized
INFO - 2021-09-24 15:38:25 --> Output Class Initialized
INFO - 2021-09-24 15:38:25 --> Security Class Initialized
DEBUG - 2021-09-24 15:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:38:25 --> Input Class Initialized
INFO - 2021-09-24 15:38:25 --> Language Class Initialized
INFO - 2021-09-24 15:38:25 --> Loader Class Initialized
INFO - 2021-09-24 15:38:25 --> Helper loaded: url_helper
INFO - 2021-09-24 15:38:25 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:38:25 --> Controller Class Initialized
INFO - 2021-09-24 15:38:25 --> Model "DBModel" initialized
DEBUG - 2021-09-24 15:38:25 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:38:25 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:38:25 --> Database Driver Class Initialized
INFO - 2021-09-24 15:38:25 --> Helper loaded: string_helper
INFO - 2021-09-24 15:38:25 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:38:25 --> Model "BlogModel" initialized
INFO - 2021-09-24 15:38:25 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 15:38:25 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 15:38:25 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 15:38:25 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonials.php
INFO - 2021-09-24 15:38:25 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 15:38:25 --> Final output sent to browser
DEBUG - 2021-09-24 15:38:25 --> Total execution time: 0.0477
INFO - 2021-09-24 15:38:27 --> Config Class Initialized
INFO - 2021-09-24 15:38:27 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:38:27 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:38:27 --> Utf8 Class Initialized
INFO - 2021-09-24 15:38:27 --> URI Class Initialized
INFO - 2021-09-24 15:38:27 --> Router Class Initialized
INFO - 2021-09-24 15:38:27 --> Output Class Initialized
INFO - 2021-09-24 15:38:27 --> Security Class Initialized
DEBUG - 2021-09-24 15:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:38:27 --> Input Class Initialized
INFO - 2021-09-24 15:38:27 --> Language Class Initialized
INFO - 2021-09-24 15:38:27 --> Loader Class Initialized
INFO - 2021-09-24 15:38:27 --> Helper loaded: url_helper
INFO - 2021-09-24 15:38:27 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:38:27 --> Controller Class Initialized
INFO - 2021-09-24 15:38:27 --> Model "DBModel" initialized
DEBUG - 2021-09-24 15:38:27 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:38:27 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:38:27 --> Database Driver Class Initialized
INFO - 2021-09-24 15:38:27 --> Helper loaded: string_helper
INFO - 2021-09-24 15:38:27 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:38:27 --> Model "BlogModel" initialized
INFO - 2021-09-24 15:38:27 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 15:38:27 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 15:38:27 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 15:38:27 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/blogs.php
INFO - 2021-09-24 15:38:27 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 15:38:27 --> Final output sent to browser
DEBUG - 2021-09-24 15:38:27 --> Total execution time: 0.0503
INFO - 2021-09-24 15:38:29 --> Config Class Initialized
INFO - 2021-09-24 15:38:29 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:38:29 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:38:29 --> Utf8 Class Initialized
INFO - 2021-09-24 15:38:29 --> URI Class Initialized
INFO - 2021-09-24 15:38:29 --> Router Class Initialized
INFO - 2021-09-24 15:38:29 --> Output Class Initialized
INFO - 2021-09-24 15:38:29 --> Security Class Initialized
DEBUG - 2021-09-24 15:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:38:29 --> Input Class Initialized
INFO - 2021-09-24 15:38:29 --> Language Class Initialized
INFO - 2021-09-24 15:38:29 --> Loader Class Initialized
INFO - 2021-09-24 15:38:29 --> Helper loaded: url_helper
INFO - 2021-09-24 15:38:29 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:38:29 --> Controller Class Initialized
INFO - 2021-09-24 15:38:29 --> Model "DBModel" initialized
DEBUG - 2021-09-24 15:38:29 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:38:29 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:38:29 --> Database Driver Class Initialized
INFO - 2021-09-24 15:38:29 --> Helper loaded: string_helper
INFO - 2021-09-24 15:38:29 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:38:29 --> Model "BlogModel" initialized
INFO - 2021-09-24 15:38:29 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 15:38:29 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 15:38:29 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 15:38:29 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonials.php
INFO - 2021-09-24 15:38:29 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 15:38:29 --> Final output sent to browser
DEBUG - 2021-09-24 15:38:29 --> Total execution time: 0.0537
INFO - 2021-09-24 15:38:30 --> Config Class Initialized
INFO - 2021-09-24 15:38:30 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:38:30 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:38:30 --> Utf8 Class Initialized
INFO - 2021-09-24 15:38:30 --> URI Class Initialized
INFO - 2021-09-24 15:38:30 --> Router Class Initialized
INFO - 2021-09-24 15:38:30 --> Output Class Initialized
INFO - 2021-09-24 15:38:30 --> Security Class Initialized
DEBUG - 2021-09-24 15:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:38:30 --> Input Class Initialized
INFO - 2021-09-24 15:38:30 --> Language Class Initialized
INFO - 2021-09-24 15:38:30 --> Loader Class Initialized
INFO - 2021-09-24 15:38:30 --> Helper loaded: url_helper
INFO - 2021-09-24 15:38:30 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:38:30 --> Controller Class Initialized
INFO - 2021-09-24 15:38:30 --> Model "DBModel" initialized
DEBUG - 2021-09-24 15:38:30 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:38:30 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:38:30 --> Database Driver Class Initialized
INFO - 2021-09-24 15:38:30 --> Helper loaded: string_helper
INFO - 2021-09-24 15:38:30 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:38:30 --> Model "BlogModel" initialized
INFO - 2021-09-24 15:38:30 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 15:38:30 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 15:38:30 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 15:38:30 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/blogs.php
INFO - 2021-09-24 15:38:30 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 15:38:30 --> Final output sent to browser
DEBUG - 2021-09-24 15:38:30 --> Total execution time: 0.0440
INFO - 2021-09-24 15:38:31 --> Config Class Initialized
INFO - 2021-09-24 15:38:31 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:38:31 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:38:31 --> Utf8 Class Initialized
INFO - 2021-09-24 15:38:31 --> URI Class Initialized
INFO - 2021-09-24 15:38:31 --> Router Class Initialized
INFO - 2021-09-24 15:38:31 --> Output Class Initialized
INFO - 2021-09-24 15:38:31 --> Security Class Initialized
DEBUG - 2021-09-24 15:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:38:31 --> Input Class Initialized
INFO - 2021-09-24 15:38:31 --> Language Class Initialized
INFO - 2021-09-24 15:38:31 --> Loader Class Initialized
INFO - 2021-09-24 15:38:31 --> Helper loaded: url_helper
INFO - 2021-09-24 15:38:31 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:38:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:38:31 --> Controller Class Initialized
INFO - 2021-09-24 15:38:31 --> Model "DBModel" initialized
DEBUG - 2021-09-24 15:38:31 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:38:31 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:38:31 --> Database Driver Class Initialized
INFO - 2021-09-24 15:38:31 --> Helper loaded: string_helper
INFO - 2021-09-24 15:38:31 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:38:31 --> Model "BlogModel" initialized
INFO - 2021-09-24 15:38:31 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 15:38:31 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 15:38:31 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 15:38:31 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonials.php
INFO - 2021-09-24 15:38:31 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 15:38:31 --> Final output sent to browser
DEBUG - 2021-09-24 15:38:31 --> Total execution time: 0.0476
INFO - 2021-09-24 15:38:32 --> Config Class Initialized
INFO - 2021-09-24 15:38:32 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:38:32 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:38:32 --> Utf8 Class Initialized
INFO - 2021-09-24 15:38:32 --> URI Class Initialized
INFO - 2021-09-24 15:38:32 --> Router Class Initialized
INFO - 2021-09-24 15:38:32 --> Output Class Initialized
INFO - 2021-09-24 15:38:32 --> Security Class Initialized
DEBUG - 2021-09-24 15:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:38:32 --> Input Class Initialized
INFO - 2021-09-24 15:38:32 --> Language Class Initialized
INFO - 2021-09-24 15:38:32 --> Loader Class Initialized
INFO - 2021-09-24 15:38:32 --> Helper loaded: url_helper
INFO - 2021-09-24 15:38:32 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:38:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:38:32 --> Controller Class Initialized
INFO - 2021-09-24 15:38:32 --> Model "DBModel" initialized
DEBUG - 2021-09-24 15:38:32 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:38:32 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:38:32 --> Database Driver Class Initialized
INFO - 2021-09-24 15:38:32 --> Helper loaded: string_helper
INFO - 2021-09-24 15:38:32 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:38:32 --> Model "BlogModel" initialized
INFO - 2021-09-24 15:38:32 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 15:38:32 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 15:38:32 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 15:38:32 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 15:38:32 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 15:38:32 --> Final output sent to browser
DEBUG - 2021-09-24 15:38:32 --> Total execution time: 0.0528
INFO - 2021-09-24 15:52:43 --> Config Class Initialized
INFO - 2021-09-24 15:52:43 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:52:43 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:52:43 --> Utf8 Class Initialized
INFO - 2021-09-24 15:52:43 --> URI Class Initialized
INFO - 2021-09-24 15:52:43 --> Router Class Initialized
INFO - 2021-09-24 15:52:43 --> Output Class Initialized
INFO - 2021-09-24 15:52:43 --> Security Class Initialized
DEBUG - 2021-09-24 15:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:52:43 --> Input Class Initialized
INFO - 2021-09-24 15:52:43 --> Language Class Initialized
INFO - 2021-09-24 15:52:43 --> Loader Class Initialized
INFO - 2021-09-24 15:52:43 --> Helper loaded: url_helper
INFO - 2021-09-24 15:52:43 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:52:43 --> Controller Class Initialized
INFO - 2021-09-24 15:52:43 --> Model "DBModel" initialized
DEBUG - 2021-09-24 15:52:43 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:52:43 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:52:43 --> Database Driver Class Initialized
INFO - 2021-09-24 15:52:43 --> Helper loaded: string_helper
INFO - 2021-09-24 15:52:43 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:52:43 --> Model "BlogModel" initialized
INFO - 2021-09-24 15:52:43 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 15:52:43 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 15:52:43 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 15:52:43 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 15:52:43 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 15:52:43 --> Final output sent to browser
DEBUG - 2021-09-24 15:52:43 --> Total execution time: 0.0749
INFO - 2021-09-24 15:52:44 --> Config Class Initialized
INFO - 2021-09-24 15:52:44 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:52:44 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:52:44 --> Utf8 Class Initialized
INFO - 2021-09-24 15:52:44 --> URI Class Initialized
INFO - 2021-09-24 15:52:44 --> Router Class Initialized
INFO - 2021-09-24 15:52:44 --> Output Class Initialized
INFO - 2021-09-24 15:52:44 --> Security Class Initialized
DEBUG - 2021-09-24 15:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:52:44 --> Input Class Initialized
INFO - 2021-09-24 15:52:44 --> Language Class Initialized
INFO - 2021-09-24 15:52:44 --> Loader Class Initialized
INFO - 2021-09-24 15:52:44 --> Helper loaded: url_helper
INFO - 2021-09-24 15:52:44 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:52:44 --> Controller Class Initialized
INFO - 2021-09-24 15:52:44 --> Model "DBModel" initialized
DEBUG - 2021-09-24 15:52:44 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:52:44 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:52:44 --> Database Driver Class Initialized
INFO - 2021-09-24 15:52:44 --> Helper loaded: string_helper
INFO - 2021-09-24 15:52:44 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:52:44 --> Model "BlogModel" initialized
INFO - 2021-09-24 15:52:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 15:52:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 15:52:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 15:52:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 15:52:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 15:52:44 --> Final output sent to browser
DEBUG - 2021-09-24 15:52:44 --> Total execution time: 0.0476
INFO - 2021-09-24 15:52:45 --> Config Class Initialized
INFO - 2021-09-24 15:52:45 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:52:45 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:52:45 --> Utf8 Class Initialized
INFO - 2021-09-24 15:52:45 --> URI Class Initialized
INFO - 2021-09-24 15:52:45 --> Router Class Initialized
INFO - 2021-09-24 15:52:45 --> Output Class Initialized
INFO - 2021-09-24 15:52:45 --> Security Class Initialized
DEBUG - 2021-09-24 15:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:52:45 --> Input Class Initialized
INFO - 2021-09-24 15:52:45 --> Language Class Initialized
INFO - 2021-09-24 15:52:45 --> Loader Class Initialized
INFO - 2021-09-24 15:52:45 --> Helper loaded: url_helper
INFO - 2021-09-24 15:52:45 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:52:45 --> Controller Class Initialized
INFO - 2021-09-24 15:52:45 --> Model "DBModel" initialized
DEBUG - 2021-09-24 15:52:45 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:52:45 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:52:45 --> Database Driver Class Initialized
INFO - 2021-09-24 15:52:45 --> Helper loaded: string_helper
INFO - 2021-09-24 15:52:45 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:52:45 --> Model "BlogModel" initialized
INFO - 2021-09-24 15:52:45 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 15:52:45 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 15:52:45 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 15:52:45 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 15:52:45 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 15:52:45 --> Final output sent to browser
DEBUG - 2021-09-24 15:52:45 --> Total execution time: 0.0424
INFO - 2021-09-24 15:52:45 --> Config Class Initialized
INFO - 2021-09-24 15:52:45 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:52:45 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:52:45 --> Utf8 Class Initialized
INFO - 2021-09-24 15:52:45 --> URI Class Initialized
INFO - 2021-09-24 15:52:45 --> Router Class Initialized
INFO - 2021-09-24 15:52:45 --> Output Class Initialized
INFO - 2021-09-24 15:52:45 --> Security Class Initialized
DEBUG - 2021-09-24 15:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:52:45 --> Input Class Initialized
INFO - 2021-09-24 15:52:45 --> Language Class Initialized
INFO - 2021-09-24 15:52:45 --> Loader Class Initialized
INFO - 2021-09-24 15:52:45 --> Helper loaded: url_helper
INFO - 2021-09-24 15:52:45 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:52:45 --> Controller Class Initialized
INFO - 2021-09-24 15:52:45 --> Model "DBModel" initialized
DEBUG - 2021-09-24 15:52:45 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:52:45 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:52:45 --> Database Driver Class Initialized
INFO - 2021-09-24 15:52:45 --> Helper loaded: string_helper
INFO - 2021-09-24 15:52:45 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:52:45 --> Model "BlogModel" initialized
INFO - 2021-09-24 15:52:45 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 15:52:45 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 15:52:45 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 15:52:45 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 15:52:45 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 15:52:45 --> Final output sent to browser
DEBUG - 2021-09-24 15:52:45 --> Total execution time: 0.0608
INFO - 2021-09-24 15:52:46 --> Config Class Initialized
INFO - 2021-09-24 15:52:46 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:52:46 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:52:46 --> Utf8 Class Initialized
INFO - 2021-09-24 15:52:46 --> URI Class Initialized
INFO - 2021-09-24 15:52:46 --> Router Class Initialized
INFO - 2021-09-24 15:52:46 --> Output Class Initialized
INFO - 2021-09-24 15:52:46 --> Security Class Initialized
DEBUG - 2021-09-24 15:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:52:46 --> Input Class Initialized
INFO - 2021-09-24 15:52:46 --> Language Class Initialized
INFO - 2021-09-24 15:52:46 --> Loader Class Initialized
INFO - 2021-09-24 15:52:46 --> Helper loaded: url_helper
INFO - 2021-09-24 15:52:46 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:52:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:52:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:52:46 --> Controller Class Initialized
INFO - 2021-09-24 15:52:46 --> Model "DBModel" initialized
DEBUG - 2021-09-24 15:52:46 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:52:46 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:52:46 --> Database Driver Class Initialized
INFO - 2021-09-24 15:52:46 --> Helper loaded: string_helper
INFO - 2021-09-24 15:52:46 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:52:46 --> Model "BlogModel" initialized
INFO - 2021-09-24 15:52:46 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 15:52:46 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 15:52:46 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 15:52:46 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 15:52:46 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 15:52:46 --> Final output sent to browser
DEBUG - 2021-09-24 15:52:46 --> Total execution time: 0.0532
INFO - 2021-09-24 15:52:46 --> Config Class Initialized
INFO - 2021-09-24 15:52:46 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:52:46 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:52:46 --> Utf8 Class Initialized
INFO - 2021-09-24 15:52:46 --> URI Class Initialized
INFO - 2021-09-24 15:52:46 --> Router Class Initialized
INFO - 2021-09-24 15:52:46 --> Output Class Initialized
INFO - 2021-09-24 15:52:46 --> Security Class Initialized
DEBUG - 2021-09-24 15:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:52:46 --> Input Class Initialized
INFO - 2021-09-24 15:52:46 --> Language Class Initialized
INFO - 2021-09-24 15:52:46 --> Loader Class Initialized
INFO - 2021-09-24 15:52:46 --> Helper loaded: url_helper
INFO - 2021-09-24 15:52:46 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:52:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:52:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:52:46 --> Controller Class Initialized
INFO - 2021-09-24 15:52:46 --> Model "DBModel" initialized
DEBUG - 2021-09-24 15:52:46 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:52:46 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:52:46 --> Database Driver Class Initialized
INFO - 2021-09-24 15:52:46 --> Helper loaded: string_helper
INFO - 2021-09-24 15:52:46 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:52:46 --> Model "BlogModel" initialized
INFO - 2021-09-24 15:52:46 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 15:52:46 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 15:52:46 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 15:52:46 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 15:52:46 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 15:52:46 --> Final output sent to browser
DEBUG - 2021-09-24 15:52:46 --> Total execution time: 0.0502
INFO - 2021-09-24 15:52:51 --> Config Class Initialized
INFO - 2021-09-24 15:52:51 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:52:51 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:52:51 --> Utf8 Class Initialized
INFO - 2021-09-24 15:52:51 --> URI Class Initialized
INFO - 2021-09-24 15:52:51 --> Router Class Initialized
INFO - 2021-09-24 15:52:51 --> Output Class Initialized
INFO - 2021-09-24 15:52:51 --> Security Class Initialized
DEBUG - 2021-09-24 15:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:52:51 --> Input Class Initialized
INFO - 2021-09-24 15:52:51 --> Language Class Initialized
INFO - 2021-09-24 15:52:51 --> Loader Class Initialized
INFO - 2021-09-24 15:52:51 --> Helper loaded: url_helper
INFO - 2021-09-24 15:52:51 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:52:51 --> Controller Class Initialized
INFO - 2021-09-24 15:52:51 --> Model "DBModel" initialized
DEBUG - 2021-09-24 15:52:51 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:52:51 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:52:51 --> Database Driver Class Initialized
INFO - 2021-09-24 15:52:51 --> Helper loaded: string_helper
INFO - 2021-09-24 15:52:51 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:52:51 --> Model "BlogModel" initialized
INFO - 2021-09-24 15:52:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 15:52:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 15:52:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 15:52:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 15:52:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 15:52:51 --> Final output sent to browser
DEBUG - 2021-09-24 15:52:51 --> Total execution time: 0.0488
INFO - 2021-09-24 15:52:51 --> Config Class Initialized
INFO - 2021-09-24 15:52:51 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:52:51 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:52:51 --> Utf8 Class Initialized
INFO - 2021-09-24 15:52:51 --> URI Class Initialized
INFO - 2021-09-24 15:52:51 --> Router Class Initialized
INFO - 2021-09-24 15:52:51 --> Output Class Initialized
INFO - 2021-09-24 15:52:51 --> Security Class Initialized
DEBUG - 2021-09-24 15:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:52:51 --> Input Class Initialized
INFO - 2021-09-24 15:52:51 --> Language Class Initialized
INFO - 2021-09-24 15:52:51 --> Loader Class Initialized
INFO - 2021-09-24 15:52:51 --> Helper loaded: url_helper
INFO - 2021-09-24 15:52:51 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:52:51 --> Controller Class Initialized
INFO - 2021-09-24 15:52:51 --> Model "DBModel" initialized
DEBUG - 2021-09-24 15:52:51 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:52:51 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:52:51 --> Database Driver Class Initialized
INFO - 2021-09-24 15:52:51 --> Helper loaded: string_helper
INFO - 2021-09-24 15:52:51 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:52:51 --> Model "BlogModel" initialized
INFO - 2021-09-24 15:52:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 15:52:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 15:52:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 15:52:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 15:52:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 15:52:51 --> Final output sent to browser
DEBUG - 2021-09-24 15:52:51 --> Total execution time: 0.0445
INFO - 2021-09-24 15:52:52 --> Config Class Initialized
INFO - 2021-09-24 15:52:52 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:52:52 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:52:52 --> Utf8 Class Initialized
INFO - 2021-09-24 15:52:52 --> URI Class Initialized
INFO - 2021-09-24 15:52:52 --> Router Class Initialized
INFO - 2021-09-24 15:52:52 --> Output Class Initialized
INFO - 2021-09-24 15:52:52 --> Security Class Initialized
DEBUG - 2021-09-24 15:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:52:52 --> Input Class Initialized
INFO - 2021-09-24 15:52:52 --> Language Class Initialized
INFO - 2021-09-24 15:52:52 --> Loader Class Initialized
INFO - 2021-09-24 15:52:52 --> Helper loaded: url_helper
INFO - 2021-09-24 15:52:52 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:52:52 --> Controller Class Initialized
INFO - 2021-09-24 15:52:52 --> Model "DBModel" initialized
DEBUG - 2021-09-24 15:52:52 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:52:52 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:52:52 --> Database Driver Class Initialized
INFO - 2021-09-24 15:52:52 --> Helper loaded: string_helper
INFO - 2021-09-24 15:52:52 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:52:52 --> Model "BlogModel" initialized
INFO - 2021-09-24 15:52:52 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 15:52:52 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 15:52:52 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 15:52:52 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 15:52:52 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 15:52:52 --> Final output sent to browser
DEBUG - 2021-09-24 15:52:52 --> Total execution time: 0.0722
INFO - 2021-09-24 15:52:52 --> Config Class Initialized
INFO - 2021-09-24 15:52:52 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:52:52 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:52:52 --> Utf8 Class Initialized
INFO - 2021-09-24 15:52:52 --> URI Class Initialized
INFO - 2021-09-24 15:52:52 --> Router Class Initialized
INFO - 2021-09-24 15:52:52 --> Output Class Initialized
INFO - 2021-09-24 15:52:52 --> Security Class Initialized
DEBUG - 2021-09-24 15:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:52:52 --> Input Class Initialized
INFO - 2021-09-24 15:52:52 --> Language Class Initialized
INFO - 2021-09-24 15:52:52 --> Loader Class Initialized
INFO - 2021-09-24 15:52:52 --> Helper loaded: url_helper
INFO - 2021-09-24 15:52:52 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:52:52 --> Controller Class Initialized
INFO - 2021-09-24 15:52:52 --> Model "DBModel" initialized
DEBUG - 2021-09-24 15:52:52 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:52:52 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:52:52 --> Database Driver Class Initialized
INFO - 2021-09-24 15:52:52 --> Helper loaded: string_helper
INFO - 2021-09-24 15:52:52 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:52:52 --> Model "BlogModel" initialized
INFO - 2021-09-24 15:52:52 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 15:52:52 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 15:52:52 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 15:52:52 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 15:52:52 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 15:52:52 --> Final output sent to browser
DEBUG - 2021-09-24 15:52:52 --> Total execution time: 0.0486
INFO - 2021-09-24 15:52:52 --> Config Class Initialized
INFO - 2021-09-24 15:52:52 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:52:52 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:52:52 --> Utf8 Class Initialized
INFO - 2021-09-24 15:52:52 --> URI Class Initialized
INFO - 2021-09-24 15:52:52 --> Router Class Initialized
INFO - 2021-09-24 15:52:52 --> Output Class Initialized
INFO - 2021-09-24 15:52:52 --> Security Class Initialized
DEBUG - 2021-09-24 15:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:52:52 --> Input Class Initialized
INFO - 2021-09-24 15:52:52 --> Language Class Initialized
INFO - 2021-09-24 15:52:52 --> Loader Class Initialized
INFO - 2021-09-24 15:52:52 --> Helper loaded: url_helper
INFO - 2021-09-24 15:52:52 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:52:52 --> Controller Class Initialized
INFO - 2021-09-24 15:52:52 --> Model "DBModel" initialized
DEBUG - 2021-09-24 15:52:52 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:52:52 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:52:52 --> Database Driver Class Initialized
INFO - 2021-09-24 15:52:52 --> Helper loaded: string_helper
INFO - 2021-09-24 15:52:52 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:52:52 --> Model "BlogModel" initialized
INFO - 2021-09-24 15:52:52 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 15:52:52 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 15:52:52 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 15:52:52 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 15:52:52 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 15:52:52 --> Final output sent to browser
DEBUG - 2021-09-24 15:52:52 --> Total execution time: 0.0472
INFO - 2021-09-24 15:52:53 --> Config Class Initialized
INFO - 2021-09-24 15:52:53 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:52:53 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:52:53 --> Utf8 Class Initialized
INFO - 2021-09-24 15:52:53 --> URI Class Initialized
INFO - 2021-09-24 15:52:53 --> Router Class Initialized
INFO - 2021-09-24 15:52:53 --> Output Class Initialized
INFO - 2021-09-24 15:52:53 --> Security Class Initialized
DEBUG - 2021-09-24 15:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:52:53 --> Input Class Initialized
INFO - 2021-09-24 15:52:53 --> Language Class Initialized
INFO - 2021-09-24 15:52:53 --> Loader Class Initialized
INFO - 2021-09-24 15:52:53 --> Helper loaded: url_helper
INFO - 2021-09-24 15:52:53 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:52:53 --> Controller Class Initialized
INFO - 2021-09-24 15:52:53 --> Model "DBModel" initialized
DEBUG - 2021-09-24 15:52:53 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:52:53 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:52:53 --> Database Driver Class Initialized
INFO - 2021-09-24 15:52:53 --> Helper loaded: string_helper
INFO - 2021-09-24 15:52:53 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:52:53 --> Model "BlogModel" initialized
INFO - 2021-09-24 15:52:53 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 15:52:53 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 15:52:53 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 15:52:53 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 15:52:53 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 15:52:53 --> Final output sent to browser
DEBUG - 2021-09-24 15:52:53 --> Total execution time: 0.0519
INFO - 2021-09-24 15:53:21 --> Config Class Initialized
INFO - 2021-09-24 15:53:21 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:53:21 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:53:21 --> Utf8 Class Initialized
INFO - 2021-09-24 15:53:21 --> URI Class Initialized
INFO - 2021-09-24 15:53:21 --> Router Class Initialized
INFO - 2021-09-24 15:53:21 --> Output Class Initialized
INFO - 2021-09-24 15:53:21 --> Security Class Initialized
DEBUG - 2021-09-24 15:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:53:21 --> Input Class Initialized
INFO - 2021-09-24 15:53:21 --> Language Class Initialized
INFO - 2021-09-24 15:53:21 --> Loader Class Initialized
INFO - 2021-09-24 15:53:21 --> Helper loaded: url_helper
INFO - 2021-09-24 15:53:21 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:53:21 --> Controller Class Initialized
INFO - 2021-09-24 15:53:21 --> Model "DBModel" initialized
DEBUG - 2021-09-24 15:53:21 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:53:21 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:53:21 --> Database Driver Class Initialized
INFO - 2021-09-24 15:53:21 --> Helper loaded: string_helper
INFO - 2021-09-24 15:53:21 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:53:21 --> Model "BlogModel" initialized
INFO - 2021-09-24 15:53:21 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 15:53:21 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 15:53:21 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 15:53:21 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 15:53:21 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 15:53:21 --> Final output sent to browser
DEBUG - 2021-09-24 15:53:21 --> Total execution time: 0.0841
INFO - 2021-09-24 15:53:23 --> Config Class Initialized
INFO - 2021-09-24 15:53:23 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:53:23 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:53:23 --> Utf8 Class Initialized
INFO - 2021-09-24 15:53:23 --> URI Class Initialized
INFO - 2021-09-24 15:53:23 --> Router Class Initialized
INFO - 2021-09-24 15:53:23 --> Output Class Initialized
INFO - 2021-09-24 15:53:23 --> Security Class Initialized
DEBUG - 2021-09-24 15:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:53:23 --> Input Class Initialized
INFO - 2021-09-24 15:53:23 --> Language Class Initialized
INFO - 2021-09-24 15:53:23 --> Loader Class Initialized
INFO - 2021-09-24 15:53:23 --> Helper loaded: url_helper
INFO - 2021-09-24 15:53:23 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:53:23 --> Controller Class Initialized
INFO - 2021-09-24 15:53:23 --> Model "DBModel" initialized
DEBUG - 2021-09-24 15:53:23 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:53:23 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:53:23 --> Database Driver Class Initialized
INFO - 2021-09-24 15:53:23 --> Helper loaded: string_helper
INFO - 2021-09-24 15:53:23 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:53:23 --> Model "BlogModel" initialized
INFO - 2021-09-24 15:53:23 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 15:53:23 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 15:53:23 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 15:53:23 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 15:53:23 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 15:53:23 --> Final output sent to browser
DEBUG - 2021-09-24 15:53:23 --> Total execution time: 0.0752
INFO - 2021-09-24 15:53:25 --> Config Class Initialized
INFO - 2021-09-24 15:53:25 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:53:25 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:53:25 --> Utf8 Class Initialized
INFO - 2021-09-24 15:53:25 --> URI Class Initialized
INFO - 2021-09-24 15:53:25 --> Router Class Initialized
INFO - 2021-09-24 15:53:25 --> Output Class Initialized
INFO - 2021-09-24 15:53:25 --> Security Class Initialized
DEBUG - 2021-09-24 15:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:53:25 --> Input Class Initialized
INFO - 2021-09-24 15:53:25 --> Language Class Initialized
INFO - 2021-09-24 15:53:25 --> Loader Class Initialized
INFO - 2021-09-24 15:53:25 --> Helper loaded: url_helper
INFO - 2021-09-24 15:53:25 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:53:25 --> Controller Class Initialized
INFO - 2021-09-24 15:53:25 --> Model "DBModel" initialized
DEBUG - 2021-09-24 15:53:25 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:53:25 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:53:25 --> Database Driver Class Initialized
INFO - 2021-09-24 15:53:25 --> Helper loaded: string_helper
INFO - 2021-09-24 15:53:25 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:53:25 --> Model "BlogModel" initialized
INFO - 2021-09-24 15:53:25 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 15:53:25 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 15:53:25 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 15:53:25 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 15:53:25 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 15:53:25 --> Final output sent to browser
DEBUG - 2021-09-24 15:53:25 --> Total execution time: 0.0828
INFO - 2021-09-24 15:55:20 --> Config Class Initialized
INFO - 2021-09-24 15:55:20 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:55:20 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:55:20 --> Utf8 Class Initialized
INFO - 2021-09-24 15:55:20 --> URI Class Initialized
INFO - 2021-09-24 15:55:20 --> Router Class Initialized
INFO - 2021-09-24 15:55:20 --> Output Class Initialized
INFO - 2021-09-24 15:55:20 --> Security Class Initialized
DEBUG - 2021-09-24 15:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:55:20 --> Input Class Initialized
INFO - 2021-09-24 15:55:20 --> Language Class Initialized
INFO - 2021-09-24 15:55:20 --> Loader Class Initialized
INFO - 2021-09-24 15:55:20 --> Helper loaded: url_helper
INFO - 2021-09-24 15:55:20 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:55:20 --> Controller Class Initialized
INFO - 2021-09-24 15:55:20 --> Model "DBModel" initialized
DEBUG - 2021-09-24 15:55:20 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:55:20 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:55:20 --> Database Driver Class Initialized
INFO - 2021-09-24 15:55:20 --> Helper loaded: string_helper
INFO - 2021-09-24 15:55:20 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:55:20 --> Model "BlogModel" initialized
INFO - 2021-09-24 15:55:20 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 15:55:20 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 15:55:20 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 15:55:20 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 15:55:20 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 15:55:20 --> Final output sent to browser
DEBUG - 2021-09-24 15:55:20 --> Total execution time: 0.0505
INFO - 2021-09-24 15:55:55 --> Config Class Initialized
INFO - 2021-09-24 15:55:55 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:55:55 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:55:55 --> Utf8 Class Initialized
INFO - 2021-09-24 15:55:55 --> URI Class Initialized
INFO - 2021-09-24 15:55:55 --> Router Class Initialized
INFO - 2021-09-24 15:55:55 --> Output Class Initialized
INFO - 2021-09-24 15:55:55 --> Security Class Initialized
DEBUG - 2021-09-24 15:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:55:55 --> Input Class Initialized
INFO - 2021-09-24 15:55:55 --> Language Class Initialized
INFO - 2021-09-24 15:55:55 --> Loader Class Initialized
INFO - 2021-09-24 15:55:55 --> Helper loaded: url_helper
INFO - 2021-09-24 15:55:55 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:55:55 --> Controller Class Initialized
INFO - 2021-09-24 15:55:55 --> Model "DBModel" initialized
DEBUG - 2021-09-24 15:55:55 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:55:55 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:55:55 --> Database Driver Class Initialized
INFO - 2021-09-24 15:55:55 --> Helper loaded: string_helper
INFO - 2021-09-24 15:55:55 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:55:55 --> Model "BlogModel" initialized
INFO - 2021-09-24 15:55:55 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 15:55:55 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 15:55:55 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 15:55:55 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 15:55:55 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 15:55:55 --> Final output sent to browser
DEBUG - 2021-09-24 15:55:55 --> Total execution time: 0.0615
INFO - 2021-09-24 15:56:32 --> Config Class Initialized
INFO - 2021-09-24 15:56:32 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:56:32 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:56:32 --> Utf8 Class Initialized
INFO - 2021-09-24 15:56:32 --> URI Class Initialized
INFO - 2021-09-24 15:56:32 --> Router Class Initialized
INFO - 2021-09-24 15:56:32 --> Output Class Initialized
INFO - 2021-09-24 15:56:32 --> Security Class Initialized
DEBUG - 2021-09-24 15:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:56:32 --> Input Class Initialized
INFO - 2021-09-24 15:56:32 --> Language Class Initialized
INFO - 2021-09-24 15:56:32 --> Loader Class Initialized
INFO - 2021-09-24 15:56:32 --> Helper loaded: url_helper
INFO - 2021-09-24 15:56:32 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:56:32 --> Controller Class Initialized
INFO - 2021-09-24 15:56:32 --> Model "DBModel" initialized
DEBUG - 2021-09-24 15:56:32 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:56:32 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:56:32 --> Database Driver Class Initialized
INFO - 2021-09-24 15:56:32 --> Helper loaded: string_helper
INFO - 2021-09-24 15:56:32 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:56:32 --> Model "BlogModel" initialized
INFO - 2021-09-24 15:56:32 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 15:56:32 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 15:56:32 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 15:56:32 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 15:56:32 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 15:56:32 --> Final output sent to browser
DEBUG - 2021-09-24 15:56:32 --> Total execution time: 0.0486
INFO - 2021-09-24 15:58:43 --> Config Class Initialized
INFO - 2021-09-24 15:58:43 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:58:43 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:58:43 --> Utf8 Class Initialized
INFO - 2021-09-24 15:58:43 --> URI Class Initialized
INFO - 2021-09-24 15:58:43 --> Router Class Initialized
INFO - 2021-09-24 15:58:43 --> Output Class Initialized
INFO - 2021-09-24 15:58:43 --> Security Class Initialized
DEBUG - 2021-09-24 15:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:58:43 --> Input Class Initialized
INFO - 2021-09-24 15:58:43 --> Language Class Initialized
INFO - 2021-09-24 15:58:43 --> Loader Class Initialized
INFO - 2021-09-24 15:58:43 --> Helper loaded: url_helper
INFO - 2021-09-24 15:58:43 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:58:43 --> Controller Class Initialized
INFO - 2021-09-24 15:58:43 --> Model "DBModel" initialized
DEBUG - 2021-09-24 15:58:43 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:58:43 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:58:43 --> Database Driver Class Initialized
INFO - 2021-09-24 15:58:43 --> Helper loaded: string_helper
INFO - 2021-09-24 15:58:43 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:58:43 --> Model "BlogModel" initialized
INFO - 2021-09-24 15:58:43 --> Config Class Initialized
INFO - 2021-09-24 15:58:43 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:58:43 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:58:43 --> Utf8 Class Initialized
INFO - 2021-09-24 15:58:43 --> URI Class Initialized
INFO - 2021-09-24 15:58:43 --> Router Class Initialized
INFO - 2021-09-24 15:58:43 --> Output Class Initialized
INFO - 2021-09-24 15:58:43 --> Security Class Initialized
DEBUG - 2021-09-24 15:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:58:43 --> Input Class Initialized
INFO - 2021-09-24 15:58:43 --> Language Class Initialized
INFO - 2021-09-24 15:58:43 --> Loader Class Initialized
INFO - 2021-09-24 15:58:43 --> Helper loaded: url_helper
INFO - 2021-09-24 15:58:43 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:58:43 --> Controller Class Initialized
INFO - 2021-09-24 15:58:43 --> Model "DBModel" initialized
DEBUG - 2021-09-24 15:58:43 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:58:43 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:58:44 --> Database Driver Class Initialized
INFO - 2021-09-24 15:58:44 --> Helper loaded: string_helper
INFO - 2021-09-24 15:58:44 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:58:44 --> Model "BlogModel" initialized
INFO - 2021-09-24 15:58:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 15:58:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 15:58:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 15:58:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonials.php
INFO - 2021-09-24 15:58:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 15:58:44 --> Final output sent to browser
DEBUG - 2021-09-24 15:58:44 --> Total execution time: 0.0525
INFO - 2021-09-24 15:58:44 --> Config Class Initialized
INFO - 2021-09-24 15:58:44 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:58:44 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:58:44 --> Utf8 Class Initialized
INFO - 2021-09-24 15:58:44 --> URI Class Initialized
INFO - 2021-09-24 15:58:44 --> Router Class Initialized
INFO - 2021-09-24 15:58:44 --> Output Class Initialized
INFO - 2021-09-24 15:58:44 --> Security Class Initialized
DEBUG - 2021-09-24 15:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:58:44 --> Input Class Initialized
INFO - 2021-09-24 15:58:44 --> Language Class Initialized
ERROR - 2021-09-24 15:58:44 --> 404 Page Not Found: Testimonialpics/.png
INFO - 2021-09-24 15:59:26 --> Config Class Initialized
INFO - 2021-09-24 15:59:26 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:59:26 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:59:26 --> Utf8 Class Initialized
INFO - 2021-09-24 15:59:26 --> URI Class Initialized
INFO - 2021-09-24 15:59:26 --> Router Class Initialized
INFO - 2021-09-24 15:59:26 --> Output Class Initialized
INFO - 2021-09-24 15:59:26 --> Security Class Initialized
DEBUG - 2021-09-24 15:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:59:26 --> Input Class Initialized
INFO - 2021-09-24 15:59:26 --> Language Class Initialized
INFO - 2021-09-24 15:59:26 --> Loader Class Initialized
INFO - 2021-09-24 15:59:26 --> Helper loaded: url_helper
INFO - 2021-09-24 15:59:26 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:59:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:59:26 --> Controller Class Initialized
INFO - 2021-09-24 15:59:26 --> Model "DBModel" initialized
DEBUG - 2021-09-24 15:59:26 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:59:26 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:59:26 --> Database Driver Class Initialized
INFO - 2021-09-24 15:59:26 --> Helper loaded: string_helper
INFO - 2021-09-24 15:59:26 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:59:26 --> Model "BlogModel" initialized
INFO - 2021-09-24 15:59:26 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 15:59:26 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 15:59:26 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 15:59:26 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonials.php
INFO - 2021-09-24 15:59:26 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 15:59:26 --> Final output sent to browser
DEBUG - 2021-09-24 15:59:26 --> Total execution time: 0.0582
INFO - 2021-09-24 15:59:26 --> Config Class Initialized
INFO - 2021-09-24 15:59:26 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:59:26 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:59:26 --> Utf8 Class Initialized
INFO - 2021-09-24 15:59:26 --> URI Class Initialized
INFO - 2021-09-24 15:59:26 --> Router Class Initialized
INFO - 2021-09-24 15:59:26 --> Output Class Initialized
INFO - 2021-09-24 15:59:26 --> Security Class Initialized
DEBUG - 2021-09-24 15:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:59:26 --> Input Class Initialized
INFO - 2021-09-24 15:59:26 --> Language Class Initialized
ERROR - 2021-09-24 15:59:26 --> 404 Page Not Found: Testimonialpics/.png
INFO - 2021-09-24 15:59:28 --> Config Class Initialized
INFO - 2021-09-24 15:59:28 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:59:28 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:59:28 --> Utf8 Class Initialized
INFO - 2021-09-24 15:59:28 --> URI Class Initialized
INFO - 2021-09-24 15:59:28 --> Router Class Initialized
INFO - 2021-09-24 15:59:28 --> Output Class Initialized
INFO - 2021-09-24 15:59:28 --> Security Class Initialized
DEBUG - 2021-09-24 15:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:59:28 --> Input Class Initialized
INFO - 2021-09-24 15:59:28 --> Language Class Initialized
INFO - 2021-09-24 15:59:28 --> Loader Class Initialized
INFO - 2021-09-24 15:59:28 --> Helper loaded: url_helper
INFO - 2021-09-24 15:59:28 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:59:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:59:28 --> Controller Class Initialized
INFO - 2021-09-24 15:59:28 --> Model "DBModel" initialized
DEBUG - 2021-09-24 15:59:28 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:59:28 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:59:28 --> Database Driver Class Initialized
INFO - 2021-09-24 15:59:28 --> Helper loaded: string_helper
INFO - 2021-09-24 15:59:28 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:59:28 --> Model "BlogModel" initialized
INFO - 2021-09-24 15:59:28 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 15:59:28 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 15:59:28 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 15:59:28 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonials.php
INFO - 2021-09-24 15:59:28 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 15:59:28 --> Final output sent to browser
DEBUG - 2021-09-24 15:59:28 --> Total execution time: 0.0641
INFO - 2021-09-24 15:59:28 --> Config Class Initialized
INFO - 2021-09-24 15:59:28 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:59:28 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:59:28 --> Utf8 Class Initialized
INFO - 2021-09-24 15:59:28 --> URI Class Initialized
INFO - 2021-09-24 15:59:28 --> Router Class Initialized
INFO - 2021-09-24 15:59:28 --> Output Class Initialized
INFO - 2021-09-24 15:59:28 --> Security Class Initialized
DEBUG - 2021-09-24 15:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:59:28 --> Input Class Initialized
INFO - 2021-09-24 15:59:28 --> Language Class Initialized
ERROR - 2021-09-24 15:59:28 --> 404 Page Not Found: Testimonialpics/.png
INFO - 2021-09-24 15:59:44 --> Config Class Initialized
INFO - 2021-09-24 15:59:44 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:59:44 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:59:44 --> Utf8 Class Initialized
INFO - 2021-09-24 15:59:44 --> URI Class Initialized
INFO - 2021-09-24 15:59:44 --> Router Class Initialized
INFO - 2021-09-24 15:59:44 --> Output Class Initialized
INFO - 2021-09-24 15:59:44 --> Security Class Initialized
DEBUG - 2021-09-24 15:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:59:44 --> Input Class Initialized
INFO - 2021-09-24 15:59:44 --> Language Class Initialized
INFO - 2021-09-24 15:59:44 --> Loader Class Initialized
INFO - 2021-09-24 15:59:44 --> Helper loaded: url_helper
INFO - 2021-09-24 15:59:44 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:59:44 --> Controller Class Initialized
INFO - 2021-09-24 15:59:44 --> Model "DBModel" initialized
DEBUG - 2021-09-24 15:59:44 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:59:44 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:59:44 --> Database Driver Class Initialized
INFO - 2021-09-24 15:59:44 --> Helper loaded: string_helper
INFO - 2021-09-24 15:59:44 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:59:44 --> Model "BlogModel" initialized
INFO - 2021-09-24 15:59:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 15:59:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 15:59:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 15:59:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonials.php
INFO - 2021-09-24 15:59:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 15:59:44 --> Final output sent to browser
DEBUG - 2021-09-24 15:59:44 --> Total execution time: 0.0682
INFO - 2021-09-24 15:59:44 --> Config Class Initialized
INFO - 2021-09-24 15:59:44 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:59:44 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:59:44 --> Utf8 Class Initialized
INFO - 2021-09-24 15:59:45 --> URI Class Initialized
INFO - 2021-09-24 15:59:45 --> Router Class Initialized
INFO - 2021-09-24 15:59:45 --> Output Class Initialized
INFO - 2021-09-24 15:59:45 --> Security Class Initialized
DEBUG - 2021-09-24 15:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:59:45 --> Input Class Initialized
INFO - 2021-09-24 15:59:45 --> Language Class Initialized
ERROR - 2021-09-24 15:59:45 --> 404 Page Not Found: Testimonialpics/.png
INFO - 2021-09-24 15:59:47 --> Config Class Initialized
INFO - 2021-09-24 15:59:47 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:59:47 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:59:47 --> Utf8 Class Initialized
INFO - 2021-09-24 15:59:47 --> URI Class Initialized
INFO - 2021-09-24 15:59:47 --> Router Class Initialized
INFO - 2021-09-24 15:59:47 --> Output Class Initialized
INFO - 2021-09-24 15:59:47 --> Security Class Initialized
DEBUG - 2021-09-24 15:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:59:47 --> Input Class Initialized
INFO - 2021-09-24 15:59:47 --> Language Class Initialized
INFO - 2021-09-24 15:59:47 --> Loader Class Initialized
INFO - 2021-09-24 15:59:47 --> Helper loaded: url_helper
INFO - 2021-09-24 15:59:47 --> Helper loaded: file_helper
DEBUG - 2021-09-24 15:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 15:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 15:59:47 --> Controller Class Initialized
INFO - 2021-09-24 15:59:47 --> Model "DBModel" initialized
DEBUG - 2021-09-24 15:59:47 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 15:59:47 --> Helper loaded: cookie_helper
INFO - 2021-09-24 15:59:47 --> Database Driver Class Initialized
INFO - 2021-09-24 15:59:47 --> Helper loaded: string_helper
INFO - 2021-09-24 15:59:47 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 15:59:47 --> Model "BlogModel" initialized
INFO - 2021-09-24 15:59:47 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 15:59:47 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 15:59:47 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 15:59:47 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonials.php
INFO - 2021-09-24 15:59:47 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 15:59:47 --> Final output sent to browser
DEBUG - 2021-09-24 15:59:47 --> Total execution time: 0.0465
INFO - 2021-09-24 15:59:47 --> Config Class Initialized
INFO - 2021-09-24 15:59:47 --> Hooks Class Initialized
DEBUG - 2021-09-24 15:59:47 --> UTF-8 Support Enabled
INFO - 2021-09-24 15:59:47 --> Utf8 Class Initialized
INFO - 2021-09-24 15:59:47 --> URI Class Initialized
INFO - 2021-09-24 15:59:47 --> Router Class Initialized
INFO - 2021-09-24 15:59:47 --> Output Class Initialized
INFO - 2021-09-24 15:59:47 --> Security Class Initialized
DEBUG - 2021-09-24 15:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 15:59:47 --> Input Class Initialized
INFO - 2021-09-24 15:59:47 --> Language Class Initialized
ERROR - 2021-09-24 15:59:47 --> 404 Page Not Found: Testimonialpics/.png
INFO - 2021-09-24 16:00:56 --> Config Class Initialized
INFO - 2021-09-24 16:00:56 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:00:56 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:00:56 --> Utf8 Class Initialized
INFO - 2021-09-24 16:00:56 --> URI Class Initialized
INFO - 2021-09-24 16:00:56 --> Router Class Initialized
INFO - 2021-09-24 16:00:56 --> Output Class Initialized
INFO - 2021-09-24 16:00:56 --> Security Class Initialized
DEBUG - 2021-09-24 16:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:00:56 --> Input Class Initialized
INFO - 2021-09-24 16:00:56 --> Language Class Initialized
INFO - 2021-09-24 16:00:56 --> Loader Class Initialized
INFO - 2021-09-24 16:00:56 --> Helper loaded: url_helper
INFO - 2021-09-24 16:00:56 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:00:56 --> Controller Class Initialized
INFO - 2021-09-24 16:00:56 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:00:56 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:00:56 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:00:56 --> Database Driver Class Initialized
INFO - 2021-09-24 16:00:56 --> Helper loaded: string_helper
INFO - 2021-09-24 16:00:56 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:00:56 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:00:56 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:00:56 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:00:56 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:00:56 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonials.php
INFO - 2021-09-24 16:00:56 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:00:56 --> Final output sent to browser
DEBUG - 2021-09-24 16:00:56 --> Total execution time: 0.0888
INFO - 2021-09-24 16:11:01 --> Config Class Initialized
INFO - 2021-09-24 16:11:01 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:11:01 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:11:01 --> Utf8 Class Initialized
INFO - 2021-09-24 16:11:01 --> URI Class Initialized
INFO - 2021-09-24 16:11:01 --> Router Class Initialized
INFO - 2021-09-24 16:11:01 --> Output Class Initialized
INFO - 2021-09-24 16:11:01 --> Security Class Initialized
DEBUG - 2021-09-24 16:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:11:01 --> Input Class Initialized
INFO - 2021-09-24 16:11:01 --> Language Class Initialized
INFO - 2021-09-24 16:11:01 --> Loader Class Initialized
INFO - 2021-09-24 16:11:01 --> Helper loaded: url_helper
INFO - 2021-09-24 16:11:01 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:11:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:11:01 --> Controller Class Initialized
INFO - 2021-09-24 16:11:01 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:11:01 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:11:01 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:11:01 --> Database Driver Class Initialized
INFO - 2021-09-24 16:11:01 --> Helper loaded: string_helper
INFO - 2021-09-24 16:11:01 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:11:01 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:11:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:11:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:11:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:11:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonials.php
INFO - 2021-09-24 16:11:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:11:01 --> Final output sent to browser
DEBUG - 2021-09-24 16:11:01 --> Total execution time: 0.0536
INFO - 2021-09-24 16:15:54 --> Config Class Initialized
INFO - 2021-09-24 16:15:54 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:15:54 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:15:54 --> Utf8 Class Initialized
INFO - 2021-09-24 16:15:54 --> URI Class Initialized
INFO - 2021-09-24 16:15:54 --> Router Class Initialized
INFO - 2021-09-24 16:15:54 --> Output Class Initialized
INFO - 2021-09-24 16:15:54 --> Security Class Initialized
DEBUG - 2021-09-24 16:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:15:54 --> Input Class Initialized
INFO - 2021-09-24 16:15:54 --> Language Class Initialized
INFO - 2021-09-24 16:15:54 --> Loader Class Initialized
INFO - 2021-09-24 16:15:54 --> Helper loaded: url_helper
INFO - 2021-09-24 16:15:54 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:15:54 --> Controller Class Initialized
INFO - 2021-09-24 16:15:54 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:15:54 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:15:54 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:15:54 --> Database Driver Class Initialized
INFO - 2021-09-24 16:15:54 --> Helper loaded: string_helper
INFO - 2021-09-24 16:15:54 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:15:54 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:15:54 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:15:54 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:15:54 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:15:54 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 16:15:54 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:15:54 --> Final output sent to browser
DEBUG - 2021-09-24 16:15:54 --> Total execution time: 0.0615
INFO - 2021-09-24 16:16:13 --> Config Class Initialized
INFO - 2021-09-24 16:16:13 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:16:13 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:16:13 --> Utf8 Class Initialized
INFO - 2021-09-24 16:16:13 --> URI Class Initialized
INFO - 2021-09-24 16:16:13 --> Router Class Initialized
INFO - 2021-09-24 16:16:13 --> Output Class Initialized
INFO - 2021-09-24 16:16:13 --> Security Class Initialized
DEBUG - 2021-09-24 16:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:16:13 --> Input Class Initialized
INFO - 2021-09-24 16:16:13 --> Language Class Initialized
INFO - 2021-09-24 16:16:13 --> Loader Class Initialized
INFO - 2021-09-24 16:16:13 --> Helper loaded: url_helper
INFO - 2021-09-24 16:16:13 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:16:13 --> Controller Class Initialized
INFO - 2021-09-24 16:16:13 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:16:13 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:16:13 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:16:13 --> Database Driver Class Initialized
INFO - 2021-09-24 16:16:13 --> Helper loaded: string_helper
INFO - 2021-09-24 16:16:13 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:16:13 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:16:13 --> Config Class Initialized
INFO - 2021-09-24 16:16:13 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:16:13 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:16:13 --> Utf8 Class Initialized
INFO - 2021-09-24 16:16:13 --> URI Class Initialized
INFO - 2021-09-24 16:16:13 --> Router Class Initialized
INFO - 2021-09-24 16:16:13 --> Output Class Initialized
INFO - 2021-09-24 16:16:13 --> Security Class Initialized
DEBUG - 2021-09-24 16:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:16:13 --> Input Class Initialized
INFO - 2021-09-24 16:16:13 --> Language Class Initialized
INFO - 2021-09-24 16:16:13 --> Loader Class Initialized
INFO - 2021-09-24 16:16:13 --> Helper loaded: url_helper
INFO - 2021-09-24 16:16:13 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:16:13 --> Controller Class Initialized
INFO - 2021-09-24 16:16:13 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:16:13 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:16:13 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:16:13 --> Database Driver Class Initialized
INFO - 2021-09-24 16:16:13 --> Helper loaded: string_helper
INFO - 2021-09-24 16:16:13 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:16:13 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:16:13 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:16:13 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:16:13 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:16:13 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonials.php
INFO - 2021-09-24 16:16:13 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:16:13 --> Final output sent to browser
DEBUG - 2021-09-24 16:16:13 --> Total execution time: 0.0772
INFO - 2021-09-24 16:16:30 --> Config Class Initialized
INFO - 2021-09-24 16:16:30 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:16:30 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:16:30 --> Utf8 Class Initialized
INFO - 2021-09-24 16:16:30 --> URI Class Initialized
INFO - 2021-09-24 16:16:30 --> Router Class Initialized
INFO - 2021-09-24 16:16:30 --> Output Class Initialized
INFO - 2021-09-24 16:16:30 --> Security Class Initialized
DEBUG - 2021-09-24 16:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:16:30 --> Input Class Initialized
INFO - 2021-09-24 16:16:30 --> Language Class Initialized
INFO - 2021-09-24 16:16:30 --> Loader Class Initialized
INFO - 2021-09-24 16:16:30 --> Helper loaded: url_helper
INFO - 2021-09-24 16:16:30 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:16:30 --> Controller Class Initialized
INFO - 2021-09-24 16:16:30 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:16:30 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:16:30 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:16:30 --> Database Driver Class Initialized
INFO - 2021-09-24 16:16:30 --> Helper loaded: string_helper
INFO - 2021-09-24 16:16:30 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:16:30 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:16:30 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:16:30 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:16:30 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:16:30 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 16:16:30 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:16:30 --> Final output sent to browser
DEBUG - 2021-09-24 16:16:30 --> Total execution time: 0.1099
INFO - 2021-09-24 16:16:47 --> Config Class Initialized
INFO - 2021-09-24 16:16:47 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:16:47 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:16:47 --> Utf8 Class Initialized
INFO - 2021-09-24 16:16:47 --> URI Class Initialized
INFO - 2021-09-24 16:16:47 --> Router Class Initialized
INFO - 2021-09-24 16:16:47 --> Output Class Initialized
INFO - 2021-09-24 16:16:47 --> Security Class Initialized
DEBUG - 2021-09-24 16:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:16:47 --> Input Class Initialized
INFO - 2021-09-24 16:16:47 --> Language Class Initialized
INFO - 2021-09-24 16:16:47 --> Loader Class Initialized
INFO - 2021-09-24 16:16:47 --> Helper loaded: url_helper
INFO - 2021-09-24 16:16:47 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:16:47 --> Controller Class Initialized
INFO - 2021-09-24 16:16:47 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:16:47 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:16:47 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:16:47 --> Database Driver Class Initialized
INFO - 2021-09-24 16:16:47 --> Helper loaded: string_helper
INFO - 2021-09-24 16:16:47 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:16:47 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:16:47 --> Config Class Initialized
INFO - 2021-09-24 16:16:47 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:16:47 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:16:47 --> Utf8 Class Initialized
INFO - 2021-09-24 16:16:47 --> URI Class Initialized
INFO - 2021-09-24 16:16:47 --> Router Class Initialized
INFO - 2021-09-24 16:16:47 --> Output Class Initialized
INFO - 2021-09-24 16:16:47 --> Security Class Initialized
DEBUG - 2021-09-24 16:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:16:47 --> Input Class Initialized
INFO - 2021-09-24 16:16:47 --> Language Class Initialized
INFO - 2021-09-24 16:16:47 --> Loader Class Initialized
INFO - 2021-09-24 16:16:47 --> Helper loaded: url_helper
INFO - 2021-09-24 16:16:47 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:16:47 --> Controller Class Initialized
INFO - 2021-09-24 16:16:47 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:16:47 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:16:47 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:16:47 --> Database Driver Class Initialized
INFO - 2021-09-24 16:16:47 --> Helper loaded: string_helper
INFO - 2021-09-24 16:16:47 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:16:47 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:16:47 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:16:47 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:16:47 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:16:47 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonials.php
INFO - 2021-09-24 16:16:47 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:16:47 --> Final output sent to browser
DEBUG - 2021-09-24 16:16:47 --> Total execution time: 0.0467
INFO - 2021-09-24 16:16:49 --> Config Class Initialized
INFO - 2021-09-24 16:16:49 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:16:49 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:16:49 --> Utf8 Class Initialized
INFO - 2021-09-24 16:16:49 --> URI Class Initialized
INFO - 2021-09-24 16:16:49 --> Router Class Initialized
INFO - 2021-09-24 16:16:49 --> Output Class Initialized
INFO - 2021-09-24 16:16:49 --> Security Class Initialized
DEBUG - 2021-09-24 16:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:16:49 --> Input Class Initialized
INFO - 2021-09-24 16:16:49 --> Language Class Initialized
INFO - 2021-09-24 16:16:49 --> Loader Class Initialized
INFO - 2021-09-24 16:16:49 --> Helper loaded: url_helper
INFO - 2021-09-24 16:16:49 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:16:49 --> Controller Class Initialized
INFO - 2021-09-24 16:16:49 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:16:49 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:16:49 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:16:49 --> Database Driver Class Initialized
INFO - 2021-09-24 16:16:49 --> Helper loaded: string_helper
INFO - 2021-09-24 16:16:49 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:16:49 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:16:49 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:16:49 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:16:49 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:16:49 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 16:16:49 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:16:49 --> Final output sent to browser
DEBUG - 2021-09-24 16:16:49 --> Total execution time: 0.0436
INFO - 2021-09-24 16:17:05 --> Config Class Initialized
INFO - 2021-09-24 16:17:05 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:17:05 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:17:05 --> Utf8 Class Initialized
INFO - 2021-09-24 16:17:05 --> URI Class Initialized
INFO - 2021-09-24 16:17:05 --> Router Class Initialized
INFO - 2021-09-24 16:17:05 --> Output Class Initialized
INFO - 2021-09-24 16:17:05 --> Security Class Initialized
DEBUG - 2021-09-24 16:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:17:05 --> Input Class Initialized
INFO - 2021-09-24 16:17:05 --> Language Class Initialized
INFO - 2021-09-24 16:17:05 --> Loader Class Initialized
INFO - 2021-09-24 16:17:05 --> Helper loaded: url_helper
INFO - 2021-09-24 16:17:05 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:17:05 --> Controller Class Initialized
INFO - 2021-09-24 16:17:05 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:17:05 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:17:05 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:17:05 --> Database Driver Class Initialized
INFO - 2021-09-24 16:17:05 --> Helper loaded: string_helper
INFO - 2021-09-24 16:17:05 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:17:05 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:17:05 --> Config Class Initialized
INFO - 2021-09-24 16:17:05 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:17:05 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:17:05 --> Utf8 Class Initialized
INFO - 2021-09-24 16:17:05 --> URI Class Initialized
INFO - 2021-09-24 16:17:05 --> Router Class Initialized
INFO - 2021-09-24 16:17:05 --> Output Class Initialized
INFO - 2021-09-24 16:17:05 --> Security Class Initialized
DEBUG - 2021-09-24 16:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:17:05 --> Input Class Initialized
INFO - 2021-09-24 16:17:05 --> Language Class Initialized
INFO - 2021-09-24 16:17:05 --> Loader Class Initialized
INFO - 2021-09-24 16:17:05 --> Helper loaded: url_helper
INFO - 2021-09-24 16:17:05 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:17:05 --> Controller Class Initialized
INFO - 2021-09-24 16:17:05 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:17:05 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:17:05 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:17:05 --> Database Driver Class Initialized
INFO - 2021-09-24 16:17:05 --> Helper loaded: string_helper
INFO - 2021-09-24 16:17:05 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:17:05 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:17:05 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:17:05 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:17:05 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:17:05 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonials.php
INFO - 2021-09-24 16:17:05 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:17:05 --> Final output sent to browser
DEBUG - 2021-09-24 16:17:05 --> Total execution time: 0.0477
INFO - 2021-09-24 16:17:07 --> Config Class Initialized
INFO - 2021-09-24 16:17:07 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:17:07 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:17:07 --> Utf8 Class Initialized
INFO - 2021-09-24 16:17:07 --> URI Class Initialized
INFO - 2021-09-24 16:17:07 --> Router Class Initialized
INFO - 2021-09-24 16:17:07 --> Output Class Initialized
INFO - 2021-09-24 16:17:07 --> Security Class Initialized
DEBUG - 2021-09-24 16:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:17:07 --> Input Class Initialized
INFO - 2021-09-24 16:17:07 --> Language Class Initialized
INFO - 2021-09-24 16:17:07 --> Loader Class Initialized
INFO - 2021-09-24 16:17:07 --> Helper loaded: url_helper
INFO - 2021-09-24 16:17:07 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:17:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:17:07 --> Controller Class Initialized
INFO - 2021-09-24 16:17:07 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:17:07 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:17:07 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:17:07 --> Database Driver Class Initialized
INFO - 2021-09-24 16:17:07 --> Helper loaded: string_helper
INFO - 2021-09-24 16:17:07 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:17:07 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:17:07 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:17:07 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:17:07 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:17:07 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 16:17:07 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:17:07 --> Final output sent to browser
DEBUG - 2021-09-24 16:17:07 --> Total execution time: 0.0475
INFO - 2021-09-24 16:17:21 --> Config Class Initialized
INFO - 2021-09-24 16:17:21 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:17:21 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:17:21 --> Utf8 Class Initialized
INFO - 2021-09-24 16:17:21 --> URI Class Initialized
INFO - 2021-09-24 16:17:21 --> Router Class Initialized
INFO - 2021-09-24 16:17:21 --> Output Class Initialized
INFO - 2021-09-24 16:17:21 --> Security Class Initialized
DEBUG - 2021-09-24 16:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:17:21 --> Input Class Initialized
INFO - 2021-09-24 16:17:21 --> Language Class Initialized
INFO - 2021-09-24 16:17:21 --> Loader Class Initialized
INFO - 2021-09-24 16:17:21 --> Helper loaded: url_helper
INFO - 2021-09-24 16:17:21 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:17:21 --> Controller Class Initialized
INFO - 2021-09-24 16:17:21 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:17:21 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:17:21 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:17:21 --> Database Driver Class Initialized
INFO - 2021-09-24 16:17:21 --> Helper loaded: string_helper
INFO - 2021-09-24 16:17:21 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:17:21 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:17:21 --> Config Class Initialized
INFO - 2021-09-24 16:17:21 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:17:21 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:17:21 --> Utf8 Class Initialized
INFO - 2021-09-24 16:17:21 --> URI Class Initialized
INFO - 2021-09-24 16:17:21 --> Router Class Initialized
INFO - 2021-09-24 16:17:21 --> Output Class Initialized
INFO - 2021-09-24 16:17:21 --> Security Class Initialized
DEBUG - 2021-09-24 16:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:17:21 --> Input Class Initialized
INFO - 2021-09-24 16:17:21 --> Language Class Initialized
INFO - 2021-09-24 16:17:21 --> Loader Class Initialized
INFO - 2021-09-24 16:17:21 --> Helper loaded: url_helper
INFO - 2021-09-24 16:17:21 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:17:21 --> Controller Class Initialized
INFO - 2021-09-24 16:17:21 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:17:21 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:17:21 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:17:21 --> Database Driver Class Initialized
INFO - 2021-09-24 16:17:21 --> Helper loaded: string_helper
INFO - 2021-09-24 16:17:21 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:17:21 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:17:21 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:17:21 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:17:21 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:17:21 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonials.php
INFO - 2021-09-24 16:17:21 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:17:21 --> Final output sent to browser
DEBUG - 2021-09-24 16:17:21 --> Total execution time: 0.0464
INFO - 2021-09-24 16:17:22 --> Config Class Initialized
INFO - 2021-09-24 16:17:22 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:17:22 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:17:22 --> Utf8 Class Initialized
INFO - 2021-09-24 16:17:22 --> URI Class Initialized
INFO - 2021-09-24 16:17:22 --> Router Class Initialized
INFO - 2021-09-24 16:17:22 --> Output Class Initialized
INFO - 2021-09-24 16:17:22 --> Security Class Initialized
DEBUG - 2021-09-24 16:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:17:22 --> Input Class Initialized
INFO - 2021-09-24 16:17:22 --> Language Class Initialized
INFO - 2021-09-24 16:17:22 --> Loader Class Initialized
INFO - 2021-09-24 16:17:22 --> Helper loaded: url_helper
INFO - 2021-09-24 16:17:22 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:17:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:17:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:17:22 --> Controller Class Initialized
INFO - 2021-09-24 16:17:22 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:17:22 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:17:22 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:17:22 --> Database Driver Class Initialized
INFO - 2021-09-24 16:17:22 --> Helper loaded: string_helper
INFO - 2021-09-24 16:17:22 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:17:22 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:17:22 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:17:22 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:17:22 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:17:22 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 16:17:22 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:17:22 --> Final output sent to browser
DEBUG - 2021-09-24 16:17:22 --> Total execution time: 0.0505
INFO - 2021-09-24 16:17:38 --> Config Class Initialized
INFO - 2021-09-24 16:17:38 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:17:38 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:17:38 --> Utf8 Class Initialized
INFO - 2021-09-24 16:17:38 --> URI Class Initialized
INFO - 2021-09-24 16:17:38 --> Router Class Initialized
INFO - 2021-09-24 16:17:38 --> Output Class Initialized
INFO - 2021-09-24 16:17:38 --> Security Class Initialized
DEBUG - 2021-09-24 16:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:17:38 --> Input Class Initialized
INFO - 2021-09-24 16:17:38 --> Language Class Initialized
INFO - 2021-09-24 16:17:38 --> Loader Class Initialized
INFO - 2021-09-24 16:17:38 --> Helper loaded: url_helper
INFO - 2021-09-24 16:17:38 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:17:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:17:38 --> Controller Class Initialized
INFO - 2021-09-24 16:17:38 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:17:38 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:17:38 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:17:38 --> Database Driver Class Initialized
INFO - 2021-09-24 16:17:38 --> Helper loaded: string_helper
INFO - 2021-09-24 16:17:38 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:17:38 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:17:38 --> Config Class Initialized
INFO - 2021-09-24 16:17:38 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:17:38 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:17:38 --> Utf8 Class Initialized
INFO - 2021-09-24 16:17:38 --> URI Class Initialized
INFO - 2021-09-24 16:17:38 --> Router Class Initialized
INFO - 2021-09-24 16:17:38 --> Output Class Initialized
INFO - 2021-09-24 16:17:38 --> Security Class Initialized
DEBUG - 2021-09-24 16:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:17:38 --> Input Class Initialized
INFO - 2021-09-24 16:17:38 --> Language Class Initialized
INFO - 2021-09-24 16:17:38 --> Loader Class Initialized
INFO - 2021-09-24 16:17:38 --> Helper loaded: url_helper
INFO - 2021-09-24 16:17:38 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:17:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:17:38 --> Controller Class Initialized
INFO - 2021-09-24 16:17:38 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:17:38 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:17:38 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:17:38 --> Database Driver Class Initialized
INFO - 2021-09-24 16:17:38 --> Helper loaded: string_helper
INFO - 2021-09-24 16:17:38 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:17:38 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:17:38 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:17:38 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:17:38 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:17:38 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonials.php
INFO - 2021-09-24 16:17:38 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:17:38 --> Final output sent to browser
DEBUG - 2021-09-24 16:17:38 --> Total execution time: 0.0496
INFO - 2021-09-24 16:17:40 --> Config Class Initialized
INFO - 2021-09-24 16:17:40 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:17:40 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:17:40 --> Utf8 Class Initialized
INFO - 2021-09-24 16:17:40 --> URI Class Initialized
INFO - 2021-09-24 16:17:40 --> Router Class Initialized
INFO - 2021-09-24 16:17:40 --> Output Class Initialized
INFO - 2021-09-24 16:17:40 --> Security Class Initialized
DEBUG - 2021-09-24 16:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:17:40 --> Input Class Initialized
INFO - 2021-09-24 16:17:40 --> Language Class Initialized
INFO - 2021-09-24 16:17:40 --> Loader Class Initialized
INFO - 2021-09-24 16:17:40 --> Helper loaded: url_helper
INFO - 2021-09-24 16:17:40 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:17:40 --> Controller Class Initialized
INFO - 2021-09-24 16:17:40 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:17:40 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:17:40 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:17:40 --> Database Driver Class Initialized
INFO - 2021-09-24 16:17:40 --> Helper loaded: string_helper
INFO - 2021-09-24 16:17:40 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:17:40 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:17:40 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:17:40 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:17:40 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:17:40 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 16:17:40 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:17:40 --> Final output sent to browser
DEBUG - 2021-09-24 16:17:40 --> Total execution time: 0.0512
INFO - 2021-09-24 16:17:57 --> Config Class Initialized
INFO - 2021-09-24 16:17:57 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:17:57 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:17:57 --> Utf8 Class Initialized
INFO - 2021-09-24 16:17:57 --> URI Class Initialized
INFO - 2021-09-24 16:17:57 --> Router Class Initialized
INFO - 2021-09-24 16:17:57 --> Output Class Initialized
INFO - 2021-09-24 16:17:57 --> Security Class Initialized
DEBUG - 2021-09-24 16:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:17:57 --> Input Class Initialized
INFO - 2021-09-24 16:17:57 --> Language Class Initialized
INFO - 2021-09-24 16:17:57 --> Loader Class Initialized
INFO - 2021-09-24 16:17:57 --> Helper loaded: url_helper
INFO - 2021-09-24 16:17:57 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:17:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:17:57 --> Controller Class Initialized
INFO - 2021-09-24 16:17:57 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:17:57 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:17:57 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:17:57 --> Database Driver Class Initialized
INFO - 2021-09-24 16:17:57 --> Helper loaded: string_helper
INFO - 2021-09-24 16:17:57 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:17:57 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:17:57 --> Config Class Initialized
INFO - 2021-09-24 16:17:57 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:17:57 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:17:57 --> Utf8 Class Initialized
INFO - 2021-09-24 16:17:57 --> URI Class Initialized
INFO - 2021-09-24 16:17:57 --> Router Class Initialized
INFO - 2021-09-24 16:17:57 --> Output Class Initialized
INFO - 2021-09-24 16:17:57 --> Security Class Initialized
DEBUG - 2021-09-24 16:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:17:57 --> Input Class Initialized
INFO - 2021-09-24 16:17:57 --> Language Class Initialized
INFO - 2021-09-24 16:17:57 --> Loader Class Initialized
INFO - 2021-09-24 16:17:57 --> Helper loaded: url_helper
INFO - 2021-09-24 16:17:57 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:17:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:17:57 --> Controller Class Initialized
INFO - 2021-09-24 16:17:57 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:17:57 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:17:57 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:17:57 --> Database Driver Class Initialized
INFO - 2021-09-24 16:17:57 --> Helper loaded: string_helper
INFO - 2021-09-24 16:17:57 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:17:57 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:17:57 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:17:57 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:17:57 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:17:57 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonials.php
INFO - 2021-09-24 16:17:57 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:17:57 --> Final output sent to browser
DEBUG - 2021-09-24 16:17:57 --> Total execution time: 0.0425
INFO - 2021-09-24 16:18:18 --> Config Class Initialized
INFO - 2021-09-24 16:18:18 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:18:18 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:18:18 --> Utf8 Class Initialized
INFO - 2021-09-24 16:18:18 --> URI Class Initialized
DEBUG - 2021-09-24 16:18:18 --> No URI present. Default controller set.
INFO - 2021-09-24 16:18:18 --> Router Class Initialized
INFO - 2021-09-24 16:18:18 --> Output Class Initialized
INFO - 2021-09-24 16:18:18 --> Security Class Initialized
DEBUG - 2021-09-24 16:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:18:18 --> Input Class Initialized
INFO - 2021-09-24 16:18:18 --> Language Class Initialized
INFO - 2021-09-24 16:18:18 --> Loader Class Initialized
INFO - 2021-09-24 16:18:18 --> Helper loaded: url_helper
INFO - 2021-09-24 16:18:18 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:18:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:18:18 --> Controller Class Initialized
INFO - 2021-09-24 16:18:18 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:18:18 --> Model "CookieModel" initialized
INFO - 2021-09-24 16:18:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 16:18:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-09-24 16:18:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 16:18:18 --> Final output sent to browser
DEBUG - 2021-09-24 16:18:18 --> Total execution time: 0.1233
INFO - 2021-09-24 16:18:24 --> Config Class Initialized
INFO - 2021-09-24 16:18:24 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:18:24 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:18:24 --> Utf8 Class Initialized
INFO - 2021-09-24 16:18:24 --> URI Class Initialized
INFO - 2021-09-24 16:18:24 --> Router Class Initialized
INFO - 2021-09-24 16:18:24 --> Output Class Initialized
INFO - 2021-09-24 16:18:24 --> Security Class Initialized
DEBUG - 2021-09-24 16:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:18:24 --> Input Class Initialized
INFO - 2021-09-24 16:18:24 --> Language Class Initialized
INFO - 2021-09-24 16:18:24 --> Loader Class Initialized
INFO - 2021-09-24 16:18:24 --> Helper loaded: url_helper
INFO - 2021-09-24 16:18:24 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:18:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:18:24 --> Controller Class Initialized
INFO - 2021-09-24 16:18:24 --> Database Driver Class Initialized
INFO - 2021-09-24 16:18:24 --> Helper loaded: string_helper
INFO - 2021-09-24 16:18:24 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:18:24 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:18:24 --> Model "CookieModel" initialized
INFO - 2021-09-24 16:18:24 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 16:18:24 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/testimonials.php
INFO - 2021-09-24 16:18:24 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 16:18:24 --> Final output sent to browser
DEBUG - 2021-09-24 16:18:24 --> Total execution time: 0.0825
INFO - 2021-09-24 16:20:47 --> Config Class Initialized
INFO - 2021-09-24 16:20:47 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:20:47 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:20:47 --> Utf8 Class Initialized
INFO - 2021-09-24 16:20:47 --> URI Class Initialized
INFO - 2021-09-24 16:20:47 --> Router Class Initialized
INFO - 2021-09-24 16:20:47 --> Output Class Initialized
INFO - 2021-09-24 16:20:47 --> Security Class Initialized
DEBUG - 2021-09-24 16:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:20:47 --> Input Class Initialized
INFO - 2021-09-24 16:20:47 --> Language Class Initialized
INFO - 2021-09-24 16:20:47 --> Loader Class Initialized
INFO - 2021-09-24 16:20:47 --> Helper loaded: url_helper
INFO - 2021-09-24 16:20:47 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:20:47 --> Controller Class Initialized
INFO - 2021-09-24 16:20:47 --> Database Driver Class Initialized
INFO - 2021-09-24 16:20:47 --> Helper loaded: string_helper
INFO - 2021-09-24 16:20:47 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:20:47 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:20:47 --> Model "CookieModel" initialized
INFO - 2021-09-24 16:20:47 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 16:20:47 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/testimonials.php
INFO - 2021-09-24 16:20:47 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 16:20:47 --> Final output sent to browser
DEBUG - 2021-09-24 16:20:47 --> Total execution time: 0.0460
INFO - 2021-09-24 16:21:08 --> Config Class Initialized
INFO - 2021-09-24 16:21:08 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:21:08 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:21:08 --> Utf8 Class Initialized
INFO - 2021-09-24 16:21:08 --> URI Class Initialized
INFO - 2021-09-24 16:21:08 --> Router Class Initialized
INFO - 2021-09-24 16:21:08 --> Output Class Initialized
INFO - 2021-09-24 16:21:08 --> Security Class Initialized
DEBUG - 2021-09-24 16:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:21:08 --> Input Class Initialized
INFO - 2021-09-24 16:21:08 --> Language Class Initialized
INFO - 2021-09-24 16:21:08 --> Loader Class Initialized
INFO - 2021-09-24 16:21:08 --> Helper loaded: url_helper
INFO - 2021-09-24 16:21:08 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:21:08 --> Controller Class Initialized
INFO - 2021-09-24 16:21:08 --> Database Driver Class Initialized
INFO - 2021-09-24 16:21:08 --> Helper loaded: string_helper
INFO - 2021-09-24 16:21:08 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:21:08 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:21:08 --> Model "CookieModel" initialized
INFO - 2021-09-24 16:21:08 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 16:21:08 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/testimonials.php
INFO - 2021-09-24 16:21:08 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 16:21:08 --> Final output sent to browser
DEBUG - 2021-09-24 16:21:08 --> Total execution time: 0.0478
INFO - 2021-09-24 16:21:40 --> Config Class Initialized
INFO - 2021-09-24 16:21:40 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:21:40 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:21:40 --> Utf8 Class Initialized
INFO - 2021-09-24 16:21:40 --> URI Class Initialized
INFO - 2021-09-24 16:21:40 --> Router Class Initialized
INFO - 2021-09-24 16:21:40 --> Output Class Initialized
INFO - 2021-09-24 16:21:40 --> Security Class Initialized
DEBUG - 2021-09-24 16:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:21:40 --> Input Class Initialized
INFO - 2021-09-24 16:21:40 --> Language Class Initialized
INFO - 2021-09-24 16:21:40 --> Loader Class Initialized
INFO - 2021-09-24 16:21:40 --> Helper loaded: url_helper
INFO - 2021-09-24 16:21:40 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:21:40 --> Controller Class Initialized
INFO - 2021-09-24 16:21:40 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:21:40 --> Model "CookieModel" initialized
INFO - 2021-09-24 16:21:40 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 16:21:40 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/team.php
INFO - 2021-09-24 16:21:40 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 16:21:40 --> Final output sent to browser
DEBUG - 2021-09-24 16:21:40 --> Total execution time: 0.0485
INFO - 2021-09-24 16:21:43 --> Config Class Initialized
INFO - 2021-09-24 16:21:43 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:21:43 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:21:43 --> Utf8 Class Initialized
INFO - 2021-09-24 16:21:43 --> URI Class Initialized
INFO - 2021-09-24 16:21:43 --> Router Class Initialized
INFO - 2021-09-24 16:21:43 --> Output Class Initialized
INFO - 2021-09-24 16:21:43 --> Security Class Initialized
DEBUG - 2021-09-24 16:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:21:43 --> Input Class Initialized
INFO - 2021-09-24 16:21:43 --> Language Class Initialized
INFO - 2021-09-24 16:21:43 --> Loader Class Initialized
INFO - 2021-09-24 16:21:43 --> Helper loaded: url_helper
INFO - 2021-09-24 16:21:43 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:21:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:21:43 --> Controller Class Initialized
INFO - 2021-09-24 16:21:43 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:21:43 --> Model "CookieModel" initialized
ERROR - 2021-09-24 16:21:43 --> Severity: error --> Exception: Unable to locate the model you have specified: ContactModel E:\xampp\htdocs\changeme\system\core\Loader.php 348
INFO - 2021-09-24 16:22:11 --> Config Class Initialized
INFO - 2021-09-24 16:22:11 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:22:11 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:22:11 --> Utf8 Class Initialized
INFO - 2021-09-24 16:22:11 --> URI Class Initialized
INFO - 2021-09-24 16:22:11 --> Router Class Initialized
INFO - 2021-09-24 16:22:11 --> Output Class Initialized
INFO - 2021-09-24 16:22:11 --> Security Class Initialized
DEBUG - 2021-09-24 16:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:22:11 --> Input Class Initialized
INFO - 2021-09-24 16:22:11 --> Language Class Initialized
INFO - 2021-09-24 16:22:11 --> Loader Class Initialized
INFO - 2021-09-24 16:22:11 --> Helper loaded: url_helper
INFO - 2021-09-24 16:22:11 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:22:11 --> Controller Class Initialized
INFO - 2021-09-24 16:22:11 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:22:11 --> Model "CookieModel" initialized
INFO - 2021-09-24 16:22:11 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 16:22:11 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/contact.php
INFO - 2021-09-24 16:22:11 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 16:22:11 --> Final output sent to browser
DEBUG - 2021-09-24 16:22:11 --> Total execution time: 0.0404
INFO - 2021-09-24 16:23:05 --> Config Class Initialized
INFO - 2021-09-24 16:23:05 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:23:05 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:23:05 --> Utf8 Class Initialized
INFO - 2021-09-24 16:23:05 --> URI Class Initialized
INFO - 2021-09-24 16:23:05 --> Router Class Initialized
INFO - 2021-09-24 16:23:05 --> Output Class Initialized
INFO - 2021-09-24 16:23:05 --> Security Class Initialized
DEBUG - 2021-09-24 16:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:23:05 --> Input Class Initialized
INFO - 2021-09-24 16:23:05 --> Language Class Initialized
INFO - 2021-09-24 16:23:05 --> Loader Class Initialized
INFO - 2021-09-24 16:23:05 --> Helper loaded: url_helper
INFO - 2021-09-24 16:23:05 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:23:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:23:05 --> Controller Class Initialized
INFO - 2021-09-24 16:23:05 --> Database Driver Class Initialized
INFO - 2021-09-24 16:23:05 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:23:05 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:23:05 --> Model "CookieModel" initialized
INFO - 2021-09-24 16:23:05 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 16:23:05 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-24 16:23:05 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 16:23:05 --> Final output sent to browser
DEBUG - 2021-09-24 16:23:05 --> Total execution time: 0.0536
INFO - 2021-09-24 16:23:07 --> Config Class Initialized
INFO - 2021-09-24 16:23:07 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:23:07 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:23:07 --> Utf8 Class Initialized
INFO - 2021-09-24 16:23:07 --> URI Class Initialized
INFO - 2021-09-24 16:23:07 --> Router Class Initialized
INFO - 2021-09-24 16:23:07 --> Output Class Initialized
INFO - 2021-09-24 16:23:07 --> Security Class Initialized
DEBUG - 2021-09-24 16:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:23:07 --> Input Class Initialized
INFO - 2021-09-24 16:23:07 --> Language Class Initialized
INFO - 2021-09-24 16:23:07 --> Loader Class Initialized
INFO - 2021-09-24 16:23:07 --> Helper loaded: url_helper
INFO - 2021-09-24 16:23:07 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:23:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:23:07 --> Controller Class Initialized
INFO - 2021-09-24 16:23:07 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:23:07 --> Model "CookieModel" initialized
INFO - 2021-09-24 16:23:07 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 16:23:07 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-09-24 16:23:07 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 16:23:07 --> Final output sent to browser
DEBUG - 2021-09-24 16:23:07 --> Total execution time: 0.0330
INFO - 2021-09-24 16:23:10 --> Config Class Initialized
INFO - 2021-09-24 16:23:10 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:23:10 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:23:10 --> Utf8 Class Initialized
INFO - 2021-09-24 16:23:10 --> URI Class Initialized
INFO - 2021-09-24 16:23:10 --> Router Class Initialized
INFO - 2021-09-24 16:23:10 --> Output Class Initialized
INFO - 2021-09-24 16:23:10 --> Security Class Initialized
DEBUG - 2021-09-24 16:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:23:10 --> Input Class Initialized
INFO - 2021-09-24 16:23:10 --> Language Class Initialized
INFO - 2021-09-24 16:23:10 --> Loader Class Initialized
INFO - 2021-09-24 16:23:10 --> Helper loaded: url_helper
INFO - 2021-09-24 16:23:10 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:23:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:23:10 --> Controller Class Initialized
INFO - 2021-09-24 16:23:10 --> Database Driver Class Initialized
INFO - 2021-09-24 16:23:10 --> Helper loaded: string_helper
INFO - 2021-09-24 16:23:10 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:23:10 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:23:10 --> Model "CookieModel" initialized
INFO - 2021-09-24 16:23:10 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 16:23:10 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/testimonials.php
INFO - 2021-09-24 16:23:10 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 16:23:10 --> Final output sent to browser
DEBUG - 2021-09-24 16:23:10 --> Total execution time: 0.0433
INFO - 2021-09-24 16:23:13 --> Config Class Initialized
INFO - 2021-09-24 16:23:13 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:23:13 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:23:13 --> Utf8 Class Initialized
INFO - 2021-09-24 16:23:13 --> URI Class Initialized
INFO - 2021-09-24 16:23:13 --> Router Class Initialized
INFO - 2021-09-24 16:23:13 --> Output Class Initialized
INFO - 2021-09-24 16:23:13 --> Security Class Initialized
DEBUG - 2021-09-24 16:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:23:13 --> Input Class Initialized
INFO - 2021-09-24 16:23:13 --> Language Class Initialized
INFO - 2021-09-24 16:23:13 --> Loader Class Initialized
INFO - 2021-09-24 16:23:13 --> Helper loaded: url_helper
INFO - 2021-09-24 16:23:13 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:23:13 --> Controller Class Initialized
INFO - 2021-09-24 16:23:13 --> Database Driver Class Initialized
INFO - 2021-09-24 16:23:13 --> Helper loaded: string_helper
INFO - 2021-09-24 16:23:13 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:23:13 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:23:13 --> Model "CookieModel" initialized
INFO - 2021-09-24 16:23:13 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 16:23:13 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/videotestimonials.php
INFO - 2021-09-24 16:23:13 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 16:23:13 --> Final output sent to browser
DEBUG - 2021-09-24 16:23:13 --> Total execution time: 0.0433
INFO - 2021-09-24 16:28:19 --> Config Class Initialized
INFO - 2021-09-24 16:28:19 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:28:19 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:28:19 --> Utf8 Class Initialized
INFO - 2021-09-24 16:28:19 --> URI Class Initialized
INFO - 2021-09-24 16:28:19 --> Router Class Initialized
INFO - 2021-09-24 16:28:19 --> Output Class Initialized
INFO - 2021-09-24 16:28:19 --> Security Class Initialized
DEBUG - 2021-09-24 16:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:28:19 --> Input Class Initialized
INFO - 2021-09-24 16:28:19 --> Language Class Initialized
INFO - 2021-09-24 16:28:19 --> Loader Class Initialized
INFO - 2021-09-24 16:28:19 --> Helper loaded: url_helper
INFO - 2021-09-24 16:28:19 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:28:19 --> Controller Class Initialized
INFO - 2021-09-24 16:28:19 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:28:19 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:28:19 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:28:19 --> Database Driver Class Initialized
INFO - 2021-09-24 16:28:19 --> Helper loaded: string_helper
INFO - 2021-09-24 16:28:19 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:28:19 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:28:19 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:28:19 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:28:19 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:28:19 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 16:28:19 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:28:19 --> Final output sent to browser
DEBUG - 2021-09-24 16:28:19 --> Total execution time: 0.0687
INFO - 2021-09-24 16:28:34 --> Config Class Initialized
INFO - 2021-09-24 16:28:34 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:28:34 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:28:34 --> Utf8 Class Initialized
INFO - 2021-09-24 16:28:34 --> URI Class Initialized
INFO - 2021-09-24 16:28:34 --> Router Class Initialized
INFO - 2021-09-24 16:28:34 --> Output Class Initialized
INFO - 2021-09-24 16:28:34 --> Security Class Initialized
DEBUG - 2021-09-24 16:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:28:34 --> Input Class Initialized
INFO - 2021-09-24 16:28:34 --> Language Class Initialized
INFO - 2021-09-24 16:28:34 --> Loader Class Initialized
INFO - 2021-09-24 16:28:34 --> Helper loaded: url_helper
INFO - 2021-09-24 16:28:34 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:28:34 --> Controller Class Initialized
INFO - 2021-09-24 16:28:34 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:28:34 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:28:34 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:28:34 --> Database Driver Class Initialized
INFO - 2021-09-24 16:28:34 --> Helper loaded: string_helper
INFO - 2021-09-24 16:28:34 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:28:34 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:28:34 --> Config Class Initialized
INFO - 2021-09-24 16:28:34 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:28:34 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:28:34 --> Utf8 Class Initialized
INFO - 2021-09-24 16:28:34 --> URI Class Initialized
INFO - 2021-09-24 16:28:34 --> Router Class Initialized
INFO - 2021-09-24 16:28:34 --> Output Class Initialized
INFO - 2021-09-24 16:28:34 --> Security Class Initialized
DEBUG - 2021-09-24 16:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:28:34 --> Input Class Initialized
INFO - 2021-09-24 16:28:34 --> Language Class Initialized
INFO - 2021-09-24 16:28:34 --> Loader Class Initialized
INFO - 2021-09-24 16:28:34 --> Helper loaded: url_helper
INFO - 2021-09-24 16:28:34 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:28:34 --> Controller Class Initialized
INFO - 2021-09-24 16:28:34 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:28:34 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:28:34 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:28:34 --> Database Driver Class Initialized
INFO - 2021-09-24 16:28:34 --> Helper loaded: string_helper
INFO - 2021-09-24 16:28:34 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:28:34 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:28:34 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:28:34 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:28:34 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:28:34 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonials.php
INFO - 2021-09-24 16:28:34 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:28:34 --> Final output sent to browser
DEBUG - 2021-09-24 16:28:34 --> Total execution time: 0.0505
INFO - 2021-09-24 16:28:39 --> Config Class Initialized
INFO - 2021-09-24 16:28:39 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:28:39 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:28:39 --> Utf8 Class Initialized
INFO - 2021-09-24 16:28:39 --> URI Class Initialized
INFO - 2021-09-24 16:28:39 --> Router Class Initialized
INFO - 2021-09-24 16:28:39 --> Output Class Initialized
INFO - 2021-09-24 16:28:39 --> Security Class Initialized
DEBUG - 2021-09-24 16:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:28:39 --> Input Class Initialized
INFO - 2021-09-24 16:28:39 --> Language Class Initialized
INFO - 2021-09-24 16:28:39 --> Loader Class Initialized
INFO - 2021-09-24 16:28:39 --> Helper loaded: url_helper
INFO - 2021-09-24 16:28:39 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:28:39 --> Controller Class Initialized
INFO - 2021-09-24 16:28:39 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:28:39 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:28:39 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:28:39 --> Database Driver Class Initialized
INFO - 2021-09-24 16:28:39 --> Helper loaded: string_helper
INFO - 2021-09-24 16:28:39 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:28:39 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:28:39 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:28:39 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:28:39 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:28:39 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 16:28:39 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:28:39 --> Final output sent to browser
DEBUG - 2021-09-24 16:28:39 --> Total execution time: 0.0449
INFO - 2021-09-24 16:29:00 --> Config Class Initialized
INFO - 2021-09-24 16:29:00 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:29:00 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:29:00 --> Utf8 Class Initialized
INFO - 2021-09-24 16:29:00 --> URI Class Initialized
INFO - 2021-09-24 16:29:00 --> Router Class Initialized
INFO - 2021-09-24 16:29:00 --> Output Class Initialized
INFO - 2021-09-24 16:29:00 --> Security Class Initialized
DEBUG - 2021-09-24 16:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:29:00 --> Input Class Initialized
INFO - 2021-09-24 16:29:00 --> Language Class Initialized
INFO - 2021-09-24 16:29:00 --> Loader Class Initialized
INFO - 2021-09-24 16:29:00 --> Helper loaded: url_helper
INFO - 2021-09-24 16:29:00 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:29:00 --> Controller Class Initialized
INFO - 2021-09-24 16:29:00 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:29:00 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:29:00 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:29:00 --> Database Driver Class Initialized
INFO - 2021-09-24 16:29:00 --> Helper loaded: string_helper
INFO - 2021-09-24 16:29:00 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:29:00 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:29:00 --> Config Class Initialized
INFO - 2021-09-24 16:29:00 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:29:00 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:29:00 --> Utf8 Class Initialized
INFO - 2021-09-24 16:29:00 --> URI Class Initialized
INFO - 2021-09-24 16:29:00 --> Router Class Initialized
INFO - 2021-09-24 16:29:00 --> Output Class Initialized
INFO - 2021-09-24 16:29:00 --> Security Class Initialized
DEBUG - 2021-09-24 16:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:29:00 --> Input Class Initialized
INFO - 2021-09-24 16:29:00 --> Language Class Initialized
INFO - 2021-09-24 16:29:00 --> Loader Class Initialized
INFO - 2021-09-24 16:29:00 --> Helper loaded: url_helper
INFO - 2021-09-24 16:29:00 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:29:00 --> Controller Class Initialized
INFO - 2021-09-24 16:29:00 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:29:00 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:29:00 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:29:00 --> Database Driver Class Initialized
INFO - 2021-09-24 16:29:00 --> Helper loaded: string_helper
INFO - 2021-09-24 16:29:00 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:29:00 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:29:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:29:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:29:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:29:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonials.php
INFO - 2021-09-24 16:29:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:29:00 --> Final output sent to browser
DEBUG - 2021-09-24 16:29:00 --> Total execution time: 0.0546
INFO - 2021-09-24 16:29:39 --> Config Class Initialized
INFO - 2021-09-24 16:29:39 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:29:39 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:29:39 --> Utf8 Class Initialized
INFO - 2021-09-24 16:29:39 --> URI Class Initialized
INFO - 2021-09-24 16:29:39 --> Router Class Initialized
INFO - 2021-09-24 16:29:39 --> Output Class Initialized
INFO - 2021-09-24 16:29:39 --> Security Class Initialized
DEBUG - 2021-09-24 16:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:29:39 --> Input Class Initialized
INFO - 2021-09-24 16:29:39 --> Language Class Initialized
INFO - 2021-09-24 16:29:39 --> Loader Class Initialized
INFO - 2021-09-24 16:29:39 --> Helper loaded: url_helper
INFO - 2021-09-24 16:29:39 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:29:39 --> Controller Class Initialized
INFO - 2021-09-24 16:29:39 --> Database Driver Class Initialized
INFO - 2021-09-24 16:29:39 --> Helper loaded: string_helper
INFO - 2021-09-24 16:29:39 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:29:39 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:29:39 --> Model "CookieModel" initialized
INFO - 2021-09-24 16:29:39 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 16:29:39 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/videotestimonials.php
INFO - 2021-09-24 16:29:39 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 16:29:39 --> Final output sent to browser
DEBUG - 2021-09-24 16:29:39 --> Total execution time: 0.0524
INFO - 2021-09-24 16:31:55 --> Config Class Initialized
INFO - 2021-09-24 16:31:55 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:31:55 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:31:55 --> Utf8 Class Initialized
INFO - 2021-09-24 16:31:55 --> URI Class Initialized
INFO - 2021-09-24 16:31:55 --> Router Class Initialized
INFO - 2021-09-24 16:31:55 --> Output Class Initialized
INFO - 2021-09-24 16:31:55 --> Security Class Initialized
DEBUG - 2021-09-24 16:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:31:55 --> Input Class Initialized
INFO - 2021-09-24 16:31:55 --> Language Class Initialized
INFO - 2021-09-24 16:31:55 --> Loader Class Initialized
INFO - 2021-09-24 16:31:55 --> Helper loaded: url_helper
INFO - 2021-09-24 16:31:55 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:31:55 --> Controller Class Initialized
INFO - 2021-09-24 16:31:55 --> Database Driver Class Initialized
INFO - 2021-09-24 16:31:55 --> Helper loaded: string_helper
INFO - 2021-09-24 16:31:55 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:31:55 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:31:55 --> Model "CookieModel" initialized
INFO - 2021-09-24 16:31:55 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 16:31:55 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/videotestimonials.php
INFO - 2021-09-24 16:31:55 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 16:31:55 --> Final output sent to browser
DEBUG - 2021-09-24 16:31:55 --> Total execution time: 0.0597
INFO - 2021-09-24 16:32:26 --> Config Class Initialized
INFO - 2021-09-24 16:32:26 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:32:26 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:32:26 --> Utf8 Class Initialized
INFO - 2021-09-24 16:32:26 --> URI Class Initialized
INFO - 2021-09-24 16:32:26 --> Router Class Initialized
INFO - 2021-09-24 16:32:26 --> Output Class Initialized
INFO - 2021-09-24 16:32:26 --> Security Class Initialized
DEBUG - 2021-09-24 16:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:32:26 --> Input Class Initialized
INFO - 2021-09-24 16:32:26 --> Language Class Initialized
INFO - 2021-09-24 16:32:26 --> Loader Class Initialized
INFO - 2021-09-24 16:32:26 --> Helper loaded: url_helper
INFO - 2021-09-24 16:32:26 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:32:26 --> Controller Class Initialized
INFO - 2021-09-24 16:32:26 --> Database Driver Class Initialized
INFO - 2021-09-24 16:32:26 --> Helper loaded: string_helper
INFO - 2021-09-24 16:32:26 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:32:26 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:32:26 --> Model "CookieModel" initialized
INFO - 2021-09-24 16:32:26 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 16:32:26 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/videotestimonials.php
INFO - 2021-09-24 16:32:26 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 16:32:26 --> Final output sent to browser
DEBUG - 2021-09-24 16:32:26 --> Total execution time: 0.0465
INFO - 2021-09-24 16:32:35 --> Config Class Initialized
INFO - 2021-09-24 16:32:35 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:32:35 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:32:35 --> Utf8 Class Initialized
INFO - 2021-09-24 16:32:35 --> URI Class Initialized
INFO - 2021-09-24 16:32:35 --> Router Class Initialized
INFO - 2021-09-24 16:32:35 --> Output Class Initialized
INFO - 2021-09-24 16:32:35 --> Security Class Initialized
DEBUG - 2021-09-24 16:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:32:35 --> Input Class Initialized
INFO - 2021-09-24 16:32:35 --> Language Class Initialized
INFO - 2021-09-24 16:32:35 --> Loader Class Initialized
INFO - 2021-09-24 16:32:35 --> Helper loaded: url_helper
INFO - 2021-09-24 16:32:35 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:32:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:32:35 --> Controller Class Initialized
INFO - 2021-09-24 16:32:35 --> Database Driver Class Initialized
INFO - 2021-09-24 16:32:35 --> Helper loaded: string_helper
INFO - 2021-09-24 16:32:35 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:32:35 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:32:35 --> Model "CookieModel" initialized
INFO - 2021-09-24 16:32:35 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 16:32:35 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/videotestimonials.php
INFO - 2021-09-24 16:32:35 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 16:32:35 --> Final output sent to browser
DEBUG - 2021-09-24 16:32:35 --> Total execution time: 0.0464
INFO - 2021-09-24 16:32:37 --> Config Class Initialized
INFO - 2021-09-24 16:32:37 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:32:37 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:32:37 --> Utf8 Class Initialized
INFO - 2021-09-24 16:32:37 --> URI Class Initialized
INFO - 2021-09-24 16:32:37 --> Router Class Initialized
INFO - 2021-09-24 16:32:37 --> Output Class Initialized
INFO - 2021-09-24 16:32:37 --> Security Class Initialized
DEBUG - 2021-09-24 16:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:32:37 --> Input Class Initialized
INFO - 2021-09-24 16:32:37 --> Language Class Initialized
INFO - 2021-09-24 16:32:37 --> Loader Class Initialized
INFO - 2021-09-24 16:32:37 --> Helper loaded: url_helper
INFO - 2021-09-24 16:32:37 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:32:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:32:37 --> Controller Class Initialized
INFO - 2021-09-24 16:32:37 --> Database Driver Class Initialized
INFO - 2021-09-24 16:32:37 --> Helper loaded: string_helper
INFO - 2021-09-24 16:32:37 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:32:37 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:32:37 --> Model "CookieModel" initialized
INFO - 2021-09-24 16:32:37 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 16:32:37 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/videotestimonials.php
INFO - 2021-09-24 16:32:37 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 16:32:37 --> Final output sent to browser
DEBUG - 2021-09-24 16:32:37 --> Total execution time: 0.0424
INFO - 2021-09-24 16:32:46 --> Config Class Initialized
INFO - 2021-09-24 16:32:46 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:32:46 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:32:46 --> Utf8 Class Initialized
INFO - 2021-09-24 16:32:46 --> URI Class Initialized
INFO - 2021-09-24 16:32:46 --> Router Class Initialized
INFO - 2021-09-24 16:32:46 --> Output Class Initialized
INFO - 2021-09-24 16:32:46 --> Security Class Initialized
DEBUG - 2021-09-24 16:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:32:46 --> Input Class Initialized
INFO - 2021-09-24 16:32:46 --> Language Class Initialized
INFO - 2021-09-24 16:32:46 --> Loader Class Initialized
INFO - 2021-09-24 16:32:46 --> Helper loaded: url_helper
INFO - 2021-09-24 16:32:46 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:32:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:32:46 --> Controller Class Initialized
INFO - 2021-09-24 16:32:46 --> Database Driver Class Initialized
INFO - 2021-09-24 16:32:46 --> Helper loaded: string_helper
INFO - 2021-09-24 16:32:46 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:32:46 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:32:46 --> Model "CookieModel" initialized
INFO - 2021-09-24 16:32:46 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 16:32:46 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/videotestimonials.php
INFO - 2021-09-24 16:32:46 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 16:32:46 --> Final output sent to browser
DEBUG - 2021-09-24 16:32:46 --> Total execution time: 0.0711
INFO - 2021-09-24 16:33:04 --> Config Class Initialized
INFO - 2021-09-24 16:33:04 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:33:04 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:33:04 --> Utf8 Class Initialized
INFO - 2021-09-24 16:33:04 --> URI Class Initialized
INFO - 2021-09-24 16:33:04 --> Router Class Initialized
INFO - 2021-09-24 16:33:04 --> Output Class Initialized
INFO - 2021-09-24 16:33:04 --> Security Class Initialized
DEBUG - 2021-09-24 16:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:33:04 --> Input Class Initialized
INFO - 2021-09-24 16:33:04 --> Language Class Initialized
INFO - 2021-09-24 16:33:04 --> Loader Class Initialized
INFO - 2021-09-24 16:33:04 --> Helper loaded: url_helper
INFO - 2021-09-24 16:33:04 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:33:04 --> Controller Class Initialized
INFO - 2021-09-24 16:33:04 --> Database Driver Class Initialized
INFO - 2021-09-24 16:33:04 --> Helper loaded: string_helper
INFO - 2021-09-24 16:33:04 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:33:04 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:33:04 --> Model "CookieModel" initialized
INFO - 2021-09-24 16:33:04 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 16:33:04 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/videotestimonials.php
INFO - 2021-09-24 16:33:04 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 16:33:04 --> Final output sent to browser
DEBUG - 2021-09-24 16:33:04 --> Total execution time: 0.0530
INFO - 2021-09-24 16:33:16 --> Config Class Initialized
INFO - 2021-09-24 16:33:16 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:33:16 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:33:16 --> Utf8 Class Initialized
INFO - 2021-09-24 16:33:16 --> URI Class Initialized
INFO - 2021-09-24 16:33:16 --> Router Class Initialized
INFO - 2021-09-24 16:33:16 --> Output Class Initialized
INFO - 2021-09-24 16:33:16 --> Security Class Initialized
DEBUG - 2021-09-24 16:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:33:16 --> Input Class Initialized
INFO - 2021-09-24 16:33:16 --> Language Class Initialized
INFO - 2021-09-24 16:33:16 --> Loader Class Initialized
INFO - 2021-09-24 16:33:16 --> Helper loaded: url_helper
INFO - 2021-09-24 16:33:16 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:33:16 --> Controller Class Initialized
INFO - 2021-09-24 16:33:16 --> Database Driver Class Initialized
INFO - 2021-09-24 16:33:16 --> Helper loaded: string_helper
INFO - 2021-09-24 16:33:16 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:33:16 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:33:16 --> Model "CookieModel" initialized
INFO - 2021-09-24 16:33:16 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 16:33:16 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/videotestimonials.php
INFO - 2021-09-24 16:33:16 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 16:33:16 --> Final output sent to browser
DEBUG - 2021-09-24 16:33:16 --> Total execution time: 0.0433
INFO - 2021-09-24 16:33:36 --> Config Class Initialized
INFO - 2021-09-24 16:33:36 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:33:36 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:33:36 --> Utf8 Class Initialized
INFO - 2021-09-24 16:33:36 --> URI Class Initialized
INFO - 2021-09-24 16:33:36 --> Router Class Initialized
INFO - 2021-09-24 16:33:36 --> Output Class Initialized
INFO - 2021-09-24 16:33:36 --> Security Class Initialized
DEBUG - 2021-09-24 16:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:33:36 --> Input Class Initialized
INFO - 2021-09-24 16:33:36 --> Language Class Initialized
INFO - 2021-09-24 16:33:36 --> Loader Class Initialized
INFO - 2021-09-24 16:33:36 --> Helper loaded: url_helper
INFO - 2021-09-24 16:33:36 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:33:36 --> Controller Class Initialized
INFO - 2021-09-24 16:33:36 --> Database Driver Class Initialized
INFO - 2021-09-24 16:33:36 --> Helper loaded: string_helper
INFO - 2021-09-24 16:33:36 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:33:36 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:33:36 --> Model "CookieModel" initialized
INFO - 2021-09-24 16:33:36 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 16:33:36 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/videotestimonials.php
INFO - 2021-09-24 16:33:36 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 16:33:36 --> Final output sent to browser
DEBUG - 2021-09-24 16:33:36 --> Total execution time: 0.0452
INFO - 2021-09-24 16:33:41 --> Config Class Initialized
INFO - 2021-09-24 16:33:41 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:33:41 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:33:41 --> Utf8 Class Initialized
INFO - 2021-09-24 16:33:41 --> URI Class Initialized
INFO - 2021-09-24 16:33:41 --> Router Class Initialized
INFO - 2021-09-24 16:33:41 --> Output Class Initialized
INFO - 2021-09-24 16:33:41 --> Security Class Initialized
DEBUG - 2021-09-24 16:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:33:41 --> Input Class Initialized
INFO - 2021-09-24 16:33:41 --> Language Class Initialized
INFO - 2021-09-24 16:33:41 --> Loader Class Initialized
INFO - 2021-09-24 16:33:41 --> Helper loaded: url_helper
INFO - 2021-09-24 16:33:41 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:33:41 --> Controller Class Initialized
INFO - 2021-09-24 16:33:41 --> Database Driver Class Initialized
INFO - 2021-09-24 16:33:41 --> Helper loaded: string_helper
INFO - 2021-09-24 16:33:41 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:33:41 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:33:41 --> Model "CookieModel" initialized
INFO - 2021-09-24 16:33:41 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 16:33:41 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/videotestimonials.php
INFO - 2021-09-24 16:33:41 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 16:33:41 --> Final output sent to browser
DEBUG - 2021-09-24 16:33:41 --> Total execution time: 0.0625
INFO - 2021-09-24 16:33:42 --> Config Class Initialized
INFO - 2021-09-24 16:33:42 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:33:42 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:33:42 --> Utf8 Class Initialized
INFO - 2021-09-24 16:33:42 --> URI Class Initialized
INFO - 2021-09-24 16:33:42 --> Router Class Initialized
INFO - 2021-09-24 16:33:42 --> Output Class Initialized
INFO - 2021-09-24 16:33:42 --> Security Class Initialized
DEBUG - 2021-09-24 16:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:33:42 --> Input Class Initialized
INFO - 2021-09-24 16:33:42 --> Language Class Initialized
INFO - 2021-09-24 16:33:42 --> Loader Class Initialized
INFO - 2021-09-24 16:33:42 --> Helper loaded: url_helper
INFO - 2021-09-24 16:33:42 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:33:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:33:42 --> Controller Class Initialized
INFO - 2021-09-24 16:33:42 --> Database Driver Class Initialized
INFO - 2021-09-24 16:33:42 --> Helper loaded: string_helper
INFO - 2021-09-24 16:33:42 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:33:42 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:33:42 --> Model "CookieModel" initialized
INFO - 2021-09-24 16:33:42 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 16:33:42 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/videotestimonials.php
INFO - 2021-09-24 16:33:42 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 16:33:42 --> Final output sent to browser
DEBUG - 2021-09-24 16:33:42 --> Total execution time: 0.0555
INFO - 2021-09-24 16:35:48 --> Config Class Initialized
INFO - 2021-09-24 16:35:48 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:35:48 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:35:48 --> Utf8 Class Initialized
INFO - 2021-09-24 16:35:48 --> URI Class Initialized
INFO - 2021-09-24 16:35:48 --> Router Class Initialized
INFO - 2021-09-24 16:35:48 --> Output Class Initialized
INFO - 2021-09-24 16:35:48 --> Security Class Initialized
DEBUG - 2021-09-24 16:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:35:48 --> Input Class Initialized
INFO - 2021-09-24 16:35:48 --> Language Class Initialized
INFO - 2021-09-24 16:35:48 --> Loader Class Initialized
INFO - 2021-09-24 16:35:48 --> Helper loaded: url_helper
INFO - 2021-09-24 16:35:48 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:35:48 --> Controller Class Initialized
INFO - 2021-09-24 16:35:48 --> Database Driver Class Initialized
INFO - 2021-09-24 16:35:48 --> Helper loaded: string_helper
INFO - 2021-09-24 16:35:48 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:35:48 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:35:48 --> Model "CookieModel" initialized
INFO - 2021-09-24 16:35:48 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 16:35:48 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/videotestimonials.php
INFO - 2021-09-24 16:35:48 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 16:35:48 --> Final output sent to browser
DEBUG - 2021-09-24 16:35:48 --> Total execution time: 0.0460
INFO - 2021-09-24 16:36:02 --> Config Class Initialized
INFO - 2021-09-24 16:36:02 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:36:02 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:36:02 --> Utf8 Class Initialized
INFO - 2021-09-24 16:36:02 --> URI Class Initialized
INFO - 2021-09-24 16:36:02 --> Router Class Initialized
INFO - 2021-09-24 16:36:02 --> Output Class Initialized
INFO - 2021-09-24 16:36:02 --> Security Class Initialized
DEBUG - 2021-09-24 16:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:36:02 --> Input Class Initialized
INFO - 2021-09-24 16:36:02 --> Language Class Initialized
INFO - 2021-09-24 16:36:02 --> Loader Class Initialized
INFO - 2021-09-24 16:36:02 --> Helper loaded: url_helper
INFO - 2021-09-24 16:36:02 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:36:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:36:02 --> Controller Class Initialized
INFO - 2021-09-24 16:36:02 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:36:02 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:36:02 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:36:02 --> Database Driver Class Initialized
INFO - 2021-09-24 16:36:02 --> Helper loaded: string_helper
INFO - 2021-09-24 16:36:02 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:36:02 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:36:02 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:36:02 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:36:02 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:36:02 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 16:36:02 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:36:02 --> Final output sent to browser
DEBUG - 2021-09-24 16:36:02 --> Total execution time: 0.0494
INFO - 2021-09-24 16:36:35 --> Config Class Initialized
INFO - 2021-09-24 16:36:35 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:36:35 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:36:35 --> Utf8 Class Initialized
INFO - 2021-09-24 16:36:35 --> URI Class Initialized
INFO - 2021-09-24 16:36:35 --> Router Class Initialized
INFO - 2021-09-24 16:36:35 --> Output Class Initialized
INFO - 2021-09-24 16:36:35 --> Security Class Initialized
DEBUG - 2021-09-24 16:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:36:35 --> Input Class Initialized
INFO - 2021-09-24 16:36:35 --> Language Class Initialized
INFO - 2021-09-24 16:36:35 --> Loader Class Initialized
INFO - 2021-09-24 16:36:35 --> Helper loaded: url_helper
INFO - 2021-09-24 16:36:35 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:36:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:36:35 --> Controller Class Initialized
INFO - 2021-09-24 16:36:35 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:36:35 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:36:35 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:36:35 --> Database Driver Class Initialized
INFO - 2021-09-24 16:36:35 --> Helper loaded: string_helper
INFO - 2021-09-24 16:36:35 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:36:35 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:36:35 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:36:35 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:36:35 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:36:35 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 16:36:35 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:36:35 --> Final output sent to browser
DEBUG - 2021-09-24 16:36:35 --> Total execution time: 0.0800
INFO - 2021-09-24 16:37:57 --> Config Class Initialized
INFO - 2021-09-24 16:37:57 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:37:57 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:37:57 --> Utf8 Class Initialized
INFO - 2021-09-24 16:37:57 --> URI Class Initialized
INFO - 2021-09-24 16:37:57 --> Router Class Initialized
INFO - 2021-09-24 16:37:57 --> Output Class Initialized
INFO - 2021-09-24 16:37:57 --> Security Class Initialized
DEBUG - 2021-09-24 16:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:37:57 --> Input Class Initialized
INFO - 2021-09-24 16:37:57 --> Language Class Initialized
INFO - 2021-09-24 16:37:57 --> Loader Class Initialized
INFO - 2021-09-24 16:37:57 --> Helper loaded: url_helper
INFO - 2021-09-24 16:37:57 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:37:57 --> Controller Class Initialized
INFO - 2021-09-24 16:37:57 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:37:57 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:37:57 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:37:57 --> Database Driver Class Initialized
INFO - 2021-09-24 16:37:57 --> Helper loaded: string_helper
INFO - 2021-09-24 16:37:57 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:37:57 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:37:57 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:37:57 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:37:57 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:37:57 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 16:37:57 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:37:57 --> Final output sent to browser
DEBUG - 2021-09-24 16:37:57 --> Total execution time: 0.0515
INFO - 2021-09-24 16:37:59 --> Config Class Initialized
INFO - 2021-09-24 16:37:59 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:37:59 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:37:59 --> Utf8 Class Initialized
INFO - 2021-09-24 16:37:59 --> URI Class Initialized
INFO - 2021-09-24 16:37:59 --> Router Class Initialized
INFO - 2021-09-24 16:37:59 --> Output Class Initialized
INFO - 2021-09-24 16:37:59 --> Security Class Initialized
DEBUG - 2021-09-24 16:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:37:59 --> Input Class Initialized
INFO - 2021-09-24 16:37:59 --> Language Class Initialized
INFO - 2021-09-24 16:37:59 --> Loader Class Initialized
INFO - 2021-09-24 16:37:59 --> Helper loaded: url_helper
INFO - 2021-09-24 16:37:59 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:37:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:37:59 --> Controller Class Initialized
INFO - 2021-09-24 16:37:59 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:37:59 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:37:59 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:37:59 --> Database Driver Class Initialized
INFO - 2021-09-24 16:37:59 --> Helper loaded: string_helper
INFO - 2021-09-24 16:37:59 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:37:59 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:37:59 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:37:59 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:37:59 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:37:59 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 16:37:59 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:37:59 --> Final output sent to browser
DEBUG - 2021-09-24 16:37:59 --> Total execution time: 0.0507
INFO - 2021-09-24 16:38:00 --> Config Class Initialized
INFO - 2021-09-24 16:38:00 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:38:00 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:38:00 --> Utf8 Class Initialized
INFO - 2021-09-24 16:38:00 --> URI Class Initialized
INFO - 2021-09-24 16:38:00 --> Router Class Initialized
INFO - 2021-09-24 16:38:00 --> Output Class Initialized
INFO - 2021-09-24 16:38:00 --> Security Class Initialized
DEBUG - 2021-09-24 16:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:38:00 --> Input Class Initialized
INFO - 2021-09-24 16:38:00 --> Language Class Initialized
INFO - 2021-09-24 16:38:00 --> Loader Class Initialized
INFO - 2021-09-24 16:38:00 --> Helper loaded: url_helper
INFO - 2021-09-24 16:38:00 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:38:00 --> Controller Class Initialized
INFO - 2021-09-24 16:38:00 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:38:00 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:38:00 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:38:00 --> Database Driver Class Initialized
INFO - 2021-09-24 16:38:00 --> Helper loaded: string_helper
INFO - 2021-09-24 16:38:00 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:38:00 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:38:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:38:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:38:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:38:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 16:38:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:38:00 --> Final output sent to browser
DEBUG - 2021-09-24 16:38:00 --> Total execution time: 0.0508
INFO - 2021-09-24 16:38:00 --> Config Class Initialized
INFO - 2021-09-24 16:38:00 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:38:00 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:38:00 --> Utf8 Class Initialized
INFO - 2021-09-24 16:38:00 --> URI Class Initialized
INFO - 2021-09-24 16:38:00 --> Router Class Initialized
INFO - 2021-09-24 16:38:00 --> Output Class Initialized
INFO - 2021-09-24 16:38:00 --> Security Class Initialized
DEBUG - 2021-09-24 16:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:38:00 --> Input Class Initialized
INFO - 2021-09-24 16:38:00 --> Language Class Initialized
INFO - 2021-09-24 16:38:00 --> Loader Class Initialized
INFO - 2021-09-24 16:38:00 --> Helper loaded: url_helper
INFO - 2021-09-24 16:38:00 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:38:00 --> Controller Class Initialized
INFO - 2021-09-24 16:38:00 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:38:00 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:38:00 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:38:00 --> Database Driver Class Initialized
INFO - 2021-09-24 16:38:00 --> Helper loaded: string_helper
INFO - 2021-09-24 16:38:00 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:38:00 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:38:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:38:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:38:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:38:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 16:38:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:38:00 --> Final output sent to browser
DEBUG - 2021-09-24 16:38:00 --> Total execution time: 0.0514
INFO - 2021-09-24 16:38:00 --> Config Class Initialized
INFO - 2021-09-24 16:38:00 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:38:00 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:38:00 --> Utf8 Class Initialized
INFO - 2021-09-24 16:38:00 --> URI Class Initialized
INFO - 2021-09-24 16:38:00 --> Router Class Initialized
INFO - 2021-09-24 16:38:00 --> Output Class Initialized
INFO - 2021-09-24 16:38:00 --> Security Class Initialized
DEBUG - 2021-09-24 16:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:38:00 --> Input Class Initialized
INFO - 2021-09-24 16:38:00 --> Language Class Initialized
INFO - 2021-09-24 16:38:00 --> Loader Class Initialized
INFO - 2021-09-24 16:38:00 --> Helper loaded: url_helper
INFO - 2021-09-24 16:38:00 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:38:00 --> Controller Class Initialized
INFO - 2021-09-24 16:38:00 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:38:00 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:38:00 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:38:00 --> Database Driver Class Initialized
INFO - 2021-09-24 16:38:00 --> Helper loaded: string_helper
INFO - 2021-09-24 16:38:00 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:38:00 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:38:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:38:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:38:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:38:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 16:38:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:38:00 --> Final output sent to browser
DEBUG - 2021-09-24 16:38:00 --> Total execution time: 0.0502
INFO - 2021-09-24 16:38:01 --> Config Class Initialized
INFO - 2021-09-24 16:38:01 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:38:01 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:38:01 --> Utf8 Class Initialized
INFO - 2021-09-24 16:38:01 --> URI Class Initialized
INFO - 2021-09-24 16:38:01 --> Router Class Initialized
INFO - 2021-09-24 16:38:01 --> Output Class Initialized
INFO - 2021-09-24 16:38:01 --> Security Class Initialized
DEBUG - 2021-09-24 16:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:38:01 --> Input Class Initialized
INFO - 2021-09-24 16:38:01 --> Language Class Initialized
INFO - 2021-09-24 16:38:01 --> Loader Class Initialized
INFO - 2021-09-24 16:38:01 --> Helper loaded: url_helper
INFO - 2021-09-24 16:38:01 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:38:01 --> Controller Class Initialized
INFO - 2021-09-24 16:38:01 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:38:01 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:38:01 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:38:01 --> Database Driver Class Initialized
INFO - 2021-09-24 16:38:01 --> Helper loaded: string_helper
INFO - 2021-09-24 16:38:01 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:38:01 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:38:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:38:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:38:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:38:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 16:38:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:38:01 --> Final output sent to browser
DEBUG - 2021-09-24 16:38:01 --> Total execution time: 0.0465
INFO - 2021-09-24 16:38:01 --> Config Class Initialized
INFO - 2021-09-24 16:38:01 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:38:01 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:38:01 --> Utf8 Class Initialized
INFO - 2021-09-24 16:38:01 --> URI Class Initialized
INFO - 2021-09-24 16:38:01 --> Router Class Initialized
INFO - 2021-09-24 16:38:01 --> Output Class Initialized
INFO - 2021-09-24 16:38:01 --> Security Class Initialized
DEBUG - 2021-09-24 16:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:38:01 --> Input Class Initialized
INFO - 2021-09-24 16:38:01 --> Language Class Initialized
INFO - 2021-09-24 16:38:01 --> Loader Class Initialized
INFO - 2021-09-24 16:38:01 --> Helper loaded: url_helper
INFO - 2021-09-24 16:38:01 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:38:01 --> Controller Class Initialized
INFO - 2021-09-24 16:38:01 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:38:01 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:38:01 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:38:01 --> Database Driver Class Initialized
INFO - 2021-09-24 16:38:01 --> Helper loaded: string_helper
INFO - 2021-09-24 16:38:01 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:38:01 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:38:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:38:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:38:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:38:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 16:38:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:38:01 --> Final output sent to browser
DEBUG - 2021-09-24 16:38:01 --> Total execution time: 0.0437
INFO - 2021-09-24 16:38:01 --> Config Class Initialized
INFO - 2021-09-24 16:38:01 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:38:01 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:38:01 --> Utf8 Class Initialized
INFO - 2021-09-24 16:38:01 --> URI Class Initialized
INFO - 2021-09-24 16:38:01 --> Router Class Initialized
INFO - 2021-09-24 16:38:01 --> Output Class Initialized
INFO - 2021-09-24 16:38:01 --> Security Class Initialized
DEBUG - 2021-09-24 16:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:38:01 --> Input Class Initialized
INFO - 2021-09-24 16:38:01 --> Language Class Initialized
INFO - 2021-09-24 16:38:01 --> Loader Class Initialized
INFO - 2021-09-24 16:38:01 --> Helper loaded: url_helper
INFO - 2021-09-24 16:38:01 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:38:01 --> Controller Class Initialized
INFO - 2021-09-24 16:38:01 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:38:01 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:38:01 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:38:01 --> Database Driver Class Initialized
INFO - 2021-09-24 16:38:01 --> Helper loaded: string_helper
INFO - 2021-09-24 16:38:01 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:38:01 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:38:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:38:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:38:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:38:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 16:38:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:38:01 --> Final output sent to browser
DEBUG - 2021-09-24 16:38:01 --> Total execution time: 0.0449
INFO - 2021-09-24 16:38:02 --> Config Class Initialized
INFO - 2021-09-24 16:38:02 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:38:02 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:38:02 --> Utf8 Class Initialized
INFO - 2021-09-24 16:38:02 --> URI Class Initialized
INFO - 2021-09-24 16:38:02 --> Router Class Initialized
INFO - 2021-09-24 16:38:02 --> Output Class Initialized
INFO - 2021-09-24 16:38:02 --> Security Class Initialized
DEBUG - 2021-09-24 16:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:38:02 --> Input Class Initialized
INFO - 2021-09-24 16:38:02 --> Language Class Initialized
INFO - 2021-09-24 16:38:02 --> Loader Class Initialized
INFO - 2021-09-24 16:38:02 --> Helper loaded: url_helper
INFO - 2021-09-24 16:38:02 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:38:02 --> Controller Class Initialized
INFO - 2021-09-24 16:38:02 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:38:02 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:38:02 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:38:02 --> Database Driver Class Initialized
INFO - 2021-09-24 16:38:02 --> Helper loaded: string_helper
INFO - 2021-09-24 16:38:02 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:38:02 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:38:02 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:38:02 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:38:02 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:38:02 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 16:38:02 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:38:02 --> Final output sent to browser
DEBUG - 2021-09-24 16:38:02 --> Total execution time: 0.0486
INFO - 2021-09-24 16:38:02 --> Config Class Initialized
INFO - 2021-09-24 16:38:02 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:38:02 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:38:02 --> Utf8 Class Initialized
INFO - 2021-09-24 16:38:02 --> URI Class Initialized
INFO - 2021-09-24 16:38:02 --> Router Class Initialized
INFO - 2021-09-24 16:38:02 --> Output Class Initialized
INFO - 2021-09-24 16:38:02 --> Security Class Initialized
DEBUG - 2021-09-24 16:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:38:02 --> Input Class Initialized
INFO - 2021-09-24 16:38:02 --> Language Class Initialized
INFO - 2021-09-24 16:38:02 --> Loader Class Initialized
INFO - 2021-09-24 16:38:02 --> Helper loaded: url_helper
INFO - 2021-09-24 16:38:02 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:38:02 --> Controller Class Initialized
INFO - 2021-09-24 16:38:02 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:38:02 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:38:02 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:38:02 --> Database Driver Class Initialized
INFO - 2021-09-24 16:38:02 --> Helper loaded: string_helper
INFO - 2021-09-24 16:38:02 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:38:02 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:38:02 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:38:02 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:38:02 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:38:02 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 16:38:02 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:38:02 --> Final output sent to browser
DEBUG - 2021-09-24 16:38:02 --> Total execution time: 0.0456
INFO - 2021-09-24 16:38:02 --> Config Class Initialized
INFO - 2021-09-24 16:38:02 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:38:02 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:38:02 --> Utf8 Class Initialized
INFO - 2021-09-24 16:38:02 --> URI Class Initialized
INFO - 2021-09-24 16:38:02 --> Router Class Initialized
INFO - 2021-09-24 16:38:02 --> Output Class Initialized
INFO - 2021-09-24 16:38:02 --> Security Class Initialized
DEBUG - 2021-09-24 16:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:38:02 --> Input Class Initialized
INFO - 2021-09-24 16:38:02 --> Language Class Initialized
INFO - 2021-09-24 16:38:02 --> Loader Class Initialized
INFO - 2021-09-24 16:38:02 --> Helper loaded: url_helper
INFO - 2021-09-24 16:38:02 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:38:02 --> Controller Class Initialized
INFO - 2021-09-24 16:38:02 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:38:02 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:38:02 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:38:02 --> Database Driver Class Initialized
INFO - 2021-09-24 16:38:02 --> Helper loaded: string_helper
INFO - 2021-09-24 16:38:02 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:38:02 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:38:02 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:38:02 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:38:02 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:38:02 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 16:38:02 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:38:02 --> Final output sent to browser
DEBUG - 2021-09-24 16:38:02 --> Total execution time: 0.0704
INFO - 2021-09-24 16:38:02 --> Config Class Initialized
INFO - 2021-09-24 16:38:02 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:38:02 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:38:02 --> Utf8 Class Initialized
INFO - 2021-09-24 16:38:02 --> URI Class Initialized
INFO - 2021-09-24 16:38:02 --> Router Class Initialized
INFO - 2021-09-24 16:38:02 --> Output Class Initialized
INFO - 2021-09-24 16:38:02 --> Security Class Initialized
DEBUG - 2021-09-24 16:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:38:02 --> Input Class Initialized
INFO - 2021-09-24 16:38:02 --> Language Class Initialized
INFO - 2021-09-24 16:38:02 --> Loader Class Initialized
INFO - 2021-09-24 16:38:02 --> Helper loaded: url_helper
INFO - 2021-09-24 16:38:02 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:38:02 --> Controller Class Initialized
INFO - 2021-09-24 16:38:02 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:38:02 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:38:02 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:38:02 --> Database Driver Class Initialized
INFO - 2021-09-24 16:38:02 --> Helper loaded: string_helper
INFO - 2021-09-24 16:38:02 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:38:02 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:38:02 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:38:02 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:38:02 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:38:02 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 16:38:02 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:38:02 --> Final output sent to browser
DEBUG - 2021-09-24 16:38:02 --> Total execution time: 0.0586
INFO - 2021-09-24 16:38:03 --> Config Class Initialized
INFO - 2021-09-24 16:38:03 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:38:03 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:38:03 --> Utf8 Class Initialized
INFO - 2021-09-24 16:38:03 --> URI Class Initialized
INFO - 2021-09-24 16:38:03 --> Router Class Initialized
INFO - 2021-09-24 16:38:03 --> Output Class Initialized
INFO - 2021-09-24 16:38:03 --> Security Class Initialized
DEBUG - 2021-09-24 16:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:38:03 --> Input Class Initialized
INFO - 2021-09-24 16:38:03 --> Language Class Initialized
INFO - 2021-09-24 16:38:03 --> Loader Class Initialized
INFO - 2021-09-24 16:38:03 --> Helper loaded: url_helper
INFO - 2021-09-24 16:38:03 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:38:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:38:03 --> Controller Class Initialized
INFO - 2021-09-24 16:38:03 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:38:03 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:38:03 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:38:03 --> Database Driver Class Initialized
INFO - 2021-09-24 16:38:03 --> Helper loaded: string_helper
INFO - 2021-09-24 16:38:03 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:38:03 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:38:03 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:38:03 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:38:03 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:38:03 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 16:38:03 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:38:03 --> Final output sent to browser
DEBUG - 2021-09-24 16:38:03 --> Total execution time: 0.0454
INFO - 2021-09-24 16:38:04 --> Config Class Initialized
INFO - 2021-09-24 16:38:04 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:38:04 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:38:04 --> Utf8 Class Initialized
INFO - 2021-09-24 16:38:04 --> URI Class Initialized
INFO - 2021-09-24 16:38:04 --> Router Class Initialized
INFO - 2021-09-24 16:38:04 --> Output Class Initialized
INFO - 2021-09-24 16:38:04 --> Security Class Initialized
DEBUG - 2021-09-24 16:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:38:04 --> Input Class Initialized
INFO - 2021-09-24 16:38:04 --> Language Class Initialized
INFO - 2021-09-24 16:38:04 --> Loader Class Initialized
INFO - 2021-09-24 16:38:04 --> Helper loaded: url_helper
INFO - 2021-09-24 16:38:04 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:38:04 --> Controller Class Initialized
INFO - 2021-09-24 16:38:04 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:38:04 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:38:04 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:38:04 --> Database Driver Class Initialized
INFO - 2021-09-24 16:38:04 --> Helper loaded: string_helper
INFO - 2021-09-24 16:38:04 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:38:04 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:38:04 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:38:04 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:38:04 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:38:04 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 16:38:04 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:38:04 --> Final output sent to browser
DEBUG - 2021-09-24 16:38:04 --> Total execution time: 0.0432
INFO - 2021-09-24 16:57:46 --> Config Class Initialized
INFO - 2021-09-24 16:57:46 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:57:46 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:57:46 --> Utf8 Class Initialized
INFO - 2021-09-24 16:57:46 --> URI Class Initialized
INFO - 2021-09-24 16:57:46 --> Router Class Initialized
INFO - 2021-09-24 16:57:46 --> Output Class Initialized
INFO - 2021-09-24 16:57:46 --> Security Class Initialized
DEBUG - 2021-09-24 16:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:57:46 --> Input Class Initialized
INFO - 2021-09-24 16:57:46 --> Language Class Initialized
INFO - 2021-09-24 16:57:46 --> Loader Class Initialized
INFO - 2021-09-24 16:57:46 --> Helper loaded: url_helper
INFO - 2021-09-24 16:57:46 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:57:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:57:46 --> Controller Class Initialized
INFO - 2021-09-24 16:57:46 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:57:46 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:57:46 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:57:46 --> Database Driver Class Initialized
INFO - 2021-09-24 16:57:46 --> Helper loaded: string_helper
INFO - 2021-09-24 16:57:46 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:57:46 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:57:46 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:57:46 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:57:46 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:57:46 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 16:57:46 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:57:46 --> Final output sent to browser
DEBUG - 2021-09-24 16:57:46 --> Total execution time: 0.0705
INFO - 2021-09-24 16:57:48 --> Config Class Initialized
INFO - 2021-09-24 16:57:48 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:57:48 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:57:48 --> Utf8 Class Initialized
INFO - 2021-09-24 16:57:48 --> URI Class Initialized
INFO - 2021-09-24 16:57:48 --> Router Class Initialized
INFO - 2021-09-24 16:57:48 --> Output Class Initialized
INFO - 2021-09-24 16:57:48 --> Security Class Initialized
DEBUG - 2021-09-24 16:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:57:48 --> Input Class Initialized
INFO - 2021-09-24 16:57:48 --> Language Class Initialized
INFO - 2021-09-24 16:57:48 --> Loader Class Initialized
INFO - 2021-09-24 16:57:48 --> Helper loaded: url_helper
INFO - 2021-09-24 16:57:48 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:57:48 --> Controller Class Initialized
INFO - 2021-09-24 16:57:48 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:57:48 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:57:48 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:57:48 --> Database Driver Class Initialized
INFO - 2021-09-24 16:57:48 --> Helper loaded: string_helper
INFO - 2021-09-24 16:57:48 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:57:48 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:57:48 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:57:48 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:57:48 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:57:48 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 16:57:48 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:57:48 --> Final output sent to browser
DEBUG - 2021-09-24 16:57:48 --> Total execution time: 0.0525
INFO - 2021-09-24 16:57:48 --> Config Class Initialized
INFO - 2021-09-24 16:57:48 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:57:48 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:57:48 --> Utf8 Class Initialized
INFO - 2021-09-24 16:57:48 --> URI Class Initialized
INFO - 2021-09-24 16:57:48 --> Router Class Initialized
INFO - 2021-09-24 16:57:48 --> Output Class Initialized
INFO - 2021-09-24 16:57:48 --> Security Class Initialized
DEBUG - 2021-09-24 16:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:57:48 --> Input Class Initialized
INFO - 2021-09-24 16:57:48 --> Language Class Initialized
INFO - 2021-09-24 16:57:48 --> Loader Class Initialized
INFO - 2021-09-24 16:57:48 --> Helper loaded: url_helper
INFO - 2021-09-24 16:57:48 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:57:48 --> Controller Class Initialized
INFO - 2021-09-24 16:57:48 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:57:48 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:57:48 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:57:48 --> Database Driver Class Initialized
INFO - 2021-09-24 16:57:48 --> Helper loaded: string_helper
INFO - 2021-09-24 16:57:48 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:57:48 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:57:48 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:57:48 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:57:48 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:57:48 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 16:57:48 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:57:48 --> Final output sent to browser
DEBUG - 2021-09-24 16:57:48 --> Total execution time: 0.0482
INFO - 2021-09-24 16:57:49 --> Config Class Initialized
INFO - 2021-09-24 16:57:49 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:57:49 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:57:49 --> Utf8 Class Initialized
INFO - 2021-09-24 16:57:49 --> URI Class Initialized
INFO - 2021-09-24 16:57:49 --> Router Class Initialized
INFO - 2021-09-24 16:57:49 --> Output Class Initialized
INFO - 2021-09-24 16:57:49 --> Security Class Initialized
DEBUG - 2021-09-24 16:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:57:49 --> Input Class Initialized
INFO - 2021-09-24 16:57:49 --> Language Class Initialized
INFO - 2021-09-24 16:57:49 --> Loader Class Initialized
INFO - 2021-09-24 16:57:49 --> Helper loaded: url_helper
INFO - 2021-09-24 16:57:49 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:57:49 --> Controller Class Initialized
INFO - 2021-09-24 16:57:49 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:57:49 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:57:49 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:57:49 --> Database Driver Class Initialized
INFO - 2021-09-24 16:57:49 --> Helper loaded: string_helper
INFO - 2021-09-24 16:57:49 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:57:49 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:57:49 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:57:49 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:57:49 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:57:49 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 16:57:49 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:57:49 --> Final output sent to browser
DEBUG - 2021-09-24 16:57:49 --> Total execution time: 0.0469
INFO - 2021-09-24 16:57:49 --> Config Class Initialized
INFO - 2021-09-24 16:57:49 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:57:49 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:57:49 --> Utf8 Class Initialized
INFO - 2021-09-24 16:57:49 --> URI Class Initialized
INFO - 2021-09-24 16:57:49 --> Router Class Initialized
INFO - 2021-09-24 16:57:49 --> Output Class Initialized
INFO - 2021-09-24 16:57:49 --> Security Class Initialized
DEBUG - 2021-09-24 16:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:57:49 --> Input Class Initialized
INFO - 2021-09-24 16:57:49 --> Language Class Initialized
INFO - 2021-09-24 16:57:49 --> Loader Class Initialized
INFO - 2021-09-24 16:57:49 --> Helper loaded: url_helper
INFO - 2021-09-24 16:57:49 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:57:49 --> Controller Class Initialized
INFO - 2021-09-24 16:57:49 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:57:49 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:57:49 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:57:49 --> Database Driver Class Initialized
INFO - 2021-09-24 16:57:49 --> Helper loaded: string_helper
INFO - 2021-09-24 16:57:49 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:57:49 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:57:49 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:57:49 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:57:49 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:57:49 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 16:57:49 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:57:49 --> Final output sent to browser
DEBUG - 2021-09-24 16:57:49 --> Total execution time: 0.0689
INFO - 2021-09-24 16:57:49 --> Config Class Initialized
INFO - 2021-09-24 16:57:49 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:57:49 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:57:49 --> Utf8 Class Initialized
INFO - 2021-09-24 16:57:49 --> URI Class Initialized
INFO - 2021-09-24 16:57:49 --> Router Class Initialized
INFO - 2021-09-24 16:57:49 --> Output Class Initialized
INFO - 2021-09-24 16:57:49 --> Security Class Initialized
DEBUG - 2021-09-24 16:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:57:49 --> Input Class Initialized
INFO - 2021-09-24 16:57:49 --> Language Class Initialized
INFO - 2021-09-24 16:57:49 --> Loader Class Initialized
INFO - 2021-09-24 16:57:49 --> Helper loaded: url_helper
INFO - 2021-09-24 16:57:49 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:57:49 --> Controller Class Initialized
INFO - 2021-09-24 16:57:49 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:57:49 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:57:49 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:57:49 --> Database Driver Class Initialized
INFO - 2021-09-24 16:57:49 --> Helper loaded: string_helper
INFO - 2021-09-24 16:57:49 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:57:49 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:57:49 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:57:49 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:57:49 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:57:49 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 16:57:49 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:57:49 --> Final output sent to browser
DEBUG - 2021-09-24 16:57:49 --> Total execution time: 0.0450
INFO - 2021-09-24 16:57:50 --> Config Class Initialized
INFO - 2021-09-24 16:57:50 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:57:50 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:57:50 --> Utf8 Class Initialized
INFO - 2021-09-24 16:57:50 --> URI Class Initialized
INFO - 2021-09-24 16:57:50 --> Router Class Initialized
INFO - 2021-09-24 16:57:50 --> Output Class Initialized
INFO - 2021-09-24 16:57:50 --> Security Class Initialized
DEBUG - 2021-09-24 16:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:57:50 --> Input Class Initialized
INFO - 2021-09-24 16:57:50 --> Language Class Initialized
INFO - 2021-09-24 16:57:50 --> Loader Class Initialized
INFO - 2021-09-24 16:57:50 --> Helper loaded: url_helper
INFO - 2021-09-24 16:57:50 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:57:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:57:50 --> Controller Class Initialized
INFO - 2021-09-24 16:57:50 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:57:50 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:57:50 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:57:50 --> Database Driver Class Initialized
INFO - 2021-09-24 16:57:50 --> Helper loaded: string_helper
INFO - 2021-09-24 16:57:50 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:57:50 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:57:50 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:57:50 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:57:50 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:57:50 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 16:57:50 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:57:50 --> Final output sent to browser
DEBUG - 2021-09-24 16:57:50 --> Total execution time: 0.0659
INFO - 2021-09-24 16:57:50 --> Config Class Initialized
INFO - 2021-09-24 16:57:50 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:57:50 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:57:50 --> Utf8 Class Initialized
INFO - 2021-09-24 16:57:50 --> URI Class Initialized
INFO - 2021-09-24 16:57:50 --> Router Class Initialized
INFO - 2021-09-24 16:57:50 --> Output Class Initialized
INFO - 2021-09-24 16:57:50 --> Security Class Initialized
DEBUG - 2021-09-24 16:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:57:50 --> Input Class Initialized
INFO - 2021-09-24 16:57:50 --> Language Class Initialized
INFO - 2021-09-24 16:57:50 --> Loader Class Initialized
INFO - 2021-09-24 16:57:50 --> Helper loaded: url_helper
INFO - 2021-09-24 16:57:50 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:57:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:57:50 --> Controller Class Initialized
INFO - 2021-09-24 16:57:50 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:57:50 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:57:50 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:57:50 --> Database Driver Class Initialized
INFO - 2021-09-24 16:57:50 --> Helper loaded: string_helper
INFO - 2021-09-24 16:57:50 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:57:50 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:57:50 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:57:50 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:57:50 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:57:50 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 16:57:50 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:57:50 --> Final output sent to browser
DEBUG - 2021-09-24 16:57:50 --> Total execution time: 0.0471
INFO - 2021-09-24 16:57:52 --> Config Class Initialized
INFO - 2021-09-24 16:57:52 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:57:52 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:57:52 --> Utf8 Class Initialized
INFO - 2021-09-24 16:57:52 --> URI Class Initialized
INFO - 2021-09-24 16:57:52 --> Router Class Initialized
INFO - 2021-09-24 16:57:52 --> Output Class Initialized
INFO - 2021-09-24 16:57:52 --> Security Class Initialized
DEBUG - 2021-09-24 16:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:57:52 --> Input Class Initialized
INFO - 2021-09-24 16:57:52 --> Language Class Initialized
INFO - 2021-09-24 16:57:52 --> Loader Class Initialized
INFO - 2021-09-24 16:57:52 --> Helper loaded: url_helper
INFO - 2021-09-24 16:57:52 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:57:52 --> Controller Class Initialized
INFO - 2021-09-24 16:57:52 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:57:52 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:57:52 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:57:52 --> Database Driver Class Initialized
INFO - 2021-09-24 16:57:52 --> Helper loaded: string_helper
INFO - 2021-09-24 16:57:52 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:57:52 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:57:52 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:57:52 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:57:52 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:57:52 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 16:57:52 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:57:52 --> Final output sent to browser
DEBUG - 2021-09-24 16:57:52 --> Total execution time: 0.0471
INFO - 2021-09-24 16:58:19 --> Config Class Initialized
INFO - 2021-09-24 16:58:19 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:58:19 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:58:19 --> Utf8 Class Initialized
INFO - 2021-09-24 16:58:19 --> URI Class Initialized
INFO - 2021-09-24 16:58:19 --> Router Class Initialized
INFO - 2021-09-24 16:58:19 --> Output Class Initialized
INFO - 2021-09-24 16:58:19 --> Security Class Initialized
DEBUG - 2021-09-24 16:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:58:19 --> Input Class Initialized
INFO - 2021-09-24 16:58:19 --> Language Class Initialized
INFO - 2021-09-24 16:58:19 --> Loader Class Initialized
INFO - 2021-09-24 16:58:19 --> Helper loaded: url_helper
INFO - 2021-09-24 16:58:19 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:58:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:58:19 --> Controller Class Initialized
INFO - 2021-09-24 16:58:19 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:58:19 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:58:19 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:58:19 --> Database Driver Class Initialized
INFO - 2021-09-24 16:58:19 --> Helper loaded: string_helper
INFO - 2021-09-24 16:58:19 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:58:19 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:58:19 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:58:19 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:58:19 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:58:19 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 16:58:19 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:58:19 --> Final output sent to browser
DEBUG - 2021-09-24 16:58:19 --> Total execution time: 0.0438
INFO - 2021-09-24 16:58:28 --> Config Class Initialized
INFO - 2021-09-24 16:58:28 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:58:28 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:58:28 --> Utf8 Class Initialized
INFO - 2021-09-24 16:58:28 --> URI Class Initialized
INFO - 2021-09-24 16:58:28 --> Router Class Initialized
INFO - 2021-09-24 16:58:28 --> Output Class Initialized
INFO - 2021-09-24 16:58:28 --> Security Class Initialized
DEBUG - 2021-09-24 16:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:58:28 --> Input Class Initialized
INFO - 2021-09-24 16:58:28 --> Language Class Initialized
INFO - 2021-09-24 16:58:28 --> Loader Class Initialized
INFO - 2021-09-24 16:58:28 --> Helper loaded: url_helper
INFO - 2021-09-24 16:58:28 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:58:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:58:28 --> Controller Class Initialized
INFO - 2021-09-24 16:58:28 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:58:28 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:58:28 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:58:28 --> Database Driver Class Initialized
INFO - 2021-09-24 16:58:28 --> Helper loaded: string_helper
INFO - 2021-09-24 16:58:28 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:58:28 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:58:28 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:58:28 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:58:28 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:58:28 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 16:58:28 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:58:28 --> Final output sent to browser
DEBUG - 2021-09-24 16:58:28 --> Total execution time: 0.0506
INFO - 2021-09-24 16:58:49 --> Config Class Initialized
INFO - 2021-09-24 16:58:49 --> Hooks Class Initialized
DEBUG - 2021-09-24 16:58:49 --> UTF-8 Support Enabled
INFO - 2021-09-24 16:58:49 --> Utf8 Class Initialized
INFO - 2021-09-24 16:58:49 --> URI Class Initialized
INFO - 2021-09-24 16:58:49 --> Router Class Initialized
INFO - 2021-09-24 16:58:49 --> Output Class Initialized
INFO - 2021-09-24 16:58:49 --> Security Class Initialized
DEBUG - 2021-09-24 16:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 16:58:49 --> Input Class Initialized
INFO - 2021-09-24 16:58:49 --> Language Class Initialized
INFO - 2021-09-24 16:58:49 --> Loader Class Initialized
INFO - 2021-09-24 16:58:49 --> Helper loaded: url_helper
INFO - 2021-09-24 16:58:49 --> Helper loaded: file_helper
DEBUG - 2021-09-24 16:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 16:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 16:58:49 --> Controller Class Initialized
INFO - 2021-09-24 16:58:49 --> Model "DBModel" initialized
DEBUG - 2021-09-24 16:58:49 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 16:58:49 --> Helper loaded: cookie_helper
INFO - 2021-09-24 16:58:49 --> Database Driver Class Initialized
INFO - 2021-09-24 16:58:49 --> Helper loaded: string_helper
INFO - 2021-09-24 16:58:49 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 16:58:49 --> Model "BlogModel" initialized
INFO - 2021-09-24 16:58:49 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 16:58:49 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 16:58:49 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 16:58:49 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 16:58:49 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 16:58:49 --> Final output sent to browser
DEBUG - 2021-09-24 16:58:49 --> Total execution time: 0.0641
INFO - 2021-09-24 17:16:06 --> Config Class Initialized
INFO - 2021-09-24 17:16:06 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:16:06 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:16:06 --> Utf8 Class Initialized
INFO - 2021-09-24 17:16:06 --> URI Class Initialized
INFO - 2021-09-24 17:16:06 --> Router Class Initialized
INFO - 2021-09-24 17:16:06 --> Output Class Initialized
INFO - 2021-09-24 17:16:06 --> Security Class Initialized
DEBUG - 2021-09-24 17:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:16:06 --> Input Class Initialized
INFO - 2021-09-24 17:16:06 --> Language Class Initialized
INFO - 2021-09-24 17:16:06 --> Loader Class Initialized
INFO - 2021-09-24 17:16:06 --> Helper loaded: url_helper
INFO - 2021-09-24 17:16:06 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:16:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:16:06 --> Controller Class Initialized
INFO - 2021-09-24 17:16:06 --> Model "DBModel" initialized
DEBUG - 2021-09-24 17:16:06 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 17:16:06 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:16:06 --> Database Driver Class Initialized
INFO - 2021-09-24 17:16:06 --> Helper loaded: string_helper
INFO - 2021-09-24 17:16:06 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 17:16:06 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:16:06 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 17:16:06 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 17:16:06 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 17:16:06 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 17:16:06 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 17:16:06 --> Final output sent to browser
DEBUG - 2021-09-24 17:16:06 --> Total execution time: 0.0662
INFO - 2021-09-24 17:16:14 --> Config Class Initialized
INFO - 2021-09-24 17:16:14 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:16:14 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:16:14 --> Utf8 Class Initialized
INFO - 2021-09-24 17:16:14 --> URI Class Initialized
INFO - 2021-09-24 17:16:14 --> Router Class Initialized
INFO - 2021-09-24 17:16:14 --> Output Class Initialized
INFO - 2021-09-24 17:16:14 --> Security Class Initialized
DEBUG - 2021-09-24 17:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:16:14 --> Input Class Initialized
INFO - 2021-09-24 17:16:14 --> Language Class Initialized
INFO - 2021-09-24 17:16:14 --> Loader Class Initialized
INFO - 2021-09-24 17:16:14 --> Helper loaded: url_helper
INFO - 2021-09-24 17:16:14 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:16:14 --> Controller Class Initialized
INFO - 2021-09-24 17:16:14 --> Model "DBModel" initialized
DEBUG - 2021-09-24 17:16:14 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 17:16:14 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:16:14 --> Database Driver Class Initialized
INFO - 2021-09-24 17:16:14 --> Helper loaded: string_helper
INFO - 2021-09-24 17:16:14 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 17:16:14 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:16:14 --> Config Class Initialized
INFO - 2021-09-24 17:16:14 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:16:14 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:16:14 --> Utf8 Class Initialized
INFO - 2021-09-24 17:16:14 --> URI Class Initialized
INFO - 2021-09-24 17:16:14 --> Router Class Initialized
INFO - 2021-09-24 17:16:14 --> Output Class Initialized
INFO - 2021-09-24 17:16:14 --> Security Class Initialized
DEBUG - 2021-09-24 17:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:16:14 --> Input Class Initialized
INFO - 2021-09-24 17:16:14 --> Language Class Initialized
INFO - 2021-09-24 17:16:14 --> Loader Class Initialized
INFO - 2021-09-24 17:16:14 --> Helper loaded: url_helper
INFO - 2021-09-24 17:16:14 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:16:14 --> Controller Class Initialized
INFO - 2021-09-24 17:16:14 --> Model "DBModel" initialized
DEBUG - 2021-09-24 17:16:14 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 17:16:14 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:16:14 --> Database Driver Class Initialized
INFO - 2021-09-24 17:16:14 --> Helper loaded: string_helper
INFO - 2021-09-24 17:16:14 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 17:16:14 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:16:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 17:16:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 17:16:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 17:16:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonials.php
INFO - 2021-09-24 17:16:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 17:16:14 --> Final output sent to browser
DEBUG - 2021-09-24 17:16:14 --> Total execution time: 0.0694
INFO - 2021-09-24 17:17:08 --> Config Class Initialized
INFO - 2021-09-24 17:17:08 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:17:08 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:17:08 --> Utf8 Class Initialized
INFO - 2021-09-24 17:17:08 --> URI Class Initialized
INFO - 2021-09-24 17:17:08 --> Router Class Initialized
INFO - 2021-09-24 17:17:08 --> Output Class Initialized
INFO - 2021-09-24 17:17:08 --> Security Class Initialized
DEBUG - 2021-09-24 17:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:17:08 --> Input Class Initialized
INFO - 2021-09-24 17:17:08 --> Language Class Initialized
INFO - 2021-09-24 17:17:08 --> Loader Class Initialized
INFO - 2021-09-24 17:17:08 --> Helper loaded: url_helper
INFO - 2021-09-24 17:17:08 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:17:08 --> Controller Class Initialized
INFO - 2021-09-24 17:17:08 --> Model "DBModel" initialized
DEBUG - 2021-09-24 17:17:08 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 17:17:08 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:17:08 --> Database Driver Class Initialized
INFO - 2021-09-24 17:17:08 --> Helper loaded: string_helper
INFO - 2021-09-24 17:17:08 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 17:17:08 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:17:08 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 17:17:08 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 17:17:08 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 17:17:08 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 17:17:08 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 17:17:08 --> Final output sent to browser
DEBUG - 2021-09-24 17:17:08 --> Total execution time: 0.0693
INFO - 2021-09-24 17:17:11 --> Config Class Initialized
INFO - 2021-09-24 17:17:11 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:17:11 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:17:11 --> Utf8 Class Initialized
INFO - 2021-09-24 17:17:11 --> URI Class Initialized
INFO - 2021-09-24 17:17:11 --> Router Class Initialized
INFO - 2021-09-24 17:17:11 --> Output Class Initialized
INFO - 2021-09-24 17:17:11 --> Security Class Initialized
DEBUG - 2021-09-24 17:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:17:11 --> Input Class Initialized
INFO - 2021-09-24 17:17:11 --> Language Class Initialized
INFO - 2021-09-24 17:17:11 --> Loader Class Initialized
INFO - 2021-09-24 17:17:11 --> Helper loaded: url_helper
INFO - 2021-09-24 17:17:11 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:17:11 --> Controller Class Initialized
INFO - 2021-09-24 17:17:11 --> Model "DBModel" initialized
DEBUG - 2021-09-24 17:17:11 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 17:17:11 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:17:11 --> Database Driver Class Initialized
INFO - 2021-09-24 17:17:11 --> Helper loaded: string_helper
INFO - 2021-09-24 17:17:11 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 17:17:11 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:17:12 --> Config Class Initialized
INFO - 2021-09-24 17:17:12 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:17:12 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:17:12 --> Utf8 Class Initialized
INFO - 2021-09-24 17:17:12 --> URI Class Initialized
INFO - 2021-09-24 17:17:12 --> Router Class Initialized
INFO - 2021-09-24 17:17:12 --> Output Class Initialized
INFO - 2021-09-24 17:17:12 --> Security Class Initialized
DEBUG - 2021-09-24 17:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:17:12 --> Input Class Initialized
INFO - 2021-09-24 17:17:12 --> Language Class Initialized
INFO - 2021-09-24 17:17:12 --> Loader Class Initialized
INFO - 2021-09-24 17:17:12 --> Helper loaded: url_helper
INFO - 2021-09-24 17:17:12 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:17:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:17:12 --> Controller Class Initialized
INFO - 2021-09-24 17:17:12 --> Model "DBModel" initialized
DEBUG - 2021-09-24 17:17:12 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 17:17:12 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:17:12 --> Database Driver Class Initialized
INFO - 2021-09-24 17:17:12 --> Helper loaded: string_helper
INFO - 2021-09-24 17:17:12 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 17:17:12 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:17:12 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 17:17:12 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 17:17:12 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 17:17:12 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonials.php
INFO - 2021-09-24 17:17:12 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 17:17:12 --> Final output sent to browser
DEBUG - 2021-09-24 17:17:12 --> Total execution time: 0.0497
INFO - 2021-09-24 17:17:30 --> Config Class Initialized
INFO - 2021-09-24 17:17:30 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:17:30 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:17:30 --> Utf8 Class Initialized
INFO - 2021-09-24 17:17:30 --> URI Class Initialized
INFO - 2021-09-24 17:17:30 --> Router Class Initialized
INFO - 2021-09-24 17:17:30 --> Output Class Initialized
INFO - 2021-09-24 17:17:30 --> Security Class Initialized
DEBUG - 2021-09-24 17:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:17:30 --> Input Class Initialized
INFO - 2021-09-24 17:17:30 --> Language Class Initialized
INFO - 2021-09-24 17:17:30 --> Loader Class Initialized
INFO - 2021-09-24 17:17:30 --> Helper loaded: url_helper
INFO - 2021-09-24 17:17:30 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:17:30 --> Controller Class Initialized
INFO - 2021-09-24 17:17:30 --> Model "DBModel" initialized
DEBUG - 2021-09-24 17:17:30 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 17:17:30 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:17:30 --> Database Driver Class Initialized
INFO - 2021-09-24 17:17:30 --> Helper loaded: string_helper
INFO - 2021-09-24 17:17:30 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 17:17:30 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:17:30 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 17:17:30 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 17:17:30 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 17:17:30 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonials.php
INFO - 2021-09-24 17:17:30 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 17:17:30 --> Final output sent to browser
DEBUG - 2021-09-24 17:17:30 --> Total execution time: 0.0565
INFO - 2021-09-24 17:17:50 --> Config Class Initialized
INFO - 2021-09-24 17:17:50 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:17:50 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:17:50 --> Utf8 Class Initialized
INFO - 2021-09-24 17:17:50 --> URI Class Initialized
INFO - 2021-09-24 17:17:50 --> Router Class Initialized
INFO - 2021-09-24 17:17:50 --> Output Class Initialized
INFO - 2021-09-24 17:17:50 --> Security Class Initialized
DEBUG - 2021-09-24 17:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:17:50 --> Input Class Initialized
INFO - 2021-09-24 17:17:50 --> Language Class Initialized
INFO - 2021-09-24 17:17:50 --> Loader Class Initialized
INFO - 2021-09-24 17:17:50 --> Helper loaded: url_helper
INFO - 2021-09-24 17:17:50 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:17:50 --> Controller Class Initialized
INFO - 2021-09-24 17:17:50 --> Model "DBModel" initialized
DEBUG - 2021-09-24 17:17:50 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 17:17:50 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:17:50 --> Database Driver Class Initialized
INFO - 2021-09-24 17:17:50 --> Helper loaded: string_helper
INFO - 2021-09-24 17:17:50 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 17:17:50 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:17:50 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 17:17:50 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 17:17:50 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 17:17:50 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 17:17:50 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 17:17:50 --> Final output sent to browser
DEBUG - 2021-09-24 17:17:50 --> Total execution time: 0.0527
INFO - 2021-09-24 17:18:41 --> Config Class Initialized
INFO - 2021-09-24 17:18:41 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:18:41 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:18:41 --> Utf8 Class Initialized
INFO - 2021-09-24 17:18:41 --> URI Class Initialized
INFO - 2021-09-24 17:18:41 --> Router Class Initialized
INFO - 2021-09-24 17:18:41 --> Output Class Initialized
INFO - 2021-09-24 17:18:41 --> Security Class Initialized
DEBUG - 2021-09-24 17:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:18:41 --> Input Class Initialized
INFO - 2021-09-24 17:18:41 --> Language Class Initialized
INFO - 2021-09-24 17:18:41 --> Loader Class Initialized
INFO - 2021-09-24 17:18:41 --> Helper loaded: url_helper
INFO - 2021-09-24 17:18:41 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:18:41 --> Controller Class Initialized
INFO - 2021-09-24 17:18:41 --> Model "DBModel" initialized
DEBUG - 2021-09-24 17:18:41 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 17:18:41 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:18:41 --> Database Driver Class Initialized
INFO - 2021-09-24 17:18:41 --> Helper loaded: string_helper
INFO - 2021-09-24 17:18:41 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 17:18:41 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:18:41 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 17:18:41 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 17:18:41 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 17:18:41 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 17:18:41 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 17:18:41 --> Final output sent to browser
DEBUG - 2021-09-24 17:18:41 --> Total execution time: 0.0676
INFO - 2021-09-24 17:18:45 --> Config Class Initialized
INFO - 2021-09-24 17:18:45 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:18:45 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:18:45 --> Utf8 Class Initialized
INFO - 2021-09-24 17:18:45 --> URI Class Initialized
INFO - 2021-09-24 17:18:45 --> Router Class Initialized
INFO - 2021-09-24 17:18:45 --> Output Class Initialized
INFO - 2021-09-24 17:18:45 --> Security Class Initialized
DEBUG - 2021-09-24 17:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:18:45 --> Input Class Initialized
INFO - 2021-09-24 17:18:45 --> Language Class Initialized
INFO - 2021-09-24 17:18:45 --> Loader Class Initialized
INFO - 2021-09-24 17:18:45 --> Helper loaded: url_helper
INFO - 2021-09-24 17:18:45 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:18:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:18:45 --> Controller Class Initialized
INFO - 2021-09-24 17:18:45 --> Model "DBModel" initialized
DEBUG - 2021-09-24 17:18:45 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 17:18:45 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:18:45 --> Database Driver Class Initialized
INFO - 2021-09-24 17:18:45 --> Helper loaded: string_helper
INFO - 2021-09-24 17:18:45 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 17:18:45 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:18:45 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 17:18:45 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 17:18:45 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 17:18:45 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonials.php
INFO - 2021-09-24 17:18:45 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 17:18:45 --> Final output sent to browser
DEBUG - 2021-09-24 17:18:45 --> Total execution time: 0.0580
INFO - 2021-09-24 17:18:51 --> Config Class Initialized
INFO - 2021-09-24 17:18:51 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:18:51 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:18:51 --> Utf8 Class Initialized
INFO - 2021-09-24 17:18:51 --> URI Class Initialized
INFO - 2021-09-24 17:18:51 --> Router Class Initialized
INFO - 2021-09-24 17:18:51 --> Output Class Initialized
INFO - 2021-09-24 17:18:51 --> Security Class Initialized
DEBUG - 2021-09-24 17:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:18:51 --> Input Class Initialized
INFO - 2021-09-24 17:18:51 --> Language Class Initialized
INFO - 2021-09-24 17:18:51 --> Loader Class Initialized
INFO - 2021-09-24 17:18:51 --> Helper loaded: url_helper
INFO - 2021-09-24 17:18:51 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:18:51 --> Controller Class Initialized
INFO - 2021-09-24 17:18:51 --> Model "DBModel" initialized
DEBUG - 2021-09-24 17:18:51 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 17:18:51 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:18:51 --> Database Driver Class Initialized
INFO - 2021-09-24 17:18:51 --> Helper loaded: string_helper
INFO - 2021-09-24 17:18:51 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 17:18:51 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:18:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 17:18:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 17:18:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 17:18:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonials.php
INFO - 2021-09-24 17:18:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 17:18:51 --> Final output sent to browser
DEBUG - 2021-09-24 17:18:51 --> Total execution time: 0.0623
INFO - 2021-09-24 17:19:09 --> Config Class Initialized
INFO - 2021-09-24 17:19:09 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:19:09 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:19:09 --> Utf8 Class Initialized
INFO - 2021-09-24 17:19:09 --> URI Class Initialized
INFO - 2021-09-24 17:19:09 --> Router Class Initialized
INFO - 2021-09-24 17:19:09 --> Output Class Initialized
INFO - 2021-09-24 17:19:09 --> Security Class Initialized
DEBUG - 2021-09-24 17:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:19:09 --> Input Class Initialized
INFO - 2021-09-24 17:19:09 --> Language Class Initialized
INFO - 2021-09-24 17:19:09 --> Loader Class Initialized
INFO - 2021-09-24 17:19:09 --> Helper loaded: url_helper
INFO - 2021-09-24 17:19:09 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:19:09 --> Controller Class Initialized
INFO - 2021-09-24 17:19:09 --> Model "DBModel" initialized
DEBUG - 2021-09-24 17:19:09 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 17:19:09 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:19:09 --> Database Driver Class Initialized
INFO - 2021-09-24 17:19:09 --> Helper loaded: string_helper
INFO - 2021-09-24 17:19:09 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 17:19:09 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:19:09 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 17:19:09 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 17:19:09 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 17:19:09 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonials.php
INFO - 2021-09-24 17:19:09 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 17:19:09 --> Final output sent to browser
DEBUG - 2021-09-24 17:19:09 --> Total execution time: 0.0708
INFO - 2021-09-24 17:19:16 --> Config Class Initialized
INFO - 2021-09-24 17:19:17 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:19:17 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:19:17 --> Utf8 Class Initialized
INFO - 2021-09-24 17:19:17 --> URI Class Initialized
INFO - 2021-09-24 17:19:17 --> Router Class Initialized
INFO - 2021-09-24 17:19:17 --> Output Class Initialized
INFO - 2021-09-24 17:19:17 --> Security Class Initialized
DEBUG - 2021-09-24 17:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:19:17 --> Input Class Initialized
INFO - 2021-09-24 17:19:17 --> Language Class Initialized
INFO - 2021-09-24 17:19:17 --> Loader Class Initialized
INFO - 2021-09-24 17:19:17 --> Helper loaded: url_helper
INFO - 2021-09-24 17:19:17 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:19:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:19:17 --> Controller Class Initialized
INFO - 2021-09-24 17:19:17 --> Model "DBModel" initialized
DEBUG - 2021-09-24 17:19:17 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 17:19:17 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:19:17 --> Database Driver Class Initialized
INFO - 2021-09-24 17:19:17 --> Helper loaded: string_helper
INFO - 2021-09-24 17:19:17 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 17:19:17 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:19:17 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 17:19:17 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 17:19:17 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 17:19:17 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 17:19:17 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 17:19:17 --> Final output sent to browser
DEBUG - 2021-09-24 17:19:17 --> Total execution time: 0.0544
INFO - 2021-09-24 17:19:21 --> Config Class Initialized
INFO - 2021-09-24 17:19:21 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:19:21 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:19:21 --> Utf8 Class Initialized
INFO - 2021-09-24 17:19:22 --> URI Class Initialized
INFO - 2021-09-24 17:19:22 --> Router Class Initialized
INFO - 2021-09-24 17:19:22 --> Output Class Initialized
INFO - 2021-09-24 17:19:22 --> Security Class Initialized
DEBUG - 2021-09-24 17:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:19:22 --> Input Class Initialized
INFO - 2021-09-24 17:19:22 --> Language Class Initialized
INFO - 2021-09-24 17:19:22 --> Loader Class Initialized
INFO - 2021-09-24 17:19:22 --> Helper loaded: url_helper
INFO - 2021-09-24 17:19:22 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:19:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:19:22 --> Controller Class Initialized
INFO - 2021-09-24 17:19:22 --> Model "DBModel" initialized
DEBUG - 2021-09-24 17:19:22 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 17:19:22 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:19:22 --> Database Driver Class Initialized
INFO - 2021-09-24 17:19:22 --> Helper loaded: string_helper
INFO - 2021-09-24 17:19:22 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 17:19:22 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:19:22 --> Config Class Initialized
INFO - 2021-09-24 17:19:22 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:19:22 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:19:22 --> Utf8 Class Initialized
INFO - 2021-09-24 17:19:22 --> URI Class Initialized
INFO - 2021-09-24 17:19:22 --> Router Class Initialized
INFO - 2021-09-24 17:19:22 --> Output Class Initialized
INFO - 2021-09-24 17:19:22 --> Security Class Initialized
DEBUG - 2021-09-24 17:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:19:22 --> Input Class Initialized
INFO - 2021-09-24 17:19:22 --> Language Class Initialized
INFO - 2021-09-24 17:19:22 --> Loader Class Initialized
INFO - 2021-09-24 17:19:22 --> Helper loaded: url_helper
INFO - 2021-09-24 17:19:22 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:19:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:19:22 --> Controller Class Initialized
INFO - 2021-09-24 17:19:22 --> Model "DBModel" initialized
DEBUG - 2021-09-24 17:19:22 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 17:19:22 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:19:22 --> Database Driver Class Initialized
INFO - 2021-09-24 17:19:22 --> Helper loaded: string_helper
INFO - 2021-09-24 17:19:22 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 17:19:22 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:19:22 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 17:19:22 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 17:19:22 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 17:19:22 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonials.php
INFO - 2021-09-24 17:19:22 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 17:19:22 --> Final output sent to browser
DEBUG - 2021-09-24 17:19:22 --> Total execution time: 0.0678
INFO - 2021-09-24 17:19:25 --> Config Class Initialized
INFO - 2021-09-24 17:19:25 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:19:25 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:19:25 --> Utf8 Class Initialized
INFO - 2021-09-24 17:19:25 --> URI Class Initialized
INFO - 2021-09-24 17:19:25 --> Router Class Initialized
INFO - 2021-09-24 17:19:25 --> Output Class Initialized
INFO - 2021-09-24 17:19:25 --> Security Class Initialized
DEBUG - 2021-09-24 17:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:19:25 --> Input Class Initialized
INFO - 2021-09-24 17:19:25 --> Language Class Initialized
INFO - 2021-09-24 17:19:25 --> Loader Class Initialized
INFO - 2021-09-24 17:19:25 --> Helper loaded: url_helper
INFO - 2021-09-24 17:19:25 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:19:25 --> Controller Class Initialized
INFO - 2021-09-24 17:19:25 --> Model "DBModel" initialized
DEBUG - 2021-09-24 17:19:25 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 17:19:25 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:19:25 --> Database Driver Class Initialized
INFO - 2021-09-24 17:19:25 --> Helper loaded: string_helper
INFO - 2021-09-24 17:19:25 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 17:19:25 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:19:25 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 17:19:25 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 17:19:25 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 17:19:25 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 17:19:25 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 17:19:25 --> Final output sent to browser
DEBUG - 2021-09-24 17:19:25 --> Total execution time: 0.0717
INFO - 2021-09-24 17:19:34 --> Config Class Initialized
INFO - 2021-09-24 17:19:34 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:19:34 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:19:34 --> Utf8 Class Initialized
INFO - 2021-09-24 17:19:34 --> URI Class Initialized
INFO - 2021-09-24 17:19:34 --> Router Class Initialized
INFO - 2021-09-24 17:19:34 --> Output Class Initialized
INFO - 2021-09-24 17:19:34 --> Security Class Initialized
DEBUG - 2021-09-24 17:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:19:34 --> Input Class Initialized
INFO - 2021-09-24 17:19:34 --> Language Class Initialized
INFO - 2021-09-24 17:19:34 --> Loader Class Initialized
INFO - 2021-09-24 17:19:34 --> Helper loaded: url_helper
INFO - 2021-09-24 17:19:34 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:19:34 --> Controller Class Initialized
INFO - 2021-09-24 17:19:34 --> Model "DBModel" initialized
DEBUG - 2021-09-24 17:19:34 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 17:19:34 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:19:34 --> Database Driver Class Initialized
INFO - 2021-09-24 17:19:34 --> Helper loaded: string_helper
INFO - 2021-09-24 17:19:34 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 17:19:34 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:19:34 --> Config Class Initialized
INFO - 2021-09-24 17:19:34 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:19:34 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:19:34 --> Utf8 Class Initialized
INFO - 2021-09-24 17:19:34 --> URI Class Initialized
INFO - 2021-09-24 17:19:34 --> Router Class Initialized
INFO - 2021-09-24 17:19:34 --> Output Class Initialized
INFO - 2021-09-24 17:19:34 --> Security Class Initialized
DEBUG - 2021-09-24 17:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:19:34 --> Input Class Initialized
INFO - 2021-09-24 17:19:34 --> Language Class Initialized
INFO - 2021-09-24 17:19:34 --> Loader Class Initialized
INFO - 2021-09-24 17:19:34 --> Helper loaded: url_helper
INFO - 2021-09-24 17:19:34 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:19:34 --> Controller Class Initialized
INFO - 2021-09-24 17:19:34 --> Model "DBModel" initialized
DEBUG - 2021-09-24 17:19:34 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 17:19:34 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:19:34 --> Database Driver Class Initialized
INFO - 2021-09-24 17:19:34 --> Helper loaded: string_helper
INFO - 2021-09-24 17:19:34 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 17:19:34 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:19:34 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 17:19:34 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 17:19:34 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 17:19:34 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonials.php
INFO - 2021-09-24 17:19:34 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 17:19:34 --> Final output sent to browser
DEBUG - 2021-09-24 17:19:34 --> Total execution time: 0.0618
INFO - 2021-09-24 17:19:38 --> Config Class Initialized
INFO - 2021-09-24 17:19:38 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:19:38 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:19:38 --> Utf8 Class Initialized
INFO - 2021-09-24 17:19:38 --> URI Class Initialized
INFO - 2021-09-24 17:19:38 --> Router Class Initialized
INFO - 2021-09-24 17:19:38 --> Output Class Initialized
INFO - 2021-09-24 17:19:38 --> Security Class Initialized
DEBUG - 2021-09-24 17:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:19:38 --> Input Class Initialized
INFO - 2021-09-24 17:19:38 --> Language Class Initialized
INFO - 2021-09-24 17:19:38 --> Loader Class Initialized
INFO - 2021-09-24 17:19:38 --> Helper loaded: url_helper
INFO - 2021-09-24 17:19:38 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:19:38 --> Controller Class Initialized
INFO - 2021-09-24 17:19:38 --> Database Driver Class Initialized
INFO - 2021-09-24 17:19:38 --> Helper loaded: string_helper
INFO - 2021-09-24 17:19:38 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 17:19:38 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:19:38 --> Model "CookieModel" initialized
INFO - 2021-09-24 17:19:38 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 17:19:38 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/videotestimonials.php
INFO - 2021-09-24 17:19:38 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 17:19:38 --> Final output sent to browser
DEBUG - 2021-09-24 17:19:38 --> Total execution time: 0.0517
INFO - 2021-09-24 17:19:46 --> Config Class Initialized
INFO - 2021-09-24 17:19:46 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:19:46 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:19:46 --> Utf8 Class Initialized
INFO - 2021-09-24 17:19:46 --> URI Class Initialized
INFO - 2021-09-24 17:19:46 --> Router Class Initialized
INFO - 2021-09-24 17:19:46 --> Output Class Initialized
INFO - 2021-09-24 17:19:46 --> Security Class Initialized
DEBUG - 2021-09-24 17:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:19:46 --> Input Class Initialized
INFO - 2021-09-24 17:19:46 --> Language Class Initialized
INFO - 2021-09-24 17:19:46 --> Loader Class Initialized
INFO - 2021-09-24 17:19:46 --> Helper loaded: url_helper
INFO - 2021-09-24 17:19:46 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:19:46 --> Controller Class Initialized
INFO - 2021-09-24 17:19:46 --> Model "DBModel" initialized
DEBUG - 2021-09-24 17:19:46 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 17:19:46 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:19:46 --> Database Driver Class Initialized
INFO - 2021-09-24 17:19:46 --> Helper loaded: string_helper
INFO - 2021-09-24 17:19:46 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 17:19:46 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:19:46 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 17:19:46 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 17:19:46 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 17:19:46 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-24 17:19:46 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 17:19:46 --> Final output sent to browser
DEBUG - 2021-09-24 17:19:46 --> Total execution time: 0.0540
INFO - 2021-09-24 17:19:53 --> Config Class Initialized
INFO - 2021-09-24 17:19:53 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:19:53 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:19:53 --> Utf8 Class Initialized
INFO - 2021-09-24 17:19:53 --> URI Class Initialized
INFO - 2021-09-24 17:19:53 --> Router Class Initialized
INFO - 2021-09-24 17:19:53 --> Output Class Initialized
INFO - 2021-09-24 17:19:53 --> Security Class Initialized
DEBUG - 2021-09-24 17:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:19:53 --> Input Class Initialized
INFO - 2021-09-24 17:19:53 --> Language Class Initialized
INFO - 2021-09-24 17:19:53 --> Loader Class Initialized
INFO - 2021-09-24 17:19:53 --> Helper loaded: url_helper
INFO - 2021-09-24 17:19:53 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:19:53 --> Controller Class Initialized
INFO - 2021-09-24 17:19:53 --> Model "DBModel" initialized
DEBUG - 2021-09-24 17:19:53 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 17:19:53 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:19:53 --> Database Driver Class Initialized
INFO - 2021-09-24 17:19:53 --> Helper loaded: string_helper
INFO - 2021-09-24 17:19:53 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 17:19:53 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:19:53 --> Config Class Initialized
INFO - 2021-09-24 17:19:53 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:19:53 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:19:53 --> Utf8 Class Initialized
INFO - 2021-09-24 17:19:53 --> URI Class Initialized
INFO - 2021-09-24 17:19:53 --> Router Class Initialized
INFO - 2021-09-24 17:19:53 --> Output Class Initialized
INFO - 2021-09-24 17:19:53 --> Security Class Initialized
DEBUG - 2021-09-24 17:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:19:53 --> Input Class Initialized
INFO - 2021-09-24 17:19:53 --> Language Class Initialized
INFO - 2021-09-24 17:19:53 --> Loader Class Initialized
INFO - 2021-09-24 17:19:53 --> Helper loaded: url_helper
INFO - 2021-09-24 17:19:53 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:19:53 --> Controller Class Initialized
INFO - 2021-09-24 17:19:53 --> Model "DBModel" initialized
DEBUG - 2021-09-24 17:19:53 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 17:19:53 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:19:53 --> Database Driver Class Initialized
INFO - 2021-09-24 17:19:53 --> Helper loaded: string_helper
INFO - 2021-09-24 17:19:53 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 17:19:53 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:19:53 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 17:19:53 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 17:19:53 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 17:19:53 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonials.php
INFO - 2021-09-24 17:19:53 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 17:19:53 --> Final output sent to browser
DEBUG - 2021-09-24 17:19:53 --> Total execution time: 0.0614
INFO - 2021-09-24 17:19:56 --> Config Class Initialized
INFO - 2021-09-24 17:19:56 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:19:56 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:19:56 --> Utf8 Class Initialized
INFO - 2021-09-24 17:19:56 --> URI Class Initialized
INFO - 2021-09-24 17:19:56 --> Router Class Initialized
INFO - 2021-09-24 17:19:56 --> Output Class Initialized
INFO - 2021-09-24 17:19:56 --> Security Class Initialized
DEBUG - 2021-09-24 17:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:19:56 --> Input Class Initialized
INFO - 2021-09-24 17:19:56 --> Language Class Initialized
INFO - 2021-09-24 17:19:56 --> Loader Class Initialized
INFO - 2021-09-24 17:19:56 --> Helper loaded: url_helper
INFO - 2021-09-24 17:19:56 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:19:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:19:56 --> Controller Class Initialized
INFO - 2021-09-24 17:19:56 --> Database Driver Class Initialized
INFO - 2021-09-24 17:19:56 --> Helper loaded: string_helper
INFO - 2021-09-24 17:19:56 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 17:19:56 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:19:56 --> Model "CookieModel" initialized
INFO - 2021-09-24 17:19:56 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 17:19:56 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/videotestimonials.php
INFO - 2021-09-24 17:19:56 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 17:19:56 --> Final output sent to browser
DEBUG - 2021-09-24 17:19:56 --> Total execution time: 0.0492
INFO - 2021-09-24 17:20:09 --> Config Class Initialized
INFO - 2021-09-24 17:20:09 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:20:09 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:20:09 --> Utf8 Class Initialized
INFO - 2021-09-24 17:20:09 --> URI Class Initialized
INFO - 2021-09-24 17:20:09 --> Router Class Initialized
INFO - 2021-09-24 17:20:09 --> Output Class Initialized
INFO - 2021-09-24 17:20:09 --> Security Class Initialized
DEBUG - 2021-09-24 17:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:20:09 --> Input Class Initialized
INFO - 2021-09-24 17:20:09 --> Language Class Initialized
INFO - 2021-09-24 17:20:09 --> Loader Class Initialized
INFO - 2021-09-24 17:20:09 --> Helper loaded: url_helper
INFO - 2021-09-24 17:20:09 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:20:09 --> Controller Class Initialized
INFO - 2021-09-24 17:20:09 --> Database Driver Class Initialized
INFO - 2021-09-24 17:20:09 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:20:09 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:20:09 --> Model "CookieModel" initialized
INFO - 2021-09-24 17:20:09 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 17:20:09 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-24 17:20:09 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 17:20:09 --> Final output sent to browser
DEBUG - 2021-09-24 17:20:09 --> Total execution time: 0.0537
INFO - 2021-09-24 17:20:13 --> Config Class Initialized
INFO - 2021-09-24 17:20:13 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:20:13 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:20:13 --> Utf8 Class Initialized
INFO - 2021-09-24 17:20:13 --> URI Class Initialized
INFO - 2021-09-24 17:20:13 --> Router Class Initialized
INFO - 2021-09-24 17:20:13 --> Output Class Initialized
INFO - 2021-09-24 17:20:13 --> Security Class Initialized
DEBUG - 2021-09-24 17:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:20:13 --> Input Class Initialized
INFO - 2021-09-24 17:20:13 --> Language Class Initialized
INFO - 2021-09-24 17:20:13 --> Loader Class Initialized
INFO - 2021-09-24 17:20:13 --> Helper loaded: url_helper
INFO - 2021-09-24 17:20:13 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:20:13 --> Controller Class Initialized
INFO - 2021-09-24 17:20:13 --> Model "DBModel" initialized
DEBUG - 2021-09-24 17:20:13 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 17:20:13 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:20:13 --> Database Driver Class Initialized
INFO - 2021-09-24 17:20:13 --> Helper loaded: string_helper
INFO - 2021-09-24 17:20:13 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 17:20:13 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:20:13 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 17:20:13 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 17:20:13 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 17:20:13 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/blogs.php
INFO - 2021-09-24 17:20:13 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 17:20:13 --> Final output sent to browser
DEBUG - 2021-09-24 17:20:13 --> Total execution time: 0.0565
INFO - 2021-09-24 17:20:16 --> Config Class Initialized
INFO - 2021-09-24 17:20:16 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:20:16 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:20:16 --> Utf8 Class Initialized
INFO - 2021-09-24 17:20:16 --> URI Class Initialized
INFO - 2021-09-24 17:20:16 --> Router Class Initialized
INFO - 2021-09-24 17:20:16 --> Output Class Initialized
INFO - 2021-09-24 17:20:16 --> Security Class Initialized
DEBUG - 2021-09-24 17:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:20:16 --> Input Class Initialized
INFO - 2021-09-24 17:20:16 --> Language Class Initialized
INFO - 2021-09-24 17:20:16 --> Loader Class Initialized
INFO - 2021-09-24 17:20:16 --> Helper loaded: url_helper
INFO - 2021-09-24 17:20:16 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:20:16 --> Controller Class Initialized
INFO - 2021-09-24 17:20:16 --> Model "DBModel" initialized
DEBUG - 2021-09-24 17:20:16 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 17:20:16 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:20:16 --> Database Driver Class Initialized
INFO - 2021-09-24 17:20:16 --> Helper loaded: string_helper
INFO - 2021-09-24 17:20:16 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 17:20:16 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:20:16 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 17:20:16 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 17:20:16 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 17:20:16 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/blog.php
INFO - 2021-09-24 17:20:16 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 17:20:16 --> Final output sent to browser
DEBUG - 2021-09-24 17:20:16 --> Total execution time: 0.0506
INFO - 2021-09-24 17:20:21 --> Config Class Initialized
INFO - 2021-09-24 17:20:21 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:20:21 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:20:21 --> Utf8 Class Initialized
INFO - 2021-09-24 17:20:21 --> URI Class Initialized
INFO - 2021-09-24 17:20:21 --> Router Class Initialized
INFO - 2021-09-24 17:20:21 --> Output Class Initialized
INFO - 2021-09-24 17:20:21 --> Security Class Initialized
DEBUG - 2021-09-24 17:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:20:21 --> Input Class Initialized
INFO - 2021-09-24 17:20:21 --> Language Class Initialized
INFO - 2021-09-24 17:20:21 --> Loader Class Initialized
INFO - 2021-09-24 17:20:21 --> Helper loaded: url_helper
INFO - 2021-09-24 17:20:21 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:20:21 --> Controller Class Initialized
INFO - 2021-09-24 17:20:21 --> Model "DBModel" initialized
DEBUG - 2021-09-24 17:20:21 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 17:20:21 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:20:21 --> Database Driver Class Initialized
INFO - 2021-09-24 17:20:21 --> Helper loaded: string_helper
INFO - 2021-09-24 17:20:21 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 17:20:21 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:20:21 --> Config Class Initialized
INFO - 2021-09-24 17:20:21 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:20:21 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:20:21 --> Utf8 Class Initialized
INFO - 2021-09-24 17:20:21 --> URI Class Initialized
INFO - 2021-09-24 17:20:21 --> Router Class Initialized
INFO - 2021-09-24 17:20:21 --> Output Class Initialized
INFO - 2021-09-24 17:20:21 --> Security Class Initialized
DEBUG - 2021-09-24 17:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:20:21 --> Input Class Initialized
INFO - 2021-09-24 17:20:21 --> Language Class Initialized
INFO - 2021-09-24 17:20:21 --> Loader Class Initialized
INFO - 2021-09-24 17:20:21 --> Helper loaded: url_helper
INFO - 2021-09-24 17:20:21 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:20:21 --> Controller Class Initialized
INFO - 2021-09-24 17:20:21 --> Model "DBModel" initialized
DEBUG - 2021-09-24 17:20:21 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 17:20:21 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:20:21 --> Database Driver Class Initialized
INFO - 2021-09-24 17:20:21 --> Helper loaded: string_helper
INFO - 2021-09-24 17:20:21 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 17:20:21 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:20:21 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 17:20:21 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 17:20:21 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 17:20:21 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/blogs.php
INFO - 2021-09-24 17:20:21 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 17:20:21 --> Final output sent to browser
DEBUG - 2021-09-24 17:20:21 --> Total execution time: 0.0549
INFO - 2021-09-24 17:21:54 --> Config Class Initialized
INFO - 2021-09-24 17:21:54 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:21:54 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:21:54 --> Utf8 Class Initialized
INFO - 2021-09-24 17:21:54 --> URI Class Initialized
INFO - 2021-09-24 17:21:54 --> Router Class Initialized
INFO - 2021-09-24 17:21:54 --> Output Class Initialized
INFO - 2021-09-24 17:21:54 --> Security Class Initialized
DEBUG - 2021-09-24 17:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:21:54 --> Input Class Initialized
INFO - 2021-09-24 17:21:54 --> Language Class Initialized
INFO - 2021-09-24 17:21:54 --> Loader Class Initialized
INFO - 2021-09-24 17:21:54 --> Helper loaded: url_helper
INFO - 2021-09-24 17:21:54 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:21:54 --> Controller Class Initialized
INFO - 2021-09-24 17:21:54 --> Model "DBModel" initialized
DEBUG - 2021-09-24 17:21:54 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 17:21:54 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:21:54 --> Database Driver Class Initialized
INFO - 2021-09-24 17:21:54 --> Helper loaded: string_helper
INFO - 2021-09-24 17:21:54 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 17:21:54 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:21:54 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 17:21:54 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 17:21:54 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
ERROR - 2021-09-24 17:21:54 --> Severity: Notice --> Undefined variable: roe E:\xampp\htdocs\changeme\application\views\admin\blogs.php 36
ERROR - 2021-09-24 17:21:54 --> Severity: Notice --> Trying to get property 'createdon' of non-object E:\xampp\htdocs\changeme\application\views\admin\blogs.php 36
INFO - 2021-09-24 17:21:54 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/blogs.php
INFO - 2021-09-24 17:21:54 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 17:21:54 --> Final output sent to browser
DEBUG - 2021-09-24 17:21:54 --> Total execution time: 0.0845
INFO - 2021-09-24 17:22:00 --> Config Class Initialized
INFO - 2021-09-24 17:22:00 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:22:00 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:22:00 --> Utf8 Class Initialized
INFO - 2021-09-24 17:22:00 --> URI Class Initialized
INFO - 2021-09-24 17:22:00 --> Router Class Initialized
INFO - 2021-09-24 17:22:00 --> Output Class Initialized
INFO - 2021-09-24 17:22:00 --> Security Class Initialized
DEBUG - 2021-09-24 17:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:22:00 --> Input Class Initialized
INFO - 2021-09-24 17:22:00 --> Language Class Initialized
INFO - 2021-09-24 17:22:00 --> Loader Class Initialized
INFO - 2021-09-24 17:22:00 --> Helper loaded: url_helper
INFO - 2021-09-24 17:22:00 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:22:00 --> Controller Class Initialized
INFO - 2021-09-24 17:22:00 --> Model "DBModel" initialized
DEBUG - 2021-09-24 17:22:00 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 17:22:00 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:22:00 --> Database Driver Class Initialized
INFO - 2021-09-24 17:22:00 --> Helper loaded: string_helper
INFO - 2021-09-24 17:22:00 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 17:22:00 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:22:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 17:22:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 17:22:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 17:22:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/blogs.php
INFO - 2021-09-24 17:22:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 17:22:00 --> Final output sent to browser
DEBUG - 2021-09-24 17:22:00 --> Total execution time: 0.0625
INFO - 2021-09-24 17:22:14 --> Config Class Initialized
INFO - 2021-09-24 17:22:14 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:22:14 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:22:14 --> Utf8 Class Initialized
INFO - 2021-09-24 17:22:14 --> URI Class Initialized
INFO - 2021-09-24 17:22:14 --> Router Class Initialized
INFO - 2021-09-24 17:22:14 --> Output Class Initialized
INFO - 2021-09-24 17:22:14 --> Security Class Initialized
DEBUG - 2021-09-24 17:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:22:14 --> Input Class Initialized
INFO - 2021-09-24 17:22:14 --> Language Class Initialized
INFO - 2021-09-24 17:22:14 --> Loader Class Initialized
INFO - 2021-09-24 17:22:14 --> Helper loaded: url_helper
INFO - 2021-09-24 17:22:14 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:22:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:22:14 --> Controller Class Initialized
INFO - 2021-09-24 17:22:14 --> Database Driver Class Initialized
INFO - 2021-09-24 17:22:14 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:22:14 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:22:14 --> Model "CookieModel" initialized
INFO - 2021-09-24 17:22:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 17:22:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-24 17:22:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 17:22:14 --> Final output sent to browser
DEBUG - 2021-09-24 17:22:14 --> Total execution time: 0.0619
INFO - 2021-09-24 17:22:41 --> Config Class Initialized
INFO - 2021-09-24 17:22:41 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:22:41 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:22:41 --> Utf8 Class Initialized
INFO - 2021-09-24 17:22:41 --> URI Class Initialized
INFO - 2021-09-24 17:22:41 --> Router Class Initialized
INFO - 2021-09-24 17:22:41 --> Output Class Initialized
INFO - 2021-09-24 17:22:41 --> Security Class Initialized
DEBUG - 2021-09-24 17:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:22:41 --> Input Class Initialized
INFO - 2021-09-24 17:22:41 --> Language Class Initialized
INFO - 2021-09-24 17:22:41 --> Loader Class Initialized
INFO - 2021-09-24 17:22:41 --> Helper loaded: url_helper
INFO - 2021-09-24 17:22:41 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:22:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:22:41 --> Controller Class Initialized
INFO - 2021-09-24 17:22:41 --> Database Driver Class Initialized
INFO - 2021-09-24 17:22:41 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:22:41 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:22:41 --> Model "CookieModel" initialized
INFO - 2021-09-24 17:22:41 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 17:22:41 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-24 17:22:41 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 17:22:41 --> Final output sent to browser
DEBUG - 2021-09-24 17:22:41 --> Total execution time: 0.0536
INFO - 2021-09-24 17:24:23 --> Config Class Initialized
INFO - 2021-09-24 17:24:23 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:24:23 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:24:23 --> Utf8 Class Initialized
INFO - 2021-09-24 17:24:23 --> URI Class Initialized
INFO - 2021-09-24 17:24:23 --> Router Class Initialized
INFO - 2021-09-24 17:24:23 --> Output Class Initialized
INFO - 2021-09-24 17:24:23 --> Security Class Initialized
DEBUG - 2021-09-24 17:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:24:23 --> Input Class Initialized
INFO - 2021-09-24 17:24:23 --> Language Class Initialized
INFO - 2021-09-24 17:24:23 --> Loader Class Initialized
INFO - 2021-09-24 17:24:23 --> Helper loaded: url_helper
INFO - 2021-09-24 17:24:23 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:24:23 --> Controller Class Initialized
INFO - 2021-09-24 17:24:23 --> Database Driver Class Initialized
INFO - 2021-09-24 17:24:23 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:24:23 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:24:23 --> Model "CookieModel" initialized
INFO - 2021-09-24 17:24:23 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 17:24:23 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-24 17:24:23 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 17:24:23 --> Final output sent to browser
DEBUG - 2021-09-24 17:24:23 --> Total execution time: 0.0537
INFO - 2021-09-24 17:24:45 --> Config Class Initialized
INFO - 2021-09-24 17:24:45 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:24:45 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:24:45 --> Utf8 Class Initialized
INFO - 2021-09-24 17:24:45 --> URI Class Initialized
INFO - 2021-09-24 17:24:45 --> Router Class Initialized
INFO - 2021-09-24 17:24:45 --> Output Class Initialized
INFO - 2021-09-24 17:24:45 --> Security Class Initialized
DEBUG - 2021-09-24 17:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:24:45 --> Input Class Initialized
INFO - 2021-09-24 17:24:45 --> Language Class Initialized
INFO - 2021-09-24 17:24:45 --> Loader Class Initialized
INFO - 2021-09-24 17:24:45 --> Helper loaded: url_helper
INFO - 2021-09-24 17:24:45 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:24:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:24:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:24:45 --> Controller Class Initialized
INFO - 2021-09-24 17:24:45 --> Database Driver Class Initialized
INFO - 2021-09-24 17:24:45 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:24:45 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:24:45 --> Model "CookieModel" initialized
INFO - 2021-09-24 17:24:45 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 17:24:45 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-24 17:24:45 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 17:24:45 --> Final output sent to browser
DEBUG - 2021-09-24 17:24:45 --> Total execution time: 0.0491
INFO - 2021-09-24 17:24:54 --> Config Class Initialized
INFO - 2021-09-24 17:24:54 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:24:54 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:24:54 --> Utf8 Class Initialized
INFO - 2021-09-24 17:24:54 --> URI Class Initialized
INFO - 2021-09-24 17:24:54 --> Router Class Initialized
INFO - 2021-09-24 17:24:54 --> Output Class Initialized
INFO - 2021-09-24 17:24:54 --> Security Class Initialized
DEBUG - 2021-09-24 17:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:24:54 --> Input Class Initialized
INFO - 2021-09-24 17:24:54 --> Language Class Initialized
INFO - 2021-09-24 17:24:54 --> Loader Class Initialized
INFO - 2021-09-24 17:24:54 --> Helper loaded: url_helper
INFO - 2021-09-24 17:24:54 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:24:54 --> Controller Class Initialized
INFO - 2021-09-24 17:24:54 --> Database Driver Class Initialized
INFO - 2021-09-24 17:24:54 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:24:54 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:24:54 --> Model "CookieModel" initialized
INFO - 2021-09-24 17:24:54 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 17:24:54 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-24 17:24:54 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 17:24:54 --> Final output sent to browser
DEBUG - 2021-09-24 17:24:54 --> Total execution time: 0.0507
INFO - 2021-09-24 17:29:51 --> Config Class Initialized
INFO - 2021-09-24 17:29:51 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:29:51 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:29:51 --> Utf8 Class Initialized
INFO - 2021-09-24 17:29:51 --> URI Class Initialized
INFO - 2021-09-24 17:29:51 --> Router Class Initialized
INFO - 2021-09-24 17:29:51 --> Output Class Initialized
INFO - 2021-09-24 17:29:51 --> Security Class Initialized
DEBUG - 2021-09-24 17:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:29:51 --> Input Class Initialized
INFO - 2021-09-24 17:29:51 --> Language Class Initialized
INFO - 2021-09-24 17:29:51 --> Loader Class Initialized
INFO - 2021-09-24 17:29:51 --> Helper loaded: url_helper
INFO - 2021-09-24 17:29:51 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:29:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:29:51 --> Controller Class Initialized
INFO - 2021-09-24 17:29:51 --> Database Driver Class Initialized
INFO - 2021-09-24 17:29:51 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:29:51 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:29:51 --> Model "CookieModel" initialized
INFO - 2021-09-24 17:29:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 17:29:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-24 17:29:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 17:29:51 --> Final output sent to browser
DEBUG - 2021-09-24 17:29:51 --> Total execution time: 0.0735
INFO - 2021-09-24 17:30:03 --> Config Class Initialized
INFO - 2021-09-24 17:30:03 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:30:03 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:30:03 --> Utf8 Class Initialized
INFO - 2021-09-24 17:30:03 --> URI Class Initialized
INFO - 2021-09-24 17:30:03 --> Router Class Initialized
INFO - 2021-09-24 17:30:03 --> Output Class Initialized
INFO - 2021-09-24 17:30:03 --> Security Class Initialized
DEBUG - 2021-09-24 17:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:30:03 --> Input Class Initialized
INFO - 2021-09-24 17:30:03 --> Language Class Initialized
INFO - 2021-09-24 17:30:03 --> Loader Class Initialized
INFO - 2021-09-24 17:30:03 --> Helper loaded: url_helper
INFO - 2021-09-24 17:30:03 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:30:03 --> Controller Class Initialized
INFO - 2021-09-24 17:30:03 --> Database Driver Class Initialized
INFO - 2021-09-24 17:30:03 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:30:03 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:30:03 --> Model "CookieModel" initialized
INFO - 2021-09-24 17:30:03 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 17:30:03 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-24 17:30:03 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 17:30:03 --> Final output sent to browser
DEBUG - 2021-09-24 17:30:03 --> Total execution time: 0.0631
INFO - 2021-09-24 17:30:05 --> Config Class Initialized
INFO - 2021-09-24 17:30:05 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:30:05 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:30:05 --> Utf8 Class Initialized
INFO - 2021-09-24 17:30:05 --> URI Class Initialized
INFO - 2021-09-24 17:30:05 --> Router Class Initialized
INFO - 2021-09-24 17:30:05 --> Output Class Initialized
INFO - 2021-09-24 17:30:05 --> Security Class Initialized
DEBUG - 2021-09-24 17:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:30:05 --> Input Class Initialized
INFO - 2021-09-24 17:30:05 --> Language Class Initialized
INFO - 2021-09-24 17:30:05 --> Loader Class Initialized
INFO - 2021-09-24 17:30:05 --> Helper loaded: url_helper
INFO - 2021-09-24 17:30:05 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:30:05 --> Controller Class Initialized
INFO - 2021-09-24 17:30:05 --> Database Driver Class Initialized
INFO - 2021-09-24 17:30:05 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:30:05 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:30:05 --> Model "CookieModel" initialized
INFO - 2021-09-24 17:30:05 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 17:30:05 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-24 17:30:05 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 17:30:05 --> Final output sent to browser
DEBUG - 2021-09-24 17:30:05 --> Total execution time: 0.0535
INFO - 2021-09-24 17:30:19 --> Config Class Initialized
INFO - 2021-09-24 17:30:19 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:30:19 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:30:19 --> Utf8 Class Initialized
INFO - 2021-09-24 17:30:19 --> URI Class Initialized
INFO - 2021-09-24 17:30:19 --> Router Class Initialized
INFO - 2021-09-24 17:30:19 --> Output Class Initialized
INFO - 2021-09-24 17:30:19 --> Security Class Initialized
DEBUG - 2021-09-24 17:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:30:19 --> Input Class Initialized
INFO - 2021-09-24 17:30:19 --> Language Class Initialized
INFO - 2021-09-24 17:30:19 --> Loader Class Initialized
INFO - 2021-09-24 17:30:19 --> Helper loaded: url_helper
INFO - 2021-09-24 17:30:19 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:30:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:30:19 --> Controller Class Initialized
INFO - 2021-09-24 17:30:19 --> Database Driver Class Initialized
INFO - 2021-09-24 17:30:19 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:30:19 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:30:19 --> Model "CookieModel" initialized
INFO - 2021-09-24 17:30:19 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 17:30:19 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-24 17:30:19 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 17:30:19 --> Final output sent to browser
DEBUG - 2021-09-24 17:30:19 --> Total execution time: 0.0528
INFO - 2021-09-24 17:30:19 --> Config Class Initialized
INFO - 2021-09-24 17:30:19 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:30:19 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:30:19 --> Utf8 Class Initialized
INFO - 2021-09-24 17:30:19 --> URI Class Initialized
INFO - 2021-09-24 17:30:19 --> Router Class Initialized
INFO - 2021-09-24 17:30:19 --> Output Class Initialized
INFO - 2021-09-24 17:30:19 --> Security Class Initialized
DEBUG - 2021-09-24 17:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:30:19 --> Input Class Initialized
INFO - 2021-09-24 17:30:19 --> Language Class Initialized
INFO - 2021-09-24 17:30:19 --> Loader Class Initialized
INFO - 2021-09-24 17:30:19 --> Helper loaded: url_helper
INFO - 2021-09-24 17:30:19 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:30:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:30:19 --> Controller Class Initialized
INFO - 2021-09-24 17:30:19 --> Database Driver Class Initialized
INFO - 2021-09-24 17:30:19 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:30:19 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:30:19 --> Model "CookieModel" initialized
INFO - 2021-09-24 17:30:19 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 17:30:19 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-24 17:30:19 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 17:30:19 --> Final output sent to browser
DEBUG - 2021-09-24 17:30:19 --> Total execution time: 0.0708
INFO - 2021-09-24 17:30:28 --> Config Class Initialized
INFO - 2021-09-24 17:30:28 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:30:28 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:30:28 --> Utf8 Class Initialized
INFO - 2021-09-24 17:30:28 --> URI Class Initialized
INFO - 2021-09-24 17:30:28 --> Router Class Initialized
INFO - 2021-09-24 17:30:28 --> Output Class Initialized
INFO - 2021-09-24 17:30:28 --> Security Class Initialized
DEBUG - 2021-09-24 17:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:30:28 --> Input Class Initialized
INFO - 2021-09-24 17:30:28 --> Language Class Initialized
INFO - 2021-09-24 17:30:28 --> Loader Class Initialized
INFO - 2021-09-24 17:30:28 --> Helper loaded: url_helper
INFO - 2021-09-24 17:30:28 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:30:28 --> Controller Class Initialized
INFO - 2021-09-24 17:30:28 --> Database Driver Class Initialized
INFO - 2021-09-24 17:30:28 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:30:28 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:30:28 --> Model "CookieModel" initialized
INFO - 2021-09-24 17:30:28 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 17:30:28 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-24 17:30:28 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 17:30:28 --> Final output sent to browser
DEBUG - 2021-09-24 17:30:28 --> Total execution time: 0.0540
INFO - 2021-09-24 17:30:50 --> Config Class Initialized
INFO - 2021-09-24 17:30:50 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:30:50 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:30:50 --> Utf8 Class Initialized
INFO - 2021-09-24 17:30:50 --> URI Class Initialized
INFO - 2021-09-24 17:30:50 --> Router Class Initialized
INFO - 2021-09-24 17:30:50 --> Output Class Initialized
INFO - 2021-09-24 17:30:50 --> Security Class Initialized
DEBUG - 2021-09-24 17:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:30:50 --> Input Class Initialized
INFO - 2021-09-24 17:30:50 --> Language Class Initialized
INFO - 2021-09-24 17:30:50 --> Loader Class Initialized
INFO - 2021-09-24 17:30:50 --> Helper loaded: url_helper
INFO - 2021-09-24 17:30:50 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:30:50 --> Controller Class Initialized
INFO - 2021-09-24 17:30:50 --> Database Driver Class Initialized
INFO - 2021-09-24 17:30:50 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:30:50 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:30:50 --> Model "CookieModel" initialized
INFO - 2021-09-24 17:30:50 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 17:30:50 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-24 17:30:50 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 17:30:50 --> Final output sent to browser
DEBUG - 2021-09-24 17:30:50 --> Total execution time: 0.0655
INFO - 2021-09-24 17:31:04 --> Config Class Initialized
INFO - 2021-09-24 17:31:04 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:31:04 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:31:04 --> Utf8 Class Initialized
INFO - 2021-09-24 17:31:04 --> URI Class Initialized
INFO - 2021-09-24 17:31:04 --> Router Class Initialized
INFO - 2021-09-24 17:31:04 --> Output Class Initialized
INFO - 2021-09-24 17:31:04 --> Security Class Initialized
DEBUG - 2021-09-24 17:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:31:04 --> Input Class Initialized
INFO - 2021-09-24 17:31:04 --> Language Class Initialized
INFO - 2021-09-24 17:31:04 --> Loader Class Initialized
INFO - 2021-09-24 17:31:04 --> Helper loaded: url_helper
INFO - 2021-09-24 17:31:04 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:31:04 --> Controller Class Initialized
INFO - 2021-09-24 17:31:04 --> Database Driver Class Initialized
INFO - 2021-09-24 17:31:04 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:31:04 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:31:04 --> Model "CookieModel" initialized
INFO - 2021-09-24 17:31:04 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 17:31:04 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-24 17:31:04 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 17:31:04 --> Final output sent to browser
DEBUG - 2021-09-24 17:31:04 --> Total execution time: 0.0509
INFO - 2021-09-24 17:31:27 --> Config Class Initialized
INFO - 2021-09-24 17:31:27 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:31:27 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:31:27 --> Utf8 Class Initialized
INFO - 2021-09-24 17:31:27 --> URI Class Initialized
INFO - 2021-09-24 17:31:27 --> Router Class Initialized
INFO - 2021-09-24 17:31:27 --> Output Class Initialized
INFO - 2021-09-24 17:31:27 --> Security Class Initialized
DEBUG - 2021-09-24 17:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:31:27 --> Input Class Initialized
INFO - 2021-09-24 17:31:27 --> Language Class Initialized
INFO - 2021-09-24 17:31:27 --> Loader Class Initialized
INFO - 2021-09-24 17:31:27 --> Helper loaded: url_helper
INFO - 2021-09-24 17:31:27 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:31:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:31:27 --> Controller Class Initialized
INFO - 2021-09-24 17:31:27 --> Database Driver Class Initialized
INFO - 2021-09-24 17:31:27 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:31:27 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:31:27 --> Model "CookieModel" initialized
INFO - 2021-09-24 17:31:27 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
ERROR - 2021-09-24 17:31:27 --> Severity: Notice --> Undefined property: stdClass::$name E:\xampp\htdocs\changeme\application\views\user\blogs.php 42
INFO - 2021-09-24 17:31:27 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-24 17:31:27 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 17:31:27 --> Final output sent to browser
DEBUG - 2021-09-24 17:31:27 --> Total execution time: 0.0633
INFO - 2021-09-24 17:31:40 --> Config Class Initialized
INFO - 2021-09-24 17:31:40 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:31:40 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:31:40 --> Utf8 Class Initialized
INFO - 2021-09-24 17:31:40 --> URI Class Initialized
INFO - 2021-09-24 17:31:40 --> Router Class Initialized
INFO - 2021-09-24 17:31:40 --> Output Class Initialized
INFO - 2021-09-24 17:31:40 --> Security Class Initialized
DEBUG - 2021-09-24 17:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:31:40 --> Input Class Initialized
INFO - 2021-09-24 17:31:40 --> Language Class Initialized
INFO - 2021-09-24 17:31:40 --> Loader Class Initialized
INFO - 2021-09-24 17:31:40 --> Helper loaded: url_helper
INFO - 2021-09-24 17:31:40 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:31:41 --> Controller Class Initialized
INFO - 2021-09-24 17:31:41 --> Database Driver Class Initialized
INFO - 2021-09-24 17:31:41 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:31:41 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:31:41 --> Model "CookieModel" initialized
INFO - 2021-09-24 17:31:41 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 17:31:41 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-24 17:31:41 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 17:31:41 --> Final output sent to browser
DEBUG - 2021-09-24 17:31:41 --> Total execution time: 0.0608
INFO - 2021-09-24 17:35:14 --> Config Class Initialized
INFO - 2021-09-24 17:35:14 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:35:14 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:35:14 --> Utf8 Class Initialized
INFO - 2021-09-24 17:35:14 --> URI Class Initialized
INFO - 2021-09-24 17:35:14 --> Router Class Initialized
INFO - 2021-09-24 17:35:14 --> Output Class Initialized
INFO - 2021-09-24 17:35:14 --> Security Class Initialized
DEBUG - 2021-09-24 17:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:35:14 --> Input Class Initialized
INFO - 2021-09-24 17:35:14 --> Language Class Initialized
INFO - 2021-09-24 17:35:14 --> Loader Class Initialized
INFO - 2021-09-24 17:35:14 --> Helper loaded: url_helper
INFO - 2021-09-24 17:35:14 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:35:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:35:14 --> Controller Class Initialized
INFO - 2021-09-24 17:35:14 --> Database Driver Class Initialized
INFO - 2021-09-24 17:35:14 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:35:14 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:35:14 --> Model "CookieModel" initialized
INFO - 2021-09-24 17:35:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 17:35:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-24 17:35:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 17:35:14 --> Final output sent to browser
DEBUG - 2021-09-24 17:35:14 --> Total execution time: 0.0728
INFO - 2021-09-24 17:35:59 --> Config Class Initialized
INFO - 2021-09-24 17:35:59 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:35:59 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:35:59 --> Utf8 Class Initialized
INFO - 2021-09-24 17:35:59 --> URI Class Initialized
INFO - 2021-09-24 17:35:59 --> Router Class Initialized
INFO - 2021-09-24 17:35:59 --> Output Class Initialized
INFO - 2021-09-24 17:35:59 --> Security Class Initialized
DEBUG - 2021-09-24 17:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:35:59 --> Input Class Initialized
INFO - 2021-09-24 17:35:59 --> Language Class Initialized
INFO - 2021-09-24 17:35:59 --> Loader Class Initialized
INFO - 2021-09-24 17:35:59 --> Helper loaded: url_helper
INFO - 2021-09-24 17:35:59 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:35:59 --> Controller Class Initialized
INFO - 2021-09-24 17:35:59 --> Database Driver Class Initialized
INFO - 2021-09-24 17:35:59 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:35:59 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:35:59 --> Model "CookieModel" initialized
INFO - 2021-09-24 17:35:59 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 17:35:59 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-24 17:35:59 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 17:35:59 --> Final output sent to browser
DEBUG - 2021-09-24 17:35:59 --> Total execution time: 0.0881
INFO - 2021-09-24 17:36:59 --> Config Class Initialized
INFO - 2021-09-24 17:36:59 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:36:59 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:36:59 --> Utf8 Class Initialized
INFO - 2021-09-24 17:36:59 --> URI Class Initialized
INFO - 2021-09-24 17:36:59 --> Router Class Initialized
INFO - 2021-09-24 17:36:59 --> Output Class Initialized
INFO - 2021-09-24 17:36:59 --> Security Class Initialized
DEBUG - 2021-09-24 17:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:36:59 --> Input Class Initialized
INFO - 2021-09-24 17:36:59 --> Language Class Initialized
INFO - 2021-09-24 17:36:59 --> Loader Class Initialized
INFO - 2021-09-24 17:36:59 --> Helper loaded: url_helper
INFO - 2021-09-24 17:36:59 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:36:59 --> Controller Class Initialized
INFO - 2021-09-24 17:36:59 --> Database Driver Class Initialized
INFO - 2021-09-24 17:36:59 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:36:59 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:36:59 --> Model "CookieModel" initialized
INFO - 2021-09-24 17:36:59 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 17:36:59 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-24 17:36:59 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 17:36:59 --> Final output sent to browser
DEBUG - 2021-09-24 17:36:59 --> Total execution time: 0.0485
INFO - 2021-09-24 17:38:29 --> Config Class Initialized
INFO - 2021-09-24 17:38:29 --> Hooks Class Initialized
DEBUG - 2021-09-24 17:38:29 --> UTF-8 Support Enabled
INFO - 2021-09-24 17:38:29 --> Utf8 Class Initialized
INFO - 2021-09-24 17:38:29 --> URI Class Initialized
INFO - 2021-09-24 17:38:29 --> Router Class Initialized
INFO - 2021-09-24 17:38:29 --> Output Class Initialized
INFO - 2021-09-24 17:38:29 --> Security Class Initialized
DEBUG - 2021-09-24 17:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 17:38:29 --> Input Class Initialized
INFO - 2021-09-24 17:38:29 --> Language Class Initialized
INFO - 2021-09-24 17:38:29 --> Loader Class Initialized
INFO - 2021-09-24 17:38:29 --> Helper loaded: url_helper
INFO - 2021-09-24 17:38:29 --> Helper loaded: file_helper
DEBUG - 2021-09-24 17:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 17:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 17:38:29 --> Controller Class Initialized
INFO - 2021-09-24 17:38:29 --> Database Driver Class Initialized
INFO - 2021-09-24 17:38:29 --> Model "BlogModel" initialized
INFO - 2021-09-24 17:38:29 --> Helper loaded: cookie_helper
INFO - 2021-09-24 17:38:29 --> Model "CookieModel" initialized
INFO - 2021-09-24 17:38:29 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 17:38:29 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-24 17:38:29 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 17:38:29 --> Final output sent to browser
DEBUG - 2021-09-24 17:38:29 --> Total execution time: 0.0705
INFO - 2021-09-24 22:28:36 --> Config Class Initialized
INFO - 2021-09-24 22:28:36 --> Hooks Class Initialized
DEBUG - 2021-09-24 22:28:36 --> UTF-8 Support Enabled
INFO - 2021-09-24 22:28:36 --> Utf8 Class Initialized
INFO - 2021-09-24 22:28:36 --> URI Class Initialized
INFO - 2021-09-24 22:28:36 --> Router Class Initialized
INFO - 2021-09-24 22:28:36 --> Output Class Initialized
INFO - 2021-09-24 22:28:36 --> Security Class Initialized
DEBUG - 2021-09-24 22:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 22:28:36 --> Input Class Initialized
INFO - 2021-09-24 22:28:36 --> Language Class Initialized
INFO - 2021-09-24 22:28:36 --> Loader Class Initialized
INFO - 2021-09-24 22:28:36 --> Helper loaded: url_helper
INFO - 2021-09-24 22:28:36 --> Helper loaded: file_helper
DEBUG - 2021-09-24 22:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 22:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 22:28:36 --> Controller Class Initialized
INFO - 2021-09-24 22:28:36 --> Model "DBModel" initialized
DEBUG - 2021-09-24 22:28:36 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 22:28:36 --> Helper loaded: cookie_helper
INFO - 2021-09-24 22:28:36 --> Database Driver Class Initialized
INFO - 2021-09-24 22:28:36 --> Helper loaded: string_helper
INFO - 2021-09-24 22:28:36 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 22:28:36 --> Model "BlogModel" initialized
INFO - 2021-09-24 22:28:36 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 22:28:36 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 22:28:36 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 22:28:36 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/blog.php
INFO - 2021-09-24 22:28:36 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 22:28:36 --> Final output sent to browser
DEBUG - 2021-09-24 22:28:36 --> Total execution time: 0.0651
INFO - 2021-09-24 22:29:14 --> Config Class Initialized
INFO - 2021-09-24 22:29:14 --> Hooks Class Initialized
DEBUG - 2021-09-24 22:29:14 --> UTF-8 Support Enabled
INFO - 2021-09-24 22:29:14 --> Utf8 Class Initialized
INFO - 2021-09-24 22:29:14 --> URI Class Initialized
INFO - 2021-09-24 22:29:14 --> Router Class Initialized
INFO - 2021-09-24 22:29:14 --> Output Class Initialized
INFO - 2021-09-24 22:29:14 --> Security Class Initialized
DEBUG - 2021-09-24 22:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 22:29:14 --> Input Class Initialized
INFO - 2021-09-24 22:29:14 --> Language Class Initialized
INFO - 2021-09-24 22:29:14 --> Loader Class Initialized
INFO - 2021-09-24 22:29:14 --> Helper loaded: url_helper
INFO - 2021-09-24 22:29:14 --> Helper loaded: file_helper
DEBUG - 2021-09-24 22:29:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 22:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 22:29:14 --> Controller Class Initialized
INFO - 2021-09-24 22:29:14 --> Model "DBModel" initialized
DEBUG - 2021-09-24 22:29:14 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 22:29:14 --> Helper loaded: cookie_helper
INFO - 2021-09-24 22:29:14 --> Database Driver Class Initialized
INFO - 2021-09-24 22:29:14 --> Helper loaded: string_helper
INFO - 2021-09-24 22:29:14 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 22:29:14 --> Model "BlogModel" initialized
INFO - 2021-09-24 22:29:14 --> Config Class Initialized
INFO - 2021-09-24 22:29:14 --> Hooks Class Initialized
DEBUG - 2021-09-24 22:29:14 --> UTF-8 Support Enabled
INFO - 2021-09-24 22:29:14 --> Utf8 Class Initialized
INFO - 2021-09-24 22:29:14 --> URI Class Initialized
INFO - 2021-09-24 22:29:14 --> Router Class Initialized
INFO - 2021-09-24 22:29:14 --> Output Class Initialized
INFO - 2021-09-24 22:29:14 --> Security Class Initialized
DEBUG - 2021-09-24 22:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 22:29:14 --> Input Class Initialized
INFO - 2021-09-24 22:29:14 --> Language Class Initialized
INFO - 2021-09-24 22:29:14 --> Loader Class Initialized
INFO - 2021-09-24 22:29:14 --> Helper loaded: url_helper
INFO - 2021-09-24 22:29:14 --> Helper loaded: file_helper
DEBUG - 2021-09-24 22:29:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 22:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 22:29:14 --> Controller Class Initialized
INFO - 2021-09-24 22:29:14 --> Model "DBModel" initialized
DEBUG - 2021-09-24 22:29:14 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-24 22:29:14 --> Helper loaded: cookie_helper
INFO - 2021-09-24 22:29:14 --> Database Driver Class Initialized
INFO - 2021-09-24 22:29:14 --> Helper loaded: string_helper
INFO - 2021-09-24 22:29:14 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 22:29:14 --> Model "BlogModel" initialized
INFO - 2021-09-24 22:29:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-24 22:29:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-24 22:29:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-24 22:29:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/blogs.php
INFO - 2021-09-24 22:29:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-24 22:29:14 --> Final output sent to browser
DEBUG - 2021-09-24 22:29:14 --> Total execution time: 0.0405
INFO - 2021-09-24 22:29:39 --> Config Class Initialized
INFO - 2021-09-24 22:29:39 --> Hooks Class Initialized
DEBUG - 2021-09-24 22:29:39 --> UTF-8 Support Enabled
INFO - 2021-09-24 22:29:39 --> Utf8 Class Initialized
INFO - 2021-09-24 22:29:39 --> URI Class Initialized
INFO - 2021-09-24 22:29:39 --> Router Class Initialized
INFO - 2021-09-24 22:29:39 --> Output Class Initialized
INFO - 2021-09-24 22:29:39 --> Security Class Initialized
DEBUG - 2021-09-24 22:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 22:29:39 --> Input Class Initialized
INFO - 2021-09-24 22:29:39 --> Language Class Initialized
INFO - 2021-09-24 22:29:39 --> Loader Class Initialized
INFO - 2021-09-24 22:29:39 --> Helper loaded: url_helper
INFO - 2021-09-24 22:29:39 --> Helper loaded: file_helper
DEBUG - 2021-09-24 22:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 22:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 22:29:39 --> Controller Class Initialized
INFO - 2021-09-24 22:29:39 --> Database Driver Class Initialized
INFO - 2021-09-24 22:29:39 --> Model "BlogModel" initialized
INFO - 2021-09-24 22:29:39 --> Helper loaded: cookie_helper
INFO - 2021-09-24 22:29:39 --> Model "CookieModel" initialized
INFO - 2021-09-24 22:29:39 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 22:29:39 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-24 22:29:39 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 22:29:39 --> Final output sent to browser
DEBUG - 2021-09-24 22:29:39 --> Total execution time: 0.0642
INFO - 2021-09-24 22:30:08 --> Config Class Initialized
INFO - 2021-09-24 22:30:08 --> Hooks Class Initialized
DEBUG - 2021-09-24 22:30:08 --> UTF-8 Support Enabled
INFO - 2021-09-24 22:30:08 --> Utf8 Class Initialized
INFO - 2021-09-24 22:30:08 --> URI Class Initialized
INFO - 2021-09-24 22:30:08 --> Router Class Initialized
INFO - 2021-09-24 22:30:08 --> Output Class Initialized
INFO - 2021-09-24 22:30:08 --> Security Class Initialized
DEBUG - 2021-09-24 22:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 22:30:08 --> Input Class Initialized
INFO - 2021-09-24 22:30:08 --> Language Class Initialized
INFO - 2021-09-24 22:30:08 --> Loader Class Initialized
INFO - 2021-09-24 22:30:08 --> Helper loaded: url_helper
INFO - 2021-09-24 22:30:08 --> Helper loaded: file_helper
DEBUG - 2021-09-24 22:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 22:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 22:30:08 --> Controller Class Initialized
INFO - 2021-09-24 22:30:08 --> Database Driver Class Initialized
INFO - 2021-09-24 22:30:08 --> Model "BlogModel" initialized
INFO - 2021-09-24 22:30:08 --> Helper loaded: cookie_helper
INFO - 2021-09-24 22:30:08 --> Model "CookieModel" initialized
INFO - 2021-09-24 22:30:08 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 22:30:08 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-24 22:30:08 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 22:30:08 --> Final output sent to browser
DEBUG - 2021-09-24 22:30:08 --> Total execution time: 0.0403
INFO - 2021-09-24 22:30:16 --> Config Class Initialized
INFO - 2021-09-24 22:30:16 --> Hooks Class Initialized
DEBUG - 2021-09-24 22:30:16 --> UTF-8 Support Enabled
INFO - 2021-09-24 22:30:16 --> Utf8 Class Initialized
INFO - 2021-09-24 22:30:16 --> URI Class Initialized
INFO - 2021-09-24 22:30:16 --> Router Class Initialized
INFO - 2021-09-24 22:30:16 --> Output Class Initialized
INFO - 2021-09-24 22:30:16 --> Security Class Initialized
DEBUG - 2021-09-24 22:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 22:30:16 --> Input Class Initialized
INFO - 2021-09-24 22:30:16 --> Language Class Initialized
INFO - 2021-09-24 22:30:16 --> Loader Class Initialized
INFO - 2021-09-24 22:30:16 --> Helper loaded: url_helper
INFO - 2021-09-24 22:30:16 --> Helper loaded: file_helper
DEBUG - 2021-09-24 22:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 22:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 22:30:16 --> Controller Class Initialized
INFO - 2021-09-24 22:30:16 --> Database Driver Class Initialized
INFO - 2021-09-24 22:30:16 --> Model "BlogModel" initialized
INFO - 2021-09-24 22:30:16 --> Helper loaded: cookie_helper
INFO - 2021-09-24 22:30:16 --> Model "CookieModel" initialized
INFO - 2021-09-24 22:30:16 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 22:30:16 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-24 22:30:16 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 22:30:16 --> Final output sent to browser
DEBUG - 2021-09-24 22:30:16 --> Total execution time: 0.0474
INFO - 2021-09-24 22:30:18 --> Config Class Initialized
INFO - 2021-09-24 22:30:18 --> Hooks Class Initialized
DEBUG - 2021-09-24 22:30:18 --> UTF-8 Support Enabled
INFO - 2021-09-24 22:30:18 --> Utf8 Class Initialized
INFO - 2021-09-24 22:30:18 --> URI Class Initialized
INFO - 2021-09-24 22:30:18 --> Router Class Initialized
INFO - 2021-09-24 22:30:18 --> Output Class Initialized
INFO - 2021-09-24 22:30:18 --> Security Class Initialized
DEBUG - 2021-09-24 22:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 22:30:18 --> Input Class Initialized
INFO - 2021-09-24 22:30:18 --> Language Class Initialized
INFO - 2021-09-24 22:30:18 --> Loader Class Initialized
INFO - 2021-09-24 22:30:18 --> Helper loaded: url_helper
INFO - 2021-09-24 22:30:18 --> Helper loaded: file_helper
DEBUG - 2021-09-24 22:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 22:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 22:30:18 --> Controller Class Initialized
INFO - 2021-09-24 22:30:18 --> Database Driver Class Initialized
INFO - 2021-09-24 22:30:18 --> Model "BlogModel" initialized
INFO - 2021-09-24 22:30:18 --> Helper loaded: cookie_helper
INFO - 2021-09-24 22:30:18 --> Model "CookieModel" initialized
INFO - 2021-09-24 22:30:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 22:30:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-24 22:30:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 22:30:18 --> Final output sent to browser
DEBUG - 2021-09-24 22:30:18 --> Total execution time: 0.0555
INFO - 2021-09-24 22:30:23 --> Config Class Initialized
INFO - 2021-09-24 22:30:23 --> Hooks Class Initialized
DEBUG - 2021-09-24 22:30:23 --> UTF-8 Support Enabled
INFO - 2021-09-24 22:30:23 --> Utf8 Class Initialized
INFO - 2021-09-24 22:30:23 --> URI Class Initialized
INFO - 2021-09-24 22:30:23 --> Router Class Initialized
INFO - 2021-09-24 22:30:23 --> Output Class Initialized
INFO - 2021-09-24 22:30:23 --> Security Class Initialized
DEBUG - 2021-09-24 22:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 22:30:23 --> Input Class Initialized
INFO - 2021-09-24 22:30:23 --> Language Class Initialized
INFO - 2021-09-24 22:30:23 --> Loader Class Initialized
INFO - 2021-09-24 22:30:23 --> Helper loaded: url_helper
INFO - 2021-09-24 22:30:23 --> Helper loaded: file_helper
DEBUG - 2021-09-24 22:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 22:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 22:30:23 --> Controller Class Initialized
INFO - 2021-09-24 22:30:23 --> Database Driver Class Initialized
INFO - 2021-09-24 22:30:23 --> Model "BlogModel" initialized
INFO - 2021-09-24 22:30:23 --> Helper loaded: cookie_helper
INFO - 2021-09-24 22:30:23 --> Model "CookieModel" initialized
INFO - 2021-09-24 22:30:23 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 22:30:23 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-24 22:30:23 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 22:30:23 --> Final output sent to browser
DEBUG - 2021-09-24 22:30:23 --> Total execution time: 0.0397
INFO - 2021-09-24 22:30:25 --> Config Class Initialized
INFO - 2021-09-24 22:30:25 --> Hooks Class Initialized
DEBUG - 2021-09-24 22:30:25 --> UTF-8 Support Enabled
INFO - 2021-09-24 22:30:25 --> Utf8 Class Initialized
INFO - 2021-09-24 22:30:25 --> URI Class Initialized
INFO - 2021-09-24 22:30:25 --> Router Class Initialized
INFO - 2021-09-24 22:30:25 --> Output Class Initialized
INFO - 2021-09-24 22:30:25 --> Security Class Initialized
DEBUG - 2021-09-24 22:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 22:30:25 --> Input Class Initialized
INFO - 2021-09-24 22:30:25 --> Language Class Initialized
INFO - 2021-09-24 22:30:25 --> Loader Class Initialized
INFO - 2021-09-24 22:30:25 --> Helper loaded: url_helper
INFO - 2021-09-24 22:30:25 --> Helper loaded: file_helper
DEBUG - 2021-09-24 22:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 22:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 22:30:25 --> Controller Class Initialized
INFO - 2021-09-24 22:30:25 --> Database Driver Class Initialized
INFO - 2021-09-24 22:30:25 --> Model "BlogModel" initialized
INFO - 2021-09-24 22:30:25 --> Helper loaded: cookie_helper
INFO - 2021-09-24 22:30:25 --> Model "CookieModel" initialized
INFO - 2021-09-24 22:30:25 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 22:30:25 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-24 22:30:25 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 22:30:25 --> Final output sent to browser
DEBUG - 2021-09-24 22:30:25 --> Total execution time: 0.0421
INFO - 2021-09-24 22:30:26 --> Config Class Initialized
INFO - 2021-09-24 22:30:26 --> Hooks Class Initialized
DEBUG - 2021-09-24 22:30:26 --> UTF-8 Support Enabled
INFO - 2021-09-24 22:30:26 --> Utf8 Class Initialized
INFO - 2021-09-24 22:30:26 --> URI Class Initialized
INFO - 2021-09-24 22:30:26 --> Router Class Initialized
INFO - 2021-09-24 22:30:26 --> Output Class Initialized
INFO - 2021-09-24 22:30:26 --> Security Class Initialized
DEBUG - 2021-09-24 22:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 22:30:26 --> Input Class Initialized
INFO - 2021-09-24 22:30:26 --> Language Class Initialized
INFO - 2021-09-24 22:30:26 --> Loader Class Initialized
INFO - 2021-09-24 22:30:26 --> Helper loaded: url_helper
INFO - 2021-09-24 22:30:26 --> Helper loaded: file_helper
DEBUG - 2021-09-24 22:30:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 22:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 22:30:26 --> Controller Class Initialized
INFO - 2021-09-24 22:30:26 --> Database Driver Class Initialized
INFO - 2021-09-24 22:30:26 --> Model "BlogModel" initialized
INFO - 2021-09-24 22:30:26 --> Helper loaded: cookie_helper
INFO - 2021-09-24 22:30:26 --> Model "CookieModel" initialized
INFO - 2021-09-24 22:30:26 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 22:30:26 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-24 22:30:26 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 22:30:26 --> Final output sent to browser
DEBUG - 2021-09-24 22:30:26 --> Total execution time: 0.0449
INFO - 2021-09-24 22:30:35 --> Config Class Initialized
INFO - 2021-09-24 22:30:35 --> Hooks Class Initialized
DEBUG - 2021-09-24 22:30:35 --> UTF-8 Support Enabled
INFO - 2021-09-24 22:30:35 --> Utf8 Class Initialized
INFO - 2021-09-24 22:30:35 --> URI Class Initialized
INFO - 2021-09-24 22:30:35 --> Router Class Initialized
INFO - 2021-09-24 22:30:35 --> Output Class Initialized
INFO - 2021-09-24 22:30:35 --> Security Class Initialized
DEBUG - 2021-09-24 22:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 22:30:35 --> Input Class Initialized
INFO - 2021-09-24 22:30:35 --> Language Class Initialized
INFO - 2021-09-24 22:30:35 --> Loader Class Initialized
INFO - 2021-09-24 22:30:35 --> Helper loaded: url_helper
INFO - 2021-09-24 22:30:35 --> Helper loaded: file_helper
DEBUG - 2021-09-24 22:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 22:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 22:30:35 --> Controller Class Initialized
INFO - 2021-09-24 22:30:35 --> Database Driver Class Initialized
INFO - 2021-09-24 22:30:35 --> Model "BlogModel" initialized
INFO - 2021-09-24 22:30:35 --> Helper loaded: cookie_helper
INFO - 2021-09-24 22:30:35 --> Model "CookieModel" initialized
INFO - 2021-09-24 22:30:35 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 22:30:35 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-24 22:30:35 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 22:30:35 --> Final output sent to browser
DEBUG - 2021-09-24 22:30:35 --> Total execution time: 0.0441
INFO - 2021-09-24 22:30:37 --> Config Class Initialized
INFO - 2021-09-24 22:30:37 --> Hooks Class Initialized
DEBUG - 2021-09-24 22:30:37 --> UTF-8 Support Enabled
INFO - 2021-09-24 22:30:37 --> Utf8 Class Initialized
INFO - 2021-09-24 22:30:37 --> URI Class Initialized
INFO - 2021-09-24 22:30:37 --> Router Class Initialized
INFO - 2021-09-24 22:30:37 --> Output Class Initialized
INFO - 2021-09-24 22:30:37 --> Security Class Initialized
DEBUG - 2021-09-24 22:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 22:30:37 --> Input Class Initialized
INFO - 2021-09-24 22:30:37 --> Language Class Initialized
INFO - 2021-09-24 22:30:37 --> Loader Class Initialized
INFO - 2021-09-24 22:30:37 --> Helper loaded: url_helper
INFO - 2021-09-24 22:30:37 --> Helper loaded: file_helper
DEBUG - 2021-09-24 22:30:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 22:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 22:30:37 --> Controller Class Initialized
INFO - 2021-09-24 22:30:37 --> Database Driver Class Initialized
INFO - 2021-09-24 22:30:37 --> Model "BlogModel" initialized
INFO - 2021-09-24 22:30:37 --> Helper loaded: cookie_helper
INFO - 2021-09-24 22:30:37 --> Model "CookieModel" initialized
INFO - 2021-09-24 22:30:37 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 22:30:37 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-24 22:30:37 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 22:30:37 --> Final output sent to browser
DEBUG - 2021-09-24 22:30:37 --> Total execution time: 0.0427
INFO - 2021-09-24 22:30:38 --> Config Class Initialized
INFO - 2021-09-24 22:30:38 --> Hooks Class Initialized
DEBUG - 2021-09-24 22:30:38 --> UTF-8 Support Enabled
INFO - 2021-09-24 22:30:38 --> Utf8 Class Initialized
INFO - 2021-09-24 22:30:38 --> URI Class Initialized
INFO - 2021-09-24 22:30:38 --> Router Class Initialized
INFO - 2021-09-24 22:30:38 --> Output Class Initialized
INFO - 2021-09-24 22:30:38 --> Security Class Initialized
DEBUG - 2021-09-24 22:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 22:30:38 --> Input Class Initialized
INFO - 2021-09-24 22:30:38 --> Language Class Initialized
INFO - 2021-09-24 22:30:38 --> Loader Class Initialized
INFO - 2021-09-24 22:30:38 --> Helper loaded: url_helper
INFO - 2021-09-24 22:30:38 --> Helper loaded: file_helper
DEBUG - 2021-09-24 22:30:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 22:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 22:30:38 --> Controller Class Initialized
INFO - 2021-09-24 22:30:38 --> Database Driver Class Initialized
INFO - 2021-09-24 22:30:38 --> Model "BlogModel" initialized
INFO - 2021-09-24 22:30:38 --> Helper loaded: cookie_helper
INFO - 2021-09-24 22:30:38 --> Model "CookieModel" initialized
INFO - 2021-09-24 22:30:38 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 22:30:38 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-24 22:30:38 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 22:30:38 --> Final output sent to browser
DEBUG - 2021-09-24 22:30:38 --> Total execution time: 0.0436
INFO - 2021-09-24 22:30:55 --> Config Class Initialized
INFO - 2021-09-24 22:30:55 --> Hooks Class Initialized
DEBUG - 2021-09-24 22:30:55 --> UTF-8 Support Enabled
INFO - 2021-09-24 22:30:55 --> Utf8 Class Initialized
INFO - 2021-09-24 22:30:55 --> URI Class Initialized
INFO - 2021-09-24 22:30:55 --> Router Class Initialized
INFO - 2021-09-24 22:30:55 --> Output Class Initialized
INFO - 2021-09-24 22:30:55 --> Security Class Initialized
DEBUG - 2021-09-24 22:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 22:30:55 --> Input Class Initialized
INFO - 2021-09-24 22:30:55 --> Language Class Initialized
INFO - 2021-09-24 22:30:55 --> Loader Class Initialized
INFO - 2021-09-24 22:30:55 --> Helper loaded: url_helper
INFO - 2021-09-24 22:30:55 --> Helper loaded: file_helper
DEBUG - 2021-09-24 22:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 22:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 22:30:55 --> Controller Class Initialized
INFO - 2021-09-24 22:30:55 --> Database Driver Class Initialized
INFO - 2021-09-24 22:30:55 --> Model "BlogModel" initialized
INFO - 2021-09-24 22:30:55 --> Helper loaded: cookie_helper
INFO - 2021-09-24 22:30:55 --> Model "CookieModel" initialized
INFO - 2021-09-24 22:30:55 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 22:30:55 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-24 22:30:55 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 22:30:55 --> Final output sent to browser
DEBUG - 2021-09-24 22:30:55 --> Total execution time: 0.0430
INFO - 2021-09-24 22:30:59 --> Config Class Initialized
INFO - 2021-09-24 22:30:59 --> Hooks Class Initialized
DEBUG - 2021-09-24 22:30:59 --> UTF-8 Support Enabled
INFO - 2021-09-24 22:30:59 --> Utf8 Class Initialized
INFO - 2021-09-24 22:30:59 --> URI Class Initialized
DEBUG - 2021-09-24 22:30:59 --> No URI present. Default controller set.
INFO - 2021-09-24 22:30:59 --> Router Class Initialized
INFO - 2021-09-24 22:30:59 --> Output Class Initialized
INFO - 2021-09-24 22:30:59 --> Security Class Initialized
DEBUG - 2021-09-24 22:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 22:30:59 --> Input Class Initialized
INFO - 2021-09-24 22:30:59 --> Language Class Initialized
INFO - 2021-09-24 22:30:59 --> Loader Class Initialized
INFO - 2021-09-24 22:30:59 --> Helper loaded: url_helper
INFO - 2021-09-24 22:30:59 --> Helper loaded: file_helper
DEBUG - 2021-09-24 22:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 22:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 22:30:59 --> Controller Class Initialized
INFO - 2021-09-24 22:30:59 --> Helper loaded: cookie_helper
INFO - 2021-09-24 22:30:59 --> Model "CookieModel" initialized
INFO - 2021-09-24 22:30:59 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 22:30:59 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-09-24 22:30:59 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 22:30:59 --> Final output sent to browser
DEBUG - 2021-09-24 22:30:59 --> Total execution time: 0.0394
INFO - 2021-09-24 22:31:05 --> Config Class Initialized
INFO - 2021-09-24 22:31:05 --> Hooks Class Initialized
DEBUG - 2021-09-24 22:31:05 --> UTF-8 Support Enabled
INFO - 2021-09-24 22:31:05 --> Utf8 Class Initialized
INFO - 2021-09-24 22:31:05 --> URI Class Initialized
INFO - 2021-09-24 22:31:05 --> Router Class Initialized
INFO - 2021-09-24 22:31:05 --> Output Class Initialized
INFO - 2021-09-24 22:31:05 --> Security Class Initialized
DEBUG - 2021-09-24 22:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 22:31:05 --> Input Class Initialized
INFO - 2021-09-24 22:31:05 --> Language Class Initialized
INFO - 2021-09-24 22:31:05 --> Loader Class Initialized
INFO - 2021-09-24 22:31:05 --> Helper loaded: url_helper
INFO - 2021-09-24 22:31:05 --> Helper loaded: file_helper
DEBUG - 2021-09-24 22:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 22:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 22:31:05 --> Controller Class Initialized
INFO - 2021-09-24 22:31:05 --> Database Driver Class Initialized
INFO - 2021-09-24 22:31:05 --> Helper loaded: string_helper
INFO - 2021-09-24 22:31:05 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 22:31:05 --> Helper loaded: cookie_helper
INFO - 2021-09-24 22:31:05 --> Model "CookieModel" initialized
INFO - 2021-09-24 22:31:05 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 22:31:05 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/videotestimonials.php
INFO - 2021-09-24 22:31:05 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 22:31:05 --> Final output sent to browser
DEBUG - 2021-09-24 22:31:05 --> Total execution time: 0.0594
INFO - 2021-09-24 22:31:12 --> Config Class Initialized
INFO - 2021-09-24 22:31:12 --> Hooks Class Initialized
DEBUG - 2021-09-24 22:31:12 --> UTF-8 Support Enabled
INFO - 2021-09-24 22:31:12 --> Utf8 Class Initialized
INFO - 2021-09-24 22:31:12 --> URI Class Initialized
INFO - 2021-09-24 22:31:12 --> Router Class Initialized
INFO - 2021-09-24 22:31:12 --> Output Class Initialized
INFO - 2021-09-24 22:31:12 --> Security Class Initialized
DEBUG - 2021-09-24 22:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 22:31:12 --> Input Class Initialized
INFO - 2021-09-24 22:31:12 --> Language Class Initialized
INFO - 2021-09-24 22:31:12 --> Loader Class Initialized
INFO - 2021-09-24 22:31:12 --> Helper loaded: url_helper
INFO - 2021-09-24 22:31:12 --> Helper loaded: file_helper
DEBUG - 2021-09-24 22:31:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 22:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 22:31:12 --> Controller Class Initialized
INFO - 2021-09-24 22:31:12 --> Database Driver Class Initialized
INFO - 2021-09-24 22:31:12 --> Model "BlogModel" initialized
INFO - 2021-09-24 22:31:12 --> Helper loaded: cookie_helper
INFO - 2021-09-24 22:31:12 --> Model "CookieModel" initialized
INFO - 2021-09-24 22:31:12 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 22:31:12 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-24 22:31:12 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 22:31:12 --> Final output sent to browser
DEBUG - 2021-09-24 22:31:12 --> Total execution time: 0.0653
INFO - 2021-09-24 22:32:13 --> Config Class Initialized
INFO - 2021-09-24 22:32:13 --> Hooks Class Initialized
DEBUG - 2021-09-24 22:32:13 --> UTF-8 Support Enabled
INFO - 2021-09-24 22:32:13 --> Utf8 Class Initialized
INFO - 2021-09-24 22:32:13 --> URI Class Initialized
INFO - 2021-09-24 22:32:13 --> Router Class Initialized
INFO - 2021-09-24 22:32:13 --> Output Class Initialized
INFO - 2021-09-24 22:32:13 --> Security Class Initialized
DEBUG - 2021-09-24 22:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 22:32:13 --> Input Class Initialized
INFO - 2021-09-24 22:32:13 --> Language Class Initialized
INFO - 2021-09-24 22:32:13 --> Loader Class Initialized
INFO - 2021-09-24 22:32:13 --> Helper loaded: url_helper
INFO - 2021-09-24 22:32:13 --> Helper loaded: file_helper
DEBUG - 2021-09-24 22:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 22:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 22:32:13 --> Controller Class Initialized
INFO - 2021-09-24 22:32:13 --> Database Driver Class Initialized
INFO - 2021-09-24 22:32:13 --> Model "BlogModel" initialized
INFO - 2021-09-24 22:32:13 --> Helper loaded: cookie_helper
INFO - 2021-09-24 22:32:13 --> Model "CookieModel" initialized
INFO - 2021-09-24 22:32:13 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 22:32:13 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-24 22:32:13 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 22:32:13 --> Final output sent to browser
DEBUG - 2021-09-24 22:32:13 --> Total execution time: 0.0473
INFO - 2021-09-24 22:35:01 --> Config Class Initialized
INFO - 2021-09-24 22:35:01 --> Hooks Class Initialized
DEBUG - 2021-09-24 22:35:01 --> UTF-8 Support Enabled
INFO - 2021-09-24 22:35:01 --> Utf8 Class Initialized
INFO - 2021-09-24 22:35:01 --> URI Class Initialized
INFO - 2021-09-24 22:35:01 --> Router Class Initialized
INFO - 2021-09-24 22:35:01 --> Output Class Initialized
INFO - 2021-09-24 22:35:01 --> Security Class Initialized
DEBUG - 2021-09-24 22:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 22:35:01 --> Input Class Initialized
INFO - 2021-09-24 22:35:01 --> Language Class Initialized
INFO - 2021-09-24 22:35:01 --> Loader Class Initialized
INFO - 2021-09-24 22:35:01 --> Helper loaded: url_helper
INFO - 2021-09-24 22:35:01 --> Helper loaded: file_helper
DEBUG - 2021-09-24 22:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 22:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 22:35:01 --> Controller Class Initialized
INFO - 2021-09-24 22:35:01 --> Database Driver Class Initialized
INFO - 2021-09-24 22:35:01 --> Model "BlogModel" initialized
INFO - 2021-09-24 22:35:01 --> Helper loaded: cookie_helper
INFO - 2021-09-24 22:35:01 --> Model "CookieModel" initialized
INFO - 2021-09-24 22:35:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 22:35:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-24 22:35:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 22:35:01 --> Final output sent to browser
DEBUG - 2021-09-24 22:35:01 --> Total execution time: 0.0532
INFO - 2021-09-24 22:38:37 --> Config Class Initialized
INFO - 2021-09-24 22:38:37 --> Hooks Class Initialized
DEBUG - 2021-09-24 22:38:37 --> UTF-8 Support Enabled
INFO - 2021-09-24 22:38:37 --> Utf8 Class Initialized
INFO - 2021-09-24 22:38:37 --> URI Class Initialized
INFO - 2021-09-24 22:38:37 --> Router Class Initialized
INFO - 2021-09-24 22:38:37 --> Output Class Initialized
INFO - 2021-09-24 22:38:37 --> Security Class Initialized
DEBUG - 2021-09-24 22:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 22:38:37 --> Input Class Initialized
INFO - 2021-09-24 22:38:37 --> Language Class Initialized
INFO - 2021-09-24 22:38:37 --> Loader Class Initialized
INFO - 2021-09-24 22:38:37 --> Helper loaded: url_helper
INFO - 2021-09-24 22:38:37 --> Helper loaded: file_helper
DEBUG - 2021-09-24 22:38:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 22:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 22:38:37 --> Controller Class Initialized
INFO - 2021-09-24 22:38:37 --> Database Driver Class Initialized
INFO - 2021-09-24 22:38:37 --> Helper loaded: string_helper
INFO - 2021-09-24 22:38:37 --> Model "TestimonialModel" initialized
INFO - 2021-09-24 22:38:37 --> Helper loaded: cookie_helper
INFO - 2021-09-24 22:38:37 --> Model "CookieModel" initialized
INFO - 2021-09-24 22:38:37 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 22:38:37 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/videotestimonials.php
INFO - 2021-09-24 22:38:37 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 22:38:37 --> Final output sent to browser
DEBUG - 2021-09-24 22:38:37 --> Total execution time: 0.0471
INFO - 2021-09-24 22:38:38 --> Config Class Initialized
INFO - 2021-09-24 22:38:38 --> Hooks Class Initialized
DEBUG - 2021-09-24 22:38:38 --> UTF-8 Support Enabled
INFO - 2021-09-24 22:38:38 --> Utf8 Class Initialized
INFO - 2021-09-24 22:38:38 --> URI Class Initialized
INFO - 2021-09-24 22:38:38 --> Router Class Initialized
INFO - 2021-09-24 22:38:38 --> Output Class Initialized
INFO - 2021-09-24 22:38:38 --> Security Class Initialized
DEBUG - 2021-09-24 22:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 22:38:38 --> Input Class Initialized
INFO - 2021-09-24 22:38:38 --> Language Class Initialized
INFO - 2021-09-24 22:38:38 --> Loader Class Initialized
INFO - 2021-09-24 22:38:38 --> Helper loaded: url_helper
INFO - 2021-09-24 22:38:38 --> Helper loaded: file_helper
DEBUG - 2021-09-24 22:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 22:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 22:38:38 --> Controller Class Initialized
INFO - 2021-09-24 22:38:38 --> Database Driver Class Initialized
INFO - 2021-09-24 22:38:38 --> Model "BlogModel" initialized
INFO - 2021-09-24 22:38:38 --> Helper loaded: cookie_helper
INFO - 2021-09-24 22:38:38 --> Model "CookieModel" initialized
INFO - 2021-09-24 22:38:38 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 22:38:38 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-24 22:38:38 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 22:38:38 --> Final output sent to browser
DEBUG - 2021-09-24 22:38:38 --> Total execution time: 0.0440
INFO - 2021-09-24 22:38:50 --> Config Class Initialized
INFO - 2021-09-24 22:38:50 --> Hooks Class Initialized
DEBUG - 2021-09-24 22:38:50 --> UTF-8 Support Enabled
INFO - 2021-09-24 22:38:50 --> Utf8 Class Initialized
INFO - 2021-09-24 22:38:50 --> URI Class Initialized
INFO - 2021-09-24 22:38:50 --> Router Class Initialized
INFO - 2021-09-24 22:38:50 --> Output Class Initialized
INFO - 2021-09-24 22:38:50 --> Security Class Initialized
DEBUG - 2021-09-24 22:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 22:38:50 --> Input Class Initialized
INFO - 2021-09-24 22:38:50 --> Language Class Initialized
INFO - 2021-09-24 22:38:50 --> Loader Class Initialized
INFO - 2021-09-24 22:38:50 --> Helper loaded: url_helper
INFO - 2021-09-24 22:38:50 --> Helper loaded: file_helper
DEBUG - 2021-09-24 22:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 22:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 22:38:50 --> Controller Class Initialized
INFO - 2021-09-24 22:38:50 --> Database Driver Class Initialized
INFO - 2021-09-24 22:38:50 --> Model "BlogModel" initialized
INFO - 2021-09-24 22:38:50 --> Helper loaded: cookie_helper
INFO - 2021-09-24 22:38:50 --> Model "CookieModel" initialized
INFO - 2021-09-24 22:38:50 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 22:38:50 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-24 22:38:50 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 22:38:50 --> Final output sent to browser
DEBUG - 2021-09-24 22:38:50 --> Total execution time: 0.0419
INFO - 2021-09-24 22:39:09 --> Config Class Initialized
INFO - 2021-09-24 22:39:09 --> Hooks Class Initialized
DEBUG - 2021-09-24 22:39:09 --> UTF-8 Support Enabled
INFO - 2021-09-24 22:39:09 --> Utf8 Class Initialized
INFO - 2021-09-24 22:39:09 --> URI Class Initialized
INFO - 2021-09-24 22:39:09 --> Router Class Initialized
INFO - 2021-09-24 22:39:10 --> Output Class Initialized
INFO - 2021-09-24 22:39:10 --> Security Class Initialized
DEBUG - 2021-09-24 22:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 22:39:10 --> Input Class Initialized
INFO - 2021-09-24 22:39:10 --> Language Class Initialized
INFO - 2021-09-24 22:39:10 --> Loader Class Initialized
INFO - 2021-09-24 22:39:10 --> Helper loaded: url_helper
INFO - 2021-09-24 22:39:10 --> Helper loaded: file_helper
DEBUG - 2021-09-24 22:39:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 22:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 22:39:10 --> Controller Class Initialized
INFO - 2021-09-24 22:39:10 --> Database Driver Class Initialized
INFO - 2021-09-24 22:39:10 --> Model "BlogModel" initialized
INFO - 2021-09-24 22:39:10 --> Helper loaded: cookie_helper
INFO - 2021-09-24 22:39:10 --> Model "CookieModel" initialized
INFO - 2021-09-24 22:39:10 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 22:39:10 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-24 22:39:10 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 22:39:10 --> Final output sent to browser
DEBUG - 2021-09-24 22:39:10 --> Total execution time: 0.0465
INFO - 2021-09-24 22:39:19 --> Config Class Initialized
INFO - 2021-09-24 22:39:19 --> Hooks Class Initialized
DEBUG - 2021-09-24 22:39:19 --> UTF-8 Support Enabled
INFO - 2021-09-24 22:39:19 --> Utf8 Class Initialized
INFO - 2021-09-24 22:39:19 --> URI Class Initialized
INFO - 2021-09-24 22:39:19 --> Router Class Initialized
INFO - 2021-09-24 22:39:19 --> Output Class Initialized
INFO - 2021-09-24 22:39:19 --> Security Class Initialized
DEBUG - 2021-09-24 22:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 22:39:19 --> Input Class Initialized
INFO - 2021-09-24 22:39:19 --> Language Class Initialized
INFO - 2021-09-24 22:39:19 --> Loader Class Initialized
INFO - 2021-09-24 22:39:19 --> Helper loaded: url_helper
INFO - 2021-09-24 22:39:19 --> Helper loaded: file_helper
DEBUG - 2021-09-24 22:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 22:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 22:39:19 --> Controller Class Initialized
INFO - 2021-09-24 22:39:19 --> Database Driver Class Initialized
INFO - 2021-09-24 22:39:19 --> Model "BlogModel" initialized
INFO - 2021-09-24 22:39:19 --> Helper loaded: cookie_helper
INFO - 2021-09-24 22:39:19 --> Model "CookieModel" initialized
INFO - 2021-09-24 22:39:20 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 22:39:20 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-24 22:39:20 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 22:39:20 --> Final output sent to browser
DEBUG - 2021-09-24 22:39:20 --> Total execution time: 0.0469
INFO - 2021-09-24 22:41:14 --> Config Class Initialized
INFO - 2021-09-24 22:41:14 --> Hooks Class Initialized
DEBUG - 2021-09-24 22:41:14 --> UTF-8 Support Enabled
INFO - 2021-09-24 22:41:14 --> Utf8 Class Initialized
INFO - 2021-09-24 22:41:14 --> URI Class Initialized
INFO - 2021-09-24 22:41:14 --> Router Class Initialized
INFO - 2021-09-24 22:41:14 --> Output Class Initialized
INFO - 2021-09-24 22:41:14 --> Security Class Initialized
DEBUG - 2021-09-24 22:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 22:41:14 --> Input Class Initialized
INFO - 2021-09-24 22:41:14 --> Language Class Initialized
INFO - 2021-09-24 22:41:14 --> Loader Class Initialized
INFO - 2021-09-24 22:41:14 --> Helper loaded: url_helper
INFO - 2021-09-24 22:41:14 --> Helper loaded: file_helper
DEBUG - 2021-09-24 22:41:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 22:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 22:41:14 --> Controller Class Initialized
INFO - 2021-09-24 22:41:14 --> Database Driver Class Initialized
INFO - 2021-09-24 22:41:14 --> Model "BlogModel" initialized
INFO - 2021-09-24 22:41:14 --> Helper loaded: cookie_helper
INFO - 2021-09-24 22:41:14 --> Model "CookieModel" initialized
INFO - 2021-09-24 22:41:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 22:41:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-24 22:41:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 22:41:14 --> Final output sent to browser
DEBUG - 2021-09-24 22:41:14 --> Total execution time: 0.0473
INFO - 2021-09-24 22:44:53 --> Config Class Initialized
INFO - 2021-09-24 22:44:53 --> Hooks Class Initialized
DEBUG - 2021-09-24 22:44:53 --> UTF-8 Support Enabled
INFO - 2021-09-24 22:44:53 --> Utf8 Class Initialized
INFO - 2021-09-24 22:44:53 --> URI Class Initialized
INFO - 2021-09-24 22:44:53 --> Router Class Initialized
INFO - 2021-09-24 22:44:53 --> Output Class Initialized
INFO - 2021-09-24 22:44:53 --> Security Class Initialized
DEBUG - 2021-09-24 22:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 22:44:53 --> Input Class Initialized
INFO - 2021-09-24 22:44:53 --> Language Class Initialized
INFO - 2021-09-24 22:44:53 --> Loader Class Initialized
INFO - 2021-09-24 22:44:53 --> Helper loaded: url_helper
INFO - 2021-09-24 22:44:53 --> Helper loaded: file_helper
DEBUG - 2021-09-24 22:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 22:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 22:44:53 --> Controller Class Initialized
INFO - 2021-09-24 22:44:53 --> Database Driver Class Initialized
INFO - 2021-09-24 22:44:53 --> Model "BlogModel" initialized
INFO - 2021-09-24 22:44:53 --> Helper loaded: cookie_helper
INFO - 2021-09-24 22:44:53 --> Model "CookieModel" initialized
INFO - 2021-09-24 22:44:53 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 22:44:53 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-24 22:44:53 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 22:44:53 --> Final output sent to browser
DEBUG - 2021-09-24 22:44:53 --> Total execution time: 0.0604
INFO - 2021-09-24 22:45:02 --> Config Class Initialized
INFO - 2021-09-24 22:45:02 --> Hooks Class Initialized
DEBUG - 2021-09-24 22:45:02 --> UTF-8 Support Enabled
INFO - 2021-09-24 22:45:02 --> Utf8 Class Initialized
INFO - 2021-09-24 22:45:02 --> URI Class Initialized
INFO - 2021-09-24 22:45:02 --> Router Class Initialized
INFO - 2021-09-24 22:45:02 --> Output Class Initialized
INFO - 2021-09-24 22:45:02 --> Security Class Initialized
DEBUG - 2021-09-24 22:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-24 22:45:02 --> Input Class Initialized
INFO - 2021-09-24 22:45:02 --> Language Class Initialized
INFO - 2021-09-24 22:45:02 --> Loader Class Initialized
INFO - 2021-09-24 22:45:02 --> Helper loaded: url_helper
INFO - 2021-09-24 22:45:02 --> Helper loaded: file_helper
DEBUG - 2021-09-24 22:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-24 22:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-24 22:45:02 --> Controller Class Initialized
INFO - 2021-09-24 22:45:02 --> Database Driver Class Initialized
INFO - 2021-09-24 22:45:03 --> Model "BlogModel" initialized
INFO - 2021-09-24 22:45:03 --> Helper loaded: cookie_helper
INFO - 2021-09-24 22:45:03 --> Model "CookieModel" initialized
INFO - 2021-09-24 22:45:03 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-24 22:45:03 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-24 22:45:03 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-24 22:45:03 --> Final output sent to browser
DEBUG - 2021-09-24 22:45:03 --> Total execution time: 0.0591
