<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-10-08 11:19:45 --> Config Class Initialized
INFO - 2021-10-08 11:19:45 --> Hooks Class Initialized
DEBUG - 2021-10-08 11:19:45 --> UTF-8 Support Enabled
INFO - 2021-10-08 11:19:45 --> Utf8 Class Initialized
INFO - 2021-10-08 11:19:45 --> URI Class Initialized
DEBUG - 2021-10-08 11:19:45 --> No URI present. Default controller set.
INFO - 2021-10-08 11:19:45 --> Router Class Initialized
INFO - 2021-10-08 11:19:45 --> Output Class Initialized
INFO - 2021-10-08 11:19:45 --> Security Class Initialized
DEBUG - 2021-10-08 11:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-08 11:19:45 --> Input Class Initialized
INFO - 2021-10-08 11:19:45 --> Language Class Initialized
INFO - 2021-10-08 11:19:45 --> Loader Class Initialized
INFO - 2021-10-08 11:19:45 --> Helper loaded: url_helper
INFO - 2021-10-08 11:19:45 --> Helper loaded: file_helper
DEBUG - 2021-10-08 11:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-08 11:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-08 11:19:46 --> Controller Class Initialized
INFO - 2021-10-08 11:19:46 --> Helper loaded: cookie_helper
INFO - 2021-10-08 11:19:46 --> Model "CookieModel" initialized
INFO - 2021-10-08 11:19:46 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-10-08 11:19:46 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-10-08 11:19:46 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-10-08 11:19:46 --> Final output sent to browser
DEBUG - 2021-10-08 11:19:46 --> Total execution time: 0.6406
