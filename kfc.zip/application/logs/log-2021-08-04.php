<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-08-04 14:34:48 --> Config Class Initialized
INFO - 2021-08-04 14:34:48 --> Hooks Class Initialized
DEBUG - 2021-08-04 14:34:48 --> UTF-8 Support Enabled
INFO - 2021-08-04 14:34:48 --> Utf8 Class Initialized
INFO - 2021-08-04 14:34:48 --> URI Class Initialized
DEBUG - 2021-08-04 14:34:48 --> No URI present. Default controller set.
INFO - 2021-08-04 14:34:48 --> Router Class Initialized
INFO - 2021-08-04 14:34:48 --> Output Class Initialized
INFO - 2021-08-04 14:34:48 --> Security Class Initialized
DEBUG - 2021-08-04 14:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-04 14:34:48 --> Input Class Initialized
INFO - 2021-08-04 14:34:48 --> Language Class Initialized
INFO - 2021-08-04 14:34:48 --> Loader Class Initialized
INFO - 2021-08-04 14:34:48 --> Helper loaded: url_helper
INFO - 2021-08-04 14:34:48 --> Helper loaded: file_helper
INFO - 2021-08-04 14:34:48 --> Database Driver Class Initialized
DEBUG - 2021-08-04 14:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-04 14:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-04 14:34:49 --> Controller Class Initialized
INFO - 2021-08-04 14:34:49 --> Helper loaded: cookie_helper
INFO - 2021-08-04 14:34:49 --> Model "CookieModel" initialized
INFO - 2021-08-04 14:34:49 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-04 14:34:49 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-04 14:34:49 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-04 14:34:49 --> Final output sent to browser
DEBUG - 2021-08-04 14:34:49 --> Total execution time: 0.9882
INFO - 2021-08-04 14:35:12 --> Config Class Initialized
INFO - 2021-08-04 14:35:12 --> Hooks Class Initialized
DEBUG - 2021-08-04 14:35:12 --> UTF-8 Support Enabled
INFO - 2021-08-04 14:35:12 --> Utf8 Class Initialized
INFO - 2021-08-04 14:35:12 --> URI Class Initialized
DEBUG - 2021-08-04 14:35:12 --> No URI present. Default controller set.
INFO - 2021-08-04 14:35:12 --> Router Class Initialized
INFO - 2021-08-04 14:35:12 --> Output Class Initialized
INFO - 2021-08-04 14:35:12 --> Security Class Initialized
DEBUG - 2021-08-04 14:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-04 14:35:12 --> Input Class Initialized
INFO - 2021-08-04 14:35:12 --> Language Class Initialized
INFO - 2021-08-04 14:35:12 --> Loader Class Initialized
INFO - 2021-08-04 14:35:12 --> Helper loaded: url_helper
INFO - 2021-08-04 14:35:12 --> Helper loaded: file_helper
INFO - 2021-08-04 14:35:12 --> Database Driver Class Initialized
DEBUG - 2021-08-04 14:35:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-04 14:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-04 14:35:12 --> Controller Class Initialized
INFO - 2021-08-04 14:35:12 --> Helper loaded: cookie_helper
INFO - 2021-08-04 14:35:12 --> Model "CookieModel" initialized
INFO - 2021-08-04 14:35:12 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-04 14:35:12 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-04 14:35:12 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-04 14:35:12 --> Final output sent to browser
DEBUG - 2021-08-04 14:35:12 --> Total execution time: 0.0650
INFO - 2021-08-04 14:36:07 --> Config Class Initialized
INFO - 2021-08-04 14:36:07 --> Hooks Class Initialized
DEBUG - 2021-08-04 14:36:07 --> UTF-8 Support Enabled
INFO - 2021-08-04 14:36:07 --> Utf8 Class Initialized
INFO - 2021-08-04 14:36:07 --> URI Class Initialized
INFO - 2021-08-04 14:36:07 --> Router Class Initialized
INFO - 2021-08-04 14:36:07 --> Output Class Initialized
INFO - 2021-08-04 14:36:07 --> Security Class Initialized
DEBUG - 2021-08-04 14:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-04 14:36:07 --> Input Class Initialized
INFO - 2021-08-04 14:36:07 --> Language Class Initialized
INFO - 2021-08-04 14:36:07 --> Loader Class Initialized
INFO - 2021-08-04 14:36:07 --> Helper loaded: url_helper
INFO - 2021-08-04 14:36:07 --> Helper loaded: file_helper
INFO - 2021-08-04 14:36:07 --> Database Driver Class Initialized
DEBUG - 2021-08-04 14:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-04 14:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-04 14:36:07 --> Controller Class Initialized
INFO - 2021-08-04 14:36:07 --> Helper loaded: cookie_helper
INFO - 2021-08-04 14:36:07 --> Model "CookieModel" initialized
INFO - 2021-08-04 14:36:07 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-04 14:36:07 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-04 14:36:07 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-04 14:36:07 --> Final output sent to browser
DEBUG - 2021-08-04 14:36:07 --> Total execution time: 0.0661
INFO - 2021-08-04 15:00:53 --> Config Class Initialized
INFO - 2021-08-04 15:00:53 --> Hooks Class Initialized
DEBUG - 2021-08-04 15:00:53 --> UTF-8 Support Enabled
INFO - 2021-08-04 15:00:53 --> Utf8 Class Initialized
INFO - 2021-08-04 15:00:53 --> URI Class Initialized
INFO - 2021-08-04 15:00:53 --> Router Class Initialized
INFO - 2021-08-04 15:00:53 --> Output Class Initialized
INFO - 2021-08-04 15:00:53 --> Security Class Initialized
DEBUG - 2021-08-04 15:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-04 15:00:53 --> Input Class Initialized
INFO - 2021-08-04 15:00:53 --> Language Class Initialized
INFO - 2021-08-04 15:00:53 --> Loader Class Initialized
INFO - 2021-08-04 15:00:53 --> Helper loaded: url_helper
INFO - 2021-08-04 15:00:53 --> Helper loaded: file_helper
INFO - 2021-08-04 15:00:53 --> Database Driver Class Initialized
DEBUG - 2021-08-04 15:00:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-04 15:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-04 15:00:53 --> Controller Class Initialized
INFO - 2021-08-04 15:00:53 --> Helper loaded: cookie_helper
INFO - 2021-08-04 15:00:53 --> Model "CookieModel" initialized
INFO - 2021-08-04 15:00:53 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-04 15:00:53 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-04 15:00:53 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-04 15:00:53 --> Final output sent to browser
DEBUG - 2021-08-04 15:00:53 --> Total execution time: 0.1166
INFO - 2021-08-04 15:06:38 --> Config Class Initialized
INFO - 2021-08-04 15:06:38 --> Hooks Class Initialized
DEBUG - 2021-08-04 15:06:38 --> UTF-8 Support Enabled
INFO - 2021-08-04 15:06:38 --> Utf8 Class Initialized
INFO - 2021-08-04 15:06:38 --> URI Class Initialized
INFO - 2021-08-04 15:06:38 --> Router Class Initialized
INFO - 2021-08-04 15:06:38 --> Output Class Initialized
INFO - 2021-08-04 15:06:38 --> Security Class Initialized
DEBUG - 2021-08-04 15:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-04 15:06:38 --> Input Class Initialized
INFO - 2021-08-04 15:06:38 --> Language Class Initialized
INFO - 2021-08-04 15:06:38 --> Loader Class Initialized
INFO - 2021-08-04 15:06:38 --> Helper loaded: url_helper
INFO - 2021-08-04 15:06:38 --> Helper loaded: file_helper
INFO - 2021-08-04 15:06:38 --> Database Driver Class Initialized
DEBUG - 2021-08-04 15:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-04 15:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-04 15:06:38 --> Controller Class Initialized
INFO - 2021-08-04 15:06:38 --> Helper loaded: cookie_helper
INFO - 2021-08-04 15:06:38 --> Model "CookieModel" initialized
INFO - 2021-08-04 15:06:38 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-04 15:06:38 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-04 15:06:38 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-04 15:06:38 --> Final output sent to browser
DEBUG - 2021-08-04 15:06:38 --> Total execution time: 0.0820
INFO - 2021-08-04 15:07:00 --> Config Class Initialized
INFO - 2021-08-04 15:07:00 --> Hooks Class Initialized
DEBUG - 2021-08-04 15:07:00 --> UTF-8 Support Enabled
INFO - 2021-08-04 15:07:00 --> Utf8 Class Initialized
INFO - 2021-08-04 15:07:00 --> URI Class Initialized
INFO - 2021-08-04 15:07:00 --> Router Class Initialized
INFO - 2021-08-04 15:07:00 --> Output Class Initialized
INFO - 2021-08-04 15:07:00 --> Security Class Initialized
DEBUG - 2021-08-04 15:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-04 15:07:00 --> Input Class Initialized
INFO - 2021-08-04 15:07:00 --> Language Class Initialized
INFO - 2021-08-04 15:07:00 --> Loader Class Initialized
INFO - 2021-08-04 15:07:00 --> Helper loaded: url_helper
INFO - 2021-08-04 15:07:00 --> Helper loaded: file_helper
INFO - 2021-08-04 15:07:00 --> Database Driver Class Initialized
DEBUG - 2021-08-04 15:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-04 15:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-04 15:07:00 --> Controller Class Initialized
INFO - 2021-08-04 15:07:00 --> Helper loaded: cookie_helper
INFO - 2021-08-04 15:07:00 --> Model "CookieModel" initialized
INFO - 2021-08-04 15:07:00 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-04 15:07:00 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-04 15:07:00 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-04 15:07:00 --> Final output sent to browser
DEBUG - 2021-08-04 15:07:00 --> Total execution time: 0.0427
INFO - 2021-08-04 18:24:42 --> Config Class Initialized
INFO - 2021-08-04 18:24:42 --> Hooks Class Initialized
DEBUG - 2021-08-04 18:24:42 --> UTF-8 Support Enabled
INFO - 2021-08-04 18:24:42 --> Utf8 Class Initialized
INFO - 2021-08-04 18:24:42 --> URI Class Initialized
INFO - 2021-08-04 18:24:42 --> Router Class Initialized
INFO - 2021-08-04 18:24:42 --> Output Class Initialized
INFO - 2021-08-04 18:24:42 --> Security Class Initialized
DEBUG - 2021-08-04 18:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-04 18:24:42 --> Input Class Initialized
INFO - 2021-08-04 18:24:42 --> Language Class Initialized
INFO - 2021-08-04 18:24:42 --> Loader Class Initialized
INFO - 2021-08-04 18:24:42 --> Helper loaded: url_helper
INFO - 2021-08-04 18:24:42 --> Helper loaded: file_helper
INFO - 2021-08-04 18:24:42 --> Database Driver Class Initialized
DEBUG - 2021-08-04 18:24:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-04 18:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-04 18:24:42 --> Controller Class Initialized
INFO - 2021-08-04 18:24:42 --> Helper loaded: cookie_helper
INFO - 2021-08-04 18:24:42 --> Model "CookieModel" initialized
INFO - 2021-08-04 18:24:42 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-04 18:24:42 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-04 18:24:42 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-04 18:24:42 --> Final output sent to browser
DEBUG - 2021-08-04 18:24:42 --> Total execution time: 0.1760
INFO - 2021-08-04 18:26:35 --> Config Class Initialized
INFO - 2021-08-04 18:26:35 --> Hooks Class Initialized
DEBUG - 2021-08-04 18:26:35 --> UTF-8 Support Enabled
INFO - 2021-08-04 18:26:35 --> Utf8 Class Initialized
INFO - 2021-08-04 18:26:35 --> URI Class Initialized
INFO - 2021-08-04 18:26:35 --> Router Class Initialized
INFO - 2021-08-04 18:26:35 --> Output Class Initialized
INFO - 2021-08-04 18:26:35 --> Security Class Initialized
DEBUG - 2021-08-04 18:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-04 18:26:35 --> Input Class Initialized
INFO - 2021-08-04 18:26:35 --> Language Class Initialized
INFO - 2021-08-04 18:26:35 --> Loader Class Initialized
INFO - 2021-08-04 18:26:35 --> Helper loaded: url_helper
INFO - 2021-08-04 18:26:35 --> Helper loaded: file_helper
INFO - 2021-08-04 18:26:35 --> Database Driver Class Initialized
DEBUG - 2021-08-04 18:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-04 18:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-04 18:26:35 --> Controller Class Initialized
INFO - 2021-08-04 18:26:35 --> Helper loaded: cookie_helper
INFO - 2021-08-04 18:26:35 --> Model "CookieModel" initialized
INFO - 2021-08-04 18:26:35 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-04 18:26:35 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-04 18:26:35 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-04 18:26:35 --> Final output sent to browser
DEBUG - 2021-08-04 18:26:35 --> Total execution time: 0.0849
INFO - 2021-08-04 18:36:27 --> Config Class Initialized
INFO - 2021-08-04 18:36:27 --> Hooks Class Initialized
DEBUG - 2021-08-04 18:36:27 --> UTF-8 Support Enabled
INFO - 2021-08-04 18:36:27 --> Utf8 Class Initialized
INFO - 2021-08-04 18:36:27 --> URI Class Initialized
INFO - 2021-08-04 18:36:27 --> Router Class Initialized
INFO - 2021-08-04 18:36:27 --> Output Class Initialized
INFO - 2021-08-04 18:36:27 --> Security Class Initialized
DEBUG - 2021-08-04 18:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-04 18:36:27 --> Input Class Initialized
INFO - 2021-08-04 18:36:27 --> Language Class Initialized
INFO - 2021-08-04 18:36:27 --> Loader Class Initialized
INFO - 2021-08-04 18:36:27 --> Helper loaded: url_helper
INFO - 2021-08-04 18:36:27 --> Helper loaded: file_helper
INFO - 2021-08-04 18:36:27 --> Database Driver Class Initialized
DEBUG - 2021-08-04 18:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-04 18:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-04 18:36:27 --> Controller Class Initialized
INFO - 2021-08-04 18:36:27 --> Helper loaded: cookie_helper
INFO - 2021-08-04 18:36:27 --> Model "CookieModel" initialized
INFO - 2021-08-04 18:36:27 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-04 18:36:27 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-04 18:36:27 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-04 18:36:27 --> Final output sent to browser
DEBUG - 2021-08-04 18:36:27 --> Total execution time: 0.0708
INFO - 2021-08-04 18:38:17 --> Config Class Initialized
INFO - 2021-08-04 18:38:17 --> Hooks Class Initialized
DEBUG - 2021-08-04 18:38:17 --> UTF-8 Support Enabled
INFO - 2021-08-04 18:38:17 --> Utf8 Class Initialized
INFO - 2021-08-04 18:38:17 --> URI Class Initialized
DEBUG - 2021-08-04 18:38:17 --> No URI present. Default controller set.
INFO - 2021-08-04 18:38:17 --> Router Class Initialized
INFO - 2021-08-04 18:38:17 --> Output Class Initialized
INFO - 2021-08-04 18:38:17 --> Security Class Initialized
DEBUG - 2021-08-04 18:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-04 18:38:17 --> Input Class Initialized
INFO - 2021-08-04 18:38:17 --> Language Class Initialized
INFO - 2021-08-04 18:38:17 --> Loader Class Initialized
INFO - 2021-08-04 18:38:17 --> Helper loaded: url_helper
INFO - 2021-08-04 18:38:17 --> Helper loaded: file_helper
INFO - 2021-08-04 18:38:17 --> Database Driver Class Initialized
DEBUG - 2021-08-04 18:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-04 18:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-04 18:38:17 --> Controller Class Initialized
INFO - 2021-08-04 18:38:17 --> Helper loaded: cookie_helper
INFO - 2021-08-04 18:38:17 --> Model "CookieModel" initialized
INFO - 2021-08-04 18:38:17 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-04 18:38:17 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-04 18:38:17 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-04 18:38:17 --> Final output sent to browser
DEBUG - 2021-08-04 18:38:17 --> Total execution time: 0.0793
INFO - 2021-08-04 18:45:34 --> Config Class Initialized
INFO - 2021-08-04 18:45:34 --> Hooks Class Initialized
DEBUG - 2021-08-04 18:45:34 --> UTF-8 Support Enabled
INFO - 2021-08-04 18:45:34 --> Utf8 Class Initialized
INFO - 2021-08-04 18:45:34 --> URI Class Initialized
DEBUG - 2021-08-04 18:45:34 --> No URI present. Default controller set.
INFO - 2021-08-04 18:45:34 --> Router Class Initialized
INFO - 2021-08-04 18:45:34 --> Output Class Initialized
INFO - 2021-08-04 18:45:34 --> Security Class Initialized
DEBUG - 2021-08-04 18:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-04 18:45:34 --> Input Class Initialized
INFO - 2021-08-04 18:45:34 --> Language Class Initialized
INFO - 2021-08-04 18:45:34 --> Loader Class Initialized
INFO - 2021-08-04 18:45:34 --> Helper loaded: url_helper
INFO - 2021-08-04 18:45:34 --> Helper loaded: file_helper
INFO - 2021-08-04 18:45:34 --> Database Driver Class Initialized
DEBUG - 2021-08-04 18:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-04 18:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-04 18:45:34 --> Controller Class Initialized
INFO - 2021-08-04 18:45:34 --> Helper loaded: cookie_helper
INFO - 2021-08-04 18:45:34 --> Model "CookieModel" initialized
INFO - 2021-08-04 18:45:34 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-04 18:45:34 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-04 18:45:34 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-04 18:45:34 --> Final output sent to browser
DEBUG - 2021-08-04 18:45:34 --> Total execution time: 0.0799
INFO - 2021-08-04 18:53:58 --> Config Class Initialized
INFO - 2021-08-04 18:53:58 --> Hooks Class Initialized
DEBUG - 2021-08-04 18:53:58 --> UTF-8 Support Enabled
INFO - 2021-08-04 18:53:58 --> Utf8 Class Initialized
INFO - 2021-08-04 18:53:58 --> URI Class Initialized
DEBUG - 2021-08-04 18:53:58 --> No URI present. Default controller set.
INFO - 2021-08-04 18:53:58 --> Router Class Initialized
INFO - 2021-08-04 18:53:58 --> Output Class Initialized
INFO - 2021-08-04 18:53:58 --> Security Class Initialized
DEBUG - 2021-08-04 18:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-04 18:53:58 --> Input Class Initialized
INFO - 2021-08-04 18:53:58 --> Language Class Initialized
INFO - 2021-08-04 18:53:58 --> Loader Class Initialized
INFO - 2021-08-04 18:53:58 --> Helper loaded: url_helper
INFO - 2021-08-04 18:53:58 --> Helper loaded: file_helper
INFO - 2021-08-04 18:53:58 --> Database Driver Class Initialized
DEBUG - 2021-08-04 18:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-04 18:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-04 18:53:58 --> Controller Class Initialized
INFO - 2021-08-04 18:53:58 --> Helper loaded: cookie_helper
INFO - 2021-08-04 18:53:58 --> Model "CookieModel" initialized
INFO - 2021-08-04 18:53:58 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-04 18:53:58 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-04 18:53:58 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-04 18:53:58 --> Final output sent to browser
DEBUG - 2021-08-04 18:53:58 --> Total execution time: 0.0715
INFO - 2021-08-04 18:54:21 --> Config Class Initialized
INFO - 2021-08-04 18:54:21 --> Hooks Class Initialized
DEBUG - 2021-08-04 18:54:21 --> UTF-8 Support Enabled
INFO - 2021-08-04 18:54:21 --> Utf8 Class Initialized
INFO - 2021-08-04 18:54:21 --> URI Class Initialized
DEBUG - 2021-08-04 18:54:21 --> No URI present. Default controller set.
INFO - 2021-08-04 18:54:21 --> Router Class Initialized
INFO - 2021-08-04 18:54:21 --> Output Class Initialized
INFO - 2021-08-04 18:54:22 --> Security Class Initialized
DEBUG - 2021-08-04 18:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-04 18:54:22 --> Input Class Initialized
INFO - 2021-08-04 18:54:22 --> Language Class Initialized
INFO - 2021-08-04 18:54:22 --> Loader Class Initialized
INFO - 2021-08-04 18:54:22 --> Helper loaded: url_helper
INFO - 2021-08-04 18:54:22 --> Helper loaded: file_helper
INFO - 2021-08-04 18:54:22 --> Database Driver Class Initialized
DEBUG - 2021-08-04 18:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-04 18:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-04 18:54:22 --> Controller Class Initialized
INFO - 2021-08-04 18:54:22 --> Helper loaded: cookie_helper
INFO - 2021-08-04 18:54:22 --> Model "CookieModel" initialized
INFO - 2021-08-04 18:54:22 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-04 18:54:22 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-04 18:54:22 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-04 18:54:22 --> Final output sent to browser
DEBUG - 2021-08-04 18:54:22 --> Total execution time: 0.0623
INFO - 2021-08-04 18:54:31 --> Config Class Initialized
INFO - 2021-08-04 18:54:31 --> Hooks Class Initialized
DEBUG - 2021-08-04 18:54:31 --> UTF-8 Support Enabled
INFO - 2021-08-04 18:54:31 --> Utf8 Class Initialized
INFO - 2021-08-04 18:54:31 --> URI Class Initialized
DEBUG - 2021-08-04 18:54:31 --> No URI present. Default controller set.
INFO - 2021-08-04 18:54:31 --> Router Class Initialized
INFO - 2021-08-04 18:54:31 --> Output Class Initialized
INFO - 2021-08-04 18:54:31 --> Security Class Initialized
DEBUG - 2021-08-04 18:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-04 18:54:31 --> Input Class Initialized
INFO - 2021-08-04 18:54:31 --> Language Class Initialized
INFO - 2021-08-04 18:54:31 --> Loader Class Initialized
INFO - 2021-08-04 18:54:31 --> Helper loaded: url_helper
INFO - 2021-08-04 18:54:31 --> Helper loaded: file_helper
INFO - 2021-08-04 18:54:31 --> Database Driver Class Initialized
DEBUG - 2021-08-04 18:54:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-04 18:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-04 18:54:31 --> Controller Class Initialized
INFO - 2021-08-04 18:54:31 --> Helper loaded: cookie_helper
INFO - 2021-08-04 18:54:31 --> Model "CookieModel" initialized
INFO - 2021-08-04 18:54:31 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-04 18:54:31 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-04 18:54:31 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-04 18:54:31 --> Final output sent to browser
DEBUG - 2021-08-04 18:54:31 --> Total execution time: 0.0609
INFO - 2021-08-04 18:55:25 --> Config Class Initialized
INFO - 2021-08-04 18:55:25 --> Hooks Class Initialized
DEBUG - 2021-08-04 18:55:25 --> UTF-8 Support Enabled
INFO - 2021-08-04 18:55:25 --> Utf8 Class Initialized
INFO - 2021-08-04 18:55:25 --> URI Class Initialized
DEBUG - 2021-08-04 18:55:25 --> No URI present. Default controller set.
INFO - 2021-08-04 18:55:25 --> Router Class Initialized
INFO - 2021-08-04 18:55:25 --> Output Class Initialized
INFO - 2021-08-04 18:55:25 --> Security Class Initialized
DEBUG - 2021-08-04 18:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-04 18:55:25 --> Input Class Initialized
INFO - 2021-08-04 18:55:25 --> Language Class Initialized
INFO - 2021-08-04 18:55:25 --> Loader Class Initialized
INFO - 2021-08-04 18:55:25 --> Helper loaded: url_helper
INFO - 2021-08-04 18:55:25 --> Helper loaded: file_helper
INFO - 2021-08-04 18:55:25 --> Database Driver Class Initialized
DEBUG - 2021-08-04 18:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-04 18:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-04 18:55:25 --> Controller Class Initialized
INFO - 2021-08-04 18:55:25 --> Helper loaded: cookie_helper
INFO - 2021-08-04 18:55:25 --> Model "CookieModel" initialized
INFO - 2021-08-04 18:55:25 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-04 18:55:25 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-04 18:55:25 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-04 18:55:25 --> Final output sent to browser
DEBUG - 2021-08-04 18:55:25 --> Total execution time: 0.0549
INFO - 2021-08-04 18:57:14 --> Config Class Initialized
INFO - 2021-08-04 18:57:14 --> Hooks Class Initialized
DEBUG - 2021-08-04 18:57:14 --> UTF-8 Support Enabled
INFO - 2021-08-04 18:57:14 --> Utf8 Class Initialized
INFO - 2021-08-04 18:57:14 --> URI Class Initialized
DEBUG - 2021-08-04 18:57:14 --> No URI present. Default controller set.
INFO - 2021-08-04 18:57:14 --> Router Class Initialized
INFO - 2021-08-04 18:57:14 --> Output Class Initialized
INFO - 2021-08-04 18:57:14 --> Security Class Initialized
DEBUG - 2021-08-04 18:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-04 18:57:14 --> Input Class Initialized
INFO - 2021-08-04 18:57:14 --> Language Class Initialized
INFO - 2021-08-04 18:57:14 --> Loader Class Initialized
INFO - 2021-08-04 18:57:14 --> Helper loaded: url_helper
INFO - 2021-08-04 18:57:14 --> Helper loaded: file_helper
INFO - 2021-08-04 18:57:14 --> Database Driver Class Initialized
DEBUG - 2021-08-04 18:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-04 18:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-04 18:57:14 --> Controller Class Initialized
INFO - 2021-08-04 18:57:14 --> Helper loaded: cookie_helper
INFO - 2021-08-04 18:57:14 --> Model "CookieModel" initialized
INFO - 2021-08-04 18:57:14 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-04 18:57:14 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-04 18:57:14 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-04 18:57:14 --> Final output sent to browser
DEBUG - 2021-08-04 18:57:14 --> Total execution time: 0.0475
INFO - 2021-08-04 18:57:31 --> Config Class Initialized
INFO - 2021-08-04 18:57:31 --> Hooks Class Initialized
DEBUG - 2021-08-04 18:57:31 --> UTF-8 Support Enabled
INFO - 2021-08-04 18:57:31 --> Utf8 Class Initialized
INFO - 2021-08-04 18:57:31 --> URI Class Initialized
INFO - 2021-08-04 18:57:31 --> Router Class Initialized
INFO - 2021-08-04 18:57:31 --> Output Class Initialized
INFO - 2021-08-04 18:57:31 --> Security Class Initialized
DEBUG - 2021-08-04 18:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-04 18:57:31 --> Input Class Initialized
INFO - 2021-08-04 18:57:31 --> Language Class Initialized
INFO - 2021-08-04 18:57:31 --> Loader Class Initialized
INFO - 2021-08-04 18:57:31 --> Helper loaded: url_helper
INFO - 2021-08-04 18:57:31 --> Helper loaded: file_helper
INFO - 2021-08-04 18:57:31 --> Database Driver Class Initialized
DEBUG - 2021-08-04 18:57:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-04 18:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-04 18:57:31 --> Controller Class Initialized
INFO - 2021-08-04 18:57:31 --> Helper loaded: cookie_helper
INFO - 2021-08-04 18:57:31 --> Model "CookieModel" initialized
INFO - 2021-08-04 18:57:31 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-04 18:57:31 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/functional_training.php
INFO - 2021-08-04 18:57:31 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-04 18:57:31 --> Final output sent to browser
DEBUG - 2021-08-04 18:57:31 --> Total execution time: 0.0947
INFO - 2021-08-04 18:57:44 --> Config Class Initialized
INFO - 2021-08-04 18:57:44 --> Hooks Class Initialized
DEBUG - 2021-08-04 18:57:44 --> UTF-8 Support Enabled
INFO - 2021-08-04 18:57:44 --> Utf8 Class Initialized
INFO - 2021-08-04 18:57:44 --> URI Class Initialized
INFO - 2021-08-04 18:57:44 --> Router Class Initialized
INFO - 2021-08-04 18:57:44 --> Output Class Initialized
INFO - 2021-08-04 18:57:44 --> Security Class Initialized
DEBUG - 2021-08-04 18:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-04 18:57:44 --> Input Class Initialized
INFO - 2021-08-04 18:57:44 --> Language Class Initialized
INFO - 2021-08-04 18:57:44 --> Loader Class Initialized
INFO - 2021-08-04 18:57:44 --> Helper loaded: url_helper
INFO - 2021-08-04 18:57:44 --> Helper loaded: file_helper
INFO - 2021-08-04 18:57:44 --> Database Driver Class Initialized
DEBUG - 2021-08-04 18:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-04 18:57:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-04 18:57:44 --> Controller Class Initialized
INFO - 2021-08-04 18:57:44 --> Helper loaded: cookie_helper
INFO - 2021-08-04 18:57:44 --> Model "CookieModel" initialized
INFO - 2021-08-04 18:57:44 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-04 18:57:44 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/nutrition_coaching.php
INFO - 2021-08-04 18:57:44 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-04 18:57:44 --> Final output sent to browser
DEBUG - 2021-08-04 18:57:44 --> Total execution time: 0.0788
INFO - 2021-08-04 18:57:47 --> Config Class Initialized
INFO - 2021-08-04 18:57:47 --> Hooks Class Initialized
DEBUG - 2021-08-04 18:57:47 --> UTF-8 Support Enabled
INFO - 2021-08-04 18:57:47 --> Utf8 Class Initialized
INFO - 2021-08-04 18:57:47 --> URI Class Initialized
INFO - 2021-08-04 18:57:47 --> Router Class Initialized
INFO - 2021-08-04 18:57:47 --> Output Class Initialized
INFO - 2021-08-04 18:57:47 --> Security Class Initialized
DEBUG - 2021-08-04 18:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-04 18:57:47 --> Input Class Initialized
INFO - 2021-08-04 18:57:47 --> Language Class Initialized
INFO - 2021-08-04 18:57:47 --> Loader Class Initialized
INFO - 2021-08-04 18:57:47 --> Helper loaded: url_helper
INFO - 2021-08-04 18:57:47 --> Helper loaded: file_helper
INFO - 2021-08-04 18:57:47 --> Database Driver Class Initialized
DEBUG - 2021-08-04 18:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-04 18:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-04 18:57:47 --> Controller Class Initialized
INFO - 2021-08-04 18:57:47 --> Helper loaded: cookie_helper
INFO - 2021-08-04 18:57:47 --> Model "CookieModel" initialized
INFO - 2021-08-04 18:57:47 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-04 18:57:47 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/success_stories.php
INFO - 2021-08-04 18:57:47 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-04 18:57:47 --> Final output sent to browser
DEBUG - 2021-08-04 18:57:47 --> Total execution time: 0.0931
INFO - 2021-08-04 18:57:52 --> Config Class Initialized
INFO - 2021-08-04 18:57:52 --> Hooks Class Initialized
DEBUG - 2021-08-04 18:57:52 --> UTF-8 Support Enabled
INFO - 2021-08-04 18:57:52 --> Utf8 Class Initialized
INFO - 2021-08-04 18:57:52 --> URI Class Initialized
INFO - 2021-08-04 18:57:52 --> Router Class Initialized
INFO - 2021-08-04 18:57:52 --> Output Class Initialized
INFO - 2021-08-04 18:57:52 --> Security Class Initialized
DEBUG - 2021-08-04 18:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-04 18:57:52 --> Input Class Initialized
INFO - 2021-08-04 18:57:52 --> Language Class Initialized
INFO - 2021-08-04 18:57:52 --> Loader Class Initialized
INFO - 2021-08-04 18:57:52 --> Helper loaded: url_helper
INFO - 2021-08-04 18:57:52 --> Helper loaded: file_helper
INFO - 2021-08-04 18:57:52 --> Database Driver Class Initialized
DEBUG - 2021-08-04 18:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-04 18:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-04 18:57:52 --> Controller Class Initialized
INFO - 2021-08-04 18:57:52 --> Helper loaded: cookie_helper
INFO - 2021-08-04 18:57:52 --> Model "CookieModel" initialized
INFO - 2021-08-04 18:57:52 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-04 18:57:52 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/about.php
INFO - 2021-08-04 18:57:52 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-04 18:57:52 --> Final output sent to browser
DEBUG - 2021-08-04 18:57:52 --> Total execution time: 0.0849
INFO - 2021-08-04 19:05:09 --> Config Class Initialized
INFO - 2021-08-04 19:05:09 --> Hooks Class Initialized
DEBUG - 2021-08-04 19:05:09 --> UTF-8 Support Enabled
INFO - 2021-08-04 19:05:09 --> Utf8 Class Initialized
INFO - 2021-08-04 19:05:09 --> URI Class Initialized
INFO - 2021-08-04 19:05:09 --> Router Class Initialized
INFO - 2021-08-04 19:05:09 --> Output Class Initialized
INFO - 2021-08-04 19:05:09 --> Security Class Initialized
DEBUG - 2021-08-04 19:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-04 19:05:09 --> Input Class Initialized
INFO - 2021-08-04 19:05:09 --> Language Class Initialized
INFO - 2021-08-04 19:05:09 --> Loader Class Initialized
INFO - 2021-08-04 19:05:09 --> Helper loaded: url_helper
INFO - 2021-08-04 19:05:09 --> Helper loaded: file_helper
INFO - 2021-08-04 19:05:09 --> Database Driver Class Initialized
DEBUG - 2021-08-04 19:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-04 19:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-04 19:05:09 --> Controller Class Initialized
INFO - 2021-08-04 19:05:09 --> Helper loaded: cookie_helper
INFO - 2021-08-04 19:05:09 --> Model "CookieModel" initialized
INFO - 2021-08-04 19:05:09 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-04 19:05:09 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/team.php
INFO - 2021-08-04 19:05:09 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-04 19:05:09 --> Final output sent to browser
DEBUG - 2021-08-04 19:05:09 --> Total execution time: 0.0847
