<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-08-07 09:09:37 --> Config Class Initialized
INFO - 2021-08-07 09:09:37 --> Hooks Class Initialized
DEBUG - 2021-08-07 09:09:37 --> UTF-8 Support Enabled
INFO - 2021-08-07 09:09:37 --> Utf8 Class Initialized
INFO - 2021-08-07 09:09:37 --> URI Class Initialized
INFO - 2021-08-07 09:09:37 --> Router Class Initialized
INFO - 2021-08-07 09:09:37 --> Output Class Initialized
INFO - 2021-08-07 09:09:37 --> Security Class Initialized
DEBUG - 2021-08-07 09:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 09:09:37 --> Input Class Initialized
INFO - 2021-08-07 09:09:37 --> Language Class Initialized
INFO - 2021-08-07 09:09:37 --> Loader Class Initialized
INFO - 2021-08-07 09:09:37 --> Helper loaded: url_helper
INFO - 2021-08-07 09:09:37 --> Helper loaded: file_helper
INFO - 2021-08-07 09:09:37 --> Database Driver Class Initialized
DEBUG - 2021-08-07 09:09:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 09:09:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 09:09:37 --> Controller Class Initialized
INFO - 2021-08-07 09:09:37 --> Helper loaded: cookie_helper
INFO - 2021-08-07 09:09:37 --> Model "CookieModel" initialized
INFO - 2021-08-07 09:09:37 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 09:09:37 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/success_stories.php
INFO - 2021-08-07 09:09:37 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 09:09:37 --> Final output sent to browser
DEBUG - 2021-08-07 09:09:37 --> Total execution time: 0.0981
INFO - 2021-08-07 09:10:06 --> Config Class Initialized
INFO - 2021-08-07 09:10:06 --> Hooks Class Initialized
DEBUG - 2021-08-07 09:10:06 --> UTF-8 Support Enabled
INFO - 2021-08-07 09:10:06 --> Utf8 Class Initialized
INFO - 2021-08-07 09:10:06 --> URI Class Initialized
INFO - 2021-08-07 09:10:06 --> Router Class Initialized
INFO - 2021-08-07 09:10:06 --> Output Class Initialized
INFO - 2021-08-07 09:10:06 --> Security Class Initialized
DEBUG - 2021-08-07 09:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 09:10:06 --> Input Class Initialized
INFO - 2021-08-07 09:10:06 --> Language Class Initialized
INFO - 2021-08-07 09:10:06 --> Loader Class Initialized
INFO - 2021-08-07 09:10:06 --> Helper loaded: url_helper
INFO - 2021-08-07 09:10:06 --> Helper loaded: file_helper
INFO - 2021-08-07 09:10:06 --> Database Driver Class Initialized
DEBUG - 2021-08-07 09:10:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 09:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 09:10:06 --> Controller Class Initialized
INFO - 2021-08-07 09:10:06 --> Helper loaded: cookie_helper
INFO - 2021-08-07 09:10:06 --> Model "CookieModel" initialized
INFO - 2021-08-07 09:10:06 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 09:10:06 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-07 09:10:06 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 09:10:06 --> Final output sent to browser
DEBUG - 2021-08-07 09:10:06 --> Total execution time: 0.0435
INFO - 2021-08-07 09:10:41 --> Config Class Initialized
INFO - 2021-08-07 09:10:41 --> Hooks Class Initialized
DEBUG - 2021-08-07 09:10:41 --> UTF-8 Support Enabled
INFO - 2021-08-07 09:10:41 --> Utf8 Class Initialized
INFO - 2021-08-07 09:10:41 --> URI Class Initialized
INFO - 2021-08-07 09:10:41 --> Router Class Initialized
INFO - 2021-08-07 09:10:41 --> Output Class Initialized
INFO - 2021-08-07 09:10:41 --> Security Class Initialized
DEBUG - 2021-08-07 09:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 09:10:41 --> Input Class Initialized
INFO - 2021-08-07 09:10:41 --> Language Class Initialized
INFO - 2021-08-07 09:10:41 --> Loader Class Initialized
INFO - 2021-08-07 09:10:41 --> Helper loaded: url_helper
INFO - 2021-08-07 09:10:41 --> Helper loaded: file_helper
INFO - 2021-08-07 09:10:41 --> Database Driver Class Initialized
DEBUG - 2021-08-07 09:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 09:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 09:10:41 --> Controller Class Initialized
INFO - 2021-08-07 09:10:41 --> Helper loaded: cookie_helper
INFO - 2021-08-07 09:10:41 --> Model "CookieModel" initialized
INFO - 2021-08-07 09:10:41 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 09:10:41 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-07 09:10:41 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 09:10:41 --> Final output sent to browser
DEBUG - 2021-08-07 09:10:41 --> Total execution time: 0.0899
INFO - 2021-08-07 09:10:46 --> Config Class Initialized
INFO - 2021-08-07 09:10:46 --> Hooks Class Initialized
DEBUG - 2021-08-07 09:10:46 --> UTF-8 Support Enabled
INFO - 2021-08-07 09:10:46 --> Utf8 Class Initialized
INFO - 2021-08-07 09:10:46 --> URI Class Initialized
INFO - 2021-08-07 09:10:46 --> Router Class Initialized
INFO - 2021-08-07 09:10:46 --> Output Class Initialized
INFO - 2021-08-07 09:10:46 --> Security Class Initialized
DEBUG - 2021-08-07 09:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 09:10:46 --> Input Class Initialized
INFO - 2021-08-07 09:10:46 --> Language Class Initialized
INFO - 2021-08-07 09:10:46 --> Loader Class Initialized
INFO - 2021-08-07 09:10:46 --> Helper loaded: url_helper
INFO - 2021-08-07 09:10:46 --> Helper loaded: file_helper
INFO - 2021-08-07 09:10:46 --> Database Driver Class Initialized
DEBUG - 2021-08-07 09:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 09:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 09:10:46 --> Controller Class Initialized
INFO - 2021-08-07 09:10:46 --> Helper loaded: cookie_helper
INFO - 2021-08-07 09:10:46 --> Model "CookieModel" initialized
INFO - 2021-08-07 09:10:46 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 09:10:46 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-07 09:10:46 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 09:10:46 --> Final output sent to browser
DEBUG - 2021-08-07 09:10:46 --> Total execution time: 0.0579
INFO - 2021-08-07 09:11:04 --> Config Class Initialized
INFO - 2021-08-07 09:11:04 --> Hooks Class Initialized
DEBUG - 2021-08-07 09:11:04 --> UTF-8 Support Enabled
INFO - 2021-08-07 09:11:04 --> Utf8 Class Initialized
INFO - 2021-08-07 09:11:04 --> URI Class Initialized
DEBUG - 2021-08-07 09:11:04 --> No URI present. Default controller set.
INFO - 2021-08-07 09:11:04 --> Router Class Initialized
INFO - 2021-08-07 09:11:04 --> Output Class Initialized
INFO - 2021-08-07 09:11:04 --> Security Class Initialized
DEBUG - 2021-08-07 09:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 09:11:04 --> Input Class Initialized
INFO - 2021-08-07 09:11:04 --> Language Class Initialized
INFO - 2021-08-07 09:11:04 --> Loader Class Initialized
INFO - 2021-08-07 09:11:04 --> Helper loaded: url_helper
INFO - 2021-08-07 09:11:04 --> Helper loaded: file_helper
INFO - 2021-08-07 09:11:04 --> Database Driver Class Initialized
DEBUG - 2021-08-07 09:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 09:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 09:11:04 --> Controller Class Initialized
INFO - 2021-08-07 09:11:04 --> Helper loaded: cookie_helper
INFO - 2021-08-07 09:11:04 --> Model "CookieModel" initialized
INFO - 2021-08-07 09:11:04 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 09:11:04 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-07 09:11:04 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 09:11:04 --> Final output sent to browser
DEBUG - 2021-08-07 09:11:04 --> Total execution time: 0.0578
INFO - 2021-08-07 09:40:37 --> Config Class Initialized
INFO - 2021-08-07 09:40:37 --> Hooks Class Initialized
DEBUG - 2021-08-07 09:40:37 --> UTF-8 Support Enabled
INFO - 2021-08-07 09:40:37 --> Utf8 Class Initialized
INFO - 2021-08-07 09:40:37 --> URI Class Initialized
INFO - 2021-08-07 09:40:37 --> Router Class Initialized
INFO - 2021-08-07 09:40:37 --> Output Class Initialized
INFO - 2021-08-07 09:40:37 --> Security Class Initialized
DEBUG - 2021-08-07 09:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 09:40:37 --> Input Class Initialized
INFO - 2021-08-07 09:40:37 --> Language Class Initialized
INFO - 2021-08-07 09:40:37 --> Loader Class Initialized
INFO - 2021-08-07 09:40:37 --> Helper loaded: url_helper
INFO - 2021-08-07 09:40:37 --> Helper loaded: file_helper
INFO - 2021-08-07 09:40:37 --> Database Driver Class Initialized
DEBUG - 2021-08-07 09:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 09:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 09:40:37 --> Controller Class Initialized
INFO - 2021-08-07 09:40:38 --> Helper loaded: cookie_helper
INFO - 2021-08-07 09:40:38 --> Model "CookieModel" initialized
INFO - 2021-08-07 09:40:38 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 09:40:38 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/gallery.php
INFO - 2021-08-07 09:40:38 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 09:40:38 --> Final output sent to browser
DEBUG - 2021-08-07 09:40:38 --> Total execution time: 0.7770
INFO - 2021-08-07 09:41:31 --> Config Class Initialized
INFO - 2021-08-07 09:41:31 --> Hooks Class Initialized
DEBUG - 2021-08-07 09:41:31 --> UTF-8 Support Enabled
INFO - 2021-08-07 09:41:31 --> Utf8 Class Initialized
INFO - 2021-08-07 09:41:31 --> URI Class Initialized
DEBUG - 2021-08-07 09:41:31 --> No URI present. Default controller set.
INFO - 2021-08-07 09:41:31 --> Router Class Initialized
INFO - 2021-08-07 09:41:31 --> Output Class Initialized
INFO - 2021-08-07 09:41:31 --> Security Class Initialized
DEBUG - 2021-08-07 09:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 09:41:31 --> Input Class Initialized
INFO - 2021-08-07 09:41:31 --> Language Class Initialized
INFO - 2021-08-07 09:41:31 --> Loader Class Initialized
INFO - 2021-08-07 09:41:31 --> Helper loaded: url_helper
INFO - 2021-08-07 09:41:31 --> Helper loaded: file_helper
INFO - 2021-08-07 09:41:31 --> Database Driver Class Initialized
DEBUG - 2021-08-07 09:41:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 09:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 09:41:31 --> Controller Class Initialized
INFO - 2021-08-07 09:41:31 --> Helper loaded: cookie_helper
INFO - 2021-08-07 09:41:31 --> Model "CookieModel" initialized
INFO - 2021-08-07 09:41:31 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 09:41:31 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-07 09:41:31 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 09:41:31 --> Final output sent to browser
DEBUG - 2021-08-07 09:41:31 --> Total execution time: 0.0919
INFO - 2021-08-07 09:43:59 --> Config Class Initialized
INFO - 2021-08-07 09:43:59 --> Hooks Class Initialized
DEBUG - 2021-08-07 09:43:59 --> UTF-8 Support Enabled
INFO - 2021-08-07 09:43:59 --> Utf8 Class Initialized
INFO - 2021-08-07 09:43:59 --> URI Class Initialized
DEBUG - 2021-08-07 09:43:59 --> No URI present. Default controller set.
INFO - 2021-08-07 09:43:59 --> Router Class Initialized
INFO - 2021-08-07 09:43:59 --> Output Class Initialized
INFO - 2021-08-07 09:43:59 --> Security Class Initialized
DEBUG - 2021-08-07 09:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 09:43:59 --> Input Class Initialized
INFO - 2021-08-07 09:43:59 --> Language Class Initialized
INFO - 2021-08-07 09:43:59 --> Loader Class Initialized
INFO - 2021-08-07 09:43:59 --> Helper loaded: url_helper
INFO - 2021-08-07 09:43:59 --> Helper loaded: file_helper
INFO - 2021-08-07 09:43:59 --> Database Driver Class Initialized
DEBUG - 2021-08-07 09:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 09:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 09:43:59 --> Controller Class Initialized
INFO - 2021-08-07 09:43:59 --> Helper loaded: cookie_helper
INFO - 2021-08-07 09:43:59 --> Model "CookieModel" initialized
INFO - 2021-08-07 09:43:59 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 09:43:59 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-07 09:43:59 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 09:43:59 --> Final output sent to browser
DEBUG - 2021-08-07 09:43:59 --> Total execution time: 0.0597
INFO - 2021-08-07 09:44:16 --> Config Class Initialized
INFO - 2021-08-07 09:44:16 --> Hooks Class Initialized
DEBUG - 2021-08-07 09:44:16 --> UTF-8 Support Enabled
INFO - 2021-08-07 09:44:16 --> Utf8 Class Initialized
INFO - 2021-08-07 09:44:16 --> URI Class Initialized
DEBUG - 2021-08-07 09:44:16 --> No URI present. Default controller set.
INFO - 2021-08-07 09:44:16 --> Router Class Initialized
INFO - 2021-08-07 09:44:16 --> Output Class Initialized
INFO - 2021-08-07 09:44:16 --> Security Class Initialized
DEBUG - 2021-08-07 09:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 09:44:16 --> Input Class Initialized
INFO - 2021-08-07 09:44:16 --> Language Class Initialized
INFO - 2021-08-07 09:44:16 --> Loader Class Initialized
INFO - 2021-08-07 09:44:16 --> Helper loaded: url_helper
INFO - 2021-08-07 09:44:16 --> Helper loaded: file_helper
INFO - 2021-08-07 09:44:17 --> Database Driver Class Initialized
DEBUG - 2021-08-07 09:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 09:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 09:44:17 --> Controller Class Initialized
INFO - 2021-08-07 09:44:17 --> Helper loaded: cookie_helper
INFO - 2021-08-07 09:44:17 --> Model "CookieModel" initialized
INFO - 2021-08-07 09:44:17 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 09:44:17 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-07 09:44:17 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 09:44:17 --> Final output sent to browser
DEBUG - 2021-08-07 09:44:17 --> Total execution time: 0.0401
INFO - 2021-08-07 09:44:52 --> Config Class Initialized
INFO - 2021-08-07 09:44:52 --> Hooks Class Initialized
DEBUG - 2021-08-07 09:44:52 --> UTF-8 Support Enabled
INFO - 2021-08-07 09:44:52 --> Utf8 Class Initialized
INFO - 2021-08-07 09:44:52 --> URI Class Initialized
DEBUG - 2021-08-07 09:44:52 --> No URI present. Default controller set.
INFO - 2021-08-07 09:44:52 --> Router Class Initialized
INFO - 2021-08-07 09:44:52 --> Output Class Initialized
INFO - 2021-08-07 09:44:52 --> Security Class Initialized
DEBUG - 2021-08-07 09:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 09:44:52 --> Input Class Initialized
INFO - 2021-08-07 09:44:52 --> Language Class Initialized
INFO - 2021-08-07 09:44:52 --> Loader Class Initialized
INFO - 2021-08-07 09:44:52 --> Helper loaded: url_helper
INFO - 2021-08-07 09:44:52 --> Helper loaded: file_helper
INFO - 2021-08-07 09:44:52 --> Database Driver Class Initialized
DEBUG - 2021-08-07 09:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 09:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 09:44:53 --> Controller Class Initialized
INFO - 2021-08-07 09:44:53 --> Helper loaded: cookie_helper
INFO - 2021-08-07 09:44:53 --> Model "CookieModel" initialized
INFO - 2021-08-07 09:44:53 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 09:44:53 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-07 09:44:53 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 09:44:53 --> Final output sent to browser
DEBUG - 2021-08-07 09:44:53 --> Total execution time: 0.0432
INFO - 2021-08-07 09:45:07 --> Config Class Initialized
INFO - 2021-08-07 09:45:07 --> Hooks Class Initialized
DEBUG - 2021-08-07 09:45:07 --> UTF-8 Support Enabled
INFO - 2021-08-07 09:45:07 --> Utf8 Class Initialized
INFO - 2021-08-07 09:45:07 --> URI Class Initialized
DEBUG - 2021-08-07 09:45:07 --> No URI present. Default controller set.
INFO - 2021-08-07 09:45:07 --> Router Class Initialized
INFO - 2021-08-07 09:45:07 --> Output Class Initialized
INFO - 2021-08-07 09:45:07 --> Security Class Initialized
DEBUG - 2021-08-07 09:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 09:45:07 --> Input Class Initialized
INFO - 2021-08-07 09:45:07 --> Language Class Initialized
INFO - 2021-08-07 09:45:07 --> Loader Class Initialized
INFO - 2021-08-07 09:45:07 --> Helper loaded: url_helper
INFO - 2021-08-07 09:45:07 --> Helper loaded: file_helper
INFO - 2021-08-07 09:45:07 --> Database Driver Class Initialized
DEBUG - 2021-08-07 09:45:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 09:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 09:45:07 --> Controller Class Initialized
INFO - 2021-08-07 09:45:07 --> Helper loaded: cookie_helper
INFO - 2021-08-07 09:45:07 --> Model "CookieModel" initialized
INFO - 2021-08-07 09:45:07 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 09:45:07 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-07 09:45:07 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 09:45:07 --> Final output sent to browser
DEBUG - 2021-08-07 09:45:07 --> Total execution time: 0.0402
INFO - 2021-08-07 09:45:22 --> Config Class Initialized
INFO - 2021-08-07 09:45:22 --> Hooks Class Initialized
DEBUG - 2021-08-07 09:45:22 --> UTF-8 Support Enabled
INFO - 2021-08-07 09:45:22 --> Utf8 Class Initialized
INFO - 2021-08-07 09:45:22 --> URI Class Initialized
DEBUG - 2021-08-07 09:45:22 --> No URI present. Default controller set.
INFO - 2021-08-07 09:45:22 --> Router Class Initialized
INFO - 2021-08-07 09:45:22 --> Output Class Initialized
INFO - 2021-08-07 09:45:22 --> Security Class Initialized
DEBUG - 2021-08-07 09:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 09:45:22 --> Input Class Initialized
INFO - 2021-08-07 09:45:22 --> Language Class Initialized
INFO - 2021-08-07 09:45:22 --> Loader Class Initialized
INFO - 2021-08-07 09:45:22 --> Helper loaded: url_helper
INFO - 2021-08-07 09:45:22 --> Helper loaded: file_helper
INFO - 2021-08-07 09:45:22 --> Database Driver Class Initialized
DEBUG - 2021-08-07 09:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 09:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 09:45:22 --> Controller Class Initialized
INFO - 2021-08-07 09:45:22 --> Helper loaded: cookie_helper
INFO - 2021-08-07 09:45:22 --> Model "CookieModel" initialized
INFO - 2021-08-07 09:45:22 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 09:45:22 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-07 09:45:22 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 09:45:22 --> Final output sent to browser
DEBUG - 2021-08-07 09:45:22 --> Total execution time: 0.0429
INFO - 2021-08-07 09:45:50 --> Config Class Initialized
INFO - 2021-08-07 09:45:50 --> Hooks Class Initialized
DEBUG - 2021-08-07 09:45:50 --> UTF-8 Support Enabled
INFO - 2021-08-07 09:45:50 --> Utf8 Class Initialized
INFO - 2021-08-07 09:45:50 --> URI Class Initialized
DEBUG - 2021-08-07 09:45:50 --> No URI present. Default controller set.
INFO - 2021-08-07 09:45:50 --> Router Class Initialized
INFO - 2021-08-07 09:45:50 --> Output Class Initialized
INFO - 2021-08-07 09:45:50 --> Security Class Initialized
DEBUG - 2021-08-07 09:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 09:45:50 --> Input Class Initialized
INFO - 2021-08-07 09:45:50 --> Language Class Initialized
INFO - 2021-08-07 09:45:50 --> Loader Class Initialized
INFO - 2021-08-07 09:45:50 --> Helper loaded: url_helper
INFO - 2021-08-07 09:45:50 --> Helper loaded: file_helper
INFO - 2021-08-07 09:45:50 --> Database Driver Class Initialized
DEBUG - 2021-08-07 09:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 09:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 09:45:50 --> Controller Class Initialized
INFO - 2021-08-07 09:45:50 --> Helper loaded: cookie_helper
INFO - 2021-08-07 09:45:50 --> Model "CookieModel" initialized
INFO - 2021-08-07 09:45:50 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 09:45:50 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-07 09:45:50 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 09:45:50 --> Final output sent to browser
DEBUG - 2021-08-07 09:45:50 --> Total execution time: 0.0416
INFO - 2021-08-07 09:46:27 --> Config Class Initialized
INFO - 2021-08-07 09:46:27 --> Hooks Class Initialized
DEBUG - 2021-08-07 09:46:27 --> UTF-8 Support Enabled
INFO - 2021-08-07 09:46:27 --> Utf8 Class Initialized
INFO - 2021-08-07 09:46:27 --> URI Class Initialized
DEBUG - 2021-08-07 09:46:27 --> No URI present. Default controller set.
INFO - 2021-08-07 09:46:27 --> Router Class Initialized
INFO - 2021-08-07 09:46:27 --> Output Class Initialized
INFO - 2021-08-07 09:46:27 --> Security Class Initialized
DEBUG - 2021-08-07 09:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 09:46:27 --> Input Class Initialized
INFO - 2021-08-07 09:46:27 --> Language Class Initialized
INFO - 2021-08-07 09:46:27 --> Loader Class Initialized
INFO - 2021-08-07 09:46:27 --> Helper loaded: url_helper
INFO - 2021-08-07 09:46:27 --> Helper loaded: file_helper
INFO - 2021-08-07 09:46:27 --> Database Driver Class Initialized
DEBUG - 2021-08-07 09:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 09:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 09:46:27 --> Controller Class Initialized
INFO - 2021-08-07 09:46:27 --> Helper loaded: cookie_helper
INFO - 2021-08-07 09:46:27 --> Model "CookieModel" initialized
INFO - 2021-08-07 09:46:27 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 09:46:27 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-07 09:46:27 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 09:46:27 --> Final output sent to browser
DEBUG - 2021-08-07 09:46:27 --> Total execution time: 0.0457
INFO - 2021-08-07 09:51:42 --> Config Class Initialized
INFO - 2021-08-07 09:51:42 --> Hooks Class Initialized
DEBUG - 2021-08-07 09:51:42 --> UTF-8 Support Enabled
INFO - 2021-08-07 09:51:42 --> Utf8 Class Initialized
INFO - 2021-08-07 09:51:42 --> URI Class Initialized
DEBUG - 2021-08-07 09:51:42 --> No URI present. Default controller set.
INFO - 2021-08-07 09:51:42 --> Router Class Initialized
INFO - 2021-08-07 09:51:42 --> Output Class Initialized
INFO - 2021-08-07 09:51:42 --> Security Class Initialized
DEBUG - 2021-08-07 09:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 09:51:42 --> Input Class Initialized
INFO - 2021-08-07 09:51:42 --> Language Class Initialized
INFO - 2021-08-07 09:51:42 --> Loader Class Initialized
INFO - 2021-08-07 09:51:42 --> Helper loaded: url_helper
INFO - 2021-08-07 09:51:42 --> Helper loaded: file_helper
INFO - 2021-08-07 09:51:42 --> Database Driver Class Initialized
DEBUG - 2021-08-07 09:51:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 09:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 09:51:42 --> Controller Class Initialized
INFO - 2021-08-07 09:51:42 --> Helper loaded: cookie_helper
INFO - 2021-08-07 09:51:42 --> Model "CookieModel" initialized
INFO - 2021-08-07 09:51:42 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 09:51:42 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-07 09:51:42 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 09:51:42 --> Final output sent to browser
DEBUG - 2021-08-07 09:51:42 --> Total execution time: 0.0730
INFO - 2021-08-07 09:53:19 --> Config Class Initialized
INFO - 2021-08-07 09:53:19 --> Hooks Class Initialized
DEBUG - 2021-08-07 09:53:19 --> UTF-8 Support Enabled
INFO - 2021-08-07 09:53:19 --> Utf8 Class Initialized
INFO - 2021-08-07 09:53:19 --> URI Class Initialized
DEBUG - 2021-08-07 09:53:19 --> No URI present. Default controller set.
INFO - 2021-08-07 09:53:19 --> Router Class Initialized
INFO - 2021-08-07 09:53:19 --> Output Class Initialized
INFO - 2021-08-07 09:53:19 --> Security Class Initialized
DEBUG - 2021-08-07 09:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 09:53:19 --> Input Class Initialized
INFO - 2021-08-07 09:53:19 --> Language Class Initialized
INFO - 2021-08-07 09:53:19 --> Loader Class Initialized
INFO - 2021-08-07 09:53:19 --> Helper loaded: url_helper
INFO - 2021-08-07 09:53:19 --> Helper loaded: file_helper
INFO - 2021-08-07 09:53:19 --> Database Driver Class Initialized
DEBUG - 2021-08-07 09:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 09:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 09:53:19 --> Controller Class Initialized
INFO - 2021-08-07 09:53:19 --> Helper loaded: cookie_helper
INFO - 2021-08-07 09:53:19 --> Model "CookieModel" initialized
INFO - 2021-08-07 09:53:19 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 09:53:19 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-07 09:53:19 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 09:53:19 --> Final output sent to browser
DEBUG - 2021-08-07 09:53:19 --> Total execution time: 0.0404
INFO - 2021-08-07 09:53:43 --> Config Class Initialized
INFO - 2021-08-07 09:53:43 --> Hooks Class Initialized
DEBUG - 2021-08-07 09:53:43 --> UTF-8 Support Enabled
INFO - 2021-08-07 09:53:43 --> Utf8 Class Initialized
INFO - 2021-08-07 09:53:43 --> URI Class Initialized
INFO - 2021-08-07 09:53:43 --> Router Class Initialized
INFO - 2021-08-07 09:53:43 --> Output Class Initialized
INFO - 2021-08-07 09:53:43 --> Security Class Initialized
DEBUG - 2021-08-07 09:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 09:53:43 --> Input Class Initialized
INFO - 2021-08-07 09:53:43 --> Language Class Initialized
INFO - 2021-08-07 09:53:43 --> Loader Class Initialized
INFO - 2021-08-07 09:53:43 --> Helper loaded: url_helper
INFO - 2021-08-07 09:53:43 --> Helper loaded: file_helper
INFO - 2021-08-07 09:53:43 --> Database Driver Class Initialized
DEBUG - 2021-08-07 09:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 09:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 09:53:43 --> Controller Class Initialized
INFO - 2021-08-07 09:53:43 --> Helper loaded: cookie_helper
INFO - 2021-08-07 09:53:43 --> Model "CookieModel" initialized
INFO - 2021-08-07 09:53:43 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 09:53:43 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/services.php
INFO - 2021-08-07 09:53:43 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 09:53:43 --> Final output sent to browser
DEBUG - 2021-08-07 09:53:43 --> Total execution time: 0.0957
INFO - 2021-08-07 09:53:44 --> Config Class Initialized
INFO - 2021-08-07 09:53:44 --> Hooks Class Initialized
DEBUG - 2021-08-07 09:53:44 --> UTF-8 Support Enabled
INFO - 2021-08-07 09:53:44 --> Utf8 Class Initialized
INFO - 2021-08-07 09:53:44 --> URI Class Initialized
INFO - 2021-08-07 09:53:44 --> Router Class Initialized
INFO - 2021-08-07 09:53:44 --> Output Class Initialized
INFO - 2021-08-07 09:53:44 --> Security Class Initialized
DEBUG - 2021-08-07 09:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 09:53:44 --> Input Class Initialized
INFO - 2021-08-07 09:53:44 --> Language Class Initialized
INFO - 2021-08-07 09:53:44 --> Loader Class Initialized
INFO - 2021-08-07 09:53:44 --> Helper loaded: url_helper
INFO - 2021-08-07 09:53:44 --> Helper loaded: file_helper
INFO - 2021-08-07 09:53:44 --> Database Driver Class Initialized
DEBUG - 2021-08-07 09:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 09:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 09:53:44 --> Controller Class Initialized
INFO - 2021-08-07 09:53:44 --> Helper loaded: cookie_helper
INFO - 2021-08-07 09:53:44 --> Model "CookieModel" initialized
INFO - 2021-08-07 09:53:44 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 09:53:44 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/success_stories.php
INFO - 2021-08-07 09:53:44 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 09:53:44 --> Final output sent to browser
DEBUG - 2021-08-07 09:53:44 --> Total execution time: 0.0774
INFO - 2021-08-07 09:53:45 --> Config Class Initialized
INFO - 2021-08-07 09:53:45 --> Hooks Class Initialized
DEBUG - 2021-08-07 09:53:45 --> UTF-8 Support Enabled
INFO - 2021-08-07 09:53:45 --> Utf8 Class Initialized
INFO - 2021-08-07 09:53:45 --> URI Class Initialized
INFO - 2021-08-07 09:53:45 --> Router Class Initialized
INFO - 2021-08-07 09:53:45 --> Output Class Initialized
INFO - 2021-08-07 09:53:45 --> Security Class Initialized
DEBUG - 2021-08-07 09:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 09:53:45 --> Input Class Initialized
INFO - 2021-08-07 09:53:45 --> Language Class Initialized
INFO - 2021-08-07 09:53:45 --> Loader Class Initialized
INFO - 2021-08-07 09:53:45 --> Helper loaded: url_helper
INFO - 2021-08-07 09:53:45 --> Helper loaded: file_helper
INFO - 2021-08-07 09:53:45 --> Database Driver Class Initialized
DEBUG - 2021-08-07 09:53:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 09:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 09:53:45 --> Controller Class Initialized
INFO - 2021-08-07 09:53:45 --> Helper loaded: cookie_helper
INFO - 2021-08-07 09:53:45 --> Model "CookieModel" initialized
INFO - 2021-08-07 09:53:45 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 09:53:45 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/about.php
INFO - 2021-08-07 09:53:45 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 09:53:45 --> Final output sent to browser
DEBUG - 2021-08-07 09:53:45 --> Total execution time: 0.0732
INFO - 2021-08-07 09:57:08 --> Config Class Initialized
INFO - 2021-08-07 09:57:08 --> Hooks Class Initialized
DEBUG - 2021-08-07 09:57:08 --> UTF-8 Support Enabled
INFO - 2021-08-07 09:57:08 --> Utf8 Class Initialized
INFO - 2021-08-07 09:57:08 --> URI Class Initialized
INFO - 2021-08-07 09:57:08 --> Router Class Initialized
INFO - 2021-08-07 09:57:08 --> Output Class Initialized
INFO - 2021-08-07 09:57:08 --> Security Class Initialized
DEBUG - 2021-08-07 09:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 09:57:08 --> Input Class Initialized
INFO - 2021-08-07 09:57:08 --> Language Class Initialized
INFO - 2021-08-07 09:57:08 --> Loader Class Initialized
INFO - 2021-08-07 09:57:08 --> Helper loaded: url_helper
INFO - 2021-08-07 09:57:08 --> Helper loaded: file_helper
INFO - 2021-08-07 09:57:08 --> Database Driver Class Initialized
DEBUG - 2021-08-07 09:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 09:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 09:57:09 --> Controller Class Initialized
INFO - 2021-08-07 09:57:09 --> Helper loaded: cookie_helper
INFO - 2021-08-07 09:57:09 --> Model "CookieModel" initialized
INFO - 2021-08-07 09:57:09 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 09:57:09 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/about.php
INFO - 2021-08-07 09:57:09 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 09:57:09 --> Final output sent to browser
DEBUG - 2021-08-07 09:57:09 --> Total execution time: 0.0840
INFO - 2021-08-07 09:57:17 --> Config Class Initialized
INFO - 2021-08-07 09:57:17 --> Hooks Class Initialized
DEBUG - 2021-08-07 09:57:17 --> UTF-8 Support Enabled
INFO - 2021-08-07 09:57:17 --> Utf8 Class Initialized
INFO - 2021-08-07 09:57:17 --> URI Class Initialized
INFO - 2021-08-07 09:57:17 --> Router Class Initialized
INFO - 2021-08-07 09:57:17 --> Output Class Initialized
INFO - 2021-08-07 09:57:17 --> Security Class Initialized
DEBUG - 2021-08-07 09:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 09:57:17 --> Input Class Initialized
INFO - 2021-08-07 09:57:17 --> Language Class Initialized
INFO - 2021-08-07 09:57:17 --> Loader Class Initialized
INFO - 2021-08-07 09:57:17 --> Helper loaded: url_helper
INFO - 2021-08-07 09:57:17 --> Helper loaded: file_helper
INFO - 2021-08-07 09:57:17 --> Database Driver Class Initialized
DEBUG - 2021-08-07 09:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 09:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 09:57:17 --> Controller Class Initialized
INFO - 2021-08-07 09:57:17 --> Helper loaded: cookie_helper
INFO - 2021-08-07 09:57:17 --> Model "CookieModel" initialized
INFO - 2021-08-07 09:57:17 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 09:57:17 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-07 09:57:17 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 09:57:17 --> Final output sent to browser
DEBUG - 2021-08-07 09:57:17 --> Total execution time: 0.0869
INFO - 2021-08-07 09:57:18 --> Config Class Initialized
INFO - 2021-08-07 09:57:18 --> Hooks Class Initialized
DEBUG - 2021-08-07 09:57:18 --> UTF-8 Support Enabled
INFO - 2021-08-07 09:57:18 --> Utf8 Class Initialized
INFO - 2021-08-07 09:57:18 --> URI Class Initialized
DEBUG - 2021-08-07 09:57:18 --> No URI present. Default controller set.
INFO - 2021-08-07 09:57:18 --> Router Class Initialized
INFO - 2021-08-07 09:57:18 --> Output Class Initialized
INFO - 2021-08-07 09:57:18 --> Security Class Initialized
DEBUG - 2021-08-07 09:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 09:57:18 --> Input Class Initialized
INFO - 2021-08-07 09:57:18 --> Language Class Initialized
INFO - 2021-08-07 09:57:18 --> Loader Class Initialized
INFO - 2021-08-07 09:57:18 --> Helper loaded: url_helper
INFO - 2021-08-07 09:57:18 --> Helper loaded: file_helper
INFO - 2021-08-07 09:57:18 --> Database Driver Class Initialized
DEBUG - 2021-08-07 09:57:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 09:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 09:57:18 --> Controller Class Initialized
INFO - 2021-08-07 09:57:18 --> Helper loaded: cookie_helper
INFO - 2021-08-07 09:57:18 --> Model "CookieModel" initialized
INFO - 2021-08-07 09:57:18 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 09:57:18 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-07 09:57:18 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 09:57:18 --> Final output sent to browser
DEBUG - 2021-08-07 09:57:18 --> Total execution time: 0.0637
INFO - 2021-08-07 09:57:20 --> Config Class Initialized
INFO - 2021-08-07 09:57:20 --> Hooks Class Initialized
DEBUG - 2021-08-07 09:57:20 --> UTF-8 Support Enabled
INFO - 2021-08-07 09:57:20 --> Utf8 Class Initialized
INFO - 2021-08-07 09:57:20 --> URI Class Initialized
INFO - 2021-08-07 09:57:20 --> Router Class Initialized
INFO - 2021-08-07 09:57:20 --> Output Class Initialized
INFO - 2021-08-07 09:57:20 --> Security Class Initialized
DEBUG - 2021-08-07 09:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 09:57:20 --> Input Class Initialized
INFO - 2021-08-07 09:57:20 --> Language Class Initialized
INFO - 2021-08-07 09:57:20 --> Loader Class Initialized
INFO - 2021-08-07 09:57:20 --> Helper loaded: url_helper
INFO - 2021-08-07 09:57:20 --> Helper loaded: file_helper
INFO - 2021-08-07 09:57:20 --> Database Driver Class Initialized
DEBUG - 2021-08-07 09:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 09:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 09:57:20 --> Controller Class Initialized
INFO - 2021-08-07 09:57:20 --> Helper loaded: cookie_helper
INFO - 2021-08-07 09:57:20 --> Model "CookieModel" initialized
INFO - 2021-08-07 09:57:20 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 09:57:20 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/services.php
INFO - 2021-08-07 09:57:20 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 09:57:20 --> Final output sent to browser
DEBUG - 2021-08-07 09:57:20 --> Total execution time: 0.0439
INFO - 2021-08-07 09:57:21 --> Config Class Initialized
INFO - 2021-08-07 09:57:21 --> Hooks Class Initialized
DEBUG - 2021-08-07 09:57:21 --> UTF-8 Support Enabled
INFO - 2021-08-07 09:57:21 --> Utf8 Class Initialized
INFO - 2021-08-07 09:57:21 --> URI Class Initialized
INFO - 2021-08-07 09:57:21 --> Router Class Initialized
INFO - 2021-08-07 09:57:21 --> Output Class Initialized
INFO - 2021-08-07 09:57:21 --> Security Class Initialized
DEBUG - 2021-08-07 09:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 09:57:21 --> Input Class Initialized
INFO - 2021-08-07 09:57:21 --> Language Class Initialized
INFO - 2021-08-07 09:57:21 --> Loader Class Initialized
INFO - 2021-08-07 09:57:21 --> Helper loaded: url_helper
INFO - 2021-08-07 09:57:21 --> Helper loaded: file_helper
INFO - 2021-08-07 09:57:21 --> Database Driver Class Initialized
DEBUG - 2021-08-07 09:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 09:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 09:57:21 --> Controller Class Initialized
INFO - 2021-08-07 09:57:21 --> Helper loaded: cookie_helper
INFO - 2021-08-07 09:57:21 --> Model "CookieModel" initialized
INFO - 2021-08-07 09:57:21 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 09:57:21 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/success_stories.php
INFO - 2021-08-07 09:57:21 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 09:57:21 --> Final output sent to browser
DEBUG - 2021-08-07 09:57:21 --> Total execution time: 0.0504
INFO - 2021-08-07 09:57:22 --> Config Class Initialized
INFO - 2021-08-07 09:57:22 --> Hooks Class Initialized
DEBUG - 2021-08-07 09:57:22 --> UTF-8 Support Enabled
INFO - 2021-08-07 09:57:22 --> Utf8 Class Initialized
INFO - 2021-08-07 09:57:22 --> URI Class Initialized
INFO - 2021-08-07 09:57:22 --> Router Class Initialized
INFO - 2021-08-07 09:57:22 --> Output Class Initialized
INFO - 2021-08-07 09:57:22 --> Security Class Initialized
DEBUG - 2021-08-07 09:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 09:57:22 --> Input Class Initialized
INFO - 2021-08-07 09:57:22 --> Language Class Initialized
INFO - 2021-08-07 09:57:22 --> Loader Class Initialized
INFO - 2021-08-07 09:57:22 --> Helper loaded: url_helper
INFO - 2021-08-07 09:57:22 --> Helper loaded: file_helper
INFO - 2021-08-07 09:57:22 --> Database Driver Class Initialized
DEBUG - 2021-08-07 09:57:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 09:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 09:57:22 --> Controller Class Initialized
INFO - 2021-08-07 09:57:22 --> Helper loaded: cookie_helper
INFO - 2021-08-07 09:57:22 --> Model "CookieModel" initialized
INFO - 2021-08-07 09:57:22 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 09:57:22 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/about.php
INFO - 2021-08-07 09:57:22 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 09:57:22 --> Final output sent to browser
DEBUG - 2021-08-07 09:57:22 --> Total execution time: 0.0441
INFO - 2021-08-07 09:57:24 --> Config Class Initialized
INFO - 2021-08-07 09:57:24 --> Hooks Class Initialized
DEBUG - 2021-08-07 09:57:24 --> UTF-8 Support Enabled
INFO - 2021-08-07 09:57:24 --> Utf8 Class Initialized
INFO - 2021-08-07 09:57:24 --> URI Class Initialized
INFO - 2021-08-07 09:57:24 --> Router Class Initialized
INFO - 2021-08-07 09:57:24 --> Output Class Initialized
INFO - 2021-08-07 09:57:24 --> Security Class Initialized
DEBUG - 2021-08-07 09:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 09:57:24 --> Input Class Initialized
INFO - 2021-08-07 09:57:24 --> Language Class Initialized
INFO - 2021-08-07 09:57:24 --> Loader Class Initialized
INFO - 2021-08-07 09:57:24 --> Helper loaded: url_helper
INFO - 2021-08-07 09:57:24 --> Helper loaded: file_helper
INFO - 2021-08-07 09:57:24 --> Database Driver Class Initialized
DEBUG - 2021-08-07 09:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 09:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 09:57:24 --> Controller Class Initialized
INFO - 2021-08-07 09:57:24 --> Helper loaded: cookie_helper
INFO - 2021-08-07 09:57:24 --> Model "CookieModel" initialized
INFO - 2021-08-07 09:57:24 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 09:57:24 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/team.php
INFO - 2021-08-07 09:57:24 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 09:57:24 --> Final output sent to browser
DEBUG - 2021-08-07 09:57:24 --> Total execution time: 0.0490
INFO - 2021-08-07 09:57:40 --> Config Class Initialized
INFO - 2021-08-07 09:57:40 --> Hooks Class Initialized
DEBUG - 2021-08-07 09:57:40 --> UTF-8 Support Enabled
INFO - 2021-08-07 09:57:40 --> Utf8 Class Initialized
INFO - 2021-08-07 09:57:40 --> URI Class Initialized
INFO - 2021-08-07 09:57:40 --> Router Class Initialized
INFO - 2021-08-07 09:57:40 --> Output Class Initialized
INFO - 2021-08-07 09:57:40 --> Security Class Initialized
DEBUG - 2021-08-07 09:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 09:57:40 --> Input Class Initialized
INFO - 2021-08-07 09:57:40 --> Language Class Initialized
INFO - 2021-08-07 09:57:40 --> Loader Class Initialized
INFO - 2021-08-07 09:57:40 --> Helper loaded: url_helper
INFO - 2021-08-07 09:57:40 --> Helper loaded: file_helper
INFO - 2021-08-07 09:57:40 --> Database Driver Class Initialized
DEBUG - 2021-08-07 09:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 09:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 09:57:40 --> Controller Class Initialized
INFO - 2021-08-07 09:57:40 --> Helper loaded: cookie_helper
INFO - 2021-08-07 09:57:40 --> Model "CookieModel" initialized
INFO - 2021-08-07 09:57:40 --> Model "ContactModel" initialized
INFO - 2021-08-07 09:57:40 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 09:57:40 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/contact.php
INFO - 2021-08-07 09:57:40 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 09:57:40 --> Final output sent to browser
DEBUG - 2021-08-07 09:57:40 --> Total execution time: 0.1137
INFO - 2021-08-07 09:57:47 --> Config Class Initialized
INFO - 2021-08-07 09:57:47 --> Hooks Class Initialized
DEBUG - 2021-08-07 09:57:47 --> UTF-8 Support Enabled
INFO - 2021-08-07 09:57:47 --> Utf8 Class Initialized
INFO - 2021-08-07 09:57:47 --> URI Class Initialized
DEBUG - 2021-08-07 09:57:47 --> No URI present. Default controller set.
INFO - 2021-08-07 09:57:47 --> Router Class Initialized
INFO - 2021-08-07 09:57:47 --> Output Class Initialized
INFO - 2021-08-07 09:57:47 --> Security Class Initialized
DEBUG - 2021-08-07 09:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 09:57:47 --> Input Class Initialized
INFO - 2021-08-07 09:57:47 --> Language Class Initialized
INFO - 2021-08-07 09:57:47 --> Loader Class Initialized
INFO - 2021-08-07 09:57:47 --> Helper loaded: url_helper
INFO - 2021-08-07 09:57:47 --> Helper loaded: file_helper
INFO - 2021-08-07 09:57:47 --> Database Driver Class Initialized
DEBUG - 2021-08-07 09:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 09:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 09:57:47 --> Controller Class Initialized
INFO - 2021-08-07 09:57:47 --> Helper loaded: cookie_helper
INFO - 2021-08-07 09:57:47 --> Model "CookieModel" initialized
INFO - 2021-08-07 09:57:47 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 09:57:47 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-07 09:57:47 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 09:57:47 --> Final output sent to browser
DEBUG - 2021-08-07 09:57:47 --> Total execution time: 0.0399
INFO - 2021-08-07 09:58:06 --> Config Class Initialized
INFO - 2021-08-07 09:58:06 --> Hooks Class Initialized
DEBUG - 2021-08-07 09:58:06 --> UTF-8 Support Enabled
INFO - 2021-08-07 09:58:06 --> Utf8 Class Initialized
INFO - 2021-08-07 09:58:06 --> URI Class Initialized
INFO - 2021-08-07 09:58:06 --> Router Class Initialized
INFO - 2021-08-07 09:58:06 --> Output Class Initialized
INFO - 2021-08-07 09:58:06 --> Security Class Initialized
DEBUG - 2021-08-07 09:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 09:58:06 --> Input Class Initialized
INFO - 2021-08-07 09:58:06 --> Language Class Initialized
INFO - 2021-08-07 09:58:06 --> Loader Class Initialized
INFO - 2021-08-07 09:58:06 --> Helper loaded: url_helper
INFO - 2021-08-07 09:58:06 --> Helper loaded: file_helper
INFO - 2021-08-07 09:58:06 --> Database Driver Class Initialized
DEBUG - 2021-08-07 09:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 09:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 09:58:06 --> Controller Class Initialized
INFO - 2021-08-07 09:58:06 --> Helper loaded: cookie_helper
INFO - 2021-08-07 09:58:06 --> Model "CookieModel" initialized
INFO - 2021-08-07 09:58:06 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 09:58:06 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/about.php
INFO - 2021-08-07 09:58:06 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 09:58:06 --> Final output sent to browser
DEBUG - 2021-08-07 09:58:06 --> Total execution time: 0.0409
INFO - 2021-08-07 09:58:55 --> Config Class Initialized
INFO - 2021-08-07 09:58:55 --> Hooks Class Initialized
DEBUG - 2021-08-07 09:58:55 --> UTF-8 Support Enabled
INFO - 2021-08-07 09:58:55 --> Utf8 Class Initialized
INFO - 2021-08-07 09:58:55 --> URI Class Initialized
INFO - 2021-08-07 09:58:55 --> Router Class Initialized
INFO - 2021-08-07 09:58:55 --> Output Class Initialized
INFO - 2021-08-07 09:58:55 --> Security Class Initialized
DEBUG - 2021-08-07 09:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 09:58:55 --> Input Class Initialized
INFO - 2021-08-07 09:58:55 --> Language Class Initialized
INFO - 2021-08-07 09:58:55 --> Loader Class Initialized
INFO - 2021-08-07 09:58:55 --> Helper loaded: url_helper
INFO - 2021-08-07 09:58:55 --> Helper loaded: file_helper
INFO - 2021-08-07 09:58:55 --> Database Driver Class Initialized
DEBUG - 2021-08-07 09:58:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 09:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 09:58:55 --> Controller Class Initialized
INFO - 2021-08-07 09:58:55 --> Helper loaded: cookie_helper
INFO - 2021-08-07 09:58:55 --> Model "CookieModel" initialized
INFO - 2021-08-07 09:58:55 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 09:58:55 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/about.php
INFO - 2021-08-07 09:58:55 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 09:58:55 --> Final output sent to browser
DEBUG - 2021-08-07 09:58:55 --> Total execution time: 0.0537
INFO - 2021-08-07 09:59:08 --> Config Class Initialized
INFO - 2021-08-07 09:59:08 --> Hooks Class Initialized
DEBUG - 2021-08-07 09:59:08 --> UTF-8 Support Enabled
INFO - 2021-08-07 09:59:08 --> Utf8 Class Initialized
INFO - 2021-08-07 09:59:08 --> URI Class Initialized
INFO - 2021-08-07 09:59:08 --> Router Class Initialized
INFO - 2021-08-07 09:59:08 --> Output Class Initialized
INFO - 2021-08-07 09:59:08 --> Security Class Initialized
DEBUG - 2021-08-07 09:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 09:59:08 --> Input Class Initialized
INFO - 2021-08-07 09:59:08 --> Language Class Initialized
INFO - 2021-08-07 09:59:08 --> Loader Class Initialized
INFO - 2021-08-07 09:59:08 --> Helper loaded: url_helper
INFO - 2021-08-07 09:59:08 --> Helper loaded: file_helper
INFO - 2021-08-07 09:59:08 --> Database Driver Class Initialized
DEBUG - 2021-08-07 09:59:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 09:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 09:59:08 --> Controller Class Initialized
INFO - 2021-08-07 09:59:08 --> Helper loaded: cookie_helper
INFO - 2021-08-07 09:59:08 --> Model "CookieModel" initialized
INFO - 2021-08-07 09:59:08 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 09:59:08 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/services.php
INFO - 2021-08-07 09:59:08 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 09:59:08 --> Final output sent to browser
DEBUG - 2021-08-07 09:59:08 --> Total execution time: 0.0798
INFO - 2021-08-07 09:59:09 --> Config Class Initialized
INFO - 2021-08-07 09:59:09 --> Hooks Class Initialized
DEBUG - 2021-08-07 09:59:09 --> UTF-8 Support Enabled
INFO - 2021-08-07 09:59:09 --> Utf8 Class Initialized
INFO - 2021-08-07 09:59:09 --> URI Class Initialized
INFO - 2021-08-07 09:59:09 --> Router Class Initialized
INFO - 2021-08-07 09:59:09 --> Output Class Initialized
INFO - 2021-08-07 09:59:09 --> Security Class Initialized
DEBUG - 2021-08-07 09:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 09:59:09 --> Input Class Initialized
INFO - 2021-08-07 09:59:09 --> Language Class Initialized
INFO - 2021-08-07 09:59:09 --> Loader Class Initialized
INFO - 2021-08-07 09:59:09 --> Helper loaded: url_helper
INFO - 2021-08-07 09:59:09 --> Helper loaded: file_helper
INFO - 2021-08-07 09:59:09 --> Database Driver Class Initialized
DEBUG - 2021-08-07 09:59:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 09:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 09:59:09 --> Controller Class Initialized
INFO - 2021-08-07 09:59:09 --> Helper loaded: cookie_helper
INFO - 2021-08-07 09:59:09 --> Model "CookieModel" initialized
INFO - 2021-08-07 09:59:09 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 09:59:09 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-07 09:59:09 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 09:59:09 --> Final output sent to browser
DEBUG - 2021-08-07 09:59:09 --> Total execution time: 0.0507
INFO - 2021-08-07 09:59:10 --> Config Class Initialized
INFO - 2021-08-07 09:59:10 --> Hooks Class Initialized
DEBUG - 2021-08-07 09:59:10 --> UTF-8 Support Enabled
INFO - 2021-08-07 09:59:10 --> Utf8 Class Initialized
INFO - 2021-08-07 09:59:10 --> URI Class Initialized
INFO - 2021-08-07 09:59:10 --> Router Class Initialized
INFO - 2021-08-07 09:59:10 --> Output Class Initialized
INFO - 2021-08-07 09:59:10 --> Security Class Initialized
DEBUG - 2021-08-07 09:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 09:59:10 --> Input Class Initialized
INFO - 2021-08-07 09:59:10 --> Language Class Initialized
INFO - 2021-08-07 09:59:10 --> Loader Class Initialized
INFO - 2021-08-07 09:59:10 --> Helper loaded: url_helper
INFO - 2021-08-07 09:59:10 --> Helper loaded: file_helper
INFO - 2021-08-07 09:59:10 --> Database Driver Class Initialized
DEBUG - 2021-08-07 09:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 09:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 09:59:10 --> Controller Class Initialized
INFO - 2021-08-07 09:59:10 --> Helper loaded: cookie_helper
INFO - 2021-08-07 09:59:10 --> Model "CookieModel" initialized
INFO - 2021-08-07 09:59:10 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 09:59:10 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-07 09:59:10 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 09:59:10 --> Final output sent to browser
DEBUG - 2021-08-07 09:59:10 --> Total execution time: 0.0491
INFO - 2021-08-07 09:59:12 --> Config Class Initialized
INFO - 2021-08-07 09:59:12 --> Hooks Class Initialized
DEBUG - 2021-08-07 09:59:12 --> UTF-8 Support Enabled
INFO - 2021-08-07 09:59:12 --> Utf8 Class Initialized
INFO - 2021-08-07 09:59:12 --> URI Class Initialized
INFO - 2021-08-07 09:59:12 --> Router Class Initialized
INFO - 2021-08-07 09:59:12 --> Output Class Initialized
INFO - 2021-08-07 09:59:12 --> Security Class Initialized
DEBUG - 2021-08-07 09:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 09:59:12 --> Input Class Initialized
INFO - 2021-08-07 09:59:12 --> Language Class Initialized
INFO - 2021-08-07 09:59:12 --> Loader Class Initialized
INFO - 2021-08-07 09:59:12 --> Helper loaded: url_helper
INFO - 2021-08-07 09:59:12 --> Helper loaded: file_helper
INFO - 2021-08-07 09:59:12 --> Database Driver Class Initialized
DEBUG - 2021-08-07 09:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 09:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 09:59:12 --> Controller Class Initialized
INFO - 2021-08-07 09:59:12 --> Helper loaded: cookie_helper
INFO - 2021-08-07 09:59:12 --> Model "CookieModel" initialized
INFO - 2021-08-07 09:59:12 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 09:59:12 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/services.php
INFO - 2021-08-07 09:59:12 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 09:59:12 --> Final output sent to browser
DEBUG - 2021-08-07 09:59:12 --> Total execution time: 0.0454
INFO - 2021-08-07 09:59:19 --> Config Class Initialized
INFO - 2021-08-07 09:59:19 --> Hooks Class Initialized
INFO - 2021-08-07 09:59:19 --> Config Class Initialized
INFO - 2021-08-07 09:59:19 --> Hooks Class Initialized
DEBUG - 2021-08-07 09:59:19 --> UTF-8 Support Enabled
INFO - 2021-08-07 09:59:19 --> Utf8 Class Initialized
INFO - 2021-08-07 09:59:19 --> URI Class Initialized
INFO - 2021-08-07 09:59:19 --> Router Class Initialized
INFO - 2021-08-07 09:59:19 --> Config Class Initialized
INFO - 2021-08-07 09:59:19 --> Hooks Class Initialized
INFO - 2021-08-07 09:59:19 --> Output Class Initialized
INFO - 2021-08-07 09:59:19 --> Security Class Initialized
DEBUG - 2021-08-07 09:59:19 --> UTF-8 Support Enabled
DEBUG - 2021-08-07 09:59:19 --> UTF-8 Support Enabled
INFO - 2021-08-07 09:59:19 --> Utf8 Class Initialized
INFO - 2021-08-07 09:59:19 --> Utf8 Class Initialized
DEBUG - 2021-08-07 09:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 09:59:19 --> Input Class Initialized
INFO - 2021-08-07 09:59:19 --> Language Class Initialized
INFO - 2021-08-07 09:59:19 --> URI Class Initialized
INFO - 2021-08-07 09:59:19 --> URI Class Initialized
INFO - 2021-08-07 09:59:19 --> Router Class Initialized
INFO - 2021-08-07 09:59:19 --> Router Class Initialized
INFO - 2021-08-07 09:59:19 --> Output Class Initialized
INFO - 2021-08-07 09:59:19 --> Security Class Initialized
INFO - 2021-08-07 09:59:19 --> Output Class Initialized
DEBUG - 2021-08-07 09:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 09:59:19 --> Input Class Initialized
INFO - 2021-08-07 09:59:19 --> Language Class Initialized
INFO - 2021-08-07 09:59:19 --> Security Class Initialized
DEBUG - 2021-08-07 09:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 09:59:19 --> Input Class Initialized
INFO - 2021-08-07 09:59:19 --> Language Class Initialized
ERROR - 2021-08-07 09:59:19 --> 404 Page Not Found: Assets/js
ERROR - 2021-08-07 09:59:19 --> 404 Page Not Found: Assets/js
ERROR - 2021-08-07 09:59:19 --> 404 Page Not Found: Assets/js
INFO - 2021-08-07 09:59:19 --> Config Class Initialized
INFO - 2021-08-07 09:59:19 --> Hooks Class Initialized
INFO - 2021-08-07 09:59:19 --> Config Class Initialized
INFO - 2021-08-07 09:59:19 --> Hooks Class Initialized
DEBUG - 2021-08-07 09:59:19 --> UTF-8 Support Enabled
INFO - 2021-08-07 09:59:19 --> Utf8 Class Initialized
INFO - 2021-08-07 09:59:19 --> URI Class Initialized
DEBUG - 2021-08-07 09:59:19 --> UTF-8 Support Enabled
INFO - 2021-08-07 09:59:19 --> Utf8 Class Initialized
INFO - 2021-08-07 09:59:19 --> Router Class Initialized
INFO - 2021-08-07 09:59:19 --> URI Class Initialized
INFO - 2021-08-07 09:59:19 --> Router Class Initialized
INFO - 2021-08-07 09:59:19 --> Output Class Initialized
INFO - 2021-08-07 09:59:19 --> Security Class Initialized
INFO - 2021-08-07 09:59:19 --> Output Class Initialized
DEBUG - 2021-08-07 09:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 09:59:19 --> Input Class Initialized
INFO - 2021-08-07 09:59:19 --> Security Class Initialized
INFO - 2021-08-07 09:59:19 --> Language Class Initialized
DEBUG - 2021-08-07 09:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 09:59:19 --> Input Class Initialized
ERROR - 2021-08-07 09:59:19 --> 404 Page Not Found: Assets/css
INFO - 2021-08-07 09:59:19 --> Language Class Initialized
ERROR - 2021-08-07 09:59:19 --> 404 Page Not Found: Assets/css
INFO - 2021-08-07 10:01:25 --> Config Class Initialized
INFO - 2021-08-07 10:01:25 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:01:25 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:01:25 --> Utf8 Class Initialized
INFO - 2021-08-07 10:01:25 --> URI Class Initialized
INFO - 2021-08-07 10:01:25 --> Router Class Initialized
INFO - 2021-08-07 10:01:25 --> Output Class Initialized
INFO - 2021-08-07 10:01:25 --> Security Class Initialized
DEBUG - 2021-08-07 10:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:01:25 --> Input Class Initialized
INFO - 2021-08-07 10:01:25 --> Language Class Initialized
INFO - 2021-08-07 10:01:25 --> Loader Class Initialized
INFO - 2021-08-07 10:01:25 --> Helper loaded: url_helper
INFO - 2021-08-07 10:01:25 --> Helper loaded: file_helper
INFO - 2021-08-07 10:01:25 --> Database Driver Class Initialized
DEBUG - 2021-08-07 10:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 10:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 10:01:25 --> Controller Class Initialized
INFO - 2021-08-07 10:01:25 --> Helper loaded: cookie_helper
INFO - 2021-08-07 10:01:25 --> Model "CookieModel" initialized
INFO - 2021-08-07 10:01:25 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 10:01:25 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/services.php
INFO - 2021-08-07 10:01:25 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 10:01:25 --> Final output sent to browser
DEBUG - 2021-08-07 10:01:25 --> Total execution time: 0.0388
INFO - 2021-08-07 10:01:25 --> Config Class Initialized
INFO - 2021-08-07 10:01:25 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:01:25 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:01:25 --> Utf8 Class Initialized
INFO - 2021-08-07 10:01:25 --> URI Class Initialized
INFO - 2021-08-07 10:01:25 --> Router Class Initialized
INFO - 2021-08-07 10:01:25 --> Config Class Initialized
INFO - 2021-08-07 10:01:25 --> Hooks Class Initialized
INFO - 2021-08-07 10:01:25 --> Output Class Initialized
INFO - 2021-08-07 10:01:25 --> Security Class Initialized
DEBUG - 2021-08-07 10:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:01:25 --> Input Class Initialized
INFO - 2021-08-07 10:01:25 --> Language Class Initialized
ERROR - 2021-08-07 10:01:25 --> 404 Page Not Found: Assets/css
DEBUG - 2021-08-07 10:01:25 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:01:25 --> Utf8 Class Initialized
INFO - 2021-08-07 10:01:25 --> URI Class Initialized
INFO - 2021-08-07 10:01:25 --> Router Class Initialized
INFO - 2021-08-07 10:01:25 --> Output Class Initialized
INFO - 2021-08-07 10:01:25 --> Security Class Initialized
DEBUG - 2021-08-07 10:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:01:25 --> Input Class Initialized
INFO - 2021-08-07 10:01:25 --> Language Class Initialized
ERROR - 2021-08-07 10:01:25 --> 404 Page Not Found: Assets/css
INFO - 2021-08-07 10:01:25 --> Config Class Initialized
INFO - 2021-08-07 10:01:25 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:01:25 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:01:25 --> Utf8 Class Initialized
INFO - 2021-08-07 10:01:25 --> URI Class Initialized
INFO - 2021-08-07 10:01:25 --> Config Class Initialized
INFO - 2021-08-07 10:01:25 --> Hooks Class Initialized
INFO - 2021-08-07 10:01:25 --> Router Class Initialized
INFO - 2021-08-07 10:01:25 --> Output Class Initialized
DEBUG - 2021-08-07 10:01:25 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:01:25 --> Utf8 Class Initialized
INFO - 2021-08-07 10:01:25 --> Security Class Initialized
INFO - 2021-08-07 10:01:25 --> URI Class Initialized
DEBUG - 2021-08-07 10:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:01:25 --> Router Class Initialized
INFO - 2021-08-07 10:01:25 --> Input Class Initialized
INFO - 2021-08-07 10:01:25 --> Language Class Initialized
INFO - 2021-08-07 10:01:25 --> Output Class Initialized
INFO - 2021-08-07 10:01:25 --> Security Class Initialized
DEBUG - 2021-08-07 10:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:01:25 --> Input Class Initialized
ERROR - 2021-08-07 10:01:25 --> 404 Page Not Found: Assets/js
INFO - 2021-08-07 10:01:25 --> Language Class Initialized
ERROR - 2021-08-07 10:01:25 --> 404 Page Not Found: Assets/js
INFO - 2021-08-07 10:01:25 --> Config Class Initialized
INFO - 2021-08-07 10:01:25 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:01:25 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:01:25 --> Utf8 Class Initialized
INFO - 2021-08-07 10:01:25 --> URI Class Initialized
INFO - 2021-08-07 10:01:25 --> Router Class Initialized
INFO - 2021-08-07 10:01:25 --> Output Class Initialized
INFO - 2021-08-07 10:01:25 --> Security Class Initialized
DEBUG - 2021-08-07 10:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:01:25 --> Input Class Initialized
INFO - 2021-08-07 10:01:25 --> Language Class Initialized
ERROR - 2021-08-07 10:01:25 --> 404 Page Not Found: Assets/js
INFO - 2021-08-07 10:01:27 --> Config Class Initialized
INFO - 2021-08-07 10:01:27 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:01:27 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:01:27 --> Utf8 Class Initialized
INFO - 2021-08-07 10:01:27 --> URI Class Initialized
INFO - 2021-08-07 10:01:27 --> Router Class Initialized
INFO - 2021-08-07 10:01:27 --> Output Class Initialized
INFO - 2021-08-07 10:01:27 --> Security Class Initialized
DEBUG - 2021-08-07 10:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:01:27 --> Input Class Initialized
INFO - 2021-08-07 10:01:27 --> Language Class Initialized
INFO - 2021-08-07 10:01:27 --> Loader Class Initialized
INFO - 2021-08-07 10:01:27 --> Helper loaded: url_helper
INFO - 2021-08-07 10:01:27 --> Helper loaded: file_helper
INFO - 2021-08-07 10:01:27 --> Database Driver Class Initialized
DEBUG - 2021-08-07 10:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 10:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 10:01:27 --> Controller Class Initialized
INFO - 2021-08-07 10:01:27 --> Helper loaded: cookie_helper
INFO - 2021-08-07 10:01:27 --> Model "CookieModel" initialized
INFO - 2021-08-07 10:01:27 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 10:01:27 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/services.php
INFO - 2021-08-07 10:01:27 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 10:01:27 --> Final output sent to browser
DEBUG - 2021-08-07 10:01:27 --> Total execution time: 0.0480
INFO - 2021-08-07 10:01:28 --> Config Class Initialized
INFO - 2021-08-07 10:01:28 --> Hooks Class Initialized
INFO - 2021-08-07 10:01:28 --> Config Class Initialized
INFO - 2021-08-07 10:01:28 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:01:28 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:01:28 --> Utf8 Class Initialized
INFO - 2021-08-07 10:01:28 --> URI Class Initialized
DEBUG - 2021-08-07 10:01:28 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:01:28 --> Utf8 Class Initialized
INFO - 2021-08-07 10:01:28 --> URI Class Initialized
INFO - 2021-08-07 10:01:28 --> Router Class Initialized
INFO - 2021-08-07 10:01:28 --> Router Class Initialized
INFO - 2021-08-07 10:01:28 --> Output Class Initialized
INFO - 2021-08-07 10:01:28 --> Output Class Initialized
INFO - 2021-08-07 10:01:28 --> Security Class Initialized
DEBUG - 2021-08-07 10:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:01:28 --> Security Class Initialized
INFO - 2021-08-07 10:01:28 --> Input Class Initialized
INFO - 2021-08-07 10:01:28 --> Language Class Initialized
DEBUG - 2021-08-07 10:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:01:28 --> Input Class Initialized
INFO - 2021-08-07 10:01:28 --> Language Class Initialized
ERROR - 2021-08-07 10:01:28 --> 404 Page Not Found: Assets/css
ERROR - 2021-08-07 10:01:28 --> 404 Page Not Found: Assets/css
INFO - 2021-08-07 10:01:28 --> Config Class Initialized
INFO - 2021-08-07 10:01:28 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:01:28 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:01:28 --> Utf8 Class Initialized
INFO - 2021-08-07 10:01:28 --> URI Class Initialized
INFO - 2021-08-07 10:01:28 --> Router Class Initialized
INFO - 2021-08-07 10:01:28 --> Output Class Initialized
INFO - 2021-08-07 10:01:28 --> Security Class Initialized
INFO - 2021-08-07 10:01:28 --> Config Class Initialized
INFO - 2021-08-07 10:01:28 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:01:28 --> Input Class Initialized
INFO - 2021-08-07 10:01:28 --> Language Class Initialized
DEBUG - 2021-08-07 10:01:28 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:01:28 --> Utf8 Class Initialized
ERROR - 2021-08-07 10:01:28 --> 404 Page Not Found: Assets/js
INFO - 2021-08-07 10:01:28 --> URI Class Initialized
INFO - 2021-08-07 10:01:28 --> Router Class Initialized
INFO - 2021-08-07 10:01:28 --> Output Class Initialized
INFO - 2021-08-07 10:01:28 --> Security Class Initialized
DEBUG - 2021-08-07 10:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:01:28 --> Input Class Initialized
INFO - 2021-08-07 10:01:28 --> Language Class Initialized
ERROR - 2021-08-07 10:01:28 --> 404 Page Not Found: Assets/js
INFO - 2021-08-07 10:01:28 --> Config Class Initialized
INFO - 2021-08-07 10:01:28 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:01:28 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:01:28 --> Utf8 Class Initialized
INFO - 2021-08-07 10:01:28 --> URI Class Initialized
INFO - 2021-08-07 10:01:28 --> Router Class Initialized
INFO - 2021-08-07 10:01:28 --> Output Class Initialized
INFO - 2021-08-07 10:01:28 --> Security Class Initialized
DEBUG - 2021-08-07 10:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:01:28 --> Input Class Initialized
INFO - 2021-08-07 10:01:28 --> Language Class Initialized
ERROR - 2021-08-07 10:01:28 --> 404 Page Not Found: Assets/js
INFO - 2021-08-07 10:01:33 --> Config Class Initialized
INFO - 2021-08-07 10:01:33 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:01:33 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:01:33 --> Utf8 Class Initialized
INFO - 2021-08-07 10:01:33 --> URI Class Initialized
INFO - 2021-08-07 10:01:33 --> Router Class Initialized
INFO - 2021-08-07 10:01:33 --> Output Class Initialized
INFO - 2021-08-07 10:01:33 --> Security Class Initialized
DEBUG - 2021-08-07 10:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:01:33 --> Input Class Initialized
INFO - 2021-08-07 10:01:33 --> Language Class Initialized
INFO - 2021-08-07 10:01:33 --> Loader Class Initialized
INFO - 2021-08-07 10:01:33 --> Helper loaded: url_helper
INFO - 2021-08-07 10:01:33 --> Helper loaded: file_helper
INFO - 2021-08-07 10:01:33 --> Database Driver Class Initialized
DEBUG - 2021-08-07 10:01:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 10:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 10:01:33 --> Controller Class Initialized
INFO - 2021-08-07 10:01:33 --> Helper loaded: cookie_helper
INFO - 2021-08-07 10:01:33 --> Model "CookieModel" initialized
INFO - 2021-08-07 10:01:33 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 10:01:33 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/services.php
INFO - 2021-08-07 10:01:33 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 10:01:33 --> Final output sent to browser
DEBUG - 2021-08-07 10:01:33 --> Total execution time: 0.0512
INFO - 2021-08-07 10:01:34 --> Config Class Initialized
INFO - 2021-08-07 10:01:34 --> Hooks Class Initialized
INFO - 2021-08-07 10:01:34 --> Config Class Initialized
INFO - 2021-08-07 10:01:34 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:01:34 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:01:34 --> Utf8 Class Initialized
INFO - 2021-08-07 10:01:34 --> URI Class Initialized
INFO - 2021-08-07 10:01:34 --> Router Class Initialized
DEBUG - 2021-08-07 10:01:34 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:01:34 --> Utf8 Class Initialized
INFO - 2021-08-07 10:01:34 --> Output Class Initialized
INFO - 2021-08-07 10:01:34 --> Security Class Initialized
INFO - 2021-08-07 10:01:34 --> URI Class Initialized
DEBUG - 2021-08-07 10:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:01:34 --> Input Class Initialized
INFO - 2021-08-07 10:01:34 --> Router Class Initialized
INFO - 2021-08-07 10:01:34 --> Language Class Initialized
ERROR - 2021-08-07 10:01:34 --> 404 Page Not Found: Assets/css
INFO - 2021-08-07 10:01:34 --> Output Class Initialized
INFO - 2021-08-07 10:01:34 --> Security Class Initialized
DEBUG - 2021-08-07 10:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:01:34 --> Input Class Initialized
INFO - 2021-08-07 10:01:34 --> Language Class Initialized
ERROR - 2021-08-07 10:01:34 --> 404 Page Not Found: Assets/css
INFO - 2021-08-07 10:01:34 --> Config Class Initialized
INFO - 2021-08-07 10:01:34 --> Hooks Class Initialized
INFO - 2021-08-07 10:01:34 --> Config Class Initialized
INFO - 2021-08-07 10:01:34 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:01:34 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:01:34 --> Utf8 Class Initialized
DEBUG - 2021-08-07 10:01:34 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:01:34 --> URI Class Initialized
INFO - 2021-08-07 10:01:34 --> Utf8 Class Initialized
INFO - 2021-08-07 10:01:34 --> URI Class Initialized
INFO - 2021-08-07 10:01:34 --> Router Class Initialized
INFO - 2021-08-07 10:01:34 --> Router Class Initialized
INFO - 2021-08-07 10:01:34 --> Output Class Initialized
INFO - 2021-08-07 10:01:34 --> Output Class Initialized
INFO - 2021-08-07 10:01:34 --> Security Class Initialized
INFO - 2021-08-07 10:01:34 --> Security Class Initialized
DEBUG - 2021-08-07 10:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:01:34 --> Input Class Initialized
INFO - 2021-08-07 10:01:34 --> Language Class Initialized
DEBUG - 2021-08-07 10:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:01:34 --> Input Class Initialized
INFO - 2021-08-07 10:01:34 --> Language Class Initialized
ERROR - 2021-08-07 10:01:34 --> 404 Page Not Found: Assets/js
ERROR - 2021-08-07 10:01:34 --> 404 Page Not Found: Assets/js
INFO - 2021-08-07 10:01:34 --> Config Class Initialized
INFO - 2021-08-07 10:01:34 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:01:34 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:01:34 --> Utf8 Class Initialized
INFO - 2021-08-07 10:01:34 --> URI Class Initialized
INFO - 2021-08-07 10:01:34 --> Router Class Initialized
INFO - 2021-08-07 10:01:34 --> Output Class Initialized
INFO - 2021-08-07 10:01:34 --> Security Class Initialized
DEBUG - 2021-08-07 10:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:01:34 --> Input Class Initialized
INFO - 2021-08-07 10:01:34 --> Language Class Initialized
ERROR - 2021-08-07 10:01:34 --> 404 Page Not Found: Assets/js
INFO - 2021-08-07 10:01:38 --> Config Class Initialized
INFO - 2021-08-07 10:01:38 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:01:38 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:01:38 --> Utf8 Class Initialized
INFO - 2021-08-07 10:01:38 --> URI Class Initialized
INFO - 2021-08-07 10:01:38 --> Router Class Initialized
INFO - 2021-08-07 10:01:38 --> Output Class Initialized
INFO - 2021-08-07 10:01:38 --> Security Class Initialized
DEBUG - 2021-08-07 10:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:01:38 --> Input Class Initialized
INFO - 2021-08-07 10:01:38 --> Language Class Initialized
INFO - 2021-08-07 10:01:38 --> Loader Class Initialized
INFO - 2021-08-07 10:01:38 --> Helper loaded: url_helper
INFO - 2021-08-07 10:01:38 --> Helper loaded: file_helper
INFO - 2021-08-07 10:01:38 --> Database Driver Class Initialized
DEBUG - 2021-08-07 10:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 10:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 10:01:38 --> Controller Class Initialized
INFO - 2021-08-07 10:01:38 --> Helper loaded: cookie_helper
INFO - 2021-08-07 10:01:38 --> Model "CookieModel" initialized
INFO - 2021-08-07 10:01:38 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 10:01:38 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-07 10:01:38 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 10:01:38 --> Final output sent to browser
DEBUG - 2021-08-07 10:01:38 --> Total execution time: 0.0490
INFO - 2021-08-07 10:01:38 --> Config Class Initialized
INFO - 2021-08-07 10:01:38 --> Hooks Class Initialized
INFO - 2021-08-07 10:01:38 --> Config Class Initialized
INFO - 2021-08-07 10:01:38 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:01:38 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:01:38 --> Utf8 Class Initialized
INFO - 2021-08-07 10:01:38 --> URI Class Initialized
DEBUG - 2021-08-07 10:01:38 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:01:38 --> Router Class Initialized
INFO - 2021-08-07 10:01:38 --> Utf8 Class Initialized
INFO - 2021-08-07 10:01:38 --> URI Class Initialized
INFO - 2021-08-07 10:01:38 --> Output Class Initialized
INFO - 2021-08-07 10:01:38 --> Router Class Initialized
INFO - 2021-08-07 10:01:38 --> Security Class Initialized
DEBUG - 2021-08-07 10:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:01:38 --> Input Class Initialized
INFO - 2021-08-07 10:01:38 --> Output Class Initialized
INFO - 2021-08-07 10:01:38 --> Language Class Initialized
INFO - 2021-08-07 10:01:38 --> Security Class Initialized
ERROR - 2021-08-07 10:01:38 --> 404 Page Not Found: Assets/css
DEBUG - 2021-08-07 10:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:01:38 --> Input Class Initialized
INFO - 2021-08-07 10:01:38 --> Language Class Initialized
ERROR - 2021-08-07 10:01:38 --> 404 Page Not Found: Assets/css
INFO - 2021-08-07 10:01:38 --> Config Class Initialized
INFO - 2021-08-07 10:01:38 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:01:38 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:01:38 --> Utf8 Class Initialized
INFO - 2021-08-07 10:01:38 --> URI Class Initialized
INFO - 2021-08-07 10:01:38 --> Router Class Initialized
INFO - 2021-08-07 10:01:38 --> Output Class Initialized
INFO - 2021-08-07 10:01:38 --> Security Class Initialized
DEBUG - 2021-08-07 10:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:01:38 --> Input Class Initialized
INFO - 2021-08-07 10:01:38 --> Language Class Initialized
ERROR - 2021-08-07 10:01:38 --> 404 Page Not Found: Assets/js
INFO - 2021-08-07 10:01:38 --> Config Class Initialized
INFO - 2021-08-07 10:01:38 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:01:38 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:01:38 --> Utf8 Class Initialized
INFO - 2021-08-07 10:01:38 --> URI Class Initialized
INFO - 2021-08-07 10:01:38 --> Router Class Initialized
INFO - 2021-08-07 10:01:38 --> Output Class Initialized
INFO - 2021-08-07 10:01:38 --> Security Class Initialized
DEBUG - 2021-08-07 10:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:01:38 --> Input Class Initialized
INFO - 2021-08-07 10:01:38 --> Language Class Initialized
ERROR - 2021-08-07 10:01:38 --> 404 Page Not Found: Assets/js
INFO - 2021-08-07 10:01:38 --> Config Class Initialized
INFO - 2021-08-07 10:01:38 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:01:38 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:01:38 --> Utf8 Class Initialized
INFO - 2021-08-07 10:01:38 --> URI Class Initialized
INFO - 2021-08-07 10:01:38 --> Router Class Initialized
INFO - 2021-08-07 10:01:38 --> Output Class Initialized
INFO - 2021-08-07 10:01:38 --> Security Class Initialized
DEBUG - 2021-08-07 10:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:01:38 --> Input Class Initialized
INFO - 2021-08-07 10:01:38 --> Language Class Initialized
ERROR - 2021-08-07 10:01:38 --> 404 Page Not Found: Assets/js
INFO - 2021-08-07 10:07:36 --> Config Class Initialized
INFO - 2021-08-07 10:07:36 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:07:36 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:07:36 --> Utf8 Class Initialized
INFO - 2021-08-07 10:07:36 --> URI Class Initialized
DEBUG - 2021-08-07 10:07:36 --> No URI present. Default controller set.
INFO - 2021-08-07 10:07:36 --> Router Class Initialized
INFO - 2021-08-07 10:07:36 --> Output Class Initialized
INFO - 2021-08-07 10:07:36 --> Security Class Initialized
DEBUG - 2021-08-07 10:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:07:36 --> Input Class Initialized
INFO - 2021-08-07 10:07:36 --> Language Class Initialized
INFO - 2021-08-07 10:07:36 --> Loader Class Initialized
INFO - 2021-08-07 10:07:36 --> Helper loaded: url_helper
INFO - 2021-08-07 10:07:36 --> Helper loaded: file_helper
INFO - 2021-08-07 10:07:36 --> Database Driver Class Initialized
DEBUG - 2021-08-07 10:07:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 10:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 10:07:36 --> Controller Class Initialized
INFO - 2021-08-07 10:07:36 --> Helper loaded: cookie_helper
INFO - 2021-08-07 10:07:36 --> Model "CookieModel" initialized
INFO - 2021-08-07 10:07:36 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 10:07:36 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-07 10:07:36 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 10:07:36 --> Final output sent to browser
DEBUG - 2021-08-07 10:07:36 --> Total execution time: 0.0585
INFO - 2021-08-07 10:07:44 --> Config Class Initialized
INFO - 2021-08-07 10:07:44 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:07:44 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:07:44 --> Utf8 Class Initialized
INFO - 2021-08-07 10:07:44 --> URI Class Initialized
INFO - 2021-08-07 10:07:44 --> Config Class Initialized
INFO - 2021-08-07 10:07:44 --> Hooks Class Initialized
INFO - 2021-08-07 10:07:44 --> Router Class Initialized
INFO - 2021-08-07 10:07:44 --> Output Class Initialized
DEBUG - 2021-08-07 10:07:44 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:07:44 --> Utf8 Class Initialized
INFO - 2021-08-07 10:07:44 --> Security Class Initialized
INFO - 2021-08-07 10:07:44 --> URI Class Initialized
DEBUG - 2021-08-07 10:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:07:44 --> Input Class Initialized
INFO - 2021-08-07 10:07:44 --> Language Class Initialized
INFO - 2021-08-07 10:07:44 --> Router Class Initialized
ERROR - 2021-08-07 10:07:44 --> 404 Page Not Found: Assets/js
INFO - 2021-08-07 10:07:44 --> Output Class Initialized
INFO - 2021-08-07 10:07:44 --> Security Class Initialized
DEBUG - 2021-08-07 10:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:07:44 --> Input Class Initialized
INFO - 2021-08-07 10:07:44 --> Language Class Initialized
ERROR - 2021-08-07 10:07:44 --> 404 Page Not Found: Assets/css
INFO - 2021-08-07 10:07:44 --> Config Class Initialized
INFO - 2021-08-07 10:07:44 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:07:44 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:07:44 --> Utf8 Class Initialized
INFO - 2021-08-07 10:07:44 --> URI Class Initialized
INFO - 2021-08-07 10:07:44 --> Config Class Initialized
INFO - 2021-08-07 10:07:44 --> Hooks Class Initialized
INFO - 2021-08-07 10:07:44 --> Router Class Initialized
INFO - 2021-08-07 10:07:44 --> Output Class Initialized
DEBUG - 2021-08-07 10:07:44 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:07:44 --> Utf8 Class Initialized
INFO - 2021-08-07 10:07:44 --> Security Class Initialized
INFO - 2021-08-07 10:07:44 --> URI Class Initialized
DEBUG - 2021-08-07 10:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:07:44 --> Router Class Initialized
INFO - 2021-08-07 10:07:44 --> Input Class Initialized
INFO - 2021-08-07 10:07:44 --> Language Class Initialized
INFO - 2021-08-07 10:07:44 --> Output Class Initialized
ERROR - 2021-08-07 10:07:44 --> 404 Page Not Found: Assets/js
INFO - 2021-08-07 10:07:44 --> Security Class Initialized
DEBUG - 2021-08-07 10:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:07:44 --> Input Class Initialized
INFO - 2021-08-07 10:07:44 --> Language Class Initialized
ERROR - 2021-08-07 10:07:44 --> 404 Page Not Found: Assets/css
INFO - 2021-08-07 10:07:44 --> Config Class Initialized
INFO - 2021-08-07 10:07:44 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:07:44 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:07:44 --> Utf8 Class Initialized
INFO - 2021-08-07 10:07:44 --> URI Class Initialized
INFO - 2021-08-07 10:07:44 --> Router Class Initialized
INFO - 2021-08-07 10:07:44 --> Output Class Initialized
INFO - 2021-08-07 10:07:44 --> Security Class Initialized
DEBUG - 2021-08-07 10:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:07:44 --> Input Class Initialized
INFO - 2021-08-07 10:07:44 --> Language Class Initialized
ERROR - 2021-08-07 10:07:44 --> 404 Page Not Found: Assets/js
INFO - 2021-08-07 10:08:58 --> Config Class Initialized
INFO - 2021-08-07 10:08:58 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:08:58 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:08:58 --> Utf8 Class Initialized
INFO - 2021-08-07 10:08:58 --> URI Class Initialized
DEBUG - 2021-08-07 10:08:58 --> No URI present. Default controller set.
INFO - 2021-08-07 10:08:58 --> Router Class Initialized
INFO - 2021-08-07 10:08:58 --> Output Class Initialized
INFO - 2021-08-07 10:08:58 --> Security Class Initialized
DEBUG - 2021-08-07 10:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:08:58 --> Input Class Initialized
INFO - 2021-08-07 10:08:58 --> Language Class Initialized
INFO - 2021-08-07 10:08:58 --> Loader Class Initialized
INFO - 2021-08-07 10:08:58 --> Helper loaded: url_helper
INFO - 2021-08-07 10:08:58 --> Helper loaded: file_helper
INFO - 2021-08-07 10:08:58 --> Database Driver Class Initialized
DEBUG - 2021-08-07 10:08:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 10:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 10:08:58 --> Controller Class Initialized
INFO - 2021-08-07 10:08:58 --> Helper loaded: cookie_helper
INFO - 2021-08-07 10:08:58 --> Model "CookieModel" initialized
INFO - 2021-08-07 10:08:58 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 10:08:58 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-07 10:08:58 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 10:08:58 --> Final output sent to browser
DEBUG - 2021-08-07 10:08:58 --> Total execution time: 0.0619
INFO - 2021-08-07 10:09:06 --> Config Class Initialized
INFO - 2021-08-07 10:09:06 --> Hooks Class Initialized
INFO - 2021-08-07 10:09:06 --> Config Class Initialized
INFO - 2021-08-07 10:09:06 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:09:06 --> UTF-8 Support Enabled
DEBUG - 2021-08-07 10:09:06 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:09:06 --> Utf8 Class Initialized
INFO - 2021-08-07 10:09:06 --> Utf8 Class Initialized
INFO - 2021-08-07 10:09:06 --> URI Class Initialized
INFO - 2021-08-07 10:09:06 --> URI Class Initialized
INFO - 2021-08-07 10:09:06 --> Router Class Initialized
INFO - 2021-08-07 10:09:06 --> Config Class Initialized
INFO - 2021-08-07 10:09:06 --> Router Class Initialized
INFO - 2021-08-07 10:09:06 --> Hooks Class Initialized
INFO - 2021-08-07 10:09:06 --> Output Class Initialized
INFO - 2021-08-07 10:09:06 --> Output Class Initialized
DEBUG - 2021-08-07 10:09:06 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:09:06 --> Utf8 Class Initialized
INFO - 2021-08-07 10:09:06 --> Security Class Initialized
INFO - 2021-08-07 10:09:06 --> Security Class Initialized
INFO - 2021-08-07 10:09:06 --> URI Class Initialized
DEBUG - 2021-08-07 10:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:09:06 --> Input Class Initialized
DEBUG - 2021-08-07 10:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:09:06 --> Language Class Initialized
INFO - 2021-08-07 10:09:06 --> Input Class Initialized
INFO - 2021-08-07 10:09:06 --> Router Class Initialized
ERROR - 2021-08-07 10:09:06 --> 404 Page Not Found: Assets/js
INFO - 2021-08-07 10:09:06 --> Language Class Initialized
ERROR - 2021-08-07 10:09:06 --> 404 Page Not Found: Assets/js
INFO - 2021-08-07 10:09:06 --> Output Class Initialized
INFO - 2021-08-07 10:09:06 --> Security Class Initialized
DEBUG - 2021-08-07 10:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:09:06 --> Input Class Initialized
INFO - 2021-08-07 10:09:06 --> Language Class Initialized
INFO - 2021-08-07 10:09:06 --> Config Class Initialized
INFO - 2021-08-07 10:09:06 --> Hooks Class Initialized
ERROR - 2021-08-07 10:09:06 --> 404 Page Not Found: Assets/css
DEBUG - 2021-08-07 10:09:06 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:09:06 --> Utf8 Class Initialized
INFO - 2021-08-07 10:09:06 --> URI Class Initialized
INFO - 2021-08-07 10:09:06 --> Router Class Initialized
INFO - 2021-08-07 10:09:06 --> Config Class Initialized
INFO - 2021-08-07 10:09:06 --> Hooks Class Initialized
INFO - 2021-08-07 10:09:06 --> Output Class Initialized
DEBUG - 2021-08-07 10:09:06 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:09:06 --> Utf8 Class Initialized
INFO - 2021-08-07 10:09:06 --> URI Class Initialized
INFO - 2021-08-07 10:09:06 --> Security Class Initialized
INFO - 2021-08-07 10:09:06 --> Router Class Initialized
DEBUG - 2021-08-07 10:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:09:06 --> Input Class Initialized
INFO - 2021-08-07 10:09:06 --> Language Class Initialized
INFO - 2021-08-07 10:09:06 --> Output Class Initialized
INFO - 2021-08-07 10:09:06 --> Security Class Initialized
DEBUG - 2021-08-07 10:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:09:06 --> Input Class Initialized
ERROR - 2021-08-07 10:09:06 --> 404 Page Not Found: Assets/js
INFO - 2021-08-07 10:09:06 --> Language Class Initialized
ERROR - 2021-08-07 10:09:06 --> 404 Page Not Found: Assets/css
INFO - 2021-08-07 10:11:06 --> Config Class Initialized
INFO - 2021-08-07 10:11:06 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:11:06 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:11:06 --> Utf8 Class Initialized
INFO - 2021-08-07 10:11:06 --> URI Class Initialized
DEBUG - 2021-08-07 10:11:06 --> No URI present. Default controller set.
INFO - 2021-08-07 10:11:06 --> Router Class Initialized
INFO - 2021-08-07 10:11:06 --> Output Class Initialized
INFO - 2021-08-07 10:11:06 --> Security Class Initialized
DEBUG - 2021-08-07 10:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:11:06 --> Input Class Initialized
INFO - 2021-08-07 10:11:06 --> Language Class Initialized
INFO - 2021-08-07 10:11:06 --> Loader Class Initialized
INFO - 2021-08-07 10:11:06 --> Helper loaded: url_helper
INFO - 2021-08-07 10:11:06 --> Helper loaded: file_helper
INFO - 2021-08-07 10:11:06 --> Database Driver Class Initialized
DEBUG - 2021-08-07 10:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 10:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 10:11:06 --> Controller Class Initialized
INFO - 2021-08-07 10:11:06 --> Helper loaded: cookie_helper
INFO - 2021-08-07 10:11:06 --> Model "CookieModel" initialized
INFO - 2021-08-07 10:11:06 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 10:11:06 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-07 10:11:06 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 10:11:06 --> Final output sent to browser
DEBUG - 2021-08-07 10:11:06 --> Total execution time: 0.0810
INFO - 2021-08-07 10:11:07 --> Config Class Initialized
INFO - 2021-08-07 10:11:07 --> Hooks Class Initialized
INFO - 2021-08-07 10:11:07 --> Config Class Initialized
INFO - 2021-08-07 10:11:07 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:11:07 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:11:07 --> Utf8 Class Initialized
DEBUG - 2021-08-07 10:11:07 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:11:07 --> Utf8 Class Initialized
INFO - 2021-08-07 10:11:07 --> URI Class Initialized
INFO - 2021-08-07 10:11:07 --> URI Class Initialized
INFO - 2021-08-07 10:11:07 --> Router Class Initialized
INFO - 2021-08-07 10:11:07 --> Router Class Initialized
INFO - 2021-08-07 10:11:07 --> Output Class Initialized
INFO - 2021-08-07 10:11:07 --> Output Class Initialized
INFO - 2021-08-07 10:11:07 --> Security Class Initialized
INFO - 2021-08-07 10:11:07 --> Security Class Initialized
DEBUG - 2021-08-07 10:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-08-07 10:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:11:07 --> Input Class Initialized
INFO - 2021-08-07 10:11:07 --> Input Class Initialized
INFO - 2021-08-07 10:11:07 --> Language Class Initialized
INFO - 2021-08-07 10:11:07 --> Language Class Initialized
ERROR - 2021-08-07 10:11:07 --> 404 Page Not Found: Assets/css
ERROR - 2021-08-07 10:11:07 --> 404 Page Not Found: Assets/css
INFO - 2021-08-07 10:11:07 --> Config Class Initialized
INFO - 2021-08-07 10:11:07 --> Hooks Class Initialized
INFO - 2021-08-07 10:11:07 --> Config Class Initialized
INFO - 2021-08-07 10:11:07 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:11:07 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:11:07 --> Utf8 Class Initialized
INFO - 2021-08-07 10:11:07 --> URI Class Initialized
DEBUG - 2021-08-07 10:11:07 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:11:07 --> Utf8 Class Initialized
INFO - 2021-08-07 10:11:07 --> Router Class Initialized
INFO - 2021-08-07 10:11:07 --> URI Class Initialized
INFO - 2021-08-07 10:11:07 --> Output Class Initialized
INFO - 2021-08-07 10:11:07 --> Router Class Initialized
INFO - 2021-08-07 10:11:07 --> Security Class Initialized
INFO - 2021-08-07 10:11:07 --> Output Class Initialized
DEBUG - 2021-08-07 10:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:11:07 --> Input Class Initialized
INFO - 2021-08-07 10:11:07 --> Security Class Initialized
INFO - 2021-08-07 10:11:07 --> Language Class Initialized
ERROR - 2021-08-07 10:11:07 --> 404 Page Not Found: Assets/js
DEBUG - 2021-08-07 10:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:11:07 --> Input Class Initialized
INFO - 2021-08-07 10:11:07 --> Language Class Initialized
ERROR - 2021-08-07 10:11:07 --> 404 Page Not Found: Assets/js
INFO - 2021-08-07 10:11:08 --> Config Class Initialized
INFO - 2021-08-07 10:11:08 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:11:08 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:11:08 --> Utf8 Class Initialized
INFO - 2021-08-07 10:11:08 --> URI Class Initialized
INFO - 2021-08-07 10:11:08 --> Router Class Initialized
INFO - 2021-08-07 10:11:08 --> Output Class Initialized
INFO - 2021-08-07 10:11:08 --> Security Class Initialized
DEBUG - 2021-08-07 10:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:11:08 --> Input Class Initialized
INFO - 2021-08-07 10:11:08 --> Language Class Initialized
ERROR - 2021-08-07 10:11:08 --> 404 Page Not Found: Assets/js
INFO - 2021-08-07 10:11:41 --> Config Class Initialized
INFO - 2021-08-07 10:11:41 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:11:41 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:11:41 --> Utf8 Class Initialized
INFO - 2021-08-07 10:11:41 --> URI Class Initialized
DEBUG - 2021-08-07 10:11:41 --> No URI present. Default controller set.
INFO - 2021-08-07 10:11:41 --> Router Class Initialized
INFO - 2021-08-07 10:11:41 --> Output Class Initialized
INFO - 2021-08-07 10:11:41 --> Security Class Initialized
DEBUG - 2021-08-07 10:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:11:41 --> Input Class Initialized
INFO - 2021-08-07 10:11:41 --> Language Class Initialized
INFO - 2021-08-07 10:11:41 --> Loader Class Initialized
INFO - 2021-08-07 10:11:41 --> Helper loaded: url_helper
INFO - 2021-08-07 10:11:41 --> Helper loaded: file_helper
INFO - 2021-08-07 10:11:41 --> Database Driver Class Initialized
DEBUG - 2021-08-07 10:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 10:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 10:11:41 --> Controller Class Initialized
INFO - 2021-08-07 10:11:41 --> Helper loaded: cookie_helper
INFO - 2021-08-07 10:11:41 --> Model "CookieModel" initialized
INFO - 2021-08-07 10:11:41 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 10:11:41 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-07 10:11:41 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 10:11:41 --> Final output sent to browser
DEBUG - 2021-08-07 10:11:41 --> Total execution time: 0.0595
INFO - 2021-08-07 10:11:56 --> Config Class Initialized
INFO - 2021-08-07 10:11:56 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:11:56 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:11:56 --> Utf8 Class Initialized
INFO - 2021-08-07 10:11:56 --> URI Class Initialized
INFO - 2021-08-07 10:11:56 --> Router Class Initialized
INFO - 2021-08-07 10:11:56 --> Output Class Initialized
INFO - 2021-08-07 10:11:56 --> Security Class Initialized
DEBUG - 2021-08-07 10:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:11:56 --> Input Class Initialized
INFO - 2021-08-07 10:11:56 --> Language Class Initialized
ERROR - 2021-08-07 10:11:56 --> 404 Page Not Found: Assets/js
INFO - 2021-08-07 10:11:56 --> Config Class Initialized
INFO - 2021-08-07 10:11:56 --> Hooks Class Initialized
INFO - 2021-08-07 10:11:56 --> Config Class Initialized
INFO - 2021-08-07 10:11:56 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:11:56 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:11:56 --> Utf8 Class Initialized
DEBUG - 2021-08-07 10:11:56 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:11:56 --> Utf8 Class Initialized
INFO - 2021-08-07 10:11:56 --> URI Class Initialized
INFO - 2021-08-07 10:11:56 --> URI Class Initialized
INFO - 2021-08-07 10:11:56 --> Router Class Initialized
INFO - 2021-08-07 10:11:56 --> Router Class Initialized
INFO - 2021-08-07 10:11:56 --> Output Class Initialized
INFO - 2021-08-07 10:11:56 --> Output Class Initialized
INFO - 2021-08-07 10:11:56 --> Security Class Initialized
INFO - 2021-08-07 10:11:56 --> Security Class Initialized
DEBUG - 2021-08-07 10:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-08-07 10:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:11:56 --> Input Class Initialized
INFO - 2021-08-07 10:11:56 --> Input Class Initialized
INFO - 2021-08-07 10:11:56 --> Language Class Initialized
INFO - 2021-08-07 10:11:56 --> Language Class Initialized
ERROR - 2021-08-07 10:11:56 --> 404 Page Not Found: Assets/js
ERROR - 2021-08-07 10:11:56 --> 404 Page Not Found: Assets/js
INFO - 2021-08-07 10:11:56 --> Config Class Initialized
INFO - 2021-08-07 10:11:56 --> Hooks Class Initialized
INFO - 2021-08-07 10:11:56 --> Config Class Initialized
INFO - 2021-08-07 10:11:56 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:11:56 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:11:56 --> Utf8 Class Initialized
INFO - 2021-08-07 10:11:56 --> URI Class Initialized
INFO - 2021-08-07 10:11:56 --> Router Class Initialized
INFO - 2021-08-07 10:11:57 --> Output Class Initialized
INFO - 2021-08-07 10:11:57 --> Security Class Initialized
DEBUG - 2021-08-07 10:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:11:57 --> Input Class Initialized
INFO - 2021-08-07 10:11:57 --> Language Class Initialized
DEBUG - 2021-08-07 10:11:57 --> UTF-8 Support Enabled
ERROR - 2021-08-07 10:11:57 --> 404 Page Not Found: Assets/css
INFO - 2021-08-07 10:11:57 --> Utf8 Class Initialized
INFO - 2021-08-07 10:11:57 --> URI Class Initialized
INFO - 2021-08-07 10:11:57 --> Router Class Initialized
INFO - 2021-08-07 10:11:57 --> Output Class Initialized
INFO - 2021-08-07 10:11:57 --> Security Class Initialized
DEBUG - 2021-08-07 10:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:11:57 --> Input Class Initialized
INFO - 2021-08-07 10:11:57 --> Language Class Initialized
ERROR - 2021-08-07 10:11:57 --> 404 Page Not Found: Assets/css
INFO - 2021-08-07 10:21:12 --> Config Class Initialized
INFO - 2021-08-07 10:21:12 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:21:12 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:21:12 --> Utf8 Class Initialized
INFO - 2021-08-07 10:21:12 --> URI Class Initialized
INFO - 2021-08-07 10:21:12 --> Router Class Initialized
INFO - 2021-08-07 10:21:12 --> Output Class Initialized
INFO - 2021-08-07 10:21:12 --> Security Class Initialized
DEBUG - 2021-08-07 10:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:21:12 --> Input Class Initialized
INFO - 2021-08-07 10:21:12 --> Language Class Initialized
INFO - 2021-08-07 10:21:12 --> Loader Class Initialized
INFO - 2021-08-07 10:21:12 --> Helper loaded: url_helper
INFO - 2021-08-07 10:21:12 --> Helper loaded: file_helper
INFO - 2021-08-07 10:21:12 --> Database Driver Class Initialized
DEBUG - 2021-08-07 10:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 10:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 10:21:12 --> Controller Class Initialized
INFO - 2021-08-07 10:21:12 --> Helper loaded: cookie_helper
INFO - 2021-08-07 10:21:12 --> Model "CookieModel" initialized
INFO - 2021-08-07 10:21:12 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 10:21:12 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/team.php
INFO - 2021-08-07 10:21:12 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 10:21:12 --> Final output sent to browser
DEBUG - 2021-08-07 10:21:12 --> Total execution time: 0.0812
INFO - 2021-08-07 10:21:12 --> Config Class Initialized
INFO - 2021-08-07 10:21:12 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:21:12 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:21:12 --> Utf8 Class Initialized
INFO - 2021-08-07 10:21:12 --> URI Class Initialized
INFO - 2021-08-07 10:21:12 --> Router Class Initialized
INFO - 2021-08-07 10:21:12 --> Output Class Initialized
INFO - 2021-08-07 10:21:12 --> Security Class Initialized
DEBUG - 2021-08-07 10:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:21:12 --> Input Class Initialized
INFO - 2021-08-07 10:21:12 --> Language Class Initialized
ERROR - 2021-08-07 10:21:12 --> 404 Page Not Found: About/assets
INFO - 2021-08-07 10:22:26 --> Config Class Initialized
INFO - 2021-08-07 10:22:26 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:22:26 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:22:26 --> Utf8 Class Initialized
INFO - 2021-08-07 10:22:26 --> URI Class Initialized
INFO - 2021-08-07 10:22:26 --> Router Class Initialized
INFO - 2021-08-07 10:22:26 --> Output Class Initialized
INFO - 2021-08-07 10:22:26 --> Security Class Initialized
DEBUG - 2021-08-07 10:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:22:26 --> Input Class Initialized
INFO - 2021-08-07 10:22:26 --> Language Class Initialized
INFO - 2021-08-07 10:22:26 --> Loader Class Initialized
INFO - 2021-08-07 10:22:26 --> Helper loaded: url_helper
INFO - 2021-08-07 10:22:26 --> Helper loaded: file_helper
INFO - 2021-08-07 10:22:26 --> Database Driver Class Initialized
DEBUG - 2021-08-07 10:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 10:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 10:22:26 --> Controller Class Initialized
INFO - 2021-08-07 10:22:26 --> Helper loaded: cookie_helper
INFO - 2021-08-07 10:22:26 --> Model "CookieModel" initialized
INFO - 2021-08-07 10:22:26 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 10:22:26 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/team.php
INFO - 2021-08-07 10:22:26 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 10:22:26 --> Final output sent to browser
DEBUG - 2021-08-07 10:22:26 --> Total execution time: 0.0402
INFO - 2021-08-07 10:23:21 --> Config Class Initialized
INFO - 2021-08-07 10:23:21 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:23:21 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:23:21 --> Utf8 Class Initialized
INFO - 2021-08-07 10:23:21 --> URI Class Initialized
INFO - 2021-08-07 10:23:21 --> Router Class Initialized
INFO - 2021-08-07 10:23:21 --> Output Class Initialized
INFO - 2021-08-07 10:23:21 --> Security Class Initialized
DEBUG - 2021-08-07 10:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:23:21 --> Input Class Initialized
INFO - 2021-08-07 10:23:21 --> Language Class Initialized
INFO - 2021-08-07 10:23:21 --> Loader Class Initialized
INFO - 2021-08-07 10:23:21 --> Helper loaded: url_helper
INFO - 2021-08-07 10:23:21 --> Helper loaded: file_helper
INFO - 2021-08-07 10:23:21 --> Database Driver Class Initialized
DEBUG - 2021-08-07 10:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 10:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 10:23:21 --> Controller Class Initialized
INFO - 2021-08-07 10:23:21 --> Helper loaded: cookie_helper
INFO - 2021-08-07 10:23:21 --> Model "CookieModel" initialized
INFO - 2021-08-07 10:23:21 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 10:23:21 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/team.php
INFO - 2021-08-07 10:23:21 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 10:23:21 --> Final output sent to browser
DEBUG - 2021-08-07 10:23:21 --> Total execution time: 0.0448
INFO - 2021-08-07 10:23:56 --> Config Class Initialized
INFO - 2021-08-07 10:23:56 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:23:56 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:23:56 --> Utf8 Class Initialized
INFO - 2021-08-07 10:23:56 --> URI Class Initialized
INFO - 2021-08-07 10:23:56 --> Router Class Initialized
INFO - 2021-08-07 10:23:56 --> Output Class Initialized
INFO - 2021-08-07 10:23:56 --> Security Class Initialized
DEBUG - 2021-08-07 10:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:23:56 --> Input Class Initialized
INFO - 2021-08-07 10:23:56 --> Language Class Initialized
INFO - 2021-08-07 10:23:56 --> Loader Class Initialized
INFO - 2021-08-07 10:23:56 --> Helper loaded: url_helper
INFO - 2021-08-07 10:23:56 --> Helper loaded: file_helper
INFO - 2021-08-07 10:23:56 --> Database Driver Class Initialized
DEBUG - 2021-08-07 10:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 10:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 10:23:56 --> Controller Class Initialized
INFO - 2021-08-07 10:23:56 --> Helper loaded: cookie_helper
INFO - 2021-08-07 10:23:56 --> Model "CookieModel" initialized
INFO - 2021-08-07 10:23:56 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 10:23:56 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/team.php
INFO - 2021-08-07 10:23:56 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 10:23:56 --> Final output sent to browser
DEBUG - 2021-08-07 10:23:56 --> Total execution time: 0.0414
INFO - 2021-08-07 10:27:06 --> Config Class Initialized
INFO - 2021-08-07 10:27:06 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:27:06 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:27:06 --> Utf8 Class Initialized
INFO - 2021-08-07 10:27:06 --> URI Class Initialized
INFO - 2021-08-07 10:27:06 --> Router Class Initialized
INFO - 2021-08-07 10:27:06 --> Output Class Initialized
INFO - 2021-08-07 10:27:06 --> Security Class Initialized
DEBUG - 2021-08-07 10:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:27:06 --> Input Class Initialized
INFO - 2021-08-07 10:27:06 --> Language Class Initialized
INFO - 2021-08-07 10:27:06 --> Loader Class Initialized
INFO - 2021-08-07 10:27:06 --> Helper loaded: url_helper
INFO - 2021-08-07 10:27:06 --> Helper loaded: file_helper
INFO - 2021-08-07 10:27:06 --> Database Driver Class Initialized
DEBUG - 2021-08-07 10:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 10:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 10:27:06 --> Controller Class Initialized
INFO - 2021-08-07 10:27:06 --> Helper loaded: cookie_helper
INFO - 2021-08-07 10:27:06 --> Model "CookieModel" initialized
INFO - 2021-08-07 10:27:06 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 10:27:06 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/team.php
INFO - 2021-08-07 10:27:06 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 10:27:06 --> Final output sent to browser
DEBUG - 2021-08-07 10:27:06 --> Total execution time: 0.1266
INFO - 2021-08-07 10:27:49 --> Config Class Initialized
INFO - 2021-08-07 10:27:49 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:27:49 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:27:49 --> Utf8 Class Initialized
INFO - 2021-08-07 10:27:49 --> URI Class Initialized
INFO - 2021-08-07 10:27:49 --> Router Class Initialized
INFO - 2021-08-07 10:27:49 --> Output Class Initialized
INFO - 2021-08-07 10:27:49 --> Security Class Initialized
DEBUG - 2021-08-07 10:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:27:49 --> Input Class Initialized
INFO - 2021-08-07 10:27:49 --> Language Class Initialized
INFO - 2021-08-07 10:27:49 --> Loader Class Initialized
INFO - 2021-08-07 10:27:49 --> Helper loaded: url_helper
INFO - 2021-08-07 10:27:49 --> Helper loaded: file_helper
INFO - 2021-08-07 10:27:49 --> Database Driver Class Initialized
DEBUG - 2021-08-07 10:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 10:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 10:27:49 --> Controller Class Initialized
INFO - 2021-08-07 10:27:49 --> Helper loaded: cookie_helper
INFO - 2021-08-07 10:27:49 --> Model "CookieModel" initialized
INFO - 2021-08-07 10:27:49 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 10:27:49 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/team.php
INFO - 2021-08-07 10:27:49 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 10:27:49 --> Final output sent to browser
DEBUG - 2021-08-07 10:27:49 --> Total execution time: 0.0533
INFO - 2021-08-07 10:27:57 --> Config Class Initialized
INFO - 2021-08-07 10:27:57 --> Hooks Class Initialized
INFO - 2021-08-07 10:27:57 --> Config Class Initialized
INFO - 2021-08-07 10:27:57 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:27:57 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:27:57 --> Utf8 Class Initialized
INFO - 2021-08-07 10:27:57 --> URI Class Initialized
DEBUG - 2021-08-07 10:27:57 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:27:57 --> Utf8 Class Initialized
INFO - 2021-08-07 10:27:57 --> Router Class Initialized
INFO - 2021-08-07 10:27:57 --> URI Class Initialized
INFO - 2021-08-07 10:27:57 --> Router Class Initialized
INFO - 2021-08-07 10:27:57 --> Output Class Initialized
INFO - 2021-08-07 10:27:57 --> Security Class Initialized
INFO - 2021-08-07 10:27:57 --> Output Class Initialized
DEBUG - 2021-08-07 10:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:27:57 --> Input Class Initialized
INFO - 2021-08-07 10:27:57 --> Security Class Initialized
DEBUG - 2021-08-07 10:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:27:57 --> Input Class Initialized
INFO - 2021-08-07 10:27:57 --> Language Class Initialized
INFO - 2021-08-07 10:27:57 --> Config Class Initialized
INFO - 2021-08-07 10:27:57 --> Hooks Class Initialized
INFO - 2021-08-07 10:27:57 --> Language Class Initialized
ERROR - 2021-08-07 10:27:57 --> 404 Page Not Found: Assets/js
DEBUG - 2021-08-07 10:27:57 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:27:57 --> Utf8 Class Initialized
ERROR - 2021-08-07 10:27:57 --> 404 Page Not Found: Assets/js
INFO - 2021-08-07 10:27:57 --> URI Class Initialized
INFO - 2021-08-07 10:27:57 --> Router Class Initialized
INFO - 2021-08-07 10:27:57 --> Output Class Initialized
INFO - 2021-08-07 10:27:57 --> Security Class Initialized
DEBUG - 2021-08-07 10:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:27:57 --> Input Class Initialized
INFO - 2021-08-07 10:27:57 --> Language Class Initialized
ERROR - 2021-08-07 10:27:57 --> 404 Page Not Found: Assets/js
INFO - 2021-08-07 10:27:57 --> Config Class Initialized
INFO - 2021-08-07 10:27:57 --> Hooks Class Initialized
INFO - 2021-08-07 10:27:57 --> Config Class Initialized
DEBUG - 2021-08-07 10:27:57 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:27:57 --> Hooks Class Initialized
INFO - 2021-08-07 10:27:57 --> Utf8 Class Initialized
INFO - 2021-08-07 10:27:57 --> URI Class Initialized
INFO - 2021-08-07 10:27:57 --> Router Class Initialized
DEBUG - 2021-08-07 10:27:57 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:27:57 --> Utf8 Class Initialized
INFO - 2021-08-07 10:27:57 --> Output Class Initialized
INFO - 2021-08-07 10:27:57 --> Security Class Initialized
INFO - 2021-08-07 10:27:57 --> URI Class Initialized
DEBUG - 2021-08-07 10:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:27:57 --> Input Class Initialized
INFO - 2021-08-07 10:27:57 --> Router Class Initialized
INFO - 2021-08-07 10:27:57 --> Language Class Initialized
ERROR - 2021-08-07 10:27:57 --> 404 Page Not Found: Assets/css
INFO - 2021-08-07 10:27:57 --> Output Class Initialized
INFO - 2021-08-07 10:27:57 --> Security Class Initialized
DEBUG - 2021-08-07 10:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:27:57 --> Input Class Initialized
INFO - 2021-08-07 10:27:57 --> Language Class Initialized
ERROR - 2021-08-07 10:27:57 --> 404 Page Not Found: Assets/css
INFO - 2021-08-07 10:28:18 --> Config Class Initialized
INFO - 2021-08-07 10:28:18 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:28:18 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:28:18 --> Utf8 Class Initialized
INFO - 2021-08-07 10:28:18 --> URI Class Initialized
INFO - 2021-08-07 10:28:18 --> Router Class Initialized
INFO - 2021-08-07 10:28:18 --> Output Class Initialized
INFO - 2021-08-07 10:28:18 --> Security Class Initialized
DEBUG - 2021-08-07 10:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:28:18 --> Input Class Initialized
INFO - 2021-08-07 10:28:18 --> Language Class Initialized
INFO - 2021-08-07 10:28:18 --> Loader Class Initialized
INFO - 2021-08-07 10:28:18 --> Helper loaded: url_helper
INFO - 2021-08-07 10:28:18 --> Helper loaded: file_helper
INFO - 2021-08-07 10:28:18 --> Database Driver Class Initialized
DEBUG - 2021-08-07 10:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 10:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 10:28:18 --> Controller Class Initialized
INFO - 2021-08-07 10:28:18 --> Helper loaded: cookie_helper
INFO - 2021-08-07 10:28:18 --> Model "CookieModel" initialized
INFO - 2021-08-07 10:28:18 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 10:28:18 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/team.php
INFO - 2021-08-07 10:28:18 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 10:28:18 --> Final output sent to browser
DEBUG - 2021-08-07 10:28:18 --> Total execution time: 0.0532
INFO - 2021-08-07 10:28:18 --> Config Class Initialized
INFO - 2021-08-07 10:28:18 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:28:18 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:28:18 --> Utf8 Class Initialized
INFO - 2021-08-07 10:28:18 --> Config Class Initialized
INFO - 2021-08-07 10:28:18 --> Hooks Class Initialized
INFO - 2021-08-07 10:28:18 --> URI Class Initialized
DEBUG - 2021-08-07 10:28:18 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:28:18 --> Utf8 Class Initialized
INFO - 2021-08-07 10:28:18 --> Router Class Initialized
INFO - 2021-08-07 10:28:18 --> URI Class Initialized
INFO - 2021-08-07 10:28:18 --> Output Class Initialized
INFO - 2021-08-07 10:28:18 --> Router Class Initialized
INFO - 2021-08-07 10:28:18 --> Security Class Initialized
INFO - 2021-08-07 10:28:18 --> Output Class Initialized
DEBUG - 2021-08-07 10:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:28:18 --> Input Class Initialized
INFO - 2021-08-07 10:28:18 --> Security Class Initialized
INFO - 2021-08-07 10:28:18 --> Language Class Initialized
ERROR - 2021-08-07 10:28:18 --> 404 Page Not Found: Assets/css
DEBUG - 2021-08-07 10:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:28:18 --> Input Class Initialized
INFO - 2021-08-07 10:28:18 --> Language Class Initialized
ERROR - 2021-08-07 10:28:18 --> 404 Page Not Found: Assets/css
INFO - 2021-08-07 10:28:19 --> Config Class Initialized
INFO - 2021-08-07 10:28:19 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:28:19 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:28:19 --> Utf8 Class Initialized
INFO - 2021-08-07 10:28:19 --> URI Class Initialized
INFO - 2021-08-07 10:28:19 --> Router Class Initialized
INFO - 2021-08-07 10:28:19 --> Output Class Initialized
INFO - 2021-08-07 10:28:19 --> Config Class Initialized
INFO - 2021-08-07 10:28:19 --> Hooks Class Initialized
INFO - 2021-08-07 10:28:19 --> Security Class Initialized
DEBUG - 2021-08-07 10:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:28:19 --> Input Class Initialized
DEBUG - 2021-08-07 10:28:19 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:28:19 --> Utf8 Class Initialized
INFO - 2021-08-07 10:28:19 --> Language Class Initialized
INFO - 2021-08-07 10:28:19 --> URI Class Initialized
ERROR - 2021-08-07 10:28:19 --> 404 Page Not Found: Assets/js
INFO - 2021-08-07 10:28:19 --> Router Class Initialized
INFO - 2021-08-07 10:28:19 --> Output Class Initialized
INFO - 2021-08-07 10:28:19 --> Security Class Initialized
DEBUG - 2021-08-07 10:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:28:19 --> Input Class Initialized
INFO - 2021-08-07 10:28:19 --> Language Class Initialized
ERROR - 2021-08-07 10:28:19 --> 404 Page Not Found: Assets/js
INFO - 2021-08-07 10:28:19 --> Config Class Initialized
INFO - 2021-08-07 10:28:19 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:28:19 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:28:19 --> Utf8 Class Initialized
INFO - 2021-08-07 10:28:19 --> URI Class Initialized
INFO - 2021-08-07 10:28:19 --> Router Class Initialized
INFO - 2021-08-07 10:28:19 --> Output Class Initialized
INFO - 2021-08-07 10:28:19 --> Security Class Initialized
DEBUG - 2021-08-07 10:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:28:19 --> Input Class Initialized
INFO - 2021-08-07 10:28:19 --> Language Class Initialized
ERROR - 2021-08-07 10:28:19 --> 404 Page Not Found: Assets/js
INFO - 2021-08-07 10:30:49 --> Config Class Initialized
INFO - 2021-08-07 10:30:49 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:30:49 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:30:49 --> Utf8 Class Initialized
INFO - 2021-08-07 10:30:49 --> URI Class Initialized
INFO - 2021-08-07 10:30:50 --> Router Class Initialized
INFO - 2021-08-07 10:30:50 --> Output Class Initialized
INFO - 2021-08-07 10:30:50 --> Security Class Initialized
DEBUG - 2021-08-07 10:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:30:50 --> Input Class Initialized
INFO - 2021-08-07 10:30:50 --> Language Class Initialized
INFO - 2021-08-07 10:30:50 --> Loader Class Initialized
INFO - 2021-08-07 10:30:50 --> Helper loaded: url_helper
INFO - 2021-08-07 10:30:50 --> Helper loaded: file_helper
INFO - 2021-08-07 10:30:50 --> Database Driver Class Initialized
DEBUG - 2021-08-07 10:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 10:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 10:30:50 --> Controller Class Initialized
INFO - 2021-08-07 10:30:50 --> Helper loaded: cookie_helper
INFO - 2021-08-07 10:30:50 --> Model "CookieModel" initialized
INFO - 2021-08-07 10:30:50 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 10:30:50 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/team.php
INFO - 2021-08-07 10:30:50 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 10:30:50 --> Final output sent to browser
DEBUG - 2021-08-07 10:30:50 --> Total execution time: 0.0929
INFO - 2021-08-07 10:31:02 --> Config Class Initialized
INFO - 2021-08-07 10:31:02 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:31:02 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:31:02 --> Utf8 Class Initialized
INFO - 2021-08-07 10:31:02 --> URI Class Initialized
INFO - 2021-08-07 10:31:02 --> Router Class Initialized
INFO - 2021-08-07 10:31:02 --> Output Class Initialized
INFO - 2021-08-07 10:31:02 --> Security Class Initialized
DEBUG - 2021-08-07 10:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:31:02 --> Input Class Initialized
INFO - 2021-08-07 10:31:02 --> Language Class Initialized
INFO - 2021-08-07 10:31:02 --> Loader Class Initialized
INFO - 2021-08-07 10:31:02 --> Helper loaded: url_helper
INFO - 2021-08-07 10:31:02 --> Helper loaded: file_helper
INFO - 2021-08-07 10:31:02 --> Database Driver Class Initialized
DEBUG - 2021-08-07 10:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 10:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 10:31:02 --> Controller Class Initialized
INFO - 2021-08-07 10:31:02 --> Helper loaded: cookie_helper
INFO - 2021-08-07 10:31:02 --> Model "CookieModel" initialized
INFO - 2021-08-07 10:31:02 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 10:31:02 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/success_stories.php
INFO - 2021-08-07 10:31:02 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 10:31:02 --> Final output sent to browser
DEBUG - 2021-08-07 10:31:02 --> Total execution time: 0.0401
INFO - 2021-08-07 10:31:09 --> Config Class Initialized
INFO - 2021-08-07 10:31:09 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:31:09 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:31:09 --> Utf8 Class Initialized
INFO - 2021-08-07 10:31:09 --> URI Class Initialized
INFO - 2021-08-07 10:31:09 --> Router Class Initialized
INFO - 2021-08-07 10:31:09 --> Output Class Initialized
INFO - 2021-08-07 10:31:09 --> Security Class Initialized
DEBUG - 2021-08-07 10:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:31:09 --> Input Class Initialized
INFO - 2021-08-07 10:31:09 --> Language Class Initialized
INFO - 2021-08-07 10:31:09 --> Loader Class Initialized
INFO - 2021-08-07 10:31:09 --> Helper loaded: url_helper
INFO - 2021-08-07 10:31:09 --> Helper loaded: file_helper
INFO - 2021-08-07 10:31:09 --> Database Driver Class Initialized
DEBUG - 2021-08-07 10:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 10:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 10:31:09 --> Controller Class Initialized
INFO - 2021-08-07 10:31:09 --> Helper loaded: cookie_helper
INFO - 2021-08-07 10:31:09 --> Model "CookieModel" initialized
INFO - 2021-08-07 10:31:09 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 10:31:09 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/services.php
INFO - 2021-08-07 10:31:09 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 10:31:09 --> Final output sent to browser
DEBUG - 2021-08-07 10:31:09 --> Total execution time: 0.0411
INFO - 2021-08-07 10:31:10 --> Config Class Initialized
INFO - 2021-08-07 10:31:10 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:31:10 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:31:10 --> Utf8 Class Initialized
INFO - 2021-08-07 10:31:10 --> URI Class Initialized
INFO - 2021-08-07 10:31:10 --> Router Class Initialized
INFO - 2021-08-07 10:31:10 --> Output Class Initialized
INFO - 2021-08-07 10:31:10 --> Security Class Initialized
DEBUG - 2021-08-07 10:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:31:10 --> Input Class Initialized
INFO - 2021-08-07 10:31:10 --> Language Class Initialized
INFO - 2021-08-07 10:31:10 --> Loader Class Initialized
INFO - 2021-08-07 10:31:10 --> Helper loaded: url_helper
INFO - 2021-08-07 10:31:10 --> Helper loaded: file_helper
INFO - 2021-08-07 10:31:10 --> Database Driver Class Initialized
DEBUG - 2021-08-07 10:31:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 10:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 10:31:10 --> Controller Class Initialized
INFO - 2021-08-07 10:31:10 --> Helper loaded: cookie_helper
INFO - 2021-08-07 10:31:10 --> Model "CookieModel" initialized
INFO - 2021-08-07 10:31:10 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 10:31:10 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/services.php
INFO - 2021-08-07 10:31:10 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 10:31:10 --> Final output sent to browser
DEBUG - 2021-08-07 10:31:10 --> Total execution time: 0.0463
INFO - 2021-08-07 10:31:11 --> Config Class Initialized
INFO - 2021-08-07 10:31:11 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:31:11 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:31:11 --> Utf8 Class Initialized
INFO - 2021-08-07 10:31:11 --> URI Class Initialized
INFO - 2021-08-07 10:31:11 --> Router Class Initialized
INFO - 2021-08-07 10:31:11 --> Output Class Initialized
INFO - 2021-08-07 10:31:11 --> Security Class Initialized
DEBUG - 2021-08-07 10:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:31:11 --> Input Class Initialized
INFO - 2021-08-07 10:31:11 --> Language Class Initialized
INFO - 2021-08-07 10:31:11 --> Loader Class Initialized
INFO - 2021-08-07 10:31:11 --> Helper loaded: url_helper
INFO - 2021-08-07 10:31:11 --> Helper loaded: file_helper
INFO - 2021-08-07 10:31:11 --> Database Driver Class Initialized
DEBUG - 2021-08-07 10:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 10:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 10:31:11 --> Controller Class Initialized
INFO - 2021-08-07 10:31:11 --> Helper loaded: cookie_helper
INFO - 2021-08-07 10:31:11 --> Model "CookieModel" initialized
INFO - 2021-08-07 10:31:11 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 10:31:11 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/services.php
INFO - 2021-08-07 10:31:11 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 10:31:11 --> Final output sent to browser
DEBUG - 2021-08-07 10:31:11 --> Total execution time: 0.1273
INFO - 2021-08-07 10:32:53 --> Config Class Initialized
INFO - 2021-08-07 10:32:53 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:32:53 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:32:53 --> Utf8 Class Initialized
INFO - 2021-08-07 10:32:53 --> URI Class Initialized
INFO - 2021-08-07 10:32:53 --> Router Class Initialized
INFO - 2021-08-07 10:32:53 --> Output Class Initialized
INFO - 2021-08-07 10:32:53 --> Security Class Initialized
DEBUG - 2021-08-07 10:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:32:53 --> Input Class Initialized
INFO - 2021-08-07 10:32:53 --> Language Class Initialized
INFO - 2021-08-07 10:32:53 --> Loader Class Initialized
INFO - 2021-08-07 10:32:53 --> Helper loaded: url_helper
INFO - 2021-08-07 10:32:53 --> Helper loaded: file_helper
INFO - 2021-08-07 10:32:53 --> Database Driver Class Initialized
DEBUG - 2021-08-07 10:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 10:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 10:32:53 --> Controller Class Initialized
INFO - 2021-08-07 10:32:53 --> Helper loaded: cookie_helper
INFO - 2021-08-07 10:32:53 --> Model "CookieModel" initialized
INFO - 2021-08-07 10:32:53 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 10:32:53 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/services.php
INFO - 2021-08-07 10:32:53 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 10:32:53 --> Final output sent to browser
DEBUG - 2021-08-07 10:32:53 --> Total execution time: 0.0564
INFO - 2021-08-07 10:34:23 --> Config Class Initialized
INFO - 2021-08-07 10:34:23 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:34:23 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:34:23 --> Utf8 Class Initialized
INFO - 2021-08-07 10:34:23 --> URI Class Initialized
INFO - 2021-08-07 10:34:23 --> Router Class Initialized
INFO - 2021-08-07 10:34:23 --> Output Class Initialized
INFO - 2021-08-07 10:34:23 --> Security Class Initialized
DEBUG - 2021-08-07 10:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:34:23 --> Input Class Initialized
INFO - 2021-08-07 10:34:23 --> Language Class Initialized
INFO - 2021-08-07 10:34:23 --> Loader Class Initialized
INFO - 2021-08-07 10:34:23 --> Helper loaded: url_helper
INFO - 2021-08-07 10:34:23 --> Helper loaded: file_helper
INFO - 2021-08-07 10:34:23 --> Database Driver Class Initialized
DEBUG - 2021-08-07 10:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 10:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 10:34:23 --> Controller Class Initialized
INFO - 2021-08-07 10:34:23 --> Helper loaded: cookie_helper
INFO - 2021-08-07 10:34:23 --> Model "CookieModel" initialized
INFO - 2021-08-07 10:34:23 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 10:34:23 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/services.php
INFO - 2021-08-07 10:34:23 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 10:34:23 --> Final output sent to browser
DEBUG - 2021-08-07 10:34:23 --> Total execution time: 0.0747
INFO - 2021-08-07 10:35:39 --> Config Class Initialized
INFO - 2021-08-07 10:35:39 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:35:39 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:35:39 --> Utf8 Class Initialized
INFO - 2021-08-07 10:35:39 --> URI Class Initialized
INFO - 2021-08-07 10:35:39 --> Router Class Initialized
INFO - 2021-08-07 10:35:39 --> Output Class Initialized
INFO - 2021-08-07 10:35:39 --> Security Class Initialized
DEBUG - 2021-08-07 10:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:35:39 --> Input Class Initialized
INFO - 2021-08-07 10:35:39 --> Language Class Initialized
INFO - 2021-08-07 10:35:39 --> Loader Class Initialized
INFO - 2021-08-07 10:35:39 --> Helper loaded: url_helper
INFO - 2021-08-07 10:35:39 --> Helper loaded: file_helper
INFO - 2021-08-07 10:35:39 --> Database Driver Class Initialized
DEBUG - 2021-08-07 10:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 10:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 10:35:39 --> Controller Class Initialized
INFO - 2021-08-07 10:35:39 --> Helper loaded: cookie_helper
INFO - 2021-08-07 10:35:39 --> Model "CookieModel" initialized
INFO - 2021-08-07 10:35:39 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 10:35:39 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/services.php
INFO - 2021-08-07 10:35:39 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 10:35:39 --> Final output sent to browser
DEBUG - 2021-08-07 10:35:39 --> Total execution time: 0.0409
INFO - 2021-08-07 10:35:48 --> Config Class Initialized
INFO - 2021-08-07 10:35:48 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:35:48 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:35:48 --> Utf8 Class Initialized
INFO - 2021-08-07 10:35:48 --> URI Class Initialized
DEBUG - 2021-08-07 10:35:48 --> No URI present. Default controller set.
INFO - 2021-08-07 10:35:48 --> Router Class Initialized
INFO - 2021-08-07 10:35:48 --> Output Class Initialized
INFO - 2021-08-07 10:35:48 --> Security Class Initialized
DEBUG - 2021-08-07 10:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:35:48 --> Input Class Initialized
INFO - 2021-08-07 10:35:48 --> Language Class Initialized
INFO - 2021-08-07 10:35:48 --> Loader Class Initialized
INFO - 2021-08-07 10:35:48 --> Helper loaded: url_helper
INFO - 2021-08-07 10:35:48 --> Helper loaded: file_helper
INFO - 2021-08-07 10:35:48 --> Database Driver Class Initialized
DEBUG - 2021-08-07 10:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 10:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 10:35:48 --> Controller Class Initialized
INFO - 2021-08-07 10:35:48 --> Helper loaded: cookie_helper
INFO - 2021-08-07 10:35:48 --> Model "CookieModel" initialized
INFO - 2021-08-07 10:35:48 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 10:35:48 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-07 10:35:48 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 10:35:48 --> Final output sent to browser
DEBUG - 2021-08-07 10:35:48 --> Total execution time: 0.0431
INFO - 2021-08-07 10:36:50 --> Config Class Initialized
INFO - 2021-08-07 10:36:50 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:36:50 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:36:50 --> Utf8 Class Initialized
INFO - 2021-08-07 10:36:50 --> URI Class Initialized
DEBUG - 2021-08-07 10:36:50 --> No URI present. Default controller set.
INFO - 2021-08-07 10:36:50 --> Router Class Initialized
INFO - 2021-08-07 10:36:50 --> Output Class Initialized
INFO - 2021-08-07 10:36:50 --> Security Class Initialized
DEBUG - 2021-08-07 10:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:36:50 --> Input Class Initialized
INFO - 2021-08-07 10:36:50 --> Language Class Initialized
INFO - 2021-08-07 10:36:50 --> Loader Class Initialized
INFO - 2021-08-07 10:36:50 --> Helper loaded: url_helper
INFO - 2021-08-07 10:36:50 --> Helper loaded: file_helper
INFO - 2021-08-07 10:36:50 --> Database Driver Class Initialized
DEBUG - 2021-08-07 10:36:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 10:36:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 10:36:50 --> Controller Class Initialized
INFO - 2021-08-07 10:36:50 --> Helper loaded: cookie_helper
INFO - 2021-08-07 10:36:50 --> Model "CookieModel" initialized
INFO - 2021-08-07 10:36:50 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 10:36:50 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-07 10:36:50 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 10:36:50 --> Final output sent to browser
DEBUG - 2021-08-07 10:36:50 --> Total execution time: 0.0623
INFO - 2021-08-07 10:37:19 --> Config Class Initialized
INFO - 2021-08-07 10:37:19 --> Hooks Class Initialized
DEBUG - 2021-08-07 10:37:19 --> UTF-8 Support Enabled
INFO - 2021-08-07 10:37:19 --> Utf8 Class Initialized
INFO - 2021-08-07 10:37:19 --> URI Class Initialized
DEBUG - 2021-08-07 10:37:19 --> No URI present. Default controller set.
INFO - 2021-08-07 10:37:19 --> Router Class Initialized
INFO - 2021-08-07 10:37:19 --> Output Class Initialized
INFO - 2021-08-07 10:37:19 --> Security Class Initialized
DEBUG - 2021-08-07 10:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 10:37:19 --> Input Class Initialized
INFO - 2021-08-07 10:37:19 --> Language Class Initialized
INFO - 2021-08-07 10:37:19 --> Loader Class Initialized
INFO - 2021-08-07 10:37:19 --> Helper loaded: url_helper
INFO - 2021-08-07 10:37:19 --> Helper loaded: file_helper
INFO - 2021-08-07 10:37:19 --> Database Driver Class Initialized
DEBUG - 2021-08-07 10:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 10:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 10:37:19 --> Controller Class Initialized
INFO - 2021-08-07 10:37:19 --> Helper loaded: cookie_helper
INFO - 2021-08-07 10:37:19 --> Model "CookieModel" initialized
INFO - 2021-08-07 10:37:19 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 10:37:19 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-07 10:37:19 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 10:37:19 --> Final output sent to browser
DEBUG - 2021-08-07 10:37:19 --> Total execution time: 0.0403
INFO - 2021-08-07 14:34:20 --> Config Class Initialized
INFO - 2021-08-07 14:34:20 --> Hooks Class Initialized
DEBUG - 2021-08-07 14:34:20 --> UTF-8 Support Enabled
INFO - 2021-08-07 14:34:20 --> Utf8 Class Initialized
INFO - 2021-08-07 14:34:20 --> URI Class Initialized
DEBUG - 2021-08-07 14:34:20 --> No URI present. Default controller set.
INFO - 2021-08-07 14:34:20 --> Router Class Initialized
INFO - 2021-08-07 14:34:20 --> Output Class Initialized
INFO - 2021-08-07 14:34:20 --> Security Class Initialized
DEBUG - 2021-08-07 14:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 14:34:20 --> Input Class Initialized
INFO - 2021-08-07 14:34:20 --> Language Class Initialized
INFO - 2021-08-07 14:34:20 --> Loader Class Initialized
INFO - 2021-08-07 14:34:20 --> Helper loaded: url_helper
INFO - 2021-08-07 14:34:20 --> Helper loaded: file_helper
INFO - 2021-08-07 14:34:20 --> Database Driver Class Initialized
DEBUG - 2021-08-07 14:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 14:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 14:34:20 --> Controller Class Initialized
INFO - 2021-08-07 14:34:20 --> Helper loaded: cookie_helper
INFO - 2021-08-07 14:34:20 --> Model "CookieModel" initialized
INFO - 2021-08-07 14:34:20 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 14:34:20 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-07 14:34:20 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 14:34:20 --> Final output sent to browser
DEBUG - 2021-08-07 14:34:20 --> Total execution time: 0.1653
INFO - 2021-08-07 14:41:51 --> Config Class Initialized
INFO - 2021-08-07 14:41:51 --> Hooks Class Initialized
DEBUG - 2021-08-07 14:41:51 --> UTF-8 Support Enabled
INFO - 2021-08-07 14:41:51 --> Utf8 Class Initialized
INFO - 2021-08-07 14:41:51 --> URI Class Initialized
DEBUG - 2021-08-07 14:41:51 --> No URI present. Default controller set.
INFO - 2021-08-07 14:41:51 --> Router Class Initialized
INFO - 2021-08-07 14:41:51 --> Output Class Initialized
INFO - 2021-08-07 14:41:51 --> Security Class Initialized
DEBUG - 2021-08-07 14:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 14:41:51 --> Input Class Initialized
INFO - 2021-08-07 14:41:51 --> Language Class Initialized
INFO - 2021-08-07 14:41:51 --> Loader Class Initialized
INFO - 2021-08-07 14:41:51 --> Helper loaded: url_helper
INFO - 2021-08-07 14:41:51 --> Helper loaded: file_helper
INFO - 2021-08-07 14:41:51 --> Database Driver Class Initialized
DEBUG - 2021-08-07 14:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 14:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 14:41:51 --> Controller Class Initialized
INFO - 2021-08-07 14:41:51 --> Helper loaded: cookie_helper
INFO - 2021-08-07 14:41:51 --> Model "CookieModel" initialized
INFO - 2021-08-07 14:41:51 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 14:41:51 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-07 14:41:51 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 14:41:51 --> Final output sent to browser
DEBUG - 2021-08-07 14:41:51 --> Total execution time: 0.1405
INFO - 2021-08-07 14:42:07 --> Config Class Initialized
INFO - 2021-08-07 14:42:07 --> Hooks Class Initialized
DEBUG - 2021-08-07 14:42:07 --> UTF-8 Support Enabled
INFO - 2021-08-07 14:42:07 --> Utf8 Class Initialized
INFO - 2021-08-07 14:42:07 --> URI Class Initialized
INFO - 2021-08-07 14:42:07 --> Router Class Initialized
INFO - 2021-08-07 14:42:07 --> Output Class Initialized
INFO - 2021-08-07 14:42:07 --> Security Class Initialized
DEBUG - 2021-08-07 14:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 14:42:07 --> Input Class Initialized
INFO - 2021-08-07 14:42:07 --> Language Class Initialized
INFO - 2021-08-07 14:42:07 --> Loader Class Initialized
INFO - 2021-08-07 14:42:07 --> Helper loaded: url_helper
INFO - 2021-08-07 14:42:07 --> Helper loaded: file_helper
INFO - 2021-08-07 14:42:07 --> Database Driver Class Initialized
DEBUG - 2021-08-07 14:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 14:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 14:42:07 --> Controller Class Initialized
INFO - 2021-08-07 14:42:07 --> Helper loaded: cookie_helper
INFO - 2021-08-07 14:42:07 --> Model "CookieModel" initialized
INFO - 2021-08-07 14:42:07 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 14:42:07 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/about.php
INFO - 2021-08-07 14:42:07 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 14:42:07 --> Final output sent to browser
DEBUG - 2021-08-07 14:42:07 --> Total execution time: 0.0464
INFO - 2021-08-07 14:42:14 --> Config Class Initialized
INFO - 2021-08-07 14:42:14 --> Hooks Class Initialized
DEBUG - 2021-08-07 14:42:14 --> UTF-8 Support Enabled
INFO - 2021-08-07 14:42:14 --> Utf8 Class Initialized
INFO - 2021-08-07 14:42:14 --> URI Class Initialized
INFO - 2021-08-07 14:42:14 --> Router Class Initialized
INFO - 2021-08-07 14:42:14 --> Output Class Initialized
INFO - 2021-08-07 14:42:14 --> Security Class Initialized
DEBUG - 2021-08-07 14:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 14:42:14 --> Input Class Initialized
INFO - 2021-08-07 14:42:14 --> Language Class Initialized
INFO - 2021-08-07 14:42:14 --> Loader Class Initialized
INFO - 2021-08-07 14:42:14 --> Helper loaded: url_helper
INFO - 2021-08-07 14:42:14 --> Helper loaded: file_helper
INFO - 2021-08-07 14:42:14 --> Database Driver Class Initialized
DEBUG - 2021-08-07 14:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 14:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 14:42:14 --> Controller Class Initialized
INFO - 2021-08-07 14:42:14 --> Helper loaded: cookie_helper
INFO - 2021-08-07 14:42:14 --> Model "CookieModel" initialized
INFO - 2021-08-07 14:42:14 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 14:42:14 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/gallery.php
INFO - 2021-08-07 14:42:14 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 14:42:14 --> Final output sent to browser
DEBUG - 2021-08-07 14:42:14 --> Total execution time: 0.0442
INFO - 2021-08-07 14:42:17 --> Config Class Initialized
INFO - 2021-08-07 14:42:17 --> Hooks Class Initialized
DEBUG - 2021-08-07 14:42:17 --> UTF-8 Support Enabled
INFO - 2021-08-07 14:42:17 --> Utf8 Class Initialized
INFO - 2021-08-07 14:42:17 --> URI Class Initialized
INFO - 2021-08-07 14:42:17 --> Router Class Initialized
INFO - 2021-08-07 14:42:17 --> Output Class Initialized
INFO - 2021-08-07 14:42:17 --> Security Class Initialized
DEBUG - 2021-08-07 14:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 14:42:17 --> Input Class Initialized
INFO - 2021-08-07 14:42:17 --> Language Class Initialized
INFO - 2021-08-07 14:42:17 --> Loader Class Initialized
INFO - 2021-08-07 14:42:17 --> Helper loaded: url_helper
INFO - 2021-08-07 14:42:17 --> Helper loaded: file_helper
INFO - 2021-08-07 14:42:17 --> Database Driver Class Initialized
DEBUG - 2021-08-07 14:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 14:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 14:42:17 --> Controller Class Initialized
INFO - 2021-08-07 14:42:17 --> Helper loaded: cookie_helper
INFO - 2021-08-07 14:42:17 --> Model "CookieModel" initialized
INFO - 2021-08-07 14:42:17 --> Model "ContactModel" initialized
INFO - 2021-08-07 14:42:17 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 14:42:17 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/contact.php
INFO - 2021-08-07 14:42:17 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 14:42:17 --> Final output sent to browser
DEBUG - 2021-08-07 14:42:17 --> Total execution time: 0.0632
INFO - 2021-08-07 14:42:20 --> Config Class Initialized
INFO - 2021-08-07 14:42:20 --> Hooks Class Initialized
DEBUG - 2021-08-07 14:42:20 --> UTF-8 Support Enabled
INFO - 2021-08-07 14:42:20 --> Utf8 Class Initialized
INFO - 2021-08-07 14:42:20 --> URI Class Initialized
DEBUG - 2021-08-07 14:42:20 --> No URI present. Default controller set.
INFO - 2021-08-07 14:42:20 --> Router Class Initialized
INFO - 2021-08-07 14:42:20 --> Output Class Initialized
INFO - 2021-08-07 14:42:20 --> Security Class Initialized
DEBUG - 2021-08-07 14:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 14:42:20 --> Input Class Initialized
INFO - 2021-08-07 14:42:20 --> Language Class Initialized
INFO - 2021-08-07 14:42:20 --> Loader Class Initialized
INFO - 2021-08-07 14:42:20 --> Helper loaded: url_helper
INFO - 2021-08-07 14:42:20 --> Helper loaded: file_helper
INFO - 2021-08-07 14:42:20 --> Database Driver Class Initialized
DEBUG - 2021-08-07 14:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 14:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 14:42:20 --> Controller Class Initialized
INFO - 2021-08-07 14:42:20 --> Helper loaded: cookie_helper
INFO - 2021-08-07 14:42:20 --> Model "CookieModel" initialized
INFO - 2021-08-07 14:42:20 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 14:42:20 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-07 14:42:20 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 14:42:20 --> Final output sent to browser
DEBUG - 2021-08-07 14:42:20 --> Total execution time: 0.0423
INFO - 2021-08-07 14:42:31 --> Config Class Initialized
INFO - 2021-08-07 14:42:31 --> Hooks Class Initialized
DEBUG - 2021-08-07 14:42:31 --> UTF-8 Support Enabled
INFO - 2021-08-07 14:42:31 --> Utf8 Class Initialized
INFO - 2021-08-07 14:42:31 --> URI Class Initialized
DEBUG - 2021-08-07 14:42:31 --> No URI present. Default controller set.
INFO - 2021-08-07 14:42:31 --> Router Class Initialized
INFO - 2021-08-07 14:42:31 --> Output Class Initialized
INFO - 2021-08-07 14:42:31 --> Security Class Initialized
DEBUG - 2021-08-07 14:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 14:42:31 --> Input Class Initialized
INFO - 2021-08-07 14:42:31 --> Language Class Initialized
INFO - 2021-08-07 14:42:31 --> Loader Class Initialized
INFO - 2021-08-07 14:42:31 --> Helper loaded: url_helper
INFO - 2021-08-07 14:42:31 --> Helper loaded: file_helper
INFO - 2021-08-07 14:42:31 --> Database Driver Class Initialized
DEBUG - 2021-08-07 14:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 14:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 14:42:31 --> Controller Class Initialized
INFO - 2021-08-07 14:42:31 --> Helper loaded: cookie_helper
INFO - 2021-08-07 14:42:31 --> Model "CookieModel" initialized
INFO - 2021-08-07 14:42:31 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 14:42:31 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-07 14:42:31 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 14:42:31 --> Final output sent to browser
DEBUG - 2021-08-07 14:42:31 --> Total execution time: 0.0485
INFO - 2021-08-07 14:43:08 --> Config Class Initialized
INFO - 2021-08-07 14:43:08 --> Hooks Class Initialized
DEBUG - 2021-08-07 14:43:08 --> UTF-8 Support Enabled
INFO - 2021-08-07 14:43:08 --> Utf8 Class Initialized
INFO - 2021-08-07 14:43:08 --> URI Class Initialized
DEBUG - 2021-08-07 14:43:08 --> No URI present. Default controller set.
INFO - 2021-08-07 14:43:08 --> Router Class Initialized
INFO - 2021-08-07 14:43:08 --> Output Class Initialized
INFO - 2021-08-07 14:43:08 --> Security Class Initialized
DEBUG - 2021-08-07 14:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 14:43:08 --> Input Class Initialized
INFO - 2021-08-07 14:43:08 --> Language Class Initialized
INFO - 2021-08-07 14:43:08 --> Loader Class Initialized
INFO - 2021-08-07 14:43:08 --> Helper loaded: url_helper
INFO - 2021-08-07 14:43:08 --> Helper loaded: file_helper
INFO - 2021-08-07 14:43:08 --> Database Driver Class Initialized
DEBUG - 2021-08-07 14:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 14:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 14:43:08 --> Controller Class Initialized
INFO - 2021-08-07 14:43:08 --> Helper loaded: cookie_helper
INFO - 2021-08-07 14:43:08 --> Model "CookieModel" initialized
INFO - 2021-08-07 14:43:08 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 14:43:08 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-07 14:43:08 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 14:43:08 --> Final output sent to browser
DEBUG - 2021-08-07 14:43:08 --> Total execution time: 0.0457
INFO - 2021-08-07 14:43:16 --> Config Class Initialized
INFO - 2021-08-07 14:43:16 --> Hooks Class Initialized
DEBUG - 2021-08-07 14:43:16 --> UTF-8 Support Enabled
INFO - 2021-08-07 14:43:16 --> Utf8 Class Initialized
INFO - 2021-08-07 14:43:16 --> URI Class Initialized
INFO - 2021-08-07 14:43:16 --> Router Class Initialized
INFO - 2021-08-07 14:43:16 --> Output Class Initialized
INFO - 2021-08-07 14:43:16 --> Security Class Initialized
DEBUG - 2021-08-07 14:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 14:43:16 --> Input Class Initialized
INFO - 2021-08-07 14:43:16 --> Language Class Initialized
INFO - 2021-08-07 14:43:16 --> Loader Class Initialized
INFO - 2021-08-07 14:43:16 --> Helper loaded: url_helper
INFO - 2021-08-07 14:43:16 --> Helper loaded: file_helper
INFO - 2021-08-07 14:43:16 --> Database Driver Class Initialized
DEBUG - 2021-08-07 14:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 14:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 14:43:16 --> Controller Class Initialized
INFO - 2021-08-07 14:43:16 --> Helper loaded: cookie_helper
INFO - 2021-08-07 14:43:16 --> Model "CookieModel" initialized
INFO - 2021-08-07 14:43:16 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 14:43:16 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/success_stories.php
INFO - 2021-08-07 14:43:16 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 14:43:16 --> Final output sent to browser
DEBUG - 2021-08-07 14:43:16 --> Total execution time: 0.0843
INFO - 2021-08-07 14:43:18 --> Config Class Initialized
INFO - 2021-08-07 14:43:18 --> Hooks Class Initialized
DEBUG - 2021-08-07 14:43:18 --> UTF-8 Support Enabled
INFO - 2021-08-07 14:43:18 --> Utf8 Class Initialized
INFO - 2021-08-07 14:43:18 --> URI Class Initialized
INFO - 2021-08-07 14:43:18 --> Router Class Initialized
INFO - 2021-08-07 14:43:18 --> Output Class Initialized
INFO - 2021-08-07 14:43:18 --> Security Class Initialized
DEBUG - 2021-08-07 14:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 14:43:18 --> Input Class Initialized
INFO - 2021-08-07 14:43:18 --> Language Class Initialized
INFO - 2021-08-07 14:43:18 --> Loader Class Initialized
INFO - 2021-08-07 14:43:18 --> Helper loaded: url_helper
INFO - 2021-08-07 14:43:18 --> Helper loaded: file_helper
INFO - 2021-08-07 14:43:18 --> Database Driver Class Initialized
DEBUG - 2021-08-07 14:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 14:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 14:43:18 --> Controller Class Initialized
INFO - 2021-08-07 14:43:18 --> Helper loaded: cookie_helper
INFO - 2021-08-07 14:43:18 --> Model "CookieModel" initialized
INFO - 2021-08-07 14:43:18 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 14:43:18 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/about.php
INFO - 2021-08-07 14:43:18 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 14:43:18 --> Final output sent to browser
DEBUG - 2021-08-07 14:43:18 --> Total execution time: 0.0368
INFO - 2021-08-07 14:43:20 --> Config Class Initialized
INFO - 2021-08-07 14:43:20 --> Hooks Class Initialized
DEBUG - 2021-08-07 14:43:20 --> UTF-8 Support Enabled
INFO - 2021-08-07 14:43:20 --> Utf8 Class Initialized
INFO - 2021-08-07 14:43:20 --> URI Class Initialized
INFO - 2021-08-07 14:43:20 --> Router Class Initialized
INFO - 2021-08-07 14:43:20 --> Output Class Initialized
INFO - 2021-08-07 14:43:20 --> Security Class Initialized
DEBUG - 2021-08-07 14:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 14:43:20 --> Input Class Initialized
INFO - 2021-08-07 14:43:20 --> Language Class Initialized
INFO - 2021-08-07 14:43:20 --> Loader Class Initialized
INFO - 2021-08-07 14:43:20 --> Helper loaded: url_helper
INFO - 2021-08-07 14:43:20 --> Helper loaded: file_helper
INFO - 2021-08-07 14:43:20 --> Database Driver Class Initialized
DEBUG - 2021-08-07 14:43:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 14:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 14:43:20 --> Controller Class Initialized
INFO - 2021-08-07 14:43:20 --> Helper loaded: cookie_helper
INFO - 2021-08-07 14:43:20 --> Model "CookieModel" initialized
INFO - 2021-08-07 14:43:20 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 14:43:20 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/team.php
INFO - 2021-08-07 14:43:20 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 14:43:20 --> Final output sent to browser
DEBUG - 2021-08-07 14:43:20 --> Total execution time: 0.0429
INFO - 2021-08-07 14:43:41 --> Config Class Initialized
INFO - 2021-08-07 14:43:41 --> Hooks Class Initialized
DEBUG - 2021-08-07 14:43:41 --> UTF-8 Support Enabled
INFO - 2021-08-07 14:43:41 --> Utf8 Class Initialized
INFO - 2021-08-07 14:43:41 --> URI Class Initialized
DEBUG - 2021-08-07 14:43:41 --> No URI present. Default controller set.
INFO - 2021-08-07 14:43:41 --> Router Class Initialized
INFO - 2021-08-07 14:43:41 --> Output Class Initialized
INFO - 2021-08-07 14:43:41 --> Security Class Initialized
DEBUG - 2021-08-07 14:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 14:43:41 --> Input Class Initialized
INFO - 2021-08-07 14:43:41 --> Language Class Initialized
INFO - 2021-08-07 14:43:41 --> Loader Class Initialized
INFO - 2021-08-07 14:43:41 --> Helper loaded: url_helper
INFO - 2021-08-07 14:43:41 --> Helper loaded: file_helper
INFO - 2021-08-07 14:43:41 --> Database Driver Class Initialized
DEBUG - 2021-08-07 14:43:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 14:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 14:43:41 --> Controller Class Initialized
INFO - 2021-08-07 14:43:41 --> Helper loaded: cookie_helper
INFO - 2021-08-07 14:43:41 --> Model "CookieModel" initialized
INFO - 2021-08-07 14:43:41 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 14:43:41 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-07 14:43:41 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 14:43:41 --> Final output sent to browser
DEBUG - 2021-08-07 14:43:41 --> Total execution time: 0.0397
INFO - 2021-08-07 14:44:04 --> Config Class Initialized
INFO - 2021-08-07 14:44:04 --> Hooks Class Initialized
DEBUG - 2021-08-07 14:44:04 --> UTF-8 Support Enabled
INFO - 2021-08-07 14:44:04 --> Utf8 Class Initialized
INFO - 2021-08-07 14:44:04 --> URI Class Initialized
INFO - 2021-08-07 14:44:04 --> Router Class Initialized
INFO - 2021-08-07 14:44:04 --> Output Class Initialized
INFO - 2021-08-07 14:44:04 --> Security Class Initialized
DEBUG - 2021-08-07 14:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 14:44:04 --> Input Class Initialized
INFO - 2021-08-07 14:44:04 --> Language Class Initialized
INFO - 2021-08-07 14:44:04 --> Loader Class Initialized
INFO - 2021-08-07 14:44:04 --> Helper loaded: url_helper
INFO - 2021-08-07 14:44:04 --> Helper loaded: file_helper
INFO - 2021-08-07 14:44:04 --> Database Driver Class Initialized
DEBUG - 2021-08-07 14:44:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 14:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 14:44:04 --> Controller Class Initialized
INFO - 2021-08-07 14:44:04 --> Helper loaded: cookie_helper
INFO - 2021-08-07 14:44:04 --> Model "CookieModel" initialized
INFO - 2021-08-07 14:44:04 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 14:44:04 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-07 14:44:04 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 14:44:04 --> Final output sent to browser
DEBUG - 2021-08-07 14:44:04 --> Total execution time: 0.0532
INFO - 2021-08-07 14:45:03 --> Config Class Initialized
INFO - 2021-08-07 14:45:03 --> Hooks Class Initialized
DEBUG - 2021-08-07 14:45:03 --> UTF-8 Support Enabled
INFO - 2021-08-07 14:45:03 --> Utf8 Class Initialized
INFO - 2021-08-07 14:45:03 --> URI Class Initialized
INFO - 2021-08-07 14:45:03 --> Router Class Initialized
INFO - 2021-08-07 14:45:03 --> Output Class Initialized
INFO - 2021-08-07 14:45:03 --> Security Class Initialized
DEBUG - 2021-08-07 14:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 14:45:03 --> Input Class Initialized
INFO - 2021-08-07 14:45:03 --> Language Class Initialized
INFO - 2021-08-07 14:45:03 --> Loader Class Initialized
INFO - 2021-08-07 14:45:03 --> Helper loaded: url_helper
INFO - 2021-08-07 14:45:03 --> Helper loaded: file_helper
INFO - 2021-08-07 14:45:03 --> Database Driver Class Initialized
DEBUG - 2021-08-07 14:45:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 14:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 14:45:03 --> Controller Class Initialized
INFO - 2021-08-07 14:45:03 --> Helper loaded: cookie_helper
INFO - 2021-08-07 14:45:03 --> Model "CookieModel" initialized
INFO - 2021-08-07 14:45:03 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 14:45:03 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-07 14:45:03 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 14:45:03 --> Final output sent to browser
DEBUG - 2021-08-07 14:45:03 --> Total execution time: 0.0483
INFO - 2021-08-07 14:45:19 --> Config Class Initialized
INFO - 2021-08-07 14:45:19 --> Hooks Class Initialized
DEBUG - 2021-08-07 14:45:19 --> UTF-8 Support Enabled
INFO - 2021-08-07 14:45:19 --> Utf8 Class Initialized
INFO - 2021-08-07 14:45:19 --> URI Class Initialized
INFO - 2021-08-07 14:45:19 --> Router Class Initialized
INFO - 2021-08-07 14:45:19 --> Output Class Initialized
INFO - 2021-08-07 14:45:19 --> Security Class Initialized
DEBUG - 2021-08-07 14:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 14:45:19 --> Input Class Initialized
INFO - 2021-08-07 14:45:19 --> Language Class Initialized
INFO - 2021-08-07 14:45:19 --> Loader Class Initialized
INFO - 2021-08-07 14:45:19 --> Helper loaded: url_helper
INFO - 2021-08-07 14:45:19 --> Helper loaded: file_helper
INFO - 2021-08-07 14:45:19 --> Database Driver Class Initialized
DEBUG - 2021-08-07 14:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 14:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 14:45:19 --> Controller Class Initialized
INFO - 2021-08-07 14:45:19 --> Helper loaded: cookie_helper
INFO - 2021-08-07 14:45:19 --> Model "CookieModel" initialized
INFO - 2021-08-07 14:45:19 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 14:45:19 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-07 14:45:19 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 14:45:19 --> Final output sent to browser
DEBUG - 2021-08-07 14:45:19 --> Total execution time: 0.0560
INFO - 2021-08-07 14:45:24 --> Config Class Initialized
INFO - 2021-08-07 14:45:24 --> Hooks Class Initialized
DEBUG - 2021-08-07 14:45:24 --> UTF-8 Support Enabled
INFO - 2021-08-07 14:45:24 --> Utf8 Class Initialized
INFO - 2021-08-07 14:45:24 --> URI Class Initialized
INFO - 2021-08-07 14:45:24 --> Router Class Initialized
INFO - 2021-08-07 14:45:24 --> Output Class Initialized
INFO - 2021-08-07 14:45:24 --> Security Class Initialized
DEBUG - 2021-08-07 14:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 14:45:24 --> Input Class Initialized
INFO - 2021-08-07 14:45:24 --> Language Class Initialized
INFO - 2021-08-07 14:45:24 --> Loader Class Initialized
INFO - 2021-08-07 14:45:24 --> Helper loaded: url_helper
INFO - 2021-08-07 14:45:24 --> Helper loaded: file_helper
INFO - 2021-08-07 14:45:24 --> Database Driver Class Initialized
DEBUG - 2021-08-07 14:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 14:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 14:45:24 --> Controller Class Initialized
INFO - 2021-08-07 14:45:24 --> Helper loaded: cookie_helper
INFO - 2021-08-07 14:45:24 --> Model "CookieModel" initialized
INFO - 2021-08-07 14:45:24 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 14:45:24 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/about.php
INFO - 2021-08-07 14:45:24 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 14:45:24 --> Final output sent to browser
DEBUG - 2021-08-07 14:45:24 --> Total execution time: 0.0377
INFO - 2021-08-07 14:45:26 --> Config Class Initialized
INFO - 2021-08-07 14:45:26 --> Hooks Class Initialized
DEBUG - 2021-08-07 14:45:26 --> UTF-8 Support Enabled
INFO - 2021-08-07 14:45:26 --> Utf8 Class Initialized
INFO - 2021-08-07 14:45:26 --> URI Class Initialized
INFO - 2021-08-07 14:45:26 --> Router Class Initialized
INFO - 2021-08-07 14:45:26 --> Output Class Initialized
INFO - 2021-08-07 14:45:26 --> Security Class Initialized
DEBUG - 2021-08-07 14:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 14:45:26 --> Input Class Initialized
INFO - 2021-08-07 14:45:26 --> Language Class Initialized
INFO - 2021-08-07 14:45:26 --> Loader Class Initialized
INFO - 2021-08-07 14:45:26 --> Helper loaded: url_helper
INFO - 2021-08-07 14:45:26 --> Helper loaded: file_helper
INFO - 2021-08-07 14:45:26 --> Database Driver Class Initialized
DEBUG - 2021-08-07 14:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 14:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 14:45:26 --> Controller Class Initialized
INFO - 2021-08-07 14:45:26 --> Helper loaded: cookie_helper
INFO - 2021-08-07 14:45:26 --> Model "CookieModel" initialized
INFO - 2021-08-07 14:45:26 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 14:45:26 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/team.php
INFO - 2021-08-07 14:45:26 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 14:45:26 --> Final output sent to browser
DEBUG - 2021-08-07 14:45:26 --> Total execution time: 0.0447
INFO - 2021-08-07 14:45:33 --> Config Class Initialized
INFO - 2021-08-07 14:45:33 --> Hooks Class Initialized
DEBUG - 2021-08-07 14:45:33 --> UTF-8 Support Enabled
INFO - 2021-08-07 14:45:33 --> Utf8 Class Initialized
INFO - 2021-08-07 14:45:33 --> URI Class Initialized
INFO - 2021-08-07 14:45:34 --> Router Class Initialized
INFO - 2021-08-07 14:45:34 --> Output Class Initialized
INFO - 2021-08-07 14:45:34 --> Security Class Initialized
DEBUG - 2021-08-07 14:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 14:45:34 --> Input Class Initialized
INFO - 2021-08-07 14:45:34 --> Language Class Initialized
INFO - 2021-08-07 14:45:34 --> Loader Class Initialized
INFO - 2021-08-07 14:45:34 --> Helper loaded: url_helper
INFO - 2021-08-07 14:45:34 --> Helper loaded: file_helper
INFO - 2021-08-07 14:45:34 --> Database Driver Class Initialized
DEBUG - 2021-08-07 14:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 14:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 14:45:34 --> Controller Class Initialized
INFO - 2021-08-07 14:45:34 --> Helper loaded: cookie_helper
INFO - 2021-08-07 14:45:34 --> Model "CookieModel" initialized
INFO - 2021-08-07 14:45:34 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 14:45:34 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/services.php
INFO - 2021-08-07 14:45:34 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 14:45:34 --> Final output sent to browser
DEBUG - 2021-08-07 14:45:34 --> Total execution time: 0.0465
INFO - 2021-08-07 14:45:36 --> Config Class Initialized
INFO - 2021-08-07 14:45:36 --> Hooks Class Initialized
DEBUG - 2021-08-07 14:45:36 --> UTF-8 Support Enabled
INFO - 2021-08-07 14:45:36 --> Utf8 Class Initialized
INFO - 2021-08-07 14:45:36 --> URI Class Initialized
INFO - 2021-08-07 14:45:36 --> Router Class Initialized
INFO - 2021-08-07 14:45:36 --> Output Class Initialized
INFO - 2021-08-07 14:45:36 --> Security Class Initialized
DEBUG - 2021-08-07 14:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 14:45:36 --> Input Class Initialized
INFO - 2021-08-07 14:45:36 --> Language Class Initialized
INFO - 2021-08-07 14:45:36 --> Loader Class Initialized
INFO - 2021-08-07 14:45:36 --> Helper loaded: url_helper
INFO - 2021-08-07 14:45:36 --> Helper loaded: file_helper
INFO - 2021-08-07 14:45:36 --> Database Driver Class Initialized
DEBUG - 2021-08-07 14:45:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 14:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 14:45:36 --> Controller Class Initialized
INFO - 2021-08-07 14:45:36 --> Helper loaded: cookie_helper
INFO - 2021-08-07 14:45:36 --> Model "CookieModel" initialized
INFO - 2021-08-07 14:45:36 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 14:45:36 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/services.php
INFO - 2021-08-07 14:45:36 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 14:45:36 --> Final output sent to browser
DEBUG - 2021-08-07 14:45:36 --> Total execution time: 0.0397
INFO - 2021-08-07 14:45:52 --> Config Class Initialized
INFO - 2021-08-07 14:45:52 --> Hooks Class Initialized
DEBUG - 2021-08-07 14:45:52 --> UTF-8 Support Enabled
INFO - 2021-08-07 14:45:52 --> Utf8 Class Initialized
INFO - 2021-08-07 14:45:52 --> URI Class Initialized
INFO - 2021-08-07 14:45:52 --> Router Class Initialized
INFO - 2021-08-07 14:45:52 --> Output Class Initialized
INFO - 2021-08-07 14:45:52 --> Security Class Initialized
DEBUG - 2021-08-07 14:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 14:45:52 --> Input Class Initialized
INFO - 2021-08-07 14:45:52 --> Language Class Initialized
INFO - 2021-08-07 14:45:52 --> Loader Class Initialized
INFO - 2021-08-07 14:45:52 --> Helper loaded: url_helper
INFO - 2021-08-07 14:45:52 --> Helper loaded: file_helper
INFO - 2021-08-07 14:45:52 --> Database Driver Class Initialized
DEBUG - 2021-08-07 14:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 14:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 14:45:52 --> Controller Class Initialized
INFO - 2021-08-07 14:45:52 --> Helper loaded: cookie_helper
INFO - 2021-08-07 14:45:52 --> Model "CookieModel" initialized
INFO - 2021-08-07 14:45:52 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 14:45:52 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/services.php
INFO - 2021-08-07 14:45:52 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 14:45:52 --> Final output sent to browser
DEBUG - 2021-08-07 14:45:52 --> Total execution time: 0.0397
INFO - 2021-08-07 14:46:00 --> Config Class Initialized
INFO - 2021-08-07 14:46:00 --> Hooks Class Initialized
DEBUG - 2021-08-07 14:46:00 --> UTF-8 Support Enabled
INFO - 2021-08-07 14:46:00 --> Utf8 Class Initialized
INFO - 2021-08-07 14:46:00 --> URI Class Initialized
DEBUG - 2021-08-07 14:46:00 --> No URI present. Default controller set.
INFO - 2021-08-07 14:46:00 --> Router Class Initialized
INFO - 2021-08-07 14:46:00 --> Output Class Initialized
INFO - 2021-08-07 14:46:00 --> Security Class Initialized
DEBUG - 2021-08-07 14:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 14:46:00 --> Input Class Initialized
INFO - 2021-08-07 14:46:00 --> Language Class Initialized
INFO - 2021-08-07 14:46:00 --> Loader Class Initialized
INFO - 2021-08-07 14:46:00 --> Helper loaded: url_helper
INFO - 2021-08-07 14:46:00 --> Helper loaded: file_helper
INFO - 2021-08-07 14:46:00 --> Database Driver Class Initialized
DEBUG - 2021-08-07 14:46:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 14:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 14:46:00 --> Controller Class Initialized
INFO - 2021-08-07 14:46:00 --> Helper loaded: cookie_helper
INFO - 2021-08-07 14:46:00 --> Model "CookieModel" initialized
INFO - 2021-08-07 14:46:00 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 14:46:00 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-07 14:46:00 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 14:46:00 --> Final output sent to browser
DEBUG - 2021-08-07 14:46:00 --> Total execution time: 0.0419
INFO - 2021-08-07 14:49:29 --> Config Class Initialized
INFO - 2021-08-07 14:49:29 --> Hooks Class Initialized
DEBUG - 2021-08-07 14:49:29 --> UTF-8 Support Enabled
INFO - 2021-08-07 14:49:29 --> Utf8 Class Initialized
INFO - 2021-08-07 14:49:29 --> URI Class Initialized
DEBUG - 2021-08-07 14:49:29 --> No URI present. Default controller set.
INFO - 2021-08-07 14:49:29 --> Router Class Initialized
INFO - 2021-08-07 14:49:29 --> Output Class Initialized
INFO - 2021-08-07 14:49:29 --> Security Class Initialized
DEBUG - 2021-08-07 14:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 14:49:29 --> Input Class Initialized
INFO - 2021-08-07 14:49:29 --> Language Class Initialized
INFO - 2021-08-07 14:49:29 --> Loader Class Initialized
INFO - 2021-08-07 14:49:29 --> Helper loaded: url_helper
INFO - 2021-08-07 14:49:29 --> Helper loaded: file_helper
INFO - 2021-08-07 14:49:29 --> Database Driver Class Initialized
DEBUG - 2021-08-07 14:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 14:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 14:49:29 --> Controller Class Initialized
INFO - 2021-08-07 14:49:29 --> Helper loaded: cookie_helper
INFO - 2021-08-07 14:49:29 --> Model "CookieModel" initialized
INFO - 2021-08-07 14:49:29 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 14:49:29 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-07 14:49:29 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 14:49:29 --> Final output sent to browser
DEBUG - 2021-08-07 14:49:29 --> Total execution time: 0.0805
INFO - 2021-08-07 14:50:37 --> Config Class Initialized
INFO - 2021-08-07 14:50:37 --> Hooks Class Initialized
DEBUG - 2021-08-07 14:50:37 --> UTF-8 Support Enabled
INFO - 2021-08-07 14:50:37 --> Utf8 Class Initialized
INFO - 2021-08-07 14:50:37 --> URI Class Initialized
DEBUG - 2021-08-07 14:50:37 --> No URI present. Default controller set.
INFO - 2021-08-07 14:50:37 --> Router Class Initialized
INFO - 2021-08-07 14:50:37 --> Output Class Initialized
INFO - 2021-08-07 14:50:37 --> Security Class Initialized
DEBUG - 2021-08-07 14:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 14:50:37 --> Input Class Initialized
INFO - 2021-08-07 14:50:37 --> Language Class Initialized
INFO - 2021-08-07 14:50:37 --> Loader Class Initialized
INFO - 2021-08-07 14:50:37 --> Helper loaded: url_helper
INFO - 2021-08-07 14:50:37 --> Helper loaded: file_helper
INFO - 2021-08-07 14:50:37 --> Database Driver Class Initialized
DEBUG - 2021-08-07 14:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 14:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 14:50:37 --> Controller Class Initialized
INFO - 2021-08-07 14:50:37 --> Helper loaded: cookie_helper
INFO - 2021-08-07 14:50:37 --> Model "CookieModel" initialized
INFO - 2021-08-07 14:50:37 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-07 14:50:37 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-07 14:50:37 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-07 14:50:37 --> Final output sent to browser
DEBUG - 2021-08-07 14:50:37 --> Total execution time: 0.0422
INFO - 2021-08-07 14:59:59 --> Config Class Initialized
INFO - 2021-08-07 14:59:59 --> Hooks Class Initialized
DEBUG - 2021-08-07 14:59:59 --> UTF-8 Support Enabled
INFO - 2021-08-07 14:59:59 --> Utf8 Class Initialized
INFO - 2021-08-07 14:59:59 --> URI Class Initialized
DEBUG - 2021-08-07 14:59:59 --> No URI present. Default controller set.
INFO - 2021-08-07 14:59:59 --> Router Class Initialized
INFO - 2021-08-07 14:59:59 --> Output Class Initialized
INFO - 2021-08-07 14:59:59 --> Security Class Initialized
DEBUG - 2021-08-07 14:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 14:59:59 --> Input Class Initialized
INFO - 2021-08-07 14:59:59 --> Language Class Initialized
INFO - 2021-08-07 14:59:59 --> Loader Class Initialized
INFO - 2021-08-07 14:59:59 --> Helper loaded: url_helper
INFO - 2021-08-07 14:59:59 --> Helper loaded: file_helper
INFO - 2021-08-07 14:59:59 --> Database Driver Class Initialized
DEBUG - 2021-08-07 14:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 14:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 14:59:59 --> Controller Class Initialized
INFO - 2021-08-07 14:59:59 --> Helper loaded: cookie_helper
INFO - 2021-08-07 14:59:59 --> Model "CookieModel" initialized
INFO - 2021-08-07 14:59:59 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 14:59:59 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/index.php
INFO - 2021-08-07 14:59:59 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 14:59:59 --> Final output sent to browser
DEBUG - 2021-08-07 14:59:59 --> Total execution time: 0.0197
INFO - 2021-08-07 15:00:08 --> Config Class Initialized
INFO - 2021-08-07 15:00:08 --> Hooks Class Initialized
DEBUG - 2021-08-07 15:00:08 --> UTF-8 Support Enabled
INFO - 2021-08-07 15:00:08 --> Utf8 Class Initialized
INFO - 2021-08-07 15:00:08 --> URI Class Initialized
DEBUG - 2021-08-07 15:00:08 --> No URI present. Default controller set.
INFO - 2021-08-07 15:00:08 --> Router Class Initialized
INFO - 2021-08-07 15:00:08 --> Output Class Initialized
INFO - 2021-08-07 15:00:08 --> Security Class Initialized
DEBUG - 2021-08-07 15:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 15:00:08 --> Input Class Initialized
INFO - 2021-08-07 15:00:08 --> Language Class Initialized
INFO - 2021-08-07 15:00:08 --> Loader Class Initialized
INFO - 2021-08-07 15:00:08 --> Helper loaded: url_helper
INFO - 2021-08-07 15:00:08 --> Helper loaded: file_helper
INFO - 2021-08-07 15:00:08 --> Database Driver Class Initialized
DEBUG - 2021-08-07 15:00:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 15:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 15:00:08 --> Controller Class Initialized
INFO - 2021-08-07 15:00:08 --> Helper loaded: cookie_helper
INFO - 2021-08-07 15:00:08 --> Model "CookieModel" initialized
INFO - 2021-08-07 15:00:08 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 15:00:08 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/index.php
INFO - 2021-08-07 15:00:08 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 15:00:08 --> Final output sent to browser
DEBUG - 2021-08-07 15:00:08 --> Total execution time: 0.0232
INFO - 2021-08-07 15:00:20 --> Config Class Initialized
INFO - 2021-08-07 15:00:20 --> Hooks Class Initialized
DEBUG - 2021-08-07 15:00:20 --> UTF-8 Support Enabled
INFO - 2021-08-07 15:00:20 --> Utf8 Class Initialized
INFO - 2021-08-07 15:00:20 --> URI Class Initialized
INFO - 2021-08-07 15:00:20 --> Router Class Initialized
INFO - 2021-08-07 15:00:20 --> Output Class Initialized
INFO - 2021-08-07 15:00:20 --> Security Class Initialized
DEBUG - 2021-08-07 15:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 15:00:20 --> Input Class Initialized
INFO - 2021-08-07 15:00:20 --> Language Class Initialized
INFO - 2021-08-07 15:00:20 --> Loader Class Initialized
INFO - 2021-08-07 15:00:20 --> Helper loaded: url_helper
INFO - 2021-08-07 15:00:20 --> Helper loaded: file_helper
INFO - 2021-08-07 15:00:20 --> Database Driver Class Initialized
DEBUG - 2021-08-07 15:00:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 15:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 15:00:20 --> Controller Class Initialized
INFO - 2021-08-07 15:00:20 --> Helper loaded: cookie_helper
INFO - 2021-08-07 15:00:20 --> Model "CookieModel" initialized
INFO - 2021-08-07 15:00:20 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 15:00:20 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/services.php
INFO - 2021-08-07 15:00:20 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 15:00:20 --> Final output sent to browser
DEBUG - 2021-08-07 15:00:20 --> Total execution time: 0.0184
INFO - 2021-08-07 15:00:24 --> Config Class Initialized
INFO - 2021-08-07 15:00:24 --> Hooks Class Initialized
DEBUG - 2021-08-07 15:00:24 --> UTF-8 Support Enabled
INFO - 2021-08-07 15:00:24 --> Utf8 Class Initialized
INFO - 2021-08-07 15:00:24 --> URI Class Initialized
INFO - 2021-08-07 15:00:24 --> Router Class Initialized
INFO - 2021-08-07 15:00:24 --> Output Class Initialized
INFO - 2021-08-07 15:00:24 --> Security Class Initialized
DEBUG - 2021-08-07 15:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 15:00:24 --> Input Class Initialized
INFO - 2021-08-07 15:00:24 --> Language Class Initialized
INFO - 2021-08-07 15:00:24 --> Loader Class Initialized
INFO - 2021-08-07 15:00:24 --> Helper loaded: url_helper
INFO - 2021-08-07 15:00:24 --> Helper loaded: file_helper
INFO - 2021-08-07 15:00:24 --> Database Driver Class Initialized
DEBUG - 2021-08-07 15:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 15:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 15:00:24 --> Controller Class Initialized
INFO - 2021-08-07 15:00:24 --> Helper loaded: cookie_helper
INFO - 2021-08-07 15:00:24 --> Model "CookieModel" initialized
INFO - 2021-08-07 15:00:24 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 15:00:24 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/success_stories.php
INFO - 2021-08-07 15:00:24 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 15:00:24 --> Final output sent to browser
DEBUG - 2021-08-07 15:00:24 --> Total execution time: 0.0187
INFO - 2021-08-07 15:00:25 --> Config Class Initialized
INFO - 2021-08-07 15:00:25 --> Hooks Class Initialized
DEBUG - 2021-08-07 15:00:25 --> UTF-8 Support Enabled
INFO - 2021-08-07 15:00:25 --> Utf8 Class Initialized
INFO - 2021-08-07 15:00:25 --> URI Class Initialized
INFO - 2021-08-07 15:00:25 --> Router Class Initialized
INFO - 2021-08-07 15:00:25 --> Output Class Initialized
INFO - 2021-08-07 15:00:25 --> Security Class Initialized
DEBUG - 2021-08-07 15:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 15:00:25 --> Input Class Initialized
INFO - 2021-08-07 15:00:25 --> Language Class Initialized
INFO - 2021-08-07 15:00:25 --> Loader Class Initialized
INFO - 2021-08-07 15:00:25 --> Helper loaded: url_helper
INFO - 2021-08-07 15:00:25 --> Helper loaded: file_helper
INFO - 2021-08-07 15:00:25 --> Database Driver Class Initialized
DEBUG - 2021-08-07 15:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 15:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 15:00:25 --> Controller Class Initialized
INFO - 2021-08-07 15:00:25 --> Helper loaded: cookie_helper
INFO - 2021-08-07 15:00:25 --> Model "CookieModel" initialized
INFO - 2021-08-07 15:00:25 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 15:00:25 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/about.php
INFO - 2021-08-07 15:00:25 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 15:00:25 --> Final output sent to browser
DEBUG - 2021-08-07 15:00:25 --> Total execution time: 0.0188
INFO - 2021-08-07 15:00:30 --> Config Class Initialized
INFO - 2021-08-07 15:00:30 --> Hooks Class Initialized
DEBUG - 2021-08-07 15:00:30 --> UTF-8 Support Enabled
INFO - 2021-08-07 15:00:30 --> Utf8 Class Initialized
INFO - 2021-08-07 15:00:30 --> URI Class Initialized
DEBUG - 2021-08-07 15:00:30 --> No URI present. Default controller set.
INFO - 2021-08-07 15:00:30 --> Router Class Initialized
INFO - 2021-08-07 15:00:30 --> Output Class Initialized
INFO - 2021-08-07 15:00:30 --> Security Class Initialized
DEBUG - 2021-08-07 15:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 15:00:30 --> Input Class Initialized
INFO - 2021-08-07 15:00:30 --> Language Class Initialized
INFO - 2021-08-07 15:00:30 --> Loader Class Initialized
INFO - 2021-08-07 15:00:30 --> Helper loaded: url_helper
INFO - 2021-08-07 15:00:30 --> Helper loaded: file_helper
INFO - 2021-08-07 15:00:30 --> Database Driver Class Initialized
DEBUG - 2021-08-07 15:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 15:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 15:00:30 --> Controller Class Initialized
INFO - 2021-08-07 15:00:30 --> Helper loaded: cookie_helper
INFO - 2021-08-07 15:00:30 --> Model "CookieModel" initialized
INFO - 2021-08-07 15:00:30 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 15:00:30 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/index.php
INFO - 2021-08-07 15:00:30 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 15:00:30 --> Final output sent to browser
DEBUG - 2021-08-07 15:00:30 --> Total execution time: 0.0181
INFO - 2021-08-07 15:00:31 --> Config Class Initialized
INFO - 2021-08-07 15:00:31 --> Hooks Class Initialized
DEBUG - 2021-08-07 15:00:31 --> UTF-8 Support Enabled
INFO - 2021-08-07 15:00:31 --> Utf8 Class Initialized
INFO - 2021-08-07 15:00:31 --> URI Class Initialized
DEBUG - 2021-08-07 15:00:31 --> No URI present. Default controller set.
INFO - 2021-08-07 15:00:31 --> Router Class Initialized
INFO - 2021-08-07 15:00:31 --> Output Class Initialized
INFO - 2021-08-07 15:00:31 --> Security Class Initialized
DEBUG - 2021-08-07 15:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 15:00:31 --> Input Class Initialized
INFO - 2021-08-07 15:00:31 --> Language Class Initialized
INFO - 2021-08-07 15:00:31 --> Loader Class Initialized
INFO - 2021-08-07 15:00:31 --> Helper loaded: url_helper
INFO - 2021-08-07 15:00:31 --> Helper loaded: file_helper
INFO - 2021-08-07 15:00:31 --> Database Driver Class Initialized
DEBUG - 2021-08-07 15:00:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 15:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 15:00:31 --> Controller Class Initialized
INFO - 2021-08-07 15:00:31 --> Helper loaded: cookie_helper
INFO - 2021-08-07 15:00:31 --> Model "CookieModel" initialized
INFO - 2021-08-07 15:00:31 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 15:00:31 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/index.php
INFO - 2021-08-07 15:00:31 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 15:00:31 --> Final output sent to browser
DEBUG - 2021-08-07 15:00:31 --> Total execution time: 0.0183
INFO - 2021-08-07 15:00:44 --> Config Class Initialized
INFO - 2021-08-07 15:00:44 --> Hooks Class Initialized
DEBUG - 2021-08-07 15:00:44 --> UTF-8 Support Enabled
INFO - 2021-08-07 15:00:44 --> Utf8 Class Initialized
INFO - 2021-08-07 15:00:44 --> URI Class Initialized
DEBUG - 2021-08-07 15:00:44 --> No URI present. Default controller set.
INFO - 2021-08-07 15:00:44 --> Router Class Initialized
INFO - 2021-08-07 15:00:44 --> Output Class Initialized
INFO - 2021-08-07 15:00:44 --> Security Class Initialized
DEBUG - 2021-08-07 15:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 15:00:44 --> Input Class Initialized
INFO - 2021-08-07 15:00:44 --> Language Class Initialized
INFO - 2021-08-07 15:00:44 --> Loader Class Initialized
INFO - 2021-08-07 15:00:44 --> Helper loaded: url_helper
INFO - 2021-08-07 15:00:44 --> Helper loaded: file_helper
INFO - 2021-08-07 15:00:44 --> Database Driver Class Initialized
DEBUG - 2021-08-07 15:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 15:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 15:00:44 --> Controller Class Initialized
INFO - 2021-08-07 15:00:44 --> Helper loaded: cookie_helper
INFO - 2021-08-07 15:00:44 --> Model "CookieModel" initialized
INFO - 2021-08-07 15:00:44 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 15:00:44 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/index.php
INFO - 2021-08-07 15:00:44 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 15:00:44 --> Final output sent to browser
DEBUG - 2021-08-07 15:00:44 --> Total execution time: 0.0190
INFO - 2021-08-07 15:00:49 --> Config Class Initialized
INFO - 2021-08-07 15:00:49 --> Hooks Class Initialized
DEBUG - 2021-08-07 15:00:49 --> UTF-8 Support Enabled
INFO - 2021-08-07 15:00:49 --> Utf8 Class Initialized
INFO - 2021-08-07 15:00:49 --> URI Class Initialized
DEBUG - 2021-08-07 15:00:49 --> No URI present. Default controller set.
INFO - 2021-08-07 15:00:49 --> Router Class Initialized
INFO - 2021-08-07 15:00:49 --> Output Class Initialized
INFO - 2021-08-07 15:00:49 --> Security Class Initialized
DEBUG - 2021-08-07 15:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 15:00:49 --> Input Class Initialized
INFO - 2021-08-07 15:00:49 --> Language Class Initialized
INFO - 2021-08-07 15:00:49 --> Loader Class Initialized
INFO - 2021-08-07 15:00:49 --> Helper loaded: url_helper
INFO - 2021-08-07 15:00:49 --> Helper loaded: file_helper
INFO - 2021-08-07 15:00:49 --> Database Driver Class Initialized
DEBUG - 2021-08-07 15:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 15:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 15:00:49 --> Controller Class Initialized
INFO - 2021-08-07 15:00:49 --> Helper loaded: cookie_helper
INFO - 2021-08-07 15:00:49 --> Model "CookieModel" initialized
INFO - 2021-08-07 15:00:49 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 15:00:49 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/index.php
INFO - 2021-08-07 15:00:49 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 15:00:49 --> Final output sent to browser
DEBUG - 2021-08-07 15:00:49 --> Total execution time: 0.0191
INFO - 2021-08-07 15:15:02 --> Config Class Initialized
INFO - 2021-08-07 15:15:02 --> Hooks Class Initialized
DEBUG - 2021-08-07 15:15:02 --> UTF-8 Support Enabled
INFO - 2021-08-07 15:15:02 --> Utf8 Class Initialized
INFO - 2021-08-07 15:15:02 --> URI Class Initialized
DEBUG - 2021-08-07 15:15:02 --> No URI present. Default controller set.
INFO - 2021-08-07 15:15:02 --> Router Class Initialized
INFO - 2021-08-07 15:15:02 --> Output Class Initialized
INFO - 2021-08-07 15:15:02 --> Security Class Initialized
DEBUG - 2021-08-07 15:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 15:15:02 --> Input Class Initialized
INFO - 2021-08-07 15:15:02 --> Language Class Initialized
INFO - 2021-08-07 15:15:02 --> Loader Class Initialized
INFO - 2021-08-07 15:15:02 --> Helper loaded: url_helper
INFO - 2021-08-07 15:15:02 --> Helper loaded: file_helper
INFO - 2021-08-07 15:15:02 --> Database Driver Class Initialized
DEBUG - 2021-08-07 15:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 15:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 15:15:02 --> Controller Class Initialized
INFO - 2021-08-07 15:15:02 --> Helper loaded: cookie_helper
INFO - 2021-08-07 15:15:02 --> Model "CookieModel" initialized
INFO - 2021-08-07 15:15:02 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 15:15:02 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/index.php
INFO - 2021-08-07 15:15:02 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 15:15:02 --> Final output sent to browser
DEBUG - 2021-08-07 15:15:02 --> Total execution time: 0.0288
INFO - 2021-08-07 15:15:26 --> Config Class Initialized
INFO - 2021-08-07 15:15:26 --> Hooks Class Initialized
DEBUG - 2021-08-07 15:15:26 --> UTF-8 Support Enabled
INFO - 2021-08-07 15:15:26 --> Utf8 Class Initialized
INFO - 2021-08-07 15:15:26 --> URI Class Initialized
INFO - 2021-08-07 15:15:26 --> Router Class Initialized
INFO - 2021-08-07 15:15:26 --> Output Class Initialized
INFO - 2021-08-07 15:15:26 --> Security Class Initialized
DEBUG - 2021-08-07 15:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 15:15:26 --> Input Class Initialized
INFO - 2021-08-07 15:15:26 --> Language Class Initialized
INFO - 2021-08-07 15:15:26 --> Loader Class Initialized
INFO - 2021-08-07 15:15:26 --> Helper loaded: url_helper
INFO - 2021-08-07 15:15:26 --> Helper loaded: file_helper
INFO - 2021-08-07 15:15:26 --> Database Driver Class Initialized
DEBUG - 2021-08-07 15:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 15:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 15:15:26 --> Controller Class Initialized
INFO - 2021-08-07 15:15:26 --> Helper loaded: cookie_helper
INFO - 2021-08-07 15:15:26 --> Model "CookieModel" initialized
INFO - 2021-08-07 15:15:26 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 15:15:26 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/pilates.php
INFO - 2021-08-07 15:15:26 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 15:15:26 --> Final output sent to browser
DEBUG - 2021-08-07 15:15:26 --> Total execution time: 0.0374
INFO - 2021-08-07 15:15:39 --> Config Class Initialized
INFO - 2021-08-07 15:15:39 --> Hooks Class Initialized
DEBUG - 2021-08-07 15:15:39 --> UTF-8 Support Enabled
INFO - 2021-08-07 15:15:39 --> Utf8 Class Initialized
INFO - 2021-08-07 15:15:39 --> URI Class Initialized
INFO - 2021-08-07 15:15:39 --> Router Class Initialized
INFO - 2021-08-07 15:15:39 --> Output Class Initialized
INFO - 2021-08-07 15:15:39 --> Security Class Initialized
DEBUG - 2021-08-07 15:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 15:15:39 --> Input Class Initialized
INFO - 2021-08-07 15:15:39 --> Language Class Initialized
INFO - 2021-08-07 15:15:39 --> Loader Class Initialized
INFO - 2021-08-07 15:15:39 --> Helper loaded: url_helper
INFO - 2021-08-07 15:15:39 --> Helper loaded: file_helper
INFO - 2021-08-07 15:15:39 --> Database Driver Class Initialized
DEBUG - 2021-08-07 15:15:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 15:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 15:15:39 --> Controller Class Initialized
INFO - 2021-08-07 15:15:39 --> Helper loaded: cookie_helper
INFO - 2021-08-07 15:15:39 --> Model "CookieModel" initialized
INFO - 2021-08-07 15:15:39 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 15:15:39 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/services.php
INFO - 2021-08-07 15:15:39 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 15:15:39 --> Final output sent to browser
DEBUG - 2021-08-07 15:15:39 --> Total execution time: 0.0170
INFO - 2021-08-07 15:15:53 --> Config Class Initialized
INFO - 2021-08-07 15:15:53 --> Hooks Class Initialized
DEBUG - 2021-08-07 15:15:53 --> UTF-8 Support Enabled
INFO - 2021-08-07 15:15:53 --> Utf8 Class Initialized
INFO - 2021-08-07 15:15:53 --> URI Class Initialized
INFO - 2021-08-07 15:15:53 --> Router Class Initialized
INFO - 2021-08-07 15:15:53 --> Output Class Initialized
INFO - 2021-08-07 15:15:53 --> Security Class Initialized
DEBUG - 2021-08-07 15:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 15:15:53 --> Input Class Initialized
INFO - 2021-08-07 15:15:53 --> Language Class Initialized
INFO - 2021-08-07 15:15:53 --> Loader Class Initialized
INFO - 2021-08-07 15:15:53 --> Helper loaded: url_helper
INFO - 2021-08-07 15:15:53 --> Helper loaded: file_helper
INFO - 2021-08-07 15:15:53 --> Database Driver Class Initialized
DEBUG - 2021-08-07 15:15:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 15:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 15:15:53 --> Controller Class Initialized
INFO - 2021-08-07 15:15:53 --> Helper loaded: cookie_helper
INFO - 2021-08-07 15:15:53 --> Model "CookieModel" initialized
INFO - 2021-08-07 15:15:53 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 15:15:53 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/success_stories.php
INFO - 2021-08-07 15:15:53 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 15:15:53 --> Final output sent to browser
DEBUG - 2021-08-07 15:15:53 --> Total execution time: 0.0232
INFO - 2021-08-07 15:16:08 --> Config Class Initialized
INFO - 2021-08-07 15:16:08 --> Hooks Class Initialized
DEBUG - 2021-08-07 15:16:08 --> UTF-8 Support Enabled
INFO - 2021-08-07 15:16:08 --> Utf8 Class Initialized
INFO - 2021-08-07 15:16:08 --> URI Class Initialized
INFO - 2021-08-07 15:16:08 --> Router Class Initialized
INFO - 2021-08-07 15:16:08 --> Output Class Initialized
INFO - 2021-08-07 15:16:08 --> Security Class Initialized
DEBUG - 2021-08-07 15:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 15:16:08 --> Input Class Initialized
INFO - 2021-08-07 15:16:08 --> Language Class Initialized
INFO - 2021-08-07 15:16:08 --> Loader Class Initialized
INFO - 2021-08-07 15:16:08 --> Helper loaded: url_helper
INFO - 2021-08-07 15:16:08 --> Helper loaded: file_helper
INFO - 2021-08-07 15:16:08 --> Database Driver Class Initialized
DEBUG - 2021-08-07 15:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 15:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 15:16:08 --> Controller Class Initialized
INFO - 2021-08-07 15:16:08 --> Helper loaded: cookie_helper
INFO - 2021-08-07 15:16:08 --> Model "CookieModel" initialized
INFO - 2021-08-07 15:16:08 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 15:16:08 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/about.php
INFO - 2021-08-07 15:16:08 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 15:16:08 --> Final output sent to browser
DEBUG - 2021-08-07 15:16:08 --> Total execution time: 0.0177
INFO - 2021-08-07 15:16:13 --> Config Class Initialized
INFO - 2021-08-07 15:16:13 --> Hooks Class Initialized
DEBUG - 2021-08-07 15:16:13 --> UTF-8 Support Enabled
INFO - 2021-08-07 15:16:13 --> Utf8 Class Initialized
INFO - 2021-08-07 15:16:13 --> URI Class Initialized
INFO - 2021-08-07 15:16:13 --> Router Class Initialized
INFO - 2021-08-07 15:16:13 --> Output Class Initialized
INFO - 2021-08-07 15:16:13 --> Security Class Initialized
DEBUG - 2021-08-07 15:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 15:16:13 --> Input Class Initialized
INFO - 2021-08-07 15:16:13 --> Language Class Initialized
INFO - 2021-08-07 15:16:13 --> Loader Class Initialized
INFO - 2021-08-07 15:16:13 --> Helper loaded: url_helper
INFO - 2021-08-07 15:16:13 --> Helper loaded: file_helper
INFO - 2021-08-07 15:16:13 --> Database Driver Class Initialized
DEBUG - 2021-08-07 15:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 15:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 15:16:13 --> Controller Class Initialized
INFO - 2021-08-07 15:16:13 --> Helper loaded: cookie_helper
INFO - 2021-08-07 15:16:13 --> Model "CookieModel" initialized
INFO - 2021-08-07 15:16:13 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 15:16:13 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/team.php
INFO - 2021-08-07 15:16:13 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 15:16:13 --> Final output sent to browser
DEBUG - 2021-08-07 15:16:13 --> Total execution time: 0.3669
INFO - 2021-08-07 15:16:25 --> Config Class Initialized
INFO - 2021-08-07 15:16:25 --> Hooks Class Initialized
DEBUG - 2021-08-07 15:16:25 --> UTF-8 Support Enabled
INFO - 2021-08-07 15:16:25 --> Utf8 Class Initialized
INFO - 2021-08-07 15:16:25 --> URI Class Initialized
INFO - 2021-08-07 15:16:25 --> Router Class Initialized
INFO - 2021-08-07 15:16:25 --> Output Class Initialized
INFO - 2021-08-07 15:16:25 --> Security Class Initialized
DEBUG - 2021-08-07 15:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 15:16:25 --> Input Class Initialized
INFO - 2021-08-07 15:16:25 --> Language Class Initialized
INFO - 2021-08-07 15:16:25 --> Loader Class Initialized
INFO - 2021-08-07 15:16:25 --> Helper loaded: url_helper
INFO - 2021-08-07 15:16:25 --> Helper loaded: file_helper
INFO - 2021-08-07 15:16:25 --> Database Driver Class Initialized
DEBUG - 2021-08-07 15:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 15:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 15:16:25 --> Controller Class Initialized
INFO - 2021-08-07 15:16:25 --> Helper loaded: cookie_helper
INFO - 2021-08-07 15:16:25 --> Model "CookieModel" initialized
INFO - 2021-08-07 15:16:25 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 15:16:25 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/about.php
INFO - 2021-08-07 15:16:25 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 15:16:25 --> Final output sent to browser
DEBUG - 2021-08-07 15:16:25 --> Total execution time: 0.0189
INFO - 2021-08-07 15:16:29 --> Config Class Initialized
INFO - 2021-08-07 15:16:29 --> Hooks Class Initialized
DEBUG - 2021-08-07 15:16:29 --> UTF-8 Support Enabled
INFO - 2021-08-07 15:16:29 --> Utf8 Class Initialized
INFO - 2021-08-07 15:16:29 --> URI Class Initialized
INFO - 2021-08-07 15:16:29 --> Router Class Initialized
INFO - 2021-08-07 15:16:29 --> Output Class Initialized
INFO - 2021-08-07 15:16:29 --> Security Class Initialized
DEBUG - 2021-08-07 15:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 15:16:29 --> Input Class Initialized
INFO - 2021-08-07 15:16:29 --> Language Class Initialized
INFO - 2021-08-07 15:16:29 --> Loader Class Initialized
INFO - 2021-08-07 15:16:29 --> Helper loaded: url_helper
INFO - 2021-08-07 15:16:29 --> Helper loaded: file_helper
INFO - 2021-08-07 15:16:29 --> Database Driver Class Initialized
DEBUG - 2021-08-07 15:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 15:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 15:16:29 --> Controller Class Initialized
INFO - 2021-08-07 15:16:29 --> Helper loaded: cookie_helper
INFO - 2021-08-07 15:16:29 --> Model "CookieModel" initialized
INFO - 2021-08-07 15:16:29 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 15:16:29 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/gallery.php
INFO - 2021-08-07 15:16:29 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 15:16:29 --> Final output sent to browser
DEBUG - 2021-08-07 15:16:29 --> Total execution time: 0.0289
INFO - 2021-08-07 15:16:38 --> Config Class Initialized
INFO - 2021-08-07 15:16:38 --> Hooks Class Initialized
DEBUG - 2021-08-07 15:16:38 --> UTF-8 Support Enabled
INFO - 2021-08-07 15:16:38 --> Utf8 Class Initialized
INFO - 2021-08-07 15:16:38 --> URI Class Initialized
INFO - 2021-08-07 15:16:38 --> Router Class Initialized
INFO - 2021-08-07 15:16:38 --> Output Class Initialized
INFO - 2021-08-07 15:16:38 --> Security Class Initialized
DEBUG - 2021-08-07 15:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 15:16:38 --> Input Class Initialized
INFO - 2021-08-07 15:16:38 --> Language Class Initialized
INFO - 2021-08-07 15:16:38 --> Loader Class Initialized
INFO - 2021-08-07 15:16:38 --> Helper loaded: url_helper
INFO - 2021-08-07 15:16:38 --> Helper loaded: file_helper
INFO - 2021-08-07 15:16:38 --> Database Driver Class Initialized
DEBUG - 2021-08-07 15:16:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 15:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 15:16:38 --> Controller Class Initialized
INFO - 2021-08-07 15:16:38 --> Helper loaded: cookie_helper
INFO - 2021-08-07 15:16:38 --> Model "CookieModel" initialized
INFO - 2021-08-07 15:16:38 --> Model "ContactModel" initialized
INFO - 2021-08-07 15:16:38 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 15:16:38 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/contact.php
INFO - 2021-08-07 15:16:38 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 15:16:38 --> Final output sent to browser
DEBUG - 2021-08-07 15:16:38 --> Total execution time: 0.0336
INFO - 2021-08-07 17:52:44 --> Config Class Initialized
INFO - 2021-08-07 17:52:44 --> Hooks Class Initialized
DEBUG - 2021-08-07 17:52:44 --> UTF-8 Support Enabled
INFO - 2021-08-07 17:52:44 --> Utf8 Class Initialized
INFO - 2021-08-07 17:52:44 --> URI Class Initialized
INFO - 2021-08-07 17:52:44 --> Router Class Initialized
INFO - 2021-08-07 17:52:44 --> Output Class Initialized
INFO - 2021-08-07 17:52:44 --> Security Class Initialized
DEBUG - 2021-08-07 17:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 17:52:44 --> Input Class Initialized
INFO - 2021-08-07 17:52:44 --> Language Class Initialized
INFO - 2021-08-07 17:52:44 --> Loader Class Initialized
INFO - 2021-08-07 17:52:44 --> Helper loaded: url_helper
INFO - 2021-08-07 17:52:44 --> Helper loaded: file_helper
INFO - 2021-08-07 17:52:44 --> Database Driver Class Initialized
DEBUG - 2021-08-07 17:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 17:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 17:52:44 --> Controller Class Initialized
INFO - 2021-08-07 17:52:44 --> Helper loaded: cookie_helper
INFO - 2021-08-07 17:52:44 --> Model "CookieModel" initialized
INFO - 2021-08-07 17:52:44 --> Model "ContactModel" initialized
INFO - 2021-08-07 17:52:44 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 17:52:44 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/contact.php
INFO - 2021-08-07 17:52:44 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 17:52:44 --> Final output sent to browser
DEBUG - 2021-08-07 17:52:44 --> Total execution time: 0.0755
INFO - 2021-08-07 19:57:36 --> Config Class Initialized
INFO - 2021-08-07 19:57:36 --> Hooks Class Initialized
DEBUG - 2021-08-07 19:57:36 --> UTF-8 Support Enabled
INFO - 2021-08-07 19:57:36 --> Utf8 Class Initialized
INFO - 2021-08-07 19:57:36 --> URI Class Initialized
DEBUG - 2021-08-07 19:57:36 --> No URI present. Default controller set.
INFO - 2021-08-07 19:57:36 --> Router Class Initialized
INFO - 2021-08-07 19:57:36 --> Output Class Initialized
INFO - 2021-08-07 19:57:36 --> Security Class Initialized
DEBUG - 2021-08-07 19:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 19:57:36 --> Input Class Initialized
INFO - 2021-08-07 19:57:36 --> Language Class Initialized
INFO - 2021-08-07 19:57:36 --> Loader Class Initialized
INFO - 2021-08-07 19:57:36 --> Helper loaded: url_helper
INFO - 2021-08-07 19:57:36 --> Helper loaded: file_helper
INFO - 2021-08-07 19:57:36 --> Database Driver Class Initialized
DEBUG - 2021-08-07 19:57:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 19:57:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 19:57:36 --> Controller Class Initialized
INFO - 2021-08-07 19:57:36 --> Helper loaded: cookie_helper
INFO - 2021-08-07 19:57:36 --> Model "CookieModel" initialized
INFO - 2021-08-07 19:57:36 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 19:57:36 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/index.php
INFO - 2021-08-07 19:57:36 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 19:57:36 --> Final output sent to browser
DEBUG - 2021-08-07 19:57:36 --> Total execution time: 0.1096
INFO - 2021-08-07 19:58:14 --> Config Class Initialized
INFO - 2021-08-07 19:58:14 --> Hooks Class Initialized
DEBUG - 2021-08-07 19:58:14 --> UTF-8 Support Enabled
INFO - 2021-08-07 19:58:14 --> Utf8 Class Initialized
INFO - 2021-08-07 19:58:14 --> URI Class Initialized
INFO - 2021-08-07 19:58:14 --> Router Class Initialized
INFO - 2021-08-07 19:58:14 --> Output Class Initialized
INFO - 2021-08-07 19:58:14 --> Security Class Initialized
DEBUG - 2021-08-07 19:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 19:58:14 --> Input Class Initialized
INFO - 2021-08-07 19:58:14 --> Language Class Initialized
INFO - 2021-08-07 19:58:14 --> Loader Class Initialized
INFO - 2021-08-07 19:58:14 --> Helper loaded: url_helper
INFO - 2021-08-07 19:58:14 --> Helper loaded: file_helper
INFO - 2021-08-07 19:58:14 --> Database Driver Class Initialized
DEBUG - 2021-08-07 19:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 19:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 19:58:14 --> Controller Class Initialized
INFO - 2021-08-07 19:58:14 --> Helper loaded: cookie_helper
INFO - 2021-08-07 19:58:14 --> Model "CookieModel" initialized
INFO - 2021-08-07 19:58:14 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 19:58:14 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/pilates.php
INFO - 2021-08-07 19:58:14 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 19:58:14 --> Final output sent to browser
DEBUG - 2021-08-07 19:58:14 --> Total execution time: 0.0188
INFO - 2021-08-07 19:58:15 --> Config Class Initialized
INFO - 2021-08-07 19:58:15 --> Hooks Class Initialized
DEBUG - 2021-08-07 19:58:15 --> UTF-8 Support Enabled
INFO - 2021-08-07 19:58:15 --> Utf8 Class Initialized
INFO - 2021-08-07 19:58:15 --> URI Class Initialized
INFO - 2021-08-07 19:58:15 --> Router Class Initialized
INFO - 2021-08-07 19:58:15 --> Output Class Initialized
INFO - 2021-08-07 19:58:15 --> Security Class Initialized
DEBUG - 2021-08-07 19:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 19:58:15 --> Input Class Initialized
INFO - 2021-08-07 19:58:15 --> Language Class Initialized
INFO - 2021-08-07 19:58:15 --> Loader Class Initialized
INFO - 2021-08-07 19:58:15 --> Helper loaded: url_helper
INFO - 2021-08-07 19:58:15 --> Helper loaded: file_helper
INFO - 2021-08-07 19:58:15 --> Database Driver Class Initialized
DEBUG - 2021-08-07 19:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 19:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 19:58:15 --> Controller Class Initialized
INFO - 2021-08-07 19:58:15 --> Helper loaded: cookie_helper
INFO - 2021-08-07 19:58:15 --> Model "CookieModel" initialized
INFO - 2021-08-07 19:58:15 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 19:58:15 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/pilates.php
INFO - 2021-08-07 19:58:15 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 19:58:15 --> Final output sent to browser
DEBUG - 2021-08-07 19:58:15 --> Total execution time: 0.0209
INFO - 2021-08-07 19:58:19 --> Config Class Initialized
INFO - 2021-08-07 19:58:19 --> Hooks Class Initialized
DEBUG - 2021-08-07 19:58:19 --> UTF-8 Support Enabled
INFO - 2021-08-07 19:58:19 --> Utf8 Class Initialized
INFO - 2021-08-07 19:58:19 --> URI Class Initialized
DEBUG - 2021-08-07 19:58:19 --> No URI present. Default controller set.
INFO - 2021-08-07 19:58:19 --> Router Class Initialized
INFO - 2021-08-07 19:58:19 --> Output Class Initialized
INFO - 2021-08-07 19:58:19 --> Security Class Initialized
DEBUG - 2021-08-07 19:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 19:58:19 --> Input Class Initialized
INFO - 2021-08-07 19:58:19 --> Language Class Initialized
INFO - 2021-08-07 19:58:19 --> Loader Class Initialized
INFO - 2021-08-07 19:58:19 --> Helper loaded: url_helper
INFO - 2021-08-07 19:58:19 --> Helper loaded: file_helper
INFO - 2021-08-07 19:58:19 --> Database Driver Class Initialized
DEBUG - 2021-08-07 19:58:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 19:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 19:58:19 --> Controller Class Initialized
INFO - 2021-08-07 19:58:19 --> Helper loaded: cookie_helper
INFO - 2021-08-07 19:58:19 --> Model "CookieModel" initialized
INFO - 2021-08-07 19:58:19 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 19:58:19 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/index.php
INFO - 2021-08-07 19:58:19 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 19:58:19 --> Final output sent to browser
DEBUG - 2021-08-07 19:58:19 --> Total execution time: 0.0201
INFO - 2021-08-07 19:59:13 --> Config Class Initialized
INFO - 2021-08-07 19:59:13 --> Hooks Class Initialized
DEBUG - 2021-08-07 19:59:13 --> UTF-8 Support Enabled
INFO - 2021-08-07 19:59:13 --> Utf8 Class Initialized
INFO - 2021-08-07 19:59:13 --> URI Class Initialized
INFO - 2021-08-07 19:59:13 --> Router Class Initialized
INFO - 2021-08-07 19:59:13 --> Output Class Initialized
INFO - 2021-08-07 19:59:13 --> Security Class Initialized
DEBUG - 2021-08-07 19:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 19:59:13 --> Input Class Initialized
INFO - 2021-08-07 19:59:13 --> Language Class Initialized
INFO - 2021-08-07 19:59:13 --> Loader Class Initialized
INFO - 2021-08-07 19:59:13 --> Helper loaded: url_helper
INFO - 2021-08-07 19:59:13 --> Helper loaded: file_helper
INFO - 2021-08-07 19:59:13 --> Database Driver Class Initialized
DEBUG - 2021-08-07 19:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 19:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 19:59:13 --> Controller Class Initialized
INFO - 2021-08-07 19:59:13 --> Helper loaded: cookie_helper
INFO - 2021-08-07 19:59:13 --> Model "CookieModel" initialized
INFO - 2021-08-07 19:59:13 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 19:59:13 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/pilates.php
INFO - 2021-08-07 19:59:13 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 19:59:13 --> Final output sent to browser
DEBUG - 2021-08-07 19:59:13 --> Total execution time: 0.0188
INFO - 2021-08-07 20:00:13 --> Config Class Initialized
INFO - 2021-08-07 20:00:13 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:00:13 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:00:13 --> Utf8 Class Initialized
INFO - 2021-08-07 20:00:13 --> URI Class Initialized
INFO - 2021-08-07 20:00:13 --> Router Class Initialized
INFO - 2021-08-07 20:00:13 --> Output Class Initialized
INFO - 2021-08-07 20:00:13 --> Security Class Initialized
DEBUG - 2021-08-07 20:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:00:13 --> Input Class Initialized
INFO - 2021-08-07 20:00:13 --> Language Class Initialized
INFO - 2021-08-07 20:00:13 --> Loader Class Initialized
INFO - 2021-08-07 20:00:13 --> Helper loaded: url_helper
INFO - 2021-08-07 20:00:13 --> Helper loaded: file_helper
INFO - 2021-08-07 20:00:13 --> Database Driver Class Initialized
DEBUG - 2021-08-07 20:00:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 20:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 20:00:13 --> Controller Class Initialized
INFO - 2021-08-07 20:00:13 --> Helper loaded: cookie_helper
INFO - 2021-08-07 20:00:13 --> Model "CookieModel" initialized
INFO - 2021-08-07 20:00:13 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 20:00:13 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/pilates.php
INFO - 2021-08-07 20:00:13 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 20:00:13 --> Final output sent to browser
DEBUG - 2021-08-07 20:00:13 --> Total execution time: 0.0182
INFO - 2021-08-07 20:00:20 --> Config Class Initialized
INFO - 2021-08-07 20:00:20 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:00:20 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:00:20 --> Utf8 Class Initialized
INFO - 2021-08-07 20:00:20 --> URI Class Initialized
INFO - 2021-08-07 20:00:20 --> Router Class Initialized
INFO - 2021-08-07 20:00:20 --> Output Class Initialized
INFO - 2021-08-07 20:00:20 --> Security Class Initialized
DEBUG - 2021-08-07 20:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:00:20 --> Input Class Initialized
INFO - 2021-08-07 20:00:20 --> Language Class Initialized
INFO - 2021-08-07 20:00:20 --> Loader Class Initialized
INFO - 2021-08-07 20:00:20 --> Helper loaded: url_helper
INFO - 2021-08-07 20:00:20 --> Helper loaded: file_helper
INFO - 2021-08-07 20:00:20 --> Database Driver Class Initialized
DEBUG - 2021-08-07 20:00:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 20:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 20:00:20 --> Controller Class Initialized
INFO - 2021-08-07 20:00:20 --> Helper loaded: cookie_helper
INFO - 2021-08-07 20:00:20 --> Model "CookieModel" initialized
INFO - 2021-08-07 20:00:20 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 20:00:20 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/pilates.php
INFO - 2021-08-07 20:00:20 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 20:00:20 --> Final output sent to browser
DEBUG - 2021-08-07 20:00:20 --> Total execution time: 0.0196
INFO - 2021-08-07 20:01:00 --> Config Class Initialized
INFO - 2021-08-07 20:01:00 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:01:00 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:01:00 --> Utf8 Class Initialized
INFO - 2021-08-07 20:01:00 --> URI Class Initialized
INFO - 2021-08-07 20:01:00 --> Router Class Initialized
INFO - 2021-08-07 20:01:00 --> Output Class Initialized
INFO - 2021-08-07 20:01:00 --> Security Class Initialized
DEBUG - 2021-08-07 20:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:01:00 --> Input Class Initialized
INFO - 2021-08-07 20:01:00 --> Language Class Initialized
INFO - 2021-08-07 20:01:00 --> Loader Class Initialized
INFO - 2021-08-07 20:01:00 --> Helper loaded: url_helper
INFO - 2021-08-07 20:01:00 --> Helper loaded: file_helper
INFO - 2021-08-07 20:01:00 --> Database Driver Class Initialized
DEBUG - 2021-08-07 20:01:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 20:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 20:01:00 --> Controller Class Initialized
INFO - 2021-08-07 20:01:00 --> Helper loaded: cookie_helper
INFO - 2021-08-07 20:01:00 --> Model "CookieModel" initialized
INFO - 2021-08-07 20:01:00 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 20:01:00 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/services.php
INFO - 2021-08-07 20:01:00 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 20:01:00 --> Final output sent to browser
DEBUG - 2021-08-07 20:01:00 --> Total execution time: 0.0191
INFO - 2021-08-07 20:01:04 --> Config Class Initialized
INFO - 2021-08-07 20:01:04 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:01:04 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:01:04 --> Utf8 Class Initialized
INFO - 2021-08-07 20:01:04 --> URI Class Initialized
INFO - 2021-08-07 20:01:04 --> Router Class Initialized
INFO - 2021-08-07 20:01:04 --> Output Class Initialized
INFO - 2021-08-07 20:01:04 --> Security Class Initialized
DEBUG - 2021-08-07 20:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:01:04 --> Input Class Initialized
INFO - 2021-08-07 20:01:04 --> Language Class Initialized
INFO - 2021-08-07 20:01:04 --> Loader Class Initialized
INFO - 2021-08-07 20:01:04 --> Helper loaded: url_helper
INFO - 2021-08-07 20:01:04 --> Helper loaded: file_helper
INFO - 2021-08-07 20:01:04 --> Database Driver Class Initialized
DEBUG - 2021-08-07 20:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 20:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 20:01:04 --> Controller Class Initialized
INFO - 2021-08-07 20:01:04 --> Helper loaded: cookie_helper
INFO - 2021-08-07 20:01:04 --> Model "CookieModel" initialized
INFO - 2021-08-07 20:01:04 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 20:01:04 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/pilates.php
INFO - 2021-08-07 20:01:04 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 20:01:04 --> Final output sent to browser
DEBUG - 2021-08-07 20:01:04 --> Total execution time: 0.0185
INFO - 2021-08-07 20:03:06 --> Config Class Initialized
INFO - 2021-08-07 20:03:06 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:03:06 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:03:06 --> Utf8 Class Initialized
INFO - 2021-08-07 20:03:06 --> URI Class Initialized
INFO - 2021-08-07 20:03:06 --> Router Class Initialized
INFO - 2021-08-07 20:03:06 --> Output Class Initialized
INFO - 2021-08-07 20:03:06 --> Security Class Initialized
DEBUG - 2021-08-07 20:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:03:06 --> Input Class Initialized
INFO - 2021-08-07 20:03:06 --> Language Class Initialized
INFO - 2021-08-07 20:03:06 --> Loader Class Initialized
INFO - 2021-08-07 20:03:06 --> Helper loaded: url_helper
INFO - 2021-08-07 20:03:06 --> Helper loaded: file_helper
INFO - 2021-08-07 20:03:06 --> Database Driver Class Initialized
DEBUG - 2021-08-07 20:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 20:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 20:03:06 --> Controller Class Initialized
INFO - 2021-08-07 20:03:06 --> Helper loaded: cookie_helper
INFO - 2021-08-07 20:03:06 --> Model "CookieModel" initialized
INFO - 2021-08-07 20:03:06 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 20:03:06 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/pilates.php
INFO - 2021-08-07 20:03:06 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 20:03:06 --> Final output sent to browser
DEBUG - 2021-08-07 20:03:06 --> Total execution time: 0.0183
INFO - 2021-08-07 20:03:13 --> Config Class Initialized
INFO - 2021-08-07 20:03:13 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:03:13 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:03:13 --> Utf8 Class Initialized
INFO - 2021-08-07 20:03:13 --> URI Class Initialized
INFO - 2021-08-07 20:03:13 --> Router Class Initialized
INFO - 2021-08-07 20:03:13 --> Output Class Initialized
INFO - 2021-08-07 20:03:13 --> Security Class Initialized
DEBUG - 2021-08-07 20:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:03:13 --> Input Class Initialized
INFO - 2021-08-07 20:03:13 --> Language Class Initialized
INFO - 2021-08-07 20:03:13 --> Loader Class Initialized
INFO - 2021-08-07 20:03:13 --> Helper loaded: url_helper
INFO - 2021-08-07 20:03:13 --> Helper loaded: file_helper
INFO - 2021-08-07 20:03:13 --> Database Driver Class Initialized
DEBUG - 2021-08-07 20:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 20:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 20:03:13 --> Controller Class Initialized
INFO - 2021-08-07 20:03:13 --> Helper loaded: cookie_helper
INFO - 2021-08-07 20:03:13 --> Model "CookieModel" initialized
INFO - 2021-08-07 20:03:13 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 20:03:13 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/pilates.php
INFO - 2021-08-07 20:03:13 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 20:03:13 --> Final output sent to browser
DEBUG - 2021-08-07 20:03:13 --> Total execution time: 0.0192
INFO - 2021-08-07 20:05:00 --> Config Class Initialized
INFO - 2021-08-07 20:05:00 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:05:00 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:05:00 --> Utf8 Class Initialized
INFO - 2021-08-07 20:05:00 --> URI Class Initialized
INFO - 2021-08-07 20:05:00 --> Router Class Initialized
INFO - 2021-08-07 20:05:00 --> Output Class Initialized
INFO - 2021-08-07 20:05:00 --> Security Class Initialized
DEBUG - 2021-08-07 20:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:05:00 --> Input Class Initialized
INFO - 2021-08-07 20:05:00 --> Language Class Initialized
INFO - 2021-08-07 20:05:00 --> Loader Class Initialized
INFO - 2021-08-07 20:05:00 --> Helper loaded: url_helper
INFO - 2021-08-07 20:05:00 --> Helper loaded: file_helper
INFO - 2021-08-07 20:05:00 --> Database Driver Class Initialized
DEBUG - 2021-08-07 20:05:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 20:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 20:05:00 --> Controller Class Initialized
INFO - 2021-08-07 20:05:00 --> Helper loaded: cookie_helper
INFO - 2021-08-07 20:05:00 --> Model "CookieModel" initialized
INFO - 2021-08-07 20:05:00 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 20:05:00 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/services.php
INFO - 2021-08-07 20:05:00 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 20:05:00 --> Final output sent to browser
DEBUG - 2021-08-07 20:05:00 --> Total execution time: 0.0193
INFO - 2021-08-07 20:05:34 --> Config Class Initialized
INFO - 2021-08-07 20:05:34 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:05:34 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:05:34 --> Utf8 Class Initialized
INFO - 2021-08-07 20:05:34 --> URI Class Initialized
INFO - 2021-08-07 20:05:34 --> Router Class Initialized
INFO - 2021-08-07 20:05:34 --> Output Class Initialized
INFO - 2021-08-07 20:05:34 --> Security Class Initialized
DEBUG - 2021-08-07 20:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:05:34 --> Input Class Initialized
INFO - 2021-08-07 20:05:34 --> Language Class Initialized
INFO - 2021-08-07 20:05:34 --> Loader Class Initialized
INFO - 2021-08-07 20:05:34 --> Helper loaded: url_helper
INFO - 2021-08-07 20:05:34 --> Helper loaded: file_helper
INFO - 2021-08-07 20:05:34 --> Database Driver Class Initialized
DEBUG - 2021-08-07 20:05:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 20:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 20:05:34 --> Controller Class Initialized
INFO - 2021-08-07 20:05:34 --> Helper loaded: cookie_helper
INFO - 2021-08-07 20:05:34 --> Model "CookieModel" initialized
INFO - 2021-08-07 20:05:34 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 20:05:34 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/services.php
INFO - 2021-08-07 20:05:34 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 20:05:34 --> Final output sent to browser
DEBUG - 2021-08-07 20:05:34 --> Total execution time: 0.0192
INFO - 2021-08-07 20:05:37 --> Config Class Initialized
INFO - 2021-08-07 20:05:37 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:05:37 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:05:37 --> Utf8 Class Initialized
INFO - 2021-08-07 20:05:37 --> URI Class Initialized
INFO - 2021-08-07 20:05:37 --> Router Class Initialized
INFO - 2021-08-07 20:05:37 --> Output Class Initialized
INFO - 2021-08-07 20:05:37 --> Security Class Initialized
DEBUG - 2021-08-07 20:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:05:37 --> Input Class Initialized
INFO - 2021-08-07 20:05:37 --> Language Class Initialized
INFO - 2021-08-07 20:05:37 --> Loader Class Initialized
INFO - 2021-08-07 20:05:37 --> Helper loaded: url_helper
INFO - 2021-08-07 20:05:37 --> Helper loaded: file_helper
INFO - 2021-08-07 20:05:37 --> Database Driver Class Initialized
DEBUG - 2021-08-07 20:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 20:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 20:05:37 --> Controller Class Initialized
INFO - 2021-08-07 20:05:37 --> Helper loaded: cookie_helper
INFO - 2021-08-07 20:05:37 --> Model "CookieModel" initialized
INFO - 2021-08-07 20:05:37 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 20:05:37 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/services.php
INFO - 2021-08-07 20:05:37 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 20:05:37 --> Final output sent to browser
DEBUG - 2021-08-07 20:05:37 --> Total execution time: 0.0194
INFO - 2021-08-07 20:05:49 --> Config Class Initialized
INFO - 2021-08-07 20:05:49 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:05:49 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:05:49 --> Utf8 Class Initialized
INFO - 2021-08-07 20:05:49 --> URI Class Initialized
INFO - 2021-08-07 20:05:49 --> Router Class Initialized
INFO - 2021-08-07 20:05:49 --> Output Class Initialized
INFO - 2021-08-07 20:05:49 --> Security Class Initialized
DEBUG - 2021-08-07 20:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:05:49 --> Input Class Initialized
INFO - 2021-08-07 20:05:49 --> Language Class Initialized
INFO - 2021-08-07 20:05:49 --> Loader Class Initialized
INFO - 2021-08-07 20:05:49 --> Helper loaded: url_helper
INFO - 2021-08-07 20:05:49 --> Helper loaded: file_helper
INFO - 2021-08-07 20:05:49 --> Database Driver Class Initialized
DEBUG - 2021-08-07 20:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 20:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 20:05:49 --> Controller Class Initialized
INFO - 2021-08-07 20:05:49 --> Helper loaded: cookie_helper
INFO - 2021-08-07 20:05:49 --> Model "CookieModel" initialized
INFO - 2021-08-07 20:05:49 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 20:05:49 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/pilates.php
INFO - 2021-08-07 20:05:49 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 20:05:49 --> Final output sent to browser
DEBUG - 2021-08-07 20:05:49 --> Total execution time: 0.0185
INFO - 2021-08-07 20:07:26 --> Config Class Initialized
INFO - 2021-08-07 20:07:26 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:07:26 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:07:26 --> Utf8 Class Initialized
INFO - 2021-08-07 20:07:26 --> URI Class Initialized
INFO - 2021-08-07 20:07:26 --> Router Class Initialized
INFO - 2021-08-07 20:07:26 --> Output Class Initialized
INFO - 2021-08-07 20:07:26 --> Security Class Initialized
DEBUG - 2021-08-07 20:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:07:26 --> Input Class Initialized
INFO - 2021-08-07 20:07:26 --> Language Class Initialized
INFO - 2021-08-07 20:07:26 --> Loader Class Initialized
INFO - 2021-08-07 20:07:26 --> Helper loaded: url_helper
INFO - 2021-08-07 20:07:26 --> Helper loaded: file_helper
INFO - 2021-08-07 20:07:26 --> Database Driver Class Initialized
DEBUG - 2021-08-07 20:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 20:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 20:07:26 --> Controller Class Initialized
INFO - 2021-08-07 20:07:26 --> Helper loaded: cookie_helper
INFO - 2021-08-07 20:07:26 --> Model "CookieModel" initialized
INFO - 2021-08-07 20:07:26 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 20:07:26 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/pilates.php
INFO - 2021-08-07 20:07:26 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 20:07:26 --> Final output sent to browser
DEBUG - 2021-08-07 20:07:26 --> Total execution time: 0.0192
INFO - 2021-08-07 20:10:34 --> Config Class Initialized
INFO - 2021-08-07 20:10:34 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:10:34 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:10:34 --> Utf8 Class Initialized
INFO - 2021-08-07 20:10:34 --> URI Class Initialized
INFO - 2021-08-07 20:10:34 --> Router Class Initialized
INFO - 2021-08-07 20:10:34 --> Output Class Initialized
INFO - 2021-08-07 20:10:34 --> Security Class Initialized
DEBUG - 2021-08-07 20:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:10:34 --> Input Class Initialized
INFO - 2021-08-07 20:10:34 --> Language Class Initialized
INFO - 2021-08-07 20:10:34 --> Loader Class Initialized
INFO - 2021-08-07 20:10:34 --> Helper loaded: url_helper
INFO - 2021-08-07 20:10:34 --> Helper loaded: file_helper
INFO - 2021-08-07 20:10:34 --> Database Driver Class Initialized
DEBUG - 2021-08-07 20:10:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 20:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 20:10:34 --> Controller Class Initialized
INFO - 2021-08-07 20:10:34 --> Helper loaded: cookie_helper
INFO - 2021-08-07 20:10:34 --> Model "CookieModel" initialized
INFO - 2021-08-07 20:10:34 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 20:10:34 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/gallery.php
INFO - 2021-08-07 20:10:34 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 20:10:34 --> Final output sent to browser
DEBUG - 2021-08-07 20:10:34 --> Total execution time: 0.0204
INFO - 2021-08-07 20:12:03 --> Config Class Initialized
INFO - 2021-08-07 20:12:03 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:12:03 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:12:03 --> Utf8 Class Initialized
INFO - 2021-08-07 20:12:03 --> URI Class Initialized
DEBUG - 2021-08-07 20:12:03 --> No URI present. Default controller set.
INFO - 2021-08-07 20:12:03 --> Router Class Initialized
INFO - 2021-08-07 20:12:03 --> Output Class Initialized
INFO - 2021-08-07 20:12:03 --> Security Class Initialized
DEBUG - 2021-08-07 20:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:12:03 --> Input Class Initialized
INFO - 2021-08-07 20:12:03 --> Language Class Initialized
INFO - 2021-08-07 20:12:03 --> Loader Class Initialized
INFO - 2021-08-07 20:12:03 --> Helper loaded: url_helper
INFO - 2021-08-07 20:12:03 --> Helper loaded: file_helper
INFO - 2021-08-07 20:12:03 --> Database Driver Class Initialized
DEBUG - 2021-08-07 20:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 20:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 20:12:03 --> Controller Class Initialized
INFO - 2021-08-07 20:12:03 --> Helper loaded: cookie_helper
INFO - 2021-08-07 20:12:03 --> Model "CookieModel" initialized
INFO - 2021-08-07 20:12:03 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 20:12:03 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/index.php
INFO - 2021-08-07 20:12:03 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 20:12:03 --> Final output sent to browser
DEBUG - 2021-08-07 20:12:03 --> Total execution time: 0.0185
INFO - 2021-08-07 20:12:15 --> Config Class Initialized
INFO - 2021-08-07 20:12:15 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:12:15 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:12:15 --> Utf8 Class Initialized
INFO - 2021-08-07 20:12:15 --> URI Class Initialized
DEBUG - 2021-08-07 20:12:15 --> No URI present. Default controller set.
INFO - 2021-08-07 20:12:15 --> Router Class Initialized
INFO - 2021-08-07 20:12:15 --> Output Class Initialized
INFO - 2021-08-07 20:12:15 --> Security Class Initialized
DEBUG - 2021-08-07 20:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:12:15 --> Input Class Initialized
INFO - 2021-08-07 20:12:15 --> Language Class Initialized
INFO - 2021-08-07 20:12:15 --> Loader Class Initialized
INFO - 2021-08-07 20:12:15 --> Helper loaded: url_helper
INFO - 2021-08-07 20:12:15 --> Helper loaded: file_helper
INFO - 2021-08-07 20:12:15 --> Database Driver Class Initialized
DEBUG - 2021-08-07 20:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 20:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 20:12:15 --> Controller Class Initialized
INFO - 2021-08-07 20:12:15 --> Helper loaded: cookie_helper
INFO - 2021-08-07 20:12:15 --> Model "CookieModel" initialized
INFO - 2021-08-07 20:12:15 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 20:12:15 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/index.php
INFO - 2021-08-07 20:12:15 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 20:12:15 --> Final output sent to browser
DEBUG - 2021-08-07 20:12:15 --> Total execution time: 0.0187
INFO - 2021-08-07 20:12:19 --> Config Class Initialized
INFO - 2021-08-07 20:12:19 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:12:19 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:12:19 --> Utf8 Class Initialized
INFO - 2021-08-07 20:12:19 --> URI Class Initialized
DEBUG - 2021-08-07 20:12:19 --> No URI present. Default controller set.
INFO - 2021-08-07 20:12:19 --> Router Class Initialized
INFO - 2021-08-07 20:12:19 --> Output Class Initialized
INFO - 2021-08-07 20:12:19 --> Security Class Initialized
DEBUG - 2021-08-07 20:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:12:19 --> Input Class Initialized
INFO - 2021-08-07 20:12:19 --> Language Class Initialized
INFO - 2021-08-07 20:12:19 --> Loader Class Initialized
INFO - 2021-08-07 20:12:19 --> Helper loaded: url_helper
INFO - 2021-08-07 20:12:19 --> Helper loaded: file_helper
INFO - 2021-08-07 20:12:19 --> Database Driver Class Initialized
DEBUG - 2021-08-07 20:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 20:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 20:12:19 --> Controller Class Initialized
INFO - 2021-08-07 20:12:19 --> Helper loaded: cookie_helper
INFO - 2021-08-07 20:12:19 --> Model "CookieModel" initialized
INFO - 2021-08-07 20:12:19 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 20:12:19 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/index.php
INFO - 2021-08-07 20:12:19 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 20:12:19 --> Final output sent to browser
DEBUG - 2021-08-07 20:12:19 --> Total execution time: 0.0183
INFO - 2021-08-07 20:17:52 --> Config Class Initialized
INFO - 2021-08-07 20:17:52 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:17:52 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:17:52 --> Utf8 Class Initialized
INFO - 2021-08-07 20:17:52 --> URI Class Initialized
INFO - 2021-08-07 20:17:52 --> Router Class Initialized
INFO - 2021-08-07 20:17:52 --> Output Class Initialized
INFO - 2021-08-07 20:17:52 --> Security Class Initialized
DEBUG - 2021-08-07 20:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:17:52 --> Input Class Initialized
INFO - 2021-08-07 20:17:52 --> Language Class Initialized
INFO - 2021-08-07 20:17:52 --> Loader Class Initialized
INFO - 2021-08-07 20:17:52 --> Helper loaded: url_helper
INFO - 2021-08-07 20:17:52 --> Helper loaded: file_helper
INFO - 2021-08-07 20:17:52 --> Database Driver Class Initialized
DEBUG - 2021-08-07 20:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 20:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 20:17:52 --> Controller Class Initialized
INFO - 2021-08-07 20:17:52 --> Helper loaded: cookie_helper
INFO - 2021-08-07 20:17:52 --> Model "CookieModel" initialized
INFO - 2021-08-07 20:17:52 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 20:17:52 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/team.php
INFO - 2021-08-07 20:17:52 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 20:17:52 --> Final output sent to browser
DEBUG - 2021-08-07 20:17:52 --> Total execution time: 0.0210
INFO - 2021-08-07 20:19:00 --> Config Class Initialized
INFO - 2021-08-07 20:19:00 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:19:00 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:19:00 --> Utf8 Class Initialized
INFO - 2021-08-07 20:19:00 --> URI Class Initialized
INFO - 2021-08-07 20:19:00 --> Router Class Initialized
INFO - 2021-08-07 20:19:00 --> Output Class Initialized
INFO - 2021-08-07 20:19:00 --> Security Class Initialized
DEBUG - 2021-08-07 20:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:19:00 --> Input Class Initialized
INFO - 2021-08-07 20:19:00 --> Language Class Initialized
INFO - 2021-08-07 20:19:00 --> Loader Class Initialized
INFO - 2021-08-07 20:19:00 --> Helper loaded: url_helper
INFO - 2021-08-07 20:19:00 --> Helper loaded: file_helper
INFO - 2021-08-07 20:19:00 --> Database Driver Class Initialized
DEBUG - 2021-08-07 20:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 20:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 20:19:00 --> Controller Class Initialized
INFO - 2021-08-07 20:19:00 --> Helper loaded: cookie_helper
INFO - 2021-08-07 20:19:00 --> Model "CookieModel" initialized
INFO - 2021-08-07 20:19:00 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 20:19:00 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/about.php
INFO - 2021-08-07 20:19:00 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 20:19:00 --> Final output sent to browser
DEBUG - 2021-08-07 20:19:00 --> Total execution time: 0.0198
INFO - 2021-08-07 20:19:05 --> Config Class Initialized
INFO - 2021-08-07 20:19:05 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:19:05 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:19:05 --> Utf8 Class Initialized
INFO - 2021-08-07 20:19:05 --> URI Class Initialized
INFO - 2021-08-07 20:19:05 --> Router Class Initialized
INFO - 2021-08-07 20:19:05 --> Output Class Initialized
INFO - 2021-08-07 20:19:05 --> Security Class Initialized
DEBUG - 2021-08-07 20:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:19:05 --> Input Class Initialized
INFO - 2021-08-07 20:19:05 --> Language Class Initialized
INFO - 2021-08-07 20:19:05 --> Loader Class Initialized
INFO - 2021-08-07 20:19:05 --> Helper loaded: url_helper
INFO - 2021-08-07 20:19:05 --> Helper loaded: file_helper
INFO - 2021-08-07 20:19:05 --> Database Driver Class Initialized
DEBUG - 2021-08-07 20:19:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 20:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 20:19:05 --> Controller Class Initialized
INFO - 2021-08-07 20:19:05 --> Helper loaded: cookie_helper
INFO - 2021-08-07 20:19:05 --> Model "CookieModel" initialized
INFO - 2021-08-07 20:19:05 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 20:19:05 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/about.php
INFO - 2021-08-07 20:19:05 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 20:19:05 --> Final output sent to browser
DEBUG - 2021-08-07 20:19:05 --> Total execution time: 0.0187
INFO - 2021-08-07 20:19:07 --> Config Class Initialized
INFO - 2021-08-07 20:19:07 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:19:07 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:19:07 --> Utf8 Class Initialized
INFO - 2021-08-07 20:19:07 --> URI Class Initialized
INFO - 2021-08-07 20:19:07 --> Router Class Initialized
INFO - 2021-08-07 20:19:07 --> Output Class Initialized
INFO - 2021-08-07 20:19:07 --> Security Class Initialized
DEBUG - 2021-08-07 20:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:19:07 --> Input Class Initialized
INFO - 2021-08-07 20:19:07 --> Language Class Initialized
INFO - 2021-08-07 20:19:07 --> Loader Class Initialized
INFO - 2021-08-07 20:19:07 --> Helper loaded: url_helper
INFO - 2021-08-07 20:19:07 --> Helper loaded: file_helper
INFO - 2021-08-07 20:19:07 --> Database Driver Class Initialized
DEBUG - 2021-08-07 20:19:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 20:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 20:19:07 --> Controller Class Initialized
INFO - 2021-08-07 20:19:07 --> Helper loaded: cookie_helper
INFO - 2021-08-07 20:19:07 --> Model "CookieModel" initialized
INFO - 2021-08-07 20:19:07 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 20:19:07 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/team.php
INFO - 2021-08-07 20:19:07 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 20:19:07 --> Final output sent to browser
DEBUG - 2021-08-07 20:19:07 --> Total execution time: 0.0189
INFO - 2021-08-07 20:19:18 --> Config Class Initialized
INFO - 2021-08-07 20:19:18 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:19:18 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:19:18 --> Utf8 Class Initialized
INFO - 2021-08-07 20:19:18 --> URI Class Initialized
INFO - 2021-08-07 20:19:18 --> Router Class Initialized
INFO - 2021-08-07 20:19:18 --> Output Class Initialized
INFO - 2021-08-07 20:19:18 --> Security Class Initialized
DEBUG - 2021-08-07 20:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:19:18 --> Input Class Initialized
INFO - 2021-08-07 20:19:18 --> Language Class Initialized
INFO - 2021-08-07 20:19:18 --> Loader Class Initialized
INFO - 2021-08-07 20:19:18 --> Helper loaded: url_helper
INFO - 2021-08-07 20:19:18 --> Helper loaded: file_helper
INFO - 2021-08-07 20:19:18 --> Database Driver Class Initialized
DEBUG - 2021-08-07 20:19:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 20:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 20:19:18 --> Controller Class Initialized
INFO - 2021-08-07 20:19:18 --> Helper loaded: cookie_helper
INFO - 2021-08-07 20:19:18 --> Model "CookieModel" initialized
INFO - 2021-08-07 20:19:18 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 20:19:18 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/success_stories.php
INFO - 2021-08-07 20:19:18 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 20:19:18 --> Final output sent to browser
DEBUG - 2021-08-07 20:19:18 --> Total execution time: 0.0200
INFO - 2021-08-07 20:21:59 --> Config Class Initialized
INFO - 2021-08-07 20:21:59 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:21:59 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:21:59 --> Utf8 Class Initialized
INFO - 2021-08-07 20:21:59 --> URI Class Initialized
INFO - 2021-08-07 20:21:59 --> Router Class Initialized
INFO - 2021-08-07 20:21:59 --> Output Class Initialized
INFO - 2021-08-07 20:21:59 --> Security Class Initialized
DEBUG - 2021-08-07 20:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:21:59 --> Input Class Initialized
INFO - 2021-08-07 20:21:59 --> Language Class Initialized
INFO - 2021-08-07 20:21:59 --> Loader Class Initialized
INFO - 2021-08-07 20:21:59 --> Helper loaded: url_helper
INFO - 2021-08-07 20:21:59 --> Helper loaded: file_helper
INFO - 2021-08-07 20:21:59 --> Database Driver Class Initialized
DEBUG - 2021-08-07 20:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 20:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 20:21:59 --> Controller Class Initialized
INFO - 2021-08-07 20:21:59 --> Helper loaded: cookie_helper
INFO - 2021-08-07 20:21:59 --> Model "CookieModel" initialized
INFO - 2021-08-07 20:21:59 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 20:21:59 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/success_stories.php
INFO - 2021-08-07 20:21:59 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 20:21:59 --> Final output sent to browser
DEBUG - 2021-08-07 20:21:59 --> Total execution time: 0.0195
INFO - 2021-08-07 20:23:53 --> Config Class Initialized
INFO - 2021-08-07 20:23:53 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:23:53 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:23:53 --> Utf8 Class Initialized
INFO - 2021-08-07 20:23:53 --> URI Class Initialized
DEBUG - 2021-08-07 20:23:53 --> No URI present. Default controller set.
INFO - 2021-08-07 20:23:53 --> Router Class Initialized
INFO - 2021-08-07 20:23:53 --> Output Class Initialized
INFO - 2021-08-07 20:23:53 --> Security Class Initialized
DEBUG - 2021-08-07 20:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:23:53 --> Input Class Initialized
INFO - 2021-08-07 20:23:53 --> Language Class Initialized
INFO - 2021-08-07 20:23:53 --> Loader Class Initialized
INFO - 2021-08-07 20:23:53 --> Helper loaded: url_helper
INFO - 2021-08-07 20:23:53 --> Helper loaded: file_helper
INFO - 2021-08-07 20:23:53 --> Database Driver Class Initialized
DEBUG - 2021-08-07 20:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 20:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 20:23:53 --> Controller Class Initialized
INFO - 2021-08-07 20:23:53 --> Helper loaded: cookie_helper
INFO - 2021-08-07 20:23:53 --> Model "CookieModel" initialized
INFO - 2021-08-07 20:23:53 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 20:23:53 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/index.php
INFO - 2021-08-07 20:23:53 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 20:23:53 --> Final output sent to browser
DEBUG - 2021-08-07 20:23:53 --> Total execution time: 0.0186
INFO - 2021-08-07 20:23:57 --> Config Class Initialized
INFO - 2021-08-07 20:23:57 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:23:57 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:23:57 --> Utf8 Class Initialized
INFO - 2021-08-07 20:23:57 --> URI Class Initialized
DEBUG - 2021-08-07 20:23:57 --> No URI present. Default controller set.
INFO - 2021-08-07 20:23:57 --> Router Class Initialized
INFO - 2021-08-07 20:23:57 --> Output Class Initialized
INFO - 2021-08-07 20:23:57 --> Security Class Initialized
DEBUG - 2021-08-07 20:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:23:57 --> Input Class Initialized
INFO - 2021-08-07 20:23:57 --> Language Class Initialized
INFO - 2021-08-07 20:23:57 --> Loader Class Initialized
INFO - 2021-08-07 20:23:57 --> Helper loaded: url_helper
INFO - 2021-08-07 20:23:57 --> Helper loaded: file_helper
INFO - 2021-08-07 20:23:57 --> Database Driver Class Initialized
DEBUG - 2021-08-07 20:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 20:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 20:23:57 --> Controller Class Initialized
INFO - 2021-08-07 20:23:57 --> Helper loaded: cookie_helper
INFO - 2021-08-07 20:23:57 --> Model "CookieModel" initialized
INFO - 2021-08-07 20:23:57 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 20:23:57 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/index.php
INFO - 2021-08-07 20:23:57 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 20:23:57 --> Final output sent to browser
DEBUG - 2021-08-07 20:23:57 --> Total execution time: 0.0189
INFO - 2021-08-07 20:24:22 --> Config Class Initialized
INFO - 2021-08-07 20:24:22 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:24:22 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:24:22 --> Utf8 Class Initialized
INFO - 2021-08-07 20:24:22 --> URI Class Initialized
INFO - 2021-08-07 20:24:22 --> Router Class Initialized
INFO - 2021-08-07 20:24:22 --> Output Class Initialized
INFO - 2021-08-07 20:24:22 --> Security Class Initialized
DEBUG - 2021-08-07 20:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:24:22 --> Input Class Initialized
INFO - 2021-08-07 20:24:22 --> Language Class Initialized
INFO - 2021-08-07 20:24:22 --> Loader Class Initialized
INFO - 2021-08-07 20:24:22 --> Helper loaded: url_helper
INFO - 2021-08-07 20:24:22 --> Helper loaded: file_helper
INFO - 2021-08-07 20:24:22 --> Database Driver Class Initialized
DEBUG - 2021-08-07 20:24:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 20:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 20:24:22 --> Controller Class Initialized
INFO - 2021-08-07 20:24:22 --> Helper loaded: cookie_helper
INFO - 2021-08-07 20:24:22 --> Model "CookieModel" initialized
INFO - 2021-08-07 20:24:22 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 20:24:22 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/pilates.php
INFO - 2021-08-07 20:24:22 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 20:24:22 --> Final output sent to browser
DEBUG - 2021-08-07 20:24:22 --> Total execution time: 0.0187
INFO - 2021-08-07 20:24:24 --> Config Class Initialized
INFO - 2021-08-07 20:24:24 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:24:24 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:24:24 --> Utf8 Class Initialized
INFO - 2021-08-07 20:24:24 --> URI Class Initialized
INFO - 2021-08-07 20:24:24 --> Router Class Initialized
INFO - 2021-08-07 20:24:24 --> Output Class Initialized
INFO - 2021-08-07 20:24:24 --> Security Class Initialized
DEBUG - 2021-08-07 20:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:24:24 --> Input Class Initialized
INFO - 2021-08-07 20:24:24 --> Language Class Initialized
INFO - 2021-08-07 20:24:24 --> Loader Class Initialized
INFO - 2021-08-07 20:24:24 --> Helper loaded: url_helper
INFO - 2021-08-07 20:24:24 --> Helper loaded: file_helper
INFO - 2021-08-07 20:24:24 --> Database Driver Class Initialized
DEBUG - 2021-08-07 20:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 20:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 20:24:24 --> Controller Class Initialized
INFO - 2021-08-07 20:24:24 --> Helper loaded: cookie_helper
INFO - 2021-08-07 20:24:24 --> Model "CookieModel" initialized
INFO - 2021-08-07 20:24:24 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 20:24:24 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/services.php
INFO - 2021-08-07 20:24:24 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 20:24:24 --> Final output sent to browser
DEBUG - 2021-08-07 20:24:24 --> Total execution time: 0.0179
INFO - 2021-08-07 20:24:25 --> Config Class Initialized
INFO - 2021-08-07 20:24:26 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:24:26 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:24:26 --> Utf8 Class Initialized
INFO - 2021-08-07 20:24:26 --> URI Class Initialized
INFO - 2021-08-07 20:24:26 --> Router Class Initialized
INFO - 2021-08-07 20:24:26 --> Output Class Initialized
INFO - 2021-08-07 20:24:26 --> Security Class Initialized
DEBUG - 2021-08-07 20:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:24:26 --> Input Class Initialized
INFO - 2021-08-07 20:24:26 --> Language Class Initialized
INFO - 2021-08-07 20:24:26 --> Loader Class Initialized
INFO - 2021-08-07 20:24:26 --> Helper loaded: url_helper
INFO - 2021-08-07 20:24:26 --> Helper loaded: file_helper
INFO - 2021-08-07 20:24:26 --> Database Driver Class Initialized
DEBUG - 2021-08-07 20:24:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 20:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 20:24:26 --> Controller Class Initialized
INFO - 2021-08-07 20:24:26 --> Helper loaded: cookie_helper
INFO - 2021-08-07 20:24:26 --> Model "CookieModel" initialized
INFO - 2021-08-07 20:24:26 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 20:24:26 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/services.php
INFO - 2021-08-07 20:24:26 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 20:24:26 --> Final output sent to browser
DEBUG - 2021-08-07 20:24:26 --> Total execution time: 0.0187
INFO - 2021-08-07 20:24:27 --> Config Class Initialized
INFO - 2021-08-07 20:24:27 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:24:27 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:24:27 --> Utf8 Class Initialized
INFO - 2021-08-07 20:24:27 --> URI Class Initialized
INFO - 2021-08-07 20:24:27 --> Router Class Initialized
INFO - 2021-08-07 20:24:27 --> Output Class Initialized
INFO - 2021-08-07 20:24:27 --> Security Class Initialized
DEBUG - 2021-08-07 20:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:24:27 --> Input Class Initialized
INFO - 2021-08-07 20:24:27 --> Language Class Initialized
INFO - 2021-08-07 20:24:27 --> Loader Class Initialized
INFO - 2021-08-07 20:24:27 --> Helper loaded: url_helper
INFO - 2021-08-07 20:24:27 --> Helper loaded: file_helper
INFO - 2021-08-07 20:24:27 --> Database Driver Class Initialized
DEBUG - 2021-08-07 20:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 20:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 20:24:27 --> Controller Class Initialized
INFO - 2021-08-07 20:24:27 --> Helper loaded: cookie_helper
INFO - 2021-08-07 20:24:27 --> Model "CookieModel" initialized
INFO - 2021-08-07 20:24:27 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 20:24:27 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/success_stories.php
INFO - 2021-08-07 20:24:27 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 20:24:27 --> Final output sent to browser
DEBUG - 2021-08-07 20:24:27 --> Total execution time: 0.0191
INFO - 2021-08-07 20:24:28 --> Config Class Initialized
INFO - 2021-08-07 20:24:28 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:24:28 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:24:28 --> Utf8 Class Initialized
INFO - 2021-08-07 20:24:28 --> URI Class Initialized
DEBUG - 2021-08-07 20:24:28 --> No URI present. Default controller set.
INFO - 2021-08-07 20:24:28 --> Router Class Initialized
INFO - 2021-08-07 20:24:28 --> Output Class Initialized
INFO - 2021-08-07 20:24:28 --> Security Class Initialized
DEBUG - 2021-08-07 20:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:24:28 --> Input Class Initialized
INFO - 2021-08-07 20:24:28 --> Language Class Initialized
INFO - 2021-08-07 20:24:28 --> Loader Class Initialized
INFO - 2021-08-07 20:24:28 --> Helper loaded: url_helper
INFO - 2021-08-07 20:24:28 --> Helper loaded: file_helper
INFO - 2021-08-07 20:24:28 --> Database Driver Class Initialized
DEBUG - 2021-08-07 20:24:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 20:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 20:24:28 --> Controller Class Initialized
INFO - 2021-08-07 20:24:28 --> Helper loaded: cookie_helper
INFO - 2021-08-07 20:24:28 --> Model "CookieModel" initialized
INFO - 2021-08-07 20:24:28 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 20:24:28 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/index.php
INFO - 2021-08-07 20:24:28 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 20:24:28 --> Final output sent to browser
DEBUG - 2021-08-07 20:24:28 --> Total execution time: 0.0244
INFO - 2021-08-07 20:29:50 --> Config Class Initialized
INFO - 2021-08-07 20:29:50 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:29:50 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:29:50 --> Utf8 Class Initialized
INFO - 2021-08-07 20:29:50 --> URI Class Initialized
INFO - 2021-08-07 20:29:50 --> Router Class Initialized
INFO - 2021-08-07 20:29:50 --> Output Class Initialized
INFO - 2021-08-07 20:29:50 --> Security Class Initialized
DEBUG - 2021-08-07 20:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:29:50 --> Input Class Initialized
INFO - 2021-08-07 20:29:50 --> Language Class Initialized
INFO - 2021-08-07 20:29:50 --> Loader Class Initialized
INFO - 2021-08-07 20:29:50 --> Helper loaded: url_helper
INFO - 2021-08-07 20:29:50 --> Helper loaded: file_helper
INFO - 2021-08-07 20:29:50 --> Database Driver Class Initialized
DEBUG - 2021-08-07 20:29:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 20:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 20:29:50 --> Controller Class Initialized
INFO - 2021-08-07 20:29:50 --> Helper loaded: cookie_helper
INFO - 2021-08-07 20:29:50 --> Model "CookieModel" initialized
INFO - 2021-08-07 20:29:50 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 20:29:50 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/pilates.php
INFO - 2021-08-07 20:29:50 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 20:29:50 --> Final output sent to browser
DEBUG - 2021-08-07 20:29:50 --> Total execution time: 0.0204
INFO - 2021-08-07 20:30:15 --> Config Class Initialized
INFO - 2021-08-07 20:30:15 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:30:15 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:30:15 --> Utf8 Class Initialized
INFO - 2021-08-07 20:30:15 --> URI Class Initialized
DEBUG - 2021-08-07 20:30:15 --> No URI present. Default controller set.
INFO - 2021-08-07 20:30:15 --> Router Class Initialized
INFO - 2021-08-07 20:30:15 --> Output Class Initialized
INFO - 2021-08-07 20:30:15 --> Security Class Initialized
DEBUG - 2021-08-07 20:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:30:15 --> Input Class Initialized
INFO - 2021-08-07 20:30:15 --> Language Class Initialized
INFO - 2021-08-07 20:30:15 --> Loader Class Initialized
INFO - 2021-08-07 20:30:15 --> Helper loaded: url_helper
INFO - 2021-08-07 20:30:15 --> Helper loaded: file_helper
INFO - 2021-08-07 20:30:15 --> Database Driver Class Initialized
DEBUG - 2021-08-07 20:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 20:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 20:30:15 --> Controller Class Initialized
INFO - 2021-08-07 20:30:15 --> Helper loaded: cookie_helper
INFO - 2021-08-07 20:30:15 --> Model "CookieModel" initialized
INFO - 2021-08-07 20:30:15 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 20:30:15 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/index.php
INFO - 2021-08-07 20:30:15 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 20:30:15 --> Final output sent to browser
DEBUG - 2021-08-07 20:30:15 --> Total execution time: 0.0251
INFO - 2021-08-07 20:30:33 --> Config Class Initialized
INFO - 2021-08-07 20:30:33 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:30:33 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:30:33 --> Utf8 Class Initialized
INFO - 2021-08-07 20:30:33 --> URI Class Initialized
DEBUG - 2021-08-07 20:30:33 --> No URI present. Default controller set.
INFO - 2021-08-07 20:30:33 --> Router Class Initialized
INFO - 2021-08-07 20:30:33 --> Output Class Initialized
INFO - 2021-08-07 20:30:33 --> Security Class Initialized
DEBUG - 2021-08-07 20:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:30:33 --> Input Class Initialized
INFO - 2021-08-07 20:30:33 --> Language Class Initialized
INFO - 2021-08-07 20:30:33 --> Loader Class Initialized
INFO - 2021-08-07 20:30:33 --> Helper loaded: url_helper
INFO - 2021-08-07 20:30:33 --> Helper loaded: file_helper
INFO - 2021-08-07 20:30:33 --> Database Driver Class Initialized
DEBUG - 2021-08-07 20:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 20:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 20:30:33 --> Controller Class Initialized
INFO - 2021-08-07 20:30:33 --> Helper loaded: cookie_helper
INFO - 2021-08-07 20:30:33 --> Model "CookieModel" initialized
INFO - 2021-08-07 20:30:33 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 20:30:33 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/index.php
INFO - 2021-08-07 20:30:33 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 20:30:33 --> Final output sent to browser
DEBUG - 2021-08-07 20:30:33 --> Total execution time: 0.0185
INFO - 2021-08-07 20:30:33 --> Config Class Initialized
INFO - 2021-08-07 20:30:33 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:30:33 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:30:33 --> Utf8 Class Initialized
INFO - 2021-08-07 20:30:33 --> URI Class Initialized
INFO - 2021-08-07 20:30:33 --> Router Class Initialized
INFO - 2021-08-07 20:30:33 --> Output Class Initialized
INFO - 2021-08-07 20:30:33 --> Security Class Initialized
DEBUG - 2021-08-07 20:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:30:33 --> Input Class Initialized
INFO - 2021-08-07 20:30:33 --> Language Class Initialized
ERROR - 2021-08-07 20:30:33 --> 404 Page Not Found: Faviconico/index
INFO - 2021-08-07 20:30:48 --> Config Class Initialized
INFO - 2021-08-07 20:30:48 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:30:48 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:30:48 --> Utf8 Class Initialized
INFO - 2021-08-07 20:30:48 --> URI Class Initialized
INFO - 2021-08-07 20:30:48 --> Router Class Initialized
INFO - 2021-08-07 20:30:48 --> Output Class Initialized
INFO - 2021-08-07 20:30:48 --> Security Class Initialized
DEBUG - 2021-08-07 20:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:30:48 --> Input Class Initialized
INFO - 2021-08-07 20:30:48 --> Language Class Initialized
INFO - 2021-08-07 20:30:48 --> Config Class Initialized
ERROR - 2021-08-07 20:30:48 --> 404 Page Not Found: Assets/js
INFO - 2021-08-07 20:30:48 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:30:48 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:30:48 --> Utf8 Class Initialized
INFO - 2021-08-07 20:30:48 --> URI Class Initialized
INFO - 2021-08-07 20:30:48 --> Router Class Initialized
INFO - 2021-08-07 20:30:48 --> Output Class Initialized
INFO - 2021-08-07 20:30:48 --> Security Class Initialized
DEBUG - 2021-08-07 20:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:30:48 --> Input Class Initialized
INFO - 2021-08-07 20:30:48 --> Language Class Initialized
ERROR - 2021-08-07 20:30:48 --> 404 Page Not Found: Assets/js
INFO - 2021-08-07 20:30:48 --> Config Class Initialized
INFO - 2021-08-07 20:30:48 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:30:48 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:30:48 --> Utf8 Class Initialized
INFO - 2021-08-07 20:30:48 --> URI Class Initialized
INFO - 2021-08-07 20:30:48 --> Router Class Initialized
INFO - 2021-08-07 20:30:48 --> Output Class Initialized
INFO - 2021-08-07 20:30:48 --> Security Class Initialized
DEBUG - 2021-08-07 20:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:30:48 --> Input Class Initialized
INFO - 2021-08-07 20:30:48 --> Language Class Initialized
ERROR - 2021-08-07 20:30:48 --> 404 Page Not Found: Assets/js
INFO - 2021-08-07 20:30:48 --> Config Class Initialized
INFO - 2021-08-07 20:30:48 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:30:48 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:30:48 --> Utf8 Class Initialized
INFO - 2021-08-07 20:30:48 --> URI Class Initialized
INFO - 2021-08-07 20:30:48 --> Router Class Initialized
INFO - 2021-08-07 20:30:48 --> Output Class Initialized
INFO - 2021-08-07 20:30:48 --> Security Class Initialized
DEBUG - 2021-08-07 20:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:30:48 --> Input Class Initialized
INFO - 2021-08-07 20:30:48 --> Language Class Initialized
ERROR - 2021-08-07 20:30:48 --> 404 Page Not Found: Assets/css
INFO - 2021-08-07 20:30:48 --> Config Class Initialized
INFO - 2021-08-07 20:30:48 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:30:48 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:30:48 --> Utf8 Class Initialized
INFO - 2021-08-07 20:30:48 --> URI Class Initialized
INFO - 2021-08-07 20:30:48 --> Router Class Initialized
INFO - 2021-08-07 20:30:48 --> Output Class Initialized
INFO - 2021-08-07 20:30:48 --> Security Class Initialized
DEBUG - 2021-08-07 20:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:30:48 --> Input Class Initialized
INFO - 2021-08-07 20:30:48 --> Language Class Initialized
ERROR - 2021-08-07 20:30:48 --> 404 Page Not Found: Assets/css
INFO - 2021-08-07 20:33:13 --> Config Class Initialized
INFO - 2021-08-07 20:33:13 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:33:13 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:33:13 --> Utf8 Class Initialized
INFO - 2021-08-07 20:33:13 --> URI Class Initialized
DEBUG - 2021-08-07 20:33:13 --> No URI present. Default controller set.
INFO - 2021-08-07 20:33:13 --> Router Class Initialized
INFO - 2021-08-07 20:33:13 --> Output Class Initialized
INFO - 2021-08-07 20:33:13 --> Security Class Initialized
DEBUG - 2021-08-07 20:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:33:13 --> Input Class Initialized
INFO - 2021-08-07 20:33:13 --> Language Class Initialized
INFO - 2021-08-07 20:33:13 --> Loader Class Initialized
INFO - 2021-08-07 20:33:13 --> Helper loaded: url_helper
INFO - 2021-08-07 20:33:13 --> Helper loaded: file_helper
INFO - 2021-08-07 20:33:13 --> Database Driver Class Initialized
DEBUG - 2021-08-07 20:33:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 20:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 20:33:13 --> Controller Class Initialized
INFO - 2021-08-07 20:33:13 --> Helper loaded: cookie_helper
INFO - 2021-08-07 20:33:13 --> Model "CookieModel" initialized
INFO - 2021-08-07 20:33:13 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 20:33:13 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/index.php
INFO - 2021-08-07 20:33:13 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 20:33:13 --> Final output sent to browser
DEBUG - 2021-08-07 20:33:13 --> Total execution time: 0.0183
INFO - 2021-08-07 20:34:33 --> Config Class Initialized
INFO - 2021-08-07 20:34:33 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:34:33 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:34:33 --> Utf8 Class Initialized
INFO - 2021-08-07 20:34:33 --> URI Class Initialized
DEBUG - 2021-08-07 20:34:33 --> No URI present. Default controller set.
INFO - 2021-08-07 20:34:33 --> Router Class Initialized
INFO - 2021-08-07 20:34:33 --> Output Class Initialized
INFO - 2021-08-07 20:34:33 --> Security Class Initialized
DEBUG - 2021-08-07 20:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:34:33 --> Input Class Initialized
INFO - 2021-08-07 20:34:33 --> Language Class Initialized
INFO - 2021-08-07 20:34:33 --> Loader Class Initialized
INFO - 2021-08-07 20:34:33 --> Helper loaded: url_helper
INFO - 2021-08-07 20:34:33 --> Helper loaded: file_helper
INFO - 2021-08-07 20:34:33 --> Database Driver Class Initialized
DEBUG - 2021-08-07 20:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 20:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 20:34:33 --> Controller Class Initialized
INFO - 2021-08-07 20:34:33 --> Helper loaded: cookie_helper
INFO - 2021-08-07 20:34:33 --> Model "CookieModel" initialized
INFO - 2021-08-07 20:34:33 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 20:34:33 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/index.php
INFO - 2021-08-07 20:34:33 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 20:34:33 --> Final output sent to browser
DEBUG - 2021-08-07 20:34:33 --> Total execution time: 0.0194
INFO - 2021-08-07 20:38:21 --> Config Class Initialized
INFO - 2021-08-07 20:38:21 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:38:21 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:38:21 --> Utf8 Class Initialized
INFO - 2021-08-07 20:38:21 --> URI Class Initialized
DEBUG - 2021-08-07 20:38:21 --> No URI present. Default controller set.
INFO - 2021-08-07 20:38:21 --> Router Class Initialized
INFO - 2021-08-07 20:38:21 --> Output Class Initialized
INFO - 2021-08-07 20:38:21 --> Security Class Initialized
DEBUG - 2021-08-07 20:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:38:21 --> Input Class Initialized
INFO - 2021-08-07 20:38:21 --> Language Class Initialized
INFO - 2021-08-07 20:38:21 --> Loader Class Initialized
INFO - 2021-08-07 20:38:21 --> Helper loaded: url_helper
INFO - 2021-08-07 20:38:21 --> Helper loaded: file_helper
INFO - 2021-08-07 20:38:21 --> Database Driver Class Initialized
DEBUG - 2021-08-07 20:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 20:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 20:38:21 --> Controller Class Initialized
INFO - 2021-08-07 20:38:21 --> Helper loaded: cookie_helper
INFO - 2021-08-07 20:38:21 --> Model "CookieModel" initialized
INFO - 2021-08-07 20:38:21 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 20:38:21 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/index.php
INFO - 2021-08-07 20:38:21 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 20:38:21 --> Final output sent to browser
DEBUG - 2021-08-07 20:38:21 --> Total execution time: 0.0262
INFO - 2021-08-07 20:38:42 --> Config Class Initialized
INFO - 2021-08-07 20:38:42 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:38:42 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:38:42 --> Utf8 Class Initialized
INFO - 2021-08-07 20:38:42 --> URI Class Initialized
DEBUG - 2021-08-07 20:38:42 --> No URI present. Default controller set.
INFO - 2021-08-07 20:38:42 --> Router Class Initialized
INFO - 2021-08-07 20:38:42 --> Output Class Initialized
INFO - 2021-08-07 20:38:42 --> Security Class Initialized
DEBUG - 2021-08-07 20:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:38:42 --> Input Class Initialized
INFO - 2021-08-07 20:38:42 --> Language Class Initialized
INFO - 2021-08-07 20:38:42 --> Loader Class Initialized
INFO - 2021-08-07 20:38:42 --> Helper loaded: url_helper
INFO - 2021-08-07 20:38:42 --> Helper loaded: file_helper
INFO - 2021-08-07 20:38:42 --> Database Driver Class Initialized
DEBUG - 2021-08-07 20:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 20:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 20:38:42 --> Controller Class Initialized
INFO - 2021-08-07 20:38:42 --> Helper loaded: cookie_helper
INFO - 2021-08-07 20:38:42 --> Model "CookieModel" initialized
INFO - 2021-08-07 20:38:42 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 20:38:42 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/index.php
INFO - 2021-08-07 20:38:42 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 20:38:42 --> Final output sent to browser
DEBUG - 2021-08-07 20:38:42 --> Total execution time: 0.0248
INFO - 2021-08-07 20:38:59 --> Config Class Initialized
INFO - 2021-08-07 20:38:59 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:38:59 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:38:59 --> Utf8 Class Initialized
INFO - 2021-08-07 20:38:59 --> URI Class Initialized
DEBUG - 2021-08-07 20:38:59 --> No URI present. Default controller set.
INFO - 2021-08-07 20:38:59 --> Router Class Initialized
INFO - 2021-08-07 20:38:59 --> Output Class Initialized
INFO - 2021-08-07 20:38:59 --> Security Class Initialized
DEBUG - 2021-08-07 20:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:38:59 --> Input Class Initialized
INFO - 2021-08-07 20:38:59 --> Language Class Initialized
INFO - 2021-08-07 20:38:59 --> Loader Class Initialized
INFO - 2021-08-07 20:38:59 --> Helper loaded: url_helper
INFO - 2021-08-07 20:38:59 --> Helper loaded: file_helper
INFO - 2021-08-07 20:38:59 --> Database Driver Class Initialized
DEBUG - 2021-08-07 20:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 20:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 20:38:59 --> Controller Class Initialized
INFO - 2021-08-07 20:38:59 --> Helper loaded: cookie_helper
INFO - 2021-08-07 20:38:59 --> Model "CookieModel" initialized
INFO - 2021-08-07 20:38:59 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 20:38:59 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/index.php
INFO - 2021-08-07 20:38:59 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 20:38:59 --> Final output sent to browser
DEBUG - 2021-08-07 20:38:59 --> Total execution time: 0.0195
INFO - 2021-08-07 20:40:03 --> Config Class Initialized
INFO - 2021-08-07 20:40:03 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:40:03 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:40:03 --> Utf8 Class Initialized
INFO - 2021-08-07 20:40:03 --> URI Class Initialized
DEBUG - 2021-08-07 20:40:03 --> No URI present. Default controller set.
INFO - 2021-08-07 20:40:03 --> Router Class Initialized
INFO - 2021-08-07 20:40:03 --> Output Class Initialized
INFO - 2021-08-07 20:40:03 --> Security Class Initialized
DEBUG - 2021-08-07 20:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:40:03 --> Input Class Initialized
INFO - 2021-08-07 20:40:03 --> Language Class Initialized
INFO - 2021-08-07 20:40:03 --> Loader Class Initialized
INFO - 2021-08-07 20:40:03 --> Helper loaded: url_helper
INFO - 2021-08-07 20:40:03 --> Helper loaded: file_helper
INFO - 2021-08-07 20:40:03 --> Database Driver Class Initialized
DEBUG - 2021-08-07 20:40:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 20:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 20:40:03 --> Controller Class Initialized
INFO - 2021-08-07 20:40:03 --> Helper loaded: cookie_helper
INFO - 2021-08-07 20:40:03 --> Model "CookieModel" initialized
INFO - 2021-08-07 20:40:03 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 20:40:03 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/index.php
INFO - 2021-08-07 20:40:03 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 20:40:03 --> Final output sent to browser
DEBUG - 2021-08-07 20:40:03 --> Total execution time: 0.0263
INFO - 2021-08-07 20:41:03 --> Config Class Initialized
INFO - 2021-08-07 20:41:03 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:41:03 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:41:03 --> Utf8 Class Initialized
INFO - 2021-08-07 20:41:03 --> URI Class Initialized
INFO - 2021-08-07 20:41:03 --> Router Class Initialized
INFO - 2021-08-07 20:41:03 --> Output Class Initialized
INFO - 2021-08-07 20:41:03 --> Security Class Initialized
DEBUG - 2021-08-07 20:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:41:03 --> Input Class Initialized
INFO - 2021-08-07 20:41:03 --> Language Class Initialized
ERROR - 2021-08-07 20:41:03 --> 404 Page Not Found: Assets/js
INFO - 2021-08-07 20:41:03 --> Config Class Initialized
INFO - 2021-08-07 20:41:03 --> Hooks Class Initialized
INFO - 2021-08-07 20:41:03 --> Config Class Initialized
INFO - 2021-08-07 20:41:03 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:41:03 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:41:03 --> Utf8 Class Initialized
DEBUG - 2021-08-07 20:41:03 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:41:03 --> Utf8 Class Initialized
INFO - 2021-08-07 20:41:03 --> URI Class Initialized
INFO - 2021-08-07 20:41:03 --> URI Class Initialized
INFO - 2021-08-07 20:41:03 --> Router Class Initialized
INFO - 2021-08-07 20:41:03 --> Router Class Initialized
INFO - 2021-08-07 20:41:03 --> Output Class Initialized
INFO - 2021-08-07 20:41:03 --> Output Class Initialized
INFO - 2021-08-07 20:41:03 --> Security Class Initialized
INFO - 2021-08-07 20:41:03 --> Security Class Initialized
DEBUG - 2021-08-07 20:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:41:03 --> Input Class Initialized
INFO - 2021-08-07 20:41:03 --> Language Class Initialized
DEBUG - 2021-08-07 20:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:41:03 --> Input Class Initialized
INFO - 2021-08-07 20:41:03 --> Language Class Initialized
ERROR - 2021-08-07 20:41:03 --> 404 Page Not Found: Assets/js
ERROR - 2021-08-07 20:41:03 --> 404 Page Not Found: Assets/js
INFO - 2021-08-07 20:41:03 --> Config Class Initialized
INFO - 2021-08-07 20:41:03 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:41:03 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:41:03 --> Utf8 Class Initialized
INFO - 2021-08-07 20:41:03 --> URI Class Initialized
INFO - 2021-08-07 20:41:03 --> Router Class Initialized
INFO - 2021-08-07 20:41:03 --> Output Class Initialized
INFO - 2021-08-07 20:41:03 --> Security Class Initialized
DEBUG - 2021-08-07 20:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:41:03 --> Input Class Initialized
INFO - 2021-08-07 20:41:03 --> Language Class Initialized
ERROR - 2021-08-07 20:41:03 --> 404 Page Not Found: Assets/css
INFO - 2021-08-07 20:41:03 --> Config Class Initialized
INFO - 2021-08-07 20:41:03 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:41:03 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:41:03 --> Utf8 Class Initialized
INFO - 2021-08-07 20:41:03 --> URI Class Initialized
INFO - 2021-08-07 20:41:03 --> Router Class Initialized
INFO - 2021-08-07 20:41:03 --> Output Class Initialized
INFO - 2021-08-07 20:41:03 --> Security Class Initialized
DEBUG - 2021-08-07 20:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:41:03 --> Input Class Initialized
INFO - 2021-08-07 20:41:03 --> Language Class Initialized
ERROR - 2021-08-07 20:41:03 --> 404 Page Not Found: Assets/css
INFO - 2021-08-07 20:43:38 --> Config Class Initialized
INFO - 2021-08-07 20:43:38 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:43:38 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:43:38 --> Utf8 Class Initialized
INFO - 2021-08-07 20:43:38 --> URI Class Initialized
DEBUG - 2021-08-07 20:43:38 --> No URI present. Default controller set.
INFO - 2021-08-07 20:43:38 --> Router Class Initialized
INFO - 2021-08-07 20:43:38 --> Output Class Initialized
INFO - 2021-08-07 20:43:38 --> Security Class Initialized
DEBUG - 2021-08-07 20:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:43:38 --> Input Class Initialized
INFO - 2021-08-07 20:43:38 --> Language Class Initialized
INFO - 2021-08-07 20:43:38 --> Loader Class Initialized
INFO - 2021-08-07 20:43:38 --> Helper loaded: url_helper
INFO - 2021-08-07 20:43:38 --> Helper loaded: file_helper
INFO - 2021-08-07 20:43:38 --> Database Driver Class Initialized
DEBUG - 2021-08-07 20:43:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 20:43:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 20:43:38 --> Controller Class Initialized
INFO - 2021-08-07 20:43:38 --> Helper loaded: cookie_helper
INFO - 2021-08-07 20:43:38 --> Model "CookieModel" initialized
INFO - 2021-08-07 20:43:38 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 20:43:38 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/index.php
INFO - 2021-08-07 20:43:38 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 20:43:38 --> Final output sent to browser
DEBUG - 2021-08-07 20:43:38 --> Total execution time: 0.0196
INFO - 2021-08-07 20:59:56 --> Config Class Initialized
INFO - 2021-08-07 20:59:56 --> Hooks Class Initialized
DEBUG - 2021-08-07 20:59:56 --> UTF-8 Support Enabled
INFO - 2021-08-07 20:59:56 --> Utf8 Class Initialized
INFO - 2021-08-07 20:59:56 --> URI Class Initialized
DEBUG - 2021-08-07 20:59:56 --> No URI present. Default controller set.
INFO - 2021-08-07 20:59:56 --> Router Class Initialized
INFO - 2021-08-07 20:59:56 --> Output Class Initialized
INFO - 2021-08-07 20:59:56 --> Security Class Initialized
DEBUG - 2021-08-07 20:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 20:59:56 --> Input Class Initialized
INFO - 2021-08-07 20:59:56 --> Language Class Initialized
INFO - 2021-08-07 20:59:56 --> Loader Class Initialized
INFO - 2021-08-07 20:59:56 --> Helper loaded: url_helper
INFO - 2021-08-07 20:59:56 --> Helper loaded: file_helper
INFO - 2021-08-07 20:59:56 --> Database Driver Class Initialized
DEBUG - 2021-08-07 20:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 20:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 20:59:56 --> Controller Class Initialized
INFO - 2021-08-07 20:59:56 --> Helper loaded: cookie_helper
INFO - 2021-08-07 20:59:56 --> Model "CookieModel" initialized
INFO - 2021-08-07 20:59:56 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 20:59:56 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/index.php
INFO - 2021-08-07 20:59:56 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 20:59:56 --> Final output sent to browser
DEBUG - 2021-08-07 20:59:56 --> Total execution time: 0.0194
INFO - 2021-08-07 21:04:13 --> Config Class Initialized
INFO - 2021-08-07 21:04:13 --> Hooks Class Initialized
DEBUG - 2021-08-07 21:04:13 --> UTF-8 Support Enabled
INFO - 2021-08-07 21:04:13 --> Utf8 Class Initialized
INFO - 2021-08-07 21:04:13 --> URI Class Initialized
INFO - 2021-08-07 21:04:13 --> Router Class Initialized
INFO - 2021-08-07 21:04:13 --> Output Class Initialized
INFO - 2021-08-07 21:04:13 --> Security Class Initialized
DEBUG - 2021-08-07 21:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 21:04:13 --> Input Class Initialized
INFO - 2021-08-07 21:04:13 --> Language Class Initialized
INFO - 2021-08-07 21:04:13 --> Loader Class Initialized
INFO - 2021-08-07 21:04:14 --> Helper loaded: url_helper
INFO - 2021-08-07 21:04:14 --> Helper loaded: file_helper
INFO - 2021-08-07 21:04:14 --> Database Driver Class Initialized
DEBUG - 2021-08-07 21:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 21:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 21:04:14 --> Controller Class Initialized
INFO - 2021-08-07 21:04:14 --> Helper loaded: cookie_helper
INFO - 2021-08-07 21:04:14 --> Model "CookieModel" initialized
INFO - 2021-08-07 21:04:14 --> Model "ContactModel" initialized
INFO - 2021-08-07 21:04:14 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 21:04:14 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/contact.php
INFO - 2021-08-07 21:04:14 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 21:04:14 --> Final output sent to browser
DEBUG - 2021-08-07 21:04:14 --> Total execution time: 0.0188
INFO - 2021-08-07 21:04:23 --> Config Class Initialized
INFO - 2021-08-07 21:04:23 --> Hooks Class Initialized
DEBUG - 2021-08-07 21:04:23 --> UTF-8 Support Enabled
INFO - 2021-08-07 21:04:23 --> Utf8 Class Initialized
INFO - 2021-08-07 21:04:23 --> URI Class Initialized
DEBUG - 2021-08-07 21:04:23 --> No URI present. Default controller set.
INFO - 2021-08-07 21:04:23 --> Router Class Initialized
INFO - 2021-08-07 21:04:23 --> Output Class Initialized
INFO - 2021-08-07 21:04:23 --> Security Class Initialized
DEBUG - 2021-08-07 21:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 21:04:23 --> Input Class Initialized
INFO - 2021-08-07 21:04:23 --> Language Class Initialized
INFO - 2021-08-07 21:04:23 --> Loader Class Initialized
INFO - 2021-08-07 21:04:23 --> Helper loaded: url_helper
INFO - 2021-08-07 21:04:23 --> Helper loaded: file_helper
INFO - 2021-08-07 21:04:23 --> Database Driver Class Initialized
DEBUG - 2021-08-07 21:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 21:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 21:04:23 --> Controller Class Initialized
INFO - 2021-08-07 21:04:23 --> Helper loaded: cookie_helper
INFO - 2021-08-07 21:04:23 --> Model "CookieModel" initialized
INFO - 2021-08-07 21:04:23 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 21:04:23 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/index.php
INFO - 2021-08-07 21:04:23 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 21:04:23 --> Final output sent to browser
DEBUG - 2021-08-07 21:04:23 --> Total execution time: 0.0177
INFO - 2021-08-07 21:06:11 --> Config Class Initialized
INFO - 2021-08-07 21:06:11 --> Hooks Class Initialized
DEBUG - 2021-08-07 21:06:11 --> UTF-8 Support Enabled
INFO - 2021-08-07 21:06:11 --> Utf8 Class Initialized
INFO - 2021-08-07 21:06:11 --> URI Class Initialized
INFO - 2021-08-07 21:06:11 --> Router Class Initialized
INFO - 2021-08-07 21:06:11 --> Output Class Initialized
INFO - 2021-08-07 21:06:11 --> Security Class Initialized
DEBUG - 2021-08-07 21:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 21:06:11 --> Input Class Initialized
INFO - 2021-08-07 21:06:11 --> Language Class Initialized
INFO - 2021-08-07 21:06:11 --> Loader Class Initialized
INFO - 2021-08-07 21:06:11 --> Helper loaded: url_helper
INFO - 2021-08-07 21:06:11 --> Helper loaded: file_helper
INFO - 2021-08-07 21:06:11 --> Database Driver Class Initialized
DEBUG - 2021-08-07 21:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 21:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 21:06:11 --> Controller Class Initialized
INFO - 2021-08-07 21:06:11 --> Helper loaded: cookie_helper
INFO - 2021-08-07 21:06:11 --> Model "CookieModel" initialized
INFO - 2021-08-07 21:06:11 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 21:06:11 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/team.php
INFO - 2021-08-07 21:06:11 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 21:06:11 --> Final output sent to browser
DEBUG - 2021-08-07 21:06:11 --> Total execution time: 0.0174
INFO - 2021-08-07 21:07:07 --> Config Class Initialized
INFO - 2021-08-07 21:07:07 --> Hooks Class Initialized
DEBUG - 2021-08-07 21:07:07 --> UTF-8 Support Enabled
INFO - 2021-08-07 21:07:07 --> Utf8 Class Initialized
INFO - 2021-08-07 21:07:07 --> URI Class Initialized
DEBUG - 2021-08-07 21:07:07 --> No URI present. Default controller set.
INFO - 2021-08-07 21:07:07 --> Router Class Initialized
INFO - 2021-08-07 21:07:07 --> Output Class Initialized
INFO - 2021-08-07 21:07:07 --> Security Class Initialized
DEBUG - 2021-08-07 21:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 21:07:07 --> Input Class Initialized
INFO - 2021-08-07 21:07:07 --> Language Class Initialized
INFO - 2021-08-07 21:07:07 --> Loader Class Initialized
INFO - 2021-08-07 21:07:07 --> Helper loaded: url_helper
INFO - 2021-08-07 21:07:07 --> Helper loaded: file_helper
INFO - 2021-08-07 21:07:07 --> Database Driver Class Initialized
DEBUG - 2021-08-07 21:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 21:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 21:07:07 --> Controller Class Initialized
INFO - 2021-08-07 21:07:07 --> Helper loaded: cookie_helper
INFO - 2021-08-07 21:07:07 --> Model "CookieModel" initialized
INFO - 2021-08-07 21:07:07 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 21:07:07 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/index.php
INFO - 2021-08-07 21:07:07 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 21:07:07 --> Final output sent to browser
DEBUG - 2021-08-07 21:07:07 --> Total execution time: 0.0270
INFO - 2021-08-07 21:07:21 --> Config Class Initialized
INFO - 2021-08-07 21:07:21 --> Hooks Class Initialized
DEBUG - 2021-08-07 21:07:21 --> UTF-8 Support Enabled
INFO - 2021-08-07 21:07:21 --> Utf8 Class Initialized
INFO - 2021-08-07 21:07:21 --> URI Class Initialized
DEBUG - 2021-08-07 21:07:21 --> No URI present. Default controller set.
INFO - 2021-08-07 21:07:21 --> Router Class Initialized
INFO - 2021-08-07 21:07:21 --> Output Class Initialized
INFO - 2021-08-07 21:07:21 --> Security Class Initialized
DEBUG - 2021-08-07 21:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 21:07:21 --> Input Class Initialized
INFO - 2021-08-07 21:07:21 --> Language Class Initialized
INFO - 2021-08-07 21:07:21 --> Loader Class Initialized
INFO - 2021-08-07 21:07:21 --> Helper loaded: url_helper
INFO - 2021-08-07 21:07:21 --> Helper loaded: file_helper
INFO - 2021-08-07 21:07:21 --> Database Driver Class Initialized
DEBUG - 2021-08-07 21:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 21:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 21:07:21 --> Controller Class Initialized
INFO - 2021-08-07 21:07:21 --> Helper loaded: cookie_helper
INFO - 2021-08-07 21:07:21 --> Model "CookieModel" initialized
INFO - 2021-08-07 21:07:21 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 21:07:21 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/index.php
INFO - 2021-08-07 21:07:21 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 21:07:21 --> Final output sent to browser
DEBUG - 2021-08-07 21:07:21 --> Total execution time: 0.0188
INFO - 2021-08-07 21:08:54 --> Config Class Initialized
INFO - 2021-08-07 21:08:54 --> Hooks Class Initialized
DEBUG - 2021-08-07 21:08:54 --> UTF-8 Support Enabled
INFO - 2021-08-07 21:08:54 --> Utf8 Class Initialized
INFO - 2021-08-07 21:08:54 --> URI Class Initialized
DEBUG - 2021-08-07 21:08:54 --> No URI present. Default controller set.
INFO - 2021-08-07 21:08:54 --> Router Class Initialized
INFO - 2021-08-07 21:08:54 --> Output Class Initialized
INFO - 2021-08-07 21:08:54 --> Security Class Initialized
DEBUG - 2021-08-07 21:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 21:08:54 --> Input Class Initialized
INFO - 2021-08-07 21:08:54 --> Language Class Initialized
INFO - 2021-08-07 21:08:54 --> Loader Class Initialized
INFO - 2021-08-07 21:08:54 --> Helper loaded: url_helper
INFO - 2021-08-07 21:08:54 --> Helper loaded: file_helper
INFO - 2021-08-07 21:08:54 --> Database Driver Class Initialized
DEBUG - 2021-08-07 21:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 21:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 21:08:54 --> Controller Class Initialized
INFO - 2021-08-07 21:08:54 --> Helper loaded: cookie_helper
INFO - 2021-08-07 21:08:54 --> Model "CookieModel" initialized
INFO - 2021-08-07 21:08:54 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 21:08:54 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/index.php
INFO - 2021-08-07 21:08:54 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 21:08:54 --> Final output sent to browser
DEBUG - 2021-08-07 21:08:54 --> Total execution time: 0.0188
INFO - 2021-08-07 21:08:57 --> Config Class Initialized
INFO - 2021-08-07 21:08:57 --> Hooks Class Initialized
DEBUG - 2021-08-07 21:08:57 --> UTF-8 Support Enabled
INFO - 2021-08-07 21:08:57 --> Utf8 Class Initialized
INFO - 2021-08-07 21:08:57 --> URI Class Initialized
INFO - 2021-08-07 21:08:57 --> Router Class Initialized
INFO - 2021-08-07 21:08:57 --> Output Class Initialized
INFO - 2021-08-07 21:08:57 --> Security Class Initialized
DEBUG - 2021-08-07 21:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 21:08:57 --> Input Class Initialized
INFO - 2021-08-07 21:08:57 --> Language Class Initialized
INFO - 2021-08-07 21:08:57 --> Loader Class Initialized
INFO - 2021-08-07 21:08:57 --> Helper loaded: url_helper
INFO - 2021-08-07 21:08:57 --> Helper loaded: file_helper
INFO - 2021-08-07 21:08:57 --> Database Driver Class Initialized
DEBUG - 2021-08-07 21:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 21:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 21:08:57 --> Controller Class Initialized
INFO - 2021-08-07 21:08:57 --> Helper loaded: cookie_helper
INFO - 2021-08-07 21:08:57 --> Model "CookieModel" initialized
INFO - 2021-08-07 21:08:57 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 21:08:57 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/pilates.php
INFO - 2021-08-07 21:08:57 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 21:08:57 --> Final output sent to browser
DEBUG - 2021-08-07 21:08:57 --> Total execution time: 0.0185
INFO - 2021-08-07 21:09:38 --> Config Class Initialized
INFO - 2021-08-07 21:09:38 --> Hooks Class Initialized
DEBUG - 2021-08-07 21:09:38 --> UTF-8 Support Enabled
INFO - 2021-08-07 21:09:38 --> Utf8 Class Initialized
INFO - 2021-08-07 21:09:38 --> URI Class Initialized
INFO - 2021-08-07 21:09:38 --> Router Class Initialized
INFO - 2021-08-07 21:09:38 --> Output Class Initialized
INFO - 2021-08-07 21:09:38 --> Security Class Initialized
DEBUG - 2021-08-07 21:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 21:09:38 --> Input Class Initialized
INFO - 2021-08-07 21:09:38 --> Language Class Initialized
INFO - 2021-08-07 21:09:38 --> Loader Class Initialized
INFO - 2021-08-07 21:09:38 --> Helper loaded: url_helper
INFO - 2021-08-07 21:09:38 --> Helper loaded: file_helper
INFO - 2021-08-07 21:09:38 --> Database Driver Class Initialized
DEBUG - 2021-08-07 21:09:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 21:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 21:09:38 --> Controller Class Initialized
INFO - 2021-08-07 21:09:38 --> Helper loaded: cookie_helper
INFO - 2021-08-07 21:09:38 --> Model "CookieModel" initialized
INFO - 2021-08-07 21:09:38 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 21:09:38 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/pilates.php
INFO - 2021-08-07 21:09:38 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 21:09:38 --> Final output sent to browser
DEBUG - 2021-08-07 21:09:38 --> Total execution time: 0.0250
INFO - 2021-08-07 21:09:41 --> Config Class Initialized
INFO - 2021-08-07 21:09:41 --> Hooks Class Initialized
DEBUG - 2021-08-07 21:09:41 --> UTF-8 Support Enabled
INFO - 2021-08-07 21:09:41 --> Utf8 Class Initialized
INFO - 2021-08-07 21:09:41 --> URI Class Initialized
INFO - 2021-08-07 21:09:41 --> Router Class Initialized
INFO - 2021-08-07 21:09:41 --> Output Class Initialized
INFO - 2021-08-07 21:09:41 --> Security Class Initialized
DEBUG - 2021-08-07 21:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 21:09:41 --> Input Class Initialized
INFO - 2021-08-07 21:09:41 --> Language Class Initialized
INFO - 2021-08-07 21:09:41 --> Loader Class Initialized
INFO - 2021-08-07 21:09:41 --> Helper loaded: url_helper
INFO - 2021-08-07 21:09:41 --> Helper loaded: file_helper
INFO - 2021-08-07 21:09:41 --> Database Driver Class Initialized
DEBUG - 2021-08-07 21:09:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 21:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 21:09:41 --> Controller Class Initialized
INFO - 2021-08-07 21:09:41 --> Helper loaded: cookie_helper
INFO - 2021-08-07 21:09:41 --> Model "CookieModel" initialized
INFO - 2021-08-07 21:09:41 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 21:09:41 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/services.php
INFO - 2021-08-07 21:09:41 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 21:09:41 --> Final output sent to browser
DEBUG - 2021-08-07 21:09:41 --> Total execution time: 0.0189
INFO - 2021-08-07 21:09:53 --> Config Class Initialized
INFO - 2021-08-07 21:09:53 --> Hooks Class Initialized
DEBUG - 2021-08-07 21:09:53 --> UTF-8 Support Enabled
INFO - 2021-08-07 21:09:53 --> Utf8 Class Initialized
INFO - 2021-08-07 21:09:53 --> URI Class Initialized
DEBUG - 2021-08-07 21:09:53 --> No URI present. Default controller set.
INFO - 2021-08-07 21:09:53 --> Router Class Initialized
INFO - 2021-08-07 21:09:53 --> Output Class Initialized
INFO - 2021-08-07 21:09:53 --> Security Class Initialized
DEBUG - 2021-08-07 21:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 21:09:53 --> Input Class Initialized
INFO - 2021-08-07 21:09:53 --> Language Class Initialized
INFO - 2021-08-07 21:09:53 --> Loader Class Initialized
INFO - 2021-08-07 21:09:53 --> Helper loaded: url_helper
INFO - 2021-08-07 21:09:53 --> Helper loaded: file_helper
INFO - 2021-08-07 21:09:53 --> Database Driver Class Initialized
DEBUG - 2021-08-07 21:09:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 21:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 21:09:53 --> Controller Class Initialized
INFO - 2021-08-07 21:09:53 --> Helper loaded: cookie_helper
INFO - 2021-08-07 21:09:53 --> Model "CookieModel" initialized
INFO - 2021-08-07 21:09:53 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 21:09:53 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/index.php
INFO - 2021-08-07 21:09:53 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 21:09:53 --> Final output sent to browser
DEBUG - 2021-08-07 21:09:53 --> Total execution time: 0.0181
INFO - 2021-08-07 21:10:17 --> Config Class Initialized
INFO - 2021-08-07 21:10:17 --> Hooks Class Initialized
DEBUG - 2021-08-07 21:10:17 --> UTF-8 Support Enabled
INFO - 2021-08-07 21:10:17 --> Utf8 Class Initialized
INFO - 2021-08-07 21:10:17 --> URI Class Initialized
INFO - 2021-08-07 21:10:17 --> Router Class Initialized
INFO - 2021-08-07 21:10:17 --> Output Class Initialized
INFO - 2021-08-07 21:10:17 --> Security Class Initialized
DEBUG - 2021-08-07 21:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 21:10:17 --> Input Class Initialized
INFO - 2021-08-07 21:10:17 --> Language Class Initialized
INFO - 2021-08-07 21:10:17 --> Loader Class Initialized
INFO - 2021-08-07 21:10:17 --> Helper loaded: url_helper
INFO - 2021-08-07 21:10:17 --> Helper loaded: file_helper
INFO - 2021-08-07 21:10:17 --> Database Driver Class Initialized
DEBUG - 2021-08-07 21:10:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 21:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 21:10:17 --> Controller Class Initialized
INFO - 2021-08-07 21:10:17 --> Helper loaded: cookie_helper
INFO - 2021-08-07 21:10:17 --> Model "CookieModel" initialized
INFO - 2021-08-07 21:10:17 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 21:10:17 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/pilates.php
INFO - 2021-08-07 21:10:17 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 21:10:17 --> Final output sent to browser
DEBUG - 2021-08-07 21:10:17 --> Total execution time: 0.0191
INFO - 2021-08-07 21:10:52 --> Config Class Initialized
INFO - 2021-08-07 21:10:52 --> Hooks Class Initialized
DEBUG - 2021-08-07 21:10:52 --> UTF-8 Support Enabled
INFO - 2021-08-07 21:10:52 --> Utf8 Class Initialized
INFO - 2021-08-07 21:10:52 --> URI Class Initialized
INFO - 2021-08-07 21:10:52 --> Router Class Initialized
INFO - 2021-08-07 21:10:52 --> Output Class Initialized
INFO - 2021-08-07 21:10:52 --> Security Class Initialized
DEBUG - 2021-08-07 21:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 21:10:52 --> Input Class Initialized
INFO - 2021-08-07 21:10:52 --> Language Class Initialized
INFO - 2021-08-07 21:10:52 --> Loader Class Initialized
INFO - 2021-08-07 21:10:52 --> Helper loaded: url_helper
INFO - 2021-08-07 21:10:52 --> Helper loaded: file_helper
INFO - 2021-08-07 21:10:52 --> Database Driver Class Initialized
DEBUG - 2021-08-07 21:10:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 21:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 21:10:52 --> Controller Class Initialized
INFO - 2021-08-07 21:10:52 --> Helper loaded: cookie_helper
INFO - 2021-08-07 21:10:52 --> Model "CookieModel" initialized
INFO - 2021-08-07 21:10:52 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 21:10:52 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/services.php
INFO - 2021-08-07 21:10:52 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 21:10:52 --> Final output sent to browser
DEBUG - 2021-08-07 21:10:52 --> Total execution time: 0.0182
INFO - 2021-08-07 21:11:29 --> Config Class Initialized
INFO - 2021-08-07 21:11:29 --> Hooks Class Initialized
DEBUG - 2021-08-07 21:11:29 --> UTF-8 Support Enabled
INFO - 2021-08-07 21:11:29 --> Utf8 Class Initialized
INFO - 2021-08-07 21:11:29 --> URI Class Initialized
INFO - 2021-08-07 21:11:29 --> Router Class Initialized
INFO - 2021-08-07 21:11:29 --> Output Class Initialized
INFO - 2021-08-07 21:11:29 --> Security Class Initialized
DEBUG - 2021-08-07 21:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 21:11:29 --> Input Class Initialized
INFO - 2021-08-07 21:11:29 --> Language Class Initialized
INFO - 2021-08-07 21:11:29 --> Loader Class Initialized
INFO - 2021-08-07 21:11:29 --> Helper loaded: url_helper
INFO - 2021-08-07 21:11:29 --> Helper loaded: file_helper
INFO - 2021-08-07 21:11:29 --> Database Driver Class Initialized
DEBUG - 2021-08-07 21:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 21:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 21:11:29 --> Controller Class Initialized
INFO - 2021-08-07 21:11:29 --> Helper loaded: cookie_helper
INFO - 2021-08-07 21:11:29 --> Model "CookieModel" initialized
INFO - 2021-08-07 21:11:29 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 21:11:29 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/success_stories.php
INFO - 2021-08-07 21:11:29 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 21:11:29 --> Final output sent to browser
DEBUG - 2021-08-07 21:11:29 --> Total execution time: 0.0185
INFO - 2021-08-07 21:12:11 --> Config Class Initialized
INFO - 2021-08-07 21:12:11 --> Hooks Class Initialized
DEBUG - 2021-08-07 21:12:11 --> UTF-8 Support Enabled
INFO - 2021-08-07 21:12:11 --> Utf8 Class Initialized
INFO - 2021-08-07 21:12:11 --> URI Class Initialized
INFO - 2021-08-07 21:12:11 --> Router Class Initialized
INFO - 2021-08-07 21:12:11 --> Output Class Initialized
INFO - 2021-08-07 21:12:11 --> Security Class Initialized
DEBUG - 2021-08-07 21:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 21:12:11 --> Input Class Initialized
INFO - 2021-08-07 21:12:11 --> Language Class Initialized
INFO - 2021-08-07 21:12:11 --> Loader Class Initialized
INFO - 2021-08-07 21:12:11 --> Helper loaded: url_helper
INFO - 2021-08-07 21:12:11 --> Helper loaded: file_helper
INFO - 2021-08-07 21:12:11 --> Database Driver Class Initialized
DEBUG - 2021-08-07 21:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 21:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 21:12:11 --> Controller Class Initialized
INFO - 2021-08-07 21:12:11 --> Helper loaded: cookie_helper
INFO - 2021-08-07 21:12:11 --> Model "CookieModel" initialized
INFO - 2021-08-07 21:12:11 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 21:12:11 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/success_stories.php
INFO - 2021-08-07 21:12:11 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 21:12:11 --> Final output sent to browser
DEBUG - 2021-08-07 21:12:11 --> Total execution time: 0.0188
INFO - 2021-08-07 21:12:22 --> Config Class Initialized
INFO - 2021-08-07 21:12:22 --> Hooks Class Initialized
DEBUG - 2021-08-07 21:12:22 --> UTF-8 Support Enabled
INFO - 2021-08-07 21:12:22 --> Utf8 Class Initialized
INFO - 2021-08-07 21:12:22 --> URI Class Initialized
INFO - 2021-08-07 21:12:22 --> Router Class Initialized
INFO - 2021-08-07 21:12:22 --> Output Class Initialized
INFO - 2021-08-07 21:12:22 --> Security Class Initialized
DEBUG - 2021-08-07 21:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 21:12:22 --> Input Class Initialized
INFO - 2021-08-07 21:12:22 --> Language Class Initialized
INFO - 2021-08-07 21:12:22 --> Loader Class Initialized
INFO - 2021-08-07 21:12:22 --> Helper loaded: url_helper
INFO - 2021-08-07 21:12:22 --> Helper loaded: file_helper
INFO - 2021-08-07 21:12:22 --> Database Driver Class Initialized
DEBUG - 2021-08-07 21:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 21:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 21:12:22 --> Controller Class Initialized
INFO - 2021-08-07 21:12:22 --> Helper loaded: cookie_helper
INFO - 2021-08-07 21:12:22 --> Model "CookieModel" initialized
INFO - 2021-08-07 21:12:22 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 21:12:22 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/gallery.php
INFO - 2021-08-07 21:12:22 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 21:12:22 --> Final output sent to browser
DEBUG - 2021-08-07 21:12:22 --> Total execution time: 0.0245
INFO - 2021-08-07 21:13:06 --> Config Class Initialized
INFO - 2021-08-07 21:13:06 --> Hooks Class Initialized
DEBUG - 2021-08-07 21:13:06 --> UTF-8 Support Enabled
INFO - 2021-08-07 21:13:06 --> Utf8 Class Initialized
INFO - 2021-08-07 21:13:06 --> URI Class Initialized
INFO - 2021-08-07 21:13:06 --> Router Class Initialized
INFO - 2021-08-07 21:13:06 --> Output Class Initialized
INFO - 2021-08-07 21:13:06 --> Security Class Initialized
DEBUG - 2021-08-07 21:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 21:13:06 --> Input Class Initialized
INFO - 2021-08-07 21:13:06 --> Language Class Initialized
INFO - 2021-08-07 21:13:06 --> Loader Class Initialized
INFO - 2021-08-07 21:13:06 --> Helper loaded: url_helper
INFO - 2021-08-07 21:13:06 --> Helper loaded: file_helper
INFO - 2021-08-07 21:13:06 --> Database Driver Class Initialized
DEBUG - 2021-08-07 21:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 21:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 21:13:06 --> Controller Class Initialized
INFO - 2021-08-07 21:13:06 --> Helper loaded: cookie_helper
INFO - 2021-08-07 21:13:06 --> Model "CookieModel" initialized
INFO - 2021-08-07 21:13:06 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 21:13:06 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/team.php
INFO - 2021-08-07 21:13:06 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 21:13:06 --> Final output sent to browser
DEBUG - 2021-08-07 21:13:06 --> Total execution time: 0.0194
INFO - 2021-08-07 21:15:26 --> Config Class Initialized
INFO - 2021-08-07 21:15:26 --> Hooks Class Initialized
DEBUG - 2021-08-07 21:15:26 --> UTF-8 Support Enabled
INFO - 2021-08-07 21:15:26 --> Utf8 Class Initialized
INFO - 2021-08-07 21:15:26 --> URI Class Initialized
DEBUG - 2021-08-07 21:15:26 --> No URI present. Default controller set.
INFO - 2021-08-07 21:15:26 --> Router Class Initialized
INFO - 2021-08-07 21:15:26 --> Output Class Initialized
INFO - 2021-08-07 21:15:26 --> Security Class Initialized
DEBUG - 2021-08-07 21:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 21:15:26 --> Input Class Initialized
INFO - 2021-08-07 21:15:26 --> Language Class Initialized
INFO - 2021-08-07 21:15:26 --> Loader Class Initialized
INFO - 2021-08-07 21:15:26 --> Helper loaded: url_helper
INFO - 2021-08-07 21:15:26 --> Helper loaded: file_helper
INFO - 2021-08-07 21:15:26 --> Database Driver Class Initialized
DEBUG - 2021-08-07 21:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 21:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 21:15:26 --> Controller Class Initialized
INFO - 2021-08-07 21:15:26 --> Helper loaded: cookie_helper
INFO - 2021-08-07 21:15:26 --> Model "CookieModel" initialized
INFO - 2021-08-07 21:15:26 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 21:15:26 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/index.php
INFO - 2021-08-07 21:15:26 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 21:15:26 --> Final output sent to browser
DEBUG - 2021-08-07 21:15:26 --> Total execution time: 0.0202
INFO - 2021-08-07 21:16:15 --> Config Class Initialized
INFO - 2021-08-07 21:16:15 --> Hooks Class Initialized
DEBUG - 2021-08-07 21:16:15 --> UTF-8 Support Enabled
INFO - 2021-08-07 21:16:15 --> Utf8 Class Initialized
INFO - 2021-08-07 21:16:15 --> URI Class Initialized
INFO - 2021-08-07 21:16:15 --> Router Class Initialized
INFO - 2021-08-07 21:16:15 --> Output Class Initialized
INFO - 2021-08-07 21:16:15 --> Security Class Initialized
DEBUG - 2021-08-07 21:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 21:16:15 --> Input Class Initialized
INFO - 2021-08-07 21:16:15 --> Language Class Initialized
INFO - 2021-08-07 21:16:15 --> Loader Class Initialized
INFO - 2021-08-07 21:16:15 --> Helper loaded: url_helper
INFO - 2021-08-07 21:16:15 --> Helper loaded: file_helper
INFO - 2021-08-07 21:16:15 --> Database Driver Class Initialized
DEBUG - 2021-08-07 21:16:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 21:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 21:16:15 --> Controller Class Initialized
INFO - 2021-08-07 21:16:15 --> Helper loaded: cookie_helper
INFO - 2021-08-07 21:16:15 --> Model "CookieModel" initialized
INFO - 2021-08-07 21:16:15 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 21:16:15 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/team.php
INFO - 2021-08-07 21:16:15 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 21:16:15 --> Final output sent to browser
DEBUG - 2021-08-07 21:16:15 --> Total execution time: 0.0214
INFO - 2021-08-07 21:16:25 --> Config Class Initialized
INFO - 2021-08-07 21:16:25 --> Hooks Class Initialized
DEBUG - 2021-08-07 21:16:25 --> UTF-8 Support Enabled
INFO - 2021-08-07 21:16:25 --> Utf8 Class Initialized
INFO - 2021-08-07 21:16:25 --> URI Class Initialized
DEBUG - 2021-08-07 21:16:25 --> No URI present. Default controller set.
INFO - 2021-08-07 21:16:25 --> Router Class Initialized
INFO - 2021-08-07 21:16:25 --> Output Class Initialized
INFO - 2021-08-07 21:16:25 --> Security Class Initialized
DEBUG - 2021-08-07 21:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 21:16:25 --> Input Class Initialized
INFO - 2021-08-07 21:16:25 --> Language Class Initialized
INFO - 2021-08-07 21:16:25 --> Loader Class Initialized
INFO - 2021-08-07 21:16:25 --> Helper loaded: url_helper
INFO - 2021-08-07 21:16:25 --> Helper loaded: file_helper
INFO - 2021-08-07 21:16:25 --> Database Driver Class Initialized
DEBUG - 2021-08-07 21:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 21:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 21:16:25 --> Controller Class Initialized
INFO - 2021-08-07 21:16:25 --> Helper loaded: cookie_helper
INFO - 2021-08-07 21:16:25 --> Model "CookieModel" initialized
INFO - 2021-08-07 21:16:25 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 21:16:25 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/index.php
INFO - 2021-08-07 21:16:25 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 21:16:25 --> Final output sent to browser
DEBUG - 2021-08-07 21:16:25 --> Total execution time: 0.0185
INFO - 2021-08-07 21:16:31 --> Config Class Initialized
INFO - 2021-08-07 21:16:31 --> Hooks Class Initialized
DEBUG - 2021-08-07 21:16:31 --> UTF-8 Support Enabled
INFO - 2021-08-07 21:16:31 --> Utf8 Class Initialized
INFO - 2021-08-07 21:16:31 --> URI Class Initialized
INFO - 2021-08-07 21:16:31 --> Router Class Initialized
INFO - 2021-08-07 21:16:31 --> Output Class Initialized
INFO - 2021-08-07 21:16:31 --> Security Class Initialized
DEBUG - 2021-08-07 21:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 21:16:31 --> Input Class Initialized
INFO - 2021-08-07 21:16:31 --> Language Class Initialized
INFO - 2021-08-07 21:16:31 --> Loader Class Initialized
INFO - 2021-08-07 21:16:31 --> Helper loaded: url_helper
INFO - 2021-08-07 21:16:31 --> Helper loaded: file_helper
INFO - 2021-08-07 21:16:31 --> Database Driver Class Initialized
DEBUG - 2021-08-07 21:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 21:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 21:16:31 --> Controller Class Initialized
INFO - 2021-08-07 21:16:31 --> Helper loaded: cookie_helper
INFO - 2021-08-07 21:16:31 --> Model "CookieModel" initialized
INFO - 2021-08-07 21:16:31 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 21:16:31 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/gallery.php
INFO - 2021-08-07 21:16:31 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 21:16:31 --> Final output sent to browser
DEBUG - 2021-08-07 21:16:31 --> Total execution time: 0.0191
INFO - 2021-08-07 21:16:36 --> Config Class Initialized
INFO - 2021-08-07 21:16:36 --> Hooks Class Initialized
DEBUG - 2021-08-07 21:16:36 --> UTF-8 Support Enabled
INFO - 2021-08-07 21:16:36 --> Utf8 Class Initialized
INFO - 2021-08-07 21:16:36 --> URI Class Initialized
DEBUG - 2021-08-07 21:16:36 --> No URI present. Default controller set.
INFO - 2021-08-07 21:16:36 --> Router Class Initialized
INFO - 2021-08-07 21:16:36 --> Output Class Initialized
INFO - 2021-08-07 21:16:36 --> Security Class Initialized
DEBUG - 2021-08-07 21:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 21:16:36 --> Input Class Initialized
INFO - 2021-08-07 21:16:36 --> Language Class Initialized
INFO - 2021-08-07 21:16:36 --> Loader Class Initialized
INFO - 2021-08-07 21:16:36 --> Helper loaded: url_helper
INFO - 2021-08-07 21:16:36 --> Helper loaded: file_helper
INFO - 2021-08-07 21:16:36 --> Database Driver Class Initialized
DEBUG - 2021-08-07 21:16:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 21:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 21:16:36 --> Controller Class Initialized
INFO - 2021-08-07 21:16:36 --> Helper loaded: cookie_helper
INFO - 2021-08-07 21:16:36 --> Model "CookieModel" initialized
INFO - 2021-08-07 21:16:36 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 21:16:36 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/index.php
INFO - 2021-08-07 21:16:36 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 21:16:36 --> Final output sent to browser
DEBUG - 2021-08-07 21:16:36 --> Total execution time: 0.0238
INFO - 2021-08-07 21:20:39 --> Config Class Initialized
INFO - 2021-08-07 21:20:39 --> Hooks Class Initialized
DEBUG - 2021-08-07 21:20:39 --> UTF-8 Support Enabled
INFO - 2021-08-07 21:20:39 --> Utf8 Class Initialized
INFO - 2021-08-07 21:20:39 --> URI Class Initialized
INFO - 2021-08-07 21:20:39 --> Router Class Initialized
INFO - 2021-08-07 21:20:39 --> Output Class Initialized
INFO - 2021-08-07 21:20:39 --> Security Class Initialized
DEBUG - 2021-08-07 21:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 21:20:39 --> Input Class Initialized
INFO - 2021-08-07 21:20:39 --> Language Class Initialized
INFO - 2021-08-07 21:20:39 --> Loader Class Initialized
INFO - 2021-08-07 21:20:39 --> Helper loaded: url_helper
INFO - 2021-08-07 21:20:39 --> Helper loaded: file_helper
INFO - 2021-08-07 21:20:39 --> Database Driver Class Initialized
DEBUG - 2021-08-07 21:20:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 21:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 21:20:39 --> Controller Class Initialized
INFO - 2021-08-07 21:20:39 --> Helper loaded: cookie_helper
INFO - 2021-08-07 21:20:39 --> Model "CookieModel" initialized
INFO - 2021-08-07 21:20:39 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 21:20:39 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/pilates.php
INFO - 2021-08-07 21:20:39 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 21:20:39 --> Final output sent to browser
DEBUG - 2021-08-07 21:20:39 --> Total execution time: 0.0192
INFO - 2021-08-07 21:24:05 --> Config Class Initialized
INFO - 2021-08-07 21:24:05 --> Hooks Class Initialized
DEBUG - 2021-08-07 21:24:05 --> UTF-8 Support Enabled
INFO - 2021-08-07 21:24:05 --> Utf8 Class Initialized
INFO - 2021-08-07 21:24:05 --> URI Class Initialized
INFO - 2021-08-07 21:24:05 --> Router Class Initialized
INFO - 2021-08-07 21:24:05 --> Output Class Initialized
INFO - 2021-08-07 21:24:05 --> Security Class Initialized
DEBUG - 2021-08-07 21:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 21:24:05 --> Input Class Initialized
INFO - 2021-08-07 21:24:05 --> Language Class Initialized
INFO - 2021-08-07 21:24:05 --> Loader Class Initialized
INFO - 2021-08-07 21:24:05 --> Helper loaded: url_helper
INFO - 2021-08-07 21:24:05 --> Helper loaded: file_helper
INFO - 2021-08-07 21:24:05 --> Database Driver Class Initialized
DEBUG - 2021-08-07 21:24:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 21:24:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 21:24:05 --> Controller Class Initialized
INFO - 2021-08-07 21:24:05 --> Helper loaded: cookie_helper
INFO - 2021-08-07 21:24:05 --> Model "CookieModel" initialized
INFO - 2021-08-07 21:24:05 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 21:24:05 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/pilates.php
INFO - 2021-08-07 21:24:05 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 21:24:05 --> Final output sent to browser
DEBUG - 2021-08-07 21:24:05 --> Total execution time: 0.0204
INFO - 2021-08-07 21:24:17 --> Config Class Initialized
INFO - 2021-08-07 21:24:17 --> Hooks Class Initialized
DEBUG - 2021-08-07 21:24:17 --> UTF-8 Support Enabled
INFO - 2021-08-07 21:24:17 --> Utf8 Class Initialized
INFO - 2021-08-07 21:24:17 --> URI Class Initialized
INFO - 2021-08-07 21:24:17 --> Router Class Initialized
INFO - 2021-08-07 21:24:17 --> Output Class Initialized
INFO - 2021-08-07 21:24:17 --> Security Class Initialized
DEBUG - 2021-08-07 21:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 21:24:17 --> Input Class Initialized
INFO - 2021-08-07 21:24:17 --> Language Class Initialized
INFO - 2021-08-07 21:24:17 --> Loader Class Initialized
INFO - 2021-08-07 21:24:17 --> Helper loaded: url_helper
INFO - 2021-08-07 21:24:17 --> Helper loaded: file_helper
INFO - 2021-08-07 21:24:17 --> Database Driver Class Initialized
DEBUG - 2021-08-07 21:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 21:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 21:24:17 --> Controller Class Initialized
INFO - 2021-08-07 21:24:17 --> Helper loaded: cookie_helper
INFO - 2021-08-07 21:24:17 --> Model "CookieModel" initialized
INFO - 2021-08-07 21:24:17 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 21:24:17 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/services.php
INFO - 2021-08-07 21:24:17 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 21:24:17 --> Final output sent to browser
DEBUG - 2021-08-07 21:24:17 --> Total execution time: 0.0395
INFO - 2021-08-07 21:24:36 --> Config Class Initialized
INFO - 2021-08-07 21:24:36 --> Hooks Class Initialized
DEBUG - 2021-08-07 21:24:36 --> UTF-8 Support Enabled
INFO - 2021-08-07 21:24:36 --> Utf8 Class Initialized
INFO - 2021-08-07 21:24:36 --> URI Class Initialized
INFO - 2021-08-07 21:24:36 --> Router Class Initialized
INFO - 2021-08-07 21:24:36 --> Output Class Initialized
INFO - 2021-08-07 21:24:36 --> Security Class Initialized
DEBUG - 2021-08-07 21:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 21:24:36 --> Input Class Initialized
INFO - 2021-08-07 21:24:36 --> Language Class Initialized
INFO - 2021-08-07 21:24:36 --> Loader Class Initialized
INFO - 2021-08-07 21:24:36 --> Helper loaded: url_helper
INFO - 2021-08-07 21:24:36 --> Helper loaded: file_helper
INFO - 2021-08-07 21:24:36 --> Database Driver Class Initialized
DEBUG - 2021-08-07 21:24:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 21:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 21:24:36 --> Controller Class Initialized
INFO - 2021-08-07 21:24:36 --> Helper loaded: cookie_helper
INFO - 2021-08-07 21:24:36 --> Model "CookieModel" initialized
INFO - 2021-08-07 21:24:36 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 21:24:36 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/services.php
INFO - 2021-08-07 21:24:36 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 21:24:36 --> Final output sent to browser
DEBUG - 2021-08-07 21:24:36 --> Total execution time: 0.0189
INFO - 2021-08-07 21:24:50 --> Config Class Initialized
INFO - 2021-08-07 21:24:50 --> Hooks Class Initialized
DEBUG - 2021-08-07 21:24:50 --> UTF-8 Support Enabled
INFO - 2021-08-07 21:24:50 --> Utf8 Class Initialized
INFO - 2021-08-07 21:24:50 --> URI Class Initialized
INFO - 2021-08-07 21:24:50 --> Router Class Initialized
INFO - 2021-08-07 21:24:50 --> Output Class Initialized
INFO - 2021-08-07 21:24:50 --> Security Class Initialized
DEBUG - 2021-08-07 21:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 21:24:50 --> Input Class Initialized
INFO - 2021-08-07 21:24:50 --> Language Class Initialized
INFO - 2021-08-07 21:24:50 --> Loader Class Initialized
INFO - 2021-08-07 21:24:50 --> Helper loaded: url_helper
INFO - 2021-08-07 21:24:50 --> Helper loaded: file_helper
INFO - 2021-08-07 21:24:50 --> Database Driver Class Initialized
DEBUG - 2021-08-07 21:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 21:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 21:24:50 --> Controller Class Initialized
INFO - 2021-08-07 21:24:50 --> Helper loaded: cookie_helper
INFO - 2021-08-07 21:24:50 --> Model "CookieModel" initialized
INFO - 2021-08-07 21:24:50 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 21:24:50 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/services.php
INFO - 2021-08-07 21:24:50 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 21:24:50 --> Final output sent to browser
DEBUG - 2021-08-07 21:24:50 --> Total execution time: 0.0198
INFO - 2021-08-07 21:24:57 --> Config Class Initialized
INFO - 2021-08-07 21:24:57 --> Hooks Class Initialized
DEBUG - 2021-08-07 21:24:57 --> UTF-8 Support Enabled
INFO - 2021-08-07 21:24:57 --> Utf8 Class Initialized
INFO - 2021-08-07 21:24:57 --> URI Class Initialized
INFO - 2021-08-07 21:24:57 --> Router Class Initialized
INFO - 2021-08-07 21:24:57 --> Output Class Initialized
INFO - 2021-08-07 21:24:57 --> Security Class Initialized
DEBUG - 2021-08-07 21:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 21:24:57 --> Input Class Initialized
INFO - 2021-08-07 21:24:57 --> Language Class Initialized
INFO - 2021-08-07 21:24:57 --> Loader Class Initialized
INFO - 2021-08-07 21:24:57 --> Helper loaded: url_helper
INFO - 2021-08-07 21:24:57 --> Helper loaded: file_helper
INFO - 2021-08-07 21:24:57 --> Database Driver Class Initialized
DEBUG - 2021-08-07 21:24:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 21:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 21:24:57 --> Controller Class Initialized
INFO - 2021-08-07 21:24:57 --> Helper loaded: cookie_helper
INFO - 2021-08-07 21:24:57 --> Model "CookieModel" initialized
INFO - 2021-08-07 21:24:57 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 21:24:57 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/services.php
INFO - 2021-08-07 21:24:57 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 21:24:57 --> Final output sent to browser
DEBUG - 2021-08-07 21:24:57 --> Total execution time: 0.0192
INFO - 2021-08-07 21:25:06 --> Config Class Initialized
INFO - 2021-08-07 21:25:06 --> Hooks Class Initialized
DEBUG - 2021-08-07 21:25:06 --> UTF-8 Support Enabled
INFO - 2021-08-07 21:25:06 --> Utf8 Class Initialized
INFO - 2021-08-07 21:25:06 --> URI Class Initialized
INFO - 2021-08-07 21:25:06 --> Router Class Initialized
INFO - 2021-08-07 21:25:06 --> Output Class Initialized
INFO - 2021-08-07 21:25:06 --> Security Class Initialized
DEBUG - 2021-08-07 21:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 21:25:06 --> Input Class Initialized
INFO - 2021-08-07 21:25:06 --> Language Class Initialized
INFO - 2021-08-07 21:25:06 --> Loader Class Initialized
INFO - 2021-08-07 21:25:06 --> Helper loaded: url_helper
INFO - 2021-08-07 21:25:06 --> Helper loaded: file_helper
INFO - 2021-08-07 21:25:06 --> Database Driver Class Initialized
DEBUG - 2021-08-07 21:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 21:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 21:25:06 --> Controller Class Initialized
INFO - 2021-08-07 21:25:06 --> Helper loaded: cookie_helper
INFO - 2021-08-07 21:25:06 --> Model "CookieModel" initialized
INFO - 2021-08-07 21:25:06 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 21:25:06 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/success_stories.php
INFO - 2021-08-07 21:25:06 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 21:25:06 --> Final output sent to browser
DEBUG - 2021-08-07 21:25:06 --> Total execution time: 0.0233
INFO - 2021-08-07 21:25:20 --> Config Class Initialized
INFO - 2021-08-07 21:25:20 --> Hooks Class Initialized
DEBUG - 2021-08-07 21:25:20 --> UTF-8 Support Enabled
INFO - 2021-08-07 21:25:20 --> Utf8 Class Initialized
INFO - 2021-08-07 21:25:20 --> URI Class Initialized
INFO - 2021-08-07 21:25:20 --> Router Class Initialized
INFO - 2021-08-07 21:25:20 --> Output Class Initialized
INFO - 2021-08-07 21:25:20 --> Security Class Initialized
DEBUG - 2021-08-07 21:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 21:25:20 --> Input Class Initialized
INFO - 2021-08-07 21:25:20 --> Language Class Initialized
INFO - 2021-08-07 21:25:20 --> Loader Class Initialized
INFO - 2021-08-07 21:25:20 --> Helper loaded: url_helper
INFO - 2021-08-07 21:25:20 --> Helper loaded: file_helper
INFO - 2021-08-07 21:25:20 --> Database Driver Class Initialized
DEBUG - 2021-08-07 21:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 21:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 21:25:20 --> Controller Class Initialized
INFO - 2021-08-07 21:25:20 --> Helper loaded: cookie_helper
INFO - 2021-08-07 21:25:20 --> Model "CookieModel" initialized
INFO - 2021-08-07 21:25:20 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 21:25:20 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/success_stories.php
INFO - 2021-08-07 21:25:20 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 21:25:20 --> Final output sent to browser
DEBUG - 2021-08-07 21:25:20 --> Total execution time: 0.0190
INFO - 2021-08-07 21:25:23 --> Config Class Initialized
INFO - 2021-08-07 21:25:23 --> Hooks Class Initialized
DEBUG - 2021-08-07 21:25:23 --> UTF-8 Support Enabled
INFO - 2021-08-07 21:25:23 --> Utf8 Class Initialized
INFO - 2021-08-07 21:25:23 --> URI Class Initialized
INFO - 2021-08-07 21:25:23 --> Router Class Initialized
INFO - 2021-08-07 21:25:23 --> Output Class Initialized
INFO - 2021-08-07 21:25:23 --> Security Class Initialized
DEBUG - 2021-08-07 21:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 21:25:23 --> Input Class Initialized
INFO - 2021-08-07 21:25:23 --> Language Class Initialized
INFO - 2021-08-07 21:25:23 --> Loader Class Initialized
INFO - 2021-08-07 21:25:23 --> Helper loaded: url_helper
INFO - 2021-08-07 21:25:23 --> Helper loaded: file_helper
INFO - 2021-08-07 21:25:23 --> Database Driver Class Initialized
DEBUG - 2021-08-07 21:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 21:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 21:25:23 --> Controller Class Initialized
INFO - 2021-08-07 21:25:23 --> Helper loaded: cookie_helper
INFO - 2021-08-07 21:25:23 --> Model "CookieModel" initialized
INFO - 2021-08-07 21:25:23 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 21:25:23 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/success_stories.php
INFO - 2021-08-07 21:25:23 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 21:25:23 --> Final output sent to browser
DEBUG - 2021-08-07 21:25:23 --> Total execution time: 0.0186
INFO - 2021-08-07 22:16:03 --> Config Class Initialized
INFO - 2021-08-07 22:16:03 --> Hooks Class Initialized
DEBUG - 2021-08-07 22:16:03 --> UTF-8 Support Enabled
INFO - 2021-08-07 22:16:03 --> Utf8 Class Initialized
INFO - 2021-08-07 22:16:03 --> URI Class Initialized
INFO - 2021-08-07 22:16:03 --> Router Class Initialized
INFO - 2021-08-07 22:16:03 --> Output Class Initialized
INFO - 2021-08-07 22:16:03 --> Security Class Initialized
DEBUG - 2021-08-07 22:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-07 22:16:03 --> Input Class Initialized
INFO - 2021-08-07 22:16:03 --> Language Class Initialized
INFO - 2021-08-07 22:16:03 --> Loader Class Initialized
INFO - 2021-08-07 22:16:03 --> Helper loaded: url_helper
INFO - 2021-08-07 22:16:03 --> Helper loaded: file_helper
INFO - 2021-08-07 22:16:03 --> Database Driver Class Initialized
DEBUG - 2021-08-07 22:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-07 22:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-07 22:16:03 --> Controller Class Initialized
INFO - 2021-08-07 22:16:03 --> Helper loaded: cookie_helper
INFO - 2021-08-07 22:16:03 --> Model "CookieModel" initialized
INFO - 2021-08-07 22:16:03 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/header.php
INFO - 2021-08-07 22:16:03 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/user/team.php
INFO - 2021-08-07 22:16:03 --> File loaded: /home/igaptech/testing.igaptechnologies.com/application/views/layout/footer.php
INFO - 2021-08-07 22:16:03 --> Final output sent to browser
DEBUG - 2021-08-07 22:16:03 --> Total execution time: 0.0214
