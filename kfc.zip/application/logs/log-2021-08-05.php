<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-08-05 08:50:32 --> Config Class Initialized
INFO - 2021-08-05 08:50:32 --> Hooks Class Initialized
DEBUG - 2021-08-05 08:50:32 --> UTF-8 Support Enabled
INFO - 2021-08-05 08:50:32 --> Utf8 Class Initialized
INFO - 2021-08-05 08:50:32 --> URI Class Initialized
INFO - 2021-08-05 08:50:32 --> Router Class Initialized
INFO - 2021-08-05 08:50:32 --> Output Class Initialized
INFO - 2021-08-05 08:50:32 --> Security Class Initialized
DEBUG - 2021-08-05 08:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 08:50:32 --> Input Class Initialized
INFO - 2021-08-05 08:50:32 --> Language Class Initialized
INFO - 2021-08-05 08:50:32 --> Loader Class Initialized
INFO - 2021-08-05 08:50:32 --> Helper loaded: url_helper
INFO - 2021-08-05 08:50:32 --> Helper loaded: file_helper
INFO - 2021-08-05 08:50:32 --> Database Driver Class Initialized
DEBUG - 2021-08-05 08:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 08:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 08:50:32 --> Controller Class Initialized
INFO - 2021-08-05 08:50:32 --> Helper loaded: cookie_helper
INFO - 2021-08-05 08:50:32 --> Model "CookieModel" initialized
INFO - 2021-08-05 08:50:32 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 08:50:32 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/team.php
INFO - 2021-08-05 08:50:32 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 08:50:32 --> Final output sent to browser
DEBUG - 2021-08-05 08:50:32 --> Total execution time: 0.9766
INFO - 2021-08-05 08:51:08 --> Config Class Initialized
INFO - 2021-08-05 08:51:08 --> Hooks Class Initialized
DEBUG - 2021-08-05 08:51:08 --> UTF-8 Support Enabled
INFO - 2021-08-05 08:51:08 --> Utf8 Class Initialized
INFO - 2021-08-05 08:51:08 --> URI Class Initialized
INFO - 2021-08-05 08:51:08 --> Router Class Initialized
INFO - 2021-08-05 08:51:08 --> Output Class Initialized
INFO - 2021-08-05 08:51:08 --> Security Class Initialized
DEBUG - 2021-08-05 08:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 08:51:08 --> Input Class Initialized
INFO - 2021-08-05 08:51:08 --> Language Class Initialized
INFO - 2021-08-05 08:51:08 --> Loader Class Initialized
INFO - 2021-08-05 08:51:08 --> Helper loaded: url_helper
INFO - 2021-08-05 08:51:08 --> Helper loaded: file_helper
INFO - 2021-08-05 08:51:08 --> Database Driver Class Initialized
DEBUG - 2021-08-05 08:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 08:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 08:51:08 --> Controller Class Initialized
INFO - 2021-08-05 08:51:08 --> Helper loaded: cookie_helper
INFO - 2021-08-05 08:51:08 --> Model "CookieModel" initialized
INFO - 2021-08-05 08:51:08 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 08:51:08 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/team.php
INFO - 2021-08-05 08:51:08 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 08:51:08 --> Final output sent to browser
DEBUG - 2021-08-05 08:51:08 --> Total execution time: 0.0690
INFO - 2021-08-05 08:52:40 --> Config Class Initialized
INFO - 2021-08-05 08:52:40 --> Hooks Class Initialized
DEBUG - 2021-08-05 08:52:40 --> UTF-8 Support Enabled
INFO - 2021-08-05 08:52:40 --> Utf8 Class Initialized
INFO - 2021-08-05 08:52:40 --> URI Class Initialized
INFO - 2021-08-05 08:52:40 --> Router Class Initialized
INFO - 2021-08-05 08:52:40 --> Output Class Initialized
INFO - 2021-08-05 08:52:40 --> Security Class Initialized
DEBUG - 2021-08-05 08:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 08:52:40 --> Input Class Initialized
INFO - 2021-08-05 08:52:40 --> Language Class Initialized
INFO - 2021-08-05 08:52:40 --> Loader Class Initialized
INFO - 2021-08-05 08:52:40 --> Helper loaded: url_helper
INFO - 2021-08-05 08:52:40 --> Helper loaded: file_helper
INFO - 2021-08-05 08:52:40 --> Database Driver Class Initialized
DEBUG - 2021-08-05 08:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 08:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 08:52:40 --> Controller Class Initialized
INFO - 2021-08-05 08:52:40 --> Helper loaded: cookie_helper
INFO - 2021-08-05 08:52:40 --> Model "CookieModel" initialized
INFO - 2021-08-05 08:52:40 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 08:52:40 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/team.php
INFO - 2021-08-05 08:52:40 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 08:52:40 --> Final output sent to browser
DEBUG - 2021-08-05 08:52:40 --> Total execution time: 0.1179
INFO - 2021-08-05 08:53:34 --> Config Class Initialized
INFO - 2021-08-05 08:53:34 --> Hooks Class Initialized
DEBUG - 2021-08-05 08:53:34 --> UTF-8 Support Enabled
INFO - 2021-08-05 08:53:34 --> Utf8 Class Initialized
INFO - 2021-08-05 08:53:34 --> URI Class Initialized
INFO - 2021-08-05 08:53:34 --> Router Class Initialized
INFO - 2021-08-05 08:53:34 --> Output Class Initialized
INFO - 2021-08-05 08:53:34 --> Security Class Initialized
DEBUG - 2021-08-05 08:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 08:53:34 --> Input Class Initialized
INFO - 2021-08-05 08:53:34 --> Language Class Initialized
INFO - 2021-08-05 08:53:34 --> Loader Class Initialized
INFO - 2021-08-05 08:53:34 --> Helper loaded: url_helper
INFO - 2021-08-05 08:53:34 --> Helper loaded: file_helper
INFO - 2021-08-05 08:53:34 --> Database Driver Class Initialized
DEBUG - 2021-08-05 08:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 08:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 08:53:34 --> Controller Class Initialized
INFO - 2021-08-05 08:53:34 --> Helper loaded: cookie_helper
INFO - 2021-08-05 08:53:34 --> Model "CookieModel" initialized
INFO - 2021-08-05 08:53:34 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 08:53:34 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/team.php
INFO - 2021-08-05 08:53:34 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 08:53:34 --> Final output sent to browser
DEBUG - 2021-08-05 08:53:34 --> Total execution time: 0.0427
INFO - 2021-08-05 08:54:24 --> Config Class Initialized
INFO - 2021-08-05 08:54:24 --> Hooks Class Initialized
DEBUG - 2021-08-05 08:54:24 --> UTF-8 Support Enabled
INFO - 2021-08-05 08:54:24 --> Utf8 Class Initialized
INFO - 2021-08-05 08:54:24 --> URI Class Initialized
INFO - 2021-08-05 08:54:24 --> Router Class Initialized
INFO - 2021-08-05 08:54:24 --> Output Class Initialized
INFO - 2021-08-05 08:54:24 --> Security Class Initialized
DEBUG - 2021-08-05 08:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 08:54:24 --> Input Class Initialized
INFO - 2021-08-05 08:54:24 --> Language Class Initialized
INFO - 2021-08-05 08:54:24 --> Loader Class Initialized
INFO - 2021-08-05 08:54:24 --> Helper loaded: url_helper
INFO - 2021-08-05 08:54:24 --> Helper loaded: file_helper
INFO - 2021-08-05 08:54:24 --> Database Driver Class Initialized
DEBUG - 2021-08-05 08:54:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 08:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 08:54:24 --> Controller Class Initialized
INFO - 2021-08-05 08:54:24 --> Helper loaded: cookie_helper
INFO - 2021-08-05 08:54:24 --> Model "CookieModel" initialized
INFO - 2021-08-05 08:54:24 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 08:54:24 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/team.php
INFO - 2021-08-05 08:54:24 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 08:54:24 --> Final output sent to browser
DEBUG - 2021-08-05 08:54:24 --> Total execution time: 0.0398
INFO - 2021-08-05 08:54:36 --> Config Class Initialized
INFO - 2021-08-05 08:54:36 --> Hooks Class Initialized
DEBUG - 2021-08-05 08:54:36 --> UTF-8 Support Enabled
INFO - 2021-08-05 08:54:36 --> Utf8 Class Initialized
INFO - 2021-08-05 08:54:36 --> URI Class Initialized
INFO - 2021-08-05 08:54:36 --> Router Class Initialized
INFO - 2021-08-05 08:54:36 --> Output Class Initialized
INFO - 2021-08-05 08:54:36 --> Security Class Initialized
DEBUG - 2021-08-05 08:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 08:54:36 --> Input Class Initialized
INFO - 2021-08-05 08:54:36 --> Language Class Initialized
INFO - 2021-08-05 08:54:36 --> Loader Class Initialized
INFO - 2021-08-05 08:54:36 --> Helper loaded: url_helper
INFO - 2021-08-05 08:54:36 --> Helper loaded: file_helper
INFO - 2021-08-05 08:54:36 --> Database Driver Class Initialized
DEBUG - 2021-08-05 08:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 08:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 08:54:36 --> Controller Class Initialized
INFO - 2021-08-05 08:54:36 --> Helper loaded: cookie_helper
INFO - 2021-08-05 08:54:36 --> Model "CookieModel" initialized
INFO - 2021-08-05 08:54:36 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 08:54:36 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/team.php
INFO - 2021-08-05 08:54:36 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 08:54:36 --> Final output sent to browser
DEBUG - 2021-08-05 08:54:36 --> Total execution time: 0.0413
INFO - 2021-08-05 08:57:09 --> Config Class Initialized
INFO - 2021-08-05 08:57:09 --> Hooks Class Initialized
DEBUG - 2021-08-05 08:57:09 --> UTF-8 Support Enabled
INFO - 2021-08-05 08:57:09 --> Utf8 Class Initialized
INFO - 2021-08-05 08:57:09 --> URI Class Initialized
INFO - 2021-08-05 08:57:09 --> Router Class Initialized
INFO - 2021-08-05 08:57:09 --> Output Class Initialized
INFO - 2021-08-05 08:57:09 --> Security Class Initialized
DEBUG - 2021-08-05 08:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 08:57:09 --> Input Class Initialized
INFO - 2021-08-05 08:57:09 --> Language Class Initialized
INFO - 2021-08-05 08:57:09 --> Loader Class Initialized
INFO - 2021-08-05 08:57:09 --> Helper loaded: url_helper
INFO - 2021-08-05 08:57:09 --> Helper loaded: file_helper
INFO - 2021-08-05 08:57:09 --> Database Driver Class Initialized
DEBUG - 2021-08-05 08:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 08:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 08:57:09 --> Controller Class Initialized
INFO - 2021-08-05 08:57:09 --> Helper loaded: cookie_helper
INFO - 2021-08-05 08:57:09 --> Model "CookieModel" initialized
INFO - 2021-08-05 08:57:09 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 08:57:09 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/team.php
INFO - 2021-08-05 08:57:09 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 08:57:09 --> Final output sent to browser
DEBUG - 2021-08-05 08:57:09 --> Total execution time: 0.0621
INFO - 2021-08-05 08:59:24 --> Config Class Initialized
INFO - 2021-08-05 08:59:24 --> Hooks Class Initialized
DEBUG - 2021-08-05 08:59:24 --> UTF-8 Support Enabled
INFO - 2021-08-05 08:59:24 --> Utf8 Class Initialized
INFO - 2021-08-05 08:59:24 --> URI Class Initialized
INFO - 2021-08-05 08:59:24 --> Router Class Initialized
INFO - 2021-08-05 08:59:24 --> Output Class Initialized
INFO - 2021-08-05 08:59:24 --> Security Class Initialized
DEBUG - 2021-08-05 08:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 08:59:24 --> Input Class Initialized
INFO - 2021-08-05 08:59:24 --> Language Class Initialized
INFO - 2021-08-05 08:59:24 --> Loader Class Initialized
INFO - 2021-08-05 08:59:24 --> Helper loaded: url_helper
INFO - 2021-08-05 08:59:24 --> Helper loaded: file_helper
INFO - 2021-08-05 08:59:24 --> Database Driver Class Initialized
DEBUG - 2021-08-05 08:59:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 08:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 08:59:24 --> Controller Class Initialized
INFO - 2021-08-05 08:59:24 --> Helper loaded: cookie_helper
INFO - 2021-08-05 08:59:24 --> Model "CookieModel" initialized
INFO - 2021-08-05 08:59:24 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 08:59:24 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/team.php
INFO - 2021-08-05 08:59:24 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 08:59:24 --> Final output sent to browser
DEBUG - 2021-08-05 08:59:24 --> Total execution time: 0.0497
INFO - 2021-08-05 09:00:05 --> Config Class Initialized
INFO - 2021-08-05 09:00:05 --> Hooks Class Initialized
DEBUG - 2021-08-05 09:00:05 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:00:05 --> Utf8 Class Initialized
INFO - 2021-08-05 09:00:05 --> URI Class Initialized
INFO - 2021-08-05 09:00:05 --> Router Class Initialized
INFO - 2021-08-05 09:00:05 --> Output Class Initialized
INFO - 2021-08-05 09:00:05 --> Security Class Initialized
DEBUG - 2021-08-05 09:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:00:05 --> Input Class Initialized
INFO - 2021-08-05 09:00:05 --> Language Class Initialized
INFO - 2021-08-05 09:00:05 --> Loader Class Initialized
INFO - 2021-08-05 09:00:05 --> Helper loaded: url_helper
INFO - 2021-08-05 09:00:05 --> Helper loaded: file_helper
INFO - 2021-08-05 09:00:05 --> Database Driver Class Initialized
DEBUG - 2021-08-05 09:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 09:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 09:00:05 --> Controller Class Initialized
INFO - 2021-08-05 09:00:05 --> Helper loaded: cookie_helper
INFO - 2021-08-05 09:00:05 --> Model "CookieModel" initialized
INFO - 2021-08-05 09:00:05 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 09:00:05 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/team.php
INFO - 2021-08-05 09:00:05 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 09:00:05 --> Final output sent to browser
DEBUG - 2021-08-05 09:00:05 --> Total execution time: 0.0399
INFO - 2021-08-05 09:00:38 --> Config Class Initialized
INFO - 2021-08-05 09:00:38 --> Hooks Class Initialized
DEBUG - 2021-08-05 09:00:38 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:00:38 --> Utf8 Class Initialized
INFO - 2021-08-05 09:00:38 --> URI Class Initialized
INFO - 2021-08-05 09:00:38 --> Router Class Initialized
INFO - 2021-08-05 09:00:38 --> Output Class Initialized
INFO - 2021-08-05 09:00:38 --> Security Class Initialized
DEBUG - 2021-08-05 09:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:00:38 --> Input Class Initialized
INFO - 2021-08-05 09:00:38 --> Language Class Initialized
INFO - 2021-08-05 09:00:38 --> Loader Class Initialized
INFO - 2021-08-05 09:00:38 --> Helper loaded: url_helper
INFO - 2021-08-05 09:00:38 --> Helper loaded: file_helper
INFO - 2021-08-05 09:00:38 --> Database Driver Class Initialized
DEBUG - 2021-08-05 09:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 09:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 09:00:38 --> Controller Class Initialized
INFO - 2021-08-05 09:00:38 --> Helper loaded: cookie_helper
INFO - 2021-08-05 09:00:38 --> Model "CookieModel" initialized
INFO - 2021-08-05 09:00:38 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 09:00:38 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/team.php
INFO - 2021-08-05 09:00:38 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 09:00:38 --> Final output sent to browser
DEBUG - 2021-08-05 09:00:38 --> Total execution time: 0.0383
INFO - 2021-08-05 09:03:38 --> Config Class Initialized
INFO - 2021-08-05 09:03:38 --> Hooks Class Initialized
DEBUG - 2021-08-05 09:03:38 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:03:38 --> Utf8 Class Initialized
INFO - 2021-08-05 09:03:38 --> URI Class Initialized
INFO - 2021-08-05 09:03:38 --> Router Class Initialized
INFO - 2021-08-05 09:03:38 --> Output Class Initialized
INFO - 2021-08-05 09:03:38 --> Security Class Initialized
DEBUG - 2021-08-05 09:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:03:38 --> Input Class Initialized
INFO - 2021-08-05 09:03:38 --> Language Class Initialized
INFO - 2021-08-05 09:03:38 --> Loader Class Initialized
INFO - 2021-08-05 09:03:38 --> Helper loaded: url_helper
INFO - 2021-08-05 09:03:38 --> Helper loaded: file_helper
INFO - 2021-08-05 09:03:38 --> Database Driver Class Initialized
DEBUG - 2021-08-05 09:03:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 09:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 09:03:38 --> Controller Class Initialized
INFO - 2021-08-05 09:03:38 --> Helper loaded: cookie_helper
INFO - 2021-08-05 09:03:38 --> Model "CookieModel" initialized
INFO - 2021-08-05 09:03:38 --> Model "ContactModel" initialized
INFO - 2021-08-05 09:03:38 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 09:03:38 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/contact.php
INFO - 2021-08-05 09:03:38 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 09:03:38 --> Final output sent to browser
DEBUG - 2021-08-05 09:03:38 --> Total execution time: 0.1652
INFO - 2021-08-05 09:03:57 --> Config Class Initialized
INFO - 2021-08-05 09:03:57 --> Hooks Class Initialized
DEBUG - 2021-08-05 09:03:57 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:03:57 --> Utf8 Class Initialized
INFO - 2021-08-05 09:03:57 --> URI Class Initialized
INFO - 2021-08-05 09:03:57 --> Router Class Initialized
INFO - 2021-08-05 09:03:57 --> Output Class Initialized
INFO - 2021-08-05 09:03:57 --> Security Class Initialized
DEBUG - 2021-08-05 09:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:03:57 --> Input Class Initialized
INFO - 2021-08-05 09:03:57 --> Language Class Initialized
INFO - 2021-08-05 09:03:57 --> Loader Class Initialized
INFO - 2021-08-05 09:03:57 --> Helper loaded: url_helper
INFO - 2021-08-05 09:03:57 --> Helper loaded: file_helper
INFO - 2021-08-05 09:03:57 --> Database Driver Class Initialized
DEBUG - 2021-08-05 09:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 09:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 09:03:57 --> Controller Class Initialized
INFO - 2021-08-05 09:03:57 --> Helper loaded: cookie_helper
INFO - 2021-08-05 09:03:57 --> Model "CookieModel" initialized
INFO - 2021-08-05 09:03:57 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 09:03:57 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/functional_training.php
INFO - 2021-08-05 09:03:57 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 09:03:57 --> Final output sent to browser
DEBUG - 2021-08-05 09:03:57 --> Total execution time: 0.1051
INFO - 2021-08-05 09:04:01 --> Config Class Initialized
INFO - 2021-08-05 09:04:01 --> Hooks Class Initialized
DEBUG - 2021-08-05 09:04:01 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:04:01 --> Utf8 Class Initialized
INFO - 2021-08-05 09:04:01 --> URI Class Initialized
INFO - 2021-08-05 09:04:01 --> Router Class Initialized
INFO - 2021-08-05 09:04:01 --> Output Class Initialized
INFO - 2021-08-05 09:04:01 --> Security Class Initialized
DEBUG - 2021-08-05 09:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:04:01 --> Input Class Initialized
INFO - 2021-08-05 09:04:01 --> Language Class Initialized
INFO - 2021-08-05 09:04:01 --> Loader Class Initialized
INFO - 2021-08-05 09:04:01 --> Helper loaded: url_helper
INFO - 2021-08-05 09:04:01 --> Helper loaded: file_helper
INFO - 2021-08-05 09:04:01 --> Database Driver Class Initialized
DEBUG - 2021-08-05 09:04:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 09:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 09:04:01 --> Controller Class Initialized
INFO - 2021-08-05 09:04:01 --> Helper loaded: cookie_helper
INFO - 2021-08-05 09:04:01 --> Model "CookieModel" initialized
INFO - 2021-08-05 09:04:01 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 09:04:01 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/nutrition_coaching.php
INFO - 2021-08-05 09:04:01 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 09:04:01 --> Final output sent to browser
DEBUG - 2021-08-05 09:04:01 --> Total execution time: 0.0852
INFO - 2021-08-05 09:04:06 --> Config Class Initialized
INFO - 2021-08-05 09:04:06 --> Hooks Class Initialized
DEBUG - 2021-08-05 09:04:06 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:04:06 --> Utf8 Class Initialized
INFO - 2021-08-05 09:04:06 --> URI Class Initialized
INFO - 2021-08-05 09:04:06 --> Router Class Initialized
INFO - 2021-08-05 09:04:06 --> Output Class Initialized
INFO - 2021-08-05 09:04:06 --> Security Class Initialized
DEBUG - 2021-08-05 09:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:04:06 --> Input Class Initialized
INFO - 2021-08-05 09:04:06 --> Language Class Initialized
INFO - 2021-08-05 09:04:06 --> Loader Class Initialized
INFO - 2021-08-05 09:04:06 --> Helper loaded: url_helper
INFO - 2021-08-05 09:04:06 --> Helper loaded: file_helper
INFO - 2021-08-05 09:04:06 --> Database Driver Class Initialized
DEBUG - 2021-08-05 09:04:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 09:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 09:04:06 --> Controller Class Initialized
INFO - 2021-08-05 09:04:06 --> Helper loaded: cookie_helper
INFO - 2021-08-05 09:04:06 --> Model "CookieModel" initialized
INFO - 2021-08-05 09:04:06 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 09:04:06 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/team.php
INFO - 2021-08-05 09:04:06 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 09:04:06 --> Final output sent to browser
DEBUG - 2021-08-05 09:04:06 --> Total execution time: 0.0515
INFO - 2021-08-05 09:04:11 --> Config Class Initialized
INFO - 2021-08-05 09:04:11 --> Hooks Class Initialized
DEBUG - 2021-08-05 09:04:11 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:04:11 --> Utf8 Class Initialized
INFO - 2021-08-05 09:04:11 --> URI Class Initialized
INFO - 2021-08-05 09:04:11 --> Router Class Initialized
INFO - 2021-08-05 09:04:11 --> Output Class Initialized
INFO - 2021-08-05 09:04:11 --> Security Class Initialized
DEBUG - 2021-08-05 09:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:04:11 --> Input Class Initialized
INFO - 2021-08-05 09:04:11 --> Language Class Initialized
INFO - 2021-08-05 09:04:11 --> Loader Class Initialized
INFO - 2021-08-05 09:04:11 --> Helper loaded: url_helper
INFO - 2021-08-05 09:04:11 --> Helper loaded: file_helper
INFO - 2021-08-05 09:04:11 --> Database Driver Class Initialized
DEBUG - 2021-08-05 09:04:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 09:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 09:04:11 --> Controller Class Initialized
INFO - 2021-08-05 09:04:11 --> Helper loaded: cookie_helper
INFO - 2021-08-05 09:04:11 --> Model "CookieModel" initialized
INFO - 2021-08-05 09:04:11 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 09:04:11 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/team.php
INFO - 2021-08-05 09:04:11 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 09:04:11 --> Final output sent to browser
DEBUG - 2021-08-05 09:04:11 --> Total execution time: 0.0449
INFO - 2021-08-05 09:04:12 --> Config Class Initialized
INFO - 2021-08-05 09:04:12 --> Hooks Class Initialized
DEBUG - 2021-08-05 09:04:12 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:04:12 --> Utf8 Class Initialized
INFO - 2021-08-05 09:04:12 --> URI Class Initialized
INFO - 2021-08-05 09:04:12 --> Router Class Initialized
INFO - 2021-08-05 09:04:12 --> Output Class Initialized
INFO - 2021-08-05 09:04:12 --> Security Class Initialized
DEBUG - 2021-08-05 09:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:04:12 --> Input Class Initialized
INFO - 2021-08-05 09:04:12 --> Language Class Initialized
INFO - 2021-08-05 09:04:12 --> Loader Class Initialized
INFO - 2021-08-05 09:04:12 --> Helper loaded: url_helper
INFO - 2021-08-05 09:04:12 --> Helper loaded: file_helper
INFO - 2021-08-05 09:04:12 --> Database Driver Class Initialized
DEBUG - 2021-08-05 09:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 09:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 09:04:12 --> Controller Class Initialized
INFO - 2021-08-05 09:04:12 --> Helper loaded: cookie_helper
INFO - 2021-08-05 09:04:12 --> Model "CookieModel" initialized
INFO - 2021-08-05 09:04:12 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 09:04:12 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/about.php
INFO - 2021-08-05 09:04:12 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 09:04:12 --> Final output sent to browser
DEBUG - 2021-08-05 09:04:12 --> Total execution time: 0.0629
INFO - 2021-08-05 09:13:11 --> Config Class Initialized
INFO - 2021-08-05 09:13:11 --> Hooks Class Initialized
DEBUG - 2021-08-05 09:13:11 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:13:11 --> Utf8 Class Initialized
INFO - 2021-08-05 09:13:11 --> URI Class Initialized
INFO - 2021-08-05 09:13:11 --> Router Class Initialized
INFO - 2021-08-05 09:13:11 --> Output Class Initialized
INFO - 2021-08-05 09:13:11 --> Security Class Initialized
DEBUG - 2021-08-05 09:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:13:11 --> Input Class Initialized
INFO - 2021-08-05 09:13:11 --> Language Class Initialized
INFO - 2021-08-05 09:13:11 --> Loader Class Initialized
INFO - 2021-08-05 09:13:11 --> Helper loaded: url_helper
INFO - 2021-08-05 09:13:11 --> Helper loaded: file_helper
INFO - 2021-08-05 09:13:11 --> Database Driver Class Initialized
DEBUG - 2021-08-05 09:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 09:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 09:13:11 --> Controller Class Initialized
INFO - 2021-08-05 09:13:11 --> Helper loaded: cookie_helper
INFO - 2021-08-05 09:13:11 --> Model "CookieModel" initialized
INFO - 2021-08-05 09:13:11 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 09:13:11 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/about.php
INFO - 2021-08-05 09:13:11 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 09:13:11 --> Final output sent to browser
DEBUG - 2021-08-05 09:13:11 --> Total execution time: 0.1048
INFO - 2021-08-05 09:15:23 --> Config Class Initialized
INFO - 2021-08-05 09:15:23 --> Hooks Class Initialized
DEBUG - 2021-08-05 09:15:23 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:15:23 --> Utf8 Class Initialized
INFO - 2021-08-05 09:15:23 --> URI Class Initialized
INFO - 2021-08-05 09:15:23 --> Router Class Initialized
INFO - 2021-08-05 09:15:23 --> Output Class Initialized
INFO - 2021-08-05 09:15:23 --> Security Class Initialized
DEBUG - 2021-08-05 09:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:15:23 --> Input Class Initialized
INFO - 2021-08-05 09:15:23 --> Language Class Initialized
INFO - 2021-08-05 09:15:23 --> Loader Class Initialized
INFO - 2021-08-05 09:15:23 --> Helper loaded: url_helper
INFO - 2021-08-05 09:15:23 --> Helper loaded: file_helper
INFO - 2021-08-05 09:15:23 --> Database Driver Class Initialized
DEBUG - 2021-08-05 09:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 09:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 09:15:23 --> Controller Class Initialized
INFO - 2021-08-05 09:15:23 --> Helper loaded: cookie_helper
INFO - 2021-08-05 09:15:23 --> Model "CookieModel" initialized
INFO - 2021-08-05 09:15:23 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 09:15:23 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/nutrition_coaching.php
INFO - 2021-08-05 09:15:23 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 09:15:23 --> Final output sent to browser
DEBUG - 2021-08-05 09:15:23 --> Total execution time: 0.0602
INFO - 2021-08-05 09:15:27 --> Config Class Initialized
INFO - 2021-08-05 09:15:27 --> Hooks Class Initialized
DEBUG - 2021-08-05 09:15:27 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:15:27 --> Utf8 Class Initialized
INFO - 2021-08-05 09:15:27 --> URI Class Initialized
INFO - 2021-08-05 09:15:27 --> Router Class Initialized
INFO - 2021-08-05 09:15:27 --> Output Class Initialized
INFO - 2021-08-05 09:15:27 --> Security Class Initialized
DEBUG - 2021-08-05 09:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:15:27 --> Input Class Initialized
INFO - 2021-08-05 09:15:27 --> Language Class Initialized
INFO - 2021-08-05 09:15:27 --> Loader Class Initialized
INFO - 2021-08-05 09:15:27 --> Helper loaded: url_helper
INFO - 2021-08-05 09:15:27 --> Helper loaded: file_helper
INFO - 2021-08-05 09:15:27 --> Database Driver Class Initialized
DEBUG - 2021-08-05 09:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 09:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 09:15:27 --> Controller Class Initialized
INFO - 2021-08-05 09:15:27 --> Helper loaded: cookie_helper
INFO - 2021-08-05 09:15:27 --> Model "CookieModel" initialized
INFO - 2021-08-05 09:15:27 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 09:15:27 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/functional_training.php
INFO - 2021-08-05 09:15:27 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 09:15:27 --> Final output sent to browser
DEBUG - 2021-08-05 09:15:27 --> Total execution time: 0.0524
INFO - 2021-08-05 09:15:31 --> Config Class Initialized
INFO - 2021-08-05 09:15:31 --> Hooks Class Initialized
DEBUG - 2021-08-05 09:15:31 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:15:31 --> Utf8 Class Initialized
INFO - 2021-08-05 09:15:31 --> URI Class Initialized
INFO - 2021-08-05 09:15:31 --> Router Class Initialized
INFO - 2021-08-05 09:15:31 --> Output Class Initialized
INFO - 2021-08-05 09:15:31 --> Security Class Initialized
DEBUG - 2021-08-05 09:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:15:31 --> Input Class Initialized
INFO - 2021-08-05 09:15:31 --> Language Class Initialized
INFO - 2021-08-05 09:15:31 --> Loader Class Initialized
INFO - 2021-08-05 09:15:31 --> Helper loaded: url_helper
INFO - 2021-08-05 09:15:31 --> Helper loaded: file_helper
INFO - 2021-08-05 09:15:31 --> Database Driver Class Initialized
DEBUG - 2021-08-05 09:15:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 09:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 09:15:31 --> Controller Class Initialized
INFO - 2021-08-05 09:15:31 --> Helper loaded: cookie_helper
INFO - 2021-08-05 09:15:31 --> Model "CookieModel" initialized
INFO - 2021-08-05 09:15:31 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 09:15:31 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-05 09:15:31 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 09:15:31 --> Final output sent to browser
DEBUG - 2021-08-05 09:15:31 --> Total execution time: 0.1105
INFO - 2021-08-05 09:17:19 --> Config Class Initialized
INFO - 2021-08-05 09:17:19 --> Hooks Class Initialized
DEBUG - 2021-08-05 09:17:19 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:17:19 --> Utf8 Class Initialized
INFO - 2021-08-05 09:17:19 --> URI Class Initialized
INFO - 2021-08-05 09:17:19 --> Router Class Initialized
INFO - 2021-08-05 09:17:19 --> Output Class Initialized
INFO - 2021-08-05 09:17:19 --> Security Class Initialized
DEBUG - 2021-08-05 09:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:17:19 --> Input Class Initialized
INFO - 2021-08-05 09:17:19 --> Language Class Initialized
INFO - 2021-08-05 09:17:19 --> Loader Class Initialized
INFO - 2021-08-05 09:17:19 --> Helper loaded: url_helper
INFO - 2021-08-05 09:17:19 --> Helper loaded: file_helper
INFO - 2021-08-05 09:17:19 --> Database Driver Class Initialized
DEBUG - 2021-08-05 09:17:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 09:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 09:17:19 --> Controller Class Initialized
INFO - 2021-08-05 09:17:19 --> Helper loaded: cookie_helper
INFO - 2021-08-05 09:17:19 --> Model "CookieModel" initialized
INFO - 2021-08-05 09:17:19 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 09:17:19 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-05 09:17:19 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 09:17:19 --> Final output sent to browser
DEBUG - 2021-08-05 09:17:19 --> Total execution time: 0.1010
INFO - 2021-08-05 09:18:25 --> Config Class Initialized
INFO - 2021-08-05 09:18:25 --> Hooks Class Initialized
DEBUG - 2021-08-05 09:18:25 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:18:25 --> Utf8 Class Initialized
INFO - 2021-08-05 09:18:25 --> URI Class Initialized
INFO - 2021-08-05 09:18:25 --> Router Class Initialized
INFO - 2021-08-05 09:18:25 --> Output Class Initialized
INFO - 2021-08-05 09:18:25 --> Security Class Initialized
DEBUG - 2021-08-05 09:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:18:25 --> Input Class Initialized
INFO - 2021-08-05 09:18:25 --> Language Class Initialized
INFO - 2021-08-05 09:18:25 --> Loader Class Initialized
INFO - 2021-08-05 09:18:25 --> Helper loaded: url_helper
INFO - 2021-08-05 09:18:25 --> Helper loaded: file_helper
INFO - 2021-08-05 09:18:25 --> Database Driver Class Initialized
DEBUG - 2021-08-05 09:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 09:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 09:18:25 --> Controller Class Initialized
INFO - 2021-08-05 09:18:25 --> Helper loaded: cookie_helper
INFO - 2021-08-05 09:18:25 --> Model "CookieModel" initialized
INFO - 2021-08-05 09:18:25 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 09:18:25 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/nutrition_coaching.php
INFO - 2021-08-05 09:18:25 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 09:18:25 --> Final output sent to browser
DEBUG - 2021-08-05 09:18:25 --> Total execution time: 0.0524
INFO - 2021-08-05 09:18:27 --> Config Class Initialized
INFO - 2021-08-05 09:18:27 --> Hooks Class Initialized
DEBUG - 2021-08-05 09:18:27 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:18:27 --> Utf8 Class Initialized
INFO - 2021-08-05 09:18:27 --> URI Class Initialized
INFO - 2021-08-05 09:18:27 --> Router Class Initialized
INFO - 2021-08-05 09:18:27 --> Output Class Initialized
INFO - 2021-08-05 09:18:27 --> Security Class Initialized
DEBUG - 2021-08-05 09:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:18:27 --> Input Class Initialized
INFO - 2021-08-05 09:18:27 --> Language Class Initialized
INFO - 2021-08-05 09:18:27 --> Loader Class Initialized
INFO - 2021-08-05 09:18:27 --> Helper loaded: url_helper
INFO - 2021-08-05 09:18:27 --> Helper loaded: file_helper
INFO - 2021-08-05 09:18:27 --> Database Driver Class Initialized
DEBUG - 2021-08-05 09:18:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 09:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 09:18:27 --> Controller Class Initialized
INFO - 2021-08-05 09:18:27 --> Helper loaded: cookie_helper
INFO - 2021-08-05 09:18:27 --> Model "CookieModel" initialized
INFO - 2021-08-05 09:18:27 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 09:18:27 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-05 09:18:27 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 09:18:27 --> Final output sent to browser
DEBUG - 2021-08-05 09:18:27 --> Total execution time: 0.0470
INFO - 2021-08-05 09:18:28 --> Config Class Initialized
INFO - 2021-08-05 09:18:28 --> Hooks Class Initialized
DEBUG - 2021-08-05 09:18:28 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:18:28 --> Utf8 Class Initialized
INFO - 2021-08-05 09:18:28 --> URI Class Initialized
DEBUG - 2021-08-05 09:18:28 --> No URI present. Default controller set.
INFO - 2021-08-05 09:18:28 --> Router Class Initialized
INFO - 2021-08-05 09:18:28 --> Output Class Initialized
INFO - 2021-08-05 09:18:28 --> Security Class Initialized
DEBUG - 2021-08-05 09:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:18:28 --> Input Class Initialized
INFO - 2021-08-05 09:18:28 --> Language Class Initialized
INFO - 2021-08-05 09:18:28 --> Loader Class Initialized
INFO - 2021-08-05 09:18:28 --> Helper loaded: url_helper
INFO - 2021-08-05 09:18:28 --> Helper loaded: file_helper
INFO - 2021-08-05 09:18:28 --> Database Driver Class Initialized
DEBUG - 2021-08-05 09:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 09:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 09:18:28 --> Controller Class Initialized
INFO - 2021-08-05 09:18:28 --> Helper loaded: cookie_helper
INFO - 2021-08-05 09:18:28 --> Model "CookieModel" initialized
INFO - 2021-08-05 09:18:28 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 09:18:28 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-05 09:18:28 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 09:18:28 --> Final output sent to browser
DEBUG - 2021-08-05 09:18:28 --> Total execution time: 0.1221
INFO - 2021-08-05 09:31:13 --> Config Class Initialized
INFO - 2021-08-05 09:31:13 --> Hooks Class Initialized
DEBUG - 2021-08-05 09:31:13 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:31:13 --> Utf8 Class Initialized
INFO - 2021-08-05 09:31:13 --> URI Class Initialized
DEBUG - 2021-08-05 09:31:13 --> No URI present. Default controller set.
INFO - 2021-08-05 09:31:13 --> Router Class Initialized
INFO - 2021-08-05 09:31:13 --> Output Class Initialized
INFO - 2021-08-05 09:31:13 --> Security Class Initialized
DEBUG - 2021-08-05 09:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:31:13 --> Input Class Initialized
INFO - 2021-08-05 09:31:13 --> Language Class Initialized
INFO - 2021-08-05 09:31:13 --> Loader Class Initialized
INFO - 2021-08-05 09:31:13 --> Helper loaded: url_helper
INFO - 2021-08-05 09:31:13 --> Helper loaded: file_helper
INFO - 2021-08-05 09:31:13 --> Database Driver Class Initialized
DEBUG - 2021-08-05 09:31:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 09:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 09:31:13 --> Controller Class Initialized
INFO - 2021-08-05 09:31:13 --> Helper loaded: cookie_helper
INFO - 2021-08-05 09:31:13 --> Model "CookieModel" initialized
INFO - 2021-08-05 09:31:13 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 09:31:13 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-05 09:31:13 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 09:31:13 --> Final output sent to browser
DEBUG - 2021-08-05 09:31:13 --> Total execution time: 0.1270
INFO - 2021-08-05 09:31:34 --> Config Class Initialized
INFO - 2021-08-05 09:31:34 --> Hooks Class Initialized
DEBUG - 2021-08-05 09:31:34 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:31:34 --> Utf8 Class Initialized
INFO - 2021-08-05 09:31:34 --> URI Class Initialized
DEBUG - 2021-08-05 09:31:34 --> No URI present. Default controller set.
INFO - 2021-08-05 09:31:34 --> Router Class Initialized
INFO - 2021-08-05 09:31:34 --> Output Class Initialized
INFO - 2021-08-05 09:31:34 --> Security Class Initialized
DEBUG - 2021-08-05 09:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:31:34 --> Input Class Initialized
INFO - 2021-08-05 09:31:34 --> Language Class Initialized
INFO - 2021-08-05 09:31:34 --> Loader Class Initialized
INFO - 2021-08-05 09:31:34 --> Helper loaded: url_helper
INFO - 2021-08-05 09:31:34 --> Helper loaded: file_helper
INFO - 2021-08-05 09:31:34 --> Database Driver Class Initialized
DEBUG - 2021-08-05 09:31:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 09:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 09:31:34 --> Controller Class Initialized
INFO - 2021-08-05 09:31:34 --> Helper loaded: cookie_helper
INFO - 2021-08-05 09:31:34 --> Model "CookieModel" initialized
INFO - 2021-08-05 09:31:34 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 09:31:34 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-05 09:31:34 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 09:31:34 --> Final output sent to browser
DEBUG - 2021-08-05 09:31:34 --> Total execution time: 0.0468
INFO - 2021-08-05 09:32:05 --> Config Class Initialized
INFO - 2021-08-05 09:32:05 --> Hooks Class Initialized
DEBUG - 2021-08-05 09:32:05 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:32:05 --> Utf8 Class Initialized
INFO - 2021-08-05 09:32:05 --> URI Class Initialized
DEBUG - 2021-08-05 09:32:05 --> No URI present. Default controller set.
INFO - 2021-08-05 09:32:05 --> Router Class Initialized
INFO - 2021-08-05 09:32:05 --> Output Class Initialized
INFO - 2021-08-05 09:32:05 --> Security Class Initialized
DEBUG - 2021-08-05 09:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:32:05 --> Input Class Initialized
INFO - 2021-08-05 09:32:05 --> Language Class Initialized
INFO - 2021-08-05 09:32:05 --> Loader Class Initialized
INFO - 2021-08-05 09:32:05 --> Helper loaded: url_helper
INFO - 2021-08-05 09:32:05 --> Helper loaded: file_helper
INFO - 2021-08-05 09:32:05 --> Database Driver Class Initialized
DEBUG - 2021-08-05 09:32:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 09:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 09:32:05 --> Controller Class Initialized
INFO - 2021-08-05 09:32:05 --> Helper loaded: cookie_helper
INFO - 2021-08-05 09:32:05 --> Model "CookieModel" initialized
INFO - 2021-08-05 09:32:05 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 09:32:05 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-05 09:32:05 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 09:32:05 --> Final output sent to browser
DEBUG - 2021-08-05 09:32:05 --> Total execution time: 0.0435
INFO - 2021-08-05 09:32:18 --> Config Class Initialized
INFO - 2021-08-05 09:32:18 --> Hooks Class Initialized
DEBUG - 2021-08-05 09:32:18 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:32:18 --> Utf8 Class Initialized
INFO - 2021-08-05 09:32:18 --> URI Class Initialized
DEBUG - 2021-08-05 09:32:18 --> No URI present. Default controller set.
INFO - 2021-08-05 09:32:18 --> Router Class Initialized
INFO - 2021-08-05 09:32:18 --> Output Class Initialized
INFO - 2021-08-05 09:32:18 --> Security Class Initialized
DEBUG - 2021-08-05 09:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:32:18 --> Input Class Initialized
INFO - 2021-08-05 09:32:18 --> Language Class Initialized
INFO - 2021-08-05 09:32:18 --> Loader Class Initialized
INFO - 2021-08-05 09:32:18 --> Helper loaded: url_helper
INFO - 2021-08-05 09:32:18 --> Helper loaded: file_helper
INFO - 2021-08-05 09:32:18 --> Database Driver Class Initialized
DEBUG - 2021-08-05 09:32:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 09:32:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 09:32:18 --> Controller Class Initialized
INFO - 2021-08-05 09:32:18 --> Helper loaded: cookie_helper
INFO - 2021-08-05 09:32:18 --> Model "CookieModel" initialized
INFO - 2021-08-05 09:32:18 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 09:32:18 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-05 09:32:18 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 09:32:19 --> Final output sent to browser
DEBUG - 2021-08-05 09:32:19 --> Total execution time: 0.0456
INFO - 2021-08-05 09:34:59 --> Config Class Initialized
INFO - 2021-08-05 09:34:59 --> Hooks Class Initialized
DEBUG - 2021-08-05 09:34:59 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:34:59 --> Utf8 Class Initialized
INFO - 2021-08-05 09:34:59 --> URI Class Initialized
DEBUG - 2021-08-05 09:34:59 --> No URI present. Default controller set.
INFO - 2021-08-05 09:34:59 --> Router Class Initialized
INFO - 2021-08-05 09:34:59 --> Output Class Initialized
INFO - 2021-08-05 09:34:59 --> Security Class Initialized
DEBUG - 2021-08-05 09:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:34:59 --> Input Class Initialized
INFO - 2021-08-05 09:34:59 --> Language Class Initialized
INFO - 2021-08-05 09:34:59 --> Loader Class Initialized
INFO - 2021-08-05 09:34:59 --> Helper loaded: url_helper
INFO - 2021-08-05 09:34:59 --> Helper loaded: file_helper
INFO - 2021-08-05 09:34:59 --> Database Driver Class Initialized
DEBUG - 2021-08-05 09:34:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 09:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 09:34:59 --> Controller Class Initialized
INFO - 2021-08-05 09:34:59 --> Helper loaded: cookie_helper
INFO - 2021-08-05 09:34:59 --> Model "CookieModel" initialized
INFO - 2021-08-05 09:34:59 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 09:34:59 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-05 09:34:59 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 09:34:59 --> Final output sent to browser
DEBUG - 2021-08-05 09:34:59 --> Total execution time: 0.0537
INFO - 2021-08-05 09:36:46 --> Config Class Initialized
INFO - 2021-08-05 09:36:46 --> Hooks Class Initialized
DEBUG - 2021-08-05 09:36:46 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:36:46 --> Utf8 Class Initialized
INFO - 2021-08-05 09:36:46 --> URI Class Initialized
INFO - 2021-08-05 09:36:46 --> Router Class Initialized
INFO - 2021-08-05 09:36:46 --> Output Class Initialized
INFO - 2021-08-05 09:36:46 --> Security Class Initialized
DEBUG - 2021-08-05 09:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:36:46 --> Input Class Initialized
INFO - 2021-08-05 09:36:46 --> Language Class Initialized
INFO - 2021-08-05 09:36:46 --> Loader Class Initialized
INFO - 2021-08-05 09:36:46 --> Helper loaded: url_helper
INFO - 2021-08-05 09:36:46 --> Helper loaded: file_helper
INFO - 2021-08-05 09:36:46 --> Database Driver Class Initialized
DEBUG - 2021-08-05 09:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 09:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 09:36:46 --> Controller Class Initialized
INFO - 2021-08-05 09:36:46 --> Helper loaded: cookie_helper
INFO - 2021-08-05 09:36:46 --> Model "CookieModel" initialized
INFO - 2021-08-05 09:36:46 --> Model "ContactModel" initialized
INFO - 2021-08-05 09:36:46 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 09:36:46 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/contact.php
INFO - 2021-08-05 09:36:46 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 09:36:46 --> Final output sent to browser
DEBUG - 2021-08-05 09:36:46 --> Total execution time: 0.0478
INFO - 2021-08-05 09:37:13 --> Config Class Initialized
INFO - 2021-08-05 09:37:13 --> Hooks Class Initialized
DEBUG - 2021-08-05 09:37:13 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:37:13 --> Utf8 Class Initialized
INFO - 2021-08-05 09:37:13 --> URI Class Initialized
INFO - 2021-08-05 09:37:13 --> Router Class Initialized
INFO - 2021-08-05 09:37:13 --> Output Class Initialized
INFO - 2021-08-05 09:37:13 --> Security Class Initialized
DEBUG - 2021-08-05 09:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:37:13 --> Input Class Initialized
INFO - 2021-08-05 09:37:13 --> Language Class Initialized
INFO - 2021-08-05 09:37:13 --> Loader Class Initialized
INFO - 2021-08-05 09:37:13 --> Helper loaded: url_helper
INFO - 2021-08-05 09:37:13 --> Helper loaded: file_helper
INFO - 2021-08-05 09:37:13 --> Database Driver Class Initialized
DEBUG - 2021-08-05 09:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 09:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 09:37:13 --> Controller Class Initialized
INFO - 2021-08-05 09:37:13 --> Helper loaded: cookie_helper
INFO - 2021-08-05 09:37:13 --> Model "CookieModel" initialized
INFO - 2021-08-05 09:37:13 --> Model "ContactModel" initialized
INFO - 2021-08-05 09:37:13 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 09:37:13 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/contact.php
INFO - 2021-08-05 09:37:13 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 09:37:13 --> Final output sent to browser
DEBUG - 2021-08-05 09:37:13 --> Total execution time: 0.0454
INFO - 2021-08-05 09:37:43 --> Config Class Initialized
INFO - 2021-08-05 09:37:43 --> Hooks Class Initialized
DEBUG - 2021-08-05 09:37:43 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:37:43 --> Utf8 Class Initialized
INFO - 2021-08-05 09:37:43 --> URI Class Initialized
INFO - 2021-08-05 09:37:43 --> Router Class Initialized
INFO - 2021-08-05 09:37:43 --> Output Class Initialized
INFO - 2021-08-05 09:37:43 --> Security Class Initialized
DEBUG - 2021-08-05 09:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:37:43 --> Input Class Initialized
INFO - 2021-08-05 09:37:43 --> Language Class Initialized
INFO - 2021-08-05 09:37:43 --> Loader Class Initialized
INFO - 2021-08-05 09:37:43 --> Helper loaded: url_helper
INFO - 2021-08-05 09:37:43 --> Helper loaded: file_helper
INFO - 2021-08-05 09:37:43 --> Database Driver Class Initialized
DEBUG - 2021-08-05 09:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 09:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 09:37:43 --> Controller Class Initialized
INFO - 2021-08-05 09:37:43 --> Helper loaded: cookie_helper
INFO - 2021-08-05 09:37:43 --> Model "CookieModel" initialized
INFO - 2021-08-05 09:37:43 --> Model "ContactModel" initialized
INFO - 2021-08-05 09:37:43 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 09:37:43 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/contact.php
INFO - 2021-08-05 09:37:43 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 09:37:43 --> Final output sent to browser
DEBUG - 2021-08-05 09:37:43 --> Total execution time: 0.0460
INFO - 2021-08-05 09:37:55 --> Config Class Initialized
INFO - 2021-08-05 09:37:55 --> Hooks Class Initialized
DEBUG - 2021-08-05 09:37:55 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:37:55 --> Utf8 Class Initialized
INFO - 2021-08-05 09:37:55 --> URI Class Initialized
INFO - 2021-08-05 09:37:55 --> Router Class Initialized
INFO - 2021-08-05 09:37:55 --> Output Class Initialized
INFO - 2021-08-05 09:37:55 --> Security Class Initialized
DEBUG - 2021-08-05 09:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:37:55 --> Input Class Initialized
INFO - 2021-08-05 09:37:55 --> Language Class Initialized
INFO - 2021-08-05 09:37:55 --> Loader Class Initialized
INFO - 2021-08-05 09:37:55 --> Helper loaded: url_helper
INFO - 2021-08-05 09:37:55 --> Helper loaded: file_helper
INFO - 2021-08-05 09:37:55 --> Database Driver Class Initialized
DEBUG - 2021-08-05 09:37:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 09:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 09:37:55 --> Controller Class Initialized
INFO - 2021-08-05 09:37:55 --> Helper loaded: cookie_helper
INFO - 2021-08-05 09:37:55 --> Model "CookieModel" initialized
INFO - 2021-08-05 09:37:55 --> Model "ContactModel" initialized
INFO - 2021-08-05 09:37:55 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 09:37:55 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/contact.php
INFO - 2021-08-05 09:37:55 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 09:37:55 --> Final output sent to browser
DEBUG - 2021-08-05 09:37:55 --> Total execution time: 0.0479
INFO - 2021-08-05 09:38:03 --> Config Class Initialized
INFO - 2021-08-05 09:38:03 --> Hooks Class Initialized
DEBUG - 2021-08-05 09:38:03 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:38:03 --> Utf8 Class Initialized
INFO - 2021-08-05 09:38:03 --> URI Class Initialized
INFO - 2021-08-05 09:38:03 --> Config Class Initialized
INFO - 2021-08-05 09:38:03 --> Hooks Class Initialized
INFO - 2021-08-05 09:38:03 --> Router Class Initialized
DEBUG - 2021-08-05 09:38:03 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:38:03 --> Output Class Initialized
INFO - 2021-08-05 09:38:03 --> Utf8 Class Initialized
INFO - 2021-08-05 09:38:03 --> Security Class Initialized
DEBUG - 2021-08-05 09:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:38:03 --> Input Class Initialized
INFO - 2021-08-05 09:38:03 --> Language Class Initialized
INFO - 2021-08-05 09:38:03 --> Config Class Initialized
INFO - 2021-08-05 09:38:03 --> Hooks Class Initialized
DEBUG - 2021-08-05 09:38:03 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:38:03 --> Utf8 Class Initialized
INFO - 2021-08-05 09:38:03 --> URI Class Initialized
INFO - 2021-08-05 09:38:03 --> URI Class Initialized
INFO - 2021-08-05 09:38:03 --> Router Class Initialized
INFO - 2021-08-05 09:38:03 --> Router Class Initialized
INFO - 2021-08-05 09:38:03 --> Output Class Initialized
INFO - 2021-08-05 09:38:03 --> Security Class Initialized
DEBUG - 2021-08-05 09:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:38:03 --> Input Class Initialized
INFO - 2021-08-05 09:38:03 --> Language Class Initialized
INFO - 2021-08-05 09:38:03 --> Output Class Initialized
INFO - 2021-08-05 09:38:03 --> Security Class Initialized
DEBUG - 2021-08-05 09:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:38:03 --> Input Class Initialized
INFO - 2021-08-05 09:38:03 --> Language Class Initialized
ERROR - 2021-08-05 09:38:03 --> 404 Page Not Found: Assets/js
ERROR - 2021-08-05 09:38:03 --> 404 Page Not Found: Assets/js
ERROR - 2021-08-05 09:38:03 --> 404 Page Not Found: Assets/js
INFO - 2021-08-05 09:38:03 --> Config Class Initialized
INFO - 2021-08-05 09:38:03 --> Hooks Class Initialized
INFO - 2021-08-05 09:38:03 --> Config Class Initialized
INFO - 2021-08-05 09:38:03 --> Hooks Class Initialized
DEBUG - 2021-08-05 09:38:03 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:38:03 --> Utf8 Class Initialized
DEBUG - 2021-08-05 09:38:03 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:38:03 --> Utf8 Class Initialized
INFO - 2021-08-05 09:38:03 --> URI Class Initialized
INFO - 2021-08-05 09:38:03 --> URI Class Initialized
INFO - 2021-08-05 09:38:03 --> Router Class Initialized
INFO - 2021-08-05 09:38:03 --> Router Class Initialized
INFO - 2021-08-05 09:38:03 --> Output Class Initialized
INFO - 2021-08-05 09:38:03 --> Output Class Initialized
INFO - 2021-08-05 09:38:03 --> Security Class Initialized
INFO - 2021-08-05 09:38:03 --> Security Class Initialized
DEBUG - 2021-08-05 09:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:38:03 --> Input Class Initialized
DEBUG - 2021-08-05 09:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:38:03 --> Input Class Initialized
INFO - 2021-08-05 09:38:03 --> Language Class Initialized
INFO - 2021-08-05 09:38:03 --> Language Class Initialized
ERROR - 2021-08-05 09:38:03 --> 404 Page Not Found: Assets/css
ERROR - 2021-08-05 09:38:03 --> 404 Page Not Found: Assets/css
INFO - 2021-08-05 09:38:27 --> Config Class Initialized
INFO - 2021-08-05 09:38:27 --> Hooks Class Initialized
DEBUG - 2021-08-05 09:38:27 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:38:27 --> Utf8 Class Initialized
INFO - 2021-08-05 09:38:27 --> URI Class Initialized
INFO - 2021-08-05 09:38:27 --> Router Class Initialized
INFO - 2021-08-05 09:38:27 --> Output Class Initialized
INFO - 2021-08-05 09:38:27 --> Security Class Initialized
DEBUG - 2021-08-05 09:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:38:27 --> Input Class Initialized
INFO - 2021-08-05 09:38:27 --> Language Class Initialized
INFO - 2021-08-05 09:38:27 --> Loader Class Initialized
INFO - 2021-08-05 09:38:27 --> Helper loaded: url_helper
INFO - 2021-08-05 09:38:27 --> Helper loaded: file_helper
INFO - 2021-08-05 09:38:27 --> Database Driver Class Initialized
DEBUG - 2021-08-05 09:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 09:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 09:38:27 --> Controller Class Initialized
INFO - 2021-08-05 09:38:27 --> Helper loaded: cookie_helper
INFO - 2021-08-05 09:38:27 --> Model "CookieModel" initialized
INFO - 2021-08-05 09:38:27 --> Model "ContactModel" initialized
INFO - 2021-08-05 09:38:27 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 09:38:27 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/contact.php
INFO - 2021-08-05 09:38:27 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 09:38:27 --> Final output sent to browser
DEBUG - 2021-08-05 09:38:27 --> Total execution time: 0.0545
INFO - 2021-08-05 09:38:27 --> Config Class Initialized
INFO - 2021-08-05 09:38:27 --> Hooks Class Initialized
DEBUG - 2021-08-05 09:38:27 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:38:27 --> Utf8 Class Initialized
INFO - 2021-08-05 09:38:27 --> URI Class Initialized
INFO - 2021-08-05 09:38:27 --> Router Class Initialized
INFO - 2021-08-05 09:38:27 --> Output Class Initialized
INFO - 2021-08-05 09:38:27 --> Security Class Initialized
INFO - 2021-08-05 09:38:27 --> Config Class Initialized
INFO - 2021-08-05 09:38:27 --> Hooks Class Initialized
DEBUG - 2021-08-05 09:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:38:27 --> Input Class Initialized
INFO - 2021-08-05 09:38:27 --> Language Class Initialized
ERROR - 2021-08-05 09:38:27 --> 404 Page Not Found: Assets/css
DEBUG - 2021-08-05 09:38:27 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:38:27 --> Utf8 Class Initialized
INFO - 2021-08-05 09:38:27 --> URI Class Initialized
INFO - 2021-08-05 09:38:27 --> Router Class Initialized
INFO - 2021-08-05 09:38:27 --> Output Class Initialized
INFO - 2021-08-05 09:38:27 --> Security Class Initialized
DEBUG - 2021-08-05 09:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:38:27 --> Input Class Initialized
INFO - 2021-08-05 09:38:27 --> Language Class Initialized
ERROR - 2021-08-05 09:38:27 --> 404 Page Not Found: Assets/css
INFO - 2021-08-05 09:38:28 --> Config Class Initialized
INFO - 2021-08-05 09:38:28 --> Hooks Class Initialized
DEBUG - 2021-08-05 09:38:28 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:38:28 --> Utf8 Class Initialized
INFO - 2021-08-05 09:38:28 --> Config Class Initialized
INFO - 2021-08-05 09:38:28 --> Hooks Class Initialized
INFO - 2021-08-05 09:38:28 --> URI Class Initialized
DEBUG - 2021-08-05 09:38:28 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:38:28 --> Router Class Initialized
INFO - 2021-08-05 09:38:28 --> Utf8 Class Initialized
INFO - 2021-08-05 09:38:28 --> URI Class Initialized
INFO - 2021-08-05 09:38:28 --> Output Class Initialized
INFO - 2021-08-05 09:38:28 --> Router Class Initialized
INFO - 2021-08-05 09:38:28 --> Security Class Initialized
INFO - 2021-08-05 09:38:28 --> Output Class Initialized
DEBUG - 2021-08-05 09:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:38:28 --> Input Class Initialized
INFO - 2021-08-05 09:38:28 --> Security Class Initialized
INFO - 2021-08-05 09:38:28 --> Language Class Initialized
DEBUG - 2021-08-05 09:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:38:28 --> Input Class Initialized
INFO - 2021-08-05 09:38:28 --> Language Class Initialized
ERROR - 2021-08-05 09:38:28 --> 404 Page Not Found: Assets/js
ERROR - 2021-08-05 09:38:28 --> 404 Page Not Found: Assets/js
INFO - 2021-08-05 09:38:28 --> Config Class Initialized
INFO - 2021-08-05 09:38:28 --> Hooks Class Initialized
DEBUG - 2021-08-05 09:38:28 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:38:28 --> Utf8 Class Initialized
INFO - 2021-08-05 09:38:28 --> URI Class Initialized
INFO - 2021-08-05 09:38:28 --> Router Class Initialized
INFO - 2021-08-05 09:38:28 --> Output Class Initialized
INFO - 2021-08-05 09:38:28 --> Security Class Initialized
DEBUG - 2021-08-05 09:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:38:28 --> Input Class Initialized
INFO - 2021-08-05 09:38:28 --> Language Class Initialized
ERROR - 2021-08-05 09:38:28 --> 404 Page Not Found: Assets/js
INFO - 2021-08-05 09:39:27 --> Config Class Initialized
INFO - 2021-08-05 09:39:27 --> Hooks Class Initialized
DEBUG - 2021-08-05 09:39:27 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:39:27 --> Utf8 Class Initialized
INFO - 2021-08-05 09:39:27 --> URI Class Initialized
INFO - 2021-08-05 09:39:27 --> Router Class Initialized
INFO - 2021-08-05 09:39:27 --> Output Class Initialized
INFO - 2021-08-05 09:39:27 --> Security Class Initialized
DEBUG - 2021-08-05 09:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:39:27 --> Input Class Initialized
INFO - 2021-08-05 09:39:27 --> Language Class Initialized
INFO - 2021-08-05 09:39:27 --> Loader Class Initialized
INFO - 2021-08-05 09:39:27 --> Helper loaded: url_helper
INFO - 2021-08-05 09:39:27 --> Helper loaded: file_helper
INFO - 2021-08-05 09:39:27 --> Database Driver Class Initialized
DEBUG - 2021-08-05 09:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 09:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 09:39:27 --> Controller Class Initialized
INFO - 2021-08-05 09:39:27 --> Helper loaded: cookie_helper
INFO - 2021-08-05 09:39:27 --> Model "CookieModel" initialized
INFO - 2021-08-05 09:39:27 --> Model "ContactModel" initialized
INFO - 2021-08-05 09:39:27 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 09:39:27 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/contact.php
INFO - 2021-08-05 09:39:27 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 09:39:27 --> Final output sent to browser
DEBUG - 2021-08-05 09:39:27 --> Total execution time: 0.0508
INFO - 2021-08-05 09:39:38 --> Config Class Initialized
INFO - 2021-08-05 09:39:38 --> Hooks Class Initialized
DEBUG - 2021-08-05 09:39:38 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:39:38 --> Utf8 Class Initialized
INFO - 2021-08-05 09:39:38 --> URI Class Initialized
INFO - 2021-08-05 09:39:38 --> Router Class Initialized
INFO - 2021-08-05 09:39:38 --> Output Class Initialized
INFO - 2021-08-05 09:39:38 --> Security Class Initialized
DEBUG - 2021-08-05 09:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:39:38 --> Input Class Initialized
INFO - 2021-08-05 09:39:38 --> Language Class Initialized
INFO - 2021-08-05 09:39:38 --> Loader Class Initialized
INFO - 2021-08-05 09:39:38 --> Helper loaded: url_helper
INFO - 2021-08-05 09:39:38 --> Helper loaded: file_helper
INFO - 2021-08-05 09:39:38 --> Database Driver Class Initialized
DEBUG - 2021-08-05 09:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 09:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 09:39:38 --> Controller Class Initialized
INFO - 2021-08-05 09:39:38 --> Helper loaded: cookie_helper
INFO - 2021-08-05 09:39:38 --> Model "CookieModel" initialized
INFO - 2021-08-05 09:39:38 --> Model "ContactModel" initialized
INFO - 2021-08-05 09:39:38 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 09:39:38 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/contact.php
INFO - 2021-08-05 09:39:38 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 09:39:38 --> Final output sent to browser
DEBUG - 2021-08-05 09:39:38 --> Total execution time: 0.0478
INFO - 2021-08-05 09:39:49 --> Config Class Initialized
INFO - 2021-08-05 09:39:49 --> Hooks Class Initialized
DEBUG - 2021-08-05 09:39:49 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:39:49 --> Utf8 Class Initialized
INFO - 2021-08-05 09:39:49 --> URI Class Initialized
INFO - 2021-08-05 09:39:49 --> Router Class Initialized
INFO - 2021-08-05 09:39:49 --> Output Class Initialized
INFO - 2021-08-05 09:39:49 --> Security Class Initialized
DEBUG - 2021-08-05 09:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:39:49 --> Input Class Initialized
INFO - 2021-08-05 09:39:49 --> Language Class Initialized
INFO - 2021-08-05 09:39:49 --> Loader Class Initialized
INFO - 2021-08-05 09:39:49 --> Helper loaded: url_helper
INFO - 2021-08-05 09:39:49 --> Helper loaded: file_helper
INFO - 2021-08-05 09:39:49 --> Database Driver Class Initialized
DEBUG - 2021-08-05 09:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 09:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 09:39:49 --> Controller Class Initialized
INFO - 2021-08-05 09:39:49 --> Helper loaded: cookie_helper
INFO - 2021-08-05 09:39:49 --> Model "CookieModel" initialized
INFO - 2021-08-05 09:39:49 --> Model "ContactModel" initialized
INFO - 2021-08-05 09:39:49 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 09:39:49 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/contact.php
INFO - 2021-08-05 09:39:49 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 09:39:49 --> Final output sent to browser
DEBUG - 2021-08-05 09:39:49 --> Total execution time: 0.0435
INFO - 2021-08-05 09:40:08 --> Config Class Initialized
INFO - 2021-08-05 09:40:08 --> Hooks Class Initialized
DEBUG - 2021-08-05 09:40:08 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:40:08 --> Utf8 Class Initialized
INFO - 2021-08-05 09:40:08 --> URI Class Initialized
INFO - 2021-08-05 09:40:08 --> Router Class Initialized
INFO - 2021-08-05 09:40:08 --> Output Class Initialized
INFO - 2021-08-05 09:40:08 --> Security Class Initialized
DEBUG - 2021-08-05 09:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:40:08 --> Input Class Initialized
INFO - 2021-08-05 09:40:08 --> Language Class Initialized
INFO - 2021-08-05 09:40:08 --> Loader Class Initialized
INFO - 2021-08-05 09:40:08 --> Helper loaded: url_helper
INFO - 2021-08-05 09:40:08 --> Helper loaded: file_helper
INFO - 2021-08-05 09:40:08 --> Database Driver Class Initialized
DEBUG - 2021-08-05 09:40:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 09:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 09:40:08 --> Controller Class Initialized
INFO - 2021-08-05 09:40:08 --> Helper loaded: cookie_helper
INFO - 2021-08-05 09:40:08 --> Model "CookieModel" initialized
INFO - 2021-08-05 09:40:08 --> Model "ContactModel" initialized
INFO - 2021-08-05 09:40:08 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 09:40:08 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/contact.php
INFO - 2021-08-05 09:40:08 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 09:40:08 --> Final output sent to browser
DEBUG - 2021-08-05 09:40:08 --> Total execution time: 0.0530
INFO - 2021-08-05 09:40:56 --> Config Class Initialized
INFO - 2021-08-05 09:40:56 --> Hooks Class Initialized
DEBUG - 2021-08-05 09:40:56 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:40:56 --> Utf8 Class Initialized
INFO - 2021-08-05 09:40:56 --> URI Class Initialized
INFO - 2021-08-05 09:40:56 --> Router Class Initialized
INFO - 2021-08-05 09:40:56 --> Output Class Initialized
INFO - 2021-08-05 09:40:56 --> Security Class Initialized
DEBUG - 2021-08-05 09:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:40:56 --> Input Class Initialized
INFO - 2021-08-05 09:40:56 --> Language Class Initialized
INFO - 2021-08-05 09:40:56 --> Loader Class Initialized
INFO - 2021-08-05 09:40:56 --> Helper loaded: url_helper
INFO - 2021-08-05 09:40:56 --> Helper loaded: file_helper
INFO - 2021-08-05 09:40:56 --> Database Driver Class Initialized
DEBUG - 2021-08-05 09:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 09:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 09:40:56 --> Controller Class Initialized
INFO - 2021-08-05 09:40:56 --> Helper loaded: cookie_helper
INFO - 2021-08-05 09:40:56 --> Model "CookieModel" initialized
INFO - 2021-08-05 09:40:56 --> Model "ContactModel" initialized
INFO - 2021-08-05 09:40:56 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 09:40:56 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/contact.php
INFO - 2021-08-05 09:40:56 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 09:40:56 --> Final output sent to browser
DEBUG - 2021-08-05 09:40:56 --> Total execution time: 0.0425
INFO - 2021-08-05 09:41:52 --> Config Class Initialized
INFO - 2021-08-05 09:41:52 --> Hooks Class Initialized
DEBUG - 2021-08-05 09:41:52 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:41:52 --> Utf8 Class Initialized
INFO - 2021-08-05 09:41:52 --> URI Class Initialized
INFO - 2021-08-05 09:41:52 --> Router Class Initialized
INFO - 2021-08-05 09:41:52 --> Output Class Initialized
INFO - 2021-08-05 09:41:52 --> Security Class Initialized
DEBUG - 2021-08-05 09:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:41:52 --> Input Class Initialized
INFO - 2021-08-05 09:41:52 --> Language Class Initialized
INFO - 2021-08-05 09:41:52 --> Loader Class Initialized
INFO - 2021-08-05 09:41:52 --> Helper loaded: url_helper
INFO - 2021-08-05 09:41:52 --> Helper loaded: file_helper
INFO - 2021-08-05 09:41:52 --> Database Driver Class Initialized
DEBUG - 2021-08-05 09:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 09:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 09:41:52 --> Controller Class Initialized
INFO - 2021-08-05 09:41:52 --> Helper loaded: cookie_helper
INFO - 2021-08-05 09:41:52 --> Model "CookieModel" initialized
INFO - 2021-08-05 09:41:52 --> Model "ContactModel" initialized
INFO - 2021-08-05 09:41:52 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 09:41:52 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/contact.php
INFO - 2021-08-05 09:41:52 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 09:41:52 --> Final output sent to browser
DEBUG - 2021-08-05 09:41:52 --> Total execution time: 0.0615
INFO - 2021-08-05 09:43:07 --> Config Class Initialized
INFO - 2021-08-05 09:43:07 --> Hooks Class Initialized
DEBUG - 2021-08-05 09:43:07 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:43:07 --> Utf8 Class Initialized
INFO - 2021-08-05 09:43:07 --> URI Class Initialized
INFO - 2021-08-05 09:43:07 --> Router Class Initialized
INFO - 2021-08-05 09:43:07 --> Output Class Initialized
INFO - 2021-08-05 09:43:07 --> Security Class Initialized
DEBUG - 2021-08-05 09:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:43:07 --> Input Class Initialized
INFO - 2021-08-05 09:43:07 --> Language Class Initialized
INFO - 2021-08-05 09:43:07 --> Loader Class Initialized
INFO - 2021-08-05 09:43:07 --> Helper loaded: url_helper
INFO - 2021-08-05 09:43:07 --> Helper loaded: file_helper
INFO - 2021-08-05 09:43:07 --> Database Driver Class Initialized
DEBUG - 2021-08-05 09:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 09:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 09:43:07 --> Controller Class Initialized
INFO - 2021-08-05 09:43:07 --> Helper loaded: cookie_helper
INFO - 2021-08-05 09:43:07 --> Model "CookieModel" initialized
INFO - 2021-08-05 09:43:07 --> Model "ContactModel" initialized
INFO - 2021-08-05 09:43:07 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 09:43:07 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/contact.php
INFO - 2021-08-05 09:43:07 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 09:43:07 --> Final output sent to browser
DEBUG - 2021-08-05 09:43:07 --> Total execution time: 0.0475
INFO - 2021-08-05 09:43:12 --> Config Class Initialized
INFO - 2021-08-05 09:43:12 --> Hooks Class Initialized
DEBUG - 2021-08-05 09:43:12 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:43:12 --> Utf8 Class Initialized
INFO - 2021-08-05 09:43:12 --> URI Class Initialized
DEBUG - 2021-08-05 09:43:12 --> No URI present. Default controller set.
INFO - 2021-08-05 09:43:12 --> Router Class Initialized
INFO - 2021-08-05 09:43:12 --> Output Class Initialized
INFO - 2021-08-05 09:43:12 --> Security Class Initialized
DEBUG - 2021-08-05 09:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:43:12 --> Input Class Initialized
INFO - 2021-08-05 09:43:12 --> Language Class Initialized
INFO - 2021-08-05 09:43:12 --> Loader Class Initialized
INFO - 2021-08-05 09:43:12 --> Helper loaded: url_helper
INFO - 2021-08-05 09:43:12 --> Helper loaded: file_helper
INFO - 2021-08-05 09:43:12 --> Database Driver Class Initialized
DEBUG - 2021-08-05 09:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 09:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 09:43:12 --> Controller Class Initialized
INFO - 2021-08-05 09:43:12 --> Helper loaded: cookie_helper
INFO - 2021-08-05 09:43:12 --> Model "CookieModel" initialized
INFO - 2021-08-05 09:43:12 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 09:43:12 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-05 09:43:12 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 09:43:12 --> Final output sent to browser
DEBUG - 2021-08-05 09:43:12 --> Total execution time: 0.0490
INFO - 2021-08-05 09:43:31 --> Config Class Initialized
INFO - 2021-08-05 09:43:31 --> Hooks Class Initialized
DEBUG - 2021-08-05 09:43:31 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:43:31 --> Utf8 Class Initialized
INFO - 2021-08-05 09:43:31 --> URI Class Initialized
DEBUG - 2021-08-05 09:43:31 --> No URI present. Default controller set.
INFO - 2021-08-05 09:43:31 --> Router Class Initialized
INFO - 2021-08-05 09:43:31 --> Output Class Initialized
INFO - 2021-08-05 09:43:31 --> Security Class Initialized
DEBUG - 2021-08-05 09:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:43:31 --> Input Class Initialized
INFO - 2021-08-05 09:43:31 --> Language Class Initialized
INFO - 2021-08-05 09:43:31 --> Loader Class Initialized
INFO - 2021-08-05 09:43:31 --> Helper loaded: url_helper
INFO - 2021-08-05 09:43:31 --> Helper loaded: file_helper
INFO - 2021-08-05 09:43:31 --> Database Driver Class Initialized
DEBUG - 2021-08-05 09:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 09:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 09:43:31 --> Controller Class Initialized
INFO - 2021-08-05 09:43:31 --> Helper loaded: cookie_helper
INFO - 2021-08-05 09:43:31 --> Model "CookieModel" initialized
INFO - 2021-08-05 09:43:31 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 09:43:31 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-05 09:43:31 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 09:43:31 --> Final output sent to browser
DEBUG - 2021-08-05 09:43:31 --> Total execution time: 0.0527
INFO - 2021-08-05 09:43:49 --> Config Class Initialized
INFO - 2021-08-05 09:43:49 --> Hooks Class Initialized
DEBUG - 2021-08-05 09:43:49 --> UTF-8 Support Enabled
INFO - 2021-08-05 09:43:49 --> Utf8 Class Initialized
INFO - 2021-08-05 09:43:49 --> URI Class Initialized
DEBUG - 2021-08-05 09:43:49 --> No URI present. Default controller set.
INFO - 2021-08-05 09:43:49 --> Router Class Initialized
INFO - 2021-08-05 09:43:49 --> Output Class Initialized
INFO - 2021-08-05 09:43:49 --> Security Class Initialized
DEBUG - 2021-08-05 09:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 09:43:49 --> Input Class Initialized
INFO - 2021-08-05 09:43:49 --> Language Class Initialized
INFO - 2021-08-05 09:43:49 --> Loader Class Initialized
INFO - 2021-08-05 09:43:49 --> Helper loaded: url_helper
INFO - 2021-08-05 09:43:49 --> Helper loaded: file_helper
INFO - 2021-08-05 09:43:49 --> Database Driver Class Initialized
DEBUG - 2021-08-05 09:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 09:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 09:43:49 --> Controller Class Initialized
INFO - 2021-08-05 09:43:49 --> Helper loaded: cookie_helper
INFO - 2021-08-05 09:43:49 --> Model "CookieModel" initialized
INFO - 2021-08-05 09:43:49 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 09:43:49 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-05 09:43:49 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 09:43:49 --> Final output sent to browser
DEBUG - 2021-08-05 09:43:49 --> Total execution time: 0.0401
INFO - 2021-08-05 14:37:16 --> Config Class Initialized
INFO - 2021-08-05 14:37:16 --> Hooks Class Initialized
DEBUG - 2021-08-05 14:37:16 --> UTF-8 Support Enabled
INFO - 2021-08-05 14:37:16 --> Utf8 Class Initialized
INFO - 2021-08-05 14:37:16 --> URI Class Initialized
DEBUG - 2021-08-05 14:37:16 --> No URI present. Default controller set.
INFO - 2021-08-05 14:37:16 --> Router Class Initialized
INFO - 2021-08-05 14:37:16 --> Output Class Initialized
INFO - 2021-08-05 14:37:16 --> Security Class Initialized
DEBUG - 2021-08-05 14:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 14:37:16 --> Input Class Initialized
INFO - 2021-08-05 14:37:16 --> Language Class Initialized
INFO - 2021-08-05 14:37:16 --> Loader Class Initialized
INFO - 2021-08-05 14:37:16 --> Helper loaded: url_helper
INFO - 2021-08-05 14:37:16 --> Helper loaded: file_helper
INFO - 2021-08-05 14:37:16 --> Database Driver Class Initialized
DEBUG - 2021-08-05 14:37:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 14:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 14:37:16 --> Controller Class Initialized
INFO - 2021-08-05 14:37:16 --> Helper loaded: cookie_helper
INFO - 2021-08-05 14:37:16 --> Model "CookieModel" initialized
INFO - 2021-08-05 14:37:16 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 14:37:16 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-05 14:37:16 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 14:37:16 --> Final output sent to browser
DEBUG - 2021-08-05 14:37:16 --> Total execution time: 0.2043
INFO - 2021-08-05 14:39:12 --> Config Class Initialized
INFO - 2021-08-05 14:39:12 --> Hooks Class Initialized
DEBUG - 2021-08-05 14:39:12 --> UTF-8 Support Enabled
INFO - 2021-08-05 14:39:12 --> Utf8 Class Initialized
INFO - 2021-08-05 14:39:12 --> URI Class Initialized
INFO - 2021-08-05 14:39:12 --> Router Class Initialized
INFO - 2021-08-05 14:39:12 --> Output Class Initialized
INFO - 2021-08-05 14:39:12 --> Security Class Initialized
DEBUG - 2021-08-05 14:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 14:39:12 --> Input Class Initialized
INFO - 2021-08-05 14:39:12 --> Language Class Initialized
INFO - 2021-08-05 14:39:12 --> Loader Class Initialized
INFO - 2021-08-05 14:39:12 --> Helper loaded: url_helper
INFO - 2021-08-05 14:39:12 --> Helper loaded: file_helper
INFO - 2021-08-05 14:39:12 --> Database Driver Class Initialized
DEBUG - 2021-08-05 14:39:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 14:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 14:39:12 --> Controller Class Initialized
INFO - 2021-08-05 14:39:12 --> Helper loaded: cookie_helper
INFO - 2021-08-05 14:39:12 --> Model "CookieModel" initialized
INFO - 2021-08-05 14:39:12 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 14:39:12 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-05 14:39:12 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 14:39:12 --> Final output sent to browser
DEBUG - 2021-08-05 14:39:12 --> Total execution time: 0.0939
INFO - 2021-08-05 14:39:20 --> Config Class Initialized
INFO - 2021-08-05 14:39:20 --> Hooks Class Initialized
DEBUG - 2021-08-05 14:39:20 --> UTF-8 Support Enabled
INFO - 2021-08-05 14:39:20 --> Utf8 Class Initialized
INFO - 2021-08-05 14:39:20 --> URI Class Initialized
DEBUG - 2021-08-05 14:39:20 --> No URI present. Default controller set.
INFO - 2021-08-05 14:39:20 --> Router Class Initialized
INFO - 2021-08-05 14:39:20 --> Output Class Initialized
INFO - 2021-08-05 14:39:20 --> Security Class Initialized
DEBUG - 2021-08-05 14:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 14:39:20 --> Input Class Initialized
INFO - 2021-08-05 14:39:20 --> Language Class Initialized
INFO - 2021-08-05 14:39:20 --> Loader Class Initialized
INFO - 2021-08-05 14:39:20 --> Helper loaded: url_helper
INFO - 2021-08-05 14:39:20 --> Helper loaded: file_helper
INFO - 2021-08-05 14:39:20 --> Database Driver Class Initialized
DEBUG - 2021-08-05 14:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 14:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 14:39:20 --> Controller Class Initialized
INFO - 2021-08-05 14:39:20 --> Helper loaded: cookie_helper
INFO - 2021-08-05 14:39:20 --> Model "CookieModel" initialized
INFO - 2021-08-05 14:39:20 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 14:39:20 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-05 14:39:20 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 14:39:20 --> Final output sent to browser
DEBUG - 2021-08-05 14:39:20 --> Total execution time: 0.0560
INFO - 2021-08-05 14:46:09 --> Config Class Initialized
INFO - 2021-08-05 14:46:09 --> Hooks Class Initialized
DEBUG - 2021-08-05 14:46:09 --> UTF-8 Support Enabled
INFO - 2021-08-05 14:46:09 --> Utf8 Class Initialized
INFO - 2021-08-05 14:46:09 --> URI Class Initialized
INFO - 2021-08-05 14:46:09 --> Router Class Initialized
INFO - 2021-08-05 14:46:09 --> Output Class Initialized
INFO - 2021-08-05 14:46:09 --> Security Class Initialized
DEBUG - 2021-08-05 14:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 14:46:09 --> Input Class Initialized
INFO - 2021-08-05 14:46:09 --> Language Class Initialized
INFO - 2021-08-05 14:46:09 --> Loader Class Initialized
INFO - 2021-08-05 14:46:09 --> Helper loaded: url_helper
INFO - 2021-08-05 14:46:09 --> Helper loaded: file_helper
INFO - 2021-08-05 14:46:09 --> Database Driver Class Initialized
DEBUG - 2021-08-05 14:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 14:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 14:46:09 --> Controller Class Initialized
INFO - 2021-08-05 14:46:09 --> Helper loaded: cookie_helper
INFO - 2021-08-05 14:46:09 --> Model "CookieModel" initialized
INFO - 2021-08-05 14:46:09 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 14:46:09 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/about.php
INFO - 2021-08-05 14:46:09 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 14:46:09 --> Final output sent to browser
DEBUG - 2021-08-05 14:46:09 --> Total execution time: 0.0919
INFO - 2021-08-05 14:46:25 --> Config Class Initialized
INFO - 2021-08-05 14:46:25 --> Hooks Class Initialized
DEBUG - 2021-08-05 14:46:25 --> UTF-8 Support Enabled
INFO - 2021-08-05 14:46:25 --> Utf8 Class Initialized
INFO - 2021-08-05 14:46:25 --> URI Class Initialized
INFO - 2021-08-05 14:46:25 --> Router Class Initialized
INFO - 2021-08-05 14:46:25 --> Output Class Initialized
INFO - 2021-08-05 14:46:25 --> Security Class Initialized
DEBUG - 2021-08-05 14:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 14:46:25 --> Input Class Initialized
INFO - 2021-08-05 14:46:25 --> Language Class Initialized
INFO - 2021-08-05 14:46:25 --> Loader Class Initialized
INFO - 2021-08-05 14:46:25 --> Helper loaded: url_helper
INFO - 2021-08-05 14:46:25 --> Helper loaded: file_helper
INFO - 2021-08-05 14:46:25 --> Database Driver Class Initialized
DEBUG - 2021-08-05 14:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 14:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 14:46:25 --> Controller Class Initialized
INFO - 2021-08-05 14:46:25 --> Helper loaded: cookie_helper
INFO - 2021-08-05 14:46:25 --> Model "CookieModel" initialized
INFO - 2021-08-05 14:46:25 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 14:46:25 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/team.php
INFO - 2021-08-05 14:46:25 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 14:46:25 --> Final output sent to browser
DEBUG - 2021-08-05 14:46:25 --> Total execution time: 0.0570
INFO - 2021-08-05 14:46:36 --> Config Class Initialized
INFO - 2021-08-05 14:46:36 --> Hooks Class Initialized
DEBUG - 2021-08-05 14:46:36 --> UTF-8 Support Enabled
INFO - 2021-08-05 14:46:36 --> Utf8 Class Initialized
INFO - 2021-08-05 14:46:36 --> URI Class Initialized
INFO - 2021-08-05 14:46:36 --> Router Class Initialized
INFO - 2021-08-05 14:46:36 --> Output Class Initialized
INFO - 2021-08-05 14:46:36 --> Security Class Initialized
DEBUG - 2021-08-05 14:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 14:46:36 --> Input Class Initialized
INFO - 2021-08-05 14:46:36 --> Language Class Initialized
INFO - 2021-08-05 14:46:36 --> Loader Class Initialized
INFO - 2021-08-05 14:46:36 --> Helper loaded: url_helper
INFO - 2021-08-05 14:46:36 --> Helper loaded: file_helper
INFO - 2021-08-05 14:46:36 --> Database Driver Class Initialized
DEBUG - 2021-08-05 14:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 14:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 14:46:36 --> Controller Class Initialized
INFO - 2021-08-05 14:46:36 --> Helper loaded: cookie_helper
INFO - 2021-08-05 14:46:36 --> Model "CookieModel" initialized
INFO - 2021-08-05 14:46:36 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 14:46:36 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/about.php
INFO - 2021-08-05 14:46:36 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 14:46:36 --> Final output sent to browser
DEBUG - 2021-08-05 14:46:36 --> Total execution time: 0.0419
INFO - 2021-08-05 14:46:47 --> Config Class Initialized
INFO - 2021-08-05 14:46:47 --> Hooks Class Initialized
DEBUG - 2021-08-05 14:46:47 --> UTF-8 Support Enabled
INFO - 2021-08-05 14:46:47 --> Utf8 Class Initialized
INFO - 2021-08-05 14:46:47 --> URI Class Initialized
INFO - 2021-08-05 14:46:47 --> Router Class Initialized
INFO - 2021-08-05 14:46:47 --> Output Class Initialized
INFO - 2021-08-05 14:46:47 --> Security Class Initialized
DEBUG - 2021-08-05 14:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 14:46:47 --> Input Class Initialized
INFO - 2021-08-05 14:46:47 --> Language Class Initialized
INFO - 2021-08-05 14:46:47 --> Loader Class Initialized
INFO - 2021-08-05 14:46:47 --> Helper loaded: url_helper
INFO - 2021-08-05 14:46:47 --> Helper loaded: file_helper
INFO - 2021-08-05 14:46:47 --> Database Driver Class Initialized
DEBUG - 2021-08-05 14:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 14:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 14:46:47 --> Controller Class Initialized
INFO - 2021-08-05 14:46:47 --> Helper loaded: cookie_helper
INFO - 2021-08-05 14:46:47 --> Model "CookieModel" initialized
INFO - 2021-08-05 14:46:47 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 14:46:47 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/team.php
INFO - 2021-08-05 14:46:47 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 14:46:47 --> Final output sent to browser
DEBUG - 2021-08-05 14:46:47 --> Total execution time: 0.0435
INFO - 2021-08-05 14:49:34 --> Config Class Initialized
INFO - 2021-08-05 14:49:34 --> Hooks Class Initialized
DEBUG - 2021-08-05 14:49:34 --> UTF-8 Support Enabled
INFO - 2021-08-05 14:49:34 --> Utf8 Class Initialized
INFO - 2021-08-05 14:49:34 --> URI Class Initialized
INFO - 2021-08-05 14:49:34 --> Router Class Initialized
INFO - 2021-08-05 14:49:34 --> Output Class Initialized
INFO - 2021-08-05 14:49:34 --> Security Class Initialized
DEBUG - 2021-08-05 14:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 14:49:34 --> Input Class Initialized
INFO - 2021-08-05 14:49:34 --> Language Class Initialized
INFO - 2021-08-05 14:49:34 --> Loader Class Initialized
INFO - 2021-08-05 14:49:34 --> Helper loaded: url_helper
INFO - 2021-08-05 14:49:34 --> Helper loaded: file_helper
INFO - 2021-08-05 14:49:34 --> Database Driver Class Initialized
DEBUG - 2021-08-05 14:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 14:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 14:49:34 --> Controller Class Initialized
INFO - 2021-08-05 14:49:34 --> Helper loaded: cookie_helper
INFO - 2021-08-05 14:49:34 --> Model "CookieModel" initialized
INFO - 2021-08-05 14:49:34 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 14:49:34 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/gallery.php
INFO - 2021-08-05 14:49:34 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 14:49:34 --> Final output sent to browser
DEBUG - 2021-08-05 14:49:34 --> Total execution time: 0.0778
INFO - 2021-08-05 14:49:55 --> Config Class Initialized
INFO - 2021-08-05 14:49:55 --> Hooks Class Initialized
DEBUG - 2021-08-05 14:49:55 --> UTF-8 Support Enabled
INFO - 2021-08-05 14:49:55 --> Utf8 Class Initialized
INFO - 2021-08-05 14:49:55 --> URI Class Initialized
INFO - 2021-08-05 14:49:55 --> Router Class Initialized
INFO - 2021-08-05 14:49:55 --> Output Class Initialized
INFO - 2021-08-05 14:49:55 --> Security Class Initialized
DEBUG - 2021-08-05 14:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 14:49:55 --> Input Class Initialized
INFO - 2021-08-05 14:49:55 --> Language Class Initialized
INFO - 2021-08-05 14:49:55 --> Loader Class Initialized
INFO - 2021-08-05 14:49:55 --> Helper loaded: url_helper
INFO - 2021-08-05 14:49:55 --> Helper loaded: file_helper
INFO - 2021-08-05 14:49:55 --> Database Driver Class Initialized
DEBUG - 2021-08-05 14:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 14:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 14:49:55 --> Controller Class Initialized
INFO - 2021-08-05 14:49:55 --> Helper loaded: cookie_helper
INFO - 2021-08-05 14:49:55 --> Model "CookieModel" initialized
INFO - 2021-08-05 14:49:55 --> Model "ContactModel" initialized
INFO - 2021-08-05 14:49:55 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 14:49:55 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/contact.php
INFO - 2021-08-05 14:49:55 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 14:49:55 --> Final output sent to browser
DEBUG - 2021-08-05 14:49:55 --> Total execution time: 0.0446
INFO - 2021-08-05 14:50:12 --> Config Class Initialized
INFO - 2021-08-05 14:50:12 --> Hooks Class Initialized
DEBUG - 2021-08-05 14:50:12 --> UTF-8 Support Enabled
INFO - 2021-08-05 14:50:12 --> Utf8 Class Initialized
INFO - 2021-08-05 14:50:12 --> URI Class Initialized
INFO - 2021-08-05 14:50:12 --> Router Class Initialized
INFO - 2021-08-05 14:50:12 --> Output Class Initialized
INFO - 2021-08-05 14:50:12 --> Security Class Initialized
DEBUG - 2021-08-05 14:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 14:50:12 --> Input Class Initialized
INFO - 2021-08-05 14:50:12 --> Language Class Initialized
INFO - 2021-08-05 14:50:12 --> Loader Class Initialized
INFO - 2021-08-05 14:50:12 --> Helper loaded: url_helper
INFO - 2021-08-05 14:50:12 --> Helper loaded: file_helper
INFO - 2021-08-05 14:50:12 --> Database Driver Class Initialized
DEBUG - 2021-08-05 14:50:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 14:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 14:50:12 --> Controller Class Initialized
INFO - 2021-08-05 14:50:12 --> Helper loaded: cookie_helper
INFO - 2021-08-05 14:50:12 --> Model "CookieModel" initialized
INFO - 2021-08-05 14:50:12 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 14:50:12 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-05 14:50:12 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 14:50:12 --> Final output sent to browser
DEBUG - 2021-08-05 14:50:12 --> Total execution time: 0.0447
INFO - 2021-08-05 14:51:39 --> Config Class Initialized
INFO - 2021-08-05 14:51:39 --> Hooks Class Initialized
DEBUG - 2021-08-05 14:51:39 --> UTF-8 Support Enabled
INFO - 2021-08-05 14:51:39 --> Utf8 Class Initialized
INFO - 2021-08-05 14:51:39 --> URI Class Initialized
DEBUG - 2021-08-05 14:51:39 --> No URI present. Default controller set.
INFO - 2021-08-05 14:51:39 --> Router Class Initialized
INFO - 2021-08-05 14:51:39 --> Output Class Initialized
INFO - 2021-08-05 14:51:39 --> Security Class Initialized
DEBUG - 2021-08-05 14:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 14:51:39 --> Input Class Initialized
INFO - 2021-08-05 14:51:39 --> Language Class Initialized
INFO - 2021-08-05 14:51:39 --> Loader Class Initialized
INFO - 2021-08-05 14:51:39 --> Helper loaded: url_helper
INFO - 2021-08-05 14:51:39 --> Helper loaded: file_helper
INFO - 2021-08-05 14:51:39 --> Database Driver Class Initialized
DEBUG - 2021-08-05 14:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 14:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 14:51:39 --> Controller Class Initialized
INFO - 2021-08-05 14:51:39 --> Helper loaded: cookie_helper
INFO - 2021-08-05 14:51:39 --> Model "CookieModel" initialized
INFO - 2021-08-05 14:51:39 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 14:51:39 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-05 14:51:39 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 14:51:39 --> Final output sent to browser
DEBUG - 2021-08-05 14:51:39 --> Total execution time: 0.0485
INFO - 2021-08-05 15:15:25 --> Config Class Initialized
INFO - 2021-08-05 15:15:25 --> Hooks Class Initialized
DEBUG - 2021-08-05 15:15:25 --> UTF-8 Support Enabled
INFO - 2021-08-05 15:15:25 --> Utf8 Class Initialized
INFO - 2021-08-05 15:15:25 --> URI Class Initialized
INFO - 2021-08-05 15:15:25 --> Router Class Initialized
INFO - 2021-08-05 15:15:25 --> Output Class Initialized
INFO - 2021-08-05 15:15:25 --> Security Class Initialized
DEBUG - 2021-08-05 15:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 15:15:25 --> Input Class Initialized
INFO - 2021-08-05 15:15:25 --> Language Class Initialized
INFO - 2021-08-05 15:15:25 --> Loader Class Initialized
INFO - 2021-08-05 15:15:25 --> Helper loaded: url_helper
INFO - 2021-08-05 15:15:25 --> Helper loaded: file_helper
INFO - 2021-08-05 15:15:25 --> Database Driver Class Initialized
DEBUG - 2021-08-05 15:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 15:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 15:15:25 --> Controller Class Initialized
INFO - 2021-08-05 15:15:25 --> Helper loaded: cookie_helper
INFO - 2021-08-05 15:15:25 --> Model "CookieModel" initialized
INFO - 2021-08-05 15:15:25 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 15:15:25 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/functional_training.php
INFO - 2021-08-05 15:15:25 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 15:15:25 --> Final output sent to browser
DEBUG - 2021-08-05 15:15:25 --> Total execution time: 0.1646
INFO - 2021-08-05 15:15:49 --> Config Class Initialized
INFO - 2021-08-05 15:15:49 --> Hooks Class Initialized
DEBUG - 2021-08-05 15:15:49 --> UTF-8 Support Enabled
INFO - 2021-08-05 15:15:49 --> Utf8 Class Initialized
INFO - 2021-08-05 15:15:49 --> URI Class Initialized
INFO - 2021-08-05 15:15:49 --> Router Class Initialized
INFO - 2021-08-05 15:15:49 --> Output Class Initialized
INFO - 2021-08-05 15:15:49 --> Security Class Initialized
DEBUG - 2021-08-05 15:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 15:15:49 --> Input Class Initialized
INFO - 2021-08-05 15:15:49 --> Language Class Initialized
INFO - 2021-08-05 15:15:49 --> Loader Class Initialized
INFO - 2021-08-05 15:15:49 --> Helper loaded: url_helper
INFO - 2021-08-05 15:15:49 --> Helper loaded: file_helper
INFO - 2021-08-05 15:15:49 --> Database Driver Class Initialized
DEBUG - 2021-08-05 15:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 15:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 15:15:49 --> Controller Class Initialized
INFO - 2021-08-05 15:15:49 --> Helper loaded: cookie_helper
INFO - 2021-08-05 15:15:49 --> Model "CookieModel" initialized
INFO - 2021-08-05 15:15:49 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 15:15:49 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/nutrition_coaching.php
INFO - 2021-08-05 15:15:49 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 15:15:49 --> Final output sent to browser
DEBUG - 2021-08-05 15:15:49 --> Total execution time: 0.0478
INFO - 2021-08-05 15:16:19 --> Config Class Initialized
INFO - 2021-08-05 15:16:19 --> Hooks Class Initialized
DEBUG - 2021-08-05 15:16:19 --> UTF-8 Support Enabled
INFO - 2021-08-05 15:16:19 --> Utf8 Class Initialized
INFO - 2021-08-05 15:16:19 --> URI Class Initialized
INFO - 2021-08-05 15:16:19 --> Router Class Initialized
INFO - 2021-08-05 15:16:19 --> Output Class Initialized
INFO - 2021-08-05 15:16:19 --> Security Class Initialized
DEBUG - 2021-08-05 15:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 15:16:19 --> Input Class Initialized
INFO - 2021-08-05 15:16:19 --> Language Class Initialized
INFO - 2021-08-05 15:16:19 --> Loader Class Initialized
INFO - 2021-08-05 15:16:19 --> Helper loaded: url_helper
INFO - 2021-08-05 15:16:19 --> Helper loaded: file_helper
INFO - 2021-08-05 15:16:19 --> Database Driver Class Initialized
DEBUG - 2021-08-05 15:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 15:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 15:16:19 --> Controller Class Initialized
INFO - 2021-08-05 15:16:19 --> Helper loaded: cookie_helper
INFO - 2021-08-05 15:16:19 --> Model "CookieModel" initialized
INFO - 2021-08-05 15:16:19 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 15:16:19 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/success_stories.php
INFO - 2021-08-05 15:16:19 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 15:16:19 --> Final output sent to browser
DEBUG - 2021-08-05 15:16:19 --> Total execution time: 0.1075
INFO - 2021-08-05 15:16:21 --> Config Class Initialized
INFO - 2021-08-05 15:16:21 --> Hooks Class Initialized
DEBUG - 2021-08-05 15:16:21 --> UTF-8 Support Enabled
INFO - 2021-08-05 15:16:21 --> Utf8 Class Initialized
INFO - 2021-08-05 15:16:21 --> URI Class Initialized
INFO - 2021-08-05 15:16:21 --> Router Class Initialized
INFO - 2021-08-05 15:16:21 --> Output Class Initialized
INFO - 2021-08-05 15:16:21 --> Security Class Initialized
DEBUG - 2021-08-05 15:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 15:16:21 --> Input Class Initialized
INFO - 2021-08-05 15:16:21 --> Language Class Initialized
INFO - 2021-08-05 15:16:21 --> Loader Class Initialized
INFO - 2021-08-05 15:16:21 --> Helper loaded: url_helper
INFO - 2021-08-05 15:16:21 --> Helper loaded: file_helper
INFO - 2021-08-05 15:16:21 --> Database Driver Class Initialized
DEBUG - 2021-08-05 15:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 15:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 15:16:21 --> Controller Class Initialized
INFO - 2021-08-05 15:16:21 --> Helper loaded: cookie_helper
INFO - 2021-08-05 15:16:21 --> Model "CookieModel" initialized
INFO - 2021-08-05 15:16:21 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 15:16:21 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/team.php
INFO - 2021-08-05 15:16:21 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 15:16:21 --> Final output sent to browser
DEBUG - 2021-08-05 15:16:21 --> Total execution time: 0.0388
INFO - 2021-08-05 15:24:06 --> Config Class Initialized
INFO - 2021-08-05 15:24:06 --> Hooks Class Initialized
DEBUG - 2021-08-05 15:24:06 --> UTF-8 Support Enabled
INFO - 2021-08-05 15:24:06 --> Utf8 Class Initialized
INFO - 2021-08-05 15:24:06 --> URI Class Initialized
INFO - 2021-08-05 15:24:06 --> Router Class Initialized
INFO - 2021-08-05 15:24:06 --> Output Class Initialized
INFO - 2021-08-05 15:24:06 --> Security Class Initialized
DEBUG - 2021-08-05 15:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 15:24:06 --> Input Class Initialized
INFO - 2021-08-05 15:24:06 --> Language Class Initialized
INFO - 2021-08-05 15:24:06 --> Loader Class Initialized
INFO - 2021-08-05 15:24:06 --> Helper loaded: url_helper
INFO - 2021-08-05 15:24:06 --> Helper loaded: file_helper
INFO - 2021-08-05 15:24:06 --> Database Driver Class Initialized
DEBUG - 2021-08-05 15:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 15:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 15:24:06 --> Controller Class Initialized
INFO - 2021-08-05 15:24:06 --> Helper loaded: cookie_helper
INFO - 2021-08-05 15:24:06 --> Model "CookieModel" initialized
INFO - 2021-08-05 15:24:06 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 15:24:06 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/team.php
INFO - 2021-08-05 15:24:06 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 15:24:06 --> Final output sent to browser
DEBUG - 2021-08-05 15:24:06 --> Total execution time: 0.1079
INFO - 2021-08-05 15:24:08 --> Config Class Initialized
INFO - 2021-08-05 15:24:08 --> Hooks Class Initialized
DEBUG - 2021-08-05 15:24:08 --> UTF-8 Support Enabled
INFO - 2021-08-05 15:24:08 --> Utf8 Class Initialized
INFO - 2021-08-05 15:24:08 --> URI Class Initialized
INFO - 2021-08-05 15:24:08 --> Router Class Initialized
INFO - 2021-08-05 15:24:08 --> Output Class Initialized
INFO - 2021-08-05 15:24:08 --> Security Class Initialized
DEBUG - 2021-08-05 15:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 15:24:08 --> Input Class Initialized
INFO - 2021-08-05 15:24:08 --> Language Class Initialized
INFO - 2021-08-05 15:24:08 --> Loader Class Initialized
INFO - 2021-08-05 15:24:08 --> Helper loaded: url_helper
INFO - 2021-08-05 15:24:08 --> Helper loaded: file_helper
INFO - 2021-08-05 15:24:08 --> Database Driver Class Initialized
DEBUG - 2021-08-05 15:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 15:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 15:24:08 --> Controller Class Initialized
INFO - 2021-08-05 15:24:08 --> Helper loaded: cookie_helper
INFO - 2021-08-05 15:24:08 --> Model "CookieModel" initialized
INFO - 2021-08-05 15:24:08 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 15:24:08 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/services.php
INFO - 2021-08-05 15:24:08 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 15:24:08 --> Final output sent to browser
DEBUG - 2021-08-05 15:24:08 --> Total execution time: 0.0422
INFO - 2021-08-05 15:24:44 --> Config Class Initialized
INFO - 2021-08-05 15:24:44 --> Hooks Class Initialized
DEBUG - 2021-08-05 15:24:44 --> UTF-8 Support Enabled
INFO - 2021-08-05 15:24:44 --> Utf8 Class Initialized
INFO - 2021-08-05 15:24:44 --> URI Class Initialized
INFO - 2021-08-05 15:24:44 --> Router Class Initialized
INFO - 2021-08-05 15:24:44 --> Output Class Initialized
INFO - 2021-08-05 15:24:44 --> Security Class Initialized
DEBUG - 2021-08-05 15:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 15:24:44 --> Input Class Initialized
INFO - 2021-08-05 15:24:44 --> Language Class Initialized
INFO - 2021-08-05 15:24:44 --> Loader Class Initialized
INFO - 2021-08-05 15:24:44 --> Helper loaded: url_helper
INFO - 2021-08-05 15:24:44 --> Helper loaded: file_helper
INFO - 2021-08-05 15:24:44 --> Database Driver Class Initialized
DEBUG - 2021-08-05 15:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 15:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 15:24:44 --> Controller Class Initialized
INFO - 2021-08-05 15:24:44 --> Helper loaded: cookie_helper
INFO - 2021-08-05 15:24:44 --> Model "CookieModel" initialized
INFO - 2021-08-05 15:24:44 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 15:24:44 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/services.php
INFO - 2021-08-05 15:24:44 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 15:24:44 --> Final output sent to browser
DEBUG - 2021-08-05 15:24:44 --> Total execution time: 0.0530
INFO - 2021-08-05 15:24:48 --> Config Class Initialized
INFO - 2021-08-05 15:24:48 --> Hooks Class Initialized
DEBUG - 2021-08-05 15:24:48 --> UTF-8 Support Enabled
INFO - 2021-08-05 15:24:48 --> Utf8 Class Initialized
INFO - 2021-08-05 15:24:48 --> URI Class Initialized
INFO - 2021-08-05 15:24:48 --> Router Class Initialized
INFO - 2021-08-05 15:24:48 --> Output Class Initialized
INFO - 2021-08-05 15:24:48 --> Security Class Initialized
DEBUG - 2021-08-05 15:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 15:24:48 --> Input Class Initialized
INFO - 2021-08-05 15:24:48 --> Language Class Initialized
INFO - 2021-08-05 15:24:48 --> Loader Class Initialized
INFO - 2021-08-05 15:24:48 --> Helper loaded: url_helper
INFO - 2021-08-05 15:24:48 --> Helper loaded: file_helper
INFO - 2021-08-05 15:24:48 --> Database Driver Class Initialized
DEBUG - 2021-08-05 15:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 15:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 15:24:48 --> Controller Class Initialized
INFO - 2021-08-05 15:24:48 --> Helper loaded: cookie_helper
INFO - 2021-08-05 15:24:48 --> Model "CookieModel" initialized
INFO - 2021-08-05 15:24:48 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 15:24:48 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/services.php
INFO - 2021-08-05 15:24:48 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 15:24:48 --> Final output sent to browser
DEBUG - 2021-08-05 15:24:48 --> Total execution time: 0.0402
INFO - 2021-08-05 15:26:31 --> Config Class Initialized
INFO - 2021-08-05 15:26:31 --> Hooks Class Initialized
DEBUG - 2021-08-05 15:26:31 --> UTF-8 Support Enabled
INFO - 2021-08-05 15:26:31 --> Utf8 Class Initialized
INFO - 2021-08-05 15:26:31 --> URI Class Initialized
INFO - 2021-08-05 15:26:31 --> Router Class Initialized
INFO - 2021-08-05 15:26:31 --> Output Class Initialized
INFO - 2021-08-05 15:26:31 --> Security Class Initialized
DEBUG - 2021-08-05 15:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 15:26:31 --> Input Class Initialized
INFO - 2021-08-05 15:26:31 --> Language Class Initialized
INFO - 2021-08-05 15:26:31 --> Loader Class Initialized
INFO - 2021-08-05 15:26:31 --> Helper loaded: url_helper
INFO - 2021-08-05 15:26:31 --> Helper loaded: file_helper
INFO - 2021-08-05 15:26:31 --> Database Driver Class Initialized
DEBUG - 2021-08-05 15:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 15:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 15:26:31 --> Controller Class Initialized
INFO - 2021-08-05 15:26:31 --> Helper loaded: cookie_helper
INFO - 2021-08-05 15:26:31 --> Model "CookieModel" initialized
INFO - 2021-08-05 15:26:31 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 15:26:31 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/services.php
INFO - 2021-08-05 15:26:31 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 15:26:31 --> Final output sent to browser
DEBUG - 2021-08-05 15:26:31 --> Total execution time: 0.0686
INFO - 2021-08-05 15:26:34 --> Config Class Initialized
INFO - 2021-08-05 15:26:34 --> Hooks Class Initialized
DEBUG - 2021-08-05 15:26:34 --> UTF-8 Support Enabled
INFO - 2021-08-05 15:26:34 --> Utf8 Class Initialized
INFO - 2021-08-05 15:26:34 --> URI Class Initialized
INFO - 2021-08-05 15:26:34 --> Router Class Initialized
INFO - 2021-08-05 15:26:34 --> Output Class Initialized
INFO - 2021-08-05 15:26:34 --> Security Class Initialized
DEBUG - 2021-08-05 15:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 15:26:34 --> Input Class Initialized
INFO - 2021-08-05 15:26:34 --> Language Class Initialized
INFO - 2021-08-05 15:26:34 --> Loader Class Initialized
INFO - 2021-08-05 15:26:34 --> Helper loaded: url_helper
INFO - 2021-08-05 15:26:34 --> Helper loaded: file_helper
INFO - 2021-08-05 15:26:34 --> Database Driver Class Initialized
DEBUG - 2021-08-05 15:26:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 15:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 15:26:34 --> Controller Class Initialized
INFO - 2021-08-05 15:26:34 --> Helper loaded: cookie_helper
INFO - 2021-08-05 15:26:34 --> Model "CookieModel" initialized
INFO - 2021-08-05 15:26:34 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 15:26:34 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/services.php
INFO - 2021-08-05 15:26:34 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 15:26:34 --> Final output sent to browser
DEBUG - 2021-08-05 15:26:34 --> Total execution time: 0.0398
INFO - 2021-08-05 15:26:42 --> Config Class Initialized
INFO - 2021-08-05 15:26:42 --> Hooks Class Initialized
DEBUG - 2021-08-05 15:26:42 --> UTF-8 Support Enabled
INFO - 2021-08-05 15:26:42 --> Utf8 Class Initialized
INFO - 2021-08-05 15:26:42 --> URI Class Initialized
INFO - 2021-08-05 15:26:42 --> Router Class Initialized
INFO - 2021-08-05 15:26:42 --> Output Class Initialized
INFO - 2021-08-05 15:26:42 --> Security Class Initialized
DEBUG - 2021-08-05 15:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 15:26:42 --> Input Class Initialized
INFO - 2021-08-05 15:26:42 --> Language Class Initialized
INFO - 2021-08-05 15:26:42 --> Loader Class Initialized
INFO - 2021-08-05 15:26:42 --> Helper loaded: url_helper
INFO - 2021-08-05 15:26:42 --> Helper loaded: file_helper
INFO - 2021-08-05 15:26:42 --> Database Driver Class Initialized
DEBUG - 2021-08-05 15:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 15:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 15:26:42 --> Controller Class Initialized
INFO - 2021-08-05 15:26:42 --> Helper loaded: cookie_helper
INFO - 2021-08-05 15:26:42 --> Model "CookieModel" initialized
INFO - 2021-08-05 15:26:42 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 15:26:42 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/services.php
INFO - 2021-08-05 15:26:42 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 15:26:42 --> Final output sent to browser
DEBUG - 2021-08-05 15:26:42 --> Total execution time: 0.0630
INFO - 2021-08-05 15:27:08 --> Config Class Initialized
INFO - 2021-08-05 15:27:08 --> Hooks Class Initialized
DEBUG - 2021-08-05 15:27:08 --> UTF-8 Support Enabled
INFO - 2021-08-05 15:27:08 --> Utf8 Class Initialized
INFO - 2021-08-05 15:27:08 --> URI Class Initialized
INFO - 2021-08-05 15:27:08 --> Router Class Initialized
INFO - 2021-08-05 15:27:08 --> Output Class Initialized
INFO - 2021-08-05 15:27:08 --> Security Class Initialized
DEBUG - 2021-08-05 15:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 15:27:08 --> Input Class Initialized
INFO - 2021-08-05 15:27:08 --> Language Class Initialized
INFO - 2021-08-05 15:27:08 --> Loader Class Initialized
INFO - 2021-08-05 15:27:08 --> Helper loaded: url_helper
INFO - 2021-08-05 15:27:08 --> Helper loaded: file_helper
INFO - 2021-08-05 15:27:08 --> Database Driver Class Initialized
DEBUG - 2021-08-05 15:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 15:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 15:27:08 --> Controller Class Initialized
INFO - 2021-08-05 15:27:08 --> Helper loaded: cookie_helper
INFO - 2021-08-05 15:27:08 --> Model "CookieModel" initialized
INFO - 2021-08-05 15:27:08 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 15:27:08 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/services.php
INFO - 2021-08-05 15:27:08 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 15:27:08 --> Final output sent to browser
DEBUG - 2021-08-05 15:27:08 --> Total execution time: 0.0401
INFO - 2021-08-05 15:27:10 --> Config Class Initialized
INFO - 2021-08-05 15:27:10 --> Hooks Class Initialized
DEBUG - 2021-08-05 15:27:10 --> UTF-8 Support Enabled
INFO - 2021-08-05 15:27:10 --> Utf8 Class Initialized
INFO - 2021-08-05 15:27:10 --> URI Class Initialized
INFO - 2021-08-05 15:27:10 --> Router Class Initialized
INFO - 2021-08-05 15:27:10 --> Output Class Initialized
INFO - 2021-08-05 15:27:10 --> Security Class Initialized
DEBUG - 2021-08-05 15:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 15:27:10 --> Input Class Initialized
INFO - 2021-08-05 15:27:10 --> Language Class Initialized
INFO - 2021-08-05 15:27:10 --> Loader Class Initialized
INFO - 2021-08-05 15:27:10 --> Helper loaded: url_helper
INFO - 2021-08-05 15:27:10 --> Helper loaded: file_helper
INFO - 2021-08-05 15:27:10 --> Database Driver Class Initialized
DEBUG - 2021-08-05 15:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 15:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 15:27:10 --> Controller Class Initialized
INFO - 2021-08-05 15:27:10 --> Helper loaded: cookie_helper
INFO - 2021-08-05 15:27:10 --> Model "CookieModel" initialized
INFO - 2021-08-05 15:27:10 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 15:27:10 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-05 15:27:10 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 15:27:10 --> Final output sent to browser
DEBUG - 2021-08-05 15:27:10 --> Total execution time: 0.0458
INFO - 2021-08-05 15:27:37 --> Config Class Initialized
INFO - 2021-08-05 15:27:37 --> Hooks Class Initialized
DEBUG - 2021-08-05 15:27:37 --> UTF-8 Support Enabled
INFO - 2021-08-05 15:27:37 --> Utf8 Class Initialized
INFO - 2021-08-05 15:27:37 --> URI Class Initialized
INFO - 2021-08-05 15:27:37 --> Router Class Initialized
INFO - 2021-08-05 15:27:37 --> Output Class Initialized
INFO - 2021-08-05 15:27:37 --> Security Class Initialized
DEBUG - 2021-08-05 15:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 15:27:37 --> Input Class Initialized
INFO - 2021-08-05 15:27:37 --> Language Class Initialized
INFO - 2021-08-05 15:27:37 --> Loader Class Initialized
INFO - 2021-08-05 15:27:37 --> Helper loaded: url_helper
INFO - 2021-08-05 15:27:37 --> Helper loaded: file_helper
INFO - 2021-08-05 15:27:37 --> Database Driver Class Initialized
DEBUG - 2021-08-05 15:27:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 15:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 15:27:37 --> Controller Class Initialized
INFO - 2021-08-05 15:27:37 --> Helper loaded: cookie_helper
INFO - 2021-08-05 15:27:37 --> Model "CookieModel" initialized
INFO - 2021-08-05 15:27:37 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 15:27:37 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-05 15:27:37 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 15:27:37 --> Final output sent to browser
DEBUG - 2021-08-05 15:27:37 --> Total execution time: 0.0427
INFO - 2021-08-05 15:29:15 --> Config Class Initialized
INFO - 2021-08-05 15:29:15 --> Hooks Class Initialized
DEBUG - 2021-08-05 15:29:15 --> UTF-8 Support Enabled
INFO - 2021-08-05 15:29:15 --> Utf8 Class Initialized
INFO - 2021-08-05 15:29:15 --> URI Class Initialized
INFO - 2021-08-05 15:29:15 --> Router Class Initialized
INFO - 2021-08-05 15:29:15 --> Output Class Initialized
INFO - 2021-08-05 15:29:15 --> Security Class Initialized
DEBUG - 2021-08-05 15:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 15:29:15 --> Input Class Initialized
INFO - 2021-08-05 15:29:15 --> Language Class Initialized
INFO - 2021-08-05 15:29:15 --> Loader Class Initialized
INFO - 2021-08-05 15:29:15 --> Helper loaded: url_helper
INFO - 2021-08-05 15:29:15 --> Helper loaded: file_helper
INFO - 2021-08-05 15:29:15 --> Database Driver Class Initialized
DEBUG - 2021-08-05 15:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 15:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 15:29:15 --> Controller Class Initialized
INFO - 2021-08-05 15:29:15 --> Helper loaded: cookie_helper
INFO - 2021-08-05 15:29:15 --> Model "CookieModel" initialized
INFO - 2021-08-05 15:29:15 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 15:29:15 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-05 15:29:15 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 15:29:15 --> Final output sent to browser
DEBUG - 2021-08-05 15:29:15 --> Total execution time: 0.0560
INFO - 2021-08-05 15:29:19 --> Config Class Initialized
INFO - 2021-08-05 15:29:19 --> Hooks Class Initialized
INFO - 2021-08-05 15:29:19 --> Config Class Initialized
INFO - 2021-08-05 15:29:19 --> Hooks Class Initialized
DEBUG - 2021-08-05 15:29:19 --> UTF-8 Support Enabled
INFO - 2021-08-05 15:29:19 --> Utf8 Class Initialized
INFO - 2021-08-05 15:29:19 --> URI Class Initialized
DEBUG - 2021-08-05 15:29:19 --> UTF-8 Support Enabled
INFO - 2021-08-05 15:29:19 --> Utf8 Class Initialized
INFO - 2021-08-05 15:29:19 --> Router Class Initialized
INFO - 2021-08-05 15:29:19 --> URI Class Initialized
INFO - 2021-08-05 15:29:19 --> Router Class Initialized
INFO - 2021-08-05 15:29:19 --> Output Class Initialized
INFO - 2021-08-05 15:29:19 --> Security Class Initialized
INFO - 2021-08-05 15:29:19 --> Output Class Initialized
DEBUG - 2021-08-05 15:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 15:29:19 --> Input Class Initialized
INFO - 2021-08-05 15:29:19 --> Config Class Initialized
INFO - 2021-08-05 15:29:19 --> Security Class Initialized
DEBUG - 2021-08-05 15:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 15:29:19 --> Hooks Class Initialized
INFO - 2021-08-05 15:29:19 --> Input Class Initialized
INFO - 2021-08-05 15:29:19 --> Language Class Initialized
INFO - 2021-08-05 15:29:19 --> Language Class Initialized
ERROR - 2021-08-05 15:29:19 --> 404 Page Not Found: Assets/js
DEBUG - 2021-08-05 15:29:19 --> UTF-8 Support Enabled
INFO - 2021-08-05 15:29:19 --> Utf8 Class Initialized
INFO - 2021-08-05 15:29:19 --> URI Class Initialized
INFO - 2021-08-05 15:29:19 --> Router Class Initialized
ERROR - 2021-08-05 15:29:19 --> 404 Page Not Found: Assets/js
INFO - 2021-08-05 15:29:19 --> Output Class Initialized
INFO - 2021-08-05 15:29:19 --> Security Class Initialized
DEBUG - 2021-08-05 15:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 15:29:19 --> Input Class Initialized
INFO - 2021-08-05 15:29:19 --> Language Class Initialized
ERROR - 2021-08-05 15:29:19 --> 404 Page Not Found: Assets/js
INFO - 2021-08-05 15:29:19 --> Config Class Initialized
INFO - 2021-08-05 15:29:19 --> Hooks Class Initialized
INFO - 2021-08-05 15:29:19 --> Config Class Initialized
INFO - 2021-08-05 15:29:19 --> Hooks Class Initialized
DEBUG - 2021-08-05 15:29:19 --> UTF-8 Support Enabled
DEBUG - 2021-08-05 15:29:19 --> UTF-8 Support Enabled
INFO - 2021-08-05 15:29:19 --> Utf8 Class Initialized
INFO - 2021-08-05 15:29:19 --> Utf8 Class Initialized
INFO - 2021-08-05 15:29:19 --> URI Class Initialized
INFO - 2021-08-05 15:29:19 --> URI Class Initialized
INFO - 2021-08-05 15:29:19 --> Router Class Initialized
INFO - 2021-08-05 15:29:19 --> Router Class Initialized
INFO - 2021-08-05 15:29:19 --> Output Class Initialized
INFO - 2021-08-05 15:29:19 --> Output Class Initialized
INFO - 2021-08-05 15:29:19 --> Security Class Initialized
INFO - 2021-08-05 15:29:19 --> Security Class Initialized
DEBUG - 2021-08-05 15:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-08-05 15:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 15:29:19 --> Input Class Initialized
INFO - 2021-08-05 15:29:19 --> Input Class Initialized
INFO - 2021-08-05 15:29:19 --> Language Class Initialized
INFO - 2021-08-05 15:29:19 --> Language Class Initialized
ERROR - 2021-08-05 15:29:19 --> 404 Page Not Found: Assets/css
ERROR - 2021-08-05 15:29:19 --> 404 Page Not Found: Assets/css
INFO - 2021-08-05 15:34:25 --> Config Class Initialized
INFO - 2021-08-05 15:34:25 --> Hooks Class Initialized
DEBUG - 2021-08-05 15:34:25 --> UTF-8 Support Enabled
INFO - 2021-08-05 15:34:25 --> Utf8 Class Initialized
INFO - 2021-08-05 15:34:25 --> URI Class Initialized
INFO - 2021-08-05 15:34:25 --> Router Class Initialized
INFO - 2021-08-05 15:34:25 --> Output Class Initialized
INFO - 2021-08-05 15:34:25 --> Security Class Initialized
DEBUG - 2021-08-05 15:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 15:34:25 --> Input Class Initialized
INFO - 2021-08-05 15:34:25 --> Language Class Initialized
INFO - 2021-08-05 15:34:25 --> Loader Class Initialized
INFO - 2021-08-05 15:34:25 --> Helper loaded: url_helper
INFO - 2021-08-05 15:34:25 --> Helper loaded: file_helper
INFO - 2021-08-05 15:34:25 --> Database Driver Class Initialized
DEBUG - 2021-08-05 15:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 15:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 15:34:25 --> Controller Class Initialized
INFO - 2021-08-05 15:34:25 --> Helper loaded: cookie_helper
INFO - 2021-08-05 15:34:25 --> Model "CookieModel" initialized
INFO - 2021-08-05 15:34:25 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 15:34:25 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-05 15:34:25 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 15:34:25 --> Final output sent to browser
DEBUG - 2021-08-05 15:34:25 --> Total execution time: 0.1440
INFO - 2021-08-05 15:34:28 --> Config Class Initialized
INFO - 2021-08-05 15:34:28 --> Hooks Class Initialized
DEBUG - 2021-08-05 15:34:28 --> UTF-8 Support Enabled
INFO - 2021-08-05 15:34:28 --> Utf8 Class Initialized
INFO - 2021-08-05 15:34:28 --> URI Class Initialized
INFO - 2021-08-05 15:34:28 --> Router Class Initialized
INFO - 2021-08-05 15:34:28 --> Output Class Initialized
INFO - 2021-08-05 15:34:28 --> Security Class Initialized
DEBUG - 2021-08-05 15:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 15:34:28 --> Input Class Initialized
INFO - 2021-08-05 15:34:28 --> Language Class Initialized
ERROR - 2021-08-05 15:34:28 --> 404 Page Not Found: Assets/js
INFO - 2021-08-05 15:34:28 --> Config Class Initialized
INFO - 2021-08-05 15:34:28 --> Hooks Class Initialized
INFO - 2021-08-05 15:34:28 --> Config Class Initialized
INFO - 2021-08-05 15:34:28 --> Hooks Class Initialized
DEBUG - 2021-08-05 15:34:28 --> UTF-8 Support Enabled
INFO - 2021-08-05 15:34:28 --> Utf8 Class Initialized
INFO - 2021-08-05 15:34:28 --> URI Class Initialized
DEBUG - 2021-08-05 15:34:28 --> UTF-8 Support Enabled
INFO - 2021-08-05 15:34:28 --> Utf8 Class Initialized
INFO - 2021-08-05 15:34:28 --> Router Class Initialized
INFO - 2021-08-05 15:34:28 --> URI Class Initialized
INFO - 2021-08-05 15:34:28 --> Output Class Initialized
INFO - 2021-08-05 15:34:28 --> Router Class Initialized
INFO - 2021-08-05 15:34:28 --> Security Class Initialized
INFO - 2021-08-05 15:34:28 --> Output Class Initialized
DEBUG - 2021-08-05 15:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 15:34:28 --> Input Class Initialized
INFO - 2021-08-05 15:34:28 --> Language Class Initialized
ERROR - 2021-08-05 15:34:28 --> 404 Page Not Found: Assets/js
INFO - 2021-08-05 15:34:28 --> Security Class Initialized
DEBUG - 2021-08-05 15:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 15:34:28 --> Input Class Initialized
INFO - 2021-08-05 15:34:28 --> Language Class Initialized
ERROR - 2021-08-05 15:34:28 --> 404 Page Not Found: Assets/js
INFO - 2021-08-05 15:34:28 --> Config Class Initialized
INFO - 2021-08-05 15:34:28 --> Hooks Class Initialized
DEBUG - 2021-08-05 15:34:28 --> UTF-8 Support Enabled
INFO - 2021-08-05 15:34:28 --> Utf8 Class Initialized
INFO - 2021-08-05 15:34:28 --> Config Class Initialized
INFO - 2021-08-05 15:34:28 --> Hooks Class Initialized
INFO - 2021-08-05 15:34:28 --> URI Class Initialized
INFO - 2021-08-05 15:34:28 --> Router Class Initialized
DEBUG - 2021-08-05 15:34:28 --> UTF-8 Support Enabled
INFO - 2021-08-05 15:34:28 --> Utf8 Class Initialized
INFO - 2021-08-05 15:34:28 --> Output Class Initialized
INFO - 2021-08-05 15:34:28 --> URI Class Initialized
INFO - 2021-08-05 15:34:28 --> Security Class Initialized
INFO - 2021-08-05 15:34:28 --> Router Class Initialized
DEBUG - 2021-08-05 15:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 15:34:28 --> Input Class Initialized
INFO - 2021-08-05 15:34:28 --> Output Class Initialized
INFO - 2021-08-05 15:34:28 --> Language Class Initialized
ERROR - 2021-08-05 15:34:28 --> 404 Page Not Found: Assets/css
INFO - 2021-08-05 15:34:28 --> Security Class Initialized
DEBUG - 2021-08-05 15:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 15:34:28 --> Input Class Initialized
INFO - 2021-08-05 15:34:28 --> Language Class Initialized
ERROR - 2021-08-05 15:34:28 --> 404 Page Not Found: Assets/css
INFO - 2021-08-05 15:34:49 --> Config Class Initialized
INFO - 2021-08-05 15:34:49 --> Hooks Class Initialized
DEBUG - 2021-08-05 15:34:49 --> UTF-8 Support Enabled
INFO - 2021-08-05 15:34:49 --> Utf8 Class Initialized
INFO - 2021-08-05 15:34:49 --> URI Class Initialized
INFO - 2021-08-05 15:34:49 --> Router Class Initialized
INFO - 2021-08-05 15:34:49 --> Output Class Initialized
INFO - 2021-08-05 15:34:49 --> Security Class Initialized
DEBUG - 2021-08-05 15:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 15:34:49 --> Input Class Initialized
INFO - 2021-08-05 15:34:49 --> Language Class Initialized
INFO - 2021-08-05 15:34:49 --> Loader Class Initialized
INFO - 2021-08-05 15:34:49 --> Helper loaded: url_helper
INFO - 2021-08-05 15:34:49 --> Helper loaded: file_helper
INFO - 2021-08-05 15:34:49 --> Database Driver Class Initialized
DEBUG - 2021-08-05 15:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 15:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 15:34:49 --> Controller Class Initialized
INFO - 2021-08-05 15:34:49 --> Helper loaded: cookie_helper
INFO - 2021-08-05 15:34:49 --> Model "CookieModel" initialized
INFO - 2021-08-05 15:34:49 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 15:34:49 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-05 15:34:49 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 15:34:49 --> Final output sent to browser
DEBUG - 2021-08-05 15:34:49 --> Total execution time: 0.1063
INFO - 2021-08-05 15:34:50 --> Config Class Initialized
INFO - 2021-08-05 15:34:50 --> Hooks Class Initialized
DEBUG - 2021-08-05 15:34:50 --> UTF-8 Support Enabled
INFO - 2021-08-05 15:34:50 --> Utf8 Class Initialized
INFO - 2021-08-05 15:34:50 --> URI Class Initialized
INFO - 2021-08-05 15:34:50 --> Config Class Initialized
INFO - 2021-08-05 15:34:50 --> Hooks Class Initialized
INFO - 2021-08-05 15:34:50 --> Router Class Initialized
INFO - 2021-08-05 15:34:50 --> Output Class Initialized
DEBUG - 2021-08-05 15:34:50 --> UTF-8 Support Enabled
INFO - 2021-08-05 15:34:50 --> Utf8 Class Initialized
INFO - 2021-08-05 15:34:50 --> Security Class Initialized
INFO - 2021-08-05 15:34:50 --> URI Class Initialized
DEBUG - 2021-08-05 15:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 15:34:50 --> Router Class Initialized
INFO - 2021-08-05 15:34:50 --> Input Class Initialized
INFO - 2021-08-05 15:34:50 --> Output Class Initialized
INFO - 2021-08-05 15:34:50 --> Security Class Initialized
DEBUG - 2021-08-05 15:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 15:34:50 --> Input Class Initialized
INFO - 2021-08-05 15:34:50 --> Language Class Initialized
INFO - 2021-08-05 15:34:50 --> Language Class Initialized
ERROR - 2021-08-05 15:34:50 --> 404 Page Not Found: Assets/css
ERROR - 2021-08-05 15:34:50 --> 404 Page Not Found: Assets/css
INFO - 2021-08-05 15:34:50 --> Config Class Initialized
INFO - 2021-08-05 15:34:50 --> Hooks Class Initialized
DEBUG - 2021-08-05 15:34:50 --> UTF-8 Support Enabled
INFO - 2021-08-05 15:34:50 --> Utf8 Class Initialized
INFO - 2021-08-05 15:34:50 --> URI Class Initialized
INFO - 2021-08-05 15:34:50 --> Router Class Initialized
INFO - 2021-08-05 15:34:50 --> Output Class Initialized
INFO - 2021-08-05 15:34:50 --> Security Class Initialized
DEBUG - 2021-08-05 15:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 15:34:50 --> Input Class Initialized
INFO - 2021-08-05 15:34:50 --> Language Class Initialized
ERROR - 2021-08-05 15:34:50 --> 404 Page Not Found: Assets/js
INFO - 2021-08-05 15:34:50 --> Config Class Initialized
INFO - 2021-08-05 15:34:50 --> Hooks Class Initialized
DEBUG - 2021-08-05 15:34:50 --> UTF-8 Support Enabled
INFO - 2021-08-05 15:34:50 --> Utf8 Class Initialized
INFO - 2021-08-05 15:34:50 --> URI Class Initialized
INFO - 2021-08-05 15:34:50 --> Router Class Initialized
INFO - 2021-08-05 15:34:50 --> Output Class Initialized
INFO - 2021-08-05 15:34:50 --> Security Class Initialized
DEBUG - 2021-08-05 15:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 15:34:50 --> Input Class Initialized
INFO - 2021-08-05 15:34:50 --> Language Class Initialized
ERROR - 2021-08-05 15:34:50 --> 404 Page Not Found: Assets/js
INFO - 2021-08-05 15:34:50 --> Config Class Initialized
INFO - 2021-08-05 15:34:50 --> Hooks Class Initialized
DEBUG - 2021-08-05 15:34:50 --> UTF-8 Support Enabled
INFO - 2021-08-05 15:34:50 --> Utf8 Class Initialized
INFO - 2021-08-05 15:34:50 --> URI Class Initialized
INFO - 2021-08-05 15:34:50 --> Router Class Initialized
INFO - 2021-08-05 15:34:50 --> Output Class Initialized
INFO - 2021-08-05 15:34:50 --> Security Class Initialized
DEBUG - 2021-08-05 15:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 15:34:50 --> Input Class Initialized
INFO - 2021-08-05 15:34:50 --> Language Class Initialized
ERROR - 2021-08-05 15:34:50 --> 404 Page Not Found: Assets/js
INFO - 2021-08-05 15:35:27 --> Config Class Initialized
INFO - 2021-08-05 15:35:27 --> Hooks Class Initialized
DEBUG - 2021-08-05 15:35:27 --> UTF-8 Support Enabled
INFO - 2021-08-05 15:35:27 --> Utf8 Class Initialized
INFO - 2021-08-05 15:35:27 --> URI Class Initialized
INFO - 2021-08-05 15:35:27 --> Router Class Initialized
INFO - 2021-08-05 15:35:27 --> Output Class Initialized
INFO - 2021-08-05 15:35:27 --> Security Class Initialized
DEBUG - 2021-08-05 15:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 15:35:27 --> Input Class Initialized
INFO - 2021-08-05 15:35:27 --> Language Class Initialized
INFO - 2021-08-05 15:35:27 --> Loader Class Initialized
INFO - 2021-08-05 15:35:27 --> Helper loaded: url_helper
INFO - 2021-08-05 15:35:27 --> Helper loaded: file_helper
INFO - 2021-08-05 15:35:27 --> Database Driver Class Initialized
DEBUG - 2021-08-05 15:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 15:35:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 15:35:27 --> Controller Class Initialized
INFO - 2021-08-05 15:35:27 --> Helper loaded: cookie_helper
INFO - 2021-08-05 15:35:27 --> Model "CookieModel" initialized
INFO - 2021-08-05 15:35:27 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 15:35:27 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-05 15:35:27 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 15:35:27 --> Final output sent to browser
DEBUG - 2021-08-05 15:35:27 --> Total execution time: 0.0634
INFO - 2021-08-05 15:35:28 --> Config Class Initialized
INFO - 2021-08-05 15:35:28 --> Hooks Class Initialized
INFO - 2021-08-05 15:35:28 --> Config Class Initialized
INFO - 2021-08-05 15:35:28 --> Hooks Class Initialized
DEBUG - 2021-08-05 15:35:28 --> UTF-8 Support Enabled
INFO - 2021-08-05 15:35:28 --> Utf8 Class Initialized
DEBUG - 2021-08-05 15:35:28 --> UTF-8 Support Enabled
INFO - 2021-08-05 15:35:28 --> Utf8 Class Initialized
INFO - 2021-08-05 15:35:28 --> URI Class Initialized
INFO - 2021-08-05 15:35:28 --> URI Class Initialized
INFO - 2021-08-05 15:35:28 --> Router Class Initialized
INFO - 2021-08-05 15:35:28 --> Router Class Initialized
INFO - 2021-08-05 15:35:28 --> Output Class Initialized
INFO - 2021-08-05 15:35:28 --> Output Class Initialized
INFO - 2021-08-05 15:35:28 --> Security Class Initialized
INFO - 2021-08-05 15:35:28 --> Security Class Initialized
DEBUG - 2021-08-05 15:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 15:35:28 --> Input Class Initialized
INFO - 2021-08-05 15:35:28 --> Language Class Initialized
DEBUG - 2021-08-05 15:35:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-08-05 15:35:28 --> 404 Page Not Found: Assets/css
INFO - 2021-08-05 15:35:28 --> Input Class Initialized
INFO - 2021-08-05 15:35:28 --> Language Class Initialized
ERROR - 2021-08-05 15:35:28 --> 404 Page Not Found: Assets/css
INFO - 2021-08-05 15:35:28 --> Config Class Initialized
INFO - 2021-08-05 15:35:28 --> Hooks Class Initialized
DEBUG - 2021-08-05 15:35:28 --> UTF-8 Support Enabled
INFO - 2021-08-05 15:35:28 --> Utf8 Class Initialized
INFO - 2021-08-05 15:35:28 --> URI Class Initialized
INFO - 2021-08-05 15:35:28 --> Router Class Initialized
INFO - 2021-08-05 15:35:28 --> Config Class Initialized
INFO - 2021-08-05 15:35:28 --> Hooks Class Initialized
INFO - 2021-08-05 15:35:28 --> Output Class Initialized
INFO - 2021-08-05 15:35:28 --> Security Class Initialized
DEBUG - 2021-08-05 15:35:28 --> UTF-8 Support Enabled
INFO - 2021-08-05 15:35:28 --> Utf8 Class Initialized
INFO - 2021-08-05 15:35:28 --> URI Class Initialized
DEBUG - 2021-08-05 15:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 15:35:28 --> Input Class Initialized
INFO - 2021-08-05 15:35:28 --> Language Class Initialized
INFO - 2021-08-05 15:35:28 --> Router Class Initialized
ERROR - 2021-08-05 15:35:28 --> 404 Page Not Found: Assets/js
INFO - 2021-08-05 15:35:28 --> Output Class Initialized
INFO - 2021-08-05 15:35:28 --> Security Class Initialized
DEBUG - 2021-08-05 15:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 15:35:28 --> Input Class Initialized
INFO - 2021-08-05 15:35:28 --> Language Class Initialized
ERROR - 2021-08-05 15:35:28 --> 404 Page Not Found: Assets/js
INFO - 2021-08-05 15:35:28 --> Config Class Initialized
INFO - 2021-08-05 15:35:28 --> Hooks Class Initialized
DEBUG - 2021-08-05 15:35:28 --> UTF-8 Support Enabled
INFO - 2021-08-05 15:35:28 --> Utf8 Class Initialized
INFO - 2021-08-05 15:35:28 --> URI Class Initialized
INFO - 2021-08-05 15:35:28 --> Router Class Initialized
INFO - 2021-08-05 15:35:28 --> Output Class Initialized
INFO - 2021-08-05 15:35:28 --> Security Class Initialized
DEBUG - 2021-08-05 15:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 15:35:28 --> Input Class Initialized
INFO - 2021-08-05 15:35:28 --> Language Class Initialized
ERROR - 2021-08-05 15:35:28 --> 404 Page Not Found: Assets/js
INFO - 2021-08-05 19:56:17 --> Config Class Initialized
INFO - 2021-08-05 19:56:17 --> Hooks Class Initialized
DEBUG - 2021-08-05 19:56:17 --> UTF-8 Support Enabled
INFO - 2021-08-05 19:56:17 --> Utf8 Class Initialized
INFO - 2021-08-05 19:56:17 --> URI Class Initialized
DEBUG - 2021-08-05 19:56:17 --> No URI present. Default controller set.
INFO - 2021-08-05 19:56:17 --> Router Class Initialized
INFO - 2021-08-05 19:56:17 --> Output Class Initialized
INFO - 2021-08-05 19:56:17 --> Security Class Initialized
DEBUG - 2021-08-05 19:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 19:56:17 --> Input Class Initialized
INFO - 2021-08-05 19:56:17 --> Language Class Initialized
INFO - 2021-08-05 19:56:17 --> Loader Class Initialized
INFO - 2021-08-05 19:56:17 --> Helper loaded: url_helper
INFO - 2021-08-05 19:56:17 --> Helper loaded: file_helper
INFO - 2021-08-05 19:56:17 --> Database Driver Class Initialized
DEBUG - 2021-08-05 19:56:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 19:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 19:56:17 --> Controller Class Initialized
INFO - 2021-08-05 19:56:17 --> Helper loaded: cookie_helper
INFO - 2021-08-05 19:56:17 --> Model "CookieModel" initialized
INFO - 2021-08-05 19:56:17 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 19:56:17 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-05 19:56:17 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 19:56:17 --> Final output sent to browser
DEBUG - 2021-08-05 19:56:17 --> Total execution time: 0.1765
INFO - 2021-08-05 20:04:53 --> Config Class Initialized
INFO - 2021-08-05 20:04:53 --> Hooks Class Initialized
DEBUG - 2021-08-05 20:04:53 --> UTF-8 Support Enabled
INFO - 2021-08-05 20:04:53 --> Utf8 Class Initialized
INFO - 2021-08-05 20:04:53 --> URI Class Initialized
INFO - 2021-08-05 20:04:53 --> Router Class Initialized
INFO - 2021-08-05 20:04:53 --> Output Class Initialized
INFO - 2021-08-05 20:04:53 --> Security Class Initialized
DEBUG - 2021-08-05 20:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 20:04:53 --> Input Class Initialized
INFO - 2021-08-05 20:04:53 --> Language Class Initialized
INFO - 2021-08-05 20:04:53 --> Loader Class Initialized
INFO - 2021-08-05 20:04:53 --> Helper loaded: url_helper
INFO - 2021-08-05 20:04:53 --> Helper loaded: file_helper
INFO - 2021-08-05 20:04:53 --> Database Driver Class Initialized
DEBUG - 2021-08-05 20:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 20:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 20:04:53 --> Controller Class Initialized
INFO - 2021-08-05 20:04:53 --> Helper loaded: cookie_helper
INFO - 2021-08-05 20:04:53 --> Model "CookieModel" initialized
INFO - 2021-08-05 20:04:53 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 20:04:53 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-05 20:04:53 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 20:04:53 --> Final output sent to browser
DEBUG - 2021-08-05 20:04:53 --> Total execution time: 0.1190
INFO - 2021-08-05 20:08:04 --> Config Class Initialized
INFO - 2021-08-05 20:08:04 --> Hooks Class Initialized
DEBUG - 2021-08-05 20:08:04 --> UTF-8 Support Enabled
INFO - 2021-08-05 20:08:04 --> Utf8 Class Initialized
INFO - 2021-08-05 20:08:04 --> URI Class Initialized
DEBUG - 2021-08-05 20:08:04 --> No URI present. Default controller set.
INFO - 2021-08-05 20:08:04 --> Router Class Initialized
INFO - 2021-08-05 20:08:04 --> Output Class Initialized
INFO - 2021-08-05 20:08:04 --> Security Class Initialized
DEBUG - 2021-08-05 20:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-05 20:08:04 --> Input Class Initialized
INFO - 2021-08-05 20:08:04 --> Language Class Initialized
INFO - 2021-08-05 20:08:04 --> Loader Class Initialized
INFO - 2021-08-05 20:08:04 --> Helper loaded: url_helper
INFO - 2021-08-05 20:08:04 --> Helper loaded: file_helper
INFO - 2021-08-05 20:08:04 --> Database Driver Class Initialized
DEBUG - 2021-08-05 20:08:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-05 20:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-05 20:08:04 --> Controller Class Initialized
INFO - 2021-08-05 20:08:04 --> Helper loaded: cookie_helper
INFO - 2021-08-05 20:08:04 --> Model "CookieModel" initialized
INFO - 2021-08-05 20:08:04 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-05 20:08:04 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-05 20:08:04 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-05 20:08:04 --> Final output sent to browser
DEBUG - 2021-08-05 20:08:04 --> Total execution time: 0.0779
