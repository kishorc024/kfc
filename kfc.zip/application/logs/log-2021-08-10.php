<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-08-10 20:20:44 --> Config Class Initialized
INFO - 2021-08-10 20:20:44 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:20:44 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:20:44 --> Utf8 Class Initialized
INFO - 2021-08-10 20:20:44 --> URI Class Initialized
DEBUG - 2021-08-10 20:20:44 --> No URI present. Default controller set.
INFO - 2021-08-10 20:20:44 --> Router Class Initialized
INFO - 2021-08-10 20:20:44 --> Output Class Initialized
INFO - 2021-08-10 20:20:44 --> Security Class Initialized
DEBUG - 2021-08-10 20:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:20:44 --> Input Class Initialized
INFO - 2021-08-10 20:20:44 --> Language Class Initialized
INFO - 2021-08-10 20:20:44 --> Loader Class Initialized
INFO - 2021-08-10 20:20:44 --> Helper loaded: url_helper
INFO - 2021-08-10 20:20:44 --> Helper loaded: file_helper
DEBUG - 2021-08-10 20:20:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-10 20:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-10 20:20:44 --> Controller Class Initialized
INFO - 2021-08-10 20:20:44 --> Helper loaded: cookie_helper
INFO - 2021-08-10 20:20:44 --> Model "CookieModel" initialized
INFO - 2021-08-10 20:20:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-10 20:20:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-10 20:20:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-10 20:20:44 --> Final output sent to browser
DEBUG - 2021-08-10 20:20:44 --> Total execution time: 0.0537
INFO - 2021-08-10 20:20:47 --> Config Class Initialized
INFO - 2021-08-10 20:20:47 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:20:47 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:20:47 --> Utf8 Class Initialized
INFO - 2021-08-10 20:20:47 --> URI Class Initialized
INFO - 2021-08-10 20:20:47 --> Router Class Initialized
INFO - 2021-08-10 20:20:47 --> Output Class Initialized
INFO - 2021-08-10 20:20:47 --> Security Class Initialized
DEBUG - 2021-08-10 20:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:20:47 --> Input Class Initialized
INFO - 2021-08-10 20:20:47 --> Language Class Initialized
INFO - 2021-08-10 20:20:47 --> Loader Class Initialized
INFO - 2021-08-10 20:20:47 --> Helper loaded: url_helper
INFO - 2021-08-10 20:20:47 --> Helper loaded: file_helper
DEBUG - 2021-08-10 20:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-10 20:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-10 20:20:47 --> Controller Class Initialized
INFO - 2021-08-10 20:20:47 --> Helper loaded: cookie_helper
INFO - 2021-08-10 20:20:47 --> Model "CookieModel" initialized
INFO - 2021-08-10 20:20:47 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-10 20:20:47 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-10 20:20:47 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-10 20:20:47 --> Final output sent to browser
DEBUG - 2021-08-10 20:20:47 --> Total execution time: 0.0371
INFO - 2021-08-10 20:21:25 --> Config Class Initialized
INFO - 2021-08-10 20:21:25 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:21:25 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:21:25 --> Utf8 Class Initialized
INFO - 2021-08-10 20:21:25 --> URI Class Initialized
INFO - 2021-08-10 20:21:25 --> Router Class Initialized
INFO - 2021-08-10 20:21:25 --> Output Class Initialized
INFO - 2021-08-10 20:21:25 --> Security Class Initialized
DEBUG - 2021-08-10 20:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:21:25 --> Input Class Initialized
INFO - 2021-08-10 20:21:25 --> Language Class Initialized
INFO - 2021-08-10 20:21:25 --> Loader Class Initialized
INFO - 2021-08-10 20:21:25 --> Helper loaded: url_helper
INFO - 2021-08-10 20:21:25 --> Helper loaded: file_helper
DEBUG - 2021-08-10 20:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-10 20:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-10 20:21:25 --> Controller Class Initialized
INFO - 2021-08-10 20:21:25 --> Helper loaded: cookie_helper
INFO - 2021-08-10 20:21:25 --> Model "CookieModel" initialized
INFO - 2021-08-10 20:21:25 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-10 20:21:25 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-10 20:21:25 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-10 20:21:25 --> Final output sent to browser
DEBUG - 2021-08-10 20:21:25 --> Total execution time: 0.0521
INFO - 2021-08-10 20:21:34 --> Config Class Initialized
INFO - 2021-08-10 20:21:34 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:21:34 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:21:34 --> Utf8 Class Initialized
INFO - 2021-08-10 20:21:34 --> URI Class Initialized
INFO - 2021-08-10 20:21:34 --> Router Class Initialized
INFO - 2021-08-10 20:21:34 --> Output Class Initialized
INFO - 2021-08-10 20:21:34 --> Security Class Initialized
DEBUG - 2021-08-10 20:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:21:34 --> Input Class Initialized
INFO - 2021-08-10 20:21:34 --> Language Class Initialized
INFO - 2021-08-10 20:21:34 --> Loader Class Initialized
INFO - 2021-08-10 20:21:34 --> Helper loaded: url_helper
INFO - 2021-08-10 20:21:34 --> Helper loaded: file_helper
DEBUG - 2021-08-10 20:21:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-10 20:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-10 20:21:34 --> Controller Class Initialized
INFO - 2021-08-10 20:21:34 --> Helper loaded: cookie_helper
INFO - 2021-08-10 20:21:34 --> Model "CookieModel" initialized
INFO - 2021-08-10 20:21:34 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-10 20:21:34 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-10 20:21:34 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-10 20:21:34 --> Final output sent to browser
DEBUG - 2021-08-10 20:21:34 --> Total execution time: 0.0301
INFO - 2021-08-10 20:22:08 --> Config Class Initialized
INFO - 2021-08-10 20:22:08 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:22:08 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:22:08 --> Utf8 Class Initialized
INFO - 2021-08-10 20:22:08 --> URI Class Initialized
INFO - 2021-08-10 20:22:08 --> Router Class Initialized
INFO - 2021-08-10 20:22:08 --> Output Class Initialized
INFO - 2021-08-10 20:22:08 --> Security Class Initialized
DEBUG - 2021-08-10 20:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:22:08 --> Input Class Initialized
INFO - 2021-08-10 20:22:08 --> Language Class Initialized
INFO - 2021-08-10 20:22:08 --> Loader Class Initialized
INFO - 2021-08-10 20:22:08 --> Helper loaded: url_helper
INFO - 2021-08-10 20:22:08 --> Helper loaded: file_helper
DEBUG - 2021-08-10 20:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-10 20:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-10 20:22:08 --> Controller Class Initialized
INFO - 2021-08-10 20:22:08 --> Helper loaded: cookie_helper
INFO - 2021-08-10 20:22:08 --> Model "CookieModel" initialized
INFO - 2021-08-10 20:22:08 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-10 20:22:08 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-10 20:22:08 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-10 20:22:08 --> Final output sent to browser
DEBUG - 2021-08-10 20:22:08 --> Total execution time: 0.0328
INFO - 2021-08-10 20:22:27 --> Config Class Initialized
INFO - 2021-08-10 20:22:27 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:22:27 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:22:27 --> Utf8 Class Initialized
INFO - 2021-08-10 20:22:27 --> URI Class Initialized
INFO - 2021-08-10 20:22:27 --> Router Class Initialized
INFO - 2021-08-10 20:22:27 --> Output Class Initialized
INFO - 2021-08-10 20:22:27 --> Security Class Initialized
DEBUG - 2021-08-10 20:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:22:27 --> Input Class Initialized
INFO - 2021-08-10 20:22:27 --> Language Class Initialized
INFO - 2021-08-10 20:22:27 --> Loader Class Initialized
INFO - 2021-08-10 20:22:27 --> Helper loaded: url_helper
INFO - 2021-08-10 20:22:27 --> Helper loaded: file_helper
DEBUG - 2021-08-10 20:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-10 20:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-10 20:22:27 --> Controller Class Initialized
INFO - 2021-08-10 20:22:27 --> Helper loaded: cookie_helper
INFO - 2021-08-10 20:22:27 --> Model "CookieModel" initialized
INFO - 2021-08-10 20:22:27 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-10 20:22:27 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-10 20:22:27 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-10 20:22:27 --> Final output sent to browser
DEBUG - 2021-08-10 20:22:27 --> Total execution time: 0.0323
INFO - 2021-08-10 20:22:27 --> Config Class Initialized
INFO - 2021-08-10 20:22:27 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:22:27 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:22:27 --> Utf8 Class Initialized
INFO - 2021-08-10 20:22:27 --> URI Class Initialized
INFO - 2021-08-10 20:22:27 --> Router Class Initialized
INFO - 2021-08-10 20:22:27 --> Output Class Initialized
INFO - 2021-08-10 20:22:27 --> Security Class Initialized
DEBUG - 2021-08-10 20:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:22:27 --> Input Class Initialized
INFO - 2021-08-10 20:22:27 --> Language Class Initialized
INFO - 2021-08-10 20:22:27 --> Loader Class Initialized
INFO - 2021-08-10 20:22:27 --> Helper loaded: url_helper
INFO - 2021-08-10 20:22:27 --> Helper loaded: file_helper
DEBUG - 2021-08-10 20:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-10 20:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-10 20:22:27 --> Controller Class Initialized
INFO - 2021-08-10 20:22:27 --> Helper loaded: cookie_helper
INFO - 2021-08-10 20:22:27 --> Model "CookieModel" initialized
INFO - 2021-08-10 20:22:27 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-10 20:22:27 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-10 20:22:27 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-10 20:22:27 --> Final output sent to browser
DEBUG - 2021-08-10 20:22:27 --> Total execution time: 0.0449
INFO - 2021-08-10 20:22:29 --> Config Class Initialized
INFO - 2021-08-10 20:22:29 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:22:29 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:22:29 --> Utf8 Class Initialized
INFO - 2021-08-10 20:22:29 --> URI Class Initialized
INFO - 2021-08-10 20:22:29 --> Router Class Initialized
INFO - 2021-08-10 20:22:29 --> Output Class Initialized
INFO - 2021-08-10 20:22:29 --> Security Class Initialized
DEBUG - 2021-08-10 20:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:22:29 --> Input Class Initialized
INFO - 2021-08-10 20:22:29 --> Language Class Initialized
INFO - 2021-08-10 20:22:29 --> Loader Class Initialized
INFO - 2021-08-10 20:22:29 --> Helper loaded: url_helper
INFO - 2021-08-10 20:22:29 --> Helper loaded: file_helper
DEBUG - 2021-08-10 20:22:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-10 20:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-10 20:22:29 --> Controller Class Initialized
INFO - 2021-08-10 20:22:29 --> Helper loaded: cookie_helper
INFO - 2021-08-10 20:22:29 --> Model "CookieModel" initialized
INFO - 2021-08-10 20:22:29 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-10 20:22:29 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-10 20:22:29 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-10 20:22:29 --> Final output sent to browser
DEBUG - 2021-08-10 20:22:29 --> Total execution time: 0.0322
INFO - 2021-08-10 20:22:31 --> Config Class Initialized
INFO - 2021-08-10 20:22:31 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:22:31 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:22:31 --> Utf8 Class Initialized
INFO - 2021-08-10 20:22:31 --> URI Class Initialized
INFO - 2021-08-10 20:22:31 --> Router Class Initialized
INFO - 2021-08-10 20:22:31 --> Output Class Initialized
INFO - 2021-08-10 20:22:31 --> Security Class Initialized
DEBUG - 2021-08-10 20:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:22:31 --> Input Class Initialized
INFO - 2021-08-10 20:22:31 --> Language Class Initialized
INFO - 2021-08-10 20:22:31 --> Loader Class Initialized
INFO - 2021-08-10 20:22:31 --> Helper loaded: url_helper
INFO - 2021-08-10 20:22:31 --> Helper loaded: file_helper
DEBUG - 2021-08-10 20:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-10 20:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-10 20:22:31 --> Controller Class Initialized
INFO - 2021-08-10 20:22:31 --> Helper loaded: cookie_helper
INFO - 2021-08-10 20:22:31 --> Model "CookieModel" initialized
INFO - 2021-08-10 20:22:31 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-10 20:22:31 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-10 20:22:31 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-10 20:22:31 --> Final output sent to browser
DEBUG - 2021-08-10 20:22:31 --> Total execution time: 0.0288
INFO - 2021-08-10 20:22:39 --> Config Class Initialized
INFO - 2021-08-10 20:22:39 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:22:39 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:22:39 --> Utf8 Class Initialized
INFO - 2021-08-10 20:22:39 --> URI Class Initialized
INFO - 2021-08-10 20:22:39 --> Router Class Initialized
INFO - 2021-08-10 20:22:39 --> Output Class Initialized
INFO - 2021-08-10 20:22:39 --> Security Class Initialized
DEBUG - 2021-08-10 20:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:22:39 --> Input Class Initialized
INFO - 2021-08-10 20:22:39 --> Language Class Initialized
INFO - 2021-08-10 20:22:39 --> Loader Class Initialized
INFO - 2021-08-10 20:22:39 --> Helper loaded: url_helper
INFO - 2021-08-10 20:22:39 --> Helper loaded: file_helper
DEBUG - 2021-08-10 20:22:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-10 20:22:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-10 20:22:39 --> Controller Class Initialized
INFO - 2021-08-10 20:22:39 --> Helper loaded: cookie_helper
INFO - 2021-08-10 20:22:39 --> Model "CookieModel" initialized
INFO - 2021-08-10 20:22:39 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-10 20:22:39 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-10 20:22:39 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-10 20:22:39 --> Final output sent to browser
DEBUG - 2021-08-10 20:22:39 --> Total execution time: 0.0282
INFO - 2021-08-10 20:22:41 --> Config Class Initialized
INFO - 2021-08-10 20:22:41 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:22:41 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:22:41 --> Utf8 Class Initialized
INFO - 2021-08-10 20:22:41 --> URI Class Initialized
INFO - 2021-08-10 20:22:41 --> Router Class Initialized
INFO - 2021-08-10 20:22:41 --> Output Class Initialized
INFO - 2021-08-10 20:22:41 --> Security Class Initialized
DEBUG - 2021-08-10 20:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:22:41 --> Input Class Initialized
INFO - 2021-08-10 20:22:41 --> Language Class Initialized
ERROR - 2021-08-10 20:22:41 --> 404 Page Not Found: Assets/js
INFO - 2021-08-10 20:22:41 --> Config Class Initialized
INFO - 2021-08-10 20:22:41 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:22:41 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:22:41 --> Config Class Initialized
INFO - 2021-08-10 20:22:41 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:22:41 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:22:41 --> Utf8 Class Initialized
INFO - 2021-08-10 20:22:41 --> Utf8 Class Initialized
INFO - 2021-08-10 20:22:41 --> URI Class Initialized
INFO - 2021-08-10 20:22:41 --> Router Class Initialized
INFO - 2021-08-10 20:22:41 --> URI Class Initialized
INFO - 2021-08-10 20:22:41 --> Output Class Initialized
INFO - 2021-08-10 20:22:41 --> Router Class Initialized
INFO - 2021-08-10 20:22:41 --> Security Class Initialized
INFO - 2021-08-10 20:22:41 --> Output Class Initialized
DEBUG - 2021-08-10 20:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:22:41 --> Input Class Initialized
INFO - 2021-08-10 20:22:41 --> Security Class Initialized
INFO - 2021-08-10 20:22:41 --> Language Class Initialized
DEBUG - 2021-08-10 20:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:22:41 --> Input Class Initialized
INFO - 2021-08-10 20:22:41 --> Language Class Initialized
ERROR - 2021-08-10 20:22:41 --> 404 Page Not Found: Assets/js
ERROR - 2021-08-10 20:22:41 --> 404 Page Not Found: Assets/js
INFO - 2021-08-10 20:22:42 --> Config Class Initialized
INFO - 2021-08-10 20:22:42 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:22:42 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:22:42 --> Config Class Initialized
INFO - 2021-08-10 20:22:42 --> Utf8 Class Initialized
INFO - 2021-08-10 20:22:42 --> Hooks Class Initialized
INFO - 2021-08-10 20:22:42 --> URI Class Initialized
INFO - 2021-08-10 20:22:42 --> Router Class Initialized
DEBUG - 2021-08-10 20:22:42 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:22:42 --> Utf8 Class Initialized
INFO - 2021-08-10 20:22:42 --> URI Class Initialized
INFO - 2021-08-10 20:22:42 --> Output Class Initialized
INFO - 2021-08-10 20:22:42 --> Router Class Initialized
INFO - 2021-08-10 20:22:42 --> Security Class Initialized
DEBUG - 2021-08-10 20:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:22:42 --> Output Class Initialized
INFO - 2021-08-10 20:22:42 --> Input Class Initialized
INFO - 2021-08-10 20:22:42 --> Language Class Initialized
INFO - 2021-08-10 20:22:42 --> Security Class Initialized
ERROR - 2021-08-10 20:22:42 --> 404 Page Not Found: Assets/css
DEBUG - 2021-08-10 20:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:22:42 --> Input Class Initialized
INFO - 2021-08-10 20:22:42 --> Language Class Initialized
ERROR - 2021-08-10 20:22:42 --> 404 Page Not Found: Assets/css
INFO - 2021-08-10 20:22:51 --> Config Class Initialized
INFO - 2021-08-10 20:22:51 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:22:51 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:22:51 --> Utf8 Class Initialized
INFO - 2021-08-10 20:22:51 --> URI Class Initialized
DEBUG - 2021-08-10 20:22:51 --> No URI present. Default controller set.
INFO - 2021-08-10 20:22:51 --> Router Class Initialized
INFO - 2021-08-10 20:22:51 --> Output Class Initialized
INFO - 2021-08-10 20:22:51 --> Security Class Initialized
DEBUG - 2021-08-10 20:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:22:51 --> Input Class Initialized
INFO - 2021-08-10 20:22:51 --> Language Class Initialized
INFO - 2021-08-10 20:22:51 --> Loader Class Initialized
INFO - 2021-08-10 20:22:51 --> Helper loaded: url_helper
INFO - 2021-08-10 20:22:51 --> Helper loaded: file_helper
DEBUG - 2021-08-10 20:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-10 20:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-10 20:22:51 --> Controller Class Initialized
INFO - 2021-08-10 20:22:51 --> Helper loaded: cookie_helper
INFO - 2021-08-10 20:22:51 --> Model "CookieModel" initialized
INFO - 2021-08-10 20:22:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-10 20:22:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-10 20:22:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-10 20:22:51 --> Final output sent to browser
DEBUG - 2021-08-10 20:22:51 --> Total execution time: 0.0374
INFO - 2021-08-10 20:22:52 --> Config Class Initialized
INFO - 2021-08-10 20:22:52 --> Hooks Class Initialized
INFO - 2021-08-10 20:22:52 --> Config Class Initialized
INFO - 2021-08-10 20:22:52 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:22:52 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:22:52 --> Utf8 Class Initialized
INFO - 2021-08-10 20:22:52 --> URI Class Initialized
DEBUG - 2021-08-10 20:22:52 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:22:52 --> Router Class Initialized
INFO - 2021-08-10 20:22:52 --> Utf8 Class Initialized
INFO - 2021-08-10 20:22:52 --> URI Class Initialized
INFO - 2021-08-10 20:22:52 --> Output Class Initialized
INFO - 2021-08-10 20:22:52 --> Router Class Initialized
INFO - 2021-08-10 20:22:52 --> Security Class Initialized
INFO - 2021-08-10 20:22:52 --> Output Class Initialized
DEBUG - 2021-08-10 20:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:22:52 --> Input Class Initialized
INFO - 2021-08-10 20:22:52 --> Security Class Initialized
INFO - 2021-08-10 20:22:52 --> Language Class Initialized
DEBUG - 2021-08-10 20:22:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-08-10 20:22:52 --> 404 Page Not Found: Assets/css
INFO - 2021-08-10 20:22:52 --> Input Class Initialized
INFO - 2021-08-10 20:22:52 --> Language Class Initialized
ERROR - 2021-08-10 20:22:52 --> 404 Page Not Found: Assets/css
INFO - 2021-08-10 20:22:52 --> Config Class Initialized
INFO - 2021-08-10 20:22:52 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:22:52 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:22:52 --> Utf8 Class Initialized
INFO - 2021-08-10 20:22:52 --> URI Class Initialized
INFO - 2021-08-10 20:22:52 --> Router Class Initialized
INFO - 2021-08-10 20:22:52 --> Output Class Initialized
INFO - 2021-08-10 20:22:52 --> Security Class Initialized
DEBUG - 2021-08-10 20:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:22:52 --> Input Class Initialized
INFO - 2021-08-10 20:22:52 --> Language Class Initialized
ERROR - 2021-08-10 20:22:52 --> 404 Page Not Found: Assets/js
INFO - 2021-08-10 20:22:52 --> Config Class Initialized
INFO - 2021-08-10 20:22:52 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:22:52 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:22:52 --> Utf8 Class Initialized
INFO - 2021-08-10 20:22:52 --> URI Class Initialized
INFO - 2021-08-10 20:22:52 --> Router Class Initialized
INFO - 2021-08-10 20:22:52 --> Output Class Initialized
INFO - 2021-08-10 20:22:52 --> Security Class Initialized
DEBUG - 2021-08-10 20:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:22:52 --> Input Class Initialized
INFO - 2021-08-10 20:22:52 --> Language Class Initialized
ERROR - 2021-08-10 20:22:52 --> 404 Page Not Found: Assets/js
INFO - 2021-08-10 20:22:52 --> Config Class Initialized
INFO - 2021-08-10 20:22:52 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:22:52 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:22:52 --> Utf8 Class Initialized
INFO - 2021-08-10 20:22:52 --> URI Class Initialized
INFO - 2021-08-10 20:22:52 --> Router Class Initialized
INFO - 2021-08-10 20:22:52 --> Output Class Initialized
INFO - 2021-08-10 20:22:52 --> Security Class Initialized
DEBUG - 2021-08-10 20:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:22:52 --> Input Class Initialized
INFO - 2021-08-10 20:22:52 --> Language Class Initialized
ERROR - 2021-08-10 20:22:52 --> 404 Page Not Found: Assets/js
INFO - 2021-08-10 20:22:56 --> Config Class Initialized
INFO - 2021-08-10 20:22:56 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:22:56 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:22:56 --> Utf8 Class Initialized
INFO - 2021-08-10 20:22:56 --> URI Class Initialized
INFO - 2021-08-10 20:22:56 --> Router Class Initialized
INFO - 2021-08-10 20:22:56 --> Output Class Initialized
INFO - 2021-08-10 20:22:56 --> Security Class Initialized
DEBUG - 2021-08-10 20:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:22:56 --> Input Class Initialized
INFO - 2021-08-10 20:22:56 --> Language Class Initialized
INFO - 2021-08-10 20:22:56 --> Loader Class Initialized
INFO - 2021-08-10 20:22:56 --> Helper loaded: url_helper
INFO - 2021-08-10 20:22:56 --> Helper loaded: file_helper
DEBUG - 2021-08-10 20:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-10 20:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-10 20:22:56 --> Controller Class Initialized
INFO - 2021-08-10 20:22:56 --> Helper loaded: cookie_helper
INFO - 2021-08-10 20:22:56 --> Model "CookieModel" initialized
INFO - 2021-08-10 20:22:56 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-10 20:22:56 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/pilates.php
INFO - 2021-08-10 20:22:56 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-10 20:22:56 --> Final output sent to browser
DEBUG - 2021-08-10 20:22:56 --> Total execution time: 0.0503
INFO - 2021-08-10 20:22:56 --> Config Class Initialized
INFO - 2021-08-10 20:22:56 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:22:57 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:22:57 --> Utf8 Class Initialized
INFO - 2021-08-10 20:22:57 --> Config Class Initialized
INFO - 2021-08-10 20:22:57 --> URI Class Initialized
INFO - 2021-08-10 20:22:57 --> Hooks Class Initialized
INFO - 2021-08-10 20:22:57 --> Router Class Initialized
INFO - 2021-08-10 20:22:57 --> Output Class Initialized
DEBUG - 2021-08-10 20:22:57 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:22:57 --> Utf8 Class Initialized
INFO - 2021-08-10 20:22:57 --> Security Class Initialized
DEBUG - 2021-08-10 20:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:22:57 --> Input Class Initialized
INFO - 2021-08-10 20:22:57 --> URI Class Initialized
INFO - 2021-08-10 20:22:57 --> Language Class Initialized
INFO - 2021-08-10 20:22:57 --> Router Class Initialized
ERROR - 2021-08-10 20:22:57 --> 404 Page Not Found: Assets/css
INFO - 2021-08-10 20:22:57 --> Output Class Initialized
INFO - 2021-08-10 20:22:57 --> Security Class Initialized
DEBUG - 2021-08-10 20:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:22:57 --> Input Class Initialized
INFO - 2021-08-10 20:22:57 --> Language Class Initialized
ERROR - 2021-08-10 20:22:57 --> 404 Page Not Found: Assets/css
INFO - 2021-08-10 20:22:57 --> Config Class Initialized
INFO - 2021-08-10 20:22:57 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:22:57 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:22:57 --> Utf8 Class Initialized
INFO - 2021-08-10 20:22:57 --> URI Class Initialized
INFO - 2021-08-10 20:22:57 --> Router Class Initialized
INFO - 2021-08-10 20:22:57 --> Output Class Initialized
INFO - 2021-08-10 20:22:57 --> Security Class Initialized
DEBUG - 2021-08-10 20:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:22:57 --> Input Class Initialized
INFO - 2021-08-10 20:22:57 --> Language Class Initialized
ERROR - 2021-08-10 20:22:57 --> 404 Page Not Found: Assets/js
INFO - 2021-08-10 20:22:57 --> Config Class Initialized
INFO - 2021-08-10 20:22:57 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:22:57 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:22:57 --> Utf8 Class Initialized
INFO - 2021-08-10 20:22:57 --> Config Class Initialized
INFO - 2021-08-10 20:22:57 --> Hooks Class Initialized
INFO - 2021-08-10 20:22:57 --> URI Class Initialized
INFO - 2021-08-10 20:22:57 --> Router Class Initialized
DEBUG - 2021-08-10 20:22:57 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:22:57 --> Utf8 Class Initialized
INFO - 2021-08-10 20:22:57 --> Output Class Initialized
INFO - 2021-08-10 20:22:57 --> URI Class Initialized
INFO - 2021-08-10 20:22:57 --> Router Class Initialized
INFO - 2021-08-10 20:22:57 --> Output Class Initialized
INFO - 2021-08-10 20:22:57 --> Security Class Initialized
DEBUG - 2021-08-10 20:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:22:57 --> Input Class Initialized
INFO - 2021-08-10 20:22:57 --> Language Class Initialized
ERROR - 2021-08-10 20:22:57 --> 404 Page Not Found: Assets/js
INFO - 2021-08-10 20:22:57 --> Security Class Initialized
DEBUG - 2021-08-10 20:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:22:57 --> Input Class Initialized
INFO - 2021-08-10 20:22:57 --> Language Class Initialized
ERROR - 2021-08-10 20:22:57 --> 404 Page Not Found: Assets/js
INFO - 2021-08-10 20:23:02 --> Config Class Initialized
INFO - 2021-08-10 20:23:02 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:23:02 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:23:02 --> Utf8 Class Initialized
INFO - 2021-08-10 20:23:02 --> URI Class Initialized
INFO - 2021-08-10 20:23:02 --> Router Class Initialized
INFO - 2021-08-10 20:23:02 --> Output Class Initialized
INFO - 2021-08-10 20:23:02 --> Security Class Initialized
DEBUG - 2021-08-10 20:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:23:02 --> Input Class Initialized
INFO - 2021-08-10 20:23:02 --> Language Class Initialized
INFO - 2021-08-10 20:23:02 --> Loader Class Initialized
INFO - 2021-08-10 20:23:02 --> Helper loaded: url_helper
INFO - 2021-08-10 20:23:02 --> Helper loaded: file_helper
DEBUG - 2021-08-10 20:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-10 20:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-10 20:23:02 --> Controller Class Initialized
INFO - 2021-08-10 20:23:02 --> Helper loaded: cookie_helper
INFO - 2021-08-10 20:23:02 --> Model "CookieModel" initialized
INFO - 2021-08-10 20:23:02 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-10 20:23:02 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-10 20:23:02 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-10 20:23:02 --> Final output sent to browser
DEBUG - 2021-08-10 20:23:02 --> Total execution time: 0.0361
INFO - 2021-08-10 20:23:02 --> Config Class Initialized
INFO - 2021-08-10 20:23:02 --> Hooks Class Initialized
INFO - 2021-08-10 20:23:02 --> Config Class Initialized
INFO - 2021-08-10 20:23:02 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:23:02 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:23:02 --> Utf8 Class Initialized
DEBUG - 2021-08-10 20:23:02 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:23:02 --> Utf8 Class Initialized
INFO - 2021-08-10 20:23:02 --> URI Class Initialized
INFO - 2021-08-10 20:23:02 --> URI Class Initialized
INFO - 2021-08-10 20:23:02 --> Router Class Initialized
INFO - 2021-08-10 20:23:02 --> Router Class Initialized
INFO - 2021-08-10 20:23:02 --> Output Class Initialized
INFO - 2021-08-10 20:23:02 --> Security Class Initialized
INFO - 2021-08-10 20:23:02 --> Output Class Initialized
DEBUG - 2021-08-10 20:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:23:02 --> Input Class Initialized
INFO - 2021-08-10 20:23:02 --> Security Class Initialized
INFO - 2021-08-10 20:23:02 --> Language Class Initialized
DEBUG - 2021-08-10 20:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:23:02 --> Input Class Initialized
ERROR - 2021-08-10 20:23:02 --> 404 Page Not Found: Assets/css
INFO - 2021-08-10 20:23:02 --> Language Class Initialized
ERROR - 2021-08-10 20:23:02 --> 404 Page Not Found: Assets/css
INFO - 2021-08-10 20:23:02 --> Config Class Initialized
INFO - 2021-08-10 20:23:02 --> Hooks Class Initialized
INFO - 2021-08-10 20:23:02 --> Config Class Initialized
DEBUG - 2021-08-10 20:23:02 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:23:02 --> Hooks Class Initialized
INFO - 2021-08-10 20:23:02 --> Utf8 Class Initialized
INFO - 2021-08-10 20:23:02 --> URI Class Initialized
DEBUG - 2021-08-10 20:23:02 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:23:02 --> Router Class Initialized
INFO - 2021-08-10 20:23:02 --> Utf8 Class Initialized
INFO - 2021-08-10 20:23:02 --> URI Class Initialized
INFO - 2021-08-10 20:23:02 --> Output Class Initialized
INFO - 2021-08-10 20:23:02 --> Router Class Initialized
INFO - 2021-08-10 20:23:02 --> Security Class Initialized
DEBUG - 2021-08-10 20:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:23:02 --> Input Class Initialized
INFO - 2021-08-10 20:23:02 --> Output Class Initialized
INFO - 2021-08-10 20:23:02 --> Language Class Initialized
INFO - 2021-08-10 20:23:02 --> Security Class Initialized
DEBUG - 2021-08-10 20:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:23:03 --> Input Class Initialized
ERROR - 2021-08-10 20:23:03 --> 404 Page Not Found: Assets/js
INFO - 2021-08-10 20:23:03 --> Language Class Initialized
ERROR - 2021-08-10 20:23:03 --> 404 Page Not Found: Assets/js
INFO - 2021-08-10 20:23:03 --> Config Class Initialized
INFO - 2021-08-10 20:23:03 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:23:03 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:23:03 --> Utf8 Class Initialized
INFO - 2021-08-10 20:23:03 --> URI Class Initialized
INFO - 2021-08-10 20:23:03 --> Router Class Initialized
INFO - 2021-08-10 20:23:03 --> Output Class Initialized
INFO - 2021-08-10 20:23:03 --> Security Class Initialized
DEBUG - 2021-08-10 20:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:23:03 --> Input Class Initialized
INFO - 2021-08-10 20:23:03 --> Language Class Initialized
ERROR - 2021-08-10 20:23:03 --> 404 Page Not Found: Assets/js
INFO - 2021-08-10 20:24:36 --> Config Class Initialized
INFO - 2021-08-10 20:24:36 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:24:36 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:24:36 --> Utf8 Class Initialized
INFO - 2021-08-10 20:24:36 --> URI Class Initialized
INFO - 2021-08-10 20:24:36 --> Router Class Initialized
INFO - 2021-08-10 20:24:36 --> Output Class Initialized
INFO - 2021-08-10 20:24:36 --> Security Class Initialized
DEBUG - 2021-08-10 20:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:24:36 --> Input Class Initialized
INFO - 2021-08-10 20:24:36 --> Language Class Initialized
INFO - 2021-08-10 20:24:36 --> Loader Class Initialized
INFO - 2021-08-10 20:24:36 --> Helper loaded: url_helper
INFO - 2021-08-10 20:24:36 --> Helper loaded: file_helper
DEBUG - 2021-08-10 20:24:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-10 20:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-10 20:24:36 --> Controller Class Initialized
INFO - 2021-08-10 20:24:36 --> Helper loaded: cookie_helper
INFO - 2021-08-10 20:24:36 --> Model "CookieModel" initialized
INFO - 2021-08-10 20:24:36 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-10 20:24:36 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/team.php
INFO - 2021-08-10 20:24:36 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-10 20:24:36 --> Final output sent to browser
DEBUG - 2021-08-10 20:24:36 --> Total execution time: 0.0340
INFO - 2021-08-10 20:29:09 --> Config Class Initialized
INFO - 2021-08-10 20:29:09 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:29:09 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:29:09 --> Utf8 Class Initialized
INFO - 2021-08-10 20:29:09 --> URI Class Initialized
INFO - 2021-08-10 20:29:09 --> Router Class Initialized
INFO - 2021-08-10 20:29:09 --> Output Class Initialized
INFO - 2021-08-10 20:29:09 --> Security Class Initialized
DEBUG - 2021-08-10 20:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:29:09 --> Input Class Initialized
INFO - 2021-08-10 20:29:09 --> Language Class Initialized
INFO - 2021-08-10 20:29:09 --> Loader Class Initialized
INFO - 2021-08-10 20:29:09 --> Helper loaded: url_helper
INFO - 2021-08-10 20:29:09 --> Helper loaded: file_helper
DEBUG - 2021-08-10 20:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-10 20:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-10 20:29:09 --> Controller Class Initialized
INFO - 2021-08-10 20:29:09 --> Helper loaded: cookie_helper
INFO - 2021-08-10 20:29:09 --> Model "CookieModel" initialized
INFO - 2021-08-10 20:29:09 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-10 20:29:09 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/team.php
INFO - 2021-08-10 20:29:09 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-10 20:29:09 --> Final output sent to browser
DEBUG - 2021-08-10 20:29:09 --> Total execution time: 0.0396
INFO - 2021-08-10 20:29:18 --> Config Class Initialized
INFO - 2021-08-10 20:29:18 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:29:18 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:29:18 --> Utf8 Class Initialized
INFO - 2021-08-10 20:29:18 --> URI Class Initialized
INFO - 2021-08-10 20:29:18 --> Router Class Initialized
INFO - 2021-08-10 20:29:18 --> Output Class Initialized
INFO - 2021-08-10 20:29:18 --> Security Class Initialized
DEBUG - 2021-08-10 20:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:29:18 --> Input Class Initialized
INFO - 2021-08-10 20:29:18 --> Language Class Initialized
INFO - 2021-08-10 20:29:18 --> Loader Class Initialized
INFO - 2021-08-10 20:29:18 --> Helper loaded: url_helper
INFO - 2021-08-10 20:29:18 --> Helper loaded: file_helper
DEBUG - 2021-08-10 20:29:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-10 20:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-10 20:29:18 --> Controller Class Initialized
INFO - 2021-08-10 20:29:18 --> Helper loaded: cookie_helper
INFO - 2021-08-10 20:29:18 --> Model "CookieModel" initialized
INFO - 2021-08-10 20:29:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-10 20:29:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-10 20:29:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-10 20:29:18 --> Final output sent to browser
DEBUG - 2021-08-10 20:29:18 --> Total execution time: 0.0300
INFO - 2021-08-10 20:31:09 --> Config Class Initialized
INFO - 2021-08-10 20:31:09 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:31:09 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:31:09 --> Utf8 Class Initialized
INFO - 2021-08-10 20:31:09 --> URI Class Initialized
DEBUG - 2021-08-10 20:31:09 --> No URI present. Default controller set.
INFO - 2021-08-10 20:31:09 --> Router Class Initialized
INFO - 2021-08-10 20:31:09 --> Output Class Initialized
INFO - 2021-08-10 20:31:09 --> Security Class Initialized
DEBUG - 2021-08-10 20:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:31:09 --> Input Class Initialized
INFO - 2021-08-10 20:31:09 --> Language Class Initialized
INFO - 2021-08-10 20:31:09 --> Loader Class Initialized
INFO - 2021-08-10 20:31:09 --> Helper loaded: url_helper
INFO - 2021-08-10 20:31:09 --> Helper loaded: file_helper
DEBUG - 2021-08-10 20:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-10 20:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-10 20:31:09 --> Controller Class Initialized
INFO - 2021-08-10 20:31:09 --> Helper loaded: cookie_helper
INFO - 2021-08-10 20:31:09 --> Model "CookieModel" initialized
INFO - 2021-08-10 20:31:09 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-10 20:31:09 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-10 20:31:09 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-10 20:31:09 --> Final output sent to browser
DEBUG - 2021-08-10 20:31:09 --> Total execution time: 0.0420
INFO - 2021-08-10 20:32:50 --> Config Class Initialized
INFO - 2021-08-10 20:32:50 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:32:50 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:32:50 --> Utf8 Class Initialized
INFO - 2021-08-10 20:32:50 --> URI Class Initialized
DEBUG - 2021-08-10 20:32:50 --> No URI present. Default controller set.
INFO - 2021-08-10 20:32:50 --> Router Class Initialized
INFO - 2021-08-10 20:32:50 --> Output Class Initialized
INFO - 2021-08-10 20:32:50 --> Security Class Initialized
DEBUG - 2021-08-10 20:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:32:50 --> Input Class Initialized
INFO - 2021-08-10 20:32:50 --> Language Class Initialized
INFO - 2021-08-10 20:32:50 --> Loader Class Initialized
INFO - 2021-08-10 20:32:50 --> Helper loaded: url_helper
INFO - 2021-08-10 20:32:50 --> Helper loaded: file_helper
DEBUG - 2021-08-10 20:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-10 20:32:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-10 20:32:50 --> Controller Class Initialized
INFO - 2021-08-10 20:32:50 --> Helper loaded: cookie_helper
INFO - 2021-08-10 20:32:50 --> Model "CookieModel" initialized
INFO - 2021-08-10 20:32:50 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-10 20:32:50 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-10 20:32:50 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-10 20:32:50 --> Final output sent to browser
DEBUG - 2021-08-10 20:32:50 --> Total execution time: 0.0383
INFO - 2021-08-10 20:33:36 --> Config Class Initialized
INFO - 2021-08-10 20:33:36 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:33:36 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:33:36 --> Utf8 Class Initialized
INFO - 2021-08-10 20:33:36 --> URI Class Initialized
DEBUG - 2021-08-10 20:33:36 --> No URI present. Default controller set.
INFO - 2021-08-10 20:33:36 --> Router Class Initialized
INFO - 2021-08-10 20:33:36 --> Output Class Initialized
INFO - 2021-08-10 20:33:36 --> Security Class Initialized
DEBUG - 2021-08-10 20:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:33:36 --> Input Class Initialized
INFO - 2021-08-10 20:33:36 --> Language Class Initialized
INFO - 2021-08-10 20:33:36 --> Loader Class Initialized
INFO - 2021-08-10 20:33:36 --> Helper loaded: url_helper
INFO - 2021-08-10 20:33:36 --> Helper loaded: file_helper
DEBUG - 2021-08-10 20:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-10 20:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-10 20:33:36 --> Controller Class Initialized
INFO - 2021-08-10 20:33:36 --> Helper loaded: cookie_helper
INFO - 2021-08-10 20:33:36 --> Model "CookieModel" initialized
INFO - 2021-08-10 20:33:36 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-10 20:33:36 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-10 20:33:36 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-10 20:33:36 --> Final output sent to browser
DEBUG - 2021-08-10 20:33:36 --> Total execution time: 0.0338
INFO - 2021-08-10 20:34:00 --> Config Class Initialized
INFO - 2021-08-10 20:34:00 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:34:00 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:34:00 --> Utf8 Class Initialized
INFO - 2021-08-10 20:34:00 --> URI Class Initialized
DEBUG - 2021-08-10 20:34:00 --> No URI present. Default controller set.
INFO - 2021-08-10 20:34:00 --> Router Class Initialized
INFO - 2021-08-10 20:34:00 --> Output Class Initialized
INFO - 2021-08-10 20:34:00 --> Security Class Initialized
DEBUG - 2021-08-10 20:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:34:00 --> Input Class Initialized
INFO - 2021-08-10 20:34:00 --> Language Class Initialized
INFO - 2021-08-10 20:34:00 --> Loader Class Initialized
INFO - 2021-08-10 20:34:00 --> Helper loaded: url_helper
INFO - 2021-08-10 20:34:00 --> Helper loaded: file_helper
DEBUG - 2021-08-10 20:34:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-10 20:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-10 20:34:00 --> Controller Class Initialized
INFO - 2021-08-10 20:34:00 --> Helper loaded: cookie_helper
INFO - 2021-08-10 20:34:00 --> Model "CookieModel" initialized
INFO - 2021-08-10 20:34:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-10 20:34:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-10 20:34:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-10 20:34:00 --> Final output sent to browser
DEBUG - 2021-08-10 20:34:00 --> Total execution time: 0.0733
INFO - 2021-08-10 20:34:03 --> Config Class Initialized
INFO - 2021-08-10 20:34:03 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:34:03 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:34:03 --> Utf8 Class Initialized
INFO - 2021-08-10 20:34:03 --> URI Class Initialized
DEBUG - 2021-08-10 20:34:03 --> No URI present. Default controller set.
INFO - 2021-08-10 20:34:03 --> Router Class Initialized
INFO - 2021-08-10 20:34:03 --> Output Class Initialized
INFO - 2021-08-10 20:34:03 --> Security Class Initialized
DEBUG - 2021-08-10 20:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:34:03 --> Input Class Initialized
INFO - 2021-08-10 20:34:03 --> Language Class Initialized
INFO - 2021-08-10 20:34:03 --> Loader Class Initialized
INFO - 2021-08-10 20:34:03 --> Helper loaded: url_helper
INFO - 2021-08-10 20:34:03 --> Helper loaded: file_helper
DEBUG - 2021-08-10 20:34:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-10 20:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-10 20:34:03 --> Controller Class Initialized
INFO - 2021-08-10 20:34:03 --> Helper loaded: cookie_helper
INFO - 2021-08-10 20:34:03 --> Model "CookieModel" initialized
INFO - 2021-08-10 20:34:03 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-10 20:34:03 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-10 20:34:03 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-10 20:34:03 --> Final output sent to browser
DEBUG - 2021-08-10 20:34:03 --> Total execution time: 0.0302
INFO - 2021-08-10 20:34:18 --> Config Class Initialized
INFO - 2021-08-10 20:34:18 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:34:18 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:34:18 --> Utf8 Class Initialized
INFO - 2021-08-10 20:34:18 --> URI Class Initialized
DEBUG - 2021-08-10 20:34:18 --> No URI present. Default controller set.
INFO - 2021-08-10 20:34:18 --> Router Class Initialized
INFO - 2021-08-10 20:34:18 --> Output Class Initialized
INFO - 2021-08-10 20:34:18 --> Security Class Initialized
DEBUG - 2021-08-10 20:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:34:18 --> Input Class Initialized
INFO - 2021-08-10 20:34:18 --> Language Class Initialized
INFO - 2021-08-10 20:34:18 --> Loader Class Initialized
INFO - 2021-08-10 20:34:18 --> Helper loaded: url_helper
INFO - 2021-08-10 20:34:18 --> Helper loaded: file_helper
DEBUG - 2021-08-10 20:34:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-10 20:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-10 20:34:18 --> Controller Class Initialized
INFO - 2021-08-10 20:34:18 --> Helper loaded: cookie_helper
INFO - 2021-08-10 20:34:18 --> Model "CookieModel" initialized
INFO - 2021-08-10 20:34:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-10 20:34:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-10 20:34:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-10 20:34:18 --> Final output sent to browser
DEBUG - 2021-08-10 20:34:18 --> Total execution time: 0.0475
INFO - 2021-08-10 20:34:32 --> Config Class Initialized
INFO - 2021-08-10 20:34:32 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:34:32 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:34:32 --> Utf8 Class Initialized
INFO - 2021-08-10 20:34:32 --> URI Class Initialized
DEBUG - 2021-08-10 20:34:32 --> No URI present. Default controller set.
INFO - 2021-08-10 20:34:32 --> Router Class Initialized
INFO - 2021-08-10 20:34:32 --> Output Class Initialized
INFO - 2021-08-10 20:34:32 --> Security Class Initialized
DEBUG - 2021-08-10 20:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:34:32 --> Input Class Initialized
INFO - 2021-08-10 20:34:32 --> Language Class Initialized
INFO - 2021-08-10 20:34:32 --> Loader Class Initialized
INFO - 2021-08-10 20:34:32 --> Helper loaded: url_helper
INFO - 2021-08-10 20:34:32 --> Helper loaded: file_helper
DEBUG - 2021-08-10 20:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-10 20:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-10 20:34:32 --> Controller Class Initialized
INFO - 2021-08-10 20:34:32 --> Helper loaded: cookie_helper
INFO - 2021-08-10 20:34:32 --> Model "CookieModel" initialized
INFO - 2021-08-10 20:34:32 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-10 20:34:32 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-10 20:34:32 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-10 20:34:32 --> Final output sent to browser
DEBUG - 2021-08-10 20:34:32 --> Total execution time: 0.0341
INFO - 2021-08-10 20:35:58 --> Config Class Initialized
INFO - 2021-08-10 20:35:58 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:35:58 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:35:58 --> Utf8 Class Initialized
INFO - 2021-08-10 20:35:58 --> URI Class Initialized
DEBUG - 2021-08-10 20:35:58 --> No URI present. Default controller set.
INFO - 2021-08-10 20:35:58 --> Router Class Initialized
INFO - 2021-08-10 20:35:58 --> Output Class Initialized
INFO - 2021-08-10 20:35:58 --> Security Class Initialized
DEBUG - 2021-08-10 20:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:35:58 --> Input Class Initialized
INFO - 2021-08-10 20:35:58 --> Language Class Initialized
INFO - 2021-08-10 20:35:58 --> Loader Class Initialized
INFO - 2021-08-10 20:35:58 --> Helper loaded: url_helper
INFO - 2021-08-10 20:35:58 --> Helper loaded: file_helper
DEBUG - 2021-08-10 20:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-10 20:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-10 20:35:58 --> Controller Class Initialized
INFO - 2021-08-10 20:35:58 --> Helper loaded: cookie_helper
INFO - 2021-08-10 20:35:58 --> Model "CookieModel" initialized
INFO - 2021-08-10 20:35:58 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-10 20:35:58 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-10 20:35:58 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-10 20:35:58 --> Final output sent to browser
DEBUG - 2021-08-10 20:35:58 --> Total execution time: 0.0335
INFO - 2021-08-10 20:36:39 --> Config Class Initialized
INFO - 2021-08-10 20:36:39 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:36:39 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:36:39 --> Utf8 Class Initialized
INFO - 2021-08-10 20:36:39 --> URI Class Initialized
DEBUG - 2021-08-10 20:36:39 --> No URI present. Default controller set.
INFO - 2021-08-10 20:36:39 --> Router Class Initialized
INFO - 2021-08-10 20:36:39 --> Output Class Initialized
INFO - 2021-08-10 20:36:39 --> Security Class Initialized
DEBUG - 2021-08-10 20:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:36:39 --> Input Class Initialized
INFO - 2021-08-10 20:36:39 --> Language Class Initialized
INFO - 2021-08-10 20:36:39 --> Loader Class Initialized
INFO - 2021-08-10 20:36:39 --> Helper loaded: url_helper
INFO - 2021-08-10 20:36:39 --> Helper loaded: file_helper
DEBUG - 2021-08-10 20:36:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-10 20:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-10 20:36:39 --> Controller Class Initialized
INFO - 2021-08-10 20:36:39 --> Helper loaded: cookie_helper
INFO - 2021-08-10 20:36:39 --> Model "CookieModel" initialized
INFO - 2021-08-10 20:36:39 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-10 20:36:39 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-10 20:36:39 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-10 20:36:39 --> Final output sent to browser
DEBUG - 2021-08-10 20:36:39 --> Total execution time: 0.0420
INFO - 2021-08-10 20:37:42 --> Config Class Initialized
INFO - 2021-08-10 20:37:42 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:37:42 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:37:42 --> Utf8 Class Initialized
INFO - 2021-08-10 20:37:42 --> URI Class Initialized
DEBUG - 2021-08-10 20:37:42 --> No URI present. Default controller set.
INFO - 2021-08-10 20:37:42 --> Router Class Initialized
INFO - 2021-08-10 20:37:42 --> Output Class Initialized
INFO - 2021-08-10 20:37:42 --> Security Class Initialized
DEBUG - 2021-08-10 20:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:37:42 --> Input Class Initialized
INFO - 2021-08-10 20:37:42 --> Language Class Initialized
INFO - 2021-08-10 20:37:42 --> Loader Class Initialized
INFO - 2021-08-10 20:37:42 --> Helper loaded: url_helper
INFO - 2021-08-10 20:37:42 --> Helper loaded: file_helper
DEBUG - 2021-08-10 20:37:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-10 20:37:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-10 20:37:42 --> Controller Class Initialized
INFO - 2021-08-10 20:37:42 --> Helper loaded: cookie_helper
INFO - 2021-08-10 20:37:42 --> Model "CookieModel" initialized
INFO - 2021-08-10 20:37:42 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-10 20:37:42 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-10 20:37:42 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-10 20:37:42 --> Final output sent to browser
DEBUG - 2021-08-10 20:37:42 --> Total execution time: 0.0387
INFO - 2021-08-10 20:38:08 --> Config Class Initialized
INFO - 2021-08-10 20:38:08 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:38:08 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:38:08 --> Utf8 Class Initialized
INFO - 2021-08-10 20:38:08 --> URI Class Initialized
DEBUG - 2021-08-10 20:38:08 --> No URI present. Default controller set.
INFO - 2021-08-10 20:38:08 --> Router Class Initialized
INFO - 2021-08-10 20:38:08 --> Output Class Initialized
INFO - 2021-08-10 20:38:08 --> Security Class Initialized
DEBUG - 2021-08-10 20:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:38:08 --> Input Class Initialized
INFO - 2021-08-10 20:38:08 --> Language Class Initialized
INFO - 2021-08-10 20:38:08 --> Loader Class Initialized
INFO - 2021-08-10 20:38:08 --> Helper loaded: url_helper
INFO - 2021-08-10 20:38:08 --> Helper loaded: file_helper
DEBUG - 2021-08-10 20:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-10 20:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-10 20:38:08 --> Controller Class Initialized
INFO - 2021-08-10 20:38:08 --> Helper loaded: cookie_helper
INFO - 2021-08-10 20:38:08 --> Model "CookieModel" initialized
INFO - 2021-08-10 20:38:08 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-10 20:38:08 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-10 20:38:08 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-10 20:38:08 --> Final output sent to browser
DEBUG - 2021-08-10 20:38:08 --> Total execution time: 0.0334
INFO - 2021-08-10 20:38:24 --> Config Class Initialized
INFO - 2021-08-10 20:38:24 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:38:24 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:38:24 --> Utf8 Class Initialized
INFO - 2021-08-10 20:38:24 --> URI Class Initialized
DEBUG - 2021-08-10 20:38:24 --> No URI present. Default controller set.
INFO - 2021-08-10 20:38:24 --> Router Class Initialized
INFO - 2021-08-10 20:38:24 --> Output Class Initialized
INFO - 2021-08-10 20:38:24 --> Security Class Initialized
DEBUG - 2021-08-10 20:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:38:24 --> Input Class Initialized
INFO - 2021-08-10 20:38:24 --> Language Class Initialized
INFO - 2021-08-10 20:38:24 --> Loader Class Initialized
INFO - 2021-08-10 20:38:24 --> Helper loaded: url_helper
INFO - 2021-08-10 20:38:24 --> Helper loaded: file_helper
DEBUG - 2021-08-10 20:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-10 20:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-10 20:38:24 --> Controller Class Initialized
INFO - 2021-08-10 20:38:24 --> Helper loaded: cookie_helper
INFO - 2021-08-10 20:38:24 --> Model "CookieModel" initialized
INFO - 2021-08-10 20:38:24 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-10 20:38:24 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-10 20:38:24 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-10 20:38:24 --> Final output sent to browser
DEBUG - 2021-08-10 20:38:24 --> Total execution time: 0.0333
INFO - 2021-08-10 20:38:33 --> Config Class Initialized
INFO - 2021-08-10 20:38:33 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:38:33 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:38:33 --> Utf8 Class Initialized
INFO - 2021-08-10 20:38:33 --> URI Class Initialized
DEBUG - 2021-08-10 20:38:33 --> No URI present. Default controller set.
INFO - 2021-08-10 20:38:33 --> Router Class Initialized
INFO - 2021-08-10 20:38:33 --> Output Class Initialized
INFO - 2021-08-10 20:38:33 --> Security Class Initialized
DEBUG - 2021-08-10 20:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:38:33 --> Input Class Initialized
INFO - 2021-08-10 20:38:33 --> Language Class Initialized
INFO - 2021-08-10 20:38:33 --> Loader Class Initialized
INFO - 2021-08-10 20:38:33 --> Helper loaded: url_helper
INFO - 2021-08-10 20:38:33 --> Helper loaded: file_helper
DEBUG - 2021-08-10 20:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-10 20:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-10 20:38:33 --> Controller Class Initialized
INFO - 2021-08-10 20:38:33 --> Helper loaded: cookie_helper
INFO - 2021-08-10 20:38:33 --> Model "CookieModel" initialized
INFO - 2021-08-10 20:38:33 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-10 20:38:33 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-10 20:38:33 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-10 20:38:33 --> Final output sent to browser
DEBUG - 2021-08-10 20:38:33 --> Total execution time: 0.0319
INFO - 2021-08-10 20:39:00 --> Config Class Initialized
INFO - 2021-08-10 20:39:00 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:39:00 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:39:00 --> Utf8 Class Initialized
INFO - 2021-08-10 20:39:00 --> URI Class Initialized
DEBUG - 2021-08-10 20:39:00 --> No URI present. Default controller set.
INFO - 2021-08-10 20:39:00 --> Router Class Initialized
INFO - 2021-08-10 20:39:00 --> Output Class Initialized
INFO - 2021-08-10 20:39:00 --> Security Class Initialized
DEBUG - 2021-08-10 20:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:39:00 --> Input Class Initialized
INFO - 2021-08-10 20:39:00 --> Language Class Initialized
INFO - 2021-08-10 20:39:00 --> Loader Class Initialized
INFO - 2021-08-10 20:39:00 --> Helper loaded: url_helper
INFO - 2021-08-10 20:39:00 --> Helper loaded: file_helper
DEBUG - 2021-08-10 20:39:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-10 20:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-10 20:39:00 --> Controller Class Initialized
INFO - 2021-08-10 20:39:00 --> Helper loaded: cookie_helper
INFO - 2021-08-10 20:39:00 --> Model "CookieModel" initialized
INFO - 2021-08-10 20:39:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-10 20:39:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-10 20:39:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-10 20:39:00 --> Final output sent to browser
DEBUG - 2021-08-10 20:39:00 --> Total execution time: 0.0479
INFO - 2021-08-10 20:39:01 --> Config Class Initialized
INFO - 2021-08-10 20:39:01 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:39:01 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:39:01 --> Utf8 Class Initialized
INFO - 2021-08-10 20:39:01 --> URI Class Initialized
DEBUG - 2021-08-10 20:39:01 --> No URI present. Default controller set.
INFO - 2021-08-10 20:39:01 --> Router Class Initialized
INFO - 2021-08-10 20:39:01 --> Output Class Initialized
INFO - 2021-08-10 20:39:01 --> Security Class Initialized
DEBUG - 2021-08-10 20:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:39:01 --> Input Class Initialized
INFO - 2021-08-10 20:39:01 --> Language Class Initialized
INFO - 2021-08-10 20:39:01 --> Loader Class Initialized
INFO - 2021-08-10 20:39:01 --> Helper loaded: url_helper
INFO - 2021-08-10 20:39:01 --> Helper loaded: file_helper
DEBUG - 2021-08-10 20:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-10 20:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-10 20:39:01 --> Controller Class Initialized
INFO - 2021-08-10 20:39:01 --> Helper loaded: cookie_helper
INFO - 2021-08-10 20:39:01 --> Model "CookieModel" initialized
INFO - 2021-08-10 20:39:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-10 20:39:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-10 20:39:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-10 20:39:01 --> Final output sent to browser
DEBUG - 2021-08-10 20:39:01 --> Total execution time: 0.0312
INFO - 2021-08-10 20:39:19 --> Config Class Initialized
INFO - 2021-08-10 20:39:19 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:39:19 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:39:19 --> Utf8 Class Initialized
INFO - 2021-08-10 20:39:19 --> URI Class Initialized
DEBUG - 2021-08-10 20:39:19 --> No URI present. Default controller set.
INFO - 2021-08-10 20:39:19 --> Router Class Initialized
INFO - 2021-08-10 20:39:19 --> Output Class Initialized
INFO - 2021-08-10 20:39:19 --> Security Class Initialized
DEBUG - 2021-08-10 20:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:39:19 --> Input Class Initialized
INFO - 2021-08-10 20:39:19 --> Language Class Initialized
INFO - 2021-08-10 20:39:19 --> Loader Class Initialized
INFO - 2021-08-10 20:39:19 --> Helper loaded: url_helper
INFO - 2021-08-10 20:39:19 --> Helper loaded: file_helper
DEBUG - 2021-08-10 20:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-10 20:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-10 20:39:19 --> Controller Class Initialized
INFO - 2021-08-10 20:39:19 --> Helper loaded: cookie_helper
INFO - 2021-08-10 20:39:19 --> Model "CookieModel" initialized
INFO - 2021-08-10 20:39:19 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-10 20:39:19 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-10 20:39:19 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-10 20:39:19 --> Final output sent to browser
DEBUG - 2021-08-10 20:39:19 --> Total execution time: 0.0529
INFO - 2021-08-10 20:39:36 --> Config Class Initialized
INFO - 2021-08-10 20:39:36 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:39:36 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:39:36 --> Utf8 Class Initialized
INFO - 2021-08-10 20:39:36 --> URI Class Initialized
DEBUG - 2021-08-10 20:39:36 --> No URI present. Default controller set.
INFO - 2021-08-10 20:39:36 --> Router Class Initialized
INFO - 2021-08-10 20:39:36 --> Output Class Initialized
INFO - 2021-08-10 20:39:36 --> Security Class Initialized
DEBUG - 2021-08-10 20:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:39:36 --> Input Class Initialized
INFO - 2021-08-10 20:39:36 --> Language Class Initialized
INFO - 2021-08-10 20:39:36 --> Loader Class Initialized
INFO - 2021-08-10 20:39:36 --> Helper loaded: url_helper
INFO - 2021-08-10 20:39:36 --> Helper loaded: file_helper
DEBUG - 2021-08-10 20:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-10 20:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-10 20:39:36 --> Controller Class Initialized
INFO - 2021-08-10 20:39:36 --> Helper loaded: cookie_helper
INFO - 2021-08-10 20:39:36 --> Model "CookieModel" initialized
INFO - 2021-08-10 20:39:36 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-10 20:39:36 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-10 20:39:36 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-10 20:39:36 --> Final output sent to browser
DEBUG - 2021-08-10 20:39:36 --> Total execution time: 0.0410
INFO - 2021-08-10 20:40:04 --> Config Class Initialized
INFO - 2021-08-10 20:40:04 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:40:04 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:40:04 --> Utf8 Class Initialized
INFO - 2021-08-10 20:40:04 --> URI Class Initialized
INFO - 2021-08-10 20:40:04 --> Router Class Initialized
INFO - 2021-08-10 20:40:04 --> Output Class Initialized
INFO - 2021-08-10 20:40:04 --> Security Class Initialized
DEBUG - 2021-08-10 20:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:40:04 --> Input Class Initialized
INFO - 2021-08-10 20:40:04 --> Language Class Initialized
INFO - 2021-08-10 20:40:04 --> Loader Class Initialized
INFO - 2021-08-10 20:40:04 --> Helper loaded: url_helper
INFO - 2021-08-10 20:40:04 --> Helper loaded: file_helper
DEBUG - 2021-08-10 20:40:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-10 20:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-10 20:40:04 --> Controller Class Initialized
INFO - 2021-08-10 20:40:04 --> Helper loaded: cookie_helper
INFO - 2021-08-10 20:40:04 --> Model "CookieModel" initialized
INFO - 2021-08-10 20:40:04 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-10 20:40:04 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-10 20:40:04 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-10 20:40:04 --> Final output sent to browser
DEBUG - 2021-08-10 20:40:04 --> Total execution time: 0.0429
INFO - 2021-08-10 20:40:18 --> Config Class Initialized
INFO - 2021-08-10 20:40:18 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:40:18 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:40:18 --> Utf8 Class Initialized
INFO - 2021-08-10 20:40:18 --> URI Class Initialized
INFO - 2021-08-10 20:40:18 --> Router Class Initialized
INFO - 2021-08-10 20:40:18 --> Output Class Initialized
INFO - 2021-08-10 20:40:18 --> Security Class Initialized
DEBUG - 2021-08-10 20:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:40:18 --> Input Class Initialized
INFO - 2021-08-10 20:40:18 --> Language Class Initialized
INFO - 2021-08-10 20:40:18 --> Loader Class Initialized
INFO - 2021-08-10 20:40:18 --> Helper loaded: url_helper
INFO - 2021-08-10 20:40:18 --> Helper loaded: file_helper
DEBUG - 2021-08-10 20:40:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-10 20:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-10 20:40:18 --> Controller Class Initialized
INFO - 2021-08-10 20:40:18 --> Helper loaded: cookie_helper
INFO - 2021-08-10 20:40:18 --> Model "CookieModel" initialized
INFO - 2021-08-10 20:40:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-10 20:40:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/pilates.php
INFO - 2021-08-10 20:40:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-10 20:40:18 --> Final output sent to browser
DEBUG - 2021-08-10 20:40:18 --> Total execution time: 0.0330
INFO - 2021-08-10 20:40:20 --> Config Class Initialized
INFO - 2021-08-10 20:40:20 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:40:20 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:40:20 --> Utf8 Class Initialized
INFO - 2021-08-10 20:40:20 --> URI Class Initialized
DEBUG - 2021-08-10 20:40:20 --> No URI present. Default controller set.
INFO - 2021-08-10 20:40:20 --> Router Class Initialized
INFO - 2021-08-10 20:40:20 --> Output Class Initialized
INFO - 2021-08-10 20:40:20 --> Security Class Initialized
DEBUG - 2021-08-10 20:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:40:20 --> Input Class Initialized
INFO - 2021-08-10 20:40:20 --> Language Class Initialized
INFO - 2021-08-10 20:40:20 --> Loader Class Initialized
INFO - 2021-08-10 20:40:20 --> Helper loaded: url_helper
INFO - 2021-08-10 20:40:20 --> Helper loaded: file_helper
DEBUG - 2021-08-10 20:40:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-10 20:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-10 20:40:20 --> Controller Class Initialized
INFO - 2021-08-10 20:40:20 --> Helper loaded: cookie_helper
INFO - 2021-08-10 20:40:20 --> Model "CookieModel" initialized
INFO - 2021-08-10 20:40:20 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-10 20:40:20 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-10 20:40:20 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-10 20:40:20 --> Final output sent to browser
DEBUG - 2021-08-10 20:40:20 --> Total execution time: 0.0320
INFO - 2021-08-10 20:43:36 --> Config Class Initialized
INFO - 2021-08-10 20:43:36 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:43:36 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:43:36 --> Utf8 Class Initialized
INFO - 2021-08-10 20:43:36 --> URI Class Initialized
DEBUG - 2021-08-10 20:43:36 --> No URI present. Default controller set.
INFO - 2021-08-10 20:43:36 --> Router Class Initialized
INFO - 2021-08-10 20:43:36 --> Output Class Initialized
INFO - 2021-08-10 20:43:36 --> Security Class Initialized
DEBUG - 2021-08-10 20:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:43:36 --> Input Class Initialized
INFO - 2021-08-10 20:43:36 --> Language Class Initialized
INFO - 2021-08-10 20:43:36 --> Loader Class Initialized
INFO - 2021-08-10 20:43:36 --> Helper loaded: url_helper
INFO - 2021-08-10 20:43:36 --> Helper loaded: file_helper
DEBUG - 2021-08-10 20:43:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-10 20:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-10 20:43:36 --> Controller Class Initialized
INFO - 2021-08-10 20:43:36 --> Helper loaded: cookie_helper
INFO - 2021-08-10 20:43:36 --> Model "CookieModel" initialized
INFO - 2021-08-10 20:43:36 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-10 20:43:36 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-10 20:43:36 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-10 20:43:36 --> Final output sent to browser
DEBUG - 2021-08-10 20:43:36 --> Total execution time: 0.0459
INFO - 2021-08-10 20:43:51 --> Config Class Initialized
INFO - 2021-08-10 20:43:51 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:43:51 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:43:51 --> Utf8 Class Initialized
INFO - 2021-08-10 20:43:51 --> URI Class Initialized
DEBUG - 2021-08-10 20:43:51 --> No URI present. Default controller set.
INFO - 2021-08-10 20:43:51 --> Router Class Initialized
INFO - 2021-08-10 20:43:51 --> Output Class Initialized
INFO - 2021-08-10 20:43:51 --> Security Class Initialized
DEBUG - 2021-08-10 20:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:43:51 --> Input Class Initialized
INFO - 2021-08-10 20:43:51 --> Language Class Initialized
INFO - 2021-08-10 20:43:51 --> Loader Class Initialized
INFO - 2021-08-10 20:43:51 --> Helper loaded: url_helper
INFO - 2021-08-10 20:43:51 --> Helper loaded: file_helper
DEBUG - 2021-08-10 20:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-10 20:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-10 20:43:51 --> Controller Class Initialized
INFO - 2021-08-10 20:43:51 --> Helper loaded: cookie_helper
INFO - 2021-08-10 20:43:51 --> Model "CookieModel" initialized
INFO - 2021-08-10 20:43:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-10 20:43:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-10 20:43:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-10 20:43:51 --> Final output sent to browser
DEBUG - 2021-08-10 20:43:51 --> Total execution time: 0.0419
INFO - 2021-08-10 20:44:16 --> Config Class Initialized
INFO - 2021-08-10 20:44:16 --> Hooks Class Initialized
DEBUG - 2021-08-10 20:44:16 --> UTF-8 Support Enabled
INFO - 2021-08-10 20:44:16 --> Utf8 Class Initialized
INFO - 2021-08-10 20:44:16 --> URI Class Initialized
DEBUG - 2021-08-10 20:44:16 --> No URI present. Default controller set.
INFO - 2021-08-10 20:44:16 --> Router Class Initialized
INFO - 2021-08-10 20:44:16 --> Output Class Initialized
INFO - 2021-08-10 20:44:16 --> Security Class Initialized
DEBUG - 2021-08-10 20:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-10 20:44:16 --> Input Class Initialized
INFO - 2021-08-10 20:44:16 --> Language Class Initialized
INFO - 2021-08-10 20:44:16 --> Loader Class Initialized
INFO - 2021-08-10 20:44:16 --> Helper loaded: url_helper
INFO - 2021-08-10 20:44:16 --> Helper loaded: file_helper
DEBUG - 2021-08-10 20:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-10 20:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-10 20:44:16 --> Controller Class Initialized
INFO - 2021-08-10 20:44:16 --> Helper loaded: cookie_helper
INFO - 2021-08-10 20:44:16 --> Model "CookieModel" initialized
INFO - 2021-08-10 20:44:16 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-10 20:44:16 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-10 20:44:16 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-10 20:44:16 --> Final output sent to browser
DEBUG - 2021-08-10 20:44:16 --> Total execution time: 0.0333
