<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-09-25 09:41:13 --> Config Class Initialized
INFO - 2021-09-25 09:41:13 --> Hooks Class Initialized
DEBUG - 2021-09-25 09:41:13 --> UTF-8 Support Enabled
INFO - 2021-09-25 09:41:13 --> Utf8 Class Initialized
INFO - 2021-09-25 09:41:13 --> URI Class Initialized
INFO - 2021-09-25 09:41:13 --> Router Class Initialized
INFO - 2021-09-25 09:41:13 --> Output Class Initialized
INFO - 2021-09-25 09:41:13 --> Security Class Initialized
DEBUG - 2021-09-25 09:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 09:41:13 --> Input Class Initialized
INFO - 2021-09-25 09:41:13 --> Language Class Initialized
INFO - 2021-09-25 09:41:13 --> Loader Class Initialized
INFO - 2021-09-25 09:41:13 --> Helper loaded: url_helper
INFO - 2021-09-25 09:41:13 --> Helper loaded: file_helper
DEBUG - 2021-09-25 09:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-25 09:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-25 09:41:13 --> Controller Class Initialized
INFO - 2021-09-25 09:41:13 --> Database Driver Class Initialized
INFO - 2021-09-25 09:41:13 --> Model "BlogModel" initialized
INFO - 2021-09-25 09:41:13 --> Helper loaded: cookie_helper
INFO - 2021-09-25 09:41:13 --> Model "CookieModel" initialized
INFO - 2021-09-25 09:41:13 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-25 09:41:13 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-25 09:41:13 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-25 09:41:13 --> Final output sent to browser
DEBUG - 2021-09-25 09:41:13 --> Total execution time: 0.0718
INFO - 2021-09-25 09:41:20 --> Config Class Initialized
INFO - 2021-09-25 09:41:20 --> Hooks Class Initialized
DEBUG - 2021-09-25 09:41:20 --> UTF-8 Support Enabled
INFO - 2021-09-25 09:41:20 --> Utf8 Class Initialized
INFO - 2021-09-25 09:41:20 --> URI Class Initialized
INFO - 2021-09-25 09:41:20 --> Router Class Initialized
INFO - 2021-09-25 09:41:20 --> Output Class Initialized
INFO - 2021-09-25 09:41:20 --> Security Class Initialized
DEBUG - 2021-09-25 09:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 09:41:20 --> Input Class Initialized
INFO - 2021-09-25 09:41:20 --> Language Class Initialized
INFO - 2021-09-25 09:41:20 --> Loader Class Initialized
INFO - 2021-09-25 09:41:20 --> Helper loaded: url_helper
INFO - 2021-09-25 09:41:20 --> Helper loaded: file_helper
DEBUG - 2021-09-25 09:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-25 09:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-25 09:41:20 --> Controller Class Initialized
INFO - 2021-09-25 09:41:20 --> Database Driver Class Initialized
INFO - 2021-09-25 09:41:20 --> Model "BlogModel" initialized
INFO - 2021-09-25 09:41:20 --> Helper loaded: cookie_helper
INFO - 2021-09-25 09:41:20 --> Model "CookieModel" initialized
INFO - 2021-09-25 09:41:20 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-25 09:41:20 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-25 09:41:20 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-25 09:41:20 --> Final output sent to browser
DEBUG - 2021-09-25 09:41:20 --> Total execution time: 0.0466
INFO - 2021-09-25 09:41:24 --> Config Class Initialized
INFO - 2021-09-25 09:41:24 --> Hooks Class Initialized
DEBUG - 2021-09-25 09:41:24 --> UTF-8 Support Enabled
INFO - 2021-09-25 09:41:24 --> Utf8 Class Initialized
INFO - 2021-09-25 09:41:24 --> URI Class Initialized
INFO - 2021-09-25 09:41:24 --> Router Class Initialized
INFO - 2021-09-25 09:41:24 --> Output Class Initialized
INFO - 2021-09-25 09:41:24 --> Security Class Initialized
DEBUG - 2021-09-25 09:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 09:41:24 --> Input Class Initialized
INFO - 2021-09-25 09:41:24 --> Language Class Initialized
INFO - 2021-09-25 09:41:24 --> Loader Class Initialized
INFO - 2021-09-25 09:41:24 --> Helper loaded: url_helper
INFO - 2021-09-25 09:41:24 --> Helper loaded: file_helper
DEBUG - 2021-09-25 09:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-25 09:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-25 09:41:24 --> Controller Class Initialized
INFO - 2021-09-25 09:41:24 --> Helper loaded: cookie_helper
INFO - 2021-09-25 09:41:24 --> Model "CookieModel" initialized
INFO - 2021-09-25 09:41:24 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-25 09:41:24 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/team.php
INFO - 2021-09-25 09:41:24 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-25 09:41:24 --> Final output sent to browser
DEBUG - 2021-09-25 09:41:24 --> Total execution time: 0.0332
INFO - 2021-09-25 09:41:28 --> Config Class Initialized
INFO - 2021-09-25 09:41:28 --> Hooks Class Initialized
DEBUG - 2021-09-25 09:41:28 --> UTF-8 Support Enabled
INFO - 2021-09-25 09:41:28 --> Utf8 Class Initialized
INFO - 2021-09-25 09:41:28 --> URI Class Initialized
INFO - 2021-09-25 09:41:28 --> Router Class Initialized
INFO - 2021-09-25 09:41:28 --> Output Class Initialized
INFO - 2021-09-25 09:41:28 --> Security Class Initialized
DEBUG - 2021-09-25 09:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 09:41:28 --> Input Class Initialized
INFO - 2021-09-25 09:41:28 --> Language Class Initialized
INFO - 2021-09-25 09:41:28 --> Loader Class Initialized
INFO - 2021-09-25 09:41:28 --> Helper loaded: url_helper
INFO - 2021-09-25 09:41:28 --> Helper loaded: file_helper
DEBUG - 2021-09-25 09:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-25 09:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-25 09:41:28 --> Controller Class Initialized
INFO - 2021-09-25 09:41:28 --> Database Driver Class Initialized
INFO - 2021-09-25 09:41:28 --> Model "BlogModel" initialized
INFO - 2021-09-25 09:41:28 --> Helper loaded: cookie_helper
INFO - 2021-09-25 09:41:28 --> Model "CookieModel" initialized
INFO - 2021-09-25 09:41:28 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-25 09:41:28 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-25 09:41:28 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-25 09:41:28 --> Final output sent to browser
DEBUG - 2021-09-25 09:41:28 --> Total execution time: 0.0465
INFO - 2021-09-25 09:42:20 --> Config Class Initialized
INFO - 2021-09-25 09:42:20 --> Hooks Class Initialized
DEBUG - 2021-09-25 09:42:20 --> UTF-8 Support Enabled
INFO - 2021-09-25 09:42:20 --> Utf8 Class Initialized
INFO - 2021-09-25 09:42:20 --> URI Class Initialized
INFO - 2021-09-25 09:42:20 --> Router Class Initialized
INFO - 2021-09-25 09:42:20 --> Output Class Initialized
INFO - 2021-09-25 09:42:20 --> Security Class Initialized
DEBUG - 2021-09-25 09:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 09:42:20 --> Input Class Initialized
INFO - 2021-09-25 09:42:20 --> Language Class Initialized
INFO - 2021-09-25 09:42:20 --> Loader Class Initialized
INFO - 2021-09-25 09:42:20 --> Helper loaded: url_helper
INFO - 2021-09-25 09:42:20 --> Helper loaded: file_helper
DEBUG - 2021-09-25 09:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-25 09:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-25 09:42:20 --> Controller Class Initialized
INFO - 2021-09-25 09:42:20 --> Database Driver Class Initialized
INFO - 2021-09-25 09:42:20 --> Model "BlogModel" initialized
INFO - 2021-09-25 09:42:20 --> Helper loaded: cookie_helper
INFO - 2021-09-25 09:42:20 --> Model "CookieModel" initialized
INFO - 2021-09-25 09:42:20 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-25 09:42:20 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-25 09:42:20 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-25 09:42:20 --> Final output sent to browser
DEBUG - 2021-09-25 09:42:20 --> Total execution time: 0.0530
INFO - 2021-09-25 09:43:21 --> Config Class Initialized
INFO - 2021-09-25 09:43:21 --> Hooks Class Initialized
DEBUG - 2021-09-25 09:43:21 --> UTF-8 Support Enabled
INFO - 2021-09-25 09:43:21 --> Utf8 Class Initialized
INFO - 2021-09-25 09:43:21 --> URI Class Initialized
INFO - 2021-09-25 09:43:21 --> Router Class Initialized
INFO - 2021-09-25 09:43:21 --> Output Class Initialized
INFO - 2021-09-25 09:43:21 --> Security Class Initialized
DEBUG - 2021-09-25 09:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 09:43:21 --> Input Class Initialized
INFO - 2021-09-25 09:43:21 --> Language Class Initialized
INFO - 2021-09-25 09:43:21 --> Loader Class Initialized
INFO - 2021-09-25 09:43:21 --> Helper loaded: url_helper
INFO - 2021-09-25 09:43:21 --> Helper loaded: file_helper
DEBUG - 2021-09-25 09:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-25 09:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-25 09:43:21 --> Controller Class Initialized
INFO - 2021-09-25 09:43:21 --> Database Driver Class Initialized
INFO - 2021-09-25 09:43:21 --> Model "BlogModel" initialized
INFO - 2021-09-25 09:43:21 --> Helper loaded: cookie_helper
INFO - 2021-09-25 09:43:21 --> Model "CookieModel" initialized
INFO - 2021-09-25 09:43:21 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-25 09:43:21 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-25 09:43:21 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-25 09:43:21 --> Final output sent to browser
DEBUG - 2021-09-25 09:43:21 --> Total execution time: 0.0793
INFO - 2021-09-25 09:46:45 --> Config Class Initialized
INFO - 2021-09-25 09:46:45 --> Hooks Class Initialized
DEBUG - 2021-09-25 09:46:45 --> UTF-8 Support Enabled
INFO - 2021-09-25 09:46:45 --> Utf8 Class Initialized
INFO - 2021-09-25 09:46:45 --> URI Class Initialized
INFO - 2021-09-25 09:46:45 --> Router Class Initialized
INFO - 2021-09-25 09:46:45 --> Output Class Initialized
INFO - 2021-09-25 09:46:45 --> Security Class Initialized
DEBUG - 2021-09-25 09:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 09:46:45 --> Input Class Initialized
INFO - 2021-09-25 09:46:45 --> Language Class Initialized
INFO - 2021-09-25 09:46:45 --> Loader Class Initialized
INFO - 2021-09-25 09:46:45 --> Helper loaded: url_helper
INFO - 2021-09-25 09:46:45 --> Helper loaded: file_helper
DEBUG - 2021-09-25 09:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-25 09:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-25 09:46:45 --> Controller Class Initialized
INFO - 2021-09-25 09:46:45 --> Database Driver Class Initialized
INFO - 2021-09-25 09:46:45 --> Model "BlogModel" initialized
INFO - 2021-09-25 09:46:45 --> Helper loaded: cookie_helper
INFO - 2021-09-25 09:46:45 --> Model "CookieModel" initialized
INFO - 2021-09-25 09:46:45 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-25 09:46:45 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-25 09:46:45 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-25 09:46:45 --> Final output sent to browser
DEBUG - 2021-09-25 09:46:45 --> Total execution time: 0.0662
INFO - 2021-09-25 09:47:11 --> Config Class Initialized
INFO - 2021-09-25 09:47:11 --> Hooks Class Initialized
DEBUG - 2021-09-25 09:47:11 --> UTF-8 Support Enabled
INFO - 2021-09-25 09:47:11 --> Utf8 Class Initialized
INFO - 2021-09-25 09:47:11 --> URI Class Initialized
INFO - 2021-09-25 09:47:11 --> Router Class Initialized
INFO - 2021-09-25 09:47:11 --> Output Class Initialized
INFO - 2021-09-25 09:47:11 --> Security Class Initialized
DEBUG - 2021-09-25 09:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 09:47:11 --> Input Class Initialized
INFO - 2021-09-25 09:47:11 --> Language Class Initialized
INFO - 2021-09-25 09:47:11 --> Loader Class Initialized
INFO - 2021-09-25 09:47:11 --> Helper loaded: url_helper
INFO - 2021-09-25 09:47:11 --> Helper loaded: file_helper
DEBUG - 2021-09-25 09:47:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-25 09:47:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-25 09:47:11 --> Controller Class Initialized
INFO - 2021-09-25 09:47:11 --> Database Driver Class Initialized
INFO - 2021-09-25 09:47:11 --> Model "BlogModel" initialized
INFO - 2021-09-25 09:47:11 --> Helper loaded: cookie_helper
INFO - 2021-09-25 09:47:11 --> Model "CookieModel" initialized
INFO - 2021-09-25 09:47:11 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-25 09:47:11 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-25 09:47:11 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-25 09:47:11 --> Final output sent to browser
DEBUG - 2021-09-25 09:47:11 --> Total execution time: 0.0426
INFO - 2021-09-25 09:48:27 --> Config Class Initialized
INFO - 2021-09-25 09:48:27 --> Hooks Class Initialized
DEBUG - 2021-09-25 09:48:27 --> UTF-8 Support Enabled
INFO - 2021-09-25 09:48:27 --> Utf8 Class Initialized
INFO - 2021-09-25 09:48:27 --> URI Class Initialized
INFO - 2021-09-25 09:48:27 --> Router Class Initialized
INFO - 2021-09-25 09:48:27 --> Output Class Initialized
INFO - 2021-09-25 09:48:27 --> Security Class Initialized
DEBUG - 2021-09-25 09:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 09:48:27 --> Input Class Initialized
INFO - 2021-09-25 09:48:27 --> Language Class Initialized
INFO - 2021-09-25 09:48:27 --> Loader Class Initialized
INFO - 2021-09-25 09:48:27 --> Helper loaded: url_helper
INFO - 2021-09-25 09:48:27 --> Helper loaded: file_helper
DEBUG - 2021-09-25 09:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-25 09:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-25 09:48:27 --> Controller Class Initialized
INFO - 2021-09-25 09:48:27 --> Database Driver Class Initialized
INFO - 2021-09-25 09:48:27 --> Model "BlogModel" initialized
INFO - 2021-09-25 09:48:27 --> Helper loaded: cookie_helper
INFO - 2021-09-25 09:48:27 --> Model "CookieModel" initialized
INFO - 2021-09-25 09:48:27 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-25 09:48:27 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-25 09:48:27 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-25 09:48:27 --> Final output sent to browser
DEBUG - 2021-09-25 09:48:27 --> Total execution time: 0.0427
INFO - 2021-09-25 09:49:37 --> Config Class Initialized
INFO - 2021-09-25 09:49:37 --> Hooks Class Initialized
DEBUG - 2021-09-25 09:49:37 --> UTF-8 Support Enabled
INFO - 2021-09-25 09:49:37 --> Utf8 Class Initialized
INFO - 2021-09-25 09:49:37 --> URI Class Initialized
INFO - 2021-09-25 09:49:37 --> Router Class Initialized
INFO - 2021-09-25 09:49:37 --> Output Class Initialized
INFO - 2021-09-25 09:49:37 --> Security Class Initialized
DEBUG - 2021-09-25 09:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 09:49:37 --> Input Class Initialized
INFO - 2021-09-25 09:49:37 --> Language Class Initialized
INFO - 2021-09-25 09:49:37 --> Loader Class Initialized
INFO - 2021-09-25 09:49:37 --> Helper loaded: url_helper
INFO - 2021-09-25 09:49:37 --> Helper loaded: file_helper
DEBUG - 2021-09-25 09:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-25 09:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-25 09:49:37 --> Controller Class Initialized
INFO - 2021-09-25 09:49:37 --> Database Driver Class Initialized
INFO - 2021-09-25 09:49:37 --> Model "BlogModel" initialized
INFO - 2021-09-25 09:49:37 --> Helper loaded: cookie_helper
INFO - 2021-09-25 09:49:37 --> Model "CookieModel" initialized
INFO - 2021-09-25 09:49:37 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-25 09:49:37 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-25 09:49:37 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-25 09:49:37 --> Final output sent to browser
DEBUG - 2021-09-25 09:49:37 --> Total execution time: 0.0544
INFO - 2021-09-25 09:49:46 --> Config Class Initialized
INFO - 2021-09-25 09:49:46 --> Hooks Class Initialized
DEBUG - 2021-09-25 09:49:46 --> UTF-8 Support Enabled
INFO - 2021-09-25 09:49:46 --> Utf8 Class Initialized
INFO - 2021-09-25 09:49:46 --> URI Class Initialized
INFO - 2021-09-25 09:49:46 --> Router Class Initialized
INFO - 2021-09-25 09:49:46 --> Output Class Initialized
INFO - 2021-09-25 09:49:46 --> Security Class Initialized
DEBUG - 2021-09-25 09:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 09:49:46 --> Input Class Initialized
INFO - 2021-09-25 09:49:46 --> Language Class Initialized
INFO - 2021-09-25 09:49:46 --> Loader Class Initialized
INFO - 2021-09-25 09:49:46 --> Helper loaded: url_helper
INFO - 2021-09-25 09:49:46 --> Helper loaded: file_helper
DEBUG - 2021-09-25 09:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-25 09:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-25 09:49:46 --> Controller Class Initialized
INFO - 2021-09-25 09:49:46 --> Database Driver Class Initialized
INFO - 2021-09-25 09:49:46 --> Model "BlogModel" initialized
INFO - 2021-09-25 09:49:46 --> Helper loaded: cookie_helper
INFO - 2021-09-25 09:49:46 --> Model "CookieModel" initialized
INFO - 2021-09-25 09:49:46 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-25 09:49:46 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-25 09:49:46 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-25 09:49:46 --> Final output sent to browser
DEBUG - 2021-09-25 09:49:46 --> Total execution time: 0.0465
INFO - 2021-09-25 09:51:51 --> Config Class Initialized
INFO - 2021-09-25 09:51:51 --> Hooks Class Initialized
DEBUG - 2021-09-25 09:51:51 --> UTF-8 Support Enabled
INFO - 2021-09-25 09:51:51 --> Utf8 Class Initialized
INFO - 2021-09-25 09:51:51 --> URI Class Initialized
INFO - 2021-09-25 09:51:51 --> Router Class Initialized
INFO - 2021-09-25 09:51:51 --> Output Class Initialized
INFO - 2021-09-25 09:51:51 --> Security Class Initialized
DEBUG - 2021-09-25 09:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 09:51:51 --> Input Class Initialized
INFO - 2021-09-25 09:51:51 --> Language Class Initialized
INFO - 2021-09-25 09:51:51 --> Loader Class Initialized
INFO - 2021-09-25 09:51:51 --> Helper loaded: url_helper
INFO - 2021-09-25 09:51:51 --> Helper loaded: file_helper
DEBUG - 2021-09-25 09:51:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-25 09:51:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-25 09:51:51 --> Controller Class Initialized
INFO - 2021-09-25 09:51:51 --> Database Driver Class Initialized
INFO - 2021-09-25 09:51:51 --> Model "BlogModel" initialized
INFO - 2021-09-25 09:51:51 --> Helper loaded: cookie_helper
INFO - 2021-09-25 09:51:51 --> Model "CookieModel" initialized
INFO - 2021-09-25 09:51:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-25 09:51:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-25 09:51:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-25 09:51:51 --> Final output sent to browser
DEBUG - 2021-09-25 09:51:51 --> Total execution time: 0.0529
INFO - 2021-09-25 09:52:04 --> Config Class Initialized
INFO - 2021-09-25 09:52:04 --> Hooks Class Initialized
DEBUG - 2021-09-25 09:52:04 --> UTF-8 Support Enabled
INFO - 2021-09-25 09:52:04 --> Utf8 Class Initialized
INFO - 2021-09-25 09:52:04 --> URI Class Initialized
INFO - 2021-09-25 09:52:04 --> Router Class Initialized
INFO - 2021-09-25 09:52:04 --> Output Class Initialized
INFO - 2021-09-25 09:52:04 --> Security Class Initialized
DEBUG - 2021-09-25 09:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 09:52:04 --> Input Class Initialized
INFO - 2021-09-25 09:52:04 --> Language Class Initialized
INFO - 2021-09-25 09:52:04 --> Loader Class Initialized
INFO - 2021-09-25 09:52:04 --> Helper loaded: url_helper
INFO - 2021-09-25 09:52:04 --> Helper loaded: file_helper
DEBUG - 2021-09-25 09:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-25 09:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-25 09:52:04 --> Controller Class Initialized
INFO - 2021-09-25 09:52:04 --> Database Driver Class Initialized
INFO - 2021-09-25 09:52:04 --> Model "BlogModel" initialized
INFO - 2021-09-25 09:52:04 --> Helper loaded: cookie_helper
INFO - 2021-09-25 09:52:04 --> Model "CookieModel" initialized
INFO - 2021-09-25 09:52:04 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-25 09:52:04 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-25 09:52:04 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-25 09:52:04 --> Final output sent to browser
DEBUG - 2021-09-25 09:52:04 --> Total execution time: 0.0480
INFO - 2021-09-25 09:52:15 --> Config Class Initialized
INFO - 2021-09-25 09:52:15 --> Hooks Class Initialized
DEBUG - 2021-09-25 09:52:15 --> UTF-8 Support Enabled
INFO - 2021-09-25 09:52:15 --> Utf8 Class Initialized
INFO - 2021-09-25 09:52:15 --> URI Class Initialized
INFO - 2021-09-25 09:52:15 --> Router Class Initialized
INFO - 2021-09-25 09:52:15 --> Output Class Initialized
INFO - 2021-09-25 09:52:15 --> Security Class Initialized
DEBUG - 2021-09-25 09:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 09:52:15 --> Input Class Initialized
INFO - 2021-09-25 09:52:15 --> Language Class Initialized
INFO - 2021-09-25 09:52:15 --> Loader Class Initialized
INFO - 2021-09-25 09:52:15 --> Helper loaded: url_helper
INFO - 2021-09-25 09:52:15 --> Helper loaded: file_helper
DEBUG - 2021-09-25 09:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-25 09:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-25 09:52:15 --> Controller Class Initialized
INFO - 2021-09-25 09:52:15 --> Model "DBModel" initialized
DEBUG - 2021-09-25 09:52:15 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-25 09:52:15 --> Helper loaded: cookie_helper
INFO - 2021-09-25 09:52:15 --> Database Driver Class Initialized
INFO - 2021-09-25 09:52:15 --> Helper loaded: string_helper
INFO - 2021-09-25 09:52:15 --> Model "TestimonialModel" initialized
INFO - 2021-09-25 09:52:15 --> Model "BlogModel" initialized
INFO - 2021-09-25 09:52:15 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-25 09:52:15 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-25 09:52:15 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-25 09:52:15 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/blogs.php
INFO - 2021-09-25 09:52:15 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-25 09:52:15 --> Final output sent to browser
DEBUG - 2021-09-25 09:52:15 --> Total execution time: 0.0813
INFO - 2021-09-25 09:52:17 --> Config Class Initialized
INFO - 2021-09-25 09:52:17 --> Hooks Class Initialized
DEBUG - 2021-09-25 09:52:17 --> UTF-8 Support Enabled
INFO - 2021-09-25 09:52:17 --> Utf8 Class Initialized
INFO - 2021-09-25 09:52:17 --> URI Class Initialized
INFO - 2021-09-25 09:52:17 --> Router Class Initialized
INFO - 2021-09-25 09:52:17 --> Output Class Initialized
INFO - 2021-09-25 09:52:17 --> Security Class Initialized
DEBUG - 2021-09-25 09:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 09:52:17 --> Input Class Initialized
INFO - 2021-09-25 09:52:17 --> Language Class Initialized
INFO - 2021-09-25 09:52:17 --> Loader Class Initialized
INFO - 2021-09-25 09:52:17 --> Helper loaded: url_helper
INFO - 2021-09-25 09:52:17 --> Helper loaded: file_helper
DEBUG - 2021-09-25 09:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-25 09:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-25 09:52:17 --> Controller Class Initialized
INFO - 2021-09-25 09:52:17 --> Model "DBModel" initialized
DEBUG - 2021-09-25 09:52:17 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-25 09:52:17 --> Helper loaded: cookie_helper
INFO - 2021-09-25 09:52:17 --> Database Driver Class Initialized
INFO - 2021-09-25 09:52:17 --> Helper loaded: string_helper
INFO - 2021-09-25 09:52:17 --> Model "TestimonialModel" initialized
INFO - 2021-09-25 09:52:17 --> Model "BlogModel" initialized
INFO - 2021-09-25 09:52:17 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-25 09:52:17 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-25 09:52:17 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-25 09:52:17 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/blog.php
INFO - 2021-09-25 09:52:17 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-25 09:52:17 --> Final output sent to browser
DEBUG - 2021-09-25 09:52:17 --> Total execution time: 0.0472
INFO - 2021-09-25 09:52:25 --> Config Class Initialized
INFO - 2021-09-25 09:52:25 --> Hooks Class Initialized
DEBUG - 2021-09-25 09:52:25 --> UTF-8 Support Enabled
INFO - 2021-09-25 09:52:25 --> Utf8 Class Initialized
INFO - 2021-09-25 09:52:25 --> URI Class Initialized
INFO - 2021-09-25 09:52:25 --> Router Class Initialized
INFO - 2021-09-25 09:52:25 --> Output Class Initialized
INFO - 2021-09-25 09:52:25 --> Security Class Initialized
DEBUG - 2021-09-25 09:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 09:52:25 --> Input Class Initialized
INFO - 2021-09-25 09:52:25 --> Language Class Initialized
INFO - 2021-09-25 09:52:25 --> Loader Class Initialized
INFO - 2021-09-25 09:52:25 --> Helper loaded: url_helper
INFO - 2021-09-25 09:52:25 --> Helper loaded: file_helper
DEBUG - 2021-09-25 09:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-25 09:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-25 09:52:25 --> Controller Class Initialized
INFO - 2021-09-25 09:52:25 --> Model "DBModel" initialized
DEBUG - 2021-09-25 09:52:25 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-25 09:52:25 --> Helper loaded: cookie_helper
INFO - 2021-09-25 09:52:25 --> Database Driver Class Initialized
INFO - 2021-09-25 09:52:25 --> Helper loaded: string_helper
INFO - 2021-09-25 09:52:25 --> Model "TestimonialModel" initialized
INFO - 2021-09-25 09:52:25 --> Model "BlogModel" initialized
INFO - 2021-09-25 09:52:25 --> Config Class Initialized
INFO - 2021-09-25 09:52:25 --> Hooks Class Initialized
DEBUG - 2021-09-25 09:52:25 --> UTF-8 Support Enabled
INFO - 2021-09-25 09:52:25 --> Utf8 Class Initialized
INFO - 2021-09-25 09:52:25 --> URI Class Initialized
INFO - 2021-09-25 09:52:25 --> Router Class Initialized
INFO - 2021-09-25 09:52:25 --> Output Class Initialized
INFO - 2021-09-25 09:52:25 --> Security Class Initialized
DEBUG - 2021-09-25 09:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 09:52:25 --> Input Class Initialized
INFO - 2021-09-25 09:52:25 --> Language Class Initialized
INFO - 2021-09-25 09:52:25 --> Loader Class Initialized
INFO - 2021-09-25 09:52:25 --> Helper loaded: url_helper
INFO - 2021-09-25 09:52:25 --> Helper loaded: file_helper
DEBUG - 2021-09-25 09:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-25 09:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-25 09:52:25 --> Controller Class Initialized
INFO - 2021-09-25 09:52:25 --> Model "DBModel" initialized
DEBUG - 2021-09-25 09:52:25 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-25 09:52:25 --> Helper loaded: cookie_helper
INFO - 2021-09-25 09:52:25 --> Database Driver Class Initialized
INFO - 2021-09-25 09:52:25 --> Helper loaded: string_helper
INFO - 2021-09-25 09:52:25 --> Model "TestimonialModel" initialized
INFO - 2021-09-25 09:52:25 --> Model "BlogModel" initialized
INFO - 2021-09-25 09:52:25 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-25 09:52:25 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-25 09:52:25 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-25 09:52:25 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/blogs.php
INFO - 2021-09-25 09:52:25 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-25 09:52:25 --> Final output sent to browser
DEBUG - 2021-09-25 09:52:25 --> Total execution time: 0.0493
INFO - 2021-09-25 09:52:27 --> Config Class Initialized
INFO - 2021-09-25 09:52:27 --> Hooks Class Initialized
DEBUG - 2021-09-25 09:52:27 --> UTF-8 Support Enabled
INFO - 2021-09-25 09:52:27 --> Utf8 Class Initialized
INFO - 2021-09-25 09:52:27 --> URI Class Initialized
INFO - 2021-09-25 09:52:27 --> Router Class Initialized
INFO - 2021-09-25 09:52:27 --> Output Class Initialized
INFO - 2021-09-25 09:52:27 --> Security Class Initialized
DEBUG - 2021-09-25 09:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 09:52:27 --> Input Class Initialized
INFO - 2021-09-25 09:52:27 --> Language Class Initialized
INFO - 2021-09-25 09:52:27 --> Loader Class Initialized
INFO - 2021-09-25 09:52:27 --> Helper loaded: url_helper
INFO - 2021-09-25 09:52:27 --> Helper loaded: file_helper
DEBUG - 2021-09-25 09:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-25 09:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-25 09:52:27 --> Controller Class Initialized
INFO - 2021-09-25 09:52:27 --> Database Driver Class Initialized
INFO - 2021-09-25 09:52:27 --> Model "BlogModel" initialized
INFO - 2021-09-25 09:52:27 --> Helper loaded: cookie_helper
INFO - 2021-09-25 09:52:27 --> Model "CookieModel" initialized
INFO - 2021-09-25 09:52:27 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-25 09:52:27 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-25 09:52:27 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-25 09:52:27 --> Final output sent to browser
DEBUG - 2021-09-25 09:52:27 --> Total execution time: 0.0450
INFO - 2021-09-25 09:53:00 --> Config Class Initialized
INFO - 2021-09-25 09:53:00 --> Hooks Class Initialized
DEBUG - 2021-09-25 09:53:00 --> UTF-8 Support Enabled
INFO - 2021-09-25 09:53:00 --> Utf8 Class Initialized
INFO - 2021-09-25 09:53:00 --> URI Class Initialized
INFO - 2021-09-25 09:53:00 --> Router Class Initialized
INFO - 2021-09-25 09:53:00 --> Output Class Initialized
INFO - 2021-09-25 09:53:00 --> Security Class Initialized
DEBUG - 2021-09-25 09:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 09:53:00 --> Input Class Initialized
INFO - 2021-09-25 09:53:00 --> Language Class Initialized
INFO - 2021-09-25 09:53:00 --> Loader Class Initialized
INFO - 2021-09-25 09:53:00 --> Helper loaded: url_helper
INFO - 2021-09-25 09:53:00 --> Helper loaded: file_helper
DEBUG - 2021-09-25 09:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-25 09:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-25 09:53:00 --> Controller Class Initialized
INFO - 2021-09-25 09:53:00 --> Database Driver Class Initialized
INFO - 2021-09-25 09:53:00 --> Model "BlogModel" initialized
INFO - 2021-09-25 09:53:00 --> Helper loaded: cookie_helper
INFO - 2021-09-25 09:53:00 --> Model "CookieModel" initialized
INFO - 2021-09-25 09:53:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-25 09:53:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-25 09:53:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-25 09:53:00 --> Final output sent to browser
DEBUG - 2021-09-25 09:53:00 --> Total execution time: 0.0501
INFO - 2021-09-25 09:53:15 --> Config Class Initialized
INFO - 2021-09-25 09:53:15 --> Hooks Class Initialized
DEBUG - 2021-09-25 09:53:15 --> UTF-8 Support Enabled
INFO - 2021-09-25 09:53:15 --> Utf8 Class Initialized
INFO - 2021-09-25 09:53:15 --> URI Class Initialized
INFO - 2021-09-25 09:53:15 --> Router Class Initialized
INFO - 2021-09-25 09:53:15 --> Output Class Initialized
INFO - 2021-09-25 09:53:15 --> Security Class Initialized
DEBUG - 2021-09-25 09:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 09:53:15 --> Input Class Initialized
INFO - 2021-09-25 09:53:15 --> Language Class Initialized
INFO - 2021-09-25 09:53:15 --> Loader Class Initialized
INFO - 2021-09-25 09:53:15 --> Helper loaded: url_helper
INFO - 2021-09-25 09:53:15 --> Helper loaded: file_helper
DEBUG - 2021-09-25 09:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-25 09:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-25 09:53:15 --> Controller Class Initialized
INFO - 2021-09-25 09:53:15 --> Database Driver Class Initialized
INFO - 2021-09-25 09:53:15 --> Model "BlogModel" initialized
INFO - 2021-09-25 09:53:15 --> Helper loaded: cookie_helper
INFO - 2021-09-25 09:53:15 --> Model "CookieModel" initialized
INFO - 2021-09-25 09:53:15 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-25 09:53:15 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blog.php
INFO - 2021-09-25 09:53:15 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-25 09:53:15 --> Final output sent to browser
DEBUG - 2021-09-25 09:53:15 --> Total execution time: 0.0447
INFO - 2021-09-25 09:56:43 --> Config Class Initialized
INFO - 2021-09-25 09:56:43 --> Hooks Class Initialized
DEBUG - 2021-09-25 09:56:43 --> UTF-8 Support Enabled
INFO - 2021-09-25 09:56:43 --> Utf8 Class Initialized
INFO - 2021-09-25 09:56:43 --> URI Class Initialized
INFO - 2021-09-25 09:56:43 --> Router Class Initialized
INFO - 2021-09-25 09:56:43 --> Output Class Initialized
INFO - 2021-09-25 09:56:43 --> Security Class Initialized
DEBUG - 2021-09-25 09:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 09:56:43 --> Input Class Initialized
INFO - 2021-09-25 09:56:43 --> Language Class Initialized
INFO - 2021-09-25 09:56:43 --> Loader Class Initialized
INFO - 2021-09-25 09:56:43 --> Helper loaded: url_helper
INFO - 2021-09-25 09:56:43 --> Helper loaded: file_helper
DEBUG - 2021-09-25 09:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-25 09:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-25 09:56:43 --> Controller Class Initialized
INFO - 2021-09-25 09:56:43 --> Database Driver Class Initialized
INFO - 2021-09-25 09:56:43 --> Model "BlogModel" initialized
INFO - 2021-09-25 09:56:43 --> Helper loaded: cookie_helper
INFO - 2021-09-25 09:56:43 --> Model "CookieModel" initialized
INFO - 2021-09-25 09:56:43 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-25 09:56:43 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blog.php
INFO - 2021-09-25 09:56:43 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-25 09:56:43 --> Final output sent to browser
DEBUG - 2021-09-25 09:56:43 --> Total execution time: 0.0571
INFO - 2021-09-25 09:56:43 --> Config Class Initialized
INFO - 2021-09-25 09:56:43 --> Hooks Class Initialized
INFO - 2021-09-25 09:56:43 --> Config Class Initialized
INFO - 2021-09-25 09:56:43 --> Hooks Class Initialized
DEBUG - 2021-09-25 09:56:43 --> UTF-8 Support Enabled
INFO - 2021-09-25 09:56:43 --> Utf8 Class Initialized
INFO - 2021-09-25 09:56:43 --> URI Class Initialized
DEBUG - 2021-09-25 09:56:43 --> UTF-8 Support Enabled
INFO - 2021-09-25 09:56:43 --> Utf8 Class Initialized
INFO - 2021-09-25 09:56:43 --> Router Class Initialized
INFO - 2021-09-25 09:56:43 --> Output Class Initialized
INFO - 2021-09-25 09:56:43 --> URI Class Initialized
INFO - 2021-09-25 09:56:43 --> Security Class Initialized
INFO - 2021-09-25 09:56:43 --> Router Class Initialized
DEBUG - 2021-09-25 09:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 09:56:43 --> Input Class Initialized
INFO - 2021-09-25 09:56:43 --> Config Class Initialized
INFO - 2021-09-25 09:56:43 --> Hooks Class Initialized
INFO - 2021-09-25 09:56:43 --> Language Class Initialized
INFO - 2021-09-25 09:56:43 --> Output Class Initialized
INFO - 2021-09-25 09:56:43 --> Security Class Initialized
DEBUG - 2021-09-25 09:56:43 --> UTF-8 Support Enabled
INFO - 2021-09-25 09:56:43 --> Utf8 Class Initialized
DEBUG - 2021-09-25 09:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 09:56:43 --> Input Class Initialized
INFO - 2021-09-25 09:56:43 --> Loader Class Initialized
INFO - 2021-09-25 09:56:43 --> Language Class Initialized
INFO - 2021-09-25 09:56:43 --> URI Class Initialized
INFO - 2021-09-25 09:56:43 --> Helper loaded: url_helper
INFO - 2021-09-25 09:56:43 --> Router Class Initialized
INFO - 2021-09-25 09:56:43 --> Helper loaded: file_helper
INFO - 2021-09-25 09:56:43 --> Loader Class Initialized
INFO - 2021-09-25 09:56:43 --> Config Class Initialized
INFO - 2021-09-25 09:56:43 --> Hooks Class Initialized
INFO - 2021-09-25 09:56:43 --> Output Class Initialized
INFO - 2021-09-25 09:56:43 --> Helper loaded: url_helper
INFO - 2021-09-25 09:56:43 --> Helper loaded: file_helper
INFO - 2021-09-25 09:56:43 --> Security Class Initialized
DEBUG - 2021-09-25 09:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-25 09:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-25 09:56:43 --> Controller Class Initialized
DEBUG - 2021-09-25 09:56:43 --> UTF-8 Support Enabled
INFO - 2021-09-25 09:56:43 --> Utf8 Class Initialized
DEBUG - 2021-09-25 09:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 09:56:43 --> Input Class Initialized
DEBUG - 2021-09-25 09:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-25 09:56:43 --> URI Class Initialized
INFO - 2021-09-25 09:56:43 --> Language Class Initialized
INFO - 2021-09-25 09:56:43 --> Router Class Initialized
INFO - 2021-09-25 09:56:43 --> Loader Class Initialized
INFO - 2021-09-25 09:56:43 --> Database Driver Class Initialized
INFO - 2021-09-25 09:56:43 --> Helper loaded: url_helper
INFO - 2021-09-25 09:56:43 --> Output Class Initialized
INFO - 2021-09-25 09:56:43 --> Model "BlogModel" initialized
INFO - 2021-09-25 09:56:43 --> Helper loaded: file_helper
INFO - 2021-09-25 09:56:43 --> Helper loaded: cookie_helper
INFO - 2021-09-25 09:56:43 --> Model "CookieModel" initialized
INFO - 2021-09-25 09:56:43 --> Security Class Initialized
INFO - 2021-09-25 09:56:43 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-25 09:56:43 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blog.php
INFO - 2021-09-25 09:56:43 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-25 09:56:43 --> Final output sent to browser
DEBUG - 2021-09-25 09:56:43 --> Total execution time: 0.0582
DEBUG - 2021-09-25 09:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-25 09:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-25 09:56:43 --> Controller Class Initialized
DEBUG - 2021-09-25 09:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 09:56:43 --> Input Class Initialized
INFO - 2021-09-25 09:56:43 --> Config Class Initialized
INFO - 2021-09-25 09:56:43 --> Hooks Class Initialized
INFO - 2021-09-25 09:56:43 --> Config Class Initialized
INFO - 2021-09-25 09:56:43 --> Hooks Class Initialized
INFO - 2021-09-25 09:56:43 --> Language Class Initialized
DEBUG - 2021-09-25 09:56:43 --> UTF-8 Support Enabled
DEBUG - 2021-09-25 09:56:43 --> UTF-8 Support Enabled
INFO - 2021-09-25 09:56:43 --> Utf8 Class Initialized
INFO - 2021-09-25 09:56:43 --> Utf8 Class Initialized
INFO - 2021-09-25 09:56:43 --> URI Class Initialized
INFO - 2021-09-25 09:56:43 --> URI Class Initialized
INFO - 2021-09-25 09:56:43 --> Router Class Initialized
INFO - 2021-09-25 09:56:43 --> Router Class Initialized
INFO - 2021-09-25 09:56:43 --> Database Driver Class Initialized
INFO - 2021-09-25 09:56:43 --> Model "BlogModel" initialized
INFO - 2021-09-25 09:56:43 --> Output Class Initialized
INFO - 2021-09-25 09:56:43 --> Helper loaded: cookie_helper
INFO - 2021-09-25 09:56:43 --> Output Class Initialized
INFO - 2021-09-25 09:56:43 --> Model "CookieModel" initialized
INFO - 2021-09-25 09:56:43 --> Security Class Initialized
INFO - 2021-09-25 09:56:43 --> Loader Class Initialized
INFO - 2021-09-25 09:56:43 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-25 09:56:43 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blog.php
INFO - 2021-09-25 09:56:43 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-25 09:56:43 --> Helper loaded: url_helper
INFO - 2021-09-25 09:56:43 --> Final output sent to browser
DEBUG - 2021-09-25 09:56:43 --> Total execution time: 0.0813
DEBUG - 2021-09-25 09:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 09:56:43 --> Input Class Initialized
INFO - 2021-09-25 09:56:43 --> Security Class Initialized
INFO - 2021-09-25 09:56:43 --> Language Class Initialized
INFO - 2021-09-25 09:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-25 09:56:43 --> Controller Class Initialized
DEBUG - 2021-09-25 09:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 09:56:43 --> Helper loaded: file_helper
INFO - 2021-09-25 09:56:43 --> Loader Class Initialized
INFO - 2021-09-25 09:56:43 --> Input Class Initialized
INFO - 2021-09-25 09:56:43 --> Helper loaded: url_helper
INFO - 2021-09-25 09:56:43 --> Language Class Initialized
DEBUG - 2021-09-25 09:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-25 09:56:43 --> Database Driver Class Initialized
INFO - 2021-09-25 09:56:43 --> Model "BlogModel" initialized
INFO - 2021-09-25 09:56:43 --> Helper loaded: cookie_helper
INFO - 2021-09-25 09:56:44 --> Model "CookieModel" initialized
INFO - 2021-09-25 09:56:44 --> Helper loaded: file_helper
INFO - 2021-09-25 09:56:44 --> Loader Class Initialized
INFO - 2021-09-25 09:56:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-25 09:56:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blog.php
INFO - 2021-09-25 09:56:44 --> Helper loaded: url_helper
DEBUG - 2021-09-25 09:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-25 09:56:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-25 09:56:44 --> Final output sent to browser
DEBUG - 2021-09-25 09:56:44 --> Total execution time: 0.1020
INFO - 2021-09-25 09:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-25 09:56:44 --> Controller Class Initialized
INFO - 2021-09-25 09:56:44 --> Helper loaded: file_helper
DEBUG - 2021-09-25 09:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-25 09:56:44 --> Config Class Initialized
INFO - 2021-09-25 09:56:44 --> Hooks Class Initialized
INFO - 2021-09-25 09:56:44 --> Config Class Initialized
INFO - 2021-09-25 09:56:44 --> Hooks Class Initialized
INFO - 2021-09-25 09:56:44 --> Config Class Initialized
INFO - 2021-09-25 09:56:44 --> Hooks Class Initialized
DEBUG - 2021-09-25 09:56:44 --> UTF-8 Support Enabled
INFO - 2021-09-25 09:56:44 --> Utf8 Class Initialized
DEBUG - 2021-09-25 09:56:44 --> UTF-8 Support Enabled
INFO - 2021-09-25 09:56:44 --> Utf8 Class Initialized
INFO - 2021-09-25 09:56:44 --> URI Class Initialized
INFO - 2021-09-25 09:56:44 --> URI Class Initialized
INFO - 2021-09-25 09:56:44 --> Router Class Initialized
INFO - 2021-09-25 09:56:44 --> Router Class Initialized
INFO - 2021-09-25 09:56:44 --> Output Class Initialized
INFO - 2021-09-25 09:56:44 --> Output Class Initialized
INFO - 2021-09-25 09:56:44 --> Security Class Initialized
INFO - 2021-09-25 09:56:44 --> Security Class Initialized
DEBUG - 2021-09-25 09:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 09:56:44 --> Input Class Initialized
DEBUG - 2021-09-25 09:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 09:56:44 --> Input Class Initialized
INFO - 2021-09-25 09:56:44 --> Language Class Initialized
INFO - 2021-09-25 09:56:44 --> Language Class Initialized
DEBUG - 2021-09-25 09:56:44 --> UTF-8 Support Enabled
INFO - 2021-09-25 09:56:44 --> Utf8 Class Initialized
INFO - 2021-09-25 09:56:44 --> Loader Class Initialized
INFO - 2021-09-25 09:56:44 --> Loader Class Initialized
INFO - 2021-09-25 09:56:44 --> URI Class Initialized
INFO - 2021-09-25 09:56:44 --> Helper loaded: url_helper
INFO - 2021-09-25 09:56:44 --> Helper loaded: url_helper
INFO - 2021-09-25 09:56:44 --> Router Class Initialized
INFO - 2021-09-25 09:56:44 --> Helper loaded: file_helper
INFO - 2021-09-25 09:56:44 --> Helper loaded: file_helper
INFO - 2021-09-25 09:56:44 --> Output Class Initialized
INFO - 2021-09-25 09:56:44 --> Security Class Initialized
DEBUG - 2021-09-25 09:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-09-25 09:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-09-25 09:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 09:56:44 --> Input Class Initialized
INFO - 2021-09-25 09:56:44 --> Language Class Initialized
INFO - 2021-09-25 09:56:44 --> Loader Class Initialized
INFO - 2021-09-25 09:56:44 --> Database Driver Class Initialized
INFO - 2021-09-25 09:56:44 --> Helper loaded: url_helper
INFO - 2021-09-25 09:56:44 --> Model "BlogModel" initialized
INFO - 2021-09-25 09:56:44 --> Helper loaded: file_helper
INFO - 2021-09-25 09:56:44 --> Helper loaded: cookie_helper
INFO - 2021-09-25 09:56:44 --> Model "CookieModel" initialized
DEBUG - 2021-09-25 09:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-25 09:56:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-25 09:56:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blog.php
INFO - 2021-09-25 09:56:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-25 09:56:44 --> Final output sent to browser
DEBUG - 2021-09-25 09:56:44 --> Total execution time: 0.1795
INFO - 2021-09-25 09:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-25 09:56:44 --> Controller Class Initialized
INFO - 2021-09-25 09:56:44 --> Config Class Initialized
INFO - 2021-09-25 09:56:44 --> Hooks Class Initialized
INFO - 2021-09-25 09:56:44 --> Database Driver Class Initialized
DEBUG - 2021-09-25 09:56:44 --> UTF-8 Support Enabled
INFO - 2021-09-25 09:56:44 --> Utf8 Class Initialized
INFO - 2021-09-25 09:56:44 --> Model "BlogModel" initialized
INFO - 2021-09-25 09:56:44 --> Helper loaded: cookie_helper
INFO - 2021-09-25 09:56:44 --> Model "CookieModel" initialized
INFO - 2021-09-25 09:56:44 --> URI Class Initialized
INFO - 2021-09-25 09:56:44 --> Router Class Initialized
INFO - 2021-09-25 09:56:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-25 09:56:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blog.php
INFO - 2021-09-25 09:56:44 --> Output Class Initialized
INFO - 2021-09-25 09:56:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-25 09:56:44 --> Final output sent to browser
DEBUG - 2021-09-25 09:56:44 --> Total execution time: 0.1810
INFO - 2021-09-25 09:56:44 --> Security Class Initialized
INFO - 2021-09-25 09:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-25 09:56:44 --> Controller Class Initialized
DEBUG - 2021-09-25 09:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 09:56:44 --> Input Class Initialized
INFO - 2021-09-25 09:56:44 --> Language Class Initialized
INFO - 2021-09-25 09:56:44 --> Loader Class Initialized
INFO - 2021-09-25 09:56:44 --> Helper loaded: url_helper
INFO - 2021-09-25 09:56:44 --> Helper loaded: file_helper
DEBUG - 2021-09-25 09:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-25 09:56:44 --> Database Driver Class Initialized
INFO - 2021-09-25 09:56:44 --> Model "BlogModel" initialized
INFO - 2021-09-25 09:56:44 --> Helper loaded: cookie_helper
INFO - 2021-09-25 09:56:44 --> Model "CookieModel" initialized
INFO - 2021-09-25 09:56:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-25 09:56:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blog.php
INFO - 2021-09-25 09:56:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-25 09:56:44 --> Final output sent to browser
DEBUG - 2021-09-25 09:56:44 --> Total execution time: 0.2191
INFO - 2021-09-25 09:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-25 09:56:44 --> Controller Class Initialized
INFO - 2021-09-25 09:56:44 --> Database Driver Class Initialized
INFO - 2021-09-25 09:56:44 --> Model "BlogModel" initialized
INFO - 2021-09-25 09:56:44 --> Helper loaded: cookie_helper
INFO - 2021-09-25 09:56:44 --> Model "CookieModel" initialized
INFO - 2021-09-25 09:56:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-25 09:56:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blog.php
INFO - 2021-09-25 09:56:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-25 09:56:44 --> Final output sent to browser
DEBUG - 2021-09-25 09:56:44 --> Total execution time: 0.1595
INFO - 2021-09-25 09:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-25 09:56:44 --> Controller Class Initialized
INFO - 2021-09-25 09:56:44 --> Database Driver Class Initialized
INFO - 2021-09-25 09:56:44 --> Model "BlogModel" initialized
INFO - 2021-09-25 09:56:44 --> Helper loaded: cookie_helper
INFO - 2021-09-25 09:56:44 --> Model "CookieModel" initialized
INFO - 2021-09-25 09:56:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-25 09:56:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blog.php
INFO - 2021-09-25 09:56:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-25 09:56:44 --> Final output sent to browser
DEBUG - 2021-09-25 09:56:44 --> Total execution time: 0.1840
INFO - 2021-09-25 09:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-25 09:56:44 --> Controller Class Initialized
INFO - 2021-09-25 09:56:44 --> Database Driver Class Initialized
INFO - 2021-09-25 09:56:44 --> Model "BlogModel" initialized
INFO - 2021-09-25 09:56:44 --> Helper loaded: cookie_helper
INFO - 2021-09-25 09:56:44 --> Model "CookieModel" initialized
INFO - 2021-09-25 09:56:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-25 09:56:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blog.php
INFO - 2021-09-25 09:56:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-25 09:56:44 --> Final output sent to browser
DEBUG - 2021-09-25 09:56:44 --> Total execution time: 0.2091
INFO - 2021-09-25 09:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-25 09:56:44 --> Controller Class Initialized
INFO - 2021-09-25 09:56:44 --> Database Driver Class Initialized
INFO - 2021-09-25 09:56:44 --> Model "BlogModel" initialized
INFO - 2021-09-25 09:56:44 --> Helper loaded: cookie_helper
INFO - 2021-09-25 09:56:44 --> Model "CookieModel" initialized
INFO - 2021-09-25 09:56:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-25 09:56:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blog.php
INFO - 2021-09-25 09:56:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-25 09:56:44 --> Final output sent to browser
DEBUG - 2021-09-25 09:56:44 --> Total execution time: 0.1658
INFO - 2021-09-25 10:00:12 --> Config Class Initialized
INFO - 2021-09-25 10:00:12 --> Hooks Class Initialized
DEBUG - 2021-09-25 10:00:12 --> UTF-8 Support Enabled
INFO - 2021-09-25 10:00:12 --> Utf8 Class Initialized
INFO - 2021-09-25 10:00:12 --> URI Class Initialized
INFO - 2021-09-25 10:00:12 --> Router Class Initialized
INFO - 2021-09-25 10:00:12 --> Output Class Initialized
INFO - 2021-09-25 10:00:12 --> Security Class Initialized
DEBUG - 2021-09-25 10:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 10:00:12 --> Input Class Initialized
INFO - 2021-09-25 10:00:12 --> Language Class Initialized
INFO - 2021-09-25 10:00:12 --> Loader Class Initialized
INFO - 2021-09-25 10:00:12 --> Helper loaded: url_helper
INFO - 2021-09-25 10:00:12 --> Helper loaded: file_helper
DEBUG - 2021-09-25 10:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-25 10:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-25 10:00:12 --> Controller Class Initialized
INFO - 2021-09-25 10:00:12 --> Database Driver Class Initialized
INFO - 2021-09-25 10:00:12 --> Model "BlogModel" initialized
INFO - 2021-09-25 10:00:12 --> Helper loaded: cookie_helper
INFO - 2021-09-25 10:00:12 --> Model "CookieModel" initialized
INFO - 2021-09-25 10:00:12 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-25 10:00:12 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blog.php
INFO - 2021-09-25 10:00:12 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-25 10:00:12 --> Final output sent to browser
DEBUG - 2021-09-25 10:00:12 --> Total execution time: 0.0578
INFO - 2021-09-25 10:00:24 --> Config Class Initialized
INFO - 2021-09-25 10:00:24 --> Hooks Class Initialized
DEBUG - 2021-09-25 10:00:24 --> UTF-8 Support Enabled
INFO - 2021-09-25 10:00:24 --> Utf8 Class Initialized
INFO - 2021-09-25 10:00:24 --> URI Class Initialized
INFO - 2021-09-25 10:00:24 --> Router Class Initialized
INFO - 2021-09-25 10:00:24 --> Output Class Initialized
INFO - 2021-09-25 10:00:24 --> Security Class Initialized
DEBUG - 2021-09-25 10:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 10:00:24 --> Input Class Initialized
INFO - 2021-09-25 10:00:24 --> Language Class Initialized
INFO - 2021-09-25 10:00:24 --> Loader Class Initialized
INFO - 2021-09-25 10:00:24 --> Helper loaded: url_helper
INFO - 2021-09-25 10:00:24 --> Helper loaded: file_helper
DEBUG - 2021-09-25 10:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-25 10:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-25 10:00:24 --> Controller Class Initialized
INFO - 2021-09-25 10:00:24 --> Database Driver Class Initialized
INFO - 2021-09-25 10:00:24 --> Model "BlogModel" initialized
INFO - 2021-09-25 10:00:24 --> Helper loaded: cookie_helper
INFO - 2021-09-25 10:00:24 --> Model "CookieModel" initialized
INFO - 2021-09-25 10:00:24 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-25 10:00:24 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blog.php
INFO - 2021-09-25 10:00:24 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-25 10:00:24 --> Final output sent to browser
DEBUG - 2021-09-25 10:00:24 --> Total execution time: 0.0504
INFO - 2021-09-25 10:00:44 --> Config Class Initialized
INFO - 2021-09-25 10:00:44 --> Hooks Class Initialized
DEBUG - 2021-09-25 10:00:44 --> UTF-8 Support Enabled
INFO - 2021-09-25 10:00:44 --> Utf8 Class Initialized
INFO - 2021-09-25 10:00:44 --> URI Class Initialized
INFO - 2021-09-25 10:00:44 --> Router Class Initialized
INFO - 2021-09-25 10:00:44 --> Output Class Initialized
INFO - 2021-09-25 10:00:44 --> Security Class Initialized
DEBUG - 2021-09-25 10:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 10:00:44 --> Input Class Initialized
INFO - 2021-09-25 10:00:44 --> Language Class Initialized
INFO - 2021-09-25 10:00:44 --> Loader Class Initialized
INFO - 2021-09-25 10:00:44 --> Helper loaded: url_helper
INFO - 2021-09-25 10:00:44 --> Helper loaded: file_helper
DEBUG - 2021-09-25 10:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-25 10:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-25 10:00:44 --> Controller Class Initialized
INFO - 2021-09-25 10:00:44 --> Database Driver Class Initialized
INFO - 2021-09-25 10:00:44 --> Model "BlogModel" initialized
INFO - 2021-09-25 10:00:44 --> Helper loaded: cookie_helper
INFO - 2021-09-25 10:00:44 --> Model "CookieModel" initialized
INFO - 2021-09-25 10:00:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-25 10:00:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blog.php
INFO - 2021-09-25 10:00:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-25 10:00:44 --> Final output sent to browser
DEBUG - 2021-09-25 10:00:44 --> Total execution time: 0.0432
INFO - 2021-09-25 10:00:47 --> Config Class Initialized
INFO - 2021-09-25 10:00:47 --> Hooks Class Initialized
DEBUG - 2021-09-25 10:00:47 --> UTF-8 Support Enabled
INFO - 2021-09-25 10:00:47 --> Utf8 Class Initialized
INFO - 2021-09-25 10:00:47 --> URI Class Initialized
INFO - 2021-09-25 10:00:47 --> Router Class Initialized
INFO - 2021-09-25 10:00:47 --> Output Class Initialized
INFO - 2021-09-25 10:00:47 --> Security Class Initialized
DEBUG - 2021-09-25 10:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 10:00:47 --> Input Class Initialized
INFO - 2021-09-25 10:00:47 --> Language Class Initialized
INFO - 2021-09-25 10:00:47 --> Loader Class Initialized
INFO - 2021-09-25 10:00:47 --> Helper loaded: url_helper
INFO - 2021-09-25 10:00:47 --> Helper loaded: file_helper
DEBUG - 2021-09-25 10:00:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-25 10:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-25 10:00:47 --> Controller Class Initialized
INFO - 2021-09-25 10:00:47 --> Database Driver Class Initialized
INFO - 2021-09-25 10:00:47 --> Model "BlogModel" initialized
INFO - 2021-09-25 10:00:47 --> Helper loaded: cookie_helper
INFO - 2021-09-25 10:00:47 --> Model "CookieModel" initialized
INFO - 2021-09-25 10:00:47 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-25 10:00:47 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blog.php
INFO - 2021-09-25 10:00:47 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-25 10:00:47 --> Final output sent to browser
DEBUG - 2021-09-25 10:00:47 --> Total execution time: 0.0448
INFO - 2021-09-25 10:01:54 --> Config Class Initialized
INFO - 2021-09-25 10:01:54 --> Hooks Class Initialized
DEBUG - 2021-09-25 10:01:54 --> UTF-8 Support Enabled
INFO - 2021-09-25 10:01:54 --> Utf8 Class Initialized
INFO - 2021-09-25 10:01:54 --> URI Class Initialized
INFO - 2021-09-25 10:01:54 --> Router Class Initialized
INFO - 2021-09-25 10:01:54 --> Output Class Initialized
INFO - 2021-09-25 10:01:54 --> Security Class Initialized
DEBUG - 2021-09-25 10:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 10:01:54 --> Input Class Initialized
INFO - 2021-09-25 10:01:54 --> Language Class Initialized
INFO - 2021-09-25 10:01:54 --> Loader Class Initialized
INFO - 2021-09-25 10:01:54 --> Helper loaded: url_helper
INFO - 2021-09-25 10:01:54 --> Helper loaded: file_helper
DEBUG - 2021-09-25 10:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-25 10:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-25 10:01:54 --> Controller Class Initialized
INFO - 2021-09-25 10:01:54 --> Database Driver Class Initialized
INFO - 2021-09-25 10:01:54 --> Model "BlogModel" initialized
INFO - 2021-09-25 10:01:54 --> Helper loaded: cookie_helper
INFO - 2021-09-25 10:01:54 --> Model "CookieModel" initialized
INFO - 2021-09-25 10:01:54 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-25 10:01:54 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blog.php
INFO - 2021-09-25 10:01:54 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-25 10:01:54 --> Final output sent to browser
DEBUG - 2021-09-25 10:01:54 --> Total execution time: 0.0438
INFO - 2021-09-25 10:02:18 --> Config Class Initialized
INFO - 2021-09-25 10:02:18 --> Hooks Class Initialized
DEBUG - 2021-09-25 10:02:18 --> UTF-8 Support Enabled
INFO - 2021-09-25 10:02:18 --> Utf8 Class Initialized
INFO - 2021-09-25 10:02:18 --> URI Class Initialized
INFO - 2021-09-25 10:02:18 --> Router Class Initialized
INFO - 2021-09-25 10:02:18 --> Output Class Initialized
INFO - 2021-09-25 10:02:18 --> Security Class Initialized
DEBUG - 2021-09-25 10:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 10:02:18 --> Input Class Initialized
INFO - 2021-09-25 10:02:18 --> Language Class Initialized
INFO - 2021-09-25 10:02:18 --> Loader Class Initialized
INFO - 2021-09-25 10:02:18 --> Helper loaded: url_helper
INFO - 2021-09-25 10:02:18 --> Helper loaded: file_helper
DEBUG - 2021-09-25 10:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-25 10:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-25 10:02:18 --> Controller Class Initialized
INFO - 2021-09-25 10:02:18 --> Database Driver Class Initialized
INFO - 2021-09-25 10:02:18 --> Model "BlogModel" initialized
INFO - 2021-09-25 10:02:18 --> Helper loaded: cookie_helper
INFO - 2021-09-25 10:02:18 --> Model "CookieModel" initialized
INFO - 2021-09-25 10:02:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-25 10:02:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blog.php
INFO - 2021-09-25 10:02:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-25 10:02:18 --> Final output sent to browser
DEBUG - 2021-09-25 10:02:18 --> Total execution time: 0.0437
INFO - 2021-09-25 10:04:10 --> Config Class Initialized
INFO - 2021-09-25 10:04:10 --> Hooks Class Initialized
DEBUG - 2021-09-25 10:04:10 --> UTF-8 Support Enabled
INFO - 2021-09-25 10:04:10 --> Utf8 Class Initialized
INFO - 2021-09-25 10:04:10 --> URI Class Initialized
INFO - 2021-09-25 10:04:10 --> Router Class Initialized
INFO - 2021-09-25 10:04:10 --> Output Class Initialized
INFO - 2021-09-25 10:04:10 --> Security Class Initialized
DEBUG - 2021-09-25 10:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 10:04:10 --> Input Class Initialized
INFO - 2021-09-25 10:04:10 --> Language Class Initialized
INFO - 2021-09-25 10:04:10 --> Loader Class Initialized
INFO - 2021-09-25 10:04:10 --> Helper loaded: url_helper
INFO - 2021-09-25 10:04:10 --> Helper loaded: file_helper
DEBUG - 2021-09-25 10:04:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-25 10:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-25 10:04:10 --> Controller Class Initialized
INFO - 2021-09-25 10:04:10 --> Database Driver Class Initialized
INFO - 2021-09-25 10:04:10 --> Model "BlogModel" initialized
INFO - 2021-09-25 10:04:10 --> Helper loaded: cookie_helper
INFO - 2021-09-25 10:04:10 --> Model "CookieModel" initialized
INFO - 2021-09-25 10:04:10 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-25 10:04:10 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-09-25 10:04:10 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-25 10:04:10 --> Final output sent to browser
DEBUG - 2021-09-25 10:04:10 --> Total execution time: 0.0503
INFO - 2021-09-25 10:04:12 --> Config Class Initialized
INFO - 2021-09-25 10:04:12 --> Hooks Class Initialized
DEBUG - 2021-09-25 10:04:12 --> UTF-8 Support Enabled
INFO - 2021-09-25 10:04:12 --> Utf8 Class Initialized
INFO - 2021-09-25 10:04:12 --> URI Class Initialized
INFO - 2021-09-25 10:04:12 --> Router Class Initialized
INFO - 2021-09-25 10:04:12 --> Output Class Initialized
INFO - 2021-09-25 10:04:12 --> Security Class Initialized
DEBUG - 2021-09-25 10:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 10:04:12 --> Input Class Initialized
INFO - 2021-09-25 10:04:12 --> Language Class Initialized
INFO - 2021-09-25 10:04:12 --> Loader Class Initialized
INFO - 2021-09-25 10:04:12 --> Helper loaded: url_helper
INFO - 2021-09-25 10:04:12 --> Helper loaded: file_helper
DEBUG - 2021-09-25 10:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-25 10:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-25 10:04:12 --> Controller Class Initialized
INFO - 2021-09-25 10:04:12 --> Database Driver Class Initialized
INFO - 2021-09-25 10:04:12 --> Helper loaded: string_helper
INFO - 2021-09-25 10:04:12 --> Model "TestimonialModel" initialized
INFO - 2021-09-25 10:04:12 --> Helper loaded: cookie_helper
INFO - 2021-09-25 10:04:12 --> Model "CookieModel" initialized
INFO - 2021-09-25 10:04:12 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-25 10:04:12 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/testimonials.php
INFO - 2021-09-25 10:04:12 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-25 10:04:12 --> Final output sent to browser
DEBUG - 2021-09-25 10:04:12 --> Total execution time: 0.0514
INFO - 2021-09-25 10:04:14 --> Config Class Initialized
INFO - 2021-09-25 10:04:14 --> Hooks Class Initialized
DEBUG - 2021-09-25 10:04:14 --> UTF-8 Support Enabled
INFO - 2021-09-25 10:04:14 --> Utf8 Class Initialized
INFO - 2021-09-25 10:04:14 --> URI Class Initialized
INFO - 2021-09-25 10:04:14 --> Router Class Initialized
INFO - 2021-09-25 10:04:14 --> Output Class Initialized
INFO - 2021-09-25 10:04:14 --> Security Class Initialized
DEBUG - 2021-09-25 10:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 10:04:14 --> Input Class Initialized
INFO - 2021-09-25 10:04:14 --> Language Class Initialized
INFO - 2021-09-25 10:04:14 --> Loader Class Initialized
INFO - 2021-09-25 10:04:14 --> Helper loaded: url_helper
INFO - 2021-09-25 10:04:14 --> Helper loaded: file_helper
DEBUG - 2021-09-25 10:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-25 10:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-25 10:04:14 --> Controller Class Initialized
INFO - 2021-09-25 10:04:14 --> Database Driver Class Initialized
INFO - 2021-09-25 10:04:14 --> Helper loaded: string_helper
INFO - 2021-09-25 10:04:14 --> Model "TestimonialModel" initialized
INFO - 2021-09-25 10:04:14 --> Helper loaded: cookie_helper
INFO - 2021-09-25 10:04:14 --> Model "CookieModel" initialized
INFO - 2021-09-25 10:04:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-25 10:04:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/videotestimonials.php
INFO - 2021-09-25 10:04:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-25 10:04:14 --> Final output sent to browser
DEBUG - 2021-09-25 10:04:14 --> Total execution time: 0.0490
INFO - 2021-09-25 10:48:14 --> Config Class Initialized
INFO - 2021-09-25 10:48:14 --> Hooks Class Initialized
DEBUG - 2021-09-25 10:48:14 --> UTF-8 Support Enabled
INFO - 2021-09-25 10:48:14 --> Utf8 Class Initialized
INFO - 2021-09-25 10:48:14 --> URI Class Initialized
INFO - 2021-09-25 10:48:14 --> Router Class Initialized
INFO - 2021-09-25 10:48:14 --> Output Class Initialized
INFO - 2021-09-25 10:48:14 --> Security Class Initialized
DEBUG - 2021-09-25 10:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 10:48:14 --> Input Class Initialized
INFO - 2021-09-25 10:48:14 --> Language Class Initialized
INFO - 2021-09-25 10:48:14 --> Loader Class Initialized
INFO - 2021-09-25 10:48:14 --> Helper loaded: url_helper
INFO - 2021-09-25 10:48:14 --> Helper loaded: file_helper
DEBUG - 2021-09-25 10:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-25 10:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-25 10:48:14 --> Controller Class Initialized
INFO - 2021-09-25 10:48:14 --> Model "DBModel" initialized
DEBUG - 2021-09-25 10:48:14 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-25 10:48:14 --> Helper loaded: cookie_helper
INFO - 2021-09-25 10:48:14 --> Database Driver Class Initialized
INFO - 2021-09-25 10:48:14 --> Helper loaded: string_helper
INFO - 2021-09-25 10:48:14 --> Model "TestimonialModel" initialized
INFO - 2021-09-25 10:48:14 --> Model "BlogModel" initialized
INFO - 2021-09-25 10:48:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-25 10:48:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-25 10:48:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-25 10:48:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/blogs.php
INFO - 2021-09-25 10:48:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-25 10:48:14 --> Final output sent to browser
DEBUG - 2021-09-25 10:48:14 --> Total execution time: 0.1540
INFO - 2021-09-25 10:48:15 --> Config Class Initialized
INFO - 2021-09-25 10:48:15 --> Hooks Class Initialized
DEBUG - 2021-09-25 10:48:15 --> UTF-8 Support Enabled
INFO - 2021-09-25 10:48:15 --> Utf8 Class Initialized
INFO - 2021-09-25 10:48:15 --> URI Class Initialized
INFO - 2021-09-25 10:48:15 --> Router Class Initialized
INFO - 2021-09-25 10:48:15 --> Output Class Initialized
INFO - 2021-09-25 10:48:15 --> Security Class Initialized
DEBUG - 2021-09-25 10:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 10:48:15 --> Input Class Initialized
INFO - 2021-09-25 10:48:15 --> Language Class Initialized
INFO - 2021-09-25 10:48:15 --> Loader Class Initialized
INFO - 2021-09-25 10:48:15 --> Helper loaded: url_helper
INFO - 2021-09-25 10:48:15 --> Helper loaded: file_helper
DEBUG - 2021-09-25 10:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-25 10:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-25 10:48:15 --> Controller Class Initialized
INFO - 2021-09-25 10:48:15 --> Model "DBModel" initialized
DEBUG - 2021-09-25 10:48:15 --> Session class already loaded. Second attempt ignored.
INFO - 2021-09-25 10:48:15 --> Helper loaded: cookie_helper
INFO - 2021-09-25 10:48:15 --> Database Driver Class Initialized
INFO - 2021-09-25 10:48:15 --> Helper loaded: string_helper
INFO - 2021-09-25 10:48:15 --> Model "TestimonialModel" initialized
INFO - 2021-09-25 10:48:15 --> Model "BlogModel" initialized
INFO - 2021-09-25 10:48:15 --> File loaded: E:\xampp\htdocs\changeme\application\views\snackbar.php
INFO - 2021-09-25 10:48:15 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/header.php
INFO - 2021-09-25 10:48:15 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/sidebar.php
INFO - 2021-09-25 10:48:15 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/testimonial.php
INFO - 2021-09-25 10:48:15 --> File loaded: E:\xampp\htdocs\changeme\application\views\admin/layout/footer.php
INFO - 2021-09-25 10:48:15 --> Final output sent to browser
DEBUG - 2021-09-25 10:48:15 --> Total execution time: 0.0994
INFO - 2021-09-25 10:48:17 --> Config Class Initialized
INFO - 2021-09-25 10:48:17 --> Hooks Class Initialized
DEBUG - 2021-09-25 10:48:17 --> UTF-8 Support Enabled
INFO - 2021-09-25 10:48:17 --> Utf8 Class Initialized
INFO - 2021-09-25 10:48:17 --> URI Class Initialized
INFO - 2021-09-25 10:48:17 --> Router Class Initialized
INFO - 2021-09-25 10:48:17 --> Output Class Initialized
INFO - 2021-09-25 10:48:17 --> Security Class Initialized
DEBUG - 2021-09-25 10:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-25 10:48:17 --> Input Class Initialized
INFO - 2021-09-25 10:48:17 --> Language Class Initialized
INFO - 2021-09-25 10:48:17 --> Loader Class Initialized
INFO - 2021-09-25 10:48:17 --> Helper loaded: url_helper
INFO - 2021-09-25 10:48:17 --> Helper loaded: file_helper
DEBUG - 2021-09-25 10:48:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-25 10:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-25 10:48:17 --> Controller Class Initialized
INFO - 2021-09-25 10:48:17 --> Database Driver Class Initialized
INFO - 2021-09-25 10:48:17 --> Helper loaded: string_helper
INFO - 2021-09-25 10:48:17 --> Model "TestimonialModel" initialized
INFO - 2021-09-25 10:48:17 --> Helper loaded: cookie_helper
INFO - 2021-09-25 10:48:17 --> Model "CookieModel" initialized
INFO - 2021-09-25 10:48:17 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-25 10:48:17 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/videotestimonials.php
INFO - 2021-09-25 10:48:17 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-25 10:48:17 --> Final output sent to browser
DEBUG - 2021-09-25 10:48:17 --> Total execution time: 0.0683
