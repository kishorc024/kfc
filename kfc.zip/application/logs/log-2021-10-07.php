<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-10-07 10:41:01 --> Config Class Initialized
INFO - 2021-10-07 10:41:01 --> Hooks Class Initialized
DEBUG - 2021-10-07 10:41:01 --> UTF-8 Support Enabled
INFO - 2021-10-07 10:41:01 --> Utf8 Class Initialized
INFO - 2021-10-07 10:41:01 --> URI Class Initialized
DEBUG - 2021-10-07 10:41:01 --> No URI present. Default controller set.
INFO - 2021-10-07 10:41:01 --> Router Class Initialized
INFO - 2021-10-07 10:41:01 --> Output Class Initialized
INFO - 2021-10-07 10:41:01 --> Security Class Initialized
DEBUG - 2021-10-07 10:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-07 10:41:02 --> Input Class Initialized
INFO - 2021-10-07 10:41:02 --> Language Class Initialized
INFO - 2021-10-07 10:41:02 --> Loader Class Initialized
INFO - 2021-10-07 10:41:02 --> Helper loaded: url_helper
INFO - 2021-10-07 10:41:02 --> Helper loaded: file_helper
DEBUG - 2021-10-07 10:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-07 10:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-07 10:41:02 --> Controller Class Initialized
INFO - 2021-10-07 10:41:02 --> Helper loaded: cookie_helper
INFO - 2021-10-07 10:41:02 --> Model "CookieModel" initialized
INFO - 2021-10-07 10:41:02 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-10-07 10:41:02 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-10-07 10:41:02 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-10-07 10:41:02 --> Final output sent to browser
DEBUG - 2021-10-07 10:41:02 --> Total execution time: 0.5113
INFO - 2021-10-07 10:41:10 --> Config Class Initialized
INFO - 2021-10-07 10:41:10 --> Hooks Class Initialized
DEBUG - 2021-10-07 10:41:10 --> UTF-8 Support Enabled
INFO - 2021-10-07 10:41:10 --> Utf8 Class Initialized
INFO - 2021-10-07 10:41:10 --> URI Class Initialized
INFO - 2021-10-07 10:41:10 --> Router Class Initialized
INFO - 2021-10-07 10:41:10 --> Output Class Initialized
INFO - 2021-10-07 10:41:10 --> Security Class Initialized
DEBUG - 2021-10-07 10:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-07 10:41:10 --> Input Class Initialized
INFO - 2021-10-07 10:41:10 --> Language Class Initialized
INFO - 2021-10-07 10:41:10 --> Loader Class Initialized
INFO - 2021-10-07 10:41:10 --> Helper loaded: url_helper
INFO - 2021-10-07 10:41:10 --> Helper loaded: file_helper
DEBUG - 2021-10-07 10:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-07 10:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-07 10:41:11 --> Controller Class Initialized
INFO - 2021-10-07 10:41:11 --> Database Driver Class Initialized
INFO - 2021-10-07 10:41:11 --> Model "BlogModel" initialized
INFO - 2021-10-07 10:41:11 --> Helper loaded: cookie_helper
INFO - 2021-10-07 10:41:11 --> Model "CookieModel" initialized
INFO - 2021-10-07 10:41:11 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-10-07 10:41:11 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blogs.php
INFO - 2021-10-07 10:41:11 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-10-07 10:41:11 --> Final output sent to browser
DEBUG - 2021-10-07 10:41:11 --> Total execution time: 0.2321
INFO - 2021-10-07 10:43:14 --> Config Class Initialized
INFO - 2021-10-07 10:43:14 --> Hooks Class Initialized
DEBUG - 2021-10-07 10:43:14 --> UTF-8 Support Enabled
INFO - 2021-10-07 10:43:14 --> Utf8 Class Initialized
INFO - 2021-10-07 10:43:14 --> URI Class Initialized
INFO - 2021-10-07 10:43:14 --> Router Class Initialized
INFO - 2021-10-07 10:43:14 --> Output Class Initialized
INFO - 2021-10-07 10:43:14 --> Security Class Initialized
DEBUG - 2021-10-07 10:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-07 10:43:14 --> Input Class Initialized
INFO - 2021-10-07 10:43:14 --> Language Class Initialized
INFO - 2021-10-07 10:43:14 --> Loader Class Initialized
INFO - 2021-10-07 10:43:14 --> Helper loaded: url_helper
INFO - 2021-10-07 10:43:14 --> Helper loaded: file_helper
DEBUG - 2021-10-07 10:43:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-07 10:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-07 10:43:14 --> Controller Class Initialized
INFO - 2021-10-07 10:43:14 --> Database Driver Class Initialized
INFO - 2021-10-07 10:43:14 --> Model "BlogModel" initialized
INFO - 2021-10-07 10:43:14 --> Helper loaded: cookie_helper
INFO - 2021-10-07 10:43:14 --> Model "CookieModel" initialized
INFO - 2021-10-07 10:43:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-10-07 10:43:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/blog.php
INFO - 2021-10-07 10:43:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-10-07 10:43:14 --> Final output sent to browser
DEBUG - 2021-10-07 10:43:14 --> Total execution time: 0.0620
INFO - 2021-10-07 10:46:06 --> Config Class Initialized
INFO - 2021-10-07 10:46:06 --> Hooks Class Initialized
DEBUG - 2021-10-07 10:46:06 --> UTF-8 Support Enabled
INFO - 2021-10-07 10:46:06 --> Utf8 Class Initialized
INFO - 2021-10-07 10:46:06 --> URI Class Initialized
DEBUG - 2021-10-07 10:46:06 --> No URI present. Default controller set.
INFO - 2021-10-07 10:46:06 --> Router Class Initialized
INFO - 2021-10-07 10:46:06 --> Output Class Initialized
INFO - 2021-10-07 10:46:06 --> Security Class Initialized
DEBUG - 2021-10-07 10:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-07 10:46:06 --> Input Class Initialized
INFO - 2021-10-07 10:46:06 --> Language Class Initialized
INFO - 2021-10-07 10:46:06 --> Loader Class Initialized
INFO - 2021-10-07 10:46:06 --> Helper loaded: url_helper
INFO - 2021-10-07 10:46:06 --> Helper loaded: file_helper
DEBUG - 2021-10-07 10:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-07 10:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-07 10:46:06 --> Controller Class Initialized
INFO - 2021-10-07 10:46:06 --> Helper loaded: cookie_helper
INFO - 2021-10-07 10:46:06 --> Model "CookieModel" initialized
INFO - 2021-10-07 10:46:06 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-10-07 10:46:06 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-10-07 10:46:06 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-10-07 10:46:06 --> Final output sent to browser
DEBUG - 2021-10-07 10:46:06 --> Total execution time: 0.0448
