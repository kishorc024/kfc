<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-10-29 11:01:34 --> Config Class Initialized
INFO - 2021-10-29 11:01:34 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:01:34 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:01:34 --> Utf8 Class Initialized
INFO - 2021-10-29 11:01:34 --> URI Class Initialized
INFO - 2021-10-29 11:01:34 --> Router Class Initialized
INFO - 2021-10-29 11:01:34 --> Output Class Initialized
INFO - 2021-10-29 11:01:34 --> Security Class Initialized
DEBUG - 2021-10-29 11:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:01:34 --> Input Class Initialized
INFO - 2021-10-29 11:01:34 --> Language Class Initialized
ERROR - 2021-10-29 11:01:34 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 11:04:21 --> Config Class Initialized
INFO - 2021-10-29 11:04:21 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:04:21 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:04:21 --> Utf8 Class Initialized
INFO - 2021-10-29 11:04:21 --> URI Class Initialized
DEBUG - 2021-10-29 11:04:21 --> No URI present. Default controller set.
INFO - 2021-10-29 11:04:21 --> Router Class Initialized
INFO - 2021-10-29 11:04:21 --> Output Class Initialized
INFO - 2021-10-29 11:04:21 --> Security Class Initialized
DEBUG - 2021-10-29 11:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:04:21 --> Input Class Initialized
INFO - 2021-10-29 11:04:21 --> Language Class Initialized
INFO - 2021-10-29 11:04:21 --> Loader Class Initialized
INFO - 2021-10-29 11:04:21 --> Helper loaded: url_helper
INFO - 2021-10-29 11:04:21 --> Helper loaded: file_helper
DEBUG - 2021-10-29 11:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 11:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 11:04:21 --> Controller Class Initialized
INFO - 2021-10-29 11:04:21 --> Helper loaded: cookie_helper
INFO - 2021-10-29 11:04:21 --> Model "CookieModel" initialized
INFO - 2021-10-29 11:04:21 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 11:04:21 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 11:04:21 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 11:04:21 --> Final output sent to browser
DEBUG - 2021-10-29 11:04:21 --> Total execution time: 0.0512
INFO - 2021-10-29 11:04:22 --> Config Class Initialized
INFO - 2021-10-29 11:04:22 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:04:22 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:04:22 --> Utf8 Class Initialized
INFO - 2021-10-29 11:04:22 --> URI Class Initialized
INFO - 2021-10-29 11:04:22 --> Router Class Initialized
INFO - 2021-10-29 11:04:22 --> Output Class Initialized
INFO - 2021-10-29 11:04:22 --> Security Class Initialized
DEBUG - 2021-10-29 11:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:04:22 --> Input Class Initialized
INFO - 2021-10-29 11:04:22 --> Language Class Initialized
ERROR - 2021-10-29 11:04:22 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 11:04:40 --> Config Class Initialized
INFO - 2021-10-29 11:04:40 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:04:40 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:04:40 --> Utf8 Class Initialized
INFO - 2021-10-29 11:04:40 --> URI Class Initialized
DEBUG - 2021-10-29 11:04:40 --> No URI present. Default controller set.
INFO - 2021-10-29 11:04:40 --> Router Class Initialized
INFO - 2021-10-29 11:04:40 --> Output Class Initialized
INFO - 2021-10-29 11:04:40 --> Security Class Initialized
DEBUG - 2021-10-29 11:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:04:40 --> Input Class Initialized
INFO - 2021-10-29 11:04:40 --> Language Class Initialized
INFO - 2021-10-29 11:04:40 --> Loader Class Initialized
INFO - 2021-10-29 11:04:40 --> Helper loaded: url_helper
INFO - 2021-10-29 11:04:40 --> Helper loaded: file_helper
DEBUG - 2021-10-29 11:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 11:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 11:04:40 --> Controller Class Initialized
INFO - 2021-10-29 11:04:40 --> Helper loaded: cookie_helper
INFO - 2021-10-29 11:04:40 --> Model "CookieModel" initialized
INFO - 2021-10-29 11:04:40 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 11:04:40 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 11:04:40 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 11:04:40 --> Final output sent to browser
DEBUG - 2021-10-29 11:04:40 --> Total execution time: 0.0427
INFO - 2021-10-29 11:04:41 --> Config Class Initialized
INFO - 2021-10-29 11:04:41 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:04:41 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:04:41 --> Utf8 Class Initialized
INFO - 2021-10-29 11:04:41 --> URI Class Initialized
INFO - 2021-10-29 11:04:41 --> Router Class Initialized
INFO - 2021-10-29 11:04:41 --> Output Class Initialized
INFO - 2021-10-29 11:04:41 --> Security Class Initialized
DEBUG - 2021-10-29 11:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:04:41 --> Input Class Initialized
INFO - 2021-10-29 11:04:41 --> Language Class Initialized
ERROR - 2021-10-29 11:04:41 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 11:05:44 --> Config Class Initialized
INFO - 2021-10-29 11:05:44 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:05:44 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:05:44 --> Utf8 Class Initialized
INFO - 2021-10-29 11:05:44 --> URI Class Initialized
DEBUG - 2021-10-29 11:05:44 --> No URI present. Default controller set.
INFO - 2021-10-29 11:05:44 --> Router Class Initialized
INFO - 2021-10-29 11:05:44 --> Output Class Initialized
INFO - 2021-10-29 11:05:44 --> Security Class Initialized
DEBUG - 2021-10-29 11:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:05:44 --> Input Class Initialized
INFO - 2021-10-29 11:05:44 --> Language Class Initialized
INFO - 2021-10-29 11:05:44 --> Loader Class Initialized
INFO - 2021-10-29 11:05:44 --> Helper loaded: url_helper
INFO - 2021-10-29 11:05:44 --> Helper loaded: file_helper
DEBUG - 2021-10-29 11:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 11:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 11:05:44 --> Controller Class Initialized
INFO - 2021-10-29 11:05:44 --> Helper loaded: cookie_helper
INFO - 2021-10-29 11:05:44 --> Model "CookieModel" initialized
INFO - 2021-10-29 11:05:44 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 11:05:44 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 11:05:44 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 11:05:44 --> Final output sent to browser
DEBUG - 2021-10-29 11:05:44 --> Total execution time: 0.0387
INFO - 2021-10-29 11:05:44 --> Config Class Initialized
INFO - 2021-10-29 11:05:44 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:05:44 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:05:44 --> Utf8 Class Initialized
INFO - 2021-10-29 11:05:44 --> URI Class Initialized
INFO - 2021-10-29 11:05:44 --> Router Class Initialized
INFO - 2021-10-29 11:05:44 --> Output Class Initialized
INFO - 2021-10-29 11:05:44 --> Security Class Initialized
DEBUG - 2021-10-29 11:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:05:44 --> Input Class Initialized
INFO - 2021-10-29 11:05:44 --> Language Class Initialized
ERROR - 2021-10-29 11:05:44 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 11:05:57 --> Config Class Initialized
INFO - 2021-10-29 11:05:57 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:05:57 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:05:57 --> Utf8 Class Initialized
INFO - 2021-10-29 11:05:57 --> URI Class Initialized
INFO - 2021-10-29 11:05:57 --> Router Class Initialized
INFO - 2021-10-29 11:05:57 --> Output Class Initialized
INFO - 2021-10-29 11:05:57 --> Security Class Initialized
DEBUG - 2021-10-29 11:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:05:57 --> Input Class Initialized
INFO - 2021-10-29 11:05:57 --> Language Class Initialized
ERROR - 2021-10-29 11:05:57 --> 404 Page Not Found: Classeshtml/index
INFO - 2021-10-29 11:05:59 --> Config Class Initialized
INFO - 2021-10-29 11:05:59 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:05:59 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:05:59 --> Utf8 Class Initialized
INFO - 2021-10-29 11:05:59 --> URI Class Initialized
DEBUG - 2021-10-29 11:05:59 --> No URI present. Default controller set.
INFO - 2021-10-29 11:05:59 --> Router Class Initialized
INFO - 2021-10-29 11:05:59 --> Output Class Initialized
INFO - 2021-10-29 11:05:59 --> Security Class Initialized
DEBUG - 2021-10-29 11:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:05:59 --> Input Class Initialized
INFO - 2021-10-29 11:05:59 --> Language Class Initialized
INFO - 2021-10-29 11:05:59 --> Loader Class Initialized
INFO - 2021-10-29 11:05:59 --> Helper loaded: url_helper
INFO - 2021-10-29 11:05:59 --> Helper loaded: file_helper
DEBUG - 2021-10-29 11:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 11:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 11:05:59 --> Controller Class Initialized
INFO - 2021-10-29 11:05:59 --> Helper loaded: cookie_helper
INFO - 2021-10-29 11:05:59 --> Model "CookieModel" initialized
INFO - 2021-10-29 11:05:59 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 11:05:59 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 11:05:59 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 11:05:59 --> Final output sent to browser
DEBUG - 2021-10-29 11:05:59 --> Total execution time: 0.0324
INFO - 2021-10-29 11:06:17 --> Config Class Initialized
INFO - 2021-10-29 11:06:17 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:06:17 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:06:17 --> Utf8 Class Initialized
INFO - 2021-10-29 11:06:17 --> URI Class Initialized
DEBUG - 2021-10-29 11:06:17 --> No URI present. Default controller set.
INFO - 2021-10-29 11:06:17 --> Router Class Initialized
INFO - 2021-10-29 11:06:17 --> Output Class Initialized
INFO - 2021-10-29 11:06:17 --> Security Class Initialized
DEBUG - 2021-10-29 11:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:06:17 --> Input Class Initialized
INFO - 2021-10-29 11:06:17 --> Language Class Initialized
INFO - 2021-10-29 11:06:17 --> Loader Class Initialized
INFO - 2021-10-29 11:06:17 --> Helper loaded: url_helper
INFO - 2021-10-29 11:06:17 --> Helper loaded: file_helper
DEBUG - 2021-10-29 11:06:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 11:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 11:06:17 --> Controller Class Initialized
INFO - 2021-10-29 11:06:17 --> Helper loaded: cookie_helper
INFO - 2021-10-29 11:06:17 --> Model "CookieModel" initialized
INFO - 2021-10-29 11:06:17 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 11:06:17 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 11:06:17 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 11:06:17 --> Final output sent to browser
DEBUG - 2021-10-29 11:06:17 --> Total execution time: 0.0414
INFO - 2021-10-29 11:06:17 --> Config Class Initialized
INFO - 2021-10-29 11:06:17 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:06:17 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:06:17 --> Utf8 Class Initialized
INFO - 2021-10-29 11:06:17 --> URI Class Initialized
INFO - 2021-10-29 11:06:17 --> Router Class Initialized
INFO - 2021-10-29 11:06:17 --> Output Class Initialized
INFO - 2021-10-29 11:06:17 --> Security Class Initialized
DEBUG - 2021-10-29 11:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:06:17 --> Input Class Initialized
INFO - 2021-10-29 11:06:17 --> Language Class Initialized
ERROR - 2021-10-29 11:06:17 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 11:06:29 --> Config Class Initialized
INFO - 2021-10-29 11:06:29 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:06:29 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:06:29 --> Utf8 Class Initialized
INFO - 2021-10-29 11:06:29 --> URI Class Initialized
DEBUG - 2021-10-29 11:06:29 --> No URI present. Default controller set.
INFO - 2021-10-29 11:06:29 --> Router Class Initialized
INFO - 2021-10-29 11:06:29 --> Output Class Initialized
INFO - 2021-10-29 11:06:29 --> Security Class Initialized
DEBUG - 2021-10-29 11:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:06:29 --> Input Class Initialized
INFO - 2021-10-29 11:06:29 --> Language Class Initialized
INFO - 2021-10-29 11:06:29 --> Loader Class Initialized
INFO - 2021-10-29 11:06:29 --> Helper loaded: url_helper
INFO - 2021-10-29 11:06:29 --> Helper loaded: file_helper
DEBUG - 2021-10-29 11:06:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 11:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 11:06:29 --> Controller Class Initialized
INFO - 2021-10-29 11:06:29 --> Helper loaded: cookie_helper
INFO - 2021-10-29 11:06:29 --> Model "CookieModel" initialized
INFO - 2021-10-29 11:06:29 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 11:06:29 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 11:06:29 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 11:06:29 --> Final output sent to browser
DEBUG - 2021-10-29 11:06:29 --> Total execution time: 0.0377
INFO - 2021-10-29 11:06:29 --> Config Class Initialized
INFO - 2021-10-29 11:06:29 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:06:29 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:06:29 --> Utf8 Class Initialized
INFO - 2021-10-29 11:06:29 --> URI Class Initialized
INFO - 2021-10-29 11:06:29 --> Router Class Initialized
INFO - 2021-10-29 11:06:29 --> Output Class Initialized
INFO - 2021-10-29 11:06:29 --> Security Class Initialized
DEBUG - 2021-10-29 11:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:06:29 --> Input Class Initialized
INFO - 2021-10-29 11:06:29 --> Language Class Initialized
ERROR - 2021-10-29 11:06:29 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 11:06:37 --> Config Class Initialized
INFO - 2021-10-29 11:06:37 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:06:37 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:06:37 --> Utf8 Class Initialized
INFO - 2021-10-29 11:06:37 --> URI Class Initialized
DEBUG - 2021-10-29 11:06:37 --> No URI present. Default controller set.
INFO - 2021-10-29 11:06:37 --> Router Class Initialized
INFO - 2021-10-29 11:06:37 --> Output Class Initialized
INFO - 2021-10-29 11:06:37 --> Security Class Initialized
DEBUG - 2021-10-29 11:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:06:37 --> Input Class Initialized
INFO - 2021-10-29 11:06:37 --> Language Class Initialized
INFO - 2021-10-29 11:06:37 --> Loader Class Initialized
INFO - 2021-10-29 11:06:37 --> Helper loaded: url_helper
INFO - 2021-10-29 11:06:37 --> Helper loaded: file_helper
DEBUG - 2021-10-29 11:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 11:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 11:06:37 --> Controller Class Initialized
INFO - 2021-10-29 11:06:37 --> Helper loaded: cookie_helper
INFO - 2021-10-29 11:06:37 --> Model "CookieModel" initialized
INFO - 2021-10-29 11:06:37 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 11:06:37 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 11:06:37 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 11:06:37 --> Final output sent to browser
DEBUG - 2021-10-29 11:06:37 --> Total execution time: 0.0355
INFO - 2021-10-29 11:06:37 --> Config Class Initialized
INFO - 2021-10-29 11:06:37 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:06:37 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:06:37 --> Utf8 Class Initialized
INFO - 2021-10-29 11:06:37 --> URI Class Initialized
INFO - 2021-10-29 11:06:37 --> Router Class Initialized
INFO - 2021-10-29 11:06:37 --> Output Class Initialized
INFO - 2021-10-29 11:06:37 --> Security Class Initialized
DEBUG - 2021-10-29 11:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:06:37 --> Input Class Initialized
INFO - 2021-10-29 11:06:37 --> Language Class Initialized
ERROR - 2021-10-29 11:06:37 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 11:06:57 --> Config Class Initialized
INFO - 2021-10-29 11:06:57 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:06:57 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:06:57 --> Utf8 Class Initialized
INFO - 2021-10-29 11:06:57 --> URI Class Initialized
DEBUG - 2021-10-29 11:06:57 --> No URI present. Default controller set.
INFO - 2021-10-29 11:06:57 --> Router Class Initialized
INFO - 2021-10-29 11:06:57 --> Output Class Initialized
INFO - 2021-10-29 11:06:57 --> Security Class Initialized
DEBUG - 2021-10-29 11:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:06:57 --> Input Class Initialized
INFO - 2021-10-29 11:06:57 --> Language Class Initialized
INFO - 2021-10-29 11:06:57 --> Loader Class Initialized
INFO - 2021-10-29 11:06:57 --> Helper loaded: url_helper
INFO - 2021-10-29 11:06:57 --> Helper loaded: file_helper
DEBUG - 2021-10-29 11:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 11:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 11:06:57 --> Controller Class Initialized
INFO - 2021-10-29 11:06:57 --> Helper loaded: cookie_helper
INFO - 2021-10-29 11:06:57 --> Model "CookieModel" initialized
INFO - 2021-10-29 11:06:57 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 11:06:57 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 11:06:57 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 11:06:57 --> Final output sent to browser
DEBUG - 2021-10-29 11:06:57 --> Total execution time: 0.0314
INFO - 2021-10-29 11:06:57 --> Config Class Initialized
INFO - 2021-10-29 11:06:57 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:06:57 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:06:57 --> Utf8 Class Initialized
INFO - 2021-10-29 11:06:57 --> URI Class Initialized
INFO - 2021-10-29 11:06:57 --> Router Class Initialized
INFO - 2021-10-29 11:06:57 --> Output Class Initialized
INFO - 2021-10-29 11:06:57 --> Security Class Initialized
DEBUG - 2021-10-29 11:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:06:57 --> Input Class Initialized
INFO - 2021-10-29 11:06:57 --> Language Class Initialized
ERROR - 2021-10-29 11:06:57 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 11:07:16 --> Config Class Initialized
INFO - 2021-10-29 11:07:16 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:07:16 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:07:16 --> Utf8 Class Initialized
INFO - 2021-10-29 11:07:16 --> URI Class Initialized
DEBUG - 2021-10-29 11:07:16 --> No URI present. Default controller set.
INFO - 2021-10-29 11:07:16 --> Router Class Initialized
INFO - 2021-10-29 11:07:16 --> Output Class Initialized
INFO - 2021-10-29 11:07:16 --> Security Class Initialized
DEBUG - 2021-10-29 11:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:07:16 --> Input Class Initialized
INFO - 2021-10-29 11:07:16 --> Language Class Initialized
INFO - 2021-10-29 11:07:16 --> Loader Class Initialized
INFO - 2021-10-29 11:07:16 --> Helper loaded: url_helper
INFO - 2021-10-29 11:07:16 --> Helper loaded: file_helper
DEBUG - 2021-10-29 11:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 11:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 11:07:16 --> Controller Class Initialized
INFO - 2021-10-29 11:07:16 --> Helper loaded: cookie_helper
INFO - 2021-10-29 11:07:16 --> Model "CookieModel" initialized
INFO - 2021-10-29 11:07:16 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 11:07:16 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 11:07:16 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 11:07:16 --> Final output sent to browser
DEBUG - 2021-10-29 11:07:16 --> Total execution time: 0.0336
INFO - 2021-10-29 11:07:16 --> Config Class Initialized
INFO - 2021-10-29 11:07:16 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:07:16 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:07:16 --> Utf8 Class Initialized
INFO - 2021-10-29 11:07:16 --> URI Class Initialized
INFO - 2021-10-29 11:07:16 --> Router Class Initialized
INFO - 2021-10-29 11:07:16 --> Output Class Initialized
INFO - 2021-10-29 11:07:16 --> Security Class Initialized
DEBUG - 2021-10-29 11:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:07:16 --> Input Class Initialized
INFO - 2021-10-29 11:07:16 --> Language Class Initialized
ERROR - 2021-10-29 11:07:16 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 11:14:25 --> Config Class Initialized
INFO - 2021-10-29 11:14:25 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:14:25 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:14:25 --> Utf8 Class Initialized
INFO - 2021-10-29 11:14:25 --> URI Class Initialized
DEBUG - 2021-10-29 11:14:25 --> No URI present. Default controller set.
INFO - 2021-10-29 11:14:25 --> Router Class Initialized
INFO - 2021-10-29 11:14:25 --> Output Class Initialized
INFO - 2021-10-29 11:14:25 --> Security Class Initialized
DEBUG - 2021-10-29 11:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:14:25 --> Input Class Initialized
INFO - 2021-10-29 11:14:25 --> Language Class Initialized
INFO - 2021-10-29 11:14:25 --> Loader Class Initialized
INFO - 2021-10-29 11:14:25 --> Helper loaded: url_helper
INFO - 2021-10-29 11:14:25 --> Helper loaded: file_helper
DEBUG - 2021-10-29 11:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 11:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 11:14:25 --> Controller Class Initialized
INFO - 2021-10-29 11:14:25 --> Helper loaded: cookie_helper
INFO - 2021-10-29 11:14:25 --> Model "CookieModel" initialized
INFO - 2021-10-29 11:14:25 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 11:14:25 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 11:14:25 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 11:14:25 --> Final output sent to browser
DEBUG - 2021-10-29 11:14:25 --> Total execution time: 0.0483
INFO - 2021-10-29 11:14:25 --> Config Class Initialized
INFO - 2021-10-29 11:14:25 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:14:25 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:14:25 --> Utf8 Class Initialized
INFO - 2021-10-29 11:14:25 --> URI Class Initialized
INFO - 2021-10-29 11:14:25 --> Router Class Initialized
INFO - 2021-10-29 11:14:25 --> Output Class Initialized
INFO - 2021-10-29 11:14:25 --> Security Class Initialized
DEBUG - 2021-10-29 11:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:14:25 --> Input Class Initialized
INFO - 2021-10-29 11:14:25 --> Language Class Initialized
ERROR - 2021-10-29 11:14:25 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 11:14:44 --> Config Class Initialized
INFO - 2021-10-29 11:14:44 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:14:44 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:14:44 --> Utf8 Class Initialized
INFO - 2021-10-29 11:14:44 --> URI Class Initialized
DEBUG - 2021-10-29 11:14:44 --> No URI present. Default controller set.
INFO - 2021-10-29 11:14:44 --> Router Class Initialized
INFO - 2021-10-29 11:14:44 --> Output Class Initialized
INFO - 2021-10-29 11:14:44 --> Security Class Initialized
DEBUG - 2021-10-29 11:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:14:44 --> Input Class Initialized
INFO - 2021-10-29 11:14:44 --> Language Class Initialized
INFO - 2021-10-29 11:14:44 --> Loader Class Initialized
INFO - 2021-10-29 11:14:44 --> Helper loaded: url_helper
INFO - 2021-10-29 11:14:44 --> Helper loaded: file_helper
DEBUG - 2021-10-29 11:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 11:14:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 11:14:44 --> Controller Class Initialized
INFO - 2021-10-29 11:14:44 --> Helper loaded: cookie_helper
INFO - 2021-10-29 11:14:44 --> Model "CookieModel" initialized
INFO - 2021-10-29 11:14:44 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 11:14:44 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 11:14:44 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 11:14:44 --> Final output sent to browser
DEBUG - 2021-10-29 11:14:44 --> Total execution time: 0.0302
INFO - 2021-10-29 11:14:44 --> Config Class Initialized
INFO - 2021-10-29 11:14:44 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:14:44 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:14:44 --> Utf8 Class Initialized
INFO - 2021-10-29 11:14:44 --> URI Class Initialized
INFO - 2021-10-29 11:14:44 --> Router Class Initialized
INFO - 2021-10-29 11:14:44 --> Output Class Initialized
INFO - 2021-10-29 11:14:44 --> Security Class Initialized
DEBUG - 2021-10-29 11:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:14:44 --> Input Class Initialized
INFO - 2021-10-29 11:14:44 --> Language Class Initialized
ERROR - 2021-10-29 11:14:44 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 11:15:18 --> Config Class Initialized
INFO - 2021-10-29 11:15:18 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:15:18 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:15:18 --> Utf8 Class Initialized
INFO - 2021-10-29 11:15:18 --> URI Class Initialized
INFO - 2021-10-29 11:15:18 --> Router Class Initialized
INFO - 2021-10-29 11:15:18 --> Output Class Initialized
INFO - 2021-10-29 11:15:18 --> Security Class Initialized
DEBUG - 2021-10-29 11:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:15:18 --> Input Class Initialized
INFO - 2021-10-29 11:15:18 --> Language Class Initialized
ERROR - 2021-10-29 11:15:18 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 11:17:07 --> Config Class Initialized
INFO - 2021-10-29 11:17:07 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:17:07 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:17:07 --> Utf8 Class Initialized
INFO - 2021-10-29 11:17:07 --> URI Class Initialized
DEBUG - 2021-10-29 11:17:07 --> No URI present. Default controller set.
INFO - 2021-10-29 11:17:07 --> Router Class Initialized
INFO - 2021-10-29 11:17:07 --> Output Class Initialized
INFO - 2021-10-29 11:17:07 --> Security Class Initialized
DEBUG - 2021-10-29 11:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:17:07 --> Input Class Initialized
INFO - 2021-10-29 11:17:07 --> Language Class Initialized
INFO - 2021-10-29 11:17:07 --> Loader Class Initialized
INFO - 2021-10-29 11:17:07 --> Helper loaded: url_helper
INFO - 2021-10-29 11:17:07 --> Helper loaded: file_helper
DEBUG - 2021-10-29 11:17:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 11:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 11:17:07 --> Controller Class Initialized
INFO - 2021-10-29 11:17:07 --> Helper loaded: cookie_helper
INFO - 2021-10-29 11:17:07 --> Model "CookieModel" initialized
INFO - 2021-10-29 11:17:07 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 11:17:07 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 11:17:07 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 11:17:07 --> Final output sent to browser
DEBUG - 2021-10-29 11:17:07 --> Total execution time: 0.0496
INFO - 2021-10-29 11:17:07 --> Config Class Initialized
INFO - 2021-10-29 11:17:07 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:17:07 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:17:07 --> Utf8 Class Initialized
INFO - 2021-10-29 11:17:07 --> URI Class Initialized
INFO - 2021-10-29 11:17:07 --> Router Class Initialized
INFO - 2021-10-29 11:17:07 --> Output Class Initialized
INFO - 2021-10-29 11:17:07 --> Security Class Initialized
DEBUG - 2021-10-29 11:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:17:07 --> Input Class Initialized
INFO - 2021-10-29 11:17:07 --> Language Class Initialized
ERROR - 2021-10-29 11:17:07 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 11:17:28 --> Config Class Initialized
INFO - 2021-10-29 11:17:28 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:17:28 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:17:28 --> Utf8 Class Initialized
INFO - 2021-10-29 11:17:28 --> URI Class Initialized
DEBUG - 2021-10-29 11:17:28 --> No URI present. Default controller set.
INFO - 2021-10-29 11:17:28 --> Router Class Initialized
INFO - 2021-10-29 11:17:28 --> Output Class Initialized
INFO - 2021-10-29 11:17:28 --> Security Class Initialized
DEBUG - 2021-10-29 11:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:17:28 --> Input Class Initialized
INFO - 2021-10-29 11:17:28 --> Language Class Initialized
INFO - 2021-10-29 11:17:28 --> Loader Class Initialized
INFO - 2021-10-29 11:17:28 --> Helper loaded: url_helper
INFO - 2021-10-29 11:17:28 --> Helper loaded: file_helper
DEBUG - 2021-10-29 11:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 11:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 11:17:28 --> Controller Class Initialized
INFO - 2021-10-29 11:17:28 --> Helper loaded: cookie_helper
INFO - 2021-10-29 11:17:28 --> Model "CookieModel" initialized
INFO - 2021-10-29 11:17:28 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 11:17:28 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 11:17:28 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 11:17:28 --> Final output sent to browser
DEBUG - 2021-10-29 11:17:28 --> Total execution time: 0.0477
INFO - 2021-10-29 11:17:28 --> Config Class Initialized
INFO - 2021-10-29 11:17:28 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:17:28 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:17:28 --> Utf8 Class Initialized
INFO - 2021-10-29 11:17:28 --> URI Class Initialized
INFO - 2021-10-29 11:17:28 --> Router Class Initialized
INFO - 2021-10-29 11:17:28 --> Output Class Initialized
INFO - 2021-10-29 11:17:28 --> Security Class Initialized
DEBUG - 2021-10-29 11:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:17:28 --> Input Class Initialized
INFO - 2021-10-29 11:17:28 --> Language Class Initialized
ERROR - 2021-10-29 11:17:28 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 11:17:39 --> Config Class Initialized
INFO - 2021-10-29 11:17:39 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:17:39 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:17:39 --> Utf8 Class Initialized
INFO - 2021-10-29 11:17:39 --> URI Class Initialized
DEBUG - 2021-10-29 11:17:39 --> No URI present. Default controller set.
INFO - 2021-10-29 11:17:39 --> Router Class Initialized
INFO - 2021-10-29 11:17:39 --> Output Class Initialized
INFO - 2021-10-29 11:17:39 --> Security Class Initialized
DEBUG - 2021-10-29 11:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:17:39 --> Input Class Initialized
INFO - 2021-10-29 11:17:39 --> Language Class Initialized
INFO - 2021-10-29 11:17:39 --> Loader Class Initialized
INFO - 2021-10-29 11:17:39 --> Helper loaded: url_helper
INFO - 2021-10-29 11:17:39 --> Helper loaded: file_helper
DEBUG - 2021-10-29 11:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 11:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 11:17:39 --> Controller Class Initialized
INFO - 2021-10-29 11:17:39 --> Helper loaded: cookie_helper
INFO - 2021-10-29 11:17:39 --> Model "CookieModel" initialized
INFO - 2021-10-29 11:17:39 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 11:17:39 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 11:17:39 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 11:17:39 --> Final output sent to browser
DEBUG - 2021-10-29 11:17:39 --> Total execution time: 0.0389
INFO - 2021-10-29 11:17:40 --> Config Class Initialized
INFO - 2021-10-29 11:17:40 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:17:40 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:17:40 --> Utf8 Class Initialized
INFO - 2021-10-29 11:17:40 --> URI Class Initialized
INFO - 2021-10-29 11:17:40 --> Router Class Initialized
INFO - 2021-10-29 11:17:40 --> Output Class Initialized
INFO - 2021-10-29 11:17:40 --> Security Class Initialized
DEBUG - 2021-10-29 11:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:17:40 --> Input Class Initialized
INFO - 2021-10-29 11:17:40 --> Language Class Initialized
ERROR - 2021-10-29 11:17:40 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 11:17:55 --> Config Class Initialized
INFO - 2021-10-29 11:17:55 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:17:55 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:17:55 --> Utf8 Class Initialized
INFO - 2021-10-29 11:17:55 --> URI Class Initialized
DEBUG - 2021-10-29 11:17:55 --> No URI present. Default controller set.
INFO - 2021-10-29 11:17:55 --> Router Class Initialized
INFO - 2021-10-29 11:17:55 --> Output Class Initialized
INFO - 2021-10-29 11:17:55 --> Security Class Initialized
DEBUG - 2021-10-29 11:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:17:55 --> Input Class Initialized
INFO - 2021-10-29 11:17:55 --> Language Class Initialized
INFO - 2021-10-29 11:17:55 --> Loader Class Initialized
INFO - 2021-10-29 11:17:55 --> Helper loaded: url_helper
INFO - 2021-10-29 11:17:55 --> Helper loaded: file_helper
DEBUG - 2021-10-29 11:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 11:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 11:17:56 --> Controller Class Initialized
INFO - 2021-10-29 11:17:56 --> Helper loaded: cookie_helper
INFO - 2021-10-29 11:17:56 --> Model "CookieModel" initialized
INFO - 2021-10-29 11:17:56 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 11:17:56 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 11:17:56 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 11:17:56 --> Final output sent to browser
DEBUG - 2021-10-29 11:17:56 --> Total execution time: 0.0411
INFO - 2021-10-29 11:17:56 --> Config Class Initialized
INFO - 2021-10-29 11:17:56 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:17:56 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:17:56 --> Utf8 Class Initialized
INFO - 2021-10-29 11:17:56 --> URI Class Initialized
INFO - 2021-10-29 11:17:56 --> Router Class Initialized
INFO - 2021-10-29 11:17:56 --> Output Class Initialized
INFO - 2021-10-29 11:17:56 --> Security Class Initialized
DEBUG - 2021-10-29 11:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:17:56 --> Input Class Initialized
INFO - 2021-10-29 11:17:56 --> Language Class Initialized
ERROR - 2021-10-29 11:17:56 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 11:19:59 --> Config Class Initialized
INFO - 2021-10-29 11:19:59 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:19:59 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:19:59 --> Utf8 Class Initialized
INFO - 2021-10-29 11:19:59 --> URI Class Initialized
INFO - 2021-10-29 11:19:59 --> Router Class Initialized
INFO - 2021-10-29 11:19:59 --> Output Class Initialized
INFO - 2021-10-29 11:19:59 --> Security Class Initialized
DEBUG - 2021-10-29 11:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:19:59 --> Input Class Initialized
INFO - 2021-10-29 11:19:59 --> Language Class Initialized
ERROR - 2021-10-29 11:19:59 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 11:34:46 --> Config Class Initialized
INFO - 2021-10-29 11:34:46 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:34:46 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:34:46 --> Utf8 Class Initialized
INFO - 2021-10-29 11:34:46 --> URI Class Initialized
DEBUG - 2021-10-29 11:34:46 --> No URI present. Default controller set.
INFO - 2021-10-29 11:34:46 --> Router Class Initialized
INFO - 2021-10-29 11:34:46 --> Output Class Initialized
INFO - 2021-10-29 11:34:46 --> Security Class Initialized
DEBUG - 2021-10-29 11:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:34:46 --> Input Class Initialized
INFO - 2021-10-29 11:34:46 --> Language Class Initialized
INFO - 2021-10-29 11:34:46 --> Loader Class Initialized
INFO - 2021-10-29 11:34:46 --> Helper loaded: url_helper
INFO - 2021-10-29 11:34:46 --> Helper loaded: file_helper
DEBUG - 2021-10-29 11:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 11:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 11:34:46 --> Controller Class Initialized
INFO - 2021-10-29 11:34:46 --> Helper loaded: cookie_helper
INFO - 2021-10-29 11:34:46 --> Model "CookieModel" initialized
INFO - 2021-10-29 11:34:46 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 11:34:46 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 11:34:46 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 11:34:46 --> Final output sent to browser
DEBUG - 2021-10-29 11:34:46 --> Total execution time: 0.0489
INFO - 2021-10-29 11:34:47 --> Config Class Initialized
INFO - 2021-10-29 11:34:47 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:34:47 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:34:47 --> Utf8 Class Initialized
INFO - 2021-10-29 11:34:47 --> URI Class Initialized
INFO - 2021-10-29 11:34:47 --> Router Class Initialized
INFO - 2021-10-29 11:34:47 --> Output Class Initialized
INFO - 2021-10-29 11:34:47 --> Security Class Initialized
DEBUG - 2021-10-29 11:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:34:47 --> Input Class Initialized
INFO - 2021-10-29 11:34:47 --> Language Class Initialized
ERROR - 2021-10-29 11:34:47 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 11:35:57 --> Config Class Initialized
INFO - 2021-10-29 11:35:57 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:35:57 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:35:57 --> Utf8 Class Initialized
INFO - 2021-10-29 11:35:57 --> URI Class Initialized
DEBUG - 2021-10-29 11:35:57 --> No URI present. Default controller set.
INFO - 2021-10-29 11:35:57 --> Router Class Initialized
INFO - 2021-10-29 11:35:57 --> Output Class Initialized
INFO - 2021-10-29 11:35:57 --> Security Class Initialized
DEBUG - 2021-10-29 11:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:35:57 --> Input Class Initialized
INFO - 2021-10-29 11:35:57 --> Language Class Initialized
INFO - 2021-10-29 11:35:57 --> Loader Class Initialized
INFO - 2021-10-29 11:35:57 --> Helper loaded: url_helper
INFO - 2021-10-29 11:35:57 --> Helper loaded: file_helper
DEBUG - 2021-10-29 11:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 11:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 11:35:57 --> Controller Class Initialized
INFO - 2021-10-29 11:35:57 --> Helper loaded: cookie_helper
INFO - 2021-10-29 11:35:57 --> Model "CookieModel" initialized
INFO - 2021-10-29 11:35:57 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 11:35:57 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 11:35:57 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 11:35:57 --> Final output sent to browser
DEBUG - 2021-10-29 11:35:57 --> Total execution time: 0.0307
INFO - 2021-10-29 11:35:58 --> Config Class Initialized
INFO - 2021-10-29 11:35:58 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:35:58 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:35:58 --> Utf8 Class Initialized
INFO - 2021-10-29 11:35:58 --> URI Class Initialized
INFO - 2021-10-29 11:35:58 --> Router Class Initialized
INFO - 2021-10-29 11:35:58 --> Output Class Initialized
INFO - 2021-10-29 11:35:58 --> Security Class Initialized
DEBUG - 2021-10-29 11:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:35:58 --> Input Class Initialized
INFO - 2021-10-29 11:35:58 --> Language Class Initialized
ERROR - 2021-10-29 11:35:58 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 11:36:13 --> Config Class Initialized
INFO - 2021-10-29 11:36:13 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:36:13 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:36:13 --> Utf8 Class Initialized
INFO - 2021-10-29 11:36:13 --> URI Class Initialized
DEBUG - 2021-10-29 11:36:13 --> No URI present. Default controller set.
INFO - 2021-10-29 11:36:13 --> Router Class Initialized
INFO - 2021-10-29 11:36:13 --> Output Class Initialized
INFO - 2021-10-29 11:36:13 --> Security Class Initialized
DEBUG - 2021-10-29 11:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:36:13 --> Input Class Initialized
INFO - 2021-10-29 11:36:13 --> Language Class Initialized
INFO - 2021-10-29 11:36:13 --> Loader Class Initialized
INFO - 2021-10-29 11:36:13 --> Helper loaded: url_helper
INFO - 2021-10-29 11:36:13 --> Helper loaded: file_helper
DEBUG - 2021-10-29 11:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 11:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 11:36:13 --> Controller Class Initialized
INFO - 2021-10-29 11:36:13 --> Helper loaded: cookie_helper
INFO - 2021-10-29 11:36:13 --> Model "CookieModel" initialized
INFO - 2021-10-29 11:36:13 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 11:36:13 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 11:36:13 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 11:36:13 --> Final output sent to browser
DEBUG - 2021-10-29 11:36:13 --> Total execution time: 0.0340
INFO - 2021-10-29 11:36:13 --> Config Class Initialized
INFO - 2021-10-29 11:36:13 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:36:13 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:36:13 --> Utf8 Class Initialized
INFO - 2021-10-29 11:36:13 --> URI Class Initialized
INFO - 2021-10-29 11:36:13 --> Router Class Initialized
INFO - 2021-10-29 11:36:13 --> Output Class Initialized
INFO - 2021-10-29 11:36:13 --> Security Class Initialized
DEBUG - 2021-10-29 11:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:36:13 --> Input Class Initialized
INFO - 2021-10-29 11:36:13 --> Language Class Initialized
ERROR - 2021-10-29 11:36:13 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 11:36:36 --> Config Class Initialized
INFO - 2021-10-29 11:36:36 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:36:36 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:36:36 --> Utf8 Class Initialized
INFO - 2021-10-29 11:36:36 --> URI Class Initialized
DEBUG - 2021-10-29 11:36:36 --> No URI present. Default controller set.
INFO - 2021-10-29 11:36:36 --> Router Class Initialized
INFO - 2021-10-29 11:36:36 --> Output Class Initialized
INFO - 2021-10-29 11:36:36 --> Security Class Initialized
DEBUG - 2021-10-29 11:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:36:36 --> Input Class Initialized
INFO - 2021-10-29 11:36:36 --> Language Class Initialized
INFO - 2021-10-29 11:36:36 --> Loader Class Initialized
INFO - 2021-10-29 11:36:36 --> Helper loaded: url_helper
INFO - 2021-10-29 11:36:36 --> Helper loaded: file_helper
DEBUG - 2021-10-29 11:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 11:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 11:36:36 --> Controller Class Initialized
INFO - 2021-10-29 11:36:36 --> Helper loaded: cookie_helper
INFO - 2021-10-29 11:36:36 --> Model "CookieModel" initialized
INFO - 2021-10-29 11:36:36 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 11:36:36 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 11:36:36 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 11:36:36 --> Final output sent to browser
DEBUG - 2021-10-29 11:36:36 --> Total execution time: 0.0350
INFO - 2021-10-29 11:36:36 --> Config Class Initialized
INFO - 2021-10-29 11:36:36 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:36:36 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:36:36 --> Utf8 Class Initialized
INFO - 2021-10-29 11:36:36 --> URI Class Initialized
INFO - 2021-10-29 11:36:36 --> Router Class Initialized
INFO - 2021-10-29 11:36:36 --> Output Class Initialized
INFO - 2021-10-29 11:36:36 --> Security Class Initialized
DEBUG - 2021-10-29 11:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:36:36 --> Input Class Initialized
INFO - 2021-10-29 11:36:36 --> Language Class Initialized
ERROR - 2021-10-29 11:36:36 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 11:36:43 --> Config Class Initialized
INFO - 2021-10-29 11:36:43 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:36:43 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:36:43 --> Utf8 Class Initialized
INFO - 2021-10-29 11:36:43 --> URI Class Initialized
DEBUG - 2021-10-29 11:36:43 --> No URI present. Default controller set.
INFO - 2021-10-29 11:36:43 --> Router Class Initialized
INFO - 2021-10-29 11:36:43 --> Output Class Initialized
INFO - 2021-10-29 11:36:43 --> Security Class Initialized
DEBUG - 2021-10-29 11:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:36:43 --> Input Class Initialized
INFO - 2021-10-29 11:36:43 --> Language Class Initialized
INFO - 2021-10-29 11:36:43 --> Loader Class Initialized
INFO - 2021-10-29 11:36:43 --> Helper loaded: url_helper
INFO - 2021-10-29 11:36:43 --> Helper loaded: file_helper
DEBUG - 2021-10-29 11:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 11:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 11:36:43 --> Controller Class Initialized
INFO - 2021-10-29 11:36:43 --> Helper loaded: cookie_helper
INFO - 2021-10-29 11:36:43 --> Model "CookieModel" initialized
INFO - 2021-10-29 11:36:43 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 11:36:43 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 11:36:43 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 11:36:43 --> Final output sent to browser
DEBUG - 2021-10-29 11:36:43 --> Total execution time: 0.0313
INFO - 2021-10-29 11:36:43 --> Config Class Initialized
INFO - 2021-10-29 11:36:43 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:36:43 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:36:43 --> Utf8 Class Initialized
INFO - 2021-10-29 11:36:43 --> URI Class Initialized
DEBUG - 2021-10-29 11:36:43 --> No URI present. Default controller set.
INFO - 2021-10-29 11:36:43 --> Router Class Initialized
INFO - 2021-10-29 11:36:43 --> Output Class Initialized
INFO - 2021-10-29 11:36:43 --> Security Class Initialized
DEBUG - 2021-10-29 11:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:36:43 --> Input Class Initialized
INFO - 2021-10-29 11:36:43 --> Language Class Initialized
INFO - 2021-10-29 11:36:43 --> Loader Class Initialized
INFO - 2021-10-29 11:36:43 --> Helper loaded: url_helper
INFO - 2021-10-29 11:36:43 --> Helper loaded: file_helper
DEBUG - 2021-10-29 11:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 11:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 11:36:43 --> Controller Class Initialized
INFO - 2021-10-29 11:36:43 --> Helper loaded: cookie_helper
INFO - 2021-10-29 11:36:43 --> Model "CookieModel" initialized
INFO - 2021-10-29 11:36:43 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 11:36:43 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 11:36:43 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 11:36:43 --> Final output sent to browser
DEBUG - 2021-10-29 11:36:43 --> Total execution time: 0.0401
INFO - 2021-10-29 11:36:43 --> Config Class Initialized
INFO - 2021-10-29 11:36:43 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:36:43 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:36:43 --> Utf8 Class Initialized
INFO - 2021-10-29 11:36:43 --> URI Class Initialized
INFO - 2021-10-29 11:36:43 --> Router Class Initialized
INFO - 2021-10-29 11:36:43 --> Output Class Initialized
INFO - 2021-10-29 11:36:43 --> Security Class Initialized
DEBUG - 2021-10-29 11:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:36:43 --> Input Class Initialized
INFO - 2021-10-29 11:36:43 --> Language Class Initialized
ERROR - 2021-10-29 11:36:43 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 11:36:45 --> Config Class Initialized
INFO - 2021-10-29 11:36:45 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:36:45 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:36:45 --> Utf8 Class Initialized
INFO - 2021-10-29 11:36:45 --> URI Class Initialized
DEBUG - 2021-10-29 11:36:45 --> No URI present. Default controller set.
INFO - 2021-10-29 11:36:45 --> Router Class Initialized
INFO - 2021-10-29 11:36:45 --> Output Class Initialized
INFO - 2021-10-29 11:36:45 --> Security Class Initialized
DEBUG - 2021-10-29 11:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:36:45 --> Input Class Initialized
INFO - 2021-10-29 11:36:45 --> Language Class Initialized
INFO - 2021-10-29 11:36:45 --> Loader Class Initialized
INFO - 2021-10-29 11:36:45 --> Helper loaded: url_helper
INFO - 2021-10-29 11:36:45 --> Helper loaded: file_helper
DEBUG - 2021-10-29 11:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 11:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 11:36:45 --> Controller Class Initialized
INFO - 2021-10-29 11:36:45 --> Helper loaded: cookie_helper
INFO - 2021-10-29 11:36:45 --> Model "CookieModel" initialized
INFO - 2021-10-29 11:36:45 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 11:36:45 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 11:36:45 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 11:36:45 --> Final output sent to browser
DEBUG - 2021-10-29 11:36:45 --> Total execution time: 0.0396
INFO - 2021-10-29 11:36:45 --> Config Class Initialized
INFO - 2021-10-29 11:36:45 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:36:45 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:36:45 --> Utf8 Class Initialized
INFO - 2021-10-29 11:36:45 --> URI Class Initialized
INFO - 2021-10-29 11:36:45 --> Router Class Initialized
INFO - 2021-10-29 11:36:45 --> Output Class Initialized
INFO - 2021-10-29 11:36:45 --> Security Class Initialized
DEBUG - 2021-10-29 11:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:36:45 --> Input Class Initialized
INFO - 2021-10-29 11:36:45 --> Language Class Initialized
ERROR - 2021-10-29 11:36:45 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 11:37:43 --> Config Class Initialized
INFO - 2021-10-29 11:37:43 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:37:43 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:37:43 --> Utf8 Class Initialized
INFO - 2021-10-29 11:37:43 --> URI Class Initialized
DEBUG - 2021-10-29 11:37:43 --> No URI present. Default controller set.
INFO - 2021-10-29 11:37:43 --> Router Class Initialized
INFO - 2021-10-29 11:37:43 --> Output Class Initialized
INFO - 2021-10-29 11:37:43 --> Security Class Initialized
DEBUG - 2021-10-29 11:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:37:43 --> Input Class Initialized
INFO - 2021-10-29 11:37:43 --> Language Class Initialized
INFO - 2021-10-29 11:37:43 --> Loader Class Initialized
INFO - 2021-10-29 11:37:43 --> Helper loaded: url_helper
INFO - 2021-10-29 11:37:43 --> Helper loaded: file_helper
DEBUG - 2021-10-29 11:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 11:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 11:37:43 --> Controller Class Initialized
INFO - 2021-10-29 11:37:43 --> Helper loaded: cookie_helper
INFO - 2021-10-29 11:37:43 --> Model "CookieModel" initialized
INFO - 2021-10-29 11:37:43 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 11:37:43 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 11:37:43 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 11:37:43 --> Final output sent to browser
DEBUG - 2021-10-29 11:37:43 --> Total execution time: 0.0303
INFO - 2021-10-29 11:37:43 --> Config Class Initialized
INFO - 2021-10-29 11:37:43 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:37:43 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:37:43 --> Utf8 Class Initialized
INFO - 2021-10-29 11:37:43 --> URI Class Initialized
INFO - 2021-10-29 11:37:43 --> Router Class Initialized
INFO - 2021-10-29 11:37:43 --> Output Class Initialized
INFO - 2021-10-29 11:37:43 --> Security Class Initialized
DEBUG - 2021-10-29 11:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:37:43 --> Input Class Initialized
INFO - 2021-10-29 11:37:43 --> Language Class Initialized
ERROR - 2021-10-29 11:37:43 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 11:39:47 --> Config Class Initialized
INFO - 2021-10-29 11:39:47 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:39:47 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:39:47 --> Utf8 Class Initialized
INFO - 2021-10-29 11:39:47 --> URI Class Initialized
DEBUG - 2021-10-29 11:39:47 --> No URI present. Default controller set.
INFO - 2021-10-29 11:39:47 --> Router Class Initialized
INFO - 2021-10-29 11:39:47 --> Output Class Initialized
INFO - 2021-10-29 11:39:47 --> Security Class Initialized
DEBUG - 2021-10-29 11:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:39:47 --> Input Class Initialized
INFO - 2021-10-29 11:39:47 --> Language Class Initialized
INFO - 2021-10-29 11:39:47 --> Loader Class Initialized
INFO - 2021-10-29 11:39:47 --> Helper loaded: url_helper
INFO - 2021-10-29 11:39:47 --> Helper loaded: file_helper
DEBUG - 2021-10-29 11:39:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 11:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 11:39:47 --> Controller Class Initialized
INFO - 2021-10-29 11:39:47 --> Helper loaded: cookie_helper
INFO - 2021-10-29 11:39:47 --> Model "CookieModel" initialized
INFO - 2021-10-29 11:39:47 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 11:39:47 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 11:39:47 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 11:39:47 --> Final output sent to browser
DEBUG - 2021-10-29 11:39:47 --> Total execution time: 0.0378
INFO - 2021-10-29 11:39:48 --> Config Class Initialized
INFO - 2021-10-29 11:39:48 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:39:48 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:39:48 --> Utf8 Class Initialized
INFO - 2021-10-29 11:39:48 --> URI Class Initialized
INFO - 2021-10-29 11:39:48 --> Router Class Initialized
INFO - 2021-10-29 11:39:48 --> Output Class Initialized
INFO - 2021-10-29 11:39:48 --> Security Class Initialized
DEBUG - 2021-10-29 11:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:39:48 --> Input Class Initialized
INFO - 2021-10-29 11:39:48 --> Language Class Initialized
ERROR - 2021-10-29 11:39:48 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 11:41:46 --> Config Class Initialized
INFO - 2021-10-29 11:41:46 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:41:46 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:41:46 --> Utf8 Class Initialized
INFO - 2021-10-29 11:41:46 --> URI Class Initialized
DEBUG - 2021-10-29 11:41:46 --> No URI present. Default controller set.
INFO - 2021-10-29 11:41:46 --> Router Class Initialized
INFO - 2021-10-29 11:41:46 --> Output Class Initialized
INFO - 2021-10-29 11:41:46 --> Security Class Initialized
DEBUG - 2021-10-29 11:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:41:46 --> Input Class Initialized
INFO - 2021-10-29 11:41:46 --> Language Class Initialized
INFO - 2021-10-29 11:41:46 --> Loader Class Initialized
INFO - 2021-10-29 11:41:46 --> Helper loaded: url_helper
INFO - 2021-10-29 11:41:46 --> Helper loaded: file_helper
DEBUG - 2021-10-29 11:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 11:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 11:41:46 --> Controller Class Initialized
INFO - 2021-10-29 11:41:46 --> Helper loaded: cookie_helper
INFO - 2021-10-29 11:41:46 --> Model "CookieModel" initialized
INFO - 2021-10-29 11:41:46 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 11:41:46 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 11:41:46 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 11:41:46 --> Final output sent to browser
DEBUG - 2021-10-29 11:41:46 --> Total execution time: 0.0308
INFO - 2021-10-29 11:41:46 --> Config Class Initialized
INFO - 2021-10-29 11:41:46 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:41:46 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:41:46 --> Utf8 Class Initialized
INFO - 2021-10-29 11:41:46 --> URI Class Initialized
INFO - 2021-10-29 11:41:46 --> Router Class Initialized
INFO - 2021-10-29 11:41:46 --> Output Class Initialized
INFO - 2021-10-29 11:41:46 --> Security Class Initialized
DEBUG - 2021-10-29 11:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:41:46 --> Input Class Initialized
INFO - 2021-10-29 11:41:46 --> Language Class Initialized
ERROR - 2021-10-29 11:41:46 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 11:41:48 --> Config Class Initialized
INFO - 2021-10-29 11:41:48 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:41:48 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:41:48 --> Utf8 Class Initialized
INFO - 2021-10-29 11:41:48 --> URI Class Initialized
DEBUG - 2021-10-29 11:41:48 --> No URI present. Default controller set.
INFO - 2021-10-29 11:41:48 --> Router Class Initialized
INFO - 2021-10-29 11:41:48 --> Output Class Initialized
INFO - 2021-10-29 11:41:48 --> Security Class Initialized
DEBUG - 2021-10-29 11:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:41:48 --> Input Class Initialized
INFO - 2021-10-29 11:41:48 --> Language Class Initialized
INFO - 2021-10-29 11:41:48 --> Loader Class Initialized
INFO - 2021-10-29 11:41:48 --> Helper loaded: url_helper
INFO - 2021-10-29 11:41:48 --> Helper loaded: file_helper
DEBUG - 2021-10-29 11:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 11:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 11:41:48 --> Controller Class Initialized
INFO - 2021-10-29 11:41:48 --> Helper loaded: cookie_helper
INFO - 2021-10-29 11:41:48 --> Model "CookieModel" initialized
INFO - 2021-10-29 11:41:48 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 11:41:48 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 11:41:48 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 11:41:48 --> Final output sent to browser
DEBUG - 2021-10-29 11:41:48 --> Total execution time: 0.0331
INFO - 2021-10-29 11:41:48 --> Config Class Initialized
INFO - 2021-10-29 11:41:48 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:41:48 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:41:48 --> Utf8 Class Initialized
INFO - 2021-10-29 11:41:48 --> URI Class Initialized
INFO - 2021-10-29 11:41:48 --> Router Class Initialized
INFO - 2021-10-29 11:41:48 --> Output Class Initialized
INFO - 2021-10-29 11:41:48 --> Security Class Initialized
DEBUG - 2021-10-29 11:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:41:48 --> Input Class Initialized
INFO - 2021-10-29 11:41:48 --> Language Class Initialized
ERROR - 2021-10-29 11:41:48 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 11:42:04 --> Config Class Initialized
INFO - 2021-10-29 11:42:04 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:42:04 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:42:04 --> Utf8 Class Initialized
INFO - 2021-10-29 11:42:04 --> URI Class Initialized
DEBUG - 2021-10-29 11:42:04 --> No URI present. Default controller set.
INFO - 2021-10-29 11:42:04 --> Router Class Initialized
INFO - 2021-10-29 11:42:04 --> Output Class Initialized
INFO - 2021-10-29 11:42:04 --> Security Class Initialized
DEBUG - 2021-10-29 11:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:42:04 --> Input Class Initialized
INFO - 2021-10-29 11:42:04 --> Language Class Initialized
INFO - 2021-10-29 11:42:04 --> Loader Class Initialized
INFO - 2021-10-29 11:42:04 --> Helper loaded: url_helper
INFO - 2021-10-29 11:42:04 --> Helper loaded: file_helper
DEBUG - 2021-10-29 11:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 11:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 11:42:04 --> Controller Class Initialized
INFO - 2021-10-29 11:42:04 --> Helper loaded: cookie_helper
INFO - 2021-10-29 11:42:04 --> Model "CookieModel" initialized
INFO - 2021-10-29 11:42:04 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 11:42:04 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 11:42:04 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 11:42:04 --> Final output sent to browser
DEBUG - 2021-10-29 11:42:04 --> Total execution time: 0.0434
INFO - 2021-10-29 11:42:04 --> Config Class Initialized
INFO - 2021-10-29 11:42:04 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:42:04 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:42:04 --> Utf8 Class Initialized
INFO - 2021-10-29 11:42:04 --> URI Class Initialized
INFO - 2021-10-29 11:42:04 --> Router Class Initialized
INFO - 2021-10-29 11:42:04 --> Output Class Initialized
INFO - 2021-10-29 11:42:04 --> Security Class Initialized
DEBUG - 2021-10-29 11:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:42:04 --> Input Class Initialized
INFO - 2021-10-29 11:42:04 --> Language Class Initialized
ERROR - 2021-10-29 11:42:04 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 11:57:50 --> Config Class Initialized
INFO - 2021-10-29 11:57:50 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:57:50 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:57:50 --> Utf8 Class Initialized
INFO - 2021-10-29 11:57:50 --> URI Class Initialized
DEBUG - 2021-10-29 11:57:50 --> No URI present. Default controller set.
INFO - 2021-10-29 11:57:50 --> Router Class Initialized
INFO - 2021-10-29 11:57:50 --> Output Class Initialized
INFO - 2021-10-29 11:57:50 --> Security Class Initialized
DEBUG - 2021-10-29 11:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:57:50 --> Input Class Initialized
INFO - 2021-10-29 11:57:50 --> Language Class Initialized
INFO - 2021-10-29 11:57:50 --> Loader Class Initialized
INFO - 2021-10-29 11:57:50 --> Helper loaded: url_helper
INFO - 2021-10-29 11:57:50 --> Helper loaded: file_helper
DEBUG - 2021-10-29 11:57:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 11:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 11:57:50 --> Controller Class Initialized
INFO - 2021-10-29 11:57:50 --> Helper loaded: cookie_helper
INFO - 2021-10-29 11:57:50 --> Model "CookieModel" initialized
INFO - 2021-10-29 11:57:50 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 11:57:50 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 11:57:50 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 11:57:50 --> Final output sent to browser
DEBUG - 2021-10-29 11:57:50 --> Total execution time: 0.8288
INFO - 2021-10-29 11:57:51 --> Config Class Initialized
INFO - 2021-10-29 11:57:51 --> Hooks Class Initialized
DEBUG - 2021-10-29 11:57:51 --> UTF-8 Support Enabled
INFO - 2021-10-29 11:57:51 --> Utf8 Class Initialized
INFO - 2021-10-29 11:57:51 --> URI Class Initialized
INFO - 2021-10-29 11:57:51 --> Router Class Initialized
INFO - 2021-10-29 11:57:51 --> Output Class Initialized
INFO - 2021-10-29 11:57:51 --> Security Class Initialized
DEBUG - 2021-10-29 11:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 11:57:51 --> Input Class Initialized
INFO - 2021-10-29 11:57:51 --> Language Class Initialized
ERROR - 2021-10-29 11:57:51 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 12:11:52 --> Config Class Initialized
INFO - 2021-10-29 12:11:52 --> Hooks Class Initialized
DEBUG - 2021-10-29 12:11:52 --> UTF-8 Support Enabled
INFO - 2021-10-29 12:11:52 --> Utf8 Class Initialized
INFO - 2021-10-29 12:11:52 --> URI Class Initialized
DEBUG - 2021-10-29 12:11:52 --> No URI present. Default controller set.
INFO - 2021-10-29 12:11:52 --> Router Class Initialized
INFO - 2021-10-29 12:11:52 --> Output Class Initialized
INFO - 2021-10-29 12:11:52 --> Security Class Initialized
DEBUG - 2021-10-29 12:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 12:11:52 --> Input Class Initialized
INFO - 2021-10-29 12:11:52 --> Language Class Initialized
INFO - 2021-10-29 12:11:52 --> Loader Class Initialized
INFO - 2021-10-29 12:11:52 --> Helper loaded: url_helper
INFO - 2021-10-29 12:11:52 --> Helper loaded: file_helper
DEBUG - 2021-10-29 12:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 12:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 12:11:52 --> Controller Class Initialized
INFO - 2021-10-29 12:11:52 --> Helper loaded: cookie_helper
INFO - 2021-10-29 12:11:52 --> Model "CookieModel" initialized
INFO - 2021-10-29 12:11:52 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 12:11:52 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 12:11:52 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 12:11:52 --> Final output sent to browser
DEBUG - 2021-10-29 12:11:52 --> Total execution time: 0.0629
INFO - 2021-10-29 12:11:52 --> Config Class Initialized
INFO - 2021-10-29 12:11:52 --> Hooks Class Initialized
DEBUG - 2021-10-29 12:11:52 --> UTF-8 Support Enabled
INFO - 2021-10-29 12:11:52 --> Utf8 Class Initialized
INFO - 2021-10-29 12:11:52 --> URI Class Initialized
INFO - 2021-10-29 12:11:52 --> Router Class Initialized
INFO - 2021-10-29 12:11:52 --> Output Class Initialized
INFO - 2021-10-29 12:11:52 --> Security Class Initialized
DEBUG - 2021-10-29 12:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 12:11:52 --> Input Class Initialized
INFO - 2021-10-29 12:11:52 --> Language Class Initialized
ERROR - 2021-10-29 12:11:52 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 12:11:59 --> Config Class Initialized
INFO - 2021-10-29 12:11:59 --> Hooks Class Initialized
DEBUG - 2021-10-29 12:11:59 --> UTF-8 Support Enabled
INFO - 2021-10-29 12:11:59 --> Utf8 Class Initialized
INFO - 2021-10-29 12:11:59 --> URI Class Initialized
DEBUG - 2021-10-29 12:11:59 --> No URI present. Default controller set.
INFO - 2021-10-29 12:11:59 --> Router Class Initialized
INFO - 2021-10-29 12:11:59 --> Output Class Initialized
INFO - 2021-10-29 12:11:59 --> Security Class Initialized
DEBUG - 2021-10-29 12:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 12:11:59 --> Input Class Initialized
INFO - 2021-10-29 12:11:59 --> Language Class Initialized
INFO - 2021-10-29 12:11:59 --> Loader Class Initialized
INFO - 2021-10-29 12:11:59 --> Helper loaded: url_helper
INFO - 2021-10-29 12:11:59 --> Helper loaded: file_helper
DEBUG - 2021-10-29 12:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 12:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 12:11:59 --> Controller Class Initialized
INFO - 2021-10-29 12:11:59 --> Helper loaded: cookie_helper
INFO - 2021-10-29 12:11:59 --> Model "CookieModel" initialized
INFO - 2021-10-29 12:11:59 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 12:11:59 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 12:11:59 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 12:11:59 --> Final output sent to browser
DEBUG - 2021-10-29 12:11:59 --> Total execution time: 0.0519
INFO - 2021-10-29 12:12:00 --> Config Class Initialized
INFO - 2021-10-29 12:12:00 --> Hooks Class Initialized
DEBUG - 2021-10-29 12:12:00 --> UTF-8 Support Enabled
INFO - 2021-10-29 12:12:00 --> Utf8 Class Initialized
INFO - 2021-10-29 12:12:00 --> URI Class Initialized
INFO - 2021-10-29 12:12:00 --> Router Class Initialized
INFO - 2021-10-29 12:12:00 --> Output Class Initialized
INFO - 2021-10-29 12:12:00 --> Security Class Initialized
DEBUG - 2021-10-29 12:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 12:12:00 --> Input Class Initialized
INFO - 2021-10-29 12:12:00 --> Language Class Initialized
ERROR - 2021-10-29 12:12:00 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 12:12:30 --> Config Class Initialized
INFO - 2021-10-29 12:12:30 --> Hooks Class Initialized
DEBUG - 2021-10-29 12:12:30 --> UTF-8 Support Enabled
INFO - 2021-10-29 12:12:30 --> Utf8 Class Initialized
INFO - 2021-10-29 12:12:30 --> URI Class Initialized
DEBUG - 2021-10-29 12:12:30 --> No URI present. Default controller set.
INFO - 2021-10-29 12:12:30 --> Router Class Initialized
INFO - 2021-10-29 12:12:30 --> Output Class Initialized
INFO - 2021-10-29 12:12:30 --> Security Class Initialized
DEBUG - 2021-10-29 12:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 12:12:30 --> Input Class Initialized
INFO - 2021-10-29 12:12:30 --> Language Class Initialized
INFO - 2021-10-29 12:12:30 --> Loader Class Initialized
INFO - 2021-10-29 12:12:30 --> Helper loaded: url_helper
INFO - 2021-10-29 12:12:30 --> Helper loaded: file_helper
DEBUG - 2021-10-29 12:12:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 12:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 12:12:30 --> Controller Class Initialized
INFO - 2021-10-29 12:12:30 --> Helper loaded: cookie_helper
INFO - 2021-10-29 12:12:30 --> Model "CookieModel" initialized
INFO - 2021-10-29 12:12:30 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 12:12:30 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 12:12:30 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 12:12:30 --> Final output sent to browser
DEBUG - 2021-10-29 12:12:30 --> Total execution time: 0.0839
INFO - 2021-10-29 12:12:30 --> Config Class Initialized
INFO - 2021-10-29 12:12:30 --> Hooks Class Initialized
DEBUG - 2021-10-29 12:12:30 --> UTF-8 Support Enabled
INFO - 2021-10-29 12:12:30 --> Utf8 Class Initialized
INFO - 2021-10-29 12:12:30 --> URI Class Initialized
INFO - 2021-10-29 12:12:30 --> Router Class Initialized
INFO - 2021-10-29 12:12:30 --> Output Class Initialized
INFO - 2021-10-29 12:12:30 --> Security Class Initialized
DEBUG - 2021-10-29 12:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 12:12:30 --> Input Class Initialized
INFO - 2021-10-29 12:12:30 --> Language Class Initialized
ERROR - 2021-10-29 12:12:30 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 12:12:32 --> Config Class Initialized
INFO - 2021-10-29 12:12:32 --> Hooks Class Initialized
DEBUG - 2021-10-29 12:12:32 --> UTF-8 Support Enabled
INFO - 2021-10-29 12:12:32 --> Utf8 Class Initialized
INFO - 2021-10-29 12:12:32 --> URI Class Initialized
DEBUG - 2021-10-29 12:12:32 --> No URI present. Default controller set.
INFO - 2021-10-29 12:12:32 --> Router Class Initialized
INFO - 2021-10-29 12:12:32 --> Output Class Initialized
INFO - 2021-10-29 12:12:32 --> Security Class Initialized
DEBUG - 2021-10-29 12:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 12:12:32 --> Input Class Initialized
INFO - 2021-10-29 12:12:32 --> Language Class Initialized
INFO - 2021-10-29 12:12:32 --> Loader Class Initialized
INFO - 2021-10-29 12:12:32 --> Helper loaded: url_helper
INFO - 2021-10-29 12:12:32 --> Helper loaded: file_helper
DEBUG - 2021-10-29 12:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 12:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 12:12:32 --> Controller Class Initialized
INFO - 2021-10-29 12:12:32 --> Helper loaded: cookie_helper
INFO - 2021-10-29 12:12:32 --> Model "CookieModel" initialized
INFO - 2021-10-29 12:12:32 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 12:12:32 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 12:12:32 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 12:12:32 --> Final output sent to browser
DEBUG - 2021-10-29 12:12:32 --> Total execution time: 0.0580
INFO - 2021-10-29 12:12:32 --> Config Class Initialized
INFO - 2021-10-29 12:12:32 --> Hooks Class Initialized
DEBUG - 2021-10-29 12:12:32 --> UTF-8 Support Enabled
INFO - 2021-10-29 12:12:32 --> Utf8 Class Initialized
INFO - 2021-10-29 12:12:32 --> URI Class Initialized
INFO - 2021-10-29 12:12:32 --> Router Class Initialized
INFO - 2021-10-29 12:12:32 --> Output Class Initialized
INFO - 2021-10-29 12:12:32 --> Security Class Initialized
DEBUG - 2021-10-29 12:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 12:12:32 --> Input Class Initialized
INFO - 2021-10-29 12:12:32 --> Language Class Initialized
ERROR - 2021-10-29 12:12:32 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 12:13:24 --> Config Class Initialized
INFO - 2021-10-29 12:13:24 --> Hooks Class Initialized
DEBUG - 2021-10-29 12:13:24 --> UTF-8 Support Enabled
INFO - 2021-10-29 12:13:24 --> Utf8 Class Initialized
INFO - 2021-10-29 12:13:24 --> URI Class Initialized
DEBUG - 2021-10-29 12:13:24 --> No URI present. Default controller set.
INFO - 2021-10-29 12:13:24 --> Router Class Initialized
INFO - 2021-10-29 12:13:24 --> Output Class Initialized
INFO - 2021-10-29 12:13:24 --> Security Class Initialized
DEBUG - 2021-10-29 12:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 12:13:24 --> Input Class Initialized
INFO - 2021-10-29 12:13:24 --> Language Class Initialized
INFO - 2021-10-29 12:13:24 --> Loader Class Initialized
INFO - 2021-10-29 12:13:24 --> Helper loaded: url_helper
INFO - 2021-10-29 12:13:24 --> Helper loaded: file_helper
DEBUG - 2021-10-29 12:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 12:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 12:13:24 --> Controller Class Initialized
INFO - 2021-10-29 12:13:24 --> Helper loaded: cookie_helper
INFO - 2021-10-29 12:13:24 --> Model "CookieModel" initialized
INFO - 2021-10-29 12:13:24 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 12:13:24 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 12:13:24 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 12:13:24 --> Final output sent to browser
DEBUG - 2021-10-29 12:13:24 --> Total execution time: 0.0356
INFO - 2021-10-29 12:13:25 --> Config Class Initialized
INFO - 2021-10-29 12:13:25 --> Hooks Class Initialized
DEBUG - 2021-10-29 12:13:25 --> UTF-8 Support Enabled
INFO - 2021-10-29 12:13:25 --> Utf8 Class Initialized
INFO - 2021-10-29 12:13:25 --> URI Class Initialized
INFO - 2021-10-29 12:13:25 --> Router Class Initialized
INFO - 2021-10-29 12:13:25 --> Output Class Initialized
INFO - 2021-10-29 12:13:25 --> Security Class Initialized
DEBUG - 2021-10-29 12:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 12:13:25 --> Input Class Initialized
INFO - 2021-10-29 12:13:25 --> Language Class Initialized
ERROR - 2021-10-29 12:13:25 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 12:15:11 --> Config Class Initialized
INFO - 2021-10-29 12:15:11 --> Hooks Class Initialized
DEBUG - 2021-10-29 12:15:11 --> UTF-8 Support Enabled
INFO - 2021-10-29 12:15:11 --> Utf8 Class Initialized
INFO - 2021-10-29 12:15:11 --> URI Class Initialized
DEBUG - 2021-10-29 12:15:11 --> No URI present. Default controller set.
INFO - 2021-10-29 12:15:11 --> Router Class Initialized
INFO - 2021-10-29 12:15:11 --> Output Class Initialized
INFO - 2021-10-29 12:15:11 --> Security Class Initialized
DEBUG - 2021-10-29 12:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 12:15:11 --> Input Class Initialized
INFO - 2021-10-29 12:15:11 --> Language Class Initialized
INFO - 2021-10-29 12:15:11 --> Loader Class Initialized
INFO - 2021-10-29 12:15:11 --> Helper loaded: url_helper
INFO - 2021-10-29 12:15:11 --> Helper loaded: file_helper
DEBUG - 2021-10-29 12:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 12:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 12:15:11 --> Controller Class Initialized
INFO - 2021-10-29 12:15:11 --> Helper loaded: cookie_helper
INFO - 2021-10-29 12:15:11 --> Model "CookieModel" initialized
INFO - 2021-10-29 12:15:11 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 12:15:11 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 12:15:11 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 12:15:11 --> Final output sent to browser
DEBUG - 2021-10-29 12:15:11 --> Total execution time: 0.0454
INFO - 2021-10-29 12:15:11 --> Config Class Initialized
INFO - 2021-10-29 12:15:11 --> Hooks Class Initialized
DEBUG - 2021-10-29 12:15:11 --> UTF-8 Support Enabled
INFO - 2021-10-29 12:15:11 --> Utf8 Class Initialized
INFO - 2021-10-29 12:15:11 --> URI Class Initialized
INFO - 2021-10-29 12:15:11 --> Router Class Initialized
INFO - 2021-10-29 12:15:11 --> Output Class Initialized
INFO - 2021-10-29 12:15:11 --> Security Class Initialized
DEBUG - 2021-10-29 12:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 12:15:11 --> Input Class Initialized
INFO - 2021-10-29 12:15:11 --> Language Class Initialized
ERROR - 2021-10-29 12:15:11 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 12:16:13 --> Config Class Initialized
INFO - 2021-10-29 12:16:13 --> Hooks Class Initialized
DEBUG - 2021-10-29 12:16:13 --> UTF-8 Support Enabled
INFO - 2021-10-29 12:16:13 --> Utf8 Class Initialized
INFO - 2021-10-29 12:16:13 --> URI Class Initialized
DEBUG - 2021-10-29 12:16:13 --> No URI present. Default controller set.
INFO - 2021-10-29 12:16:13 --> Router Class Initialized
INFO - 2021-10-29 12:16:13 --> Output Class Initialized
INFO - 2021-10-29 12:16:13 --> Security Class Initialized
DEBUG - 2021-10-29 12:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 12:16:13 --> Input Class Initialized
INFO - 2021-10-29 12:16:13 --> Language Class Initialized
INFO - 2021-10-29 12:16:13 --> Loader Class Initialized
INFO - 2021-10-29 12:16:13 --> Helper loaded: url_helper
INFO - 2021-10-29 12:16:13 --> Helper loaded: file_helper
DEBUG - 2021-10-29 12:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 12:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 12:16:13 --> Controller Class Initialized
INFO - 2021-10-29 12:16:13 --> Helper loaded: cookie_helper
INFO - 2021-10-29 12:16:13 --> Model "CookieModel" initialized
INFO - 2021-10-29 12:16:13 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 12:16:13 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 12:16:13 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 12:16:13 --> Final output sent to browser
DEBUG - 2021-10-29 12:16:13 --> Total execution time: 0.0492
INFO - 2021-10-29 12:16:14 --> Config Class Initialized
INFO - 2021-10-29 12:16:14 --> Hooks Class Initialized
DEBUG - 2021-10-29 12:16:14 --> UTF-8 Support Enabled
INFO - 2021-10-29 12:16:14 --> Utf8 Class Initialized
INFO - 2021-10-29 12:16:14 --> URI Class Initialized
INFO - 2021-10-29 12:16:14 --> Router Class Initialized
INFO - 2021-10-29 12:16:14 --> Output Class Initialized
INFO - 2021-10-29 12:16:14 --> Security Class Initialized
DEBUG - 2021-10-29 12:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 12:16:14 --> Input Class Initialized
INFO - 2021-10-29 12:16:14 --> Language Class Initialized
ERROR - 2021-10-29 12:16:14 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 12:16:55 --> Config Class Initialized
INFO - 2021-10-29 12:16:55 --> Hooks Class Initialized
DEBUG - 2021-10-29 12:16:55 --> UTF-8 Support Enabled
INFO - 2021-10-29 12:16:55 --> Utf8 Class Initialized
INFO - 2021-10-29 12:16:55 --> URI Class Initialized
DEBUG - 2021-10-29 12:16:55 --> No URI present. Default controller set.
INFO - 2021-10-29 12:16:55 --> Router Class Initialized
INFO - 2021-10-29 12:16:55 --> Output Class Initialized
INFO - 2021-10-29 12:16:55 --> Security Class Initialized
DEBUG - 2021-10-29 12:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 12:16:55 --> Input Class Initialized
INFO - 2021-10-29 12:16:55 --> Language Class Initialized
INFO - 2021-10-29 12:16:55 --> Loader Class Initialized
INFO - 2021-10-29 12:16:55 --> Helper loaded: url_helper
INFO - 2021-10-29 12:16:55 --> Helper loaded: file_helper
DEBUG - 2021-10-29 12:16:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 12:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 12:16:55 --> Controller Class Initialized
INFO - 2021-10-29 12:16:55 --> Helper loaded: cookie_helper
INFO - 2021-10-29 12:16:55 --> Model "CookieModel" initialized
INFO - 2021-10-29 12:16:55 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 12:16:55 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 12:16:55 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 12:16:55 --> Final output sent to browser
DEBUG - 2021-10-29 12:16:55 --> Total execution time: 0.0529
INFO - 2021-10-29 12:16:55 --> Config Class Initialized
INFO - 2021-10-29 12:16:55 --> Hooks Class Initialized
DEBUG - 2021-10-29 12:16:55 --> UTF-8 Support Enabled
INFO - 2021-10-29 12:16:55 --> Utf8 Class Initialized
INFO - 2021-10-29 12:16:55 --> URI Class Initialized
INFO - 2021-10-29 12:16:55 --> Router Class Initialized
INFO - 2021-10-29 12:16:55 --> Output Class Initialized
INFO - 2021-10-29 12:16:55 --> Security Class Initialized
DEBUG - 2021-10-29 12:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 12:16:55 --> Input Class Initialized
INFO - 2021-10-29 12:16:55 --> Language Class Initialized
ERROR - 2021-10-29 12:16:55 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 12:17:08 --> Config Class Initialized
INFO - 2021-10-29 12:17:08 --> Hooks Class Initialized
DEBUG - 2021-10-29 12:17:08 --> UTF-8 Support Enabled
INFO - 2021-10-29 12:17:08 --> Utf8 Class Initialized
INFO - 2021-10-29 12:17:08 --> URI Class Initialized
DEBUG - 2021-10-29 12:17:08 --> No URI present. Default controller set.
INFO - 2021-10-29 12:17:08 --> Router Class Initialized
INFO - 2021-10-29 12:17:08 --> Output Class Initialized
INFO - 2021-10-29 12:17:08 --> Security Class Initialized
DEBUG - 2021-10-29 12:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 12:17:08 --> Input Class Initialized
INFO - 2021-10-29 12:17:08 --> Language Class Initialized
INFO - 2021-10-29 12:17:08 --> Loader Class Initialized
INFO - 2021-10-29 12:17:08 --> Helper loaded: url_helper
INFO - 2021-10-29 12:17:08 --> Helper loaded: file_helper
DEBUG - 2021-10-29 12:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 12:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 12:17:08 --> Controller Class Initialized
INFO - 2021-10-29 12:17:08 --> Helper loaded: cookie_helper
INFO - 2021-10-29 12:17:08 --> Model "CookieModel" initialized
INFO - 2021-10-29 12:17:08 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 12:17:08 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 12:17:08 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 12:17:08 --> Final output sent to browser
DEBUG - 2021-10-29 12:17:08 --> Total execution time: 0.0350
INFO - 2021-10-29 12:17:08 --> Config Class Initialized
INFO - 2021-10-29 12:17:08 --> Hooks Class Initialized
DEBUG - 2021-10-29 12:17:08 --> UTF-8 Support Enabled
INFO - 2021-10-29 12:17:08 --> Utf8 Class Initialized
INFO - 2021-10-29 12:17:08 --> URI Class Initialized
INFO - 2021-10-29 12:17:08 --> Router Class Initialized
INFO - 2021-10-29 12:17:08 --> Output Class Initialized
INFO - 2021-10-29 12:17:08 --> Security Class Initialized
DEBUG - 2021-10-29 12:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 12:17:08 --> Input Class Initialized
INFO - 2021-10-29 12:17:08 --> Language Class Initialized
ERROR - 2021-10-29 12:17:08 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 12:17:10 --> Config Class Initialized
INFO - 2021-10-29 12:17:10 --> Hooks Class Initialized
DEBUG - 2021-10-29 12:17:10 --> UTF-8 Support Enabled
INFO - 2021-10-29 12:17:10 --> Utf8 Class Initialized
INFO - 2021-10-29 12:17:10 --> URI Class Initialized
DEBUG - 2021-10-29 12:17:10 --> No URI present. Default controller set.
INFO - 2021-10-29 12:17:10 --> Router Class Initialized
INFO - 2021-10-29 12:17:10 --> Output Class Initialized
INFO - 2021-10-29 12:17:10 --> Security Class Initialized
DEBUG - 2021-10-29 12:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 12:17:10 --> Input Class Initialized
INFO - 2021-10-29 12:17:10 --> Language Class Initialized
INFO - 2021-10-29 12:17:10 --> Loader Class Initialized
INFO - 2021-10-29 12:17:10 --> Helper loaded: url_helper
INFO - 2021-10-29 12:17:10 --> Helper loaded: file_helper
DEBUG - 2021-10-29 12:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 12:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 12:17:10 --> Controller Class Initialized
INFO - 2021-10-29 12:17:10 --> Helper loaded: cookie_helper
INFO - 2021-10-29 12:17:10 --> Model "CookieModel" initialized
INFO - 2021-10-29 12:17:10 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 12:17:10 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 12:17:10 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 12:17:10 --> Final output sent to browser
DEBUG - 2021-10-29 12:17:10 --> Total execution time: 0.0329
INFO - 2021-10-29 12:17:10 --> Config Class Initialized
INFO - 2021-10-29 12:17:10 --> Hooks Class Initialized
DEBUG - 2021-10-29 12:17:10 --> UTF-8 Support Enabled
INFO - 2021-10-29 12:17:10 --> Utf8 Class Initialized
INFO - 2021-10-29 12:17:10 --> URI Class Initialized
INFO - 2021-10-29 12:17:10 --> Router Class Initialized
INFO - 2021-10-29 12:17:10 --> Output Class Initialized
INFO - 2021-10-29 12:17:10 --> Security Class Initialized
DEBUG - 2021-10-29 12:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 12:17:10 --> Input Class Initialized
INFO - 2021-10-29 12:17:10 --> Language Class Initialized
ERROR - 2021-10-29 12:17:10 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 12:19:19 --> Config Class Initialized
INFO - 2021-10-29 12:19:19 --> Hooks Class Initialized
DEBUG - 2021-10-29 12:19:19 --> UTF-8 Support Enabled
INFO - 2021-10-29 12:19:19 --> Utf8 Class Initialized
INFO - 2021-10-29 12:19:19 --> URI Class Initialized
DEBUG - 2021-10-29 12:19:19 --> No URI present. Default controller set.
INFO - 2021-10-29 12:19:19 --> Router Class Initialized
INFO - 2021-10-29 12:19:19 --> Output Class Initialized
INFO - 2021-10-29 12:19:19 --> Security Class Initialized
DEBUG - 2021-10-29 12:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 12:19:19 --> Input Class Initialized
INFO - 2021-10-29 12:19:19 --> Language Class Initialized
INFO - 2021-10-29 12:19:19 --> Loader Class Initialized
INFO - 2021-10-29 12:19:19 --> Helper loaded: url_helper
INFO - 2021-10-29 12:19:19 --> Helper loaded: file_helper
DEBUG - 2021-10-29 12:19:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 12:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 12:19:19 --> Controller Class Initialized
INFO - 2021-10-29 12:19:19 --> Helper loaded: cookie_helper
INFO - 2021-10-29 12:19:19 --> Model "CookieModel" initialized
INFO - 2021-10-29 12:19:19 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 12:19:19 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 12:19:19 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 12:19:19 --> Final output sent to browser
DEBUG - 2021-10-29 12:19:19 --> Total execution time: 0.0465
INFO - 2021-10-29 12:19:19 --> Config Class Initialized
INFO - 2021-10-29 12:19:19 --> Hooks Class Initialized
DEBUG - 2021-10-29 12:19:19 --> UTF-8 Support Enabled
INFO - 2021-10-29 12:19:19 --> Utf8 Class Initialized
INFO - 2021-10-29 12:19:19 --> URI Class Initialized
INFO - 2021-10-29 12:19:19 --> Router Class Initialized
INFO - 2021-10-29 12:19:19 --> Output Class Initialized
INFO - 2021-10-29 12:19:19 --> Security Class Initialized
DEBUG - 2021-10-29 12:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 12:19:19 --> Input Class Initialized
INFO - 2021-10-29 12:19:19 --> Language Class Initialized
ERROR - 2021-10-29 12:19:19 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 12:19:32 --> Config Class Initialized
INFO - 2021-10-29 12:19:32 --> Hooks Class Initialized
DEBUG - 2021-10-29 12:19:32 --> UTF-8 Support Enabled
INFO - 2021-10-29 12:19:32 --> Utf8 Class Initialized
INFO - 2021-10-29 12:19:32 --> URI Class Initialized
DEBUG - 2021-10-29 12:19:32 --> No URI present. Default controller set.
INFO - 2021-10-29 12:19:32 --> Router Class Initialized
INFO - 2021-10-29 12:19:32 --> Output Class Initialized
INFO - 2021-10-29 12:19:32 --> Security Class Initialized
DEBUG - 2021-10-29 12:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 12:19:32 --> Input Class Initialized
INFO - 2021-10-29 12:19:32 --> Language Class Initialized
INFO - 2021-10-29 12:19:32 --> Loader Class Initialized
INFO - 2021-10-29 12:19:32 --> Helper loaded: url_helper
INFO - 2021-10-29 12:19:32 --> Helper loaded: file_helper
DEBUG - 2021-10-29 12:19:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 12:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 12:19:32 --> Controller Class Initialized
INFO - 2021-10-29 12:19:32 --> Helper loaded: cookie_helper
INFO - 2021-10-29 12:19:32 --> Model "CookieModel" initialized
INFO - 2021-10-29 12:19:32 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 12:19:32 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 12:19:32 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 12:19:32 --> Final output sent to browser
DEBUG - 2021-10-29 12:19:32 --> Total execution time: 0.0515
INFO - 2021-10-29 12:19:33 --> Config Class Initialized
INFO - 2021-10-29 12:19:33 --> Hooks Class Initialized
DEBUG - 2021-10-29 12:19:33 --> UTF-8 Support Enabled
INFO - 2021-10-29 12:19:33 --> Utf8 Class Initialized
INFO - 2021-10-29 12:19:33 --> URI Class Initialized
INFO - 2021-10-29 12:19:33 --> Router Class Initialized
INFO - 2021-10-29 12:19:33 --> Output Class Initialized
INFO - 2021-10-29 12:19:33 --> Security Class Initialized
DEBUG - 2021-10-29 12:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 12:19:33 --> Input Class Initialized
INFO - 2021-10-29 12:19:33 --> Language Class Initialized
ERROR - 2021-10-29 12:19:33 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 12:21:54 --> Config Class Initialized
INFO - 2021-10-29 12:21:54 --> Hooks Class Initialized
DEBUG - 2021-10-29 12:21:54 --> UTF-8 Support Enabled
INFO - 2021-10-29 12:21:54 --> Utf8 Class Initialized
INFO - 2021-10-29 12:21:54 --> URI Class Initialized
DEBUG - 2021-10-29 12:21:54 --> No URI present. Default controller set.
INFO - 2021-10-29 12:21:54 --> Router Class Initialized
INFO - 2021-10-29 12:21:54 --> Output Class Initialized
INFO - 2021-10-29 12:21:54 --> Security Class Initialized
DEBUG - 2021-10-29 12:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 12:21:54 --> Input Class Initialized
INFO - 2021-10-29 12:21:54 --> Language Class Initialized
INFO - 2021-10-29 12:21:54 --> Loader Class Initialized
INFO - 2021-10-29 12:21:54 --> Helper loaded: url_helper
INFO - 2021-10-29 12:21:54 --> Helper loaded: file_helper
DEBUG - 2021-10-29 12:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 12:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 12:21:54 --> Controller Class Initialized
INFO - 2021-10-29 12:21:54 --> Helper loaded: cookie_helper
INFO - 2021-10-29 12:21:54 --> Model "CookieModel" initialized
INFO - 2021-10-29 12:21:54 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 12:21:54 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 12:21:54 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 12:21:54 --> Final output sent to browser
DEBUG - 2021-10-29 12:21:54 --> Total execution time: 0.0466
INFO - 2021-10-29 12:21:55 --> Config Class Initialized
INFO - 2021-10-29 12:21:55 --> Hooks Class Initialized
DEBUG - 2021-10-29 12:21:55 --> UTF-8 Support Enabled
INFO - 2021-10-29 12:21:55 --> Utf8 Class Initialized
INFO - 2021-10-29 12:21:55 --> URI Class Initialized
INFO - 2021-10-29 12:21:55 --> Router Class Initialized
INFO - 2021-10-29 12:21:55 --> Output Class Initialized
INFO - 2021-10-29 12:21:55 --> Security Class Initialized
DEBUG - 2021-10-29 12:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 12:21:55 --> Input Class Initialized
INFO - 2021-10-29 12:21:55 --> Language Class Initialized
ERROR - 2021-10-29 12:21:55 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 12:25:58 --> Config Class Initialized
INFO - 2021-10-29 12:25:58 --> Hooks Class Initialized
DEBUG - 2021-10-29 12:25:58 --> UTF-8 Support Enabled
INFO - 2021-10-29 12:25:58 --> Utf8 Class Initialized
INFO - 2021-10-29 12:25:58 --> URI Class Initialized
DEBUG - 2021-10-29 12:25:58 --> No URI present. Default controller set.
INFO - 2021-10-29 12:25:58 --> Router Class Initialized
INFO - 2021-10-29 12:25:58 --> Output Class Initialized
INFO - 2021-10-29 12:25:58 --> Security Class Initialized
DEBUG - 2021-10-29 12:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 12:25:58 --> Input Class Initialized
INFO - 2021-10-29 12:25:58 --> Language Class Initialized
INFO - 2021-10-29 12:25:58 --> Loader Class Initialized
INFO - 2021-10-29 12:25:58 --> Helper loaded: url_helper
INFO - 2021-10-29 12:25:58 --> Helper loaded: file_helper
DEBUG - 2021-10-29 12:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 12:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 12:25:58 --> Controller Class Initialized
INFO - 2021-10-29 12:25:58 --> Helper loaded: cookie_helper
INFO - 2021-10-29 12:25:58 --> Model "CookieModel" initialized
INFO - 2021-10-29 12:25:58 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 12:25:58 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 12:25:58 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 12:25:58 --> Final output sent to browser
DEBUG - 2021-10-29 12:25:58 --> Total execution time: 0.0508
INFO - 2021-10-29 12:25:58 --> Config Class Initialized
INFO - 2021-10-29 12:25:58 --> Hooks Class Initialized
DEBUG - 2021-10-29 12:25:58 --> UTF-8 Support Enabled
INFO - 2021-10-29 12:25:58 --> Utf8 Class Initialized
INFO - 2021-10-29 12:25:58 --> URI Class Initialized
INFO - 2021-10-29 12:25:58 --> Router Class Initialized
INFO - 2021-10-29 12:25:58 --> Output Class Initialized
INFO - 2021-10-29 12:25:58 --> Security Class Initialized
DEBUG - 2021-10-29 12:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 12:25:58 --> Input Class Initialized
INFO - 2021-10-29 12:25:58 --> Language Class Initialized
ERROR - 2021-10-29 12:25:58 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 12:26:19 --> Config Class Initialized
INFO - 2021-10-29 12:26:19 --> Hooks Class Initialized
DEBUG - 2021-10-29 12:26:19 --> UTF-8 Support Enabled
INFO - 2021-10-29 12:26:19 --> Utf8 Class Initialized
INFO - 2021-10-29 12:26:19 --> URI Class Initialized
INFO - 2021-10-29 12:26:19 --> Router Class Initialized
INFO - 2021-10-29 12:26:19 --> Output Class Initialized
INFO - 2021-10-29 12:26:19 --> Security Class Initialized
DEBUG - 2021-10-29 12:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 12:26:19 --> Input Class Initialized
INFO - 2021-10-29 12:26:19 --> Language Class Initialized
ERROR - 2021-10-29 12:26:19 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 12:27:57 --> Config Class Initialized
INFO - 2021-10-29 12:27:57 --> Hooks Class Initialized
DEBUG - 2021-10-29 12:27:57 --> UTF-8 Support Enabled
INFO - 2021-10-29 12:27:57 --> Utf8 Class Initialized
INFO - 2021-10-29 12:27:57 --> URI Class Initialized
DEBUG - 2021-10-29 12:27:57 --> No URI present. Default controller set.
INFO - 2021-10-29 12:27:57 --> Router Class Initialized
INFO - 2021-10-29 12:27:57 --> Output Class Initialized
INFO - 2021-10-29 12:27:57 --> Security Class Initialized
DEBUG - 2021-10-29 12:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 12:27:57 --> Input Class Initialized
INFO - 2021-10-29 12:27:57 --> Language Class Initialized
INFO - 2021-10-29 12:27:57 --> Loader Class Initialized
INFO - 2021-10-29 12:27:57 --> Helper loaded: url_helper
INFO - 2021-10-29 12:27:57 --> Helper loaded: file_helper
DEBUG - 2021-10-29 12:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 12:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 12:27:57 --> Controller Class Initialized
INFO - 2021-10-29 12:27:57 --> Helper loaded: cookie_helper
INFO - 2021-10-29 12:27:57 --> Model "CookieModel" initialized
INFO - 2021-10-29 12:27:57 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 12:27:57 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 12:27:57 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 12:27:57 --> Final output sent to browser
DEBUG - 2021-10-29 12:27:57 --> Total execution time: 0.0338
INFO - 2021-10-29 12:27:57 --> Config Class Initialized
INFO - 2021-10-29 12:27:57 --> Hooks Class Initialized
DEBUG - 2021-10-29 12:27:57 --> UTF-8 Support Enabled
INFO - 2021-10-29 12:27:57 --> Utf8 Class Initialized
INFO - 2021-10-29 12:27:57 --> URI Class Initialized
INFO - 2021-10-29 12:27:57 --> Router Class Initialized
INFO - 2021-10-29 12:27:57 --> Output Class Initialized
INFO - 2021-10-29 12:27:57 --> Security Class Initialized
DEBUG - 2021-10-29 12:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 12:27:57 --> Input Class Initialized
INFO - 2021-10-29 12:27:57 --> Language Class Initialized
ERROR - 2021-10-29 12:27:57 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 13:06:01 --> Config Class Initialized
INFO - 2021-10-29 13:06:01 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:06:01 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:06:01 --> Utf8 Class Initialized
INFO - 2021-10-29 13:06:01 --> URI Class Initialized
DEBUG - 2021-10-29 13:06:01 --> No URI present. Default controller set.
INFO - 2021-10-29 13:06:01 --> Router Class Initialized
INFO - 2021-10-29 13:06:01 --> Output Class Initialized
INFO - 2021-10-29 13:06:01 --> Security Class Initialized
DEBUG - 2021-10-29 13:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:06:01 --> Input Class Initialized
INFO - 2021-10-29 13:06:01 --> Language Class Initialized
INFO - 2021-10-29 13:06:01 --> Loader Class Initialized
INFO - 2021-10-29 13:06:01 --> Helper loaded: url_helper
INFO - 2021-10-29 13:06:01 --> Helper loaded: file_helper
DEBUG - 2021-10-29 13:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 13:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 13:06:01 --> Controller Class Initialized
INFO - 2021-10-29 13:06:01 --> Helper loaded: cookie_helper
INFO - 2021-10-29 13:06:01 --> Model "CookieModel" initialized
INFO - 2021-10-29 13:06:01 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 13:06:01 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 13:06:01 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 13:06:01 --> Final output sent to browser
DEBUG - 2021-10-29 13:06:01 --> Total execution time: 0.0624
INFO - 2021-10-29 13:06:01 --> Config Class Initialized
INFO - 2021-10-29 13:06:01 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:06:01 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:06:01 --> Utf8 Class Initialized
INFO - 2021-10-29 13:06:01 --> URI Class Initialized
INFO - 2021-10-29 13:06:01 --> Router Class Initialized
INFO - 2021-10-29 13:06:01 --> Output Class Initialized
INFO - 2021-10-29 13:06:01 --> Security Class Initialized
DEBUG - 2021-10-29 13:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:06:01 --> Input Class Initialized
INFO - 2021-10-29 13:06:01 --> Language Class Initialized
ERROR - 2021-10-29 13:06:01 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 13:06:03 --> Config Class Initialized
INFO - 2021-10-29 13:06:03 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:06:03 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:06:03 --> Utf8 Class Initialized
INFO - 2021-10-29 13:06:03 --> URI Class Initialized
DEBUG - 2021-10-29 13:06:03 --> No URI present. Default controller set.
INFO - 2021-10-29 13:06:03 --> Router Class Initialized
INFO - 2021-10-29 13:06:03 --> Output Class Initialized
INFO - 2021-10-29 13:06:03 --> Security Class Initialized
DEBUG - 2021-10-29 13:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:06:03 --> Input Class Initialized
INFO - 2021-10-29 13:06:03 --> Language Class Initialized
INFO - 2021-10-29 13:06:03 --> Loader Class Initialized
INFO - 2021-10-29 13:06:03 --> Helper loaded: url_helper
INFO - 2021-10-29 13:06:03 --> Helper loaded: file_helper
DEBUG - 2021-10-29 13:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 13:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 13:06:03 --> Controller Class Initialized
INFO - 2021-10-29 13:06:03 --> Helper loaded: cookie_helper
INFO - 2021-10-29 13:06:03 --> Model "CookieModel" initialized
INFO - 2021-10-29 13:06:03 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 13:06:03 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 13:06:03 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 13:06:03 --> Final output sent to browser
DEBUG - 2021-10-29 13:06:03 --> Total execution time: 0.0387
INFO - 2021-10-29 13:06:03 --> Config Class Initialized
INFO - 2021-10-29 13:06:03 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:06:03 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:06:03 --> Utf8 Class Initialized
INFO - 2021-10-29 13:06:03 --> URI Class Initialized
INFO - 2021-10-29 13:06:03 --> Router Class Initialized
INFO - 2021-10-29 13:06:03 --> Output Class Initialized
INFO - 2021-10-29 13:06:03 --> Security Class Initialized
DEBUG - 2021-10-29 13:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:06:03 --> Input Class Initialized
INFO - 2021-10-29 13:06:03 --> Language Class Initialized
ERROR - 2021-10-29 13:06:03 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 13:06:22 --> Config Class Initialized
INFO - 2021-10-29 13:06:22 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:06:22 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:06:22 --> Utf8 Class Initialized
INFO - 2021-10-29 13:06:22 --> URI Class Initialized
DEBUG - 2021-10-29 13:06:22 --> No URI present. Default controller set.
INFO - 2021-10-29 13:06:22 --> Router Class Initialized
INFO - 2021-10-29 13:06:22 --> Output Class Initialized
INFO - 2021-10-29 13:06:22 --> Security Class Initialized
DEBUG - 2021-10-29 13:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:06:22 --> Input Class Initialized
INFO - 2021-10-29 13:06:22 --> Language Class Initialized
INFO - 2021-10-29 13:06:22 --> Loader Class Initialized
INFO - 2021-10-29 13:06:22 --> Helper loaded: url_helper
INFO - 2021-10-29 13:06:22 --> Helper loaded: file_helper
DEBUG - 2021-10-29 13:06:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 13:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 13:06:22 --> Controller Class Initialized
INFO - 2021-10-29 13:06:22 --> Helper loaded: cookie_helper
INFO - 2021-10-29 13:06:22 --> Model "CookieModel" initialized
INFO - 2021-10-29 13:06:22 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 13:06:22 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 13:06:22 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 13:06:22 --> Final output sent to browser
DEBUG - 2021-10-29 13:06:22 --> Total execution time: 0.0428
INFO - 2021-10-29 13:06:22 --> Config Class Initialized
INFO - 2021-10-29 13:06:22 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:06:22 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:06:22 --> Utf8 Class Initialized
INFO - 2021-10-29 13:06:22 --> URI Class Initialized
INFO - 2021-10-29 13:06:22 --> Router Class Initialized
INFO - 2021-10-29 13:06:22 --> Output Class Initialized
INFO - 2021-10-29 13:06:22 --> Security Class Initialized
DEBUG - 2021-10-29 13:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:06:22 --> Input Class Initialized
INFO - 2021-10-29 13:06:22 --> Language Class Initialized
ERROR - 2021-10-29 13:06:22 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 13:06:24 --> Config Class Initialized
INFO - 2021-10-29 13:06:24 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:06:24 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:06:24 --> Utf8 Class Initialized
INFO - 2021-10-29 13:06:24 --> URI Class Initialized
DEBUG - 2021-10-29 13:06:24 --> No URI present. Default controller set.
INFO - 2021-10-29 13:06:24 --> Router Class Initialized
INFO - 2021-10-29 13:06:24 --> Output Class Initialized
INFO - 2021-10-29 13:06:24 --> Security Class Initialized
DEBUG - 2021-10-29 13:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:06:24 --> Input Class Initialized
INFO - 2021-10-29 13:06:24 --> Language Class Initialized
INFO - 2021-10-29 13:06:24 --> Loader Class Initialized
INFO - 2021-10-29 13:06:24 --> Helper loaded: url_helper
INFO - 2021-10-29 13:06:24 --> Helper loaded: file_helper
DEBUG - 2021-10-29 13:06:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 13:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 13:06:24 --> Controller Class Initialized
INFO - 2021-10-29 13:06:24 --> Helper loaded: cookie_helper
INFO - 2021-10-29 13:06:24 --> Model "CookieModel" initialized
INFO - 2021-10-29 13:06:24 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 13:06:24 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 13:06:24 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 13:06:24 --> Final output sent to browser
DEBUG - 2021-10-29 13:06:24 --> Total execution time: 0.0305
INFO - 2021-10-29 13:06:24 --> Config Class Initialized
INFO - 2021-10-29 13:06:24 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:06:24 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:06:24 --> Utf8 Class Initialized
INFO - 2021-10-29 13:06:24 --> URI Class Initialized
INFO - 2021-10-29 13:06:24 --> Router Class Initialized
INFO - 2021-10-29 13:06:24 --> Output Class Initialized
INFO - 2021-10-29 13:06:24 --> Security Class Initialized
DEBUG - 2021-10-29 13:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:06:24 --> Input Class Initialized
INFO - 2021-10-29 13:06:24 --> Language Class Initialized
ERROR - 2021-10-29 13:06:24 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 13:06:49 --> Config Class Initialized
INFO - 2021-10-29 13:06:49 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:06:49 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:06:49 --> Utf8 Class Initialized
INFO - 2021-10-29 13:06:49 --> URI Class Initialized
DEBUG - 2021-10-29 13:06:49 --> No URI present. Default controller set.
INFO - 2021-10-29 13:06:49 --> Router Class Initialized
INFO - 2021-10-29 13:06:49 --> Output Class Initialized
INFO - 2021-10-29 13:06:49 --> Security Class Initialized
DEBUG - 2021-10-29 13:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:06:49 --> Input Class Initialized
INFO - 2021-10-29 13:06:49 --> Language Class Initialized
INFO - 2021-10-29 13:06:49 --> Loader Class Initialized
INFO - 2021-10-29 13:06:49 --> Helper loaded: url_helper
INFO - 2021-10-29 13:06:49 --> Helper loaded: file_helper
DEBUG - 2021-10-29 13:06:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 13:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 13:06:49 --> Controller Class Initialized
INFO - 2021-10-29 13:06:49 --> Helper loaded: cookie_helper
INFO - 2021-10-29 13:06:49 --> Model "CookieModel" initialized
INFO - 2021-10-29 13:06:49 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 13:06:49 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 13:06:49 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 13:06:49 --> Final output sent to browser
DEBUG - 2021-10-29 13:06:49 --> Total execution time: 0.0443
INFO - 2021-10-29 13:06:49 --> Config Class Initialized
INFO - 2021-10-29 13:06:49 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:06:49 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:06:49 --> Utf8 Class Initialized
INFO - 2021-10-29 13:06:49 --> URI Class Initialized
INFO - 2021-10-29 13:06:49 --> Router Class Initialized
INFO - 2021-10-29 13:06:49 --> Output Class Initialized
INFO - 2021-10-29 13:06:49 --> Security Class Initialized
DEBUG - 2021-10-29 13:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:06:49 --> Input Class Initialized
INFO - 2021-10-29 13:06:49 --> Language Class Initialized
ERROR - 2021-10-29 13:06:49 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 13:06:58 --> Config Class Initialized
INFO - 2021-10-29 13:06:58 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:06:58 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:06:58 --> Utf8 Class Initialized
INFO - 2021-10-29 13:06:58 --> URI Class Initialized
INFO - 2021-10-29 13:06:58 --> Router Class Initialized
INFO - 2021-10-29 13:06:58 --> Output Class Initialized
INFO - 2021-10-29 13:06:58 --> Security Class Initialized
DEBUG - 2021-10-29 13:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:06:58 --> Input Class Initialized
INFO - 2021-10-29 13:06:58 --> Language Class Initialized
ERROR - 2021-10-29 13:06:58 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 13:07:36 --> Config Class Initialized
INFO - 2021-10-29 13:07:36 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:07:36 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:07:36 --> Utf8 Class Initialized
INFO - 2021-10-29 13:07:36 --> URI Class Initialized
DEBUG - 2021-10-29 13:07:36 --> No URI present. Default controller set.
INFO - 2021-10-29 13:07:36 --> Router Class Initialized
INFO - 2021-10-29 13:07:36 --> Output Class Initialized
INFO - 2021-10-29 13:07:36 --> Security Class Initialized
DEBUG - 2021-10-29 13:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:07:36 --> Input Class Initialized
INFO - 2021-10-29 13:07:36 --> Language Class Initialized
INFO - 2021-10-29 13:07:36 --> Loader Class Initialized
INFO - 2021-10-29 13:07:36 --> Helper loaded: url_helper
INFO - 2021-10-29 13:07:36 --> Helper loaded: file_helper
DEBUG - 2021-10-29 13:07:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 13:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 13:07:36 --> Controller Class Initialized
INFO - 2021-10-29 13:07:36 --> Helper loaded: cookie_helper
INFO - 2021-10-29 13:07:36 --> Model "CookieModel" initialized
INFO - 2021-10-29 13:07:36 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 13:07:36 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 13:07:36 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 13:07:36 --> Final output sent to browser
DEBUG - 2021-10-29 13:07:36 --> Total execution time: 0.0385
INFO - 2021-10-29 13:07:36 --> Config Class Initialized
INFO - 2021-10-29 13:07:36 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:07:36 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:07:36 --> Utf8 Class Initialized
INFO - 2021-10-29 13:07:36 --> URI Class Initialized
INFO - 2021-10-29 13:07:36 --> Router Class Initialized
INFO - 2021-10-29 13:07:36 --> Output Class Initialized
INFO - 2021-10-29 13:07:36 --> Security Class Initialized
DEBUG - 2021-10-29 13:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:07:36 --> Input Class Initialized
INFO - 2021-10-29 13:07:36 --> Language Class Initialized
ERROR - 2021-10-29 13:07:36 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 13:08:17 --> Config Class Initialized
INFO - 2021-10-29 13:08:17 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:08:17 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:08:17 --> Utf8 Class Initialized
INFO - 2021-10-29 13:08:17 --> URI Class Initialized
DEBUG - 2021-10-29 13:08:17 --> No URI present. Default controller set.
INFO - 2021-10-29 13:08:17 --> Router Class Initialized
INFO - 2021-10-29 13:08:17 --> Output Class Initialized
INFO - 2021-10-29 13:08:17 --> Security Class Initialized
DEBUG - 2021-10-29 13:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:08:17 --> Input Class Initialized
INFO - 2021-10-29 13:08:17 --> Language Class Initialized
INFO - 2021-10-29 13:08:17 --> Loader Class Initialized
INFO - 2021-10-29 13:08:17 --> Helper loaded: url_helper
INFO - 2021-10-29 13:08:17 --> Helper loaded: file_helper
DEBUG - 2021-10-29 13:08:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 13:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 13:08:17 --> Controller Class Initialized
INFO - 2021-10-29 13:08:17 --> Helper loaded: cookie_helper
INFO - 2021-10-29 13:08:17 --> Model "CookieModel" initialized
INFO - 2021-10-29 13:08:17 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 13:08:17 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 13:08:17 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 13:08:17 --> Final output sent to browser
DEBUG - 2021-10-29 13:08:17 --> Total execution time: 0.0469
INFO - 2021-10-29 13:08:18 --> Config Class Initialized
INFO - 2021-10-29 13:08:18 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:08:18 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:08:18 --> Utf8 Class Initialized
INFO - 2021-10-29 13:08:18 --> URI Class Initialized
INFO - 2021-10-29 13:08:18 --> Router Class Initialized
INFO - 2021-10-29 13:08:18 --> Output Class Initialized
INFO - 2021-10-29 13:08:18 --> Security Class Initialized
DEBUG - 2021-10-29 13:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:08:18 --> Input Class Initialized
INFO - 2021-10-29 13:08:18 --> Language Class Initialized
ERROR - 2021-10-29 13:08:18 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 13:08:20 --> Config Class Initialized
INFO - 2021-10-29 13:08:20 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:08:20 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:08:20 --> Utf8 Class Initialized
INFO - 2021-10-29 13:08:20 --> URI Class Initialized
DEBUG - 2021-10-29 13:08:20 --> No URI present. Default controller set.
INFO - 2021-10-29 13:08:20 --> Router Class Initialized
INFO - 2021-10-29 13:08:20 --> Output Class Initialized
INFO - 2021-10-29 13:08:20 --> Security Class Initialized
DEBUG - 2021-10-29 13:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:08:20 --> Input Class Initialized
INFO - 2021-10-29 13:08:20 --> Language Class Initialized
INFO - 2021-10-29 13:08:20 --> Loader Class Initialized
INFO - 2021-10-29 13:08:20 --> Helper loaded: url_helper
INFO - 2021-10-29 13:08:20 --> Helper loaded: file_helper
DEBUG - 2021-10-29 13:08:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 13:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 13:08:20 --> Controller Class Initialized
INFO - 2021-10-29 13:08:20 --> Helper loaded: cookie_helper
INFO - 2021-10-29 13:08:20 --> Model "CookieModel" initialized
INFO - 2021-10-29 13:08:20 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 13:08:20 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 13:08:20 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 13:08:20 --> Final output sent to browser
DEBUG - 2021-10-29 13:08:20 --> Total execution time: 0.0447
INFO - 2021-10-29 13:08:21 --> Config Class Initialized
INFO - 2021-10-29 13:08:21 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:08:21 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:08:21 --> Utf8 Class Initialized
INFO - 2021-10-29 13:08:21 --> URI Class Initialized
INFO - 2021-10-29 13:08:21 --> Router Class Initialized
INFO - 2021-10-29 13:08:21 --> Output Class Initialized
INFO - 2021-10-29 13:08:21 --> Security Class Initialized
DEBUG - 2021-10-29 13:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:08:21 --> Input Class Initialized
INFO - 2021-10-29 13:08:21 --> Language Class Initialized
ERROR - 2021-10-29 13:08:21 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 13:08:36 --> Config Class Initialized
INFO - 2021-10-29 13:08:36 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:08:36 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:08:36 --> Utf8 Class Initialized
INFO - 2021-10-29 13:08:36 --> URI Class Initialized
DEBUG - 2021-10-29 13:08:36 --> No URI present. Default controller set.
INFO - 2021-10-29 13:08:36 --> Router Class Initialized
INFO - 2021-10-29 13:08:36 --> Output Class Initialized
INFO - 2021-10-29 13:08:36 --> Security Class Initialized
DEBUG - 2021-10-29 13:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:08:36 --> Input Class Initialized
INFO - 2021-10-29 13:08:36 --> Language Class Initialized
INFO - 2021-10-29 13:08:36 --> Loader Class Initialized
INFO - 2021-10-29 13:08:36 --> Helper loaded: url_helper
INFO - 2021-10-29 13:08:36 --> Helper loaded: file_helper
DEBUG - 2021-10-29 13:08:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 13:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 13:08:36 --> Controller Class Initialized
INFO - 2021-10-29 13:08:36 --> Helper loaded: cookie_helper
INFO - 2021-10-29 13:08:36 --> Model "CookieModel" initialized
INFO - 2021-10-29 13:08:36 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 13:08:36 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 13:08:36 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 13:08:36 --> Final output sent to browser
DEBUG - 2021-10-29 13:08:36 --> Total execution time: 0.0431
INFO - 2021-10-29 13:08:36 --> Config Class Initialized
INFO - 2021-10-29 13:08:36 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:08:36 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:08:36 --> Utf8 Class Initialized
INFO - 2021-10-29 13:08:36 --> URI Class Initialized
INFO - 2021-10-29 13:08:36 --> Router Class Initialized
INFO - 2021-10-29 13:08:36 --> Output Class Initialized
INFO - 2021-10-29 13:08:36 --> Security Class Initialized
DEBUG - 2021-10-29 13:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:08:36 --> Input Class Initialized
INFO - 2021-10-29 13:08:36 --> Language Class Initialized
ERROR - 2021-10-29 13:08:36 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 13:08:57 --> Config Class Initialized
INFO - 2021-10-29 13:08:57 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:08:57 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:08:57 --> Utf8 Class Initialized
INFO - 2021-10-29 13:08:57 --> URI Class Initialized
DEBUG - 2021-10-29 13:08:57 --> No URI present. Default controller set.
INFO - 2021-10-29 13:08:57 --> Router Class Initialized
INFO - 2021-10-29 13:08:57 --> Output Class Initialized
INFO - 2021-10-29 13:08:57 --> Security Class Initialized
DEBUG - 2021-10-29 13:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:08:57 --> Input Class Initialized
INFO - 2021-10-29 13:08:57 --> Language Class Initialized
INFO - 2021-10-29 13:08:57 --> Loader Class Initialized
INFO - 2021-10-29 13:08:57 --> Helper loaded: url_helper
INFO - 2021-10-29 13:08:57 --> Helper loaded: file_helper
DEBUG - 2021-10-29 13:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 13:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 13:08:57 --> Controller Class Initialized
INFO - 2021-10-29 13:08:57 --> Helper loaded: cookie_helper
INFO - 2021-10-29 13:08:57 --> Model "CookieModel" initialized
INFO - 2021-10-29 13:08:57 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 13:08:57 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 13:08:57 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 13:08:57 --> Final output sent to browser
DEBUG - 2021-10-29 13:08:57 --> Total execution time: 0.0377
INFO - 2021-10-29 13:08:57 --> Config Class Initialized
INFO - 2021-10-29 13:08:57 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:08:57 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:08:57 --> Utf8 Class Initialized
INFO - 2021-10-29 13:08:57 --> URI Class Initialized
INFO - 2021-10-29 13:08:57 --> Router Class Initialized
INFO - 2021-10-29 13:08:57 --> Output Class Initialized
INFO - 2021-10-29 13:08:57 --> Security Class Initialized
DEBUG - 2021-10-29 13:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:08:57 --> Input Class Initialized
INFO - 2021-10-29 13:08:57 --> Language Class Initialized
ERROR - 2021-10-29 13:08:57 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 13:09:17 --> Config Class Initialized
INFO - 2021-10-29 13:09:17 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:09:17 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:09:17 --> Utf8 Class Initialized
INFO - 2021-10-29 13:09:17 --> URI Class Initialized
DEBUG - 2021-10-29 13:09:17 --> No URI present. Default controller set.
INFO - 2021-10-29 13:09:17 --> Router Class Initialized
INFO - 2021-10-29 13:09:17 --> Output Class Initialized
INFO - 2021-10-29 13:09:17 --> Security Class Initialized
DEBUG - 2021-10-29 13:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:09:17 --> Input Class Initialized
INFO - 2021-10-29 13:09:17 --> Language Class Initialized
INFO - 2021-10-29 13:09:17 --> Loader Class Initialized
INFO - 2021-10-29 13:09:17 --> Helper loaded: url_helper
INFO - 2021-10-29 13:09:17 --> Helper loaded: file_helper
DEBUG - 2021-10-29 13:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 13:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 13:09:17 --> Controller Class Initialized
INFO - 2021-10-29 13:09:17 --> Helper loaded: cookie_helper
INFO - 2021-10-29 13:09:17 --> Model "CookieModel" initialized
INFO - 2021-10-29 13:09:17 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 13:09:17 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 13:09:17 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 13:09:17 --> Final output sent to browser
DEBUG - 2021-10-29 13:09:17 --> Total execution time: 0.0354
INFO - 2021-10-29 13:09:17 --> Config Class Initialized
INFO - 2021-10-29 13:09:17 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:09:18 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:09:18 --> Utf8 Class Initialized
INFO - 2021-10-29 13:09:18 --> URI Class Initialized
INFO - 2021-10-29 13:09:18 --> Router Class Initialized
INFO - 2021-10-29 13:09:18 --> Output Class Initialized
INFO - 2021-10-29 13:09:18 --> Security Class Initialized
DEBUG - 2021-10-29 13:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:09:18 --> Input Class Initialized
INFO - 2021-10-29 13:09:18 --> Language Class Initialized
ERROR - 2021-10-29 13:09:18 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 13:09:20 --> Config Class Initialized
INFO - 2021-10-29 13:09:20 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:09:20 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:09:20 --> Utf8 Class Initialized
INFO - 2021-10-29 13:09:20 --> URI Class Initialized
DEBUG - 2021-10-29 13:09:20 --> No URI present. Default controller set.
INFO - 2021-10-29 13:09:20 --> Router Class Initialized
INFO - 2021-10-29 13:09:20 --> Output Class Initialized
INFO - 2021-10-29 13:09:20 --> Security Class Initialized
DEBUG - 2021-10-29 13:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:09:20 --> Input Class Initialized
INFO - 2021-10-29 13:09:20 --> Language Class Initialized
INFO - 2021-10-29 13:09:20 --> Loader Class Initialized
INFO - 2021-10-29 13:09:20 --> Helper loaded: url_helper
INFO - 2021-10-29 13:09:20 --> Helper loaded: file_helper
DEBUG - 2021-10-29 13:09:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 13:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 13:09:20 --> Controller Class Initialized
INFO - 2021-10-29 13:09:20 --> Helper loaded: cookie_helper
INFO - 2021-10-29 13:09:20 --> Model "CookieModel" initialized
INFO - 2021-10-29 13:09:20 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 13:09:20 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 13:09:20 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 13:09:20 --> Final output sent to browser
DEBUG - 2021-10-29 13:09:20 --> Total execution time: 0.0321
INFO - 2021-10-29 13:09:20 --> Config Class Initialized
INFO - 2021-10-29 13:09:20 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:09:20 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:09:20 --> Utf8 Class Initialized
INFO - 2021-10-29 13:09:20 --> URI Class Initialized
INFO - 2021-10-29 13:09:20 --> Router Class Initialized
INFO - 2021-10-29 13:09:20 --> Output Class Initialized
INFO - 2021-10-29 13:09:20 --> Security Class Initialized
DEBUG - 2021-10-29 13:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:09:20 --> Input Class Initialized
INFO - 2021-10-29 13:09:20 --> Language Class Initialized
ERROR - 2021-10-29 13:09:20 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 13:19:36 --> Config Class Initialized
INFO - 2021-10-29 13:19:36 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:19:36 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:19:36 --> Utf8 Class Initialized
INFO - 2021-10-29 13:19:36 --> URI Class Initialized
DEBUG - 2021-10-29 13:19:36 --> No URI present. Default controller set.
INFO - 2021-10-29 13:19:36 --> Router Class Initialized
INFO - 2021-10-29 13:19:36 --> Output Class Initialized
INFO - 2021-10-29 13:19:36 --> Security Class Initialized
DEBUG - 2021-10-29 13:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:19:36 --> Input Class Initialized
INFO - 2021-10-29 13:19:36 --> Language Class Initialized
INFO - 2021-10-29 13:19:36 --> Loader Class Initialized
INFO - 2021-10-29 13:19:36 --> Helper loaded: url_helper
INFO - 2021-10-29 13:19:36 --> Helper loaded: file_helper
DEBUG - 2021-10-29 13:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 13:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 13:19:36 --> Controller Class Initialized
INFO - 2021-10-29 13:19:36 --> Helper loaded: cookie_helper
INFO - 2021-10-29 13:19:36 --> Model "CookieModel" initialized
INFO - 2021-10-29 13:19:36 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 13:19:36 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 13:19:36 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 13:19:36 --> Final output sent to browser
DEBUG - 2021-10-29 13:19:36 --> Total execution time: 0.0691
INFO - 2021-10-29 13:19:36 --> Config Class Initialized
INFO - 2021-10-29 13:19:36 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:19:36 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:19:36 --> Utf8 Class Initialized
INFO - 2021-10-29 13:19:36 --> URI Class Initialized
INFO - 2021-10-29 13:19:36 --> Router Class Initialized
INFO - 2021-10-29 13:19:36 --> Output Class Initialized
INFO - 2021-10-29 13:19:36 --> Security Class Initialized
DEBUG - 2021-10-29 13:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:19:36 --> Input Class Initialized
INFO - 2021-10-29 13:19:36 --> Language Class Initialized
ERROR - 2021-10-29 13:19:36 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 13:19:45 --> Config Class Initialized
INFO - 2021-10-29 13:19:45 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:19:45 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:19:45 --> Utf8 Class Initialized
INFO - 2021-10-29 13:19:45 --> URI Class Initialized
DEBUG - 2021-10-29 13:19:45 --> No URI present. Default controller set.
INFO - 2021-10-29 13:19:45 --> Router Class Initialized
INFO - 2021-10-29 13:19:45 --> Output Class Initialized
INFO - 2021-10-29 13:19:45 --> Security Class Initialized
DEBUG - 2021-10-29 13:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:19:45 --> Input Class Initialized
INFO - 2021-10-29 13:19:45 --> Language Class Initialized
INFO - 2021-10-29 13:19:45 --> Loader Class Initialized
INFO - 2021-10-29 13:19:45 --> Helper loaded: url_helper
INFO - 2021-10-29 13:19:45 --> Helper loaded: file_helper
DEBUG - 2021-10-29 13:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 13:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 13:19:45 --> Controller Class Initialized
INFO - 2021-10-29 13:19:45 --> Helper loaded: cookie_helper
INFO - 2021-10-29 13:19:45 --> Model "CookieModel" initialized
INFO - 2021-10-29 13:19:45 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 13:19:45 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 13:19:45 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 13:19:45 --> Final output sent to browser
DEBUG - 2021-10-29 13:19:45 --> Total execution time: 0.0374
INFO - 2021-10-29 13:19:46 --> Config Class Initialized
INFO - 2021-10-29 13:19:46 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:19:46 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:19:46 --> Utf8 Class Initialized
INFO - 2021-10-29 13:19:46 --> URI Class Initialized
INFO - 2021-10-29 13:19:46 --> Router Class Initialized
INFO - 2021-10-29 13:19:46 --> Output Class Initialized
INFO - 2021-10-29 13:19:46 --> Security Class Initialized
DEBUG - 2021-10-29 13:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:19:46 --> Input Class Initialized
INFO - 2021-10-29 13:19:46 --> Language Class Initialized
ERROR - 2021-10-29 13:19:46 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 13:20:35 --> Config Class Initialized
INFO - 2021-10-29 13:20:35 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:20:35 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:20:35 --> Utf8 Class Initialized
INFO - 2021-10-29 13:20:35 --> URI Class Initialized
DEBUG - 2021-10-29 13:20:35 --> No URI present. Default controller set.
INFO - 2021-10-29 13:20:35 --> Router Class Initialized
INFO - 2021-10-29 13:20:35 --> Output Class Initialized
INFO - 2021-10-29 13:20:35 --> Security Class Initialized
DEBUG - 2021-10-29 13:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:20:35 --> Input Class Initialized
INFO - 2021-10-29 13:20:35 --> Language Class Initialized
INFO - 2021-10-29 13:20:35 --> Loader Class Initialized
INFO - 2021-10-29 13:20:35 --> Helper loaded: url_helper
INFO - 2021-10-29 13:20:35 --> Helper loaded: file_helper
DEBUG - 2021-10-29 13:20:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 13:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 13:20:35 --> Controller Class Initialized
INFO - 2021-10-29 13:20:35 --> Helper loaded: cookie_helper
INFO - 2021-10-29 13:20:35 --> Model "CookieModel" initialized
INFO - 2021-10-29 13:20:35 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 13:20:35 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 13:20:35 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 13:20:35 --> Final output sent to browser
DEBUG - 2021-10-29 13:20:35 --> Total execution time: 0.0454
INFO - 2021-10-29 13:20:36 --> Config Class Initialized
INFO - 2021-10-29 13:20:36 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:20:36 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:20:36 --> Utf8 Class Initialized
INFO - 2021-10-29 13:20:36 --> URI Class Initialized
INFO - 2021-10-29 13:20:36 --> Router Class Initialized
INFO - 2021-10-29 13:20:36 --> Output Class Initialized
INFO - 2021-10-29 13:20:36 --> Security Class Initialized
DEBUG - 2021-10-29 13:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:20:36 --> Input Class Initialized
INFO - 2021-10-29 13:20:36 --> Language Class Initialized
ERROR - 2021-10-29 13:20:36 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 13:21:32 --> Config Class Initialized
INFO - 2021-10-29 13:21:32 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:21:32 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:21:32 --> Utf8 Class Initialized
INFO - 2021-10-29 13:21:32 --> URI Class Initialized
INFO - 2021-10-29 13:21:32 --> Router Class Initialized
INFO - 2021-10-29 13:21:32 --> Output Class Initialized
INFO - 2021-10-29 13:21:32 --> Security Class Initialized
DEBUG - 2021-10-29 13:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:21:32 --> Input Class Initialized
INFO - 2021-10-29 13:21:32 --> Language Class Initialized
ERROR - 2021-10-29 13:21:32 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 13:22:11 --> Config Class Initialized
INFO - 2021-10-29 13:22:11 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:22:11 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:22:11 --> Utf8 Class Initialized
INFO - 2021-10-29 13:22:11 --> URI Class Initialized
DEBUG - 2021-10-29 13:22:11 --> No URI present. Default controller set.
INFO - 2021-10-29 13:22:11 --> Router Class Initialized
INFO - 2021-10-29 13:22:11 --> Output Class Initialized
INFO - 2021-10-29 13:22:11 --> Security Class Initialized
DEBUG - 2021-10-29 13:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:22:11 --> Input Class Initialized
INFO - 2021-10-29 13:22:11 --> Language Class Initialized
INFO - 2021-10-29 13:22:11 --> Loader Class Initialized
INFO - 2021-10-29 13:22:11 --> Helper loaded: url_helper
INFO - 2021-10-29 13:22:11 --> Helper loaded: file_helper
DEBUG - 2021-10-29 13:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 13:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 13:22:11 --> Controller Class Initialized
INFO - 2021-10-29 13:22:11 --> Helper loaded: cookie_helper
INFO - 2021-10-29 13:22:11 --> Model "CookieModel" initialized
INFO - 2021-10-29 13:22:11 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 13:22:11 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 13:22:11 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 13:22:11 --> Final output sent to browser
DEBUG - 2021-10-29 13:22:11 --> Total execution time: 0.0391
INFO - 2021-10-29 13:22:12 --> Config Class Initialized
INFO - 2021-10-29 13:22:12 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:22:12 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:22:12 --> Utf8 Class Initialized
INFO - 2021-10-29 13:22:12 --> URI Class Initialized
INFO - 2021-10-29 13:22:12 --> Router Class Initialized
INFO - 2021-10-29 13:22:12 --> Output Class Initialized
INFO - 2021-10-29 13:22:12 --> Security Class Initialized
DEBUG - 2021-10-29 13:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:22:12 --> Input Class Initialized
INFO - 2021-10-29 13:22:12 --> Language Class Initialized
ERROR - 2021-10-29 13:22:12 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 13:23:37 --> Config Class Initialized
INFO - 2021-10-29 13:23:37 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:23:37 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:23:37 --> Utf8 Class Initialized
INFO - 2021-10-29 13:23:37 --> URI Class Initialized
DEBUG - 2021-10-29 13:23:37 --> No URI present. Default controller set.
INFO - 2021-10-29 13:23:37 --> Router Class Initialized
INFO - 2021-10-29 13:23:37 --> Output Class Initialized
INFO - 2021-10-29 13:23:37 --> Security Class Initialized
DEBUG - 2021-10-29 13:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:23:37 --> Input Class Initialized
INFO - 2021-10-29 13:23:37 --> Language Class Initialized
INFO - 2021-10-29 13:23:37 --> Loader Class Initialized
INFO - 2021-10-29 13:23:37 --> Helper loaded: url_helper
INFO - 2021-10-29 13:23:37 --> Helper loaded: file_helper
DEBUG - 2021-10-29 13:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 13:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 13:23:37 --> Controller Class Initialized
INFO - 2021-10-29 13:23:37 --> Helper loaded: cookie_helper
INFO - 2021-10-29 13:23:37 --> Model "CookieModel" initialized
INFO - 2021-10-29 13:23:37 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 13:23:37 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 13:23:37 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 13:23:37 --> Final output sent to browser
DEBUG - 2021-10-29 13:23:37 --> Total execution time: 0.0461
INFO - 2021-10-29 13:23:38 --> Config Class Initialized
INFO - 2021-10-29 13:23:38 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:23:38 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:23:38 --> Utf8 Class Initialized
INFO - 2021-10-29 13:23:38 --> URI Class Initialized
INFO - 2021-10-29 13:23:38 --> Router Class Initialized
INFO - 2021-10-29 13:23:38 --> Output Class Initialized
INFO - 2021-10-29 13:23:38 --> Security Class Initialized
DEBUG - 2021-10-29 13:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:23:38 --> Input Class Initialized
INFO - 2021-10-29 13:23:38 --> Language Class Initialized
ERROR - 2021-10-29 13:23:38 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 13:24:03 --> Config Class Initialized
INFO - 2021-10-29 13:24:03 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:24:03 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:24:03 --> Utf8 Class Initialized
INFO - 2021-10-29 13:24:03 --> URI Class Initialized
DEBUG - 2021-10-29 13:24:03 --> No URI present. Default controller set.
INFO - 2021-10-29 13:24:03 --> Router Class Initialized
INFO - 2021-10-29 13:24:03 --> Output Class Initialized
INFO - 2021-10-29 13:24:03 --> Security Class Initialized
DEBUG - 2021-10-29 13:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:24:03 --> Input Class Initialized
INFO - 2021-10-29 13:24:03 --> Language Class Initialized
INFO - 2021-10-29 13:24:03 --> Loader Class Initialized
INFO - 2021-10-29 13:24:03 --> Helper loaded: url_helper
INFO - 2021-10-29 13:24:03 --> Helper loaded: file_helper
DEBUG - 2021-10-29 13:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 13:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 13:24:03 --> Controller Class Initialized
INFO - 2021-10-29 13:24:03 --> Helper loaded: cookie_helper
INFO - 2021-10-29 13:24:03 --> Model "CookieModel" initialized
INFO - 2021-10-29 13:24:03 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 13:24:03 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 13:24:03 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 13:24:03 --> Final output sent to browser
DEBUG - 2021-10-29 13:24:03 --> Total execution time: 0.0520
INFO - 2021-10-29 13:24:04 --> Config Class Initialized
INFO - 2021-10-29 13:24:04 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:24:04 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:24:04 --> Utf8 Class Initialized
INFO - 2021-10-29 13:24:04 --> URI Class Initialized
INFO - 2021-10-29 13:24:04 --> Router Class Initialized
INFO - 2021-10-29 13:24:04 --> Output Class Initialized
INFO - 2021-10-29 13:24:04 --> Security Class Initialized
DEBUG - 2021-10-29 13:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:24:04 --> Input Class Initialized
INFO - 2021-10-29 13:24:04 --> Language Class Initialized
ERROR - 2021-10-29 13:24:04 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 13:24:05 --> Config Class Initialized
INFO - 2021-10-29 13:24:05 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:24:05 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:24:05 --> Utf8 Class Initialized
INFO - 2021-10-29 13:24:05 --> URI Class Initialized
DEBUG - 2021-10-29 13:24:05 --> No URI present. Default controller set.
INFO - 2021-10-29 13:24:05 --> Router Class Initialized
INFO - 2021-10-29 13:24:05 --> Output Class Initialized
INFO - 2021-10-29 13:24:05 --> Security Class Initialized
DEBUG - 2021-10-29 13:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:24:05 --> Input Class Initialized
INFO - 2021-10-29 13:24:05 --> Language Class Initialized
INFO - 2021-10-29 13:24:05 --> Loader Class Initialized
INFO - 2021-10-29 13:24:05 --> Helper loaded: url_helper
INFO - 2021-10-29 13:24:05 --> Helper loaded: file_helper
DEBUG - 2021-10-29 13:24:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 13:24:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 13:24:05 --> Controller Class Initialized
INFO - 2021-10-29 13:24:05 --> Helper loaded: cookie_helper
INFO - 2021-10-29 13:24:05 --> Model "CookieModel" initialized
INFO - 2021-10-29 13:24:05 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 13:24:05 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 13:24:05 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 13:24:05 --> Final output sent to browser
DEBUG - 2021-10-29 13:24:05 --> Total execution time: 0.0443
INFO - 2021-10-29 13:24:05 --> Config Class Initialized
INFO - 2021-10-29 13:24:05 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:24:05 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:24:05 --> Utf8 Class Initialized
INFO - 2021-10-29 13:24:05 --> URI Class Initialized
INFO - 2021-10-29 13:24:05 --> Router Class Initialized
INFO - 2021-10-29 13:24:05 --> Output Class Initialized
INFO - 2021-10-29 13:24:05 --> Security Class Initialized
DEBUG - 2021-10-29 13:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:24:05 --> Input Class Initialized
INFO - 2021-10-29 13:24:05 --> Language Class Initialized
ERROR - 2021-10-29 13:24:05 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 13:24:22 --> Config Class Initialized
INFO - 2021-10-29 13:24:22 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:24:22 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:24:22 --> Utf8 Class Initialized
INFO - 2021-10-29 13:24:22 --> URI Class Initialized
DEBUG - 2021-10-29 13:24:22 --> No URI present. Default controller set.
INFO - 2021-10-29 13:24:22 --> Router Class Initialized
INFO - 2021-10-29 13:24:22 --> Output Class Initialized
INFO - 2021-10-29 13:24:22 --> Security Class Initialized
DEBUG - 2021-10-29 13:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:24:22 --> Input Class Initialized
INFO - 2021-10-29 13:24:22 --> Language Class Initialized
INFO - 2021-10-29 13:24:22 --> Loader Class Initialized
INFO - 2021-10-29 13:24:22 --> Helper loaded: url_helper
INFO - 2021-10-29 13:24:22 --> Helper loaded: file_helper
DEBUG - 2021-10-29 13:24:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 13:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 13:24:22 --> Controller Class Initialized
INFO - 2021-10-29 13:24:22 --> Helper loaded: cookie_helper
INFO - 2021-10-29 13:24:22 --> Model "CookieModel" initialized
INFO - 2021-10-29 13:24:22 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 13:24:22 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 13:24:22 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 13:24:22 --> Final output sent to browser
DEBUG - 2021-10-29 13:24:22 --> Total execution time: 0.0507
INFO - 2021-10-29 13:24:22 --> Config Class Initialized
INFO - 2021-10-29 13:24:22 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:24:22 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:24:22 --> Utf8 Class Initialized
INFO - 2021-10-29 13:24:22 --> URI Class Initialized
INFO - 2021-10-29 13:24:22 --> Router Class Initialized
INFO - 2021-10-29 13:24:22 --> Output Class Initialized
INFO - 2021-10-29 13:24:22 --> Security Class Initialized
DEBUG - 2021-10-29 13:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:24:22 --> Input Class Initialized
INFO - 2021-10-29 13:24:22 --> Language Class Initialized
ERROR - 2021-10-29 13:24:22 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 13:24:23 --> Config Class Initialized
INFO - 2021-10-29 13:24:23 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:24:23 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:24:23 --> Utf8 Class Initialized
INFO - 2021-10-29 13:24:23 --> URI Class Initialized
DEBUG - 2021-10-29 13:24:23 --> No URI present. Default controller set.
INFO - 2021-10-29 13:24:23 --> Router Class Initialized
INFO - 2021-10-29 13:24:23 --> Output Class Initialized
INFO - 2021-10-29 13:24:23 --> Security Class Initialized
DEBUG - 2021-10-29 13:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:24:23 --> Input Class Initialized
INFO - 2021-10-29 13:24:23 --> Language Class Initialized
INFO - 2021-10-29 13:24:23 --> Loader Class Initialized
INFO - 2021-10-29 13:24:23 --> Helper loaded: url_helper
INFO - 2021-10-29 13:24:23 --> Helper loaded: file_helper
DEBUG - 2021-10-29 13:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 13:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 13:24:23 --> Controller Class Initialized
INFO - 2021-10-29 13:24:23 --> Helper loaded: cookie_helper
INFO - 2021-10-29 13:24:23 --> Model "CookieModel" initialized
INFO - 2021-10-29 13:24:23 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 13:24:23 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 13:24:23 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 13:24:23 --> Final output sent to browser
DEBUG - 2021-10-29 13:24:23 --> Total execution time: 0.0493
INFO - 2021-10-29 13:24:23 --> Config Class Initialized
INFO - 2021-10-29 13:24:23 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:24:23 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:24:23 --> Utf8 Class Initialized
INFO - 2021-10-29 13:24:23 --> URI Class Initialized
DEBUG - 2021-10-29 13:24:23 --> No URI present. Default controller set.
INFO - 2021-10-29 13:24:23 --> Router Class Initialized
INFO - 2021-10-29 13:24:23 --> Output Class Initialized
INFO - 2021-10-29 13:24:23 --> Security Class Initialized
DEBUG - 2021-10-29 13:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:24:23 --> Input Class Initialized
INFO - 2021-10-29 13:24:23 --> Language Class Initialized
INFO - 2021-10-29 13:24:23 --> Loader Class Initialized
INFO - 2021-10-29 13:24:23 --> Helper loaded: url_helper
INFO - 2021-10-29 13:24:23 --> Helper loaded: file_helper
DEBUG - 2021-10-29 13:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 13:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 13:24:23 --> Controller Class Initialized
INFO - 2021-10-29 13:24:23 --> Helper loaded: cookie_helper
INFO - 2021-10-29 13:24:23 --> Model "CookieModel" initialized
INFO - 2021-10-29 13:24:23 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 13:24:23 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 13:24:23 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 13:24:23 --> Final output sent to browser
DEBUG - 2021-10-29 13:24:23 --> Total execution time: 0.0553
INFO - 2021-10-29 13:24:24 --> Config Class Initialized
INFO - 2021-10-29 13:24:24 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:24:24 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:24:24 --> Utf8 Class Initialized
INFO - 2021-10-29 13:24:24 --> URI Class Initialized
INFO - 2021-10-29 13:24:24 --> Router Class Initialized
INFO - 2021-10-29 13:24:24 --> Output Class Initialized
INFO - 2021-10-29 13:24:24 --> Security Class Initialized
DEBUG - 2021-10-29 13:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:24:24 --> Input Class Initialized
INFO - 2021-10-29 13:24:24 --> Language Class Initialized
ERROR - 2021-10-29 13:24:24 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 13:29:16 --> Config Class Initialized
INFO - 2021-10-29 13:29:16 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:29:16 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:29:16 --> Utf8 Class Initialized
INFO - 2021-10-29 13:29:16 --> URI Class Initialized
DEBUG - 2021-10-29 13:29:16 --> No URI present. Default controller set.
INFO - 2021-10-29 13:29:16 --> Router Class Initialized
INFO - 2021-10-29 13:29:16 --> Output Class Initialized
INFO - 2021-10-29 13:29:16 --> Security Class Initialized
DEBUG - 2021-10-29 13:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:29:16 --> Input Class Initialized
INFO - 2021-10-29 13:29:16 --> Language Class Initialized
INFO - 2021-10-29 13:29:16 --> Loader Class Initialized
INFO - 2021-10-29 13:29:16 --> Helper loaded: url_helper
INFO - 2021-10-29 13:29:16 --> Helper loaded: file_helper
DEBUG - 2021-10-29 13:29:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 13:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 13:29:16 --> Controller Class Initialized
INFO - 2021-10-29 13:29:16 --> Helper loaded: cookie_helper
INFO - 2021-10-29 13:29:16 --> Model "CookieModel" initialized
INFO - 2021-10-29 13:29:16 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 13:29:16 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 13:29:16 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 13:29:16 --> Final output sent to browser
DEBUG - 2021-10-29 13:29:16 --> Total execution time: 0.0601
INFO - 2021-10-29 13:29:17 --> Config Class Initialized
INFO - 2021-10-29 13:29:17 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:29:17 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:29:17 --> Utf8 Class Initialized
INFO - 2021-10-29 13:29:17 --> URI Class Initialized
INFO - 2021-10-29 13:29:17 --> Router Class Initialized
INFO - 2021-10-29 13:29:17 --> Output Class Initialized
INFO - 2021-10-29 13:29:17 --> Security Class Initialized
DEBUG - 2021-10-29 13:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:29:17 --> Input Class Initialized
INFO - 2021-10-29 13:29:17 --> Language Class Initialized
ERROR - 2021-10-29 13:29:17 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 13:29:27 --> Config Class Initialized
INFO - 2021-10-29 13:29:27 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:29:28 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:29:28 --> Utf8 Class Initialized
INFO - 2021-10-29 13:29:28 --> URI Class Initialized
DEBUG - 2021-10-29 13:29:28 --> No URI present. Default controller set.
INFO - 2021-10-29 13:29:28 --> Router Class Initialized
INFO - 2021-10-29 13:29:28 --> Output Class Initialized
INFO - 2021-10-29 13:29:28 --> Security Class Initialized
DEBUG - 2021-10-29 13:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:29:28 --> Input Class Initialized
INFO - 2021-10-29 13:29:28 --> Language Class Initialized
INFO - 2021-10-29 13:29:28 --> Loader Class Initialized
INFO - 2021-10-29 13:29:28 --> Helper loaded: url_helper
INFO - 2021-10-29 13:29:28 --> Helper loaded: file_helper
DEBUG - 2021-10-29 13:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 13:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 13:29:28 --> Controller Class Initialized
INFO - 2021-10-29 13:29:28 --> Helper loaded: cookie_helper
INFO - 2021-10-29 13:29:28 --> Model "CookieModel" initialized
INFO - 2021-10-29 13:29:28 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 13:29:28 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 13:29:28 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 13:29:28 --> Final output sent to browser
DEBUG - 2021-10-29 13:29:28 --> Total execution time: 0.0465
INFO - 2021-10-29 13:29:29 --> Config Class Initialized
INFO - 2021-10-29 13:29:29 --> Hooks Class Initialized
DEBUG - 2021-10-29 13:29:29 --> UTF-8 Support Enabled
INFO - 2021-10-29 13:29:29 --> Utf8 Class Initialized
INFO - 2021-10-29 13:29:29 --> URI Class Initialized
INFO - 2021-10-29 13:29:29 --> Router Class Initialized
INFO - 2021-10-29 13:29:29 --> Output Class Initialized
INFO - 2021-10-29 13:29:29 --> Security Class Initialized
DEBUG - 2021-10-29 13:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 13:29:29 --> Input Class Initialized
INFO - 2021-10-29 13:29:29 --> Language Class Initialized
ERROR - 2021-10-29 13:29:29 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 14:03:51 --> Config Class Initialized
INFO - 2021-10-29 14:03:51 --> Hooks Class Initialized
DEBUG - 2021-10-29 14:03:51 --> UTF-8 Support Enabled
INFO - 2021-10-29 14:03:51 --> Utf8 Class Initialized
INFO - 2021-10-29 14:03:51 --> URI Class Initialized
DEBUG - 2021-10-29 14:03:51 --> No URI present. Default controller set.
INFO - 2021-10-29 14:03:51 --> Router Class Initialized
INFO - 2021-10-29 14:03:51 --> Output Class Initialized
INFO - 2021-10-29 14:03:51 --> Security Class Initialized
DEBUG - 2021-10-29 14:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 14:03:51 --> Input Class Initialized
INFO - 2021-10-29 14:03:51 --> Language Class Initialized
INFO - 2021-10-29 14:03:51 --> Loader Class Initialized
INFO - 2021-10-29 14:03:51 --> Helper loaded: url_helper
INFO - 2021-10-29 14:03:51 --> Helper loaded: file_helper
DEBUG - 2021-10-29 14:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 14:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 14:03:51 --> Controller Class Initialized
INFO - 2021-10-29 14:03:51 --> Helper loaded: cookie_helper
INFO - 2021-10-29 14:03:51 --> Model "CookieModel" initialized
INFO - 2021-10-29 14:03:51 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 14:03:51 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 14:03:51 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 14:03:51 --> Final output sent to browser
DEBUG - 2021-10-29 14:03:51 --> Total execution time: 0.0458
INFO - 2021-10-29 14:03:52 --> Config Class Initialized
INFO - 2021-10-29 14:03:52 --> Hooks Class Initialized
DEBUG - 2021-10-29 14:03:52 --> UTF-8 Support Enabled
INFO - 2021-10-29 14:03:52 --> Utf8 Class Initialized
INFO - 2021-10-29 14:03:52 --> URI Class Initialized
INFO - 2021-10-29 14:03:52 --> Router Class Initialized
INFO - 2021-10-29 14:03:52 --> Output Class Initialized
INFO - 2021-10-29 14:03:52 --> Security Class Initialized
DEBUG - 2021-10-29 14:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 14:03:52 --> Input Class Initialized
INFO - 2021-10-29 14:03:52 --> Language Class Initialized
ERROR - 2021-10-29 14:03:52 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 14:33:31 --> Config Class Initialized
INFO - 2021-10-29 14:33:31 --> Hooks Class Initialized
DEBUG - 2021-10-29 14:33:31 --> UTF-8 Support Enabled
INFO - 2021-10-29 14:33:31 --> Utf8 Class Initialized
INFO - 2021-10-29 14:33:31 --> URI Class Initialized
DEBUG - 2021-10-29 14:33:31 --> No URI present. Default controller set.
INFO - 2021-10-29 14:33:31 --> Router Class Initialized
INFO - 2021-10-29 14:33:31 --> Output Class Initialized
INFO - 2021-10-29 14:33:31 --> Security Class Initialized
DEBUG - 2021-10-29 14:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 14:33:31 --> Input Class Initialized
INFO - 2021-10-29 14:33:31 --> Language Class Initialized
INFO - 2021-10-29 14:33:31 --> Loader Class Initialized
INFO - 2021-10-29 14:33:31 --> Helper loaded: url_helper
INFO - 2021-10-29 14:33:31 --> Helper loaded: file_helper
DEBUG - 2021-10-29 14:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 14:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 14:33:31 --> Controller Class Initialized
INFO - 2021-10-29 14:33:31 --> Helper loaded: cookie_helper
INFO - 2021-10-29 14:33:31 --> Model "CookieModel" initialized
INFO - 2021-10-29 14:33:31 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 14:33:31 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 14:33:31 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 14:33:31 --> Final output sent to browser
DEBUG - 2021-10-29 14:33:31 --> Total execution time: 0.0520
INFO - 2021-10-29 14:33:32 --> Config Class Initialized
INFO - 2021-10-29 14:33:32 --> Hooks Class Initialized
DEBUG - 2021-10-29 14:33:32 --> UTF-8 Support Enabled
INFO - 2021-10-29 14:33:32 --> Utf8 Class Initialized
INFO - 2021-10-29 14:33:32 --> URI Class Initialized
INFO - 2021-10-29 14:33:32 --> Router Class Initialized
INFO - 2021-10-29 14:33:32 --> Output Class Initialized
INFO - 2021-10-29 14:33:32 --> Security Class Initialized
DEBUG - 2021-10-29 14:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 14:33:32 --> Input Class Initialized
INFO - 2021-10-29 14:33:32 --> Language Class Initialized
ERROR - 2021-10-29 14:33:32 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 14:34:15 --> Config Class Initialized
INFO - 2021-10-29 14:34:15 --> Hooks Class Initialized
DEBUG - 2021-10-29 14:34:15 --> UTF-8 Support Enabled
INFO - 2021-10-29 14:34:15 --> Utf8 Class Initialized
INFO - 2021-10-29 14:34:15 --> URI Class Initialized
DEBUG - 2021-10-29 14:34:15 --> No URI present. Default controller set.
INFO - 2021-10-29 14:34:15 --> Router Class Initialized
INFO - 2021-10-29 14:34:15 --> Output Class Initialized
INFO - 2021-10-29 14:34:15 --> Security Class Initialized
DEBUG - 2021-10-29 14:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 14:34:15 --> Input Class Initialized
INFO - 2021-10-29 14:34:15 --> Language Class Initialized
INFO - 2021-10-29 14:34:15 --> Loader Class Initialized
INFO - 2021-10-29 14:34:15 --> Helper loaded: url_helper
INFO - 2021-10-29 14:34:15 --> Helper loaded: file_helper
DEBUG - 2021-10-29 14:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 14:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 14:34:15 --> Controller Class Initialized
INFO - 2021-10-29 14:34:15 --> Helper loaded: cookie_helper
INFO - 2021-10-29 14:34:15 --> Model "CookieModel" initialized
INFO - 2021-10-29 14:34:15 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 14:34:15 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 14:34:15 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 14:34:15 --> Final output sent to browser
DEBUG - 2021-10-29 14:34:15 --> Total execution time: 0.0338
INFO - 2021-10-29 14:34:15 --> Config Class Initialized
INFO - 2021-10-29 14:34:15 --> Hooks Class Initialized
DEBUG - 2021-10-29 14:34:15 --> UTF-8 Support Enabled
INFO - 2021-10-29 14:34:15 --> Utf8 Class Initialized
INFO - 2021-10-29 14:34:15 --> URI Class Initialized
INFO - 2021-10-29 14:34:15 --> Router Class Initialized
INFO - 2021-10-29 14:34:15 --> Output Class Initialized
INFO - 2021-10-29 14:34:15 --> Security Class Initialized
DEBUG - 2021-10-29 14:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 14:34:15 --> Input Class Initialized
INFO - 2021-10-29 14:34:15 --> Language Class Initialized
ERROR - 2021-10-29 14:34:15 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 14:34:28 --> Config Class Initialized
INFO - 2021-10-29 14:34:28 --> Hooks Class Initialized
DEBUG - 2021-10-29 14:34:28 --> UTF-8 Support Enabled
INFO - 2021-10-29 14:34:28 --> Utf8 Class Initialized
INFO - 2021-10-29 14:34:28 --> URI Class Initialized
DEBUG - 2021-10-29 14:34:28 --> No URI present. Default controller set.
INFO - 2021-10-29 14:34:28 --> Router Class Initialized
INFO - 2021-10-29 14:34:28 --> Output Class Initialized
INFO - 2021-10-29 14:34:28 --> Security Class Initialized
DEBUG - 2021-10-29 14:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 14:34:28 --> Input Class Initialized
INFO - 2021-10-29 14:34:28 --> Language Class Initialized
INFO - 2021-10-29 14:34:28 --> Loader Class Initialized
INFO - 2021-10-29 14:34:28 --> Helper loaded: url_helper
INFO - 2021-10-29 14:34:28 --> Helper loaded: file_helper
DEBUG - 2021-10-29 14:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 14:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 14:34:28 --> Controller Class Initialized
INFO - 2021-10-29 14:34:28 --> Helper loaded: cookie_helper
INFO - 2021-10-29 14:34:28 --> Model "CookieModel" initialized
INFO - 2021-10-29 14:34:28 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 14:34:28 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 14:34:28 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 14:34:28 --> Final output sent to browser
DEBUG - 2021-10-29 14:34:28 --> Total execution time: 0.0762
INFO - 2021-10-29 14:34:29 --> Config Class Initialized
INFO - 2021-10-29 14:34:29 --> Hooks Class Initialized
DEBUG - 2021-10-29 14:34:29 --> UTF-8 Support Enabled
INFO - 2021-10-29 14:34:29 --> Utf8 Class Initialized
INFO - 2021-10-29 14:34:29 --> URI Class Initialized
INFO - 2021-10-29 14:34:29 --> Router Class Initialized
INFO - 2021-10-29 14:34:29 --> Output Class Initialized
INFO - 2021-10-29 14:34:29 --> Security Class Initialized
DEBUG - 2021-10-29 14:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 14:34:29 --> Input Class Initialized
INFO - 2021-10-29 14:34:29 --> Language Class Initialized
ERROR - 2021-10-29 14:34:29 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 14:34:40 --> Config Class Initialized
INFO - 2021-10-29 14:34:40 --> Hooks Class Initialized
DEBUG - 2021-10-29 14:34:40 --> UTF-8 Support Enabled
INFO - 2021-10-29 14:34:40 --> Utf8 Class Initialized
INFO - 2021-10-29 14:34:40 --> URI Class Initialized
DEBUG - 2021-10-29 14:34:40 --> No URI present. Default controller set.
INFO - 2021-10-29 14:34:40 --> Router Class Initialized
INFO - 2021-10-29 14:34:40 --> Output Class Initialized
INFO - 2021-10-29 14:34:40 --> Security Class Initialized
DEBUG - 2021-10-29 14:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 14:34:40 --> Input Class Initialized
INFO - 2021-10-29 14:34:40 --> Language Class Initialized
INFO - 2021-10-29 14:34:40 --> Loader Class Initialized
INFO - 2021-10-29 14:34:40 --> Helper loaded: url_helper
INFO - 2021-10-29 14:34:40 --> Helper loaded: file_helper
DEBUG - 2021-10-29 14:34:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 14:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 14:34:40 --> Controller Class Initialized
INFO - 2021-10-29 14:34:40 --> Helper loaded: cookie_helper
INFO - 2021-10-29 14:34:40 --> Model "CookieModel" initialized
INFO - 2021-10-29 14:34:40 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 14:34:40 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 14:34:40 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 14:34:40 --> Final output sent to browser
DEBUG - 2021-10-29 14:34:40 --> Total execution time: 0.0454
INFO - 2021-10-29 14:34:41 --> Config Class Initialized
INFO - 2021-10-29 14:34:41 --> Hooks Class Initialized
DEBUG - 2021-10-29 14:34:41 --> UTF-8 Support Enabled
INFO - 2021-10-29 14:34:41 --> Utf8 Class Initialized
INFO - 2021-10-29 14:34:41 --> URI Class Initialized
INFO - 2021-10-29 14:34:41 --> Router Class Initialized
INFO - 2021-10-29 14:34:41 --> Output Class Initialized
INFO - 2021-10-29 14:34:41 --> Security Class Initialized
DEBUG - 2021-10-29 14:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 14:34:41 --> Input Class Initialized
INFO - 2021-10-29 14:34:41 --> Language Class Initialized
ERROR - 2021-10-29 14:34:41 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 14:34:48 --> Config Class Initialized
INFO - 2021-10-29 14:34:48 --> Hooks Class Initialized
DEBUG - 2021-10-29 14:34:48 --> UTF-8 Support Enabled
INFO - 2021-10-29 14:34:48 --> Utf8 Class Initialized
INFO - 2021-10-29 14:34:48 --> URI Class Initialized
DEBUG - 2021-10-29 14:34:48 --> No URI present. Default controller set.
INFO - 2021-10-29 14:34:48 --> Router Class Initialized
INFO - 2021-10-29 14:34:48 --> Output Class Initialized
INFO - 2021-10-29 14:34:48 --> Security Class Initialized
DEBUG - 2021-10-29 14:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 14:34:48 --> Input Class Initialized
INFO - 2021-10-29 14:34:48 --> Language Class Initialized
INFO - 2021-10-29 14:34:48 --> Loader Class Initialized
INFO - 2021-10-29 14:34:48 --> Helper loaded: url_helper
INFO - 2021-10-29 14:34:48 --> Helper loaded: file_helper
DEBUG - 2021-10-29 14:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 14:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 14:34:48 --> Controller Class Initialized
INFO - 2021-10-29 14:34:48 --> Helper loaded: cookie_helper
INFO - 2021-10-29 14:34:48 --> Model "CookieModel" initialized
INFO - 2021-10-29 14:34:48 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 14:34:48 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 14:34:48 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 14:34:48 --> Final output sent to browser
DEBUG - 2021-10-29 14:34:48 --> Total execution time: 0.0385
INFO - 2021-10-29 14:34:49 --> Config Class Initialized
INFO - 2021-10-29 14:34:49 --> Hooks Class Initialized
DEBUG - 2021-10-29 14:34:49 --> UTF-8 Support Enabled
INFO - 2021-10-29 14:34:49 --> Utf8 Class Initialized
INFO - 2021-10-29 14:34:49 --> URI Class Initialized
INFO - 2021-10-29 14:34:49 --> Router Class Initialized
INFO - 2021-10-29 14:34:49 --> Output Class Initialized
INFO - 2021-10-29 14:34:49 --> Security Class Initialized
DEBUG - 2021-10-29 14:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 14:34:49 --> Input Class Initialized
INFO - 2021-10-29 14:34:49 --> Language Class Initialized
ERROR - 2021-10-29 14:34:49 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 14:36:43 --> Config Class Initialized
INFO - 2021-10-29 14:36:43 --> Hooks Class Initialized
DEBUG - 2021-10-29 14:36:43 --> UTF-8 Support Enabled
INFO - 2021-10-29 14:36:43 --> Utf8 Class Initialized
INFO - 2021-10-29 14:36:43 --> URI Class Initialized
DEBUG - 2021-10-29 14:36:43 --> No URI present. Default controller set.
INFO - 2021-10-29 14:36:43 --> Router Class Initialized
INFO - 2021-10-29 14:36:43 --> Output Class Initialized
INFO - 2021-10-29 14:36:43 --> Security Class Initialized
DEBUG - 2021-10-29 14:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 14:36:43 --> Input Class Initialized
INFO - 2021-10-29 14:36:43 --> Language Class Initialized
INFO - 2021-10-29 14:36:43 --> Loader Class Initialized
INFO - 2021-10-29 14:36:43 --> Helper loaded: url_helper
INFO - 2021-10-29 14:36:43 --> Helper loaded: file_helper
DEBUG - 2021-10-29 14:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 14:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 14:36:43 --> Controller Class Initialized
INFO - 2021-10-29 14:36:43 --> Helper loaded: cookie_helper
INFO - 2021-10-29 14:36:43 --> Model "CookieModel" initialized
INFO - 2021-10-29 14:36:43 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 14:36:43 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 14:36:43 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 14:36:43 --> Final output sent to browser
DEBUG - 2021-10-29 14:36:43 --> Total execution time: 0.0425
INFO - 2021-10-29 14:36:44 --> Config Class Initialized
INFO - 2021-10-29 14:36:44 --> Hooks Class Initialized
DEBUG - 2021-10-29 14:36:44 --> UTF-8 Support Enabled
INFO - 2021-10-29 14:36:44 --> Utf8 Class Initialized
INFO - 2021-10-29 14:36:44 --> URI Class Initialized
INFO - 2021-10-29 14:36:44 --> Router Class Initialized
INFO - 2021-10-29 14:36:44 --> Output Class Initialized
INFO - 2021-10-29 14:36:44 --> Security Class Initialized
DEBUG - 2021-10-29 14:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 14:36:44 --> Input Class Initialized
INFO - 2021-10-29 14:36:44 --> Language Class Initialized
ERROR - 2021-10-29 14:36:44 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 14:37:15 --> Config Class Initialized
INFO - 2021-10-29 14:37:15 --> Hooks Class Initialized
DEBUG - 2021-10-29 14:37:15 --> UTF-8 Support Enabled
INFO - 2021-10-29 14:37:15 --> Utf8 Class Initialized
INFO - 2021-10-29 14:37:15 --> URI Class Initialized
DEBUG - 2021-10-29 14:37:15 --> No URI present. Default controller set.
INFO - 2021-10-29 14:37:15 --> Router Class Initialized
INFO - 2021-10-29 14:37:15 --> Output Class Initialized
INFO - 2021-10-29 14:37:15 --> Security Class Initialized
DEBUG - 2021-10-29 14:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 14:37:15 --> Input Class Initialized
INFO - 2021-10-29 14:37:15 --> Language Class Initialized
INFO - 2021-10-29 14:37:15 --> Loader Class Initialized
INFO - 2021-10-29 14:37:15 --> Helper loaded: url_helper
INFO - 2021-10-29 14:37:15 --> Helper loaded: file_helper
DEBUG - 2021-10-29 14:37:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 14:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 14:37:15 --> Controller Class Initialized
INFO - 2021-10-29 14:37:15 --> Helper loaded: cookie_helper
INFO - 2021-10-29 14:37:15 --> Model "CookieModel" initialized
INFO - 2021-10-29 14:37:15 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 14:37:15 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 14:37:15 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 14:37:15 --> Final output sent to browser
DEBUG - 2021-10-29 14:37:15 --> Total execution time: 0.0432
INFO - 2021-10-29 14:37:15 --> Config Class Initialized
INFO - 2021-10-29 14:37:15 --> Hooks Class Initialized
DEBUG - 2021-10-29 14:37:15 --> UTF-8 Support Enabled
INFO - 2021-10-29 14:37:15 --> Utf8 Class Initialized
INFO - 2021-10-29 14:37:15 --> URI Class Initialized
INFO - 2021-10-29 14:37:15 --> Router Class Initialized
INFO - 2021-10-29 14:37:15 --> Output Class Initialized
INFO - 2021-10-29 14:37:15 --> Security Class Initialized
DEBUG - 2021-10-29 14:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 14:37:15 --> Input Class Initialized
INFO - 2021-10-29 14:37:15 --> Language Class Initialized
ERROR - 2021-10-29 14:37:15 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 14:37:28 --> Config Class Initialized
INFO - 2021-10-29 14:37:28 --> Hooks Class Initialized
DEBUG - 2021-10-29 14:37:28 --> UTF-8 Support Enabled
INFO - 2021-10-29 14:37:28 --> Utf8 Class Initialized
INFO - 2021-10-29 14:37:28 --> URI Class Initialized
INFO - 2021-10-29 14:37:28 --> Router Class Initialized
INFO - 2021-10-29 14:37:28 --> Output Class Initialized
INFO - 2021-10-29 14:37:28 --> Security Class Initialized
DEBUG - 2021-10-29 14:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 14:37:28 --> Input Class Initialized
INFO - 2021-10-29 14:37:28 --> Language Class Initialized
ERROR - 2021-10-29 14:37:28 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 14:37:38 --> Config Class Initialized
INFO - 2021-10-29 14:37:38 --> Hooks Class Initialized
DEBUG - 2021-10-29 14:37:38 --> UTF-8 Support Enabled
INFO - 2021-10-29 14:37:38 --> Utf8 Class Initialized
INFO - 2021-10-29 14:37:38 --> URI Class Initialized
DEBUG - 2021-10-29 14:37:38 --> No URI present. Default controller set.
INFO - 2021-10-29 14:37:38 --> Router Class Initialized
INFO - 2021-10-29 14:37:38 --> Output Class Initialized
INFO - 2021-10-29 14:37:38 --> Security Class Initialized
DEBUG - 2021-10-29 14:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 14:37:38 --> Input Class Initialized
INFO - 2021-10-29 14:37:38 --> Language Class Initialized
INFO - 2021-10-29 14:37:38 --> Loader Class Initialized
INFO - 2021-10-29 14:37:38 --> Helper loaded: url_helper
INFO - 2021-10-29 14:37:38 --> Helper loaded: file_helper
DEBUG - 2021-10-29 14:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 14:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 14:37:38 --> Controller Class Initialized
INFO - 2021-10-29 14:37:38 --> Helper loaded: cookie_helper
INFO - 2021-10-29 14:37:38 --> Model "CookieModel" initialized
INFO - 2021-10-29 14:37:38 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 14:37:38 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 14:37:38 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 14:37:38 --> Final output sent to browser
DEBUG - 2021-10-29 14:37:38 --> Total execution time: 0.0383
INFO - 2021-10-29 14:37:39 --> Config Class Initialized
INFO - 2021-10-29 14:37:39 --> Hooks Class Initialized
DEBUG - 2021-10-29 14:37:39 --> UTF-8 Support Enabled
INFO - 2021-10-29 14:37:39 --> Utf8 Class Initialized
INFO - 2021-10-29 14:37:39 --> URI Class Initialized
INFO - 2021-10-29 14:37:39 --> Router Class Initialized
INFO - 2021-10-29 14:37:39 --> Output Class Initialized
INFO - 2021-10-29 14:37:39 --> Security Class Initialized
DEBUG - 2021-10-29 14:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 14:37:39 --> Input Class Initialized
INFO - 2021-10-29 14:37:39 --> Language Class Initialized
ERROR - 2021-10-29 14:37:39 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 14:38:07 --> Config Class Initialized
INFO - 2021-10-29 14:38:07 --> Hooks Class Initialized
DEBUG - 2021-10-29 14:38:07 --> UTF-8 Support Enabled
INFO - 2021-10-29 14:38:07 --> Utf8 Class Initialized
INFO - 2021-10-29 14:38:07 --> URI Class Initialized
DEBUG - 2021-10-29 14:38:07 --> No URI present. Default controller set.
INFO - 2021-10-29 14:38:07 --> Router Class Initialized
INFO - 2021-10-29 14:38:07 --> Output Class Initialized
INFO - 2021-10-29 14:38:07 --> Security Class Initialized
DEBUG - 2021-10-29 14:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 14:38:07 --> Input Class Initialized
INFO - 2021-10-29 14:38:07 --> Language Class Initialized
INFO - 2021-10-29 14:38:07 --> Loader Class Initialized
INFO - 2021-10-29 14:38:07 --> Helper loaded: url_helper
INFO - 2021-10-29 14:38:07 --> Helper loaded: file_helper
DEBUG - 2021-10-29 14:38:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 14:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 14:38:07 --> Controller Class Initialized
INFO - 2021-10-29 14:38:07 --> Helper loaded: cookie_helper
INFO - 2021-10-29 14:38:07 --> Model "CookieModel" initialized
INFO - 2021-10-29 14:38:07 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 14:38:07 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 14:38:07 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 14:38:07 --> Final output sent to browser
DEBUG - 2021-10-29 14:38:07 --> Total execution time: 0.0350
INFO - 2021-10-29 14:38:07 --> Config Class Initialized
INFO - 2021-10-29 14:38:07 --> Hooks Class Initialized
DEBUG - 2021-10-29 14:38:07 --> UTF-8 Support Enabled
INFO - 2021-10-29 14:38:07 --> Utf8 Class Initialized
INFO - 2021-10-29 14:38:07 --> URI Class Initialized
INFO - 2021-10-29 14:38:07 --> Router Class Initialized
INFO - 2021-10-29 14:38:07 --> Output Class Initialized
INFO - 2021-10-29 14:38:07 --> Security Class Initialized
DEBUG - 2021-10-29 14:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 14:38:07 --> Input Class Initialized
INFO - 2021-10-29 14:38:07 --> Language Class Initialized
ERROR - 2021-10-29 14:38:07 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 14:39:52 --> Config Class Initialized
INFO - 2021-10-29 14:39:52 --> Hooks Class Initialized
DEBUG - 2021-10-29 14:39:52 --> UTF-8 Support Enabled
INFO - 2021-10-29 14:39:52 --> Utf8 Class Initialized
INFO - 2021-10-29 14:39:52 --> URI Class Initialized
DEBUG - 2021-10-29 14:39:52 --> No URI present. Default controller set.
INFO - 2021-10-29 14:39:52 --> Router Class Initialized
INFO - 2021-10-29 14:39:52 --> Output Class Initialized
INFO - 2021-10-29 14:39:52 --> Security Class Initialized
DEBUG - 2021-10-29 14:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 14:39:52 --> Input Class Initialized
INFO - 2021-10-29 14:39:52 --> Language Class Initialized
INFO - 2021-10-29 14:39:52 --> Loader Class Initialized
INFO - 2021-10-29 14:39:52 --> Helper loaded: url_helper
INFO - 2021-10-29 14:39:52 --> Helper loaded: file_helper
DEBUG - 2021-10-29 14:39:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 14:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 14:39:52 --> Controller Class Initialized
INFO - 2021-10-29 14:39:52 --> Helper loaded: cookie_helper
INFO - 2021-10-29 14:39:52 --> Model "CookieModel" initialized
INFO - 2021-10-29 14:39:52 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 14:39:52 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 14:39:52 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 14:39:52 --> Final output sent to browser
DEBUG - 2021-10-29 14:39:52 --> Total execution time: 0.0465
INFO - 2021-10-29 14:39:52 --> Config Class Initialized
INFO - 2021-10-29 14:39:52 --> Hooks Class Initialized
DEBUG - 2021-10-29 14:39:52 --> UTF-8 Support Enabled
INFO - 2021-10-29 14:39:52 --> Utf8 Class Initialized
INFO - 2021-10-29 14:39:52 --> URI Class Initialized
INFO - 2021-10-29 14:39:52 --> Router Class Initialized
INFO - 2021-10-29 14:39:52 --> Output Class Initialized
INFO - 2021-10-29 14:39:52 --> Security Class Initialized
DEBUG - 2021-10-29 14:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 14:39:52 --> Input Class Initialized
INFO - 2021-10-29 14:39:52 --> Language Class Initialized
ERROR - 2021-10-29 14:39:52 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 14:44:35 --> Config Class Initialized
INFO - 2021-10-29 14:44:35 --> Hooks Class Initialized
DEBUG - 2021-10-29 14:44:35 --> UTF-8 Support Enabled
INFO - 2021-10-29 14:44:35 --> Utf8 Class Initialized
INFO - 2021-10-29 14:44:35 --> URI Class Initialized
DEBUG - 2021-10-29 14:44:35 --> No URI present. Default controller set.
INFO - 2021-10-29 14:44:35 --> Router Class Initialized
INFO - 2021-10-29 14:44:35 --> Output Class Initialized
INFO - 2021-10-29 14:44:35 --> Security Class Initialized
DEBUG - 2021-10-29 14:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 14:44:35 --> Input Class Initialized
INFO - 2021-10-29 14:44:35 --> Language Class Initialized
INFO - 2021-10-29 14:44:35 --> Loader Class Initialized
INFO - 2021-10-29 14:44:35 --> Helper loaded: url_helper
INFO - 2021-10-29 14:44:35 --> Helper loaded: file_helper
DEBUG - 2021-10-29 14:44:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 14:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 14:44:35 --> Controller Class Initialized
INFO - 2021-10-29 14:44:35 --> Helper loaded: cookie_helper
INFO - 2021-10-29 14:44:35 --> Model "CookieModel" initialized
INFO - 2021-10-29 14:44:35 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 14:44:35 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 14:44:35 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 14:44:35 --> Final output sent to browser
DEBUG - 2021-10-29 14:44:35 --> Total execution time: 0.0437
INFO - 2021-10-29 14:44:36 --> Config Class Initialized
INFO - 2021-10-29 14:44:36 --> Hooks Class Initialized
DEBUG - 2021-10-29 14:44:36 --> UTF-8 Support Enabled
INFO - 2021-10-29 14:44:36 --> Utf8 Class Initialized
INFO - 2021-10-29 14:44:36 --> URI Class Initialized
INFO - 2021-10-29 14:44:36 --> Router Class Initialized
INFO - 2021-10-29 14:44:36 --> Output Class Initialized
INFO - 2021-10-29 14:44:36 --> Security Class Initialized
DEBUG - 2021-10-29 14:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 14:44:36 --> Input Class Initialized
INFO - 2021-10-29 14:44:36 --> Language Class Initialized
ERROR - 2021-10-29 14:44:36 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 14:45:38 --> Config Class Initialized
INFO - 2021-10-29 14:45:38 --> Hooks Class Initialized
DEBUG - 2021-10-29 14:45:38 --> UTF-8 Support Enabled
INFO - 2021-10-29 14:45:38 --> Utf8 Class Initialized
INFO - 2021-10-29 14:45:38 --> URI Class Initialized
DEBUG - 2021-10-29 14:45:38 --> No URI present. Default controller set.
INFO - 2021-10-29 14:45:38 --> Router Class Initialized
INFO - 2021-10-29 14:45:38 --> Output Class Initialized
INFO - 2021-10-29 14:45:38 --> Security Class Initialized
DEBUG - 2021-10-29 14:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 14:45:38 --> Input Class Initialized
INFO - 2021-10-29 14:45:38 --> Language Class Initialized
INFO - 2021-10-29 14:45:38 --> Loader Class Initialized
INFO - 2021-10-29 14:45:38 --> Helper loaded: url_helper
INFO - 2021-10-29 14:45:38 --> Helper loaded: file_helper
DEBUG - 2021-10-29 14:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 14:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 14:45:38 --> Controller Class Initialized
INFO - 2021-10-29 14:45:38 --> Helper loaded: cookie_helper
INFO - 2021-10-29 14:45:38 --> Model "CookieModel" initialized
INFO - 2021-10-29 14:45:38 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 14:45:38 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 14:45:38 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 14:45:38 --> Final output sent to browser
DEBUG - 2021-10-29 14:45:38 --> Total execution time: 0.0428
INFO - 2021-10-29 14:45:39 --> Config Class Initialized
INFO - 2021-10-29 14:45:39 --> Hooks Class Initialized
DEBUG - 2021-10-29 14:45:39 --> UTF-8 Support Enabled
INFO - 2021-10-29 14:45:39 --> Utf8 Class Initialized
INFO - 2021-10-29 14:45:39 --> URI Class Initialized
INFO - 2021-10-29 14:45:39 --> Router Class Initialized
INFO - 2021-10-29 14:45:39 --> Output Class Initialized
INFO - 2021-10-29 14:45:39 --> Security Class Initialized
DEBUG - 2021-10-29 14:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 14:45:39 --> Input Class Initialized
INFO - 2021-10-29 14:45:39 --> Language Class Initialized
ERROR - 2021-10-29 14:45:39 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 14:47:09 --> Config Class Initialized
INFO - 2021-10-29 14:47:09 --> Hooks Class Initialized
DEBUG - 2021-10-29 14:47:09 --> UTF-8 Support Enabled
INFO - 2021-10-29 14:47:09 --> Utf8 Class Initialized
INFO - 2021-10-29 14:47:09 --> URI Class Initialized
INFO - 2021-10-29 14:47:09 --> Router Class Initialized
INFO - 2021-10-29 14:47:09 --> Output Class Initialized
INFO - 2021-10-29 14:47:09 --> Security Class Initialized
DEBUG - 2021-10-29 14:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 14:47:09 --> Input Class Initialized
INFO - 2021-10-29 14:47:09 --> Language Class Initialized
ERROR - 2021-10-29 14:47:09 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 15:24:47 --> Config Class Initialized
INFO - 2021-10-29 15:24:47 --> Hooks Class Initialized
DEBUG - 2021-10-29 15:24:47 --> UTF-8 Support Enabled
INFO - 2021-10-29 15:24:47 --> Utf8 Class Initialized
INFO - 2021-10-29 15:24:47 --> URI Class Initialized
DEBUG - 2021-10-29 15:24:47 --> No URI present. Default controller set.
INFO - 2021-10-29 15:24:47 --> Router Class Initialized
INFO - 2021-10-29 15:24:47 --> Output Class Initialized
INFO - 2021-10-29 15:24:47 --> Security Class Initialized
DEBUG - 2021-10-29 15:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 15:24:47 --> Input Class Initialized
INFO - 2021-10-29 15:24:47 --> Language Class Initialized
INFO - 2021-10-29 15:24:47 --> Loader Class Initialized
INFO - 2021-10-29 15:24:47 --> Helper loaded: url_helper
INFO - 2021-10-29 15:24:47 --> Helper loaded: file_helper
DEBUG - 2021-10-29 15:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 15:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 15:24:47 --> Controller Class Initialized
INFO - 2021-10-29 15:24:47 --> Helper loaded: cookie_helper
INFO - 2021-10-29 15:24:47 --> Model "CookieModel" initialized
INFO - 2021-10-29 15:24:47 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 15:24:47 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 15:24:47 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 15:24:47 --> Final output sent to browser
DEBUG - 2021-10-29 15:24:47 --> Total execution time: 0.0614
INFO - 2021-10-29 15:24:48 --> Config Class Initialized
INFO - 2021-10-29 15:24:48 --> Hooks Class Initialized
DEBUG - 2021-10-29 15:24:48 --> UTF-8 Support Enabled
INFO - 2021-10-29 15:24:48 --> Utf8 Class Initialized
INFO - 2021-10-29 15:24:48 --> URI Class Initialized
INFO - 2021-10-29 15:24:48 --> Router Class Initialized
INFO - 2021-10-29 15:24:48 --> Output Class Initialized
INFO - 2021-10-29 15:24:48 --> Security Class Initialized
DEBUG - 2021-10-29 15:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 15:24:48 --> Input Class Initialized
INFO - 2021-10-29 15:24:48 --> Language Class Initialized
ERROR - 2021-10-29 15:24:48 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 15:26:53 --> Config Class Initialized
INFO - 2021-10-29 15:26:53 --> Hooks Class Initialized
DEBUG - 2021-10-29 15:26:53 --> UTF-8 Support Enabled
INFO - 2021-10-29 15:26:53 --> Utf8 Class Initialized
INFO - 2021-10-29 15:26:53 --> URI Class Initialized
DEBUG - 2021-10-29 15:26:53 --> No URI present. Default controller set.
INFO - 2021-10-29 15:26:53 --> Router Class Initialized
INFO - 2021-10-29 15:26:53 --> Output Class Initialized
INFO - 2021-10-29 15:26:53 --> Security Class Initialized
DEBUG - 2021-10-29 15:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 15:26:53 --> Input Class Initialized
INFO - 2021-10-29 15:26:53 --> Language Class Initialized
INFO - 2021-10-29 15:26:53 --> Loader Class Initialized
INFO - 2021-10-29 15:26:53 --> Helper loaded: url_helper
INFO - 2021-10-29 15:26:53 --> Helper loaded: file_helper
DEBUG - 2021-10-29 15:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 15:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 15:26:53 --> Controller Class Initialized
INFO - 2021-10-29 15:26:53 --> Helper loaded: cookie_helper
INFO - 2021-10-29 15:26:53 --> Model "CookieModel" initialized
INFO - 2021-10-29 15:26:53 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 15:26:53 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 15:26:53 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 15:26:53 --> Final output sent to browser
DEBUG - 2021-10-29 15:26:53 --> Total execution time: 0.0434
INFO - 2021-10-29 15:26:53 --> Config Class Initialized
INFO - 2021-10-29 15:26:53 --> Hooks Class Initialized
DEBUG - 2021-10-29 15:26:53 --> UTF-8 Support Enabled
INFO - 2021-10-29 15:26:53 --> Utf8 Class Initialized
INFO - 2021-10-29 15:26:53 --> URI Class Initialized
INFO - 2021-10-29 15:26:53 --> Router Class Initialized
INFO - 2021-10-29 15:26:53 --> Output Class Initialized
INFO - 2021-10-29 15:26:53 --> Security Class Initialized
DEBUG - 2021-10-29 15:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 15:26:53 --> Input Class Initialized
INFO - 2021-10-29 15:26:53 --> Language Class Initialized
ERROR - 2021-10-29 15:26:53 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 15:26:56 --> Config Class Initialized
INFO - 2021-10-29 15:26:56 --> Hooks Class Initialized
DEBUG - 2021-10-29 15:26:56 --> UTF-8 Support Enabled
INFO - 2021-10-29 15:26:56 --> Utf8 Class Initialized
INFO - 2021-10-29 15:26:56 --> URI Class Initialized
DEBUG - 2021-10-29 15:26:56 --> No URI present. Default controller set.
INFO - 2021-10-29 15:26:56 --> Router Class Initialized
INFO - 2021-10-29 15:26:56 --> Output Class Initialized
INFO - 2021-10-29 15:26:56 --> Security Class Initialized
DEBUG - 2021-10-29 15:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 15:26:56 --> Input Class Initialized
INFO - 2021-10-29 15:26:56 --> Language Class Initialized
INFO - 2021-10-29 15:26:56 --> Loader Class Initialized
INFO - 2021-10-29 15:26:56 --> Helper loaded: url_helper
INFO - 2021-10-29 15:26:56 --> Helper loaded: file_helper
DEBUG - 2021-10-29 15:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 15:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 15:26:56 --> Controller Class Initialized
INFO - 2021-10-29 15:26:56 --> Helper loaded: cookie_helper
INFO - 2021-10-29 15:26:56 --> Model "CookieModel" initialized
INFO - 2021-10-29 15:26:56 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 15:26:56 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 15:26:56 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 15:26:56 --> Final output sent to browser
DEBUG - 2021-10-29 15:26:56 --> Total execution time: 0.0366
INFO - 2021-10-29 15:26:56 --> Config Class Initialized
INFO - 2021-10-29 15:26:56 --> Hooks Class Initialized
DEBUG - 2021-10-29 15:26:56 --> UTF-8 Support Enabled
INFO - 2021-10-29 15:26:56 --> Utf8 Class Initialized
INFO - 2021-10-29 15:26:56 --> URI Class Initialized
INFO - 2021-10-29 15:26:56 --> Router Class Initialized
INFO - 2021-10-29 15:26:56 --> Output Class Initialized
INFO - 2021-10-29 15:26:56 --> Security Class Initialized
DEBUG - 2021-10-29 15:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 15:26:56 --> Input Class Initialized
INFO - 2021-10-29 15:26:56 --> Language Class Initialized
ERROR - 2021-10-29 15:26:56 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 15:27:58 --> Config Class Initialized
INFO - 2021-10-29 15:27:58 --> Hooks Class Initialized
DEBUG - 2021-10-29 15:27:58 --> UTF-8 Support Enabled
INFO - 2021-10-29 15:27:58 --> Utf8 Class Initialized
INFO - 2021-10-29 15:27:58 --> URI Class Initialized
DEBUG - 2021-10-29 15:27:58 --> No URI present. Default controller set.
INFO - 2021-10-29 15:27:58 --> Router Class Initialized
INFO - 2021-10-29 15:27:58 --> Output Class Initialized
INFO - 2021-10-29 15:27:58 --> Security Class Initialized
DEBUG - 2021-10-29 15:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 15:27:58 --> Input Class Initialized
INFO - 2021-10-29 15:27:58 --> Language Class Initialized
INFO - 2021-10-29 15:27:58 --> Loader Class Initialized
INFO - 2021-10-29 15:27:58 --> Helper loaded: url_helper
INFO - 2021-10-29 15:27:58 --> Helper loaded: file_helper
DEBUG - 2021-10-29 15:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 15:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 15:27:58 --> Controller Class Initialized
INFO - 2021-10-29 15:27:58 --> Helper loaded: cookie_helper
INFO - 2021-10-29 15:27:58 --> Model "CookieModel" initialized
INFO - 2021-10-29 15:27:58 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 15:27:58 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 15:27:58 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 15:27:58 --> Final output sent to browser
DEBUG - 2021-10-29 15:27:58 --> Total execution time: 0.0428
INFO - 2021-10-29 15:27:58 --> Config Class Initialized
INFO - 2021-10-29 15:27:58 --> Hooks Class Initialized
DEBUG - 2021-10-29 15:27:58 --> UTF-8 Support Enabled
INFO - 2021-10-29 15:27:58 --> Utf8 Class Initialized
INFO - 2021-10-29 15:27:58 --> URI Class Initialized
INFO - 2021-10-29 15:27:58 --> Router Class Initialized
INFO - 2021-10-29 15:27:58 --> Output Class Initialized
INFO - 2021-10-29 15:27:58 --> Security Class Initialized
DEBUG - 2021-10-29 15:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 15:27:58 --> Input Class Initialized
INFO - 2021-10-29 15:27:58 --> Language Class Initialized
ERROR - 2021-10-29 15:27:58 --> 404 Page Not Found: Assets/icons
INFO - 2021-10-29 15:28:21 --> Config Class Initialized
INFO - 2021-10-29 15:28:21 --> Hooks Class Initialized
DEBUG - 2021-10-29 15:28:21 --> UTF-8 Support Enabled
INFO - 2021-10-29 15:28:21 --> Utf8 Class Initialized
INFO - 2021-10-29 15:28:21 --> URI Class Initialized
DEBUG - 2021-10-29 15:28:21 --> No URI present. Default controller set.
INFO - 2021-10-29 15:28:21 --> Router Class Initialized
INFO - 2021-10-29 15:28:21 --> Output Class Initialized
INFO - 2021-10-29 15:28:21 --> Security Class Initialized
DEBUG - 2021-10-29 15:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 15:28:21 --> Input Class Initialized
INFO - 2021-10-29 15:28:21 --> Language Class Initialized
INFO - 2021-10-29 15:28:21 --> Loader Class Initialized
INFO - 2021-10-29 15:28:21 --> Helper loaded: url_helper
INFO - 2021-10-29 15:28:21 --> Helper loaded: file_helper
DEBUG - 2021-10-29 15:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-10-29 15:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-10-29 15:28:21 --> Controller Class Initialized
INFO - 2021-10-29 15:28:21 --> Helper loaded: cookie_helper
INFO - 2021-10-29 15:28:21 --> Model "CookieModel" initialized
INFO - 2021-10-29 15:28:21 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/header.php
INFO - 2021-10-29 15:28:21 --> File loaded: E:\xampp\htdocs\kfc\application\views\user/index.php
INFO - 2021-10-29 15:28:21 --> File loaded: E:\xampp\htdocs\kfc\application\views\layout/footer.php
INFO - 2021-10-29 15:28:21 --> Final output sent to browser
DEBUG - 2021-10-29 15:28:21 --> Total execution time: 0.0367
INFO - 2021-10-29 15:28:22 --> Config Class Initialized
INFO - 2021-10-29 15:28:22 --> Hooks Class Initialized
DEBUG - 2021-10-29 15:28:22 --> UTF-8 Support Enabled
INFO - 2021-10-29 15:28:22 --> Utf8 Class Initialized
INFO - 2021-10-29 15:28:22 --> URI Class Initialized
INFO - 2021-10-29 15:28:22 --> Router Class Initialized
INFO - 2021-10-29 15:28:22 --> Output Class Initialized
INFO - 2021-10-29 15:28:22 --> Security Class Initialized
DEBUG - 2021-10-29 15:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-10-29 15:28:22 --> Input Class Initialized
INFO - 2021-10-29 15:28:22 --> Language Class Initialized
ERROR - 2021-10-29 15:28:22 --> 404 Page Not Found: Assets/icons
