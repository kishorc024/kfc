<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-08-18 10:55:59 --> Config Class Initialized
INFO - 2021-08-18 10:55:59 --> Hooks Class Initialized
DEBUG - 2021-08-18 10:55:59 --> UTF-8 Support Enabled
INFO - 2021-08-18 10:55:59 --> Utf8 Class Initialized
INFO - 2021-08-18 10:55:59 --> URI Class Initialized
DEBUG - 2021-08-18 10:55:59 --> No URI present. Default controller set.
INFO - 2021-08-18 10:55:59 --> Router Class Initialized
INFO - 2021-08-18 10:55:59 --> Output Class Initialized
INFO - 2021-08-18 10:55:59 --> Security Class Initialized
DEBUG - 2021-08-18 10:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 10:55:59 --> Input Class Initialized
INFO - 2021-08-18 10:55:59 --> Language Class Initialized
INFO - 2021-08-18 10:55:59 --> Loader Class Initialized
INFO - 2021-08-18 10:55:59 --> Helper loaded: url_helper
INFO - 2021-08-18 10:55:59 --> Helper loaded: file_helper
DEBUG - 2021-08-18 10:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 10:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 10:55:59 --> Controller Class Initialized
INFO - 2021-08-18 10:55:59 --> Helper loaded: cookie_helper
INFO - 2021-08-18 10:55:59 --> Model "CookieModel" initialized
INFO - 2021-08-18 10:56:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 10:56:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-18 10:56:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 10:56:00 --> Final output sent to browser
DEBUG - 2021-08-18 10:56:00 --> Total execution time: 0.0569
INFO - 2021-08-18 10:56:58 --> Config Class Initialized
INFO - 2021-08-18 10:56:58 --> Hooks Class Initialized
DEBUG - 2021-08-18 10:56:58 --> UTF-8 Support Enabled
INFO - 2021-08-18 10:56:58 --> Utf8 Class Initialized
INFO - 2021-08-18 10:56:58 --> URI Class Initialized
INFO - 2021-08-18 10:56:58 --> Router Class Initialized
INFO - 2021-08-18 10:56:58 --> Output Class Initialized
INFO - 2021-08-18 10:56:58 --> Security Class Initialized
DEBUG - 2021-08-18 10:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 10:56:58 --> Input Class Initialized
INFO - 2021-08-18 10:56:58 --> Language Class Initialized
INFO - 2021-08-18 10:56:58 --> Loader Class Initialized
INFO - 2021-08-18 10:56:58 --> Helper loaded: url_helper
INFO - 2021-08-18 10:56:58 --> Helper loaded: file_helper
DEBUG - 2021-08-18 10:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 10:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 10:56:58 --> Controller Class Initialized
INFO - 2021-08-18 10:56:58 --> Helper loaded: cookie_helper
INFO - 2021-08-18 10:56:58 --> Model "CookieModel" initialized
INFO - 2021-08-18 10:56:58 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 10:56:58 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-18 10:56:58 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 10:56:58 --> Final output sent to browser
DEBUG - 2021-08-18 10:56:58 --> Total execution time: 0.0494
INFO - 2021-08-18 10:57:00 --> Config Class Initialized
INFO - 2021-08-18 10:57:00 --> Hooks Class Initialized
DEBUG - 2021-08-18 10:57:00 --> UTF-8 Support Enabled
INFO - 2021-08-18 10:57:00 --> Utf8 Class Initialized
INFO - 2021-08-18 10:57:00 --> URI Class Initialized
INFO - 2021-08-18 10:57:00 --> Router Class Initialized
INFO - 2021-08-18 10:57:00 --> Output Class Initialized
INFO - 2021-08-18 10:57:00 --> Security Class Initialized
DEBUG - 2021-08-18 10:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 10:57:00 --> Input Class Initialized
INFO - 2021-08-18 10:57:00 --> Language Class Initialized
INFO - 2021-08-18 10:57:00 --> Loader Class Initialized
INFO - 2021-08-18 10:57:00 --> Helper loaded: url_helper
INFO - 2021-08-18 10:57:00 --> Helper loaded: file_helper
DEBUG - 2021-08-18 10:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 10:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 10:57:00 --> Controller Class Initialized
INFO - 2021-08-18 10:57:00 --> Helper loaded: cookie_helper
INFO - 2021-08-18 10:57:00 --> Model "CookieModel" initialized
INFO - 2021-08-18 10:57:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 10:57:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/team.php
INFO - 2021-08-18 10:57:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 10:57:00 --> Final output sent to browser
DEBUG - 2021-08-18 10:57:00 --> Total execution time: 0.0353
INFO - 2021-08-18 11:10:05 --> Config Class Initialized
INFO - 2021-08-18 11:10:05 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:10:05 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:10:05 --> Utf8 Class Initialized
INFO - 2021-08-18 11:10:05 --> URI Class Initialized
INFO - 2021-08-18 11:10:05 --> Router Class Initialized
INFO - 2021-08-18 11:10:05 --> Output Class Initialized
INFO - 2021-08-18 11:10:05 --> Security Class Initialized
DEBUG - 2021-08-18 11:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:10:05 --> Input Class Initialized
INFO - 2021-08-18 11:10:05 --> Language Class Initialized
INFO - 2021-08-18 11:10:05 --> Loader Class Initialized
INFO - 2021-08-18 11:10:05 --> Helper loaded: url_helper
INFO - 2021-08-18 11:10:05 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:10:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:10:05 --> Controller Class Initialized
INFO - 2021-08-18 11:10:05 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:10:05 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:10:05 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:10:05 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-18 11:10:05 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:10:05 --> Final output sent to browser
DEBUG - 2021-08-18 11:10:05 --> Total execution time: 0.0560
INFO - 2021-08-18 11:10:29 --> Config Class Initialized
INFO - 2021-08-18 11:10:29 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:10:29 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:10:29 --> Utf8 Class Initialized
INFO - 2021-08-18 11:10:29 --> URI Class Initialized
INFO - 2021-08-18 11:10:29 --> Router Class Initialized
INFO - 2021-08-18 11:10:29 --> Output Class Initialized
INFO - 2021-08-18 11:10:29 --> Security Class Initialized
DEBUG - 2021-08-18 11:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:10:29 --> Input Class Initialized
INFO - 2021-08-18 11:10:29 --> Language Class Initialized
INFO - 2021-08-18 11:10:29 --> Loader Class Initialized
INFO - 2021-08-18 11:10:29 --> Helper loaded: url_helper
INFO - 2021-08-18 11:10:29 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:10:29 --> Controller Class Initialized
INFO - 2021-08-18 11:10:29 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:10:29 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:10:29 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:10:29 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/team.php
INFO - 2021-08-18 11:10:29 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:10:29 --> Final output sent to browser
DEBUG - 2021-08-18 11:10:29 --> Total execution time: 0.0337
INFO - 2021-08-18 11:10:49 --> Config Class Initialized
INFO - 2021-08-18 11:10:50 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:10:50 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:10:50 --> Utf8 Class Initialized
INFO - 2021-08-18 11:10:50 --> URI Class Initialized
INFO - 2021-08-18 11:10:50 --> Router Class Initialized
INFO - 2021-08-18 11:10:50 --> Output Class Initialized
INFO - 2021-08-18 11:10:50 --> Security Class Initialized
DEBUG - 2021-08-18 11:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:10:50 --> Input Class Initialized
INFO - 2021-08-18 11:10:50 --> Language Class Initialized
INFO - 2021-08-18 11:10:50 --> Loader Class Initialized
INFO - 2021-08-18 11:10:50 --> Helper loaded: url_helper
INFO - 2021-08-18 11:10:50 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:10:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:10:50 --> Controller Class Initialized
INFO - 2021-08-18 11:10:50 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:10:50 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:10:50 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:10:50 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/team.php
INFO - 2021-08-18 11:10:50 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:10:50 --> Final output sent to browser
DEBUG - 2021-08-18 11:10:50 --> Total execution time: 0.0314
INFO - 2021-08-18 11:11:52 --> Config Class Initialized
INFO - 2021-08-18 11:11:52 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:11:52 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:11:52 --> Utf8 Class Initialized
INFO - 2021-08-18 11:11:52 --> URI Class Initialized
INFO - 2021-08-18 11:11:52 --> Router Class Initialized
INFO - 2021-08-18 11:11:52 --> Output Class Initialized
INFO - 2021-08-18 11:11:52 --> Security Class Initialized
DEBUG - 2021-08-18 11:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:11:52 --> Input Class Initialized
INFO - 2021-08-18 11:11:52 --> Language Class Initialized
INFO - 2021-08-18 11:11:52 --> Loader Class Initialized
INFO - 2021-08-18 11:11:52 --> Helper loaded: url_helper
INFO - 2021-08-18 11:11:52 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:11:52 --> Controller Class Initialized
INFO - 2021-08-18 11:11:52 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:11:52 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:11:52 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:11:52 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/team.php
INFO - 2021-08-18 11:11:52 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:11:52 --> Final output sent to browser
DEBUG - 2021-08-18 11:11:52 --> Total execution time: 0.0289
INFO - 2021-08-18 11:12:08 --> Config Class Initialized
INFO - 2021-08-18 11:12:08 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:12:08 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:12:08 --> Utf8 Class Initialized
INFO - 2021-08-18 11:12:08 --> URI Class Initialized
INFO - 2021-08-18 11:12:08 --> Router Class Initialized
INFO - 2021-08-18 11:12:08 --> Output Class Initialized
INFO - 2021-08-18 11:12:08 --> Config Class Initialized
INFO - 2021-08-18 11:12:08 --> Hooks Class Initialized
INFO - 2021-08-18 11:12:08 --> Security Class Initialized
DEBUG - 2021-08-18 11:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:12:08 --> Input Class Initialized
DEBUG - 2021-08-18 11:12:08 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:12:08 --> Utf8 Class Initialized
INFO - 2021-08-18 11:12:08 --> Language Class Initialized
INFO - 2021-08-18 11:12:08 --> URI Class Initialized
ERROR - 2021-08-18 11:12:08 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 11:12:08 --> Router Class Initialized
INFO - 2021-08-18 11:12:08 --> Output Class Initialized
INFO - 2021-08-18 11:12:08 --> Security Class Initialized
DEBUG - 2021-08-18 11:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:12:08 --> Input Class Initialized
INFO - 2021-08-18 11:12:08 --> Language Class Initialized
ERROR - 2021-08-18 11:12:08 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 11:12:08 --> Config Class Initialized
INFO - 2021-08-18 11:12:08 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:12:08 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:12:08 --> Utf8 Class Initialized
INFO - 2021-08-18 11:12:08 --> URI Class Initialized
INFO - 2021-08-18 11:12:08 --> Router Class Initialized
INFO - 2021-08-18 11:12:08 --> Output Class Initialized
INFO - 2021-08-18 11:12:08 --> Security Class Initialized
DEBUG - 2021-08-18 11:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:12:08 --> Input Class Initialized
INFO - 2021-08-18 11:12:08 --> Language Class Initialized
ERROR - 2021-08-18 11:12:08 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 11:12:08 --> Config Class Initialized
INFO - 2021-08-18 11:12:08 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:12:08 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:12:08 --> Utf8 Class Initialized
INFO - 2021-08-18 11:12:08 --> Config Class Initialized
INFO - 2021-08-18 11:12:08 --> Hooks Class Initialized
INFO - 2021-08-18 11:12:08 --> URI Class Initialized
INFO - 2021-08-18 11:12:08 --> Router Class Initialized
DEBUG - 2021-08-18 11:12:08 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:12:08 --> Utf8 Class Initialized
INFO - 2021-08-18 11:12:08 --> URI Class Initialized
INFO - 2021-08-18 11:12:08 --> Output Class Initialized
INFO - 2021-08-18 11:12:08 --> Router Class Initialized
INFO - 2021-08-18 11:12:08 --> Security Class Initialized
INFO - 2021-08-18 11:12:08 --> Output Class Initialized
DEBUG - 2021-08-18 11:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:12:08 --> Input Class Initialized
INFO - 2021-08-18 11:12:08 --> Security Class Initialized
INFO - 2021-08-18 11:12:08 --> Language Class Initialized
DEBUG - 2021-08-18 11:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:12:08 --> Input Class Initialized
ERROR - 2021-08-18 11:12:08 --> 404 Page Not Found: Assets/css
INFO - 2021-08-18 11:12:08 --> Language Class Initialized
ERROR - 2021-08-18 11:12:08 --> 404 Page Not Found: Assets/css
INFO - 2021-08-18 11:12:52 --> Config Class Initialized
INFO - 2021-08-18 11:12:52 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:12:52 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:12:52 --> Utf8 Class Initialized
INFO - 2021-08-18 11:12:52 --> URI Class Initialized
INFO - 2021-08-18 11:12:52 --> Router Class Initialized
INFO - 2021-08-18 11:12:52 --> Output Class Initialized
INFO - 2021-08-18 11:12:52 --> Security Class Initialized
DEBUG - 2021-08-18 11:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:12:52 --> Input Class Initialized
INFO - 2021-08-18 11:12:52 --> Language Class Initialized
INFO - 2021-08-18 11:12:52 --> Loader Class Initialized
INFO - 2021-08-18 11:12:52 --> Helper loaded: url_helper
INFO - 2021-08-18 11:12:52 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:12:52 --> Controller Class Initialized
INFO - 2021-08-18 11:12:52 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:12:52 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:12:52 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:12:52 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/team.php
INFO - 2021-08-18 11:12:52 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:12:52 --> Final output sent to browser
DEBUG - 2021-08-18 11:12:52 --> Total execution time: 0.0345
INFO - 2021-08-18 11:12:52 --> Config Class Initialized
INFO - 2021-08-18 11:12:52 --> Hooks Class Initialized
INFO - 2021-08-18 11:12:52 --> Config Class Initialized
INFO - 2021-08-18 11:12:52 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:12:52 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:12:52 --> Utf8 Class Initialized
INFO - 2021-08-18 11:12:52 --> URI Class Initialized
DEBUG - 2021-08-18 11:12:52 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:12:52 --> Utf8 Class Initialized
INFO - 2021-08-18 11:12:52 --> Router Class Initialized
INFO - 2021-08-18 11:12:52 --> URI Class Initialized
INFO - 2021-08-18 11:12:52 --> Output Class Initialized
INFO - 2021-08-18 11:12:52 --> Router Class Initialized
INFO - 2021-08-18 11:12:52 --> Security Class Initialized
INFO - 2021-08-18 11:12:52 --> Output Class Initialized
DEBUG - 2021-08-18 11:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:12:52 --> Input Class Initialized
INFO - 2021-08-18 11:12:52 --> Security Class Initialized
INFO - 2021-08-18 11:12:52 --> Language Class Initialized
DEBUG - 2021-08-18 11:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:12:52 --> Input Class Initialized
ERROR - 2021-08-18 11:12:52 --> 404 Page Not Found: Assets/css
INFO - 2021-08-18 11:12:52 --> Language Class Initialized
ERROR - 2021-08-18 11:12:52 --> 404 Page Not Found: Assets/css
INFO - 2021-08-18 11:12:52 --> Config Class Initialized
INFO - 2021-08-18 11:12:52 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:12:52 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:12:52 --> Utf8 Class Initialized
INFO - 2021-08-18 11:12:52 --> URI Class Initialized
INFO - 2021-08-18 11:12:52 --> Config Class Initialized
INFO - 2021-08-18 11:12:52 --> Hooks Class Initialized
INFO - 2021-08-18 11:12:52 --> Router Class Initialized
INFO - 2021-08-18 11:12:52 --> Output Class Initialized
DEBUG - 2021-08-18 11:12:52 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:12:52 --> Utf8 Class Initialized
INFO - 2021-08-18 11:12:52 --> Security Class Initialized
INFO - 2021-08-18 11:12:52 --> URI Class Initialized
DEBUG - 2021-08-18 11:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:12:52 --> Input Class Initialized
INFO - 2021-08-18 11:12:52 --> Router Class Initialized
INFO - 2021-08-18 11:12:52 --> Language Class Initialized
ERROR - 2021-08-18 11:12:52 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 11:12:52 --> Output Class Initialized
INFO - 2021-08-18 11:12:52 --> Security Class Initialized
DEBUG - 2021-08-18 11:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:12:52 --> Input Class Initialized
INFO - 2021-08-18 11:12:52 --> Language Class Initialized
ERROR - 2021-08-18 11:12:52 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 11:12:52 --> Config Class Initialized
INFO - 2021-08-18 11:12:52 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:12:52 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:12:52 --> Utf8 Class Initialized
INFO - 2021-08-18 11:12:52 --> URI Class Initialized
INFO - 2021-08-18 11:12:52 --> Router Class Initialized
INFO - 2021-08-18 11:12:52 --> Output Class Initialized
INFO - 2021-08-18 11:12:52 --> Security Class Initialized
DEBUG - 2021-08-18 11:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:12:52 --> Input Class Initialized
INFO - 2021-08-18 11:12:52 --> Language Class Initialized
ERROR - 2021-08-18 11:12:52 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 11:13:04 --> Config Class Initialized
INFO - 2021-08-18 11:13:04 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:13:04 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:13:04 --> Utf8 Class Initialized
INFO - 2021-08-18 11:13:04 --> URI Class Initialized
INFO - 2021-08-18 11:13:04 --> Router Class Initialized
INFO - 2021-08-18 11:13:04 --> Output Class Initialized
INFO - 2021-08-18 11:13:04 --> Security Class Initialized
DEBUG - 2021-08-18 11:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:13:04 --> Input Class Initialized
INFO - 2021-08-18 11:13:04 --> Language Class Initialized
INFO - 2021-08-18 11:13:04 --> Loader Class Initialized
INFO - 2021-08-18 11:13:04 --> Helper loaded: url_helper
INFO - 2021-08-18 11:13:04 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:13:04 --> Controller Class Initialized
INFO - 2021-08-18 11:13:04 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:13:04 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:13:04 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:13:04 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/team.php
INFO - 2021-08-18 11:13:04 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:13:04 --> Final output sent to browser
DEBUG - 2021-08-18 11:13:04 --> Total execution time: 0.0327
INFO - 2021-08-18 11:13:15 --> Config Class Initialized
INFO - 2021-08-18 11:13:15 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:13:15 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:13:15 --> Utf8 Class Initialized
INFO - 2021-08-18 11:13:15 --> URI Class Initialized
INFO - 2021-08-18 11:13:15 --> Router Class Initialized
INFO - 2021-08-18 11:13:15 --> Output Class Initialized
INFO - 2021-08-18 11:13:15 --> Security Class Initialized
DEBUG - 2021-08-18 11:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:13:15 --> Input Class Initialized
INFO - 2021-08-18 11:13:15 --> Language Class Initialized
INFO - 2021-08-18 11:13:15 --> Loader Class Initialized
INFO - 2021-08-18 11:13:15 --> Helper loaded: url_helper
INFO - 2021-08-18 11:13:15 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:13:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:13:15 --> Controller Class Initialized
INFO - 2021-08-18 11:13:15 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:13:15 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:13:15 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:13:15 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/team.php
INFO - 2021-08-18 11:13:15 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:13:15 --> Final output sent to browser
DEBUG - 2021-08-18 11:13:15 --> Total execution time: 0.0296
INFO - 2021-08-18 11:13:23 --> Config Class Initialized
INFO - 2021-08-18 11:13:23 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:13:23 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:13:23 --> Utf8 Class Initialized
INFO - 2021-08-18 11:13:23 --> URI Class Initialized
INFO - 2021-08-18 11:13:23 --> Router Class Initialized
INFO - 2021-08-18 11:13:23 --> Output Class Initialized
INFO - 2021-08-18 11:13:23 --> Security Class Initialized
DEBUG - 2021-08-18 11:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:13:23 --> Input Class Initialized
INFO - 2021-08-18 11:13:23 --> Language Class Initialized
INFO - 2021-08-18 11:13:23 --> Loader Class Initialized
INFO - 2021-08-18 11:13:23 --> Helper loaded: url_helper
INFO - 2021-08-18 11:13:23 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:13:23 --> Controller Class Initialized
INFO - 2021-08-18 11:13:23 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:13:23 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:13:23 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:13:23 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/team.php
INFO - 2021-08-18 11:13:23 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:13:23 --> Final output sent to browser
DEBUG - 2021-08-18 11:13:23 --> Total execution time: 0.0342
INFO - 2021-08-18 11:19:43 --> Config Class Initialized
INFO - 2021-08-18 11:19:43 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:19:43 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:19:43 --> Utf8 Class Initialized
INFO - 2021-08-18 11:19:43 --> URI Class Initialized
INFO - 2021-08-18 11:19:43 --> Router Class Initialized
INFO - 2021-08-18 11:19:43 --> Output Class Initialized
INFO - 2021-08-18 11:19:43 --> Security Class Initialized
DEBUG - 2021-08-18 11:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:19:43 --> Input Class Initialized
INFO - 2021-08-18 11:19:43 --> Language Class Initialized
INFO - 2021-08-18 11:19:43 --> Loader Class Initialized
INFO - 2021-08-18 11:19:43 --> Helper loaded: url_helper
INFO - 2021-08-18 11:19:43 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:19:43 --> Controller Class Initialized
INFO - 2021-08-18 11:19:43 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:19:43 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:19:43 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:19:43 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 11:19:43 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:19:43 --> Final output sent to browser
DEBUG - 2021-08-18 11:19:43 --> Total execution time: 0.0431
INFO - 2021-08-18 11:20:14 --> Config Class Initialized
INFO - 2021-08-18 11:20:14 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:20:14 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:20:14 --> Utf8 Class Initialized
INFO - 2021-08-18 11:20:14 --> URI Class Initialized
INFO - 2021-08-18 11:20:14 --> Router Class Initialized
INFO - 2021-08-18 11:20:14 --> Output Class Initialized
INFO - 2021-08-18 11:20:14 --> Security Class Initialized
DEBUG - 2021-08-18 11:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:20:14 --> Input Class Initialized
INFO - 2021-08-18 11:20:14 --> Language Class Initialized
INFO - 2021-08-18 11:20:14 --> Loader Class Initialized
INFO - 2021-08-18 11:20:14 --> Helper loaded: url_helper
INFO - 2021-08-18 11:20:14 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:20:14 --> Controller Class Initialized
INFO - 2021-08-18 11:20:14 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:20:14 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:20:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:20:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/pilates.php
INFO - 2021-08-18 11:20:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:20:14 --> Final output sent to browser
DEBUG - 2021-08-18 11:20:14 --> Total execution time: 0.0392
INFO - 2021-08-18 11:22:05 --> Config Class Initialized
INFO - 2021-08-18 11:22:05 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:22:05 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:22:05 --> Utf8 Class Initialized
INFO - 2021-08-18 11:22:05 --> URI Class Initialized
INFO - 2021-08-18 11:22:05 --> Router Class Initialized
INFO - 2021-08-18 11:22:05 --> Output Class Initialized
INFO - 2021-08-18 11:22:05 --> Security Class Initialized
DEBUG - 2021-08-18 11:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:22:05 --> Input Class Initialized
INFO - 2021-08-18 11:22:05 --> Language Class Initialized
INFO - 2021-08-18 11:22:05 --> Loader Class Initialized
INFO - 2021-08-18 11:22:05 --> Helper loaded: url_helper
INFO - 2021-08-18 11:22:05 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:22:05 --> Controller Class Initialized
INFO - 2021-08-18 11:22:05 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:22:05 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:22:05 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:22:05 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/pilates.php
INFO - 2021-08-18 11:22:05 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:22:05 --> Final output sent to browser
DEBUG - 2021-08-18 11:22:05 --> Total execution time: 0.0334
INFO - 2021-08-18 11:22:33 --> Config Class Initialized
INFO - 2021-08-18 11:22:33 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:22:33 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:22:33 --> Utf8 Class Initialized
INFO - 2021-08-18 11:22:33 --> URI Class Initialized
INFO - 2021-08-18 11:22:33 --> Router Class Initialized
INFO - 2021-08-18 11:22:33 --> Output Class Initialized
INFO - 2021-08-18 11:22:33 --> Security Class Initialized
DEBUG - 2021-08-18 11:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:22:33 --> Input Class Initialized
INFO - 2021-08-18 11:22:33 --> Language Class Initialized
INFO - 2021-08-18 11:22:33 --> Loader Class Initialized
INFO - 2021-08-18 11:22:33 --> Helper loaded: url_helper
INFO - 2021-08-18 11:22:33 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:22:33 --> Controller Class Initialized
INFO - 2021-08-18 11:22:33 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:22:33 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:22:33 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:22:33 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 11:22:33 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:22:33 --> Final output sent to browser
DEBUG - 2021-08-18 11:22:33 --> Total execution time: 0.0343
INFO - 2021-08-18 11:22:39 --> Config Class Initialized
INFO - 2021-08-18 11:22:39 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:22:39 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:22:39 --> Utf8 Class Initialized
INFO - 2021-08-18 11:22:39 --> URI Class Initialized
DEBUG - 2021-08-18 11:22:39 --> No URI present. Default controller set.
INFO - 2021-08-18 11:22:39 --> Router Class Initialized
INFO - 2021-08-18 11:22:39 --> Output Class Initialized
INFO - 2021-08-18 11:22:39 --> Security Class Initialized
DEBUG - 2021-08-18 11:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:22:39 --> Input Class Initialized
INFO - 2021-08-18 11:22:39 --> Language Class Initialized
INFO - 2021-08-18 11:22:39 --> Loader Class Initialized
INFO - 2021-08-18 11:22:39 --> Helper loaded: url_helper
INFO - 2021-08-18 11:22:39 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:22:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:22:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:22:39 --> Controller Class Initialized
INFO - 2021-08-18 11:22:39 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:22:39 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:22:39 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:22:39 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-18 11:22:39 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:22:39 --> Final output sent to browser
DEBUG - 2021-08-18 11:22:39 --> Total execution time: 0.0352
INFO - 2021-08-18 11:22:43 --> Config Class Initialized
INFO - 2021-08-18 11:22:43 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:22:43 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:22:43 --> Utf8 Class Initialized
INFO - 2021-08-18 11:22:43 --> URI Class Initialized
INFO - 2021-08-18 11:22:43 --> Router Class Initialized
INFO - 2021-08-18 11:22:43 --> Output Class Initialized
INFO - 2021-08-18 11:22:43 --> Security Class Initialized
DEBUG - 2021-08-18 11:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:22:43 --> Input Class Initialized
INFO - 2021-08-18 11:22:43 --> Language Class Initialized
INFO - 2021-08-18 11:22:43 --> Loader Class Initialized
INFO - 2021-08-18 11:22:43 --> Helper loaded: url_helper
INFO - 2021-08-18 11:22:43 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:22:43 --> Controller Class Initialized
INFO - 2021-08-18 11:22:43 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:22:43 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:22:43 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:22:43 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 11:22:43 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:22:43 --> Final output sent to browser
DEBUG - 2021-08-18 11:22:43 --> Total execution time: 0.0407
INFO - 2021-08-18 11:23:38 --> Config Class Initialized
INFO - 2021-08-18 11:23:38 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:23:38 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:23:38 --> Utf8 Class Initialized
INFO - 2021-08-18 11:23:38 --> URI Class Initialized
INFO - 2021-08-18 11:23:38 --> Router Class Initialized
INFO - 2021-08-18 11:23:38 --> Output Class Initialized
INFO - 2021-08-18 11:23:38 --> Security Class Initialized
DEBUG - 2021-08-18 11:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:23:38 --> Input Class Initialized
INFO - 2021-08-18 11:23:38 --> Language Class Initialized
INFO - 2021-08-18 11:23:38 --> Loader Class Initialized
INFO - 2021-08-18 11:23:38 --> Helper loaded: url_helper
INFO - 2021-08-18 11:23:38 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:23:39 --> Controller Class Initialized
INFO - 2021-08-18 11:23:39 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:23:39 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:23:39 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:23:39 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 11:23:39 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:23:39 --> Final output sent to browser
DEBUG - 2021-08-18 11:23:39 --> Total execution time: 0.0325
INFO - 2021-08-18 11:23:42 --> Config Class Initialized
INFO - 2021-08-18 11:23:42 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:23:42 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:23:42 --> Utf8 Class Initialized
INFO - 2021-08-18 11:23:42 --> URI Class Initialized
DEBUG - 2021-08-18 11:23:42 --> No URI present. Default controller set.
INFO - 2021-08-18 11:23:42 --> Router Class Initialized
INFO - 2021-08-18 11:23:42 --> Output Class Initialized
INFO - 2021-08-18 11:23:42 --> Security Class Initialized
DEBUG - 2021-08-18 11:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:23:42 --> Input Class Initialized
INFO - 2021-08-18 11:23:42 --> Language Class Initialized
INFO - 2021-08-18 11:23:42 --> Loader Class Initialized
INFO - 2021-08-18 11:23:42 --> Helper loaded: url_helper
INFO - 2021-08-18 11:23:42 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:23:42 --> Controller Class Initialized
INFO - 2021-08-18 11:23:42 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:23:42 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:23:42 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:23:42 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-18 11:23:42 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:23:42 --> Final output sent to browser
DEBUG - 2021-08-18 11:23:42 --> Total execution time: 0.0349
INFO - 2021-08-18 11:23:45 --> Config Class Initialized
INFO - 2021-08-18 11:23:45 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:23:45 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:23:45 --> Utf8 Class Initialized
INFO - 2021-08-18 11:23:45 --> URI Class Initialized
INFO - 2021-08-18 11:23:45 --> Router Class Initialized
INFO - 2021-08-18 11:23:45 --> Output Class Initialized
INFO - 2021-08-18 11:23:45 --> Security Class Initialized
DEBUG - 2021-08-18 11:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:23:45 --> Input Class Initialized
INFO - 2021-08-18 11:23:45 --> Language Class Initialized
INFO - 2021-08-18 11:23:45 --> Loader Class Initialized
INFO - 2021-08-18 11:23:45 --> Helper loaded: url_helper
INFO - 2021-08-18 11:23:45 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:23:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:23:45 --> Controller Class Initialized
INFO - 2021-08-18 11:23:45 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:23:45 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:23:45 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:23:45 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 11:23:45 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:23:45 --> Final output sent to browser
DEBUG - 2021-08-18 11:23:45 --> Total execution time: 0.0384
INFO - 2021-08-18 11:24:04 --> Config Class Initialized
INFO - 2021-08-18 11:24:04 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:24:04 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:24:04 --> Utf8 Class Initialized
INFO - 2021-08-18 11:24:04 --> URI Class Initialized
INFO - 2021-08-18 11:24:04 --> Router Class Initialized
INFO - 2021-08-18 11:24:04 --> Output Class Initialized
INFO - 2021-08-18 11:24:04 --> Security Class Initialized
DEBUG - 2021-08-18 11:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:24:04 --> Input Class Initialized
INFO - 2021-08-18 11:24:04 --> Language Class Initialized
INFO - 2021-08-18 11:24:04 --> Loader Class Initialized
INFO - 2021-08-18 11:24:04 --> Helper loaded: url_helper
INFO - 2021-08-18 11:24:04 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:24:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:24:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:24:04 --> Controller Class Initialized
INFO - 2021-08-18 11:24:04 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:24:04 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:24:04 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:24:04 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 11:24:04 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:24:04 --> Final output sent to browser
DEBUG - 2021-08-18 11:24:04 --> Total execution time: 0.0293
INFO - 2021-08-18 11:24:09 --> Config Class Initialized
INFO - 2021-08-18 11:24:09 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:24:09 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:24:09 --> Utf8 Class Initialized
INFO - 2021-08-18 11:24:09 --> URI Class Initialized
DEBUG - 2021-08-18 11:24:09 --> No URI present. Default controller set.
INFO - 2021-08-18 11:24:09 --> Router Class Initialized
INFO - 2021-08-18 11:24:09 --> Output Class Initialized
INFO - 2021-08-18 11:24:09 --> Security Class Initialized
DEBUG - 2021-08-18 11:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:24:09 --> Input Class Initialized
INFO - 2021-08-18 11:24:09 --> Language Class Initialized
INFO - 2021-08-18 11:24:09 --> Loader Class Initialized
INFO - 2021-08-18 11:24:09 --> Helper loaded: url_helper
INFO - 2021-08-18 11:24:09 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:24:09 --> Controller Class Initialized
INFO - 2021-08-18 11:24:09 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:24:09 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:24:09 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:24:09 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-18 11:24:09 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:24:09 --> Final output sent to browser
DEBUG - 2021-08-18 11:24:09 --> Total execution time: 0.0324
INFO - 2021-08-18 11:24:11 --> Config Class Initialized
INFO - 2021-08-18 11:24:11 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:24:11 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:24:11 --> Utf8 Class Initialized
INFO - 2021-08-18 11:24:11 --> URI Class Initialized
INFO - 2021-08-18 11:24:11 --> Router Class Initialized
INFO - 2021-08-18 11:24:11 --> Output Class Initialized
INFO - 2021-08-18 11:24:11 --> Security Class Initialized
DEBUG - 2021-08-18 11:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:24:11 --> Input Class Initialized
INFO - 2021-08-18 11:24:11 --> Language Class Initialized
INFO - 2021-08-18 11:24:11 --> Loader Class Initialized
INFO - 2021-08-18 11:24:11 --> Helper loaded: url_helper
INFO - 2021-08-18 11:24:11 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:24:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:24:11 --> Controller Class Initialized
INFO - 2021-08-18 11:24:11 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:24:11 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:24:11 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:24:11 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 11:24:11 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:24:11 --> Final output sent to browser
DEBUG - 2021-08-18 11:24:11 --> Total execution time: 0.0364
INFO - 2021-08-18 11:24:50 --> Config Class Initialized
INFO - 2021-08-18 11:24:50 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:24:50 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:24:50 --> Utf8 Class Initialized
INFO - 2021-08-18 11:24:50 --> URI Class Initialized
INFO - 2021-08-18 11:24:50 --> Router Class Initialized
INFO - 2021-08-18 11:24:50 --> Output Class Initialized
INFO - 2021-08-18 11:24:50 --> Security Class Initialized
DEBUG - 2021-08-18 11:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:24:50 --> Input Class Initialized
INFO - 2021-08-18 11:24:50 --> Language Class Initialized
INFO - 2021-08-18 11:24:50 --> Loader Class Initialized
INFO - 2021-08-18 11:24:50 --> Helper loaded: url_helper
INFO - 2021-08-18 11:24:50 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:24:50 --> Controller Class Initialized
INFO - 2021-08-18 11:24:50 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:24:50 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:24:50 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:24:50 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 11:24:50 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:24:50 --> Final output sent to browser
DEBUG - 2021-08-18 11:24:50 --> Total execution time: 0.0328
INFO - 2021-08-18 11:25:14 --> Config Class Initialized
INFO - 2021-08-18 11:25:14 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:25:14 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:25:14 --> Utf8 Class Initialized
INFO - 2021-08-18 11:25:14 --> URI Class Initialized
INFO - 2021-08-18 11:25:14 --> Router Class Initialized
INFO - 2021-08-18 11:25:14 --> Output Class Initialized
INFO - 2021-08-18 11:25:14 --> Security Class Initialized
DEBUG - 2021-08-18 11:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:25:14 --> Input Class Initialized
INFO - 2021-08-18 11:25:14 --> Language Class Initialized
INFO - 2021-08-18 11:25:14 --> Loader Class Initialized
INFO - 2021-08-18 11:25:14 --> Helper loaded: url_helper
INFO - 2021-08-18 11:25:14 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:25:14 --> Controller Class Initialized
INFO - 2021-08-18 11:25:14 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:25:14 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:25:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:25:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 11:25:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:25:14 --> Final output sent to browser
DEBUG - 2021-08-18 11:25:14 --> Total execution time: 0.0330
INFO - 2021-08-18 11:25:22 --> Config Class Initialized
INFO - 2021-08-18 11:25:22 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:25:22 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:25:22 --> Utf8 Class Initialized
INFO - 2021-08-18 11:25:22 --> URI Class Initialized
DEBUG - 2021-08-18 11:25:22 --> No URI present. Default controller set.
INFO - 2021-08-18 11:25:22 --> Router Class Initialized
INFO - 2021-08-18 11:25:22 --> Output Class Initialized
INFO - 2021-08-18 11:25:22 --> Security Class Initialized
DEBUG - 2021-08-18 11:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:25:22 --> Input Class Initialized
INFO - 2021-08-18 11:25:22 --> Language Class Initialized
INFO - 2021-08-18 11:25:22 --> Loader Class Initialized
INFO - 2021-08-18 11:25:22 --> Helper loaded: url_helper
INFO - 2021-08-18 11:25:22 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:25:22 --> Controller Class Initialized
INFO - 2021-08-18 11:25:22 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:25:22 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:25:22 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:25:22 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-18 11:25:22 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:25:22 --> Final output sent to browser
DEBUG - 2021-08-18 11:25:22 --> Total execution time: 0.0345
INFO - 2021-08-18 11:25:25 --> Config Class Initialized
INFO - 2021-08-18 11:25:25 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:25:25 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:25:25 --> Utf8 Class Initialized
INFO - 2021-08-18 11:25:25 --> URI Class Initialized
INFO - 2021-08-18 11:25:25 --> Router Class Initialized
INFO - 2021-08-18 11:25:25 --> Output Class Initialized
INFO - 2021-08-18 11:25:25 --> Security Class Initialized
DEBUG - 2021-08-18 11:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:25:25 --> Input Class Initialized
INFO - 2021-08-18 11:25:25 --> Language Class Initialized
INFO - 2021-08-18 11:25:25 --> Loader Class Initialized
INFO - 2021-08-18 11:25:25 --> Helper loaded: url_helper
INFO - 2021-08-18 11:25:25 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:25:25 --> Controller Class Initialized
INFO - 2021-08-18 11:25:25 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:25:25 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:25:25 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:25:25 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 11:25:25 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:25:25 --> Final output sent to browser
DEBUG - 2021-08-18 11:25:25 --> Total execution time: 0.0393
INFO - 2021-08-18 11:25:30 --> Config Class Initialized
INFO - 2021-08-18 11:25:30 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:25:30 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:25:30 --> Utf8 Class Initialized
INFO - 2021-08-18 11:25:30 --> URI Class Initialized
INFO - 2021-08-18 11:25:30 --> Router Class Initialized
INFO - 2021-08-18 11:25:30 --> Output Class Initialized
INFO - 2021-08-18 11:25:30 --> Security Class Initialized
DEBUG - 2021-08-18 11:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:25:30 --> Input Class Initialized
INFO - 2021-08-18 11:25:30 --> Language Class Initialized
INFO - 2021-08-18 11:25:30 --> Loader Class Initialized
INFO - 2021-08-18 11:25:30 --> Helper loaded: url_helper
INFO - 2021-08-18 11:25:30 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:25:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:25:30 --> Controller Class Initialized
INFO - 2021-08-18 11:25:30 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:25:30 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:25:30 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:25:30 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/pilates.php
INFO - 2021-08-18 11:25:30 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:25:30 --> Final output sent to browser
DEBUG - 2021-08-18 11:25:30 --> Total execution time: 0.0388
INFO - 2021-08-18 11:25:32 --> Config Class Initialized
INFO - 2021-08-18 11:25:32 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:25:32 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:25:32 --> Utf8 Class Initialized
INFO - 2021-08-18 11:25:32 --> URI Class Initialized
INFO - 2021-08-18 11:25:32 --> Router Class Initialized
INFO - 2021-08-18 11:25:32 --> Output Class Initialized
INFO - 2021-08-18 11:25:32 --> Security Class Initialized
DEBUG - 2021-08-18 11:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:25:32 --> Input Class Initialized
INFO - 2021-08-18 11:25:32 --> Language Class Initialized
INFO - 2021-08-18 11:25:32 --> Loader Class Initialized
INFO - 2021-08-18 11:25:32 --> Helper loaded: url_helper
INFO - 2021-08-18 11:25:32 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:25:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:25:32 --> Controller Class Initialized
INFO - 2021-08-18 11:25:32 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:25:32 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:25:32 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:25:32 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 11:25:32 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:25:32 --> Final output sent to browser
DEBUG - 2021-08-18 11:25:32 --> Total execution time: 0.0310
INFO - 2021-08-18 11:25:59 --> Config Class Initialized
INFO - 2021-08-18 11:25:59 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:25:59 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:25:59 --> Utf8 Class Initialized
INFO - 2021-08-18 11:25:59 --> URI Class Initialized
INFO - 2021-08-18 11:25:59 --> Router Class Initialized
INFO - 2021-08-18 11:25:59 --> Output Class Initialized
INFO - 2021-08-18 11:25:59 --> Security Class Initialized
DEBUG - 2021-08-18 11:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:25:59 --> Input Class Initialized
INFO - 2021-08-18 11:25:59 --> Language Class Initialized
INFO - 2021-08-18 11:25:59 --> Loader Class Initialized
INFO - 2021-08-18 11:25:59 --> Helper loaded: url_helper
INFO - 2021-08-18 11:25:59 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:25:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:25:59 --> Controller Class Initialized
INFO - 2021-08-18 11:25:59 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:25:59 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:25:59 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:25:59 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-18 11:25:59 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:25:59 --> Final output sent to browser
DEBUG - 2021-08-18 11:25:59 --> Total execution time: 0.0400
INFO - 2021-08-18 11:26:00 --> Config Class Initialized
INFO - 2021-08-18 11:26:00 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:26:00 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:26:00 --> Utf8 Class Initialized
INFO - 2021-08-18 11:26:00 --> URI Class Initialized
INFO - 2021-08-18 11:26:00 --> Router Class Initialized
INFO - 2021-08-18 11:26:00 --> Output Class Initialized
INFO - 2021-08-18 11:26:00 --> Security Class Initialized
DEBUG - 2021-08-18 11:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:26:00 --> Input Class Initialized
INFO - 2021-08-18 11:26:00 --> Language Class Initialized
INFO - 2021-08-18 11:26:00 --> Loader Class Initialized
INFO - 2021-08-18 11:26:00 --> Helper loaded: url_helper
INFO - 2021-08-18 11:26:00 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:26:00 --> Controller Class Initialized
INFO - 2021-08-18 11:26:00 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:26:00 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:26:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:26:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/team.php
INFO - 2021-08-18 11:26:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:26:00 --> Final output sent to browser
DEBUG - 2021-08-18 11:26:00 --> Total execution time: 0.0317
INFO - 2021-08-18 11:26:01 --> Config Class Initialized
INFO - 2021-08-18 11:26:01 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:26:01 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:26:01 --> Utf8 Class Initialized
INFO - 2021-08-18 11:26:01 --> URI Class Initialized
INFO - 2021-08-18 11:26:01 --> Router Class Initialized
INFO - 2021-08-18 11:26:01 --> Output Class Initialized
INFO - 2021-08-18 11:26:01 --> Security Class Initialized
DEBUG - 2021-08-18 11:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:26:01 --> Input Class Initialized
INFO - 2021-08-18 11:26:01 --> Language Class Initialized
INFO - 2021-08-18 11:26:01 --> Loader Class Initialized
INFO - 2021-08-18 11:26:01 --> Helper loaded: url_helper
INFO - 2021-08-18 11:26:01 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:26:01 --> Controller Class Initialized
INFO - 2021-08-18 11:26:01 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:26:01 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:26:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:26:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-18 11:26:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:26:01 --> Final output sent to browser
DEBUG - 2021-08-18 11:26:01 --> Total execution time: 0.0337
INFO - 2021-08-18 11:26:31 --> Config Class Initialized
INFO - 2021-08-18 11:26:31 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:26:31 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:26:31 --> Utf8 Class Initialized
INFO - 2021-08-18 11:26:31 --> URI Class Initialized
INFO - 2021-08-18 11:26:31 --> Router Class Initialized
INFO - 2021-08-18 11:26:31 --> Output Class Initialized
INFO - 2021-08-18 11:26:31 --> Security Class Initialized
DEBUG - 2021-08-18 11:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:26:31 --> Input Class Initialized
INFO - 2021-08-18 11:26:31 --> Language Class Initialized
INFO - 2021-08-18 11:26:31 --> Loader Class Initialized
INFO - 2021-08-18 11:26:31 --> Helper loaded: url_helper
INFO - 2021-08-18 11:26:31 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:26:31 --> Controller Class Initialized
INFO - 2021-08-18 11:26:31 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:26:31 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:26:31 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:26:31 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-18 11:26:31 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:26:31 --> Final output sent to browser
DEBUG - 2021-08-18 11:26:31 --> Total execution time: 0.0288
INFO - 2021-08-18 11:27:16 --> Config Class Initialized
INFO - 2021-08-18 11:27:16 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:27:16 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:27:16 --> Utf8 Class Initialized
INFO - 2021-08-18 11:27:16 --> URI Class Initialized
INFO - 2021-08-18 11:27:16 --> Router Class Initialized
INFO - 2021-08-18 11:27:16 --> Output Class Initialized
INFO - 2021-08-18 11:27:16 --> Security Class Initialized
DEBUG - 2021-08-18 11:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:27:16 --> Input Class Initialized
INFO - 2021-08-18 11:27:16 --> Language Class Initialized
INFO - 2021-08-18 11:27:16 --> Loader Class Initialized
INFO - 2021-08-18 11:27:16 --> Helper loaded: url_helper
INFO - 2021-08-18 11:27:16 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:27:16 --> Controller Class Initialized
INFO - 2021-08-18 11:27:16 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:27:16 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:27:16 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:27:16 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-18 11:27:16 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:27:16 --> Final output sent to browser
DEBUG - 2021-08-18 11:27:16 --> Total execution time: 0.0334
INFO - 2021-08-18 11:27:18 --> Config Class Initialized
INFO - 2021-08-18 11:27:18 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:27:18 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:27:18 --> Utf8 Class Initialized
INFO - 2021-08-18 11:27:18 --> URI Class Initialized
INFO - 2021-08-18 11:27:18 --> Router Class Initialized
INFO - 2021-08-18 11:27:18 --> Output Class Initialized
INFO - 2021-08-18 11:27:18 --> Security Class Initialized
DEBUG - 2021-08-18 11:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:27:18 --> Input Class Initialized
INFO - 2021-08-18 11:27:18 --> Language Class Initialized
INFO - 2021-08-18 11:27:18 --> Loader Class Initialized
INFO - 2021-08-18 11:27:18 --> Helper loaded: url_helper
INFO - 2021-08-18 11:27:18 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:27:18 --> Controller Class Initialized
INFO - 2021-08-18 11:27:18 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:27:18 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:27:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:27:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-18 11:27:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:27:18 --> Final output sent to browser
DEBUG - 2021-08-18 11:27:18 --> Total execution time: 0.0297
INFO - 2021-08-18 11:27:18 --> Config Class Initialized
INFO - 2021-08-18 11:27:18 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:27:18 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:27:18 --> Utf8 Class Initialized
INFO - 2021-08-18 11:27:18 --> URI Class Initialized
INFO - 2021-08-18 11:27:18 --> Router Class Initialized
INFO - 2021-08-18 11:27:18 --> Output Class Initialized
INFO - 2021-08-18 11:27:18 --> Security Class Initialized
DEBUG - 2021-08-18 11:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:27:18 --> Input Class Initialized
INFO - 2021-08-18 11:27:18 --> Language Class Initialized
INFO - 2021-08-18 11:27:18 --> Loader Class Initialized
INFO - 2021-08-18 11:27:18 --> Helper loaded: url_helper
INFO - 2021-08-18 11:27:18 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:27:18 --> Controller Class Initialized
INFO - 2021-08-18 11:27:18 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:27:18 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:27:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:27:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-18 11:27:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:27:18 --> Final output sent to browser
DEBUG - 2021-08-18 11:27:18 --> Total execution time: 0.0415
INFO - 2021-08-18 11:27:34 --> Config Class Initialized
INFO - 2021-08-18 11:27:34 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:27:34 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:27:34 --> Utf8 Class Initialized
INFO - 2021-08-18 11:27:34 --> URI Class Initialized
INFO - 2021-08-18 11:27:34 --> Router Class Initialized
INFO - 2021-08-18 11:27:34 --> Output Class Initialized
INFO - 2021-08-18 11:27:34 --> Security Class Initialized
DEBUG - 2021-08-18 11:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:27:34 --> Input Class Initialized
INFO - 2021-08-18 11:27:34 --> Language Class Initialized
INFO - 2021-08-18 11:27:34 --> Loader Class Initialized
INFO - 2021-08-18 11:27:34 --> Helper loaded: url_helper
INFO - 2021-08-18 11:27:34 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:27:34 --> Controller Class Initialized
INFO - 2021-08-18 11:27:34 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:27:34 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:27:34 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:27:34 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-18 11:27:34 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:27:34 --> Final output sent to browser
DEBUG - 2021-08-18 11:27:34 --> Total execution time: 0.0293
INFO - 2021-08-18 11:27:46 --> Config Class Initialized
INFO - 2021-08-18 11:27:46 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:27:46 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:27:46 --> Utf8 Class Initialized
INFO - 2021-08-18 11:27:46 --> URI Class Initialized
INFO - 2021-08-18 11:27:46 --> Router Class Initialized
INFO - 2021-08-18 11:27:46 --> Output Class Initialized
INFO - 2021-08-18 11:27:46 --> Security Class Initialized
DEBUG - 2021-08-18 11:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:27:46 --> Input Class Initialized
INFO - 2021-08-18 11:27:46 --> Language Class Initialized
INFO - 2021-08-18 11:27:46 --> Loader Class Initialized
INFO - 2021-08-18 11:27:46 --> Helper loaded: url_helper
INFO - 2021-08-18 11:27:46 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:27:46 --> Controller Class Initialized
INFO - 2021-08-18 11:27:46 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:27:46 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:27:46 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:27:46 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-18 11:27:46 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:27:46 --> Final output sent to browser
DEBUG - 2021-08-18 11:27:46 --> Total execution time: 0.0321
INFO - 2021-08-18 11:27:53 --> Config Class Initialized
INFO - 2021-08-18 11:27:53 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:27:53 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:27:53 --> Utf8 Class Initialized
INFO - 2021-08-18 11:27:53 --> URI Class Initialized
INFO - 2021-08-18 11:27:53 --> Router Class Initialized
INFO - 2021-08-18 11:27:53 --> Output Class Initialized
INFO - 2021-08-18 11:27:53 --> Security Class Initialized
DEBUG - 2021-08-18 11:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:27:53 --> Input Class Initialized
INFO - 2021-08-18 11:27:53 --> Language Class Initialized
INFO - 2021-08-18 11:27:53 --> Loader Class Initialized
INFO - 2021-08-18 11:27:53 --> Helper loaded: url_helper
INFO - 2021-08-18 11:27:53 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:27:53 --> Controller Class Initialized
INFO - 2021-08-18 11:27:53 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:27:53 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:27:53 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:27:53 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-18 11:27:53 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:27:53 --> Final output sent to browser
DEBUG - 2021-08-18 11:27:53 --> Total execution time: 0.0333
INFO - 2021-08-18 11:28:01 --> Config Class Initialized
INFO - 2021-08-18 11:28:01 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:28:01 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:28:01 --> Utf8 Class Initialized
INFO - 2021-08-18 11:28:01 --> URI Class Initialized
INFO - 2021-08-18 11:28:01 --> Router Class Initialized
INFO - 2021-08-18 11:28:01 --> Output Class Initialized
INFO - 2021-08-18 11:28:01 --> Security Class Initialized
DEBUG - 2021-08-18 11:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:28:01 --> Input Class Initialized
INFO - 2021-08-18 11:28:01 --> Language Class Initialized
INFO - 2021-08-18 11:28:01 --> Loader Class Initialized
INFO - 2021-08-18 11:28:01 --> Helper loaded: url_helper
INFO - 2021-08-18 11:28:01 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:28:01 --> Controller Class Initialized
INFO - 2021-08-18 11:28:01 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:28:01 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:28:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:28:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-18 11:28:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:28:01 --> Final output sent to browser
DEBUG - 2021-08-18 11:28:01 --> Total execution time: 0.0360
INFO - 2021-08-18 11:31:27 --> Config Class Initialized
INFO - 2021-08-18 11:31:27 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:31:27 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:31:27 --> Utf8 Class Initialized
INFO - 2021-08-18 11:31:27 --> URI Class Initialized
INFO - 2021-08-18 11:31:27 --> Router Class Initialized
INFO - 2021-08-18 11:31:27 --> Output Class Initialized
INFO - 2021-08-18 11:31:27 --> Security Class Initialized
DEBUG - 2021-08-18 11:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:31:27 --> Input Class Initialized
INFO - 2021-08-18 11:31:27 --> Language Class Initialized
INFO - 2021-08-18 11:31:27 --> Loader Class Initialized
INFO - 2021-08-18 11:31:27 --> Helper loaded: url_helper
INFO - 2021-08-18 11:31:27 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:31:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:31:28 --> Controller Class Initialized
INFO - 2021-08-18 11:31:28 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:31:28 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:31:28 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:31:28 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-18 11:31:28 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:31:28 --> Final output sent to browser
DEBUG - 2021-08-18 11:31:28 --> Total execution time: 0.0351
INFO - 2021-08-18 11:31:33 --> Config Class Initialized
INFO - 2021-08-18 11:31:33 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:31:33 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:31:33 --> Utf8 Class Initialized
INFO - 2021-08-18 11:31:33 --> URI Class Initialized
INFO - 2021-08-18 11:31:33 --> Router Class Initialized
INFO - 2021-08-18 11:31:33 --> Output Class Initialized
INFO - 2021-08-18 11:31:33 --> Security Class Initialized
DEBUG - 2021-08-18 11:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:31:33 --> Input Class Initialized
INFO - 2021-08-18 11:31:33 --> Language Class Initialized
INFO - 2021-08-18 11:31:33 --> Loader Class Initialized
INFO - 2021-08-18 11:31:33 --> Helper loaded: url_helper
INFO - 2021-08-18 11:31:33 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:31:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:31:33 --> Controller Class Initialized
INFO - 2021-08-18 11:31:33 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:31:33 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:31:33 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:31:33 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-18 11:31:33 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:31:33 --> Final output sent to browser
DEBUG - 2021-08-18 11:31:33 --> Total execution time: 0.0309
INFO - 2021-08-18 11:31:35 --> Config Class Initialized
INFO - 2021-08-18 11:31:35 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:31:35 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:31:35 --> Utf8 Class Initialized
INFO - 2021-08-18 11:31:35 --> URI Class Initialized
INFO - 2021-08-18 11:31:35 --> Router Class Initialized
INFO - 2021-08-18 11:31:35 --> Output Class Initialized
INFO - 2021-08-18 11:31:35 --> Security Class Initialized
DEBUG - 2021-08-18 11:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:31:35 --> Input Class Initialized
INFO - 2021-08-18 11:31:35 --> Language Class Initialized
INFO - 2021-08-18 11:31:35 --> Loader Class Initialized
INFO - 2021-08-18 11:31:35 --> Helper loaded: url_helper
INFO - 2021-08-18 11:31:35 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:31:35 --> Controller Class Initialized
INFO - 2021-08-18 11:31:35 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:31:35 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:31:35 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:31:35 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-18 11:31:35 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:31:35 --> Final output sent to browser
DEBUG - 2021-08-18 11:31:35 --> Total execution time: 0.0312
INFO - 2021-08-18 11:31:36 --> Config Class Initialized
INFO - 2021-08-18 11:31:36 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:31:36 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:31:36 --> Utf8 Class Initialized
INFO - 2021-08-18 11:31:36 --> URI Class Initialized
INFO - 2021-08-18 11:31:36 --> Router Class Initialized
INFO - 2021-08-18 11:31:36 --> Output Class Initialized
INFO - 2021-08-18 11:31:36 --> Security Class Initialized
DEBUG - 2021-08-18 11:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:31:36 --> Input Class Initialized
INFO - 2021-08-18 11:31:36 --> Language Class Initialized
INFO - 2021-08-18 11:31:36 --> Loader Class Initialized
INFO - 2021-08-18 11:31:36 --> Helper loaded: url_helper
INFO - 2021-08-18 11:31:36 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:31:36 --> Controller Class Initialized
INFO - 2021-08-18 11:31:36 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:31:36 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:31:36 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:31:36 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-18 11:31:36 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:31:36 --> Final output sent to browser
DEBUG - 2021-08-18 11:31:36 --> Total execution time: 0.0333
INFO - 2021-08-18 11:31:42 --> Config Class Initialized
INFO - 2021-08-18 11:31:42 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:31:42 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:31:42 --> Utf8 Class Initialized
INFO - 2021-08-18 11:31:42 --> URI Class Initialized
INFO - 2021-08-18 11:31:42 --> Router Class Initialized
INFO - 2021-08-18 11:31:42 --> Output Class Initialized
INFO - 2021-08-18 11:31:42 --> Security Class Initialized
DEBUG - 2021-08-18 11:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:31:42 --> Input Class Initialized
INFO - 2021-08-18 11:31:42 --> Language Class Initialized
INFO - 2021-08-18 11:31:42 --> Loader Class Initialized
INFO - 2021-08-18 11:31:42 --> Helper loaded: url_helper
INFO - 2021-08-18 11:31:42 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:31:42 --> Controller Class Initialized
INFO - 2021-08-18 11:31:42 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:31:42 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:31:42 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:31:42 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-18 11:31:42 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:31:42 --> Final output sent to browser
DEBUG - 2021-08-18 11:31:42 --> Total execution time: 0.0294
INFO - 2021-08-18 11:31:48 --> Config Class Initialized
INFO - 2021-08-18 11:31:48 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:31:48 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:31:48 --> Utf8 Class Initialized
INFO - 2021-08-18 11:31:48 --> URI Class Initialized
INFO - 2021-08-18 11:31:48 --> Router Class Initialized
INFO - 2021-08-18 11:31:48 --> Output Class Initialized
INFO - 2021-08-18 11:31:48 --> Security Class Initialized
DEBUG - 2021-08-18 11:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:31:48 --> Input Class Initialized
INFO - 2021-08-18 11:31:48 --> Language Class Initialized
INFO - 2021-08-18 11:31:48 --> Loader Class Initialized
INFO - 2021-08-18 11:31:48 --> Helper loaded: url_helper
INFO - 2021-08-18 11:31:48 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:31:48 --> Controller Class Initialized
INFO - 2021-08-18 11:31:48 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:31:48 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:31:48 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:31:48 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-18 11:31:48 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:31:48 --> Final output sent to browser
DEBUG - 2021-08-18 11:31:48 --> Total execution time: 0.0321
INFO - 2021-08-18 11:32:00 --> Config Class Initialized
INFO - 2021-08-18 11:32:00 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:32:00 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:32:00 --> Utf8 Class Initialized
INFO - 2021-08-18 11:32:00 --> URI Class Initialized
INFO - 2021-08-18 11:32:00 --> Router Class Initialized
INFO - 2021-08-18 11:32:00 --> Output Class Initialized
INFO - 2021-08-18 11:32:00 --> Config Class Initialized
INFO - 2021-08-18 11:32:00 --> Hooks Class Initialized
INFO - 2021-08-18 11:32:00 --> Security Class Initialized
DEBUG - 2021-08-18 11:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:32:00 --> Input Class Initialized
DEBUG - 2021-08-18 11:32:00 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:32:00 --> Language Class Initialized
INFO - 2021-08-18 11:32:00 --> Utf8 Class Initialized
INFO - 2021-08-18 11:32:00 --> URI Class Initialized
ERROR - 2021-08-18 11:32:00 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 11:32:00 --> Router Class Initialized
INFO - 2021-08-18 11:32:00 --> Output Class Initialized
INFO - 2021-08-18 11:32:00 --> Security Class Initialized
DEBUG - 2021-08-18 11:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:32:00 --> Input Class Initialized
INFO - 2021-08-18 11:32:00 --> Language Class Initialized
ERROR - 2021-08-18 11:32:00 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 11:32:00 --> Config Class Initialized
INFO - 2021-08-18 11:32:00 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:32:00 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:32:00 --> Utf8 Class Initialized
INFO - 2021-08-18 11:32:00 --> URI Class Initialized
INFO - 2021-08-18 11:32:00 --> Router Class Initialized
INFO - 2021-08-18 11:32:00 --> Output Class Initialized
INFO - 2021-08-18 11:32:00 --> Security Class Initialized
DEBUG - 2021-08-18 11:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:32:00 --> Input Class Initialized
INFO - 2021-08-18 11:32:00 --> Language Class Initialized
ERROR - 2021-08-18 11:32:00 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 11:32:01 --> Config Class Initialized
INFO - 2021-08-18 11:32:01 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:32:01 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:32:01 --> Utf8 Class Initialized
INFO - 2021-08-18 11:32:01 --> Config Class Initialized
INFO - 2021-08-18 11:32:01 --> Hooks Class Initialized
INFO - 2021-08-18 11:32:01 --> URI Class Initialized
INFO - 2021-08-18 11:32:01 --> Router Class Initialized
DEBUG - 2021-08-18 11:32:01 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:32:01 --> Utf8 Class Initialized
INFO - 2021-08-18 11:32:01 --> URI Class Initialized
INFO - 2021-08-18 11:32:01 --> Output Class Initialized
INFO - 2021-08-18 11:32:01 --> Router Class Initialized
INFO - 2021-08-18 11:32:01 --> Security Class Initialized
INFO - 2021-08-18 11:32:01 --> Output Class Initialized
DEBUG - 2021-08-18 11:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:32:01 --> Input Class Initialized
INFO - 2021-08-18 11:32:01 --> Security Class Initialized
INFO - 2021-08-18 11:32:01 --> Language Class Initialized
DEBUG - 2021-08-18 11:32:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-08-18 11:32:01 --> 404 Page Not Found: Assets/css
INFO - 2021-08-18 11:32:01 --> Input Class Initialized
INFO - 2021-08-18 11:32:01 --> Language Class Initialized
ERROR - 2021-08-18 11:32:01 --> 404 Page Not Found: Assets/css
INFO - 2021-08-18 11:40:10 --> Config Class Initialized
INFO - 2021-08-18 11:40:10 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:40:10 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:40:10 --> Utf8 Class Initialized
INFO - 2021-08-18 11:40:10 --> URI Class Initialized
INFO - 2021-08-18 11:40:10 --> Router Class Initialized
INFO - 2021-08-18 11:40:10 --> Output Class Initialized
INFO - 2021-08-18 11:40:10 --> Security Class Initialized
DEBUG - 2021-08-18 11:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:40:10 --> Input Class Initialized
INFO - 2021-08-18 11:40:10 --> Language Class Initialized
INFO - 2021-08-18 11:40:10 --> Loader Class Initialized
INFO - 2021-08-18 11:40:10 --> Helper loaded: url_helper
INFO - 2021-08-18 11:40:10 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:40:10 --> Controller Class Initialized
INFO - 2021-08-18 11:40:11 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:40:11 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:40:11 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:40:11 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-18 11:40:11 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:40:11 --> Final output sent to browser
DEBUG - 2021-08-18 11:40:11 --> Total execution time: 0.0476
INFO - 2021-08-18 11:40:11 --> Config Class Initialized
INFO - 2021-08-18 11:40:11 --> Hooks Class Initialized
INFO - 2021-08-18 11:40:11 --> Config Class Initialized
INFO - 2021-08-18 11:40:11 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:40:11 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:40:11 --> Utf8 Class Initialized
DEBUG - 2021-08-18 11:40:11 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:40:11 --> URI Class Initialized
INFO - 2021-08-18 11:40:11 --> Utf8 Class Initialized
INFO - 2021-08-18 11:40:11 --> URI Class Initialized
INFO - 2021-08-18 11:40:11 --> Router Class Initialized
INFO - 2021-08-18 11:40:11 --> Router Class Initialized
INFO - 2021-08-18 11:40:11 --> Output Class Initialized
INFO - 2021-08-18 11:40:11 --> Output Class Initialized
INFO - 2021-08-18 11:40:11 --> Security Class Initialized
DEBUG - 2021-08-18 11:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:40:11 --> Input Class Initialized
INFO - 2021-08-18 11:40:11 --> Security Class Initialized
INFO - 2021-08-18 11:40:11 --> Language Class Initialized
DEBUG - 2021-08-18 11:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:40:11 --> Input Class Initialized
ERROR - 2021-08-18 11:40:11 --> 404 Page Not Found: Assets/css
INFO - 2021-08-18 11:40:11 --> Language Class Initialized
ERROR - 2021-08-18 11:40:11 --> 404 Page Not Found: Assets/css
INFO - 2021-08-18 11:40:11 --> Config Class Initialized
INFO - 2021-08-18 11:40:11 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:40:11 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:40:11 --> Utf8 Class Initialized
INFO - 2021-08-18 11:40:11 --> Config Class Initialized
INFO - 2021-08-18 11:40:11 --> Hooks Class Initialized
INFO - 2021-08-18 11:40:11 --> URI Class Initialized
INFO - 2021-08-18 11:40:11 --> Router Class Initialized
DEBUG - 2021-08-18 11:40:11 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:40:11 --> Utf8 Class Initialized
INFO - 2021-08-18 11:40:11 --> Output Class Initialized
INFO - 2021-08-18 11:40:11 --> URI Class Initialized
INFO - 2021-08-18 11:40:11 --> Config Class Initialized
INFO - 2021-08-18 11:40:11 --> Hooks Class Initialized
INFO - 2021-08-18 11:40:11 --> Security Class Initialized
INFO - 2021-08-18 11:40:11 --> Router Class Initialized
DEBUG - 2021-08-18 11:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:40:11 --> Input Class Initialized
INFO - 2021-08-18 11:40:11 --> Output Class Initialized
INFO - 2021-08-18 11:40:11 --> Language Class Initialized
DEBUG - 2021-08-18 11:40:11 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:40:11 --> Utf8 Class Initialized
INFO - 2021-08-18 11:40:11 --> Security Class Initialized
ERROR - 2021-08-18 11:40:11 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 11:40:11 --> URI Class Initialized
DEBUG - 2021-08-18 11:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:40:11 --> Input Class Initialized
INFO - 2021-08-18 11:40:11 --> Language Class Initialized
INFO - 2021-08-18 11:40:11 --> Router Class Initialized
ERROR - 2021-08-18 11:40:11 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 11:40:11 --> Output Class Initialized
INFO - 2021-08-18 11:40:11 --> Security Class Initialized
DEBUG - 2021-08-18 11:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:40:11 --> Input Class Initialized
INFO - 2021-08-18 11:40:11 --> Language Class Initialized
ERROR - 2021-08-18 11:40:11 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 11:40:13 --> Config Class Initialized
INFO - 2021-08-18 11:40:13 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:40:13 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:40:13 --> Utf8 Class Initialized
INFO - 2021-08-18 11:40:13 --> URI Class Initialized
INFO - 2021-08-18 11:40:13 --> Router Class Initialized
INFO - 2021-08-18 11:40:13 --> Output Class Initialized
INFO - 2021-08-18 11:40:13 --> Security Class Initialized
DEBUG - 2021-08-18 11:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:40:13 --> Input Class Initialized
INFO - 2021-08-18 11:40:13 --> Language Class Initialized
INFO - 2021-08-18 11:40:13 --> Loader Class Initialized
INFO - 2021-08-18 11:40:13 --> Helper loaded: url_helper
INFO - 2021-08-18 11:40:13 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:40:13 --> Controller Class Initialized
INFO - 2021-08-18 11:40:13 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:40:13 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:40:13 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:40:13 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-18 11:40:13 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:40:13 --> Final output sent to browser
DEBUG - 2021-08-18 11:40:13 --> Total execution time: 0.0359
INFO - 2021-08-18 11:40:13 --> Config Class Initialized
INFO - 2021-08-18 11:40:13 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:40:13 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:40:13 --> Utf8 Class Initialized
INFO - 2021-08-18 11:40:13 --> Config Class Initialized
INFO - 2021-08-18 11:40:13 --> Hooks Class Initialized
INFO - 2021-08-18 11:40:13 --> URI Class Initialized
INFO - 2021-08-18 11:40:13 --> Router Class Initialized
DEBUG - 2021-08-18 11:40:13 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:40:13 --> Utf8 Class Initialized
INFO - 2021-08-18 11:40:13 --> URI Class Initialized
INFO - 2021-08-18 11:40:13 --> Output Class Initialized
INFO - 2021-08-18 11:40:13 --> Router Class Initialized
INFO - 2021-08-18 11:40:13 --> Security Class Initialized
DEBUG - 2021-08-18 11:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:40:13 --> Input Class Initialized
INFO - 2021-08-18 11:40:13 --> Output Class Initialized
INFO - 2021-08-18 11:40:13 --> Language Class Initialized
ERROR - 2021-08-18 11:40:13 --> 404 Page Not Found: Assets/css
INFO - 2021-08-18 11:40:13 --> Security Class Initialized
DEBUG - 2021-08-18 11:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:40:13 --> Input Class Initialized
INFO - 2021-08-18 11:40:13 --> Language Class Initialized
ERROR - 2021-08-18 11:40:13 --> 404 Page Not Found: Assets/css
INFO - 2021-08-18 11:40:13 --> Config Class Initialized
INFO - 2021-08-18 11:40:13 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:40:13 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:40:13 --> Utf8 Class Initialized
INFO - 2021-08-18 11:40:13 --> URI Class Initialized
INFO - 2021-08-18 11:40:13 --> Router Class Initialized
INFO - 2021-08-18 11:40:13 --> Output Class Initialized
INFO - 2021-08-18 11:40:13 --> Security Class Initialized
DEBUG - 2021-08-18 11:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:40:13 --> Input Class Initialized
INFO - 2021-08-18 11:40:13 --> Language Class Initialized
ERROR - 2021-08-18 11:40:13 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 11:40:13 --> Config Class Initialized
INFO - 2021-08-18 11:40:13 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:40:13 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:40:13 --> Utf8 Class Initialized
INFO - 2021-08-18 11:40:13 --> URI Class Initialized
INFO - 2021-08-18 11:40:13 --> Router Class Initialized
INFO - 2021-08-18 11:40:13 --> Output Class Initialized
INFO - 2021-08-18 11:40:13 --> Security Class Initialized
DEBUG - 2021-08-18 11:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:40:13 --> Input Class Initialized
INFO - 2021-08-18 11:40:13 --> Language Class Initialized
ERROR - 2021-08-18 11:40:13 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 11:40:13 --> Config Class Initialized
INFO - 2021-08-18 11:40:13 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:40:13 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:40:13 --> Utf8 Class Initialized
INFO - 2021-08-18 11:40:13 --> URI Class Initialized
INFO - 2021-08-18 11:40:13 --> Router Class Initialized
INFO - 2021-08-18 11:40:13 --> Output Class Initialized
INFO - 2021-08-18 11:40:13 --> Security Class Initialized
DEBUG - 2021-08-18 11:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:40:13 --> Input Class Initialized
INFO - 2021-08-18 11:40:13 --> Language Class Initialized
ERROR - 2021-08-18 11:40:13 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 11:40:14 --> Config Class Initialized
INFO - 2021-08-18 11:40:14 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:40:14 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:40:14 --> Utf8 Class Initialized
INFO - 2021-08-18 11:40:14 --> URI Class Initialized
INFO - 2021-08-18 11:40:14 --> Router Class Initialized
INFO - 2021-08-18 11:40:14 --> Output Class Initialized
INFO - 2021-08-18 11:40:14 --> Security Class Initialized
DEBUG - 2021-08-18 11:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:40:14 --> Input Class Initialized
INFO - 2021-08-18 11:40:14 --> Language Class Initialized
INFO - 2021-08-18 11:40:14 --> Loader Class Initialized
INFO - 2021-08-18 11:40:14 --> Helper loaded: url_helper
INFO - 2021-08-18 11:40:14 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:40:14 --> Controller Class Initialized
INFO - 2021-08-18 11:40:14 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:40:14 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:40:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:40:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-18 11:40:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:40:14 --> Final output sent to browser
DEBUG - 2021-08-18 11:40:14 --> Total execution time: 0.0569
INFO - 2021-08-18 11:40:14 --> Config Class Initialized
INFO - 2021-08-18 11:40:14 --> Hooks Class Initialized
INFO - 2021-08-18 11:40:14 --> Config Class Initialized
INFO - 2021-08-18 11:40:14 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:40:14 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:40:14 --> Utf8 Class Initialized
INFO - 2021-08-18 11:40:14 --> URI Class Initialized
DEBUG - 2021-08-18 11:40:14 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:40:14 --> Utf8 Class Initialized
INFO - 2021-08-18 11:40:14 --> Router Class Initialized
INFO - 2021-08-18 11:40:14 --> URI Class Initialized
INFO - 2021-08-18 11:40:14 --> Router Class Initialized
INFO - 2021-08-18 11:40:14 --> Output Class Initialized
INFO - 2021-08-18 11:40:14 --> Output Class Initialized
INFO - 2021-08-18 11:40:14 --> Security Class Initialized
INFO - 2021-08-18 11:40:14 --> Security Class Initialized
DEBUG - 2021-08-18 11:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:40:14 --> Input Class Initialized
DEBUG - 2021-08-18 11:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:40:14 --> Input Class Initialized
INFO - 2021-08-18 11:40:14 --> Language Class Initialized
INFO - 2021-08-18 11:40:14 --> Language Class Initialized
ERROR - 2021-08-18 11:40:14 --> 404 Page Not Found: Assets/css
ERROR - 2021-08-18 11:40:14 --> 404 Page Not Found: Assets/css
INFO - 2021-08-18 11:40:15 --> Config Class Initialized
INFO - 2021-08-18 11:40:15 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:40:15 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:40:15 --> Utf8 Class Initialized
INFO - 2021-08-18 11:40:15 --> URI Class Initialized
INFO - 2021-08-18 11:40:15 --> Router Class Initialized
INFO - 2021-08-18 11:40:15 --> Output Class Initialized
INFO - 2021-08-18 11:40:15 --> Security Class Initialized
DEBUG - 2021-08-18 11:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:40:15 --> Input Class Initialized
INFO - 2021-08-18 11:40:15 --> Language Class Initialized
ERROR - 2021-08-18 11:40:15 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 11:40:15 --> Config Class Initialized
INFO - 2021-08-18 11:40:15 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:40:15 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:40:15 --> Utf8 Class Initialized
INFO - 2021-08-18 11:40:15 --> URI Class Initialized
INFO - 2021-08-18 11:40:15 --> Router Class Initialized
INFO - 2021-08-18 11:40:15 --> Output Class Initialized
INFO - 2021-08-18 11:40:15 --> Security Class Initialized
DEBUG - 2021-08-18 11:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:40:15 --> Input Class Initialized
INFO - 2021-08-18 11:40:15 --> Language Class Initialized
ERROR - 2021-08-18 11:40:15 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 11:40:15 --> Config Class Initialized
INFO - 2021-08-18 11:40:15 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:40:15 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:40:15 --> Utf8 Class Initialized
INFO - 2021-08-18 11:40:15 --> URI Class Initialized
INFO - 2021-08-18 11:40:15 --> Router Class Initialized
INFO - 2021-08-18 11:40:15 --> Output Class Initialized
INFO - 2021-08-18 11:40:15 --> Security Class Initialized
DEBUG - 2021-08-18 11:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:40:15 --> Input Class Initialized
INFO - 2021-08-18 11:40:15 --> Language Class Initialized
INFO - 2021-08-18 11:40:15 --> Loader Class Initialized
INFO - 2021-08-18 11:40:15 --> Helper loaded: url_helper
INFO - 2021-08-18 11:40:15 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:40:15 --> Controller Class Initialized
INFO - 2021-08-18 11:40:15 --> Config Class Initialized
INFO - 2021-08-18 11:40:15 --> Hooks Class Initialized
INFO - 2021-08-18 11:40:15 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:40:15 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:40:15 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:40:15 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-18 11:40:15 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:40:15 --> Final output sent to browser
DEBUG - 2021-08-18 11:40:15 --> Total execution time: 0.0431
DEBUG - 2021-08-18 11:40:15 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:40:15 --> Utf8 Class Initialized
INFO - 2021-08-18 11:40:15 --> URI Class Initialized
INFO - 2021-08-18 11:40:15 --> Router Class Initialized
INFO - 2021-08-18 11:40:15 --> Output Class Initialized
INFO - 2021-08-18 11:40:15 --> Security Class Initialized
DEBUG - 2021-08-18 11:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:40:15 --> Input Class Initialized
INFO - 2021-08-18 11:40:15 --> Language Class Initialized
ERROR - 2021-08-18 11:40:15 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 11:40:15 --> Config Class Initialized
INFO - 2021-08-18 11:40:15 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:40:15 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:40:15 --> Utf8 Class Initialized
INFO - 2021-08-18 11:40:15 --> URI Class Initialized
INFO - 2021-08-18 11:40:15 --> Router Class Initialized
INFO - 2021-08-18 11:40:15 --> Output Class Initialized
INFO - 2021-08-18 11:40:15 --> Security Class Initialized
DEBUG - 2021-08-18 11:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:40:15 --> Input Class Initialized
INFO - 2021-08-18 11:40:15 --> Language Class Initialized
INFO - 2021-08-18 11:40:15 --> Loader Class Initialized
INFO - 2021-08-18 11:40:15 --> Helper loaded: url_helper
INFO - 2021-08-18 11:40:15 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:40:15 --> Controller Class Initialized
INFO - 2021-08-18 11:40:15 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:40:15 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:40:15 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:40:15 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-18 11:40:15 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:40:15 --> Final output sent to browser
DEBUG - 2021-08-18 11:40:15 --> Total execution time: 0.0531
INFO - 2021-08-18 11:40:15 --> Config Class Initialized
INFO - 2021-08-18 11:40:15 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:40:15 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:40:15 --> Utf8 Class Initialized
INFO - 2021-08-18 11:40:15 --> Config Class Initialized
INFO - 2021-08-18 11:40:15 --> Hooks Class Initialized
INFO - 2021-08-18 11:40:15 --> URI Class Initialized
INFO - 2021-08-18 11:40:15 --> Router Class Initialized
DEBUG - 2021-08-18 11:40:15 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:40:15 --> Utf8 Class Initialized
INFO - 2021-08-18 11:40:15 --> URI Class Initialized
INFO - 2021-08-18 11:40:15 --> Output Class Initialized
INFO - 2021-08-18 11:40:15 --> Router Class Initialized
INFO - 2021-08-18 11:40:15 --> Security Class Initialized
INFO - 2021-08-18 11:40:15 --> Output Class Initialized
DEBUG - 2021-08-18 11:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:40:15 --> Input Class Initialized
INFO - 2021-08-18 11:40:15 --> Language Class Initialized
INFO - 2021-08-18 11:40:15 --> Security Class Initialized
ERROR - 2021-08-18 11:40:15 --> 404 Page Not Found: Assets/css
DEBUG - 2021-08-18 11:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:40:15 --> Input Class Initialized
INFO - 2021-08-18 11:40:15 --> Language Class Initialized
ERROR - 2021-08-18 11:40:15 --> 404 Page Not Found: Assets/css
INFO - 2021-08-18 11:40:15 --> Config Class Initialized
INFO - 2021-08-18 11:40:15 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:40:15 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:40:15 --> Utf8 Class Initialized
INFO - 2021-08-18 11:40:15 --> URI Class Initialized
INFO - 2021-08-18 11:40:15 --> Router Class Initialized
INFO - 2021-08-18 11:40:15 --> Output Class Initialized
INFO - 2021-08-18 11:40:15 --> Security Class Initialized
DEBUG - 2021-08-18 11:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:40:15 --> Input Class Initialized
INFO - 2021-08-18 11:40:15 --> Language Class Initialized
ERROR - 2021-08-18 11:40:15 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 11:40:15 --> Config Class Initialized
INFO - 2021-08-18 11:40:15 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:40:15 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:40:15 --> Utf8 Class Initialized
INFO - 2021-08-18 11:40:15 --> URI Class Initialized
INFO - 2021-08-18 11:40:15 --> Router Class Initialized
INFO - 2021-08-18 11:40:15 --> Output Class Initialized
INFO - 2021-08-18 11:40:15 --> Security Class Initialized
DEBUG - 2021-08-18 11:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:40:15 --> Input Class Initialized
INFO - 2021-08-18 11:40:15 --> Language Class Initialized
ERROR - 2021-08-18 11:40:15 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 11:40:15 --> Config Class Initialized
INFO - 2021-08-18 11:40:15 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:40:15 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:40:15 --> Utf8 Class Initialized
INFO - 2021-08-18 11:40:15 --> URI Class Initialized
INFO - 2021-08-18 11:40:15 --> Router Class Initialized
INFO - 2021-08-18 11:40:15 --> Output Class Initialized
INFO - 2021-08-18 11:40:15 --> Security Class Initialized
DEBUG - 2021-08-18 11:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:40:15 --> Input Class Initialized
INFO - 2021-08-18 11:40:15 --> Language Class Initialized
INFO - 2021-08-18 11:40:15 --> Loader Class Initialized
INFO - 2021-08-18 11:40:15 --> Helper loaded: url_helper
INFO - 2021-08-18 11:40:15 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:40:15 --> Controller Class Initialized
INFO - 2021-08-18 11:40:15 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:40:15 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:40:15 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:40:15 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-18 11:40:15 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:40:15 --> Final output sent to browser
DEBUG - 2021-08-18 11:40:15 --> Total execution time: 0.0575
INFO - 2021-08-18 11:40:16 --> Config Class Initialized
INFO - 2021-08-18 11:40:16 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:40:16 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:40:16 --> Utf8 Class Initialized
INFO - 2021-08-18 11:40:16 --> URI Class Initialized
INFO - 2021-08-18 11:40:16 --> Router Class Initialized
INFO - 2021-08-18 11:40:16 --> Output Class Initialized
INFO - 2021-08-18 11:40:16 --> Security Class Initialized
DEBUG - 2021-08-18 11:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:40:16 --> Input Class Initialized
INFO - 2021-08-18 11:40:16 --> Language Class Initialized
INFO - 2021-08-18 11:40:16 --> Loader Class Initialized
INFO - 2021-08-18 11:40:16 --> Helper loaded: url_helper
INFO - 2021-08-18 11:40:16 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:40:16 --> Controller Class Initialized
INFO - 2021-08-18 11:40:16 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:40:16 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:40:16 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:40:16 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-18 11:40:16 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:40:16 --> Final output sent to browser
DEBUG - 2021-08-18 11:40:16 --> Total execution time: 0.0449
INFO - 2021-08-18 11:40:16 --> Config Class Initialized
INFO - 2021-08-18 11:40:16 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:40:16 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:40:16 --> Config Class Initialized
INFO - 2021-08-18 11:40:16 --> Utf8 Class Initialized
INFO - 2021-08-18 11:40:16 --> Hooks Class Initialized
INFO - 2021-08-18 11:40:16 --> URI Class Initialized
INFO - 2021-08-18 11:40:16 --> Router Class Initialized
DEBUG - 2021-08-18 11:40:16 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:40:16 --> Utf8 Class Initialized
INFO - 2021-08-18 11:40:16 --> URI Class Initialized
INFO - 2021-08-18 11:40:16 --> Output Class Initialized
INFO - 2021-08-18 11:40:16 --> Router Class Initialized
INFO - 2021-08-18 11:40:16 --> Security Class Initialized
INFO - 2021-08-18 11:40:16 --> Output Class Initialized
DEBUG - 2021-08-18 11:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:40:16 --> Input Class Initialized
INFO - 2021-08-18 11:40:16 --> Language Class Initialized
INFO - 2021-08-18 11:40:16 --> Security Class Initialized
ERROR - 2021-08-18 11:40:16 --> 404 Page Not Found: Assets/css
DEBUG - 2021-08-18 11:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:40:16 --> Input Class Initialized
INFO - 2021-08-18 11:40:16 --> Language Class Initialized
ERROR - 2021-08-18 11:40:16 --> 404 Page Not Found: Assets/css
INFO - 2021-08-18 11:40:16 --> Config Class Initialized
INFO - 2021-08-18 11:40:16 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:40:16 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:40:16 --> Utf8 Class Initialized
INFO - 2021-08-18 11:40:16 --> Config Class Initialized
INFO - 2021-08-18 11:40:16 --> Hooks Class Initialized
INFO - 2021-08-18 11:40:16 --> URI Class Initialized
INFO - 2021-08-18 11:40:16 --> Router Class Initialized
DEBUG - 2021-08-18 11:40:16 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:40:16 --> Utf8 Class Initialized
INFO - 2021-08-18 11:40:16 --> Output Class Initialized
INFO - 2021-08-18 11:40:16 --> URI Class Initialized
INFO - 2021-08-18 11:40:16 --> Security Class Initialized
INFO - 2021-08-18 11:40:16 --> Router Class Initialized
DEBUG - 2021-08-18 11:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:40:16 --> Input Class Initialized
INFO - 2021-08-18 11:40:16 --> Output Class Initialized
INFO - 2021-08-18 11:40:16 --> Language Class Initialized
INFO - 2021-08-18 11:40:16 --> Security Class Initialized
ERROR - 2021-08-18 11:40:16 --> 404 Page Not Found: Assets/css
DEBUG - 2021-08-18 11:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:40:16 --> Input Class Initialized
INFO - 2021-08-18 11:40:16 --> Language Class Initialized
ERROR - 2021-08-18 11:40:16 --> 404 Page Not Found: Assets/css
INFO - 2021-08-18 11:40:16 --> Config Class Initialized
INFO - 2021-08-18 11:40:16 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:40:16 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:40:16 --> Utf8 Class Initialized
INFO - 2021-08-18 11:40:16 --> URI Class Initialized
INFO - 2021-08-18 11:40:16 --> Router Class Initialized
INFO - 2021-08-18 11:40:16 --> Output Class Initialized
INFO - 2021-08-18 11:40:16 --> Security Class Initialized
DEBUG - 2021-08-18 11:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:40:16 --> Input Class Initialized
INFO - 2021-08-18 11:40:16 --> Language Class Initialized
ERROR - 2021-08-18 11:40:16 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 11:40:17 --> Config Class Initialized
INFO - 2021-08-18 11:40:17 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:40:17 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:40:17 --> Utf8 Class Initialized
INFO - 2021-08-18 11:40:17 --> URI Class Initialized
INFO - 2021-08-18 11:40:17 --> Router Class Initialized
INFO - 2021-08-18 11:40:17 --> Output Class Initialized
INFO - 2021-08-18 11:40:17 --> Security Class Initialized
DEBUG - 2021-08-18 11:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:40:17 --> Input Class Initialized
INFO - 2021-08-18 11:40:17 --> Language Class Initialized
ERROR - 2021-08-18 11:40:17 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 11:40:17 --> Config Class Initialized
INFO - 2021-08-18 11:40:17 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:40:17 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:40:17 --> Utf8 Class Initialized
INFO - 2021-08-18 11:40:17 --> URI Class Initialized
INFO - 2021-08-18 11:40:17 --> Router Class Initialized
INFO - 2021-08-18 11:40:17 --> Output Class Initialized
INFO - 2021-08-18 11:40:17 --> Security Class Initialized
DEBUG - 2021-08-18 11:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:40:17 --> Input Class Initialized
INFO - 2021-08-18 11:40:17 --> Language Class Initialized
ERROR - 2021-08-18 11:40:17 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 11:40:42 --> Config Class Initialized
INFO - 2021-08-18 11:40:42 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:40:42 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:40:42 --> Utf8 Class Initialized
INFO - 2021-08-18 11:40:42 --> URI Class Initialized
INFO - 2021-08-18 11:40:42 --> Router Class Initialized
INFO - 2021-08-18 11:40:42 --> Output Class Initialized
INFO - 2021-08-18 11:40:42 --> Security Class Initialized
DEBUG - 2021-08-18 11:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:40:42 --> Input Class Initialized
INFO - 2021-08-18 11:40:42 --> Language Class Initialized
INFO - 2021-08-18 11:40:42 --> Loader Class Initialized
INFO - 2021-08-18 11:40:42 --> Helper loaded: url_helper
INFO - 2021-08-18 11:40:42 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:40:42 --> Controller Class Initialized
INFO - 2021-08-18 11:40:42 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:40:42 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:40:42 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:40:42 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-18 11:40:42 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:40:42 --> Final output sent to browser
DEBUG - 2021-08-18 11:40:42 --> Total execution time: 0.0340
INFO - 2021-08-18 11:40:43 --> Config Class Initialized
INFO - 2021-08-18 11:40:43 --> Hooks Class Initialized
INFO - 2021-08-18 11:40:43 --> Config Class Initialized
INFO - 2021-08-18 11:40:43 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:40:43 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:40:43 --> Utf8 Class Initialized
INFO - 2021-08-18 11:40:43 --> URI Class Initialized
DEBUG - 2021-08-18 11:40:43 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:40:43 --> Utf8 Class Initialized
INFO - 2021-08-18 11:40:43 --> Router Class Initialized
INFO - 2021-08-18 11:40:43 --> URI Class Initialized
INFO - 2021-08-18 11:40:43 --> Output Class Initialized
INFO - 2021-08-18 11:40:43 --> Router Class Initialized
INFO - 2021-08-18 11:40:43 --> Security Class Initialized
DEBUG - 2021-08-18 11:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:40:43 --> Output Class Initialized
INFO - 2021-08-18 11:40:43 --> Input Class Initialized
INFO - 2021-08-18 11:40:43 --> Language Class Initialized
INFO - 2021-08-18 11:40:43 --> Security Class Initialized
ERROR - 2021-08-18 11:40:43 --> 404 Page Not Found: Assets/css
DEBUG - 2021-08-18 11:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:40:43 --> Input Class Initialized
INFO - 2021-08-18 11:40:43 --> Language Class Initialized
ERROR - 2021-08-18 11:40:43 --> 404 Page Not Found: Assets/css
INFO - 2021-08-18 11:40:43 --> Config Class Initialized
INFO - 2021-08-18 11:40:43 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:40:43 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:40:43 --> Utf8 Class Initialized
INFO - 2021-08-18 11:40:43 --> URI Class Initialized
INFO - 2021-08-18 11:40:43 --> Router Class Initialized
INFO - 2021-08-18 11:40:43 --> Output Class Initialized
INFO - 2021-08-18 11:40:43 --> Security Class Initialized
DEBUG - 2021-08-18 11:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:40:43 --> Input Class Initialized
INFO - 2021-08-18 11:40:43 --> Language Class Initialized
ERROR - 2021-08-18 11:40:43 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 11:40:43 --> Config Class Initialized
INFO - 2021-08-18 11:40:43 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:40:43 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:40:43 --> Utf8 Class Initialized
INFO - 2021-08-18 11:40:43 --> URI Class Initialized
INFO - 2021-08-18 11:40:43 --> Router Class Initialized
INFO - 2021-08-18 11:40:43 --> Output Class Initialized
INFO - 2021-08-18 11:40:43 --> Security Class Initialized
DEBUG - 2021-08-18 11:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:40:43 --> Input Class Initialized
INFO - 2021-08-18 11:40:43 --> Language Class Initialized
ERROR - 2021-08-18 11:40:43 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 11:40:43 --> Config Class Initialized
INFO - 2021-08-18 11:40:43 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:40:43 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:40:43 --> Utf8 Class Initialized
INFO - 2021-08-18 11:40:43 --> URI Class Initialized
INFO - 2021-08-18 11:40:43 --> Router Class Initialized
INFO - 2021-08-18 11:40:43 --> Output Class Initialized
INFO - 2021-08-18 11:40:43 --> Security Class Initialized
DEBUG - 2021-08-18 11:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:40:43 --> Input Class Initialized
INFO - 2021-08-18 11:40:43 --> Language Class Initialized
ERROR - 2021-08-18 11:40:43 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 11:41:03 --> Config Class Initialized
INFO - 2021-08-18 11:41:03 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:41:03 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:41:03 --> Utf8 Class Initialized
INFO - 2021-08-18 11:41:03 --> URI Class Initialized
INFO - 2021-08-18 11:41:03 --> Router Class Initialized
INFO - 2021-08-18 11:41:03 --> Output Class Initialized
INFO - 2021-08-18 11:41:03 --> Security Class Initialized
DEBUG - 2021-08-18 11:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:41:03 --> Input Class Initialized
INFO - 2021-08-18 11:41:03 --> Language Class Initialized
INFO - 2021-08-18 11:41:03 --> Loader Class Initialized
INFO - 2021-08-18 11:41:03 --> Helper loaded: url_helper
INFO - 2021-08-18 11:41:03 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:41:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:41:03 --> Controller Class Initialized
INFO - 2021-08-18 11:41:03 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:41:03 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:41:03 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:41:03 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-18 11:41:03 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:41:03 --> Final output sent to browser
DEBUG - 2021-08-18 11:41:03 --> Total execution time: 0.0340
INFO - 2021-08-18 11:41:04 --> Config Class Initialized
INFO - 2021-08-18 11:41:04 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:41:04 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:41:04 --> Utf8 Class Initialized
INFO - 2021-08-18 11:41:04 --> URI Class Initialized
INFO - 2021-08-18 11:41:04 --> Router Class Initialized
INFO - 2021-08-18 11:41:04 --> Output Class Initialized
INFO - 2021-08-18 11:41:04 --> Security Class Initialized
DEBUG - 2021-08-18 11:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:41:04 --> Input Class Initialized
INFO - 2021-08-18 11:41:04 --> Language Class Initialized
INFO - 2021-08-18 11:41:04 --> Loader Class Initialized
INFO - 2021-08-18 11:41:04 --> Helper loaded: url_helper
INFO - 2021-08-18 11:41:04 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:41:04 --> Controller Class Initialized
INFO - 2021-08-18 11:41:04 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:41:04 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:41:04 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:41:04 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 11:41:04 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:41:04 --> Final output sent to browser
DEBUG - 2021-08-18 11:41:04 --> Total execution time: 0.0348
INFO - 2021-08-18 11:41:08 --> Config Class Initialized
INFO - 2021-08-18 11:41:08 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:41:08 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:41:08 --> Utf8 Class Initialized
INFO - 2021-08-18 11:41:08 --> URI Class Initialized
INFO - 2021-08-18 11:41:08 --> Router Class Initialized
INFO - 2021-08-18 11:41:08 --> Output Class Initialized
INFO - 2021-08-18 11:41:08 --> Security Class Initialized
DEBUG - 2021-08-18 11:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:41:08 --> Input Class Initialized
INFO - 2021-08-18 11:41:08 --> Language Class Initialized
INFO - 2021-08-18 11:41:08 --> Loader Class Initialized
INFO - 2021-08-18 11:41:08 --> Helper loaded: url_helper
INFO - 2021-08-18 11:41:08 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:41:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:41:08 --> Controller Class Initialized
INFO - 2021-08-18 11:41:08 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:41:08 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:41:08 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:41:08 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/pilates.php
INFO - 2021-08-18 11:41:08 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:41:08 --> Final output sent to browser
DEBUG - 2021-08-18 11:41:08 --> Total execution time: 0.0366
INFO - 2021-08-18 11:41:14 --> Config Class Initialized
INFO - 2021-08-18 11:41:14 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:41:14 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:41:14 --> Utf8 Class Initialized
INFO - 2021-08-18 11:41:14 --> URI Class Initialized
DEBUG - 2021-08-18 11:41:14 --> No URI present. Default controller set.
INFO - 2021-08-18 11:41:14 --> Router Class Initialized
INFO - 2021-08-18 11:41:14 --> Output Class Initialized
INFO - 2021-08-18 11:41:14 --> Security Class Initialized
DEBUG - 2021-08-18 11:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:41:14 --> Input Class Initialized
INFO - 2021-08-18 11:41:14 --> Language Class Initialized
INFO - 2021-08-18 11:41:14 --> Loader Class Initialized
INFO - 2021-08-18 11:41:14 --> Helper loaded: url_helper
INFO - 2021-08-18 11:41:14 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:41:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:41:14 --> Controller Class Initialized
INFO - 2021-08-18 11:41:14 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:41:14 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:41:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:41:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-18 11:41:14 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:41:14 --> Final output sent to browser
DEBUG - 2021-08-18 11:41:14 --> Total execution time: 0.0359
INFO - 2021-08-18 11:42:00 --> Config Class Initialized
INFO - 2021-08-18 11:42:00 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:42:00 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:42:00 --> Utf8 Class Initialized
INFO - 2021-08-18 11:42:00 --> URI Class Initialized
INFO - 2021-08-18 11:42:00 --> Router Class Initialized
INFO - 2021-08-18 11:42:00 --> Output Class Initialized
INFO - 2021-08-18 11:42:00 --> Security Class Initialized
DEBUG - 2021-08-18 11:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:42:00 --> Input Class Initialized
INFO - 2021-08-18 11:42:00 --> Language Class Initialized
INFO - 2021-08-18 11:42:00 --> Loader Class Initialized
INFO - 2021-08-18 11:42:00 --> Helper loaded: url_helper
INFO - 2021-08-18 11:42:00 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:42:00 --> Controller Class Initialized
INFO - 2021-08-18 11:42:00 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:42:00 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:42:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:42:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 11:42:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:42:00 --> Final output sent to browser
DEBUG - 2021-08-18 11:42:00 --> Total execution time: 0.0452
INFO - 2021-08-18 11:42:02 --> Config Class Initialized
INFO - 2021-08-18 11:42:02 --> Hooks Class Initialized
INFO - 2021-08-18 11:42:02 --> Config Class Initialized
INFO - 2021-08-18 11:42:02 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:42:02 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:42:02 --> Utf8 Class Initialized
INFO - 2021-08-18 11:42:02 --> URI Class Initialized
DEBUG - 2021-08-18 11:42:02 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:42:02 --> Utf8 Class Initialized
INFO - 2021-08-18 11:42:02 --> URI Class Initialized
INFO - 2021-08-18 11:42:02 --> Router Class Initialized
INFO - 2021-08-18 11:42:02 --> Router Class Initialized
INFO - 2021-08-18 11:42:02 --> Output Class Initialized
INFO - 2021-08-18 11:42:02 --> Security Class Initialized
INFO - 2021-08-18 11:42:02 --> Output Class Initialized
DEBUG - 2021-08-18 11:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:42:02 --> Input Class Initialized
INFO - 2021-08-18 11:42:02 --> Security Class Initialized
INFO - 2021-08-18 11:42:02 --> Language Class Initialized
DEBUG - 2021-08-18 11:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:42:02 --> Input Class Initialized
ERROR - 2021-08-18 11:42:02 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 11:42:02 --> Language Class Initialized
ERROR - 2021-08-18 11:42:02 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 11:42:02 --> Config Class Initialized
INFO - 2021-08-18 11:42:02 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:42:02 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:42:02 --> Utf8 Class Initialized
INFO - 2021-08-18 11:42:02 --> URI Class Initialized
INFO - 2021-08-18 11:42:02 --> Router Class Initialized
INFO - 2021-08-18 11:42:02 --> Output Class Initialized
INFO - 2021-08-18 11:42:02 --> Security Class Initialized
DEBUG - 2021-08-18 11:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:42:02 --> Input Class Initialized
INFO - 2021-08-18 11:42:02 --> Language Class Initialized
ERROR - 2021-08-18 11:42:02 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 11:42:03 --> Config Class Initialized
INFO - 2021-08-18 11:42:03 --> Config Class Initialized
INFO - 2021-08-18 11:42:03 --> Hooks Class Initialized
INFO - 2021-08-18 11:42:03 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:42:03 --> UTF-8 Support Enabled
DEBUG - 2021-08-18 11:42:03 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:42:03 --> Utf8 Class Initialized
INFO - 2021-08-18 11:42:03 --> Utf8 Class Initialized
INFO - 2021-08-18 11:42:03 --> URI Class Initialized
INFO - 2021-08-18 11:42:03 --> URI Class Initialized
INFO - 2021-08-18 11:42:03 --> Router Class Initialized
INFO - 2021-08-18 11:42:03 --> Router Class Initialized
INFO - 2021-08-18 11:42:03 --> Output Class Initialized
INFO - 2021-08-18 11:42:03 --> Output Class Initialized
INFO - 2021-08-18 11:42:03 --> Security Class Initialized
INFO - 2021-08-18 11:42:03 --> Security Class Initialized
DEBUG - 2021-08-18 11:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-08-18 11:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:42:03 --> Input Class Initialized
INFO - 2021-08-18 11:42:03 --> Input Class Initialized
INFO - 2021-08-18 11:42:03 --> Language Class Initialized
INFO - 2021-08-18 11:42:03 --> Language Class Initialized
ERROR - 2021-08-18 11:42:03 --> 404 Page Not Found: Assets/css
ERROR - 2021-08-18 11:42:03 --> 404 Page Not Found: Assets/css
INFO - 2021-08-18 11:43:46 --> Config Class Initialized
INFO - 2021-08-18 11:43:46 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:43:46 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:43:46 --> Utf8 Class Initialized
INFO - 2021-08-18 11:43:46 --> Config Class Initialized
INFO - 2021-08-18 11:43:46 --> Hooks Class Initialized
INFO - 2021-08-18 11:43:46 --> URI Class Initialized
INFO - 2021-08-18 11:43:46 --> Router Class Initialized
DEBUG - 2021-08-18 11:43:46 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:43:46 --> Utf8 Class Initialized
INFO - 2021-08-18 11:43:46 --> Output Class Initialized
INFO - 2021-08-18 11:43:46 --> URI Class Initialized
INFO - 2021-08-18 11:43:46 --> Security Class Initialized
INFO - 2021-08-18 11:43:46 --> Router Class Initialized
DEBUG - 2021-08-18 11:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:43:46 --> Input Class Initialized
INFO - 2021-08-18 11:43:46 --> Language Class Initialized
ERROR - 2021-08-18 11:43:46 --> 404 Page Not Found: Assets/css
INFO - 2021-08-18 11:43:46 --> Output Class Initialized
INFO - 2021-08-18 11:43:46 --> Security Class Initialized
DEBUG - 2021-08-18 11:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:43:47 --> Input Class Initialized
INFO - 2021-08-18 11:43:47 --> Language Class Initialized
ERROR - 2021-08-18 11:43:47 --> 404 Page Not Found: Assets/css
INFO - 2021-08-18 11:43:47 --> Config Class Initialized
INFO - 2021-08-18 11:43:47 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:43:47 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:43:47 --> Utf8 Class Initialized
INFO - 2021-08-18 11:43:47 --> URI Class Initialized
INFO - 2021-08-18 11:43:47 --> Router Class Initialized
INFO - 2021-08-18 11:43:47 --> Config Class Initialized
INFO - 2021-08-18 11:43:47 --> Hooks Class Initialized
INFO - 2021-08-18 11:43:47 --> Output Class Initialized
DEBUG - 2021-08-18 11:43:47 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:43:47 --> Security Class Initialized
INFO - 2021-08-18 11:43:47 --> Utf8 Class Initialized
INFO - 2021-08-18 11:43:47 --> URI Class Initialized
DEBUG - 2021-08-18 11:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:43:47 --> Input Class Initialized
INFO - 2021-08-18 11:43:47 --> Language Class Initialized
INFO - 2021-08-18 11:43:47 --> Router Class Initialized
ERROR - 2021-08-18 11:43:47 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 11:43:47 --> Output Class Initialized
INFO - 2021-08-18 11:43:47 --> Security Class Initialized
DEBUG - 2021-08-18 11:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:43:47 --> Input Class Initialized
INFO - 2021-08-18 11:43:47 --> Language Class Initialized
ERROR - 2021-08-18 11:43:47 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 11:43:47 --> Config Class Initialized
INFO - 2021-08-18 11:43:47 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:43:47 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:43:47 --> Utf8 Class Initialized
INFO - 2021-08-18 11:43:47 --> URI Class Initialized
INFO - 2021-08-18 11:43:47 --> Router Class Initialized
INFO - 2021-08-18 11:43:47 --> Output Class Initialized
INFO - 2021-08-18 11:43:47 --> Security Class Initialized
DEBUG - 2021-08-18 11:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:43:47 --> Input Class Initialized
INFO - 2021-08-18 11:43:47 --> Language Class Initialized
ERROR - 2021-08-18 11:43:47 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 11:44:02 --> Config Class Initialized
INFO - 2021-08-18 11:44:02 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:44:02 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:44:02 --> Utf8 Class Initialized
INFO - 2021-08-18 11:44:02 --> URI Class Initialized
INFO - 2021-08-18 11:44:02 --> Router Class Initialized
INFO - 2021-08-18 11:44:02 --> Output Class Initialized
INFO - 2021-08-18 11:44:02 --> Security Class Initialized
DEBUG - 2021-08-18 11:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:44:03 --> Input Class Initialized
INFO - 2021-08-18 11:44:03 --> Language Class Initialized
INFO - 2021-08-18 11:44:03 --> Loader Class Initialized
INFO - 2021-08-18 11:44:03 --> Helper loaded: url_helper
INFO - 2021-08-18 11:44:03 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:44:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:44:03 --> Controller Class Initialized
INFO - 2021-08-18 11:44:03 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:44:03 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:44:03 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:44:03 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 11:44:03 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:44:03 --> Final output sent to browser
DEBUG - 2021-08-18 11:44:03 --> Total execution time: 0.0385
INFO - 2021-08-18 11:44:03 --> Config Class Initialized
INFO - 2021-08-18 11:44:03 --> Hooks Class Initialized
INFO - 2021-08-18 11:44:03 --> Config Class Initialized
INFO - 2021-08-18 11:44:03 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:44:03 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:44:03 --> Utf8 Class Initialized
DEBUG - 2021-08-18 11:44:03 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:44:03 --> Utf8 Class Initialized
INFO - 2021-08-18 11:44:03 --> URI Class Initialized
INFO - 2021-08-18 11:44:03 --> URI Class Initialized
INFO - 2021-08-18 11:44:03 --> Router Class Initialized
INFO - 2021-08-18 11:44:03 --> Router Class Initialized
INFO - 2021-08-18 11:44:03 --> Output Class Initialized
INFO - 2021-08-18 11:44:03 --> Output Class Initialized
INFO - 2021-08-18 11:44:03 --> Security Class Initialized
INFO - 2021-08-18 11:44:03 --> Security Class Initialized
DEBUG - 2021-08-18 11:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-08-18 11:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:44:03 --> Input Class Initialized
INFO - 2021-08-18 11:44:03 --> Input Class Initialized
INFO - 2021-08-18 11:44:03 --> Language Class Initialized
INFO - 2021-08-18 11:44:03 --> Language Class Initialized
ERROR - 2021-08-18 11:44:03 --> 404 Page Not Found: Assets/css
ERROR - 2021-08-18 11:44:03 --> 404 Page Not Found: Assets/css
INFO - 2021-08-18 11:44:03 --> Config Class Initialized
INFO - 2021-08-18 11:44:03 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:44:03 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:44:03 --> Utf8 Class Initialized
INFO - 2021-08-18 11:44:03 --> URI Class Initialized
INFO - 2021-08-18 11:44:03 --> Router Class Initialized
INFO - 2021-08-18 11:44:03 --> Output Class Initialized
INFO - 2021-08-18 11:44:03 --> Security Class Initialized
DEBUG - 2021-08-18 11:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:44:03 --> Input Class Initialized
INFO - 2021-08-18 11:44:03 --> Language Class Initialized
ERROR - 2021-08-18 11:44:03 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 11:44:03 --> Config Class Initialized
INFO - 2021-08-18 11:44:03 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:44:03 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:44:03 --> Utf8 Class Initialized
INFO - 2021-08-18 11:44:03 --> URI Class Initialized
INFO - 2021-08-18 11:44:03 --> Router Class Initialized
INFO - 2021-08-18 11:44:03 --> Output Class Initialized
INFO - 2021-08-18 11:44:03 --> Security Class Initialized
DEBUG - 2021-08-18 11:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:44:03 --> Input Class Initialized
INFO - 2021-08-18 11:44:03 --> Language Class Initialized
ERROR - 2021-08-18 11:44:03 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 11:44:03 --> Config Class Initialized
INFO - 2021-08-18 11:44:03 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:44:03 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:44:03 --> Utf8 Class Initialized
INFO - 2021-08-18 11:44:03 --> URI Class Initialized
INFO - 2021-08-18 11:44:03 --> Router Class Initialized
INFO - 2021-08-18 11:44:03 --> Output Class Initialized
INFO - 2021-08-18 11:44:03 --> Security Class Initialized
DEBUG - 2021-08-18 11:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:44:03 --> Input Class Initialized
INFO - 2021-08-18 11:44:03 --> Language Class Initialized
ERROR - 2021-08-18 11:44:03 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 11:44:33 --> Config Class Initialized
INFO - 2021-08-18 11:44:33 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:44:33 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:44:33 --> Utf8 Class Initialized
INFO - 2021-08-18 11:44:33 --> URI Class Initialized
INFO - 2021-08-18 11:44:33 --> Router Class Initialized
INFO - 2021-08-18 11:44:33 --> Output Class Initialized
INFO - 2021-08-18 11:44:33 --> Security Class Initialized
DEBUG - 2021-08-18 11:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:44:33 --> Input Class Initialized
INFO - 2021-08-18 11:44:33 --> Language Class Initialized
INFO - 2021-08-18 11:44:33 --> Loader Class Initialized
INFO - 2021-08-18 11:44:33 --> Helper loaded: url_helper
INFO - 2021-08-18 11:44:33 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:44:33 --> Controller Class Initialized
INFO - 2021-08-18 11:44:33 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:44:33 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:44:33 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:44:33 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-08-18 11:44:33 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:44:33 --> Final output sent to browser
DEBUG - 2021-08-18 11:44:33 --> Total execution time: 0.0361
INFO - 2021-08-18 11:44:34 --> Config Class Initialized
INFO - 2021-08-18 11:44:34 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:44:34 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:44:34 --> Utf8 Class Initialized
INFO - 2021-08-18 11:44:34 --> Config Class Initialized
INFO - 2021-08-18 11:44:34 --> Hooks Class Initialized
INFO - 2021-08-18 11:44:34 --> URI Class Initialized
DEBUG - 2021-08-18 11:44:34 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:44:34 --> Utf8 Class Initialized
INFO - 2021-08-18 11:44:34 --> Router Class Initialized
INFO - 2021-08-18 11:44:34 --> URI Class Initialized
INFO - 2021-08-18 11:44:34 --> Output Class Initialized
INFO - 2021-08-18 11:44:34 --> Router Class Initialized
INFO - 2021-08-18 11:44:34 --> Security Class Initialized
INFO - 2021-08-18 11:44:34 --> Output Class Initialized
DEBUG - 2021-08-18 11:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:44:34 --> Input Class Initialized
INFO - 2021-08-18 11:44:34 --> Language Class Initialized
INFO - 2021-08-18 11:44:34 --> Security Class Initialized
ERROR - 2021-08-18 11:44:34 --> 404 Page Not Found: Assets/css
DEBUG - 2021-08-18 11:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:44:34 --> Input Class Initialized
INFO - 2021-08-18 11:44:34 --> Language Class Initialized
ERROR - 2021-08-18 11:44:34 --> 404 Page Not Found: Assets/css
INFO - 2021-08-18 11:44:34 --> Config Class Initialized
INFO - 2021-08-18 11:44:34 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:44:34 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:44:34 --> Utf8 Class Initialized
INFO - 2021-08-18 11:44:34 --> URI Class Initialized
INFO - 2021-08-18 11:44:34 --> Router Class Initialized
INFO - 2021-08-18 11:44:34 --> Output Class Initialized
INFO - 2021-08-18 11:44:34 --> Security Class Initialized
DEBUG - 2021-08-18 11:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:44:34 --> Input Class Initialized
INFO - 2021-08-18 11:44:34 --> Language Class Initialized
ERROR - 2021-08-18 11:44:34 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 11:44:34 --> Config Class Initialized
INFO - 2021-08-18 11:44:34 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:44:34 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:44:34 --> Utf8 Class Initialized
INFO - 2021-08-18 11:44:34 --> URI Class Initialized
INFO - 2021-08-18 11:44:34 --> Router Class Initialized
INFO - 2021-08-18 11:44:34 --> Output Class Initialized
INFO - 2021-08-18 11:44:34 --> Security Class Initialized
DEBUG - 2021-08-18 11:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:44:34 --> Input Class Initialized
INFO - 2021-08-18 11:44:34 --> Language Class Initialized
ERROR - 2021-08-18 11:44:34 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 11:44:34 --> Config Class Initialized
INFO - 2021-08-18 11:44:34 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:44:34 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:44:34 --> Utf8 Class Initialized
INFO - 2021-08-18 11:44:34 --> URI Class Initialized
INFO - 2021-08-18 11:44:34 --> Router Class Initialized
INFO - 2021-08-18 11:44:34 --> Output Class Initialized
INFO - 2021-08-18 11:44:34 --> Security Class Initialized
DEBUG - 2021-08-18 11:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:44:34 --> Input Class Initialized
INFO - 2021-08-18 11:44:34 --> Language Class Initialized
ERROR - 2021-08-18 11:44:34 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 11:44:45 --> Config Class Initialized
INFO - 2021-08-18 11:44:45 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:44:45 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:44:45 --> Utf8 Class Initialized
INFO - 2021-08-18 11:44:45 --> URI Class Initialized
INFO - 2021-08-18 11:44:45 --> Router Class Initialized
INFO - 2021-08-18 11:44:45 --> Output Class Initialized
INFO - 2021-08-18 11:44:45 --> Security Class Initialized
DEBUG - 2021-08-18 11:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:44:45 --> Input Class Initialized
INFO - 2021-08-18 11:44:45 --> Language Class Initialized
INFO - 2021-08-18 11:44:45 --> Loader Class Initialized
INFO - 2021-08-18 11:44:45 --> Helper loaded: url_helper
INFO - 2021-08-18 11:44:45 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:44:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:44:45 --> Controller Class Initialized
INFO - 2021-08-18 11:44:45 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:44:45 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:44:45 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:44:45 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/pilates.php
INFO - 2021-08-18 11:44:45 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:44:45 --> Final output sent to browser
DEBUG - 2021-08-18 11:44:45 --> Total execution time: 0.0304
INFO - 2021-08-18 11:44:46 --> Config Class Initialized
INFO - 2021-08-18 11:44:46 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:44:46 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:44:46 --> Utf8 Class Initialized
INFO - 2021-08-18 11:44:46 --> URI Class Initialized
INFO - 2021-08-18 11:44:46 --> Router Class Initialized
INFO - 2021-08-18 11:44:46 --> Output Class Initialized
INFO - 2021-08-18 11:44:46 --> Security Class Initialized
DEBUG - 2021-08-18 11:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:44:46 --> Input Class Initialized
INFO - 2021-08-18 11:44:46 --> Language Class Initialized
INFO - 2021-08-18 11:44:46 --> Loader Class Initialized
INFO - 2021-08-18 11:44:46 --> Helper loaded: url_helper
INFO - 2021-08-18 11:44:46 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:44:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:44:46 --> Controller Class Initialized
INFO - 2021-08-18 11:44:46 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:44:46 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:44:46 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:44:46 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 11:44:46 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:44:46 --> Final output sent to browser
DEBUG - 2021-08-18 11:44:46 --> Total execution time: 0.0331
INFO - 2021-08-18 11:44:48 --> Config Class Initialized
INFO - 2021-08-18 11:44:48 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:44:48 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:44:48 --> Utf8 Class Initialized
INFO - 2021-08-18 11:44:48 --> URI Class Initialized
INFO - 2021-08-18 11:44:48 --> Router Class Initialized
INFO - 2021-08-18 11:44:48 --> Config Class Initialized
INFO - 2021-08-18 11:44:48 --> Hooks Class Initialized
INFO - 2021-08-18 11:44:48 --> Output Class Initialized
INFO - 2021-08-18 11:44:48 --> Security Class Initialized
DEBUG - 2021-08-18 11:44:48 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:44:48 --> Utf8 Class Initialized
DEBUG - 2021-08-18 11:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:44:48 --> Input Class Initialized
INFO - 2021-08-18 11:44:48 --> URI Class Initialized
INFO - 2021-08-18 11:44:48 --> Language Class Initialized
INFO - 2021-08-18 11:44:48 --> Router Class Initialized
ERROR - 2021-08-18 11:44:48 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 11:44:48 --> Output Class Initialized
INFO - 2021-08-18 11:44:48 --> Security Class Initialized
DEBUG - 2021-08-18 11:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:44:48 --> Input Class Initialized
INFO - 2021-08-18 11:44:48 --> Config Class Initialized
INFO - 2021-08-18 11:44:48 --> Hooks Class Initialized
INFO - 2021-08-18 11:44:48 --> Language Class Initialized
DEBUG - 2021-08-18 11:44:48 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:44:48 --> Utf8 Class Initialized
ERROR - 2021-08-18 11:44:48 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 11:44:48 --> URI Class Initialized
INFO - 2021-08-18 11:44:48 --> Router Class Initialized
INFO - 2021-08-18 11:44:48 --> Output Class Initialized
INFO - 2021-08-18 11:44:48 --> Security Class Initialized
DEBUG - 2021-08-18 11:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:44:48 --> Input Class Initialized
INFO - 2021-08-18 11:44:48 --> Language Class Initialized
ERROR - 2021-08-18 11:44:48 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 11:44:48 --> Config Class Initialized
INFO - 2021-08-18 11:44:48 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:44:48 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:44:48 --> Utf8 Class Initialized
INFO - 2021-08-18 11:44:48 --> Config Class Initialized
INFO - 2021-08-18 11:44:48 --> URI Class Initialized
INFO - 2021-08-18 11:44:48 --> Hooks Class Initialized
INFO - 2021-08-18 11:44:48 --> Router Class Initialized
DEBUG - 2021-08-18 11:44:48 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:44:48 --> Utf8 Class Initialized
INFO - 2021-08-18 11:44:48 --> Output Class Initialized
INFO - 2021-08-18 11:44:48 --> URI Class Initialized
INFO - 2021-08-18 11:44:48 --> Security Class Initialized
DEBUG - 2021-08-18 11:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:44:48 --> Input Class Initialized
INFO - 2021-08-18 11:44:48 --> Router Class Initialized
INFO - 2021-08-18 11:44:48 --> Language Class Initialized
ERROR - 2021-08-18 11:44:48 --> 404 Page Not Found: Assets/css
INFO - 2021-08-18 11:44:48 --> Output Class Initialized
INFO - 2021-08-18 11:44:48 --> Security Class Initialized
DEBUG - 2021-08-18 11:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:44:48 --> Input Class Initialized
INFO - 2021-08-18 11:44:48 --> Language Class Initialized
ERROR - 2021-08-18 11:44:48 --> 404 Page Not Found: Assets/css
INFO - 2021-08-18 11:52:17 --> Config Class Initialized
INFO - 2021-08-18 11:52:17 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:52:17 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:52:17 --> Utf8 Class Initialized
INFO - 2021-08-18 11:52:17 --> URI Class Initialized
INFO - 2021-08-18 11:52:17 --> Router Class Initialized
INFO - 2021-08-18 11:52:17 --> Output Class Initialized
INFO - 2021-08-18 11:52:17 --> Security Class Initialized
DEBUG - 2021-08-18 11:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:52:17 --> Input Class Initialized
INFO - 2021-08-18 11:52:17 --> Language Class Initialized
INFO - 2021-08-18 11:52:17 --> Loader Class Initialized
INFO - 2021-08-18 11:52:17 --> Helper loaded: url_helper
INFO - 2021-08-18 11:52:17 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:52:17 --> Controller Class Initialized
INFO - 2021-08-18 11:52:17 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:52:17 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:52:17 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:52:17 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/pilates.php
INFO - 2021-08-18 11:52:17 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:52:17 --> Final output sent to browser
DEBUG - 2021-08-18 11:52:17 --> Total execution time: 0.0471
INFO - 2021-08-18 11:54:13 --> Config Class Initialized
INFO - 2021-08-18 11:54:13 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:54:13 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:54:13 --> Utf8 Class Initialized
INFO - 2021-08-18 11:54:13 --> URI Class Initialized
INFO - 2021-08-18 11:54:13 --> Router Class Initialized
INFO - 2021-08-18 11:54:13 --> Output Class Initialized
INFO - 2021-08-18 11:54:13 --> Security Class Initialized
DEBUG - 2021-08-18 11:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:54:13 --> Input Class Initialized
INFO - 2021-08-18 11:54:13 --> Language Class Initialized
INFO - 2021-08-18 11:54:13 --> Loader Class Initialized
INFO - 2021-08-18 11:54:13 --> Helper loaded: url_helper
INFO - 2021-08-18 11:54:13 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:54:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:54:13 --> Controller Class Initialized
INFO - 2021-08-18 11:54:13 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:54:13 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:54:13 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:54:13 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 11:54:13 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:54:13 --> Final output sent to browser
DEBUG - 2021-08-18 11:54:13 --> Total execution time: 0.0362
INFO - 2021-08-18 11:55:28 --> Config Class Initialized
INFO - 2021-08-18 11:55:28 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:55:28 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:55:28 --> Utf8 Class Initialized
INFO - 2021-08-18 11:55:28 --> URI Class Initialized
INFO - 2021-08-18 11:55:28 --> Router Class Initialized
INFO - 2021-08-18 11:55:28 --> Output Class Initialized
INFO - 2021-08-18 11:55:28 --> Security Class Initialized
DEBUG - 2021-08-18 11:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:55:28 --> Input Class Initialized
INFO - 2021-08-18 11:55:28 --> Language Class Initialized
INFO - 2021-08-18 11:55:28 --> Loader Class Initialized
INFO - 2021-08-18 11:55:28 --> Helper loaded: url_helper
INFO - 2021-08-18 11:55:28 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:55:28 --> Controller Class Initialized
INFO - 2021-08-18 11:55:28 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:55:28 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:55:28 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:55:28 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 11:55:28 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:55:28 --> Final output sent to browser
DEBUG - 2021-08-18 11:55:28 --> Total execution time: 0.0382
INFO - 2021-08-18 11:55:51 --> Config Class Initialized
INFO - 2021-08-18 11:55:51 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:55:51 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:55:51 --> Utf8 Class Initialized
INFO - 2021-08-18 11:55:51 --> URI Class Initialized
INFO - 2021-08-18 11:55:51 --> Config Class Initialized
INFO - 2021-08-18 11:55:51 --> Hooks Class Initialized
INFO - 2021-08-18 11:55:51 --> Router Class Initialized
INFO - 2021-08-18 11:55:51 --> Output Class Initialized
DEBUG - 2021-08-18 11:55:51 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:55:51 --> Utf8 Class Initialized
INFO - 2021-08-18 11:55:51 --> Security Class Initialized
INFO - 2021-08-18 11:55:51 --> URI Class Initialized
DEBUG - 2021-08-18 11:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:55:51 --> Input Class Initialized
INFO - 2021-08-18 11:55:51 --> Router Class Initialized
INFO - 2021-08-18 11:55:51 --> Language Class Initialized
INFO - 2021-08-18 11:55:51 --> Output Class Initialized
INFO - 2021-08-18 11:55:51 --> Config Class Initialized
INFO - 2021-08-18 11:55:51 --> Hooks Class Initialized
INFO - 2021-08-18 11:55:51 --> Security Class Initialized
DEBUG - 2021-08-18 11:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:55:51 --> Input Class Initialized
INFO - 2021-08-18 11:55:51 --> Language Class Initialized
DEBUG - 2021-08-18 11:55:51 --> UTF-8 Support Enabled
ERROR - 2021-08-18 11:55:51 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 11:55:51 --> Utf8 Class Initialized
INFO - 2021-08-18 11:55:51 --> URI Class Initialized
INFO - 2021-08-18 11:55:51 --> Router Class Initialized
INFO - 2021-08-18 11:55:51 --> Output Class Initialized
INFO - 2021-08-18 11:55:51 --> Security Class Initialized
DEBUG - 2021-08-18 11:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:55:51 --> Input Class Initialized
INFO - 2021-08-18 11:55:51 --> Language Class Initialized
ERROR - 2021-08-18 11:55:51 --> 404 Page Not Found: Assets/js
ERROR - 2021-08-18 11:55:52 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 11:55:52 --> Config Class Initialized
INFO - 2021-08-18 11:55:52 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:55:52 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:55:52 --> Utf8 Class Initialized
INFO - 2021-08-18 11:55:52 --> URI Class Initialized
INFO - 2021-08-18 11:55:52 --> Router Class Initialized
INFO - 2021-08-18 11:55:52 --> Output Class Initialized
INFO - 2021-08-18 11:55:52 --> Security Class Initialized
DEBUG - 2021-08-18 11:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:55:52 --> Input Class Initialized
INFO - 2021-08-18 11:55:52 --> Language Class Initialized
ERROR - 2021-08-18 11:55:52 --> 404 Page Not Found: Assets/css
INFO - 2021-08-18 11:55:52 --> Config Class Initialized
INFO - 2021-08-18 11:55:52 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:55:52 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:55:52 --> Utf8 Class Initialized
INFO - 2021-08-18 11:55:52 --> URI Class Initialized
INFO - 2021-08-18 11:55:52 --> Router Class Initialized
INFO - 2021-08-18 11:55:52 --> Output Class Initialized
INFO - 2021-08-18 11:55:52 --> Security Class Initialized
DEBUG - 2021-08-18 11:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:55:52 --> Input Class Initialized
INFO - 2021-08-18 11:55:52 --> Language Class Initialized
ERROR - 2021-08-18 11:55:52 --> 404 Page Not Found: Assets/css
INFO - 2021-08-18 11:57:07 --> Config Class Initialized
INFO - 2021-08-18 11:57:07 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:57:07 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:57:07 --> Utf8 Class Initialized
INFO - 2021-08-18 11:57:07 --> URI Class Initialized
INFO - 2021-08-18 11:57:07 --> Router Class Initialized
INFO - 2021-08-18 11:57:07 --> Output Class Initialized
INFO - 2021-08-18 11:57:07 --> Security Class Initialized
DEBUG - 2021-08-18 11:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:57:07 --> Input Class Initialized
INFO - 2021-08-18 11:57:07 --> Language Class Initialized
INFO - 2021-08-18 11:57:07 --> Loader Class Initialized
INFO - 2021-08-18 11:57:07 --> Helper loaded: url_helper
INFO - 2021-08-18 11:57:07 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:57:07 --> Controller Class Initialized
INFO - 2021-08-18 11:57:07 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:57:07 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:57:07 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:57:07 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 11:57:07 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:57:07 --> Final output sent to browser
DEBUG - 2021-08-18 11:57:07 --> Total execution time: 0.0295
INFO - 2021-08-18 11:57:15 --> Config Class Initialized
INFO - 2021-08-18 11:57:15 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:57:15 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:57:15 --> Utf8 Class Initialized
INFO - 2021-08-18 11:57:15 --> URI Class Initialized
INFO - 2021-08-18 11:57:15 --> Router Class Initialized
INFO - 2021-08-18 11:57:15 --> Output Class Initialized
INFO - 2021-08-18 11:57:15 --> Security Class Initialized
DEBUG - 2021-08-18 11:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:57:15 --> Input Class Initialized
INFO - 2021-08-18 11:57:15 --> Language Class Initialized
INFO - 2021-08-18 11:57:15 --> Loader Class Initialized
INFO - 2021-08-18 11:57:15 --> Helper loaded: url_helper
INFO - 2021-08-18 11:57:15 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:57:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:57:15 --> Controller Class Initialized
INFO - 2021-08-18 11:57:15 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:57:15 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:57:15 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:57:15 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 11:57:15 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:57:15 --> Final output sent to browser
DEBUG - 2021-08-18 11:57:15 --> Total execution time: 0.0290
INFO - 2021-08-18 11:57:17 --> Config Class Initialized
INFO - 2021-08-18 11:57:17 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:57:17 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:57:17 --> Utf8 Class Initialized
INFO - 2021-08-18 11:57:17 --> URI Class Initialized
INFO - 2021-08-18 11:57:17 --> Router Class Initialized
INFO - 2021-08-18 11:57:17 --> Output Class Initialized
INFO - 2021-08-18 11:57:17 --> Security Class Initialized
DEBUG - 2021-08-18 11:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:57:17 --> Input Class Initialized
INFO - 2021-08-18 11:57:17 --> Language Class Initialized
INFO - 2021-08-18 11:57:17 --> Loader Class Initialized
INFO - 2021-08-18 11:57:17 --> Helper loaded: url_helper
INFO - 2021-08-18 11:57:17 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:57:17 --> Controller Class Initialized
INFO - 2021-08-18 11:57:17 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:57:17 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:57:17 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:57:17 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 11:57:17 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:57:17 --> Final output sent to browser
DEBUG - 2021-08-18 11:57:17 --> Total execution time: 0.0339
INFO - 2021-08-18 11:57:18 --> Config Class Initialized
INFO - 2021-08-18 11:57:18 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:57:18 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:57:18 --> Utf8 Class Initialized
INFO - 2021-08-18 11:57:18 --> URI Class Initialized
INFO - 2021-08-18 11:57:18 --> Router Class Initialized
INFO - 2021-08-18 11:57:18 --> Output Class Initialized
INFO - 2021-08-18 11:57:18 --> Security Class Initialized
DEBUG - 2021-08-18 11:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:57:18 --> Input Class Initialized
INFO - 2021-08-18 11:57:18 --> Language Class Initialized
INFO - 2021-08-18 11:57:18 --> Loader Class Initialized
INFO - 2021-08-18 11:57:18 --> Helper loaded: url_helper
INFO - 2021-08-18 11:57:18 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:57:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:57:18 --> Controller Class Initialized
INFO - 2021-08-18 11:57:18 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:57:18 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:57:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:57:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 11:57:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:57:18 --> Final output sent to browser
DEBUG - 2021-08-18 11:57:18 --> Total execution time: 0.0441
INFO - 2021-08-18 11:57:18 --> Config Class Initialized
INFO - 2021-08-18 11:57:18 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:57:18 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:57:18 --> Utf8 Class Initialized
INFO - 2021-08-18 11:57:18 --> URI Class Initialized
INFO - 2021-08-18 11:57:18 --> Router Class Initialized
INFO - 2021-08-18 11:57:18 --> Output Class Initialized
INFO - 2021-08-18 11:57:18 --> Security Class Initialized
DEBUG - 2021-08-18 11:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:57:18 --> Input Class Initialized
INFO - 2021-08-18 11:57:18 --> Language Class Initialized
INFO - 2021-08-18 11:57:18 --> Loader Class Initialized
INFO - 2021-08-18 11:57:18 --> Helper loaded: url_helper
INFO - 2021-08-18 11:57:18 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:57:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:57:18 --> Controller Class Initialized
INFO - 2021-08-18 11:57:18 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:57:18 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:57:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:57:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 11:57:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:57:18 --> Final output sent to browser
DEBUG - 2021-08-18 11:57:18 --> Total execution time: 0.0420
INFO - 2021-08-18 11:57:18 --> Config Class Initialized
INFO - 2021-08-18 11:57:18 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:57:18 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:57:18 --> Utf8 Class Initialized
INFO - 2021-08-18 11:57:18 --> URI Class Initialized
INFO - 2021-08-18 11:57:18 --> Router Class Initialized
INFO - 2021-08-18 11:57:18 --> Output Class Initialized
INFO - 2021-08-18 11:57:18 --> Security Class Initialized
DEBUG - 2021-08-18 11:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:57:18 --> Input Class Initialized
INFO - 2021-08-18 11:57:18 --> Language Class Initialized
INFO - 2021-08-18 11:57:18 --> Loader Class Initialized
INFO - 2021-08-18 11:57:18 --> Helper loaded: url_helper
INFO - 2021-08-18 11:57:18 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:57:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:57:18 --> Controller Class Initialized
INFO - 2021-08-18 11:57:18 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:57:18 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:57:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:57:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 11:57:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:57:18 --> Final output sent to browser
DEBUG - 2021-08-18 11:57:18 --> Total execution time: 0.0455
INFO - 2021-08-18 11:57:18 --> Config Class Initialized
INFO - 2021-08-18 11:57:18 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:57:18 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:57:18 --> Utf8 Class Initialized
INFO - 2021-08-18 11:57:18 --> URI Class Initialized
INFO - 2021-08-18 11:57:18 --> Router Class Initialized
INFO - 2021-08-18 11:57:18 --> Output Class Initialized
INFO - 2021-08-18 11:57:18 --> Security Class Initialized
DEBUG - 2021-08-18 11:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:57:18 --> Input Class Initialized
INFO - 2021-08-18 11:57:18 --> Language Class Initialized
INFO - 2021-08-18 11:57:18 --> Loader Class Initialized
INFO - 2021-08-18 11:57:18 --> Helper loaded: url_helper
INFO - 2021-08-18 11:57:18 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:57:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:57:18 --> Controller Class Initialized
INFO - 2021-08-18 11:57:18 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:57:18 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:57:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:57:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 11:57:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:57:18 --> Final output sent to browser
DEBUG - 2021-08-18 11:57:18 --> Total execution time: 0.0498
INFO - 2021-08-18 11:57:19 --> Config Class Initialized
INFO - 2021-08-18 11:57:19 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:57:19 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:57:19 --> Utf8 Class Initialized
INFO - 2021-08-18 11:57:19 --> URI Class Initialized
INFO - 2021-08-18 11:57:19 --> Router Class Initialized
INFO - 2021-08-18 11:57:19 --> Output Class Initialized
INFO - 2021-08-18 11:57:19 --> Security Class Initialized
DEBUG - 2021-08-18 11:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:57:19 --> Input Class Initialized
INFO - 2021-08-18 11:57:19 --> Language Class Initialized
INFO - 2021-08-18 11:57:19 --> Loader Class Initialized
INFO - 2021-08-18 11:57:19 --> Helper loaded: url_helper
INFO - 2021-08-18 11:57:19 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:57:19 --> Controller Class Initialized
INFO - 2021-08-18 11:57:19 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:57:19 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:57:19 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:57:19 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 11:57:19 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:57:19 --> Final output sent to browser
DEBUG - 2021-08-18 11:57:19 --> Total execution time: 0.0434
INFO - 2021-08-18 11:57:19 --> Config Class Initialized
INFO - 2021-08-18 11:57:19 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:57:19 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:57:19 --> Utf8 Class Initialized
INFO - 2021-08-18 11:57:19 --> URI Class Initialized
INFO - 2021-08-18 11:57:19 --> Router Class Initialized
INFO - 2021-08-18 11:57:19 --> Output Class Initialized
INFO - 2021-08-18 11:57:19 --> Security Class Initialized
DEBUG - 2021-08-18 11:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:57:19 --> Input Class Initialized
INFO - 2021-08-18 11:57:19 --> Language Class Initialized
INFO - 2021-08-18 11:57:19 --> Loader Class Initialized
INFO - 2021-08-18 11:57:19 --> Helper loaded: url_helper
INFO - 2021-08-18 11:57:19 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:57:19 --> Controller Class Initialized
INFO - 2021-08-18 11:57:19 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:57:19 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:57:19 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:57:19 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 11:57:19 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:57:19 --> Final output sent to browser
DEBUG - 2021-08-18 11:57:19 --> Total execution time: 0.0327
INFO - 2021-08-18 11:57:19 --> Config Class Initialized
INFO - 2021-08-18 11:57:19 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:57:19 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:57:19 --> Utf8 Class Initialized
INFO - 2021-08-18 11:57:19 --> URI Class Initialized
INFO - 2021-08-18 11:57:19 --> Router Class Initialized
INFO - 2021-08-18 11:57:19 --> Output Class Initialized
INFO - 2021-08-18 11:57:19 --> Security Class Initialized
DEBUG - 2021-08-18 11:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:57:19 --> Input Class Initialized
INFO - 2021-08-18 11:57:19 --> Language Class Initialized
INFO - 2021-08-18 11:57:19 --> Loader Class Initialized
INFO - 2021-08-18 11:57:19 --> Helper loaded: url_helper
INFO - 2021-08-18 11:57:19 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:57:19 --> Controller Class Initialized
INFO - 2021-08-18 11:57:19 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:57:19 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:57:20 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:57:20 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 11:57:20 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:57:20 --> Final output sent to browser
DEBUG - 2021-08-18 11:57:20 --> Total execution time: 0.0409
INFO - 2021-08-18 11:58:27 --> Config Class Initialized
INFO - 2021-08-18 11:58:27 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:58:27 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:58:27 --> Utf8 Class Initialized
INFO - 2021-08-18 11:58:27 --> URI Class Initialized
INFO - 2021-08-18 11:58:27 --> Router Class Initialized
INFO - 2021-08-18 11:58:27 --> Output Class Initialized
INFO - 2021-08-18 11:58:27 --> Security Class Initialized
DEBUG - 2021-08-18 11:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:58:27 --> Input Class Initialized
INFO - 2021-08-18 11:58:27 --> Language Class Initialized
INFO - 2021-08-18 11:58:27 --> Loader Class Initialized
INFO - 2021-08-18 11:58:27 --> Helper loaded: url_helper
INFO - 2021-08-18 11:58:27 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:58:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:58:27 --> Controller Class Initialized
INFO - 2021-08-18 11:58:27 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:58:27 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:58:27 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:58:27 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 11:58:27 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:58:27 --> Final output sent to browser
DEBUG - 2021-08-18 11:58:27 --> Total execution time: 0.0397
INFO - 2021-08-18 11:58:41 --> Config Class Initialized
INFO - 2021-08-18 11:58:41 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:58:41 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:58:41 --> Utf8 Class Initialized
INFO - 2021-08-18 11:58:41 --> URI Class Initialized
INFO - 2021-08-18 11:58:41 --> Router Class Initialized
INFO - 2021-08-18 11:58:41 --> Output Class Initialized
INFO - 2021-08-18 11:58:41 --> Security Class Initialized
DEBUG - 2021-08-18 11:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:58:41 --> Input Class Initialized
INFO - 2021-08-18 11:58:41 --> Language Class Initialized
INFO - 2021-08-18 11:58:41 --> Loader Class Initialized
INFO - 2021-08-18 11:58:41 --> Helper loaded: url_helper
INFO - 2021-08-18 11:58:41 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:58:41 --> Controller Class Initialized
INFO - 2021-08-18 11:58:41 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:58:41 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:58:41 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:58:41 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 11:58:41 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:58:41 --> Final output sent to browser
DEBUG - 2021-08-18 11:58:41 --> Total execution time: 0.0396
INFO - 2021-08-18 11:58:50 --> Config Class Initialized
INFO - 2021-08-18 11:58:50 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:58:50 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:58:50 --> Utf8 Class Initialized
INFO - 2021-08-18 11:58:50 --> URI Class Initialized
INFO - 2021-08-18 11:58:50 --> Router Class Initialized
INFO - 2021-08-18 11:58:50 --> Output Class Initialized
INFO - 2021-08-18 11:58:50 --> Security Class Initialized
DEBUG - 2021-08-18 11:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:58:50 --> Input Class Initialized
INFO - 2021-08-18 11:58:50 --> Language Class Initialized
INFO - 2021-08-18 11:58:50 --> Loader Class Initialized
INFO - 2021-08-18 11:58:50 --> Helper loaded: url_helper
INFO - 2021-08-18 11:58:50 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:58:50 --> Controller Class Initialized
INFO - 2021-08-18 11:58:50 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:58:50 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:58:50 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:58:50 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 11:58:50 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:58:50 --> Final output sent to browser
DEBUG - 2021-08-18 11:58:50 --> Total execution time: 0.0310
INFO - 2021-08-18 11:59:09 --> Config Class Initialized
INFO - 2021-08-18 11:59:09 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:59:09 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:59:09 --> Utf8 Class Initialized
INFO - 2021-08-18 11:59:09 --> URI Class Initialized
INFO - 2021-08-18 11:59:09 --> Router Class Initialized
INFO - 2021-08-18 11:59:09 --> Output Class Initialized
INFO - 2021-08-18 11:59:09 --> Security Class Initialized
DEBUG - 2021-08-18 11:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:59:09 --> Input Class Initialized
INFO - 2021-08-18 11:59:09 --> Language Class Initialized
INFO - 2021-08-18 11:59:09 --> Loader Class Initialized
INFO - 2021-08-18 11:59:09 --> Helper loaded: url_helper
INFO - 2021-08-18 11:59:09 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:59:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:59:09 --> Controller Class Initialized
INFO - 2021-08-18 11:59:09 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:59:09 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:59:09 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:59:09 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 11:59:09 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:59:09 --> Final output sent to browser
DEBUG - 2021-08-18 11:59:09 --> Total execution time: 0.0312
INFO - 2021-08-18 11:59:16 --> Config Class Initialized
INFO - 2021-08-18 11:59:16 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:59:16 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:59:16 --> Utf8 Class Initialized
INFO - 2021-08-18 11:59:16 --> URI Class Initialized
INFO - 2021-08-18 11:59:16 --> Router Class Initialized
INFO - 2021-08-18 11:59:16 --> Output Class Initialized
INFO - 2021-08-18 11:59:16 --> Security Class Initialized
DEBUG - 2021-08-18 11:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:59:16 --> Input Class Initialized
INFO - 2021-08-18 11:59:16 --> Language Class Initialized
INFO - 2021-08-18 11:59:16 --> Loader Class Initialized
INFO - 2021-08-18 11:59:16 --> Helper loaded: url_helper
INFO - 2021-08-18 11:59:16 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:59:16 --> Controller Class Initialized
INFO - 2021-08-18 11:59:16 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:59:16 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:59:16 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:59:16 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 11:59:16 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:59:16 --> Final output sent to browser
DEBUG - 2021-08-18 11:59:16 --> Total execution time: 0.0310
INFO - 2021-08-18 11:59:17 --> Config Class Initialized
INFO - 2021-08-18 11:59:17 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:59:17 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:59:17 --> Utf8 Class Initialized
INFO - 2021-08-18 11:59:17 --> URI Class Initialized
INFO - 2021-08-18 11:59:17 --> Router Class Initialized
INFO - 2021-08-18 11:59:17 --> Output Class Initialized
INFO - 2021-08-18 11:59:17 --> Security Class Initialized
DEBUG - 2021-08-18 11:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:59:17 --> Input Class Initialized
INFO - 2021-08-18 11:59:17 --> Language Class Initialized
INFO - 2021-08-18 11:59:17 --> Loader Class Initialized
INFO - 2021-08-18 11:59:17 --> Helper loaded: url_helper
INFO - 2021-08-18 11:59:17 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:59:17 --> Controller Class Initialized
INFO - 2021-08-18 11:59:17 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:59:17 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:59:17 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:59:17 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 11:59:17 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:59:17 --> Final output sent to browser
DEBUG - 2021-08-18 11:59:17 --> Total execution time: 0.0304
INFO - 2021-08-18 11:59:27 --> Config Class Initialized
INFO - 2021-08-18 11:59:27 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:59:27 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:59:27 --> Utf8 Class Initialized
INFO - 2021-08-18 11:59:27 --> URI Class Initialized
INFO - 2021-08-18 11:59:27 --> Router Class Initialized
INFO - 2021-08-18 11:59:27 --> Output Class Initialized
INFO - 2021-08-18 11:59:27 --> Security Class Initialized
DEBUG - 2021-08-18 11:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:59:27 --> Input Class Initialized
INFO - 2021-08-18 11:59:27 --> Language Class Initialized
INFO - 2021-08-18 11:59:27 --> Loader Class Initialized
INFO - 2021-08-18 11:59:27 --> Helper loaded: url_helper
INFO - 2021-08-18 11:59:27 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:59:27 --> Controller Class Initialized
INFO - 2021-08-18 11:59:27 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:59:27 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:59:27 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:59:27 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 11:59:27 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:59:27 --> Final output sent to browser
DEBUG - 2021-08-18 11:59:27 --> Total execution time: 0.0306
INFO - 2021-08-18 11:59:29 --> Config Class Initialized
INFO - 2021-08-18 11:59:29 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:59:29 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:59:29 --> Utf8 Class Initialized
INFO - 2021-08-18 11:59:29 --> URI Class Initialized
INFO - 2021-08-18 11:59:29 --> Router Class Initialized
INFO - 2021-08-18 11:59:29 --> Output Class Initialized
INFO - 2021-08-18 11:59:29 --> Security Class Initialized
DEBUG - 2021-08-18 11:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:59:29 --> Input Class Initialized
INFO - 2021-08-18 11:59:29 --> Language Class Initialized
INFO - 2021-08-18 11:59:29 --> Loader Class Initialized
INFO - 2021-08-18 11:59:29 --> Helper loaded: url_helper
INFO - 2021-08-18 11:59:29 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:59:29 --> Controller Class Initialized
INFO - 2021-08-18 11:59:29 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:59:29 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:59:29 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:59:29 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 11:59:29 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:59:29 --> Final output sent to browser
DEBUG - 2021-08-18 11:59:29 --> Total execution time: 0.0380
INFO - 2021-08-18 11:59:31 --> Config Class Initialized
INFO - 2021-08-18 11:59:31 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:59:31 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:59:31 --> Utf8 Class Initialized
INFO - 2021-08-18 11:59:31 --> URI Class Initialized
INFO - 2021-08-18 11:59:31 --> Router Class Initialized
INFO - 2021-08-18 11:59:31 --> Output Class Initialized
INFO - 2021-08-18 11:59:31 --> Security Class Initialized
DEBUG - 2021-08-18 11:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:59:31 --> Input Class Initialized
INFO - 2021-08-18 11:59:31 --> Language Class Initialized
INFO - 2021-08-18 11:59:31 --> Loader Class Initialized
INFO - 2021-08-18 11:59:31 --> Helper loaded: url_helper
INFO - 2021-08-18 11:59:31 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:59:31 --> Controller Class Initialized
INFO - 2021-08-18 11:59:31 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:59:31 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:59:31 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:59:31 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 11:59:31 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:59:31 --> Final output sent to browser
DEBUG - 2021-08-18 11:59:31 --> Total execution time: 0.0352
INFO - 2021-08-18 11:59:38 --> Config Class Initialized
INFO - 2021-08-18 11:59:38 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:59:38 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:59:38 --> Utf8 Class Initialized
INFO - 2021-08-18 11:59:38 --> URI Class Initialized
INFO - 2021-08-18 11:59:38 --> Router Class Initialized
INFO - 2021-08-18 11:59:39 --> Output Class Initialized
INFO - 2021-08-18 11:59:39 --> Security Class Initialized
DEBUG - 2021-08-18 11:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:59:39 --> Input Class Initialized
INFO - 2021-08-18 11:59:39 --> Language Class Initialized
INFO - 2021-08-18 11:59:39 --> Loader Class Initialized
INFO - 2021-08-18 11:59:39 --> Helper loaded: url_helper
INFO - 2021-08-18 11:59:39 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:59:39 --> Controller Class Initialized
INFO - 2021-08-18 11:59:39 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:59:39 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:59:39 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:59:39 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 11:59:39 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:59:39 --> Final output sent to browser
DEBUG - 2021-08-18 11:59:39 --> Total execution time: 0.0338
INFO - 2021-08-18 11:59:40 --> Config Class Initialized
INFO - 2021-08-18 11:59:40 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:59:40 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:59:40 --> Utf8 Class Initialized
INFO - 2021-08-18 11:59:40 --> URI Class Initialized
INFO - 2021-08-18 11:59:40 --> Router Class Initialized
INFO - 2021-08-18 11:59:40 --> Output Class Initialized
INFO - 2021-08-18 11:59:40 --> Security Class Initialized
DEBUG - 2021-08-18 11:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:59:40 --> Input Class Initialized
INFO - 2021-08-18 11:59:40 --> Language Class Initialized
INFO - 2021-08-18 11:59:40 --> Loader Class Initialized
INFO - 2021-08-18 11:59:40 --> Helper loaded: url_helper
INFO - 2021-08-18 11:59:40 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:59:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:59:40 --> Controller Class Initialized
INFO - 2021-08-18 11:59:40 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:59:40 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:59:40 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:59:40 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 11:59:40 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:59:40 --> Final output sent to browser
DEBUG - 2021-08-18 11:59:40 --> Total execution time: 0.0281
INFO - 2021-08-18 11:59:41 --> Config Class Initialized
INFO - 2021-08-18 11:59:41 --> Hooks Class Initialized
DEBUG - 2021-08-18 11:59:41 --> UTF-8 Support Enabled
INFO - 2021-08-18 11:59:41 --> Utf8 Class Initialized
INFO - 2021-08-18 11:59:41 --> URI Class Initialized
INFO - 2021-08-18 11:59:41 --> Router Class Initialized
INFO - 2021-08-18 11:59:41 --> Output Class Initialized
INFO - 2021-08-18 11:59:41 --> Security Class Initialized
DEBUG - 2021-08-18 11:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 11:59:41 --> Input Class Initialized
INFO - 2021-08-18 11:59:41 --> Language Class Initialized
INFO - 2021-08-18 11:59:41 --> Loader Class Initialized
INFO - 2021-08-18 11:59:41 --> Helper loaded: url_helper
INFO - 2021-08-18 11:59:41 --> Helper loaded: file_helper
DEBUG - 2021-08-18 11:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 11:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 11:59:41 --> Controller Class Initialized
INFO - 2021-08-18 11:59:41 --> Helper loaded: cookie_helper
INFO - 2021-08-18 11:59:41 --> Model "CookieModel" initialized
INFO - 2021-08-18 11:59:41 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 11:59:41 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 11:59:41 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 11:59:41 --> Final output sent to browser
DEBUG - 2021-08-18 11:59:41 --> Total execution time: 0.0299
INFO - 2021-08-18 12:00:29 --> Config Class Initialized
INFO - 2021-08-18 12:00:29 --> Hooks Class Initialized
DEBUG - 2021-08-18 12:00:29 --> UTF-8 Support Enabled
INFO - 2021-08-18 12:00:29 --> Utf8 Class Initialized
INFO - 2021-08-18 12:00:29 --> URI Class Initialized
INFO - 2021-08-18 12:00:29 --> Router Class Initialized
INFO - 2021-08-18 12:00:29 --> Output Class Initialized
INFO - 2021-08-18 12:00:29 --> Security Class Initialized
DEBUG - 2021-08-18 12:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 12:00:29 --> Input Class Initialized
INFO - 2021-08-18 12:00:29 --> Language Class Initialized
INFO - 2021-08-18 12:00:29 --> Loader Class Initialized
INFO - 2021-08-18 12:00:29 --> Helper loaded: url_helper
INFO - 2021-08-18 12:00:29 --> Helper loaded: file_helper
DEBUG - 2021-08-18 12:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 12:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 12:00:29 --> Controller Class Initialized
INFO - 2021-08-18 12:00:29 --> Helper loaded: cookie_helper
INFO - 2021-08-18 12:00:29 --> Model "CookieModel" initialized
INFO - 2021-08-18 12:00:29 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 12:00:29 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 12:00:29 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 12:00:29 --> Final output sent to browser
DEBUG - 2021-08-18 12:00:29 --> Total execution time: 0.0338
INFO - 2021-08-18 12:00:52 --> Config Class Initialized
INFO - 2021-08-18 12:00:52 --> Hooks Class Initialized
DEBUG - 2021-08-18 12:00:52 --> UTF-8 Support Enabled
INFO - 2021-08-18 12:00:52 --> Utf8 Class Initialized
INFO - 2021-08-18 12:00:52 --> URI Class Initialized
INFO - 2021-08-18 12:00:52 --> Router Class Initialized
INFO - 2021-08-18 12:00:52 --> Output Class Initialized
INFO - 2021-08-18 12:00:52 --> Security Class Initialized
DEBUG - 2021-08-18 12:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 12:00:52 --> Input Class Initialized
INFO - 2021-08-18 12:00:52 --> Language Class Initialized
INFO - 2021-08-18 12:00:52 --> Loader Class Initialized
INFO - 2021-08-18 12:00:52 --> Helper loaded: url_helper
INFO - 2021-08-18 12:00:52 --> Helper loaded: file_helper
DEBUG - 2021-08-18 12:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 12:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 12:00:52 --> Controller Class Initialized
INFO - 2021-08-18 12:00:52 --> Helper loaded: cookie_helper
INFO - 2021-08-18 12:00:52 --> Model "CookieModel" initialized
INFO - 2021-08-18 12:00:52 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 12:00:52 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 12:00:52 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 12:00:52 --> Final output sent to browser
DEBUG - 2021-08-18 12:00:52 --> Total execution time: 0.0332
INFO - 2021-08-18 12:01:00 --> Config Class Initialized
INFO - 2021-08-18 12:01:00 --> Hooks Class Initialized
DEBUG - 2021-08-18 12:01:00 --> UTF-8 Support Enabled
INFO - 2021-08-18 12:01:00 --> Utf8 Class Initialized
INFO - 2021-08-18 12:01:00 --> URI Class Initialized
INFO - 2021-08-18 12:01:00 --> Router Class Initialized
INFO - 2021-08-18 12:01:00 --> Output Class Initialized
INFO - 2021-08-18 12:01:00 --> Security Class Initialized
DEBUG - 2021-08-18 12:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 12:01:00 --> Input Class Initialized
INFO - 2021-08-18 12:01:00 --> Language Class Initialized
INFO - 2021-08-18 12:01:00 --> Loader Class Initialized
INFO - 2021-08-18 12:01:00 --> Helper loaded: url_helper
INFO - 2021-08-18 12:01:00 --> Helper loaded: file_helper
DEBUG - 2021-08-18 12:01:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 12:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 12:01:00 --> Controller Class Initialized
INFO - 2021-08-18 12:01:00 --> Helper loaded: cookie_helper
INFO - 2021-08-18 12:01:00 --> Model "CookieModel" initialized
INFO - 2021-08-18 12:01:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 12:01:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 12:01:00 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 12:01:00 --> Final output sent to browser
DEBUG - 2021-08-18 12:01:00 --> Total execution time: 0.0367
INFO - 2021-08-18 12:02:36 --> Config Class Initialized
INFO - 2021-08-18 12:02:36 --> Hooks Class Initialized
DEBUG - 2021-08-18 12:02:36 --> UTF-8 Support Enabled
INFO - 2021-08-18 12:02:36 --> Utf8 Class Initialized
INFO - 2021-08-18 12:02:36 --> URI Class Initialized
INFO - 2021-08-18 12:02:36 --> Router Class Initialized
INFO - 2021-08-18 12:02:36 --> Output Class Initialized
INFO - 2021-08-18 12:02:36 --> Security Class Initialized
DEBUG - 2021-08-18 12:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 12:02:36 --> Input Class Initialized
INFO - 2021-08-18 12:02:36 --> Language Class Initialized
INFO - 2021-08-18 12:02:36 --> Loader Class Initialized
INFO - 2021-08-18 12:02:36 --> Helper loaded: url_helper
INFO - 2021-08-18 12:02:36 --> Helper loaded: file_helper
DEBUG - 2021-08-18 12:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 12:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 12:02:36 --> Controller Class Initialized
INFO - 2021-08-18 12:02:36 --> Helper loaded: cookie_helper
INFO - 2021-08-18 12:02:36 --> Model "CookieModel" initialized
INFO - 2021-08-18 12:02:36 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 12:02:36 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/pilates.php
INFO - 2021-08-18 12:02:36 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 12:02:36 --> Final output sent to browser
DEBUG - 2021-08-18 12:02:36 --> Total execution time: 0.0344
INFO - 2021-08-18 12:21:51 --> Config Class Initialized
INFO - 2021-08-18 12:21:51 --> Hooks Class Initialized
DEBUG - 2021-08-18 12:21:51 --> UTF-8 Support Enabled
INFO - 2021-08-18 12:21:51 --> Utf8 Class Initialized
INFO - 2021-08-18 12:21:51 --> URI Class Initialized
INFO - 2021-08-18 12:21:51 --> Router Class Initialized
INFO - 2021-08-18 12:21:51 --> Output Class Initialized
INFO - 2021-08-18 12:21:51 --> Security Class Initialized
DEBUG - 2021-08-18 12:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 12:21:51 --> Input Class Initialized
INFO - 2021-08-18 12:21:51 --> Language Class Initialized
INFO - 2021-08-18 12:21:51 --> Loader Class Initialized
INFO - 2021-08-18 12:21:51 --> Helper loaded: url_helper
INFO - 2021-08-18 12:21:51 --> Helper loaded: file_helper
DEBUG - 2021-08-18 12:21:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 12:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 12:21:51 --> Controller Class Initialized
INFO - 2021-08-18 12:21:51 --> Helper loaded: cookie_helper
INFO - 2021-08-18 12:21:51 --> Model "CookieModel" initialized
INFO - 2021-08-18 12:21:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 12:21:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/pilates.php
INFO - 2021-08-18 12:21:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 12:21:51 --> Final output sent to browser
DEBUG - 2021-08-18 12:21:51 --> Total execution time: 0.0551
INFO - 2021-08-18 12:22:05 --> Config Class Initialized
INFO - 2021-08-18 12:22:05 --> Hooks Class Initialized
DEBUG - 2021-08-18 12:22:05 --> UTF-8 Support Enabled
INFO - 2021-08-18 12:22:05 --> Utf8 Class Initialized
INFO - 2021-08-18 12:22:05 --> URI Class Initialized
INFO - 2021-08-18 12:22:05 --> Router Class Initialized
INFO - 2021-08-18 12:22:05 --> Output Class Initialized
INFO - 2021-08-18 12:22:05 --> Security Class Initialized
DEBUG - 2021-08-18 12:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 12:22:05 --> Input Class Initialized
INFO - 2021-08-18 12:22:05 --> Language Class Initialized
INFO - 2021-08-18 12:22:05 --> Loader Class Initialized
INFO - 2021-08-18 12:22:05 --> Helper loaded: url_helper
INFO - 2021-08-18 12:22:05 --> Helper loaded: file_helper
DEBUG - 2021-08-18 12:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 12:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 12:22:05 --> Controller Class Initialized
INFO - 2021-08-18 12:22:05 --> Helper loaded: cookie_helper
INFO - 2021-08-18 12:22:05 --> Model "CookieModel" initialized
INFO - 2021-08-18 12:22:05 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 12:22:05 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/pilates.php
INFO - 2021-08-18 12:22:05 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 12:22:05 --> Final output sent to browser
DEBUG - 2021-08-18 12:22:05 --> Total execution time: 0.0303
INFO - 2021-08-18 12:22:07 --> Config Class Initialized
INFO - 2021-08-18 12:22:07 --> Hooks Class Initialized
DEBUG - 2021-08-18 12:22:07 --> UTF-8 Support Enabled
INFO - 2021-08-18 12:22:07 --> Utf8 Class Initialized
INFO - 2021-08-18 12:22:07 --> URI Class Initialized
INFO - 2021-08-18 12:22:07 --> Router Class Initialized
INFO - 2021-08-18 12:22:07 --> Output Class Initialized
INFO - 2021-08-18 12:22:07 --> Security Class Initialized
DEBUG - 2021-08-18 12:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 12:22:07 --> Input Class Initialized
INFO - 2021-08-18 12:22:07 --> Language Class Initialized
INFO - 2021-08-18 12:22:07 --> Loader Class Initialized
INFO - 2021-08-18 12:22:07 --> Helper loaded: url_helper
INFO - 2021-08-18 12:22:07 --> Helper loaded: file_helper
DEBUG - 2021-08-18 12:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 12:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 12:22:07 --> Controller Class Initialized
INFO - 2021-08-18 12:22:07 --> Helper loaded: cookie_helper
INFO - 2021-08-18 12:22:07 --> Model "CookieModel" initialized
INFO - 2021-08-18 12:22:07 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 12:22:07 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/pilates.php
INFO - 2021-08-18 12:22:07 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 12:22:07 --> Final output sent to browser
DEBUG - 2021-08-18 12:22:07 --> Total execution time: 0.0342
INFO - 2021-08-18 12:22:24 --> Config Class Initialized
INFO - 2021-08-18 12:22:24 --> Hooks Class Initialized
DEBUG - 2021-08-18 12:22:24 --> UTF-8 Support Enabled
INFO - 2021-08-18 12:22:24 --> Utf8 Class Initialized
INFO - 2021-08-18 12:22:24 --> URI Class Initialized
INFO - 2021-08-18 12:22:24 --> Router Class Initialized
INFO - 2021-08-18 12:22:24 --> Output Class Initialized
INFO - 2021-08-18 12:22:24 --> Security Class Initialized
DEBUG - 2021-08-18 12:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 12:22:24 --> Input Class Initialized
INFO - 2021-08-18 12:22:24 --> Language Class Initialized
INFO - 2021-08-18 12:22:24 --> Loader Class Initialized
INFO - 2021-08-18 12:22:24 --> Helper loaded: url_helper
INFO - 2021-08-18 12:22:24 --> Helper loaded: file_helper
DEBUG - 2021-08-18 12:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 12:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 12:22:24 --> Controller Class Initialized
INFO - 2021-08-18 12:22:24 --> Helper loaded: cookie_helper
INFO - 2021-08-18 12:22:24 --> Model "CookieModel" initialized
INFO - 2021-08-18 12:22:24 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 12:22:24 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/pilates.php
INFO - 2021-08-18 12:22:24 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 12:22:24 --> Final output sent to browser
DEBUG - 2021-08-18 12:22:24 --> Total execution time: 0.0395
INFO - 2021-08-18 12:23:44 --> Config Class Initialized
INFO - 2021-08-18 12:23:44 --> Hooks Class Initialized
DEBUG - 2021-08-18 12:23:44 --> UTF-8 Support Enabled
INFO - 2021-08-18 12:23:44 --> Utf8 Class Initialized
INFO - 2021-08-18 12:23:44 --> URI Class Initialized
INFO - 2021-08-18 12:23:44 --> Router Class Initialized
INFO - 2021-08-18 12:23:44 --> Output Class Initialized
INFO - 2021-08-18 12:23:44 --> Security Class Initialized
DEBUG - 2021-08-18 12:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 12:23:44 --> Input Class Initialized
INFO - 2021-08-18 12:23:44 --> Language Class Initialized
INFO - 2021-08-18 12:23:44 --> Loader Class Initialized
INFO - 2021-08-18 12:23:44 --> Helper loaded: url_helper
INFO - 2021-08-18 12:23:44 --> Helper loaded: file_helper
DEBUG - 2021-08-18 12:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 12:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 12:23:44 --> Controller Class Initialized
INFO - 2021-08-18 12:23:44 --> Helper loaded: cookie_helper
INFO - 2021-08-18 12:23:44 --> Model "CookieModel" initialized
INFO - 2021-08-18 12:23:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 12:23:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 12:23:44 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 12:23:44 --> Final output sent to browser
DEBUG - 2021-08-18 12:23:44 --> Total execution time: 0.0506
INFO - 2021-08-18 12:25:48 --> Config Class Initialized
INFO - 2021-08-18 12:25:48 --> Hooks Class Initialized
DEBUG - 2021-08-18 12:25:48 --> UTF-8 Support Enabled
INFO - 2021-08-18 12:25:48 --> Utf8 Class Initialized
INFO - 2021-08-18 12:25:48 --> URI Class Initialized
INFO - 2021-08-18 12:25:48 --> Router Class Initialized
INFO - 2021-08-18 12:25:48 --> Output Class Initialized
INFO - 2021-08-18 12:25:48 --> Security Class Initialized
DEBUG - 2021-08-18 12:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 12:25:48 --> Input Class Initialized
INFO - 2021-08-18 12:25:48 --> Language Class Initialized
INFO - 2021-08-18 12:25:48 --> Loader Class Initialized
INFO - 2021-08-18 12:25:48 --> Helper loaded: url_helper
INFO - 2021-08-18 12:25:48 --> Helper loaded: file_helper
DEBUG - 2021-08-18 12:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 12:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 12:25:48 --> Controller Class Initialized
INFO - 2021-08-18 12:25:48 --> Helper loaded: cookie_helper
INFO - 2021-08-18 12:25:48 --> Model "CookieModel" initialized
INFO - 2021-08-18 12:25:48 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 12:25:48 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 12:25:48 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 12:25:48 --> Final output sent to browser
DEBUG - 2021-08-18 12:25:48 --> Total execution time: 0.0325
INFO - 2021-08-18 12:26:01 --> Config Class Initialized
INFO - 2021-08-18 12:26:01 --> Hooks Class Initialized
DEBUG - 2021-08-18 12:26:01 --> UTF-8 Support Enabled
INFO - 2021-08-18 12:26:01 --> Utf8 Class Initialized
INFO - 2021-08-18 12:26:01 --> URI Class Initialized
INFO - 2021-08-18 12:26:01 --> Router Class Initialized
INFO - 2021-08-18 12:26:01 --> Output Class Initialized
INFO - 2021-08-18 12:26:01 --> Security Class Initialized
DEBUG - 2021-08-18 12:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 12:26:01 --> Input Class Initialized
INFO - 2021-08-18 12:26:01 --> Language Class Initialized
INFO - 2021-08-18 12:26:01 --> Loader Class Initialized
INFO - 2021-08-18 12:26:01 --> Helper loaded: url_helper
INFO - 2021-08-18 12:26:01 --> Helper loaded: file_helper
DEBUG - 2021-08-18 12:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 12:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 12:26:01 --> Controller Class Initialized
INFO - 2021-08-18 12:26:01 --> Helper loaded: cookie_helper
INFO - 2021-08-18 12:26:01 --> Model "CookieModel" initialized
INFO - 2021-08-18 12:26:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 12:26:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 12:26:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 12:26:01 --> Final output sent to browser
DEBUG - 2021-08-18 12:26:01 --> Total execution time: 0.0387
INFO - 2021-08-18 12:26:10 --> Config Class Initialized
INFO - 2021-08-18 12:26:10 --> Hooks Class Initialized
DEBUG - 2021-08-18 12:26:10 --> UTF-8 Support Enabled
INFO - 2021-08-18 12:26:10 --> Utf8 Class Initialized
INFO - 2021-08-18 12:26:10 --> URI Class Initialized
INFO - 2021-08-18 12:26:10 --> Router Class Initialized
INFO - 2021-08-18 12:26:10 --> Output Class Initialized
INFO - 2021-08-18 12:26:10 --> Security Class Initialized
INFO - 2021-08-18 12:26:10 --> Config Class Initialized
DEBUG - 2021-08-18 12:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 12:26:10 --> Input Class Initialized
INFO - 2021-08-18 12:26:10 --> Hooks Class Initialized
INFO - 2021-08-18 12:26:10 --> Language Class Initialized
ERROR - 2021-08-18 12:26:10 --> 404 Page Not Found: Assets/js
DEBUG - 2021-08-18 12:26:10 --> UTF-8 Support Enabled
INFO - 2021-08-18 12:26:10 --> Utf8 Class Initialized
INFO - 2021-08-18 12:26:10 --> URI Class Initialized
INFO - 2021-08-18 12:26:10 --> Router Class Initialized
INFO - 2021-08-18 12:26:10 --> Output Class Initialized
INFO - 2021-08-18 12:26:10 --> Security Class Initialized
INFO - 2021-08-18 12:26:10 --> Config Class Initialized
INFO - 2021-08-18 12:26:10 --> Hooks Class Initialized
DEBUG - 2021-08-18 12:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 12:26:10 --> Input Class Initialized
INFO - 2021-08-18 12:26:10 --> Language Class Initialized
DEBUG - 2021-08-18 12:26:10 --> UTF-8 Support Enabled
INFO - 2021-08-18 12:26:10 --> Utf8 Class Initialized
ERROR - 2021-08-18 12:26:10 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 12:26:10 --> URI Class Initialized
INFO - 2021-08-18 12:26:10 --> Router Class Initialized
INFO - 2021-08-18 12:26:10 --> Output Class Initialized
INFO - 2021-08-18 12:26:10 --> Security Class Initialized
DEBUG - 2021-08-18 12:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 12:26:10 --> Input Class Initialized
INFO - 2021-08-18 12:26:10 --> Language Class Initialized
ERROR - 2021-08-18 12:26:10 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 12:26:10 --> Config Class Initialized
INFO - 2021-08-18 12:26:10 --> Hooks Class Initialized
DEBUG - 2021-08-18 12:26:10 --> UTF-8 Support Enabled
INFO - 2021-08-18 12:26:10 --> Utf8 Class Initialized
INFO - 2021-08-18 12:26:10 --> Config Class Initialized
INFO - 2021-08-18 12:26:10 --> Hooks Class Initialized
INFO - 2021-08-18 12:26:10 --> URI Class Initialized
INFO - 2021-08-18 12:26:10 --> Router Class Initialized
DEBUG - 2021-08-18 12:26:10 --> UTF-8 Support Enabled
INFO - 2021-08-18 12:26:10 --> Utf8 Class Initialized
INFO - 2021-08-18 12:26:10 --> URI Class Initialized
INFO - 2021-08-18 12:26:10 --> Output Class Initialized
INFO - 2021-08-18 12:26:10 --> Router Class Initialized
INFO - 2021-08-18 12:26:10 --> Security Class Initialized
INFO - 2021-08-18 12:26:10 --> Output Class Initialized
DEBUG - 2021-08-18 12:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 12:26:10 --> Input Class Initialized
INFO - 2021-08-18 12:26:10 --> Language Class Initialized
INFO - 2021-08-18 12:26:10 --> Security Class Initialized
DEBUG - 2021-08-18 12:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 12:26:10 --> Input Class Initialized
ERROR - 2021-08-18 12:26:10 --> 404 Page Not Found: Assets/css
INFO - 2021-08-18 12:26:10 --> Language Class Initialized
ERROR - 2021-08-18 12:26:10 --> 404 Page Not Found: Assets/css
INFO - 2021-08-18 12:26:23 --> Config Class Initialized
INFO - 2021-08-18 12:26:23 --> Hooks Class Initialized
DEBUG - 2021-08-18 12:26:23 --> UTF-8 Support Enabled
INFO - 2021-08-18 12:26:23 --> Utf8 Class Initialized
INFO - 2021-08-18 12:26:23 --> URI Class Initialized
INFO - 2021-08-18 12:26:23 --> Router Class Initialized
INFO - 2021-08-18 12:26:23 --> Output Class Initialized
INFO - 2021-08-18 12:26:23 --> Security Class Initialized
DEBUG - 2021-08-18 12:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 12:26:23 --> Input Class Initialized
INFO - 2021-08-18 12:26:23 --> Language Class Initialized
INFO - 2021-08-18 12:26:23 --> Loader Class Initialized
INFO - 2021-08-18 12:26:23 --> Helper loaded: url_helper
INFO - 2021-08-18 12:26:23 --> Helper loaded: file_helper
DEBUG - 2021-08-18 12:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 12:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 12:26:23 --> Controller Class Initialized
INFO - 2021-08-18 12:26:23 --> Helper loaded: cookie_helper
INFO - 2021-08-18 12:26:23 --> Model "CookieModel" initialized
INFO - 2021-08-18 12:26:23 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 12:26:23 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/pilates.php
INFO - 2021-08-18 12:26:23 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 12:26:23 --> Final output sent to browser
DEBUG - 2021-08-18 12:26:23 --> Total execution time: 0.0441
INFO - 2021-08-18 12:27:16 --> Config Class Initialized
INFO - 2021-08-18 12:27:16 --> Hooks Class Initialized
DEBUG - 2021-08-18 12:27:16 --> UTF-8 Support Enabled
INFO - 2021-08-18 12:27:16 --> Utf8 Class Initialized
INFO - 2021-08-18 12:27:16 --> URI Class Initialized
INFO - 2021-08-18 12:27:16 --> Router Class Initialized
INFO - 2021-08-18 12:27:16 --> Output Class Initialized
INFO - 2021-08-18 12:27:16 --> Security Class Initialized
DEBUG - 2021-08-18 12:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 12:27:16 --> Input Class Initialized
INFO - 2021-08-18 12:27:16 --> Language Class Initialized
INFO - 2021-08-18 12:27:16 --> Loader Class Initialized
INFO - 2021-08-18 12:27:16 --> Helper loaded: url_helper
INFO - 2021-08-18 12:27:16 --> Helper loaded: file_helper
DEBUG - 2021-08-18 12:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 12:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 12:27:16 --> Controller Class Initialized
INFO - 2021-08-18 12:27:16 --> Helper loaded: cookie_helper
INFO - 2021-08-18 12:27:16 --> Model "CookieModel" initialized
INFO - 2021-08-18 12:27:16 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 12:27:16 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/pilates.php
INFO - 2021-08-18 12:27:16 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 12:27:16 --> Final output sent to browser
DEBUG - 2021-08-18 12:27:16 --> Total execution time: 0.0351
INFO - 2021-08-18 12:27:45 --> Config Class Initialized
INFO - 2021-08-18 12:27:45 --> Hooks Class Initialized
DEBUG - 2021-08-18 12:27:45 --> UTF-8 Support Enabled
INFO - 2021-08-18 12:27:45 --> Utf8 Class Initialized
INFO - 2021-08-18 12:27:45 --> URI Class Initialized
INFO - 2021-08-18 12:27:45 --> Router Class Initialized
INFO - 2021-08-18 12:27:45 --> Output Class Initialized
INFO - 2021-08-18 12:27:45 --> Security Class Initialized
DEBUG - 2021-08-18 12:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 12:27:45 --> Input Class Initialized
INFO - 2021-08-18 12:27:45 --> Language Class Initialized
INFO - 2021-08-18 12:27:45 --> Loader Class Initialized
INFO - 2021-08-18 12:27:45 --> Helper loaded: url_helper
INFO - 2021-08-18 12:27:45 --> Helper loaded: file_helper
DEBUG - 2021-08-18 12:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 12:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 12:27:45 --> Controller Class Initialized
INFO - 2021-08-18 12:27:45 --> Helper loaded: cookie_helper
INFO - 2021-08-18 12:27:45 --> Model "CookieModel" initialized
INFO - 2021-08-18 12:27:45 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 12:27:45 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/pilates.php
INFO - 2021-08-18 12:27:45 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 12:27:45 --> Final output sent to browser
DEBUG - 2021-08-18 12:27:45 --> Total execution time: 0.0344
INFO - 2021-08-18 12:27:52 --> Config Class Initialized
INFO - 2021-08-18 12:27:52 --> Hooks Class Initialized
DEBUG - 2021-08-18 12:27:52 --> UTF-8 Support Enabled
INFO - 2021-08-18 12:27:52 --> Utf8 Class Initialized
INFO - 2021-08-18 12:27:52 --> URI Class Initialized
INFO - 2021-08-18 12:27:52 --> Router Class Initialized
INFO - 2021-08-18 12:27:52 --> Config Class Initialized
INFO - 2021-08-18 12:27:52 --> Hooks Class Initialized
INFO - 2021-08-18 12:27:52 --> Output Class Initialized
DEBUG - 2021-08-18 12:27:52 --> UTF-8 Support Enabled
INFO - 2021-08-18 12:27:52 --> Security Class Initialized
INFO - 2021-08-18 12:27:52 --> Utf8 Class Initialized
INFO - 2021-08-18 12:27:52 --> URI Class Initialized
DEBUG - 2021-08-18 12:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 12:27:52 --> Input Class Initialized
INFO - 2021-08-18 12:27:52 --> Language Class Initialized
INFO - 2021-08-18 12:27:52 --> Router Class Initialized
ERROR - 2021-08-18 12:27:52 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 12:27:52 --> Output Class Initialized
INFO - 2021-08-18 12:27:52 --> Security Class Initialized
DEBUG - 2021-08-18 12:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 12:27:52 --> Input Class Initialized
INFO - 2021-08-18 12:27:52 --> Language Class Initialized
ERROR - 2021-08-18 12:27:52 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 12:27:52 --> Config Class Initialized
INFO - 2021-08-18 12:27:52 --> Hooks Class Initialized
DEBUG - 2021-08-18 12:27:52 --> UTF-8 Support Enabled
INFO - 2021-08-18 12:27:52 --> Utf8 Class Initialized
INFO - 2021-08-18 12:27:52 --> URI Class Initialized
INFO - 2021-08-18 12:27:52 --> Router Class Initialized
INFO - 2021-08-18 12:27:52 --> Output Class Initialized
INFO - 2021-08-18 12:27:52 --> Security Class Initialized
DEBUG - 2021-08-18 12:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 12:27:52 --> Input Class Initialized
INFO - 2021-08-18 12:27:52 --> Language Class Initialized
ERROR - 2021-08-18 12:27:52 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 12:27:52 --> Config Class Initialized
INFO - 2021-08-18 12:27:52 --> Hooks Class Initialized
INFO - 2021-08-18 12:27:52 --> Config Class Initialized
INFO - 2021-08-18 12:27:52 --> Hooks Class Initialized
DEBUG - 2021-08-18 12:27:52 --> UTF-8 Support Enabled
INFO - 2021-08-18 12:27:52 --> Utf8 Class Initialized
INFO - 2021-08-18 12:27:52 --> URI Class Initialized
DEBUG - 2021-08-18 12:27:52 --> UTF-8 Support Enabled
INFO - 2021-08-18 12:27:52 --> Utf8 Class Initialized
INFO - 2021-08-18 12:27:52 --> Router Class Initialized
INFO - 2021-08-18 12:27:52 --> URI Class Initialized
INFO - 2021-08-18 12:27:52 --> Router Class Initialized
INFO - 2021-08-18 12:27:52 --> Output Class Initialized
INFO - 2021-08-18 12:27:52 --> Security Class Initialized
INFO - 2021-08-18 12:27:52 --> Output Class Initialized
DEBUG - 2021-08-18 12:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 12:27:52 --> Input Class Initialized
INFO - 2021-08-18 12:27:52 --> Security Class Initialized
INFO - 2021-08-18 12:27:52 --> Language Class Initialized
DEBUG - 2021-08-18 12:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 12:27:52 --> Input Class Initialized
ERROR - 2021-08-18 12:27:52 --> 404 Page Not Found: Assets/css
INFO - 2021-08-18 12:27:52 --> Language Class Initialized
ERROR - 2021-08-18 12:27:52 --> 404 Page Not Found: Assets/css
INFO - 2021-08-18 12:27:58 --> Config Class Initialized
INFO - 2021-08-18 12:27:58 --> Hooks Class Initialized
DEBUG - 2021-08-18 12:27:58 --> UTF-8 Support Enabled
INFO - 2021-08-18 12:27:58 --> Utf8 Class Initialized
INFO - 2021-08-18 12:27:58 --> URI Class Initialized
INFO - 2021-08-18 12:27:58 --> Router Class Initialized
INFO - 2021-08-18 12:27:58 --> Output Class Initialized
INFO - 2021-08-18 12:27:58 --> Security Class Initialized
DEBUG - 2021-08-18 12:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 12:27:58 --> Input Class Initialized
INFO - 2021-08-18 12:27:58 --> Language Class Initialized
INFO - 2021-08-18 12:27:58 --> Loader Class Initialized
INFO - 2021-08-18 12:27:58 --> Helper loaded: url_helper
INFO - 2021-08-18 12:27:58 --> Helper loaded: file_helper
DEBUG - 2021-08-18 12:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 12:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 12:27:58 --> Controller Class Initialized
INFO - 2021-08-18 12:27:58 --> Helper loaded: cookie_helper
INFO - 2021-08-18 12:27:58 --> Model "CookieModel" initialized
INFO - 2021-08-18 12:27:58 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 12:27:58 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 12:27:58 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 12:27:58 --> Final output sent to browser
DEBUG - 2021-08-18 12:27:58 --> Total execution time: 0.0372
INFO - 2021-08-18 12:28:01 --> Config Class Initialized
INFO - 2021-08-18 12:28:01 --> Hooks Class Initialized
DEBUG - 2021-08-18 12:28:01 --> UTF-8 Support Enabled
INFO - 2021-08-18 12:28:01 --> Utf8 Class Initialized
INFO - 2021-08-18 12:28:01 --> URI Class Initialized
INFO - 2021-08-18 12:28:01 --> Router Class Initialized
INFO - 2021-08-18 12:28:01 --> Output Class Initialized
INFO - 2021-08-18 12:28:01 --> Security Class Initialized
DEBUG - 2021-08-18 12:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 12:28:01 --> Input Class Initialized
INFO - 2021-08-18 12:28:01 --> Language Class Initialized
INFO - 2021-08-18 12:28:01 --> Loader Class Initialized
INFO - 2021-08-18 12:28:01 --> Helper loaded: url_helper
INFO - 2021-08-18 12:28:01 --> Helper loaded: file_helper
DEBUG - 2021-08-18 12:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 12:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 12:28:01 --> Controller Class Initialized
INFO - 2021-08-18 12:28:01 --> Helper loaded: cookie_helper
INFO - 2021-08-18 12:28:01 --> Model "CookieModel" initialized
INFO - 2021-08-18 12:28:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 12:28:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/pilates.php
INFO - 2021-08-18 12:28:01 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 12:28:01 --> Final output sent to browser
DEBUG - 2021-08-18 12:28:01 --> Total execution time: 0.0359
INFO - 2021-08-18 12:28:46 --> Config Class Initialized
INFO - 2021-08-18 12:28:46 --> Hooks Class Initialized
DEBUG - 2021-08-18 12:28:46 --> UTF-8 Support Enabled
INFO - 2021-08-18 12:28:46 --> Utf8 Class Initialized
INFO - 2021-08-18 12:28:46 --> URI Class Initialized
INFO - 2021-08-18 12:28:46 --> Router Class Initialized
INFO - 2021-08-18 12:28:46 --> Output Class Initialized
INFO - 2021-08-18 12:28:46 --> Security Class Initialized
DEBUG - 2021-08-18 12:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 12:28:46 --> Input Class Initialized
INFO - 2021-08-18 12:28:46 --> Language Class Initialized
INFO - 2021-08-18 12:28:46 --> Loader Class Initialized
INFO - 2021-08-18 12:28:46 --> Helper loaded: url_helper
INFO - 2021-08-18 12:28:46 --> Helper loaded: file_helper
DEBUG - 2021-08-18 12:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 12:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 12:28:46 --> Controller Class Initialized
INFO - 2021-08-18 12:28:46 --> Helper loaded: cookie_helper
INFO - 2021-08-18 12:28:46 --> Model "CookieModel" initialized
INFO - 2021-08-18 12:28:46 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 12:28:46 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/services.php
INFO - 2021-08-18 12:28:46 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 12:28:46 --> Final output sent to browser
DEBUG - 2021-08-18 12:28:46 --> Total execution time: 0.0321
INFO - 2021-08-18 12:36:42 --> Config Class Initialized
INFO - 2021-08-18 12:36:42 --> Hooks Class Initialized
DEBUG - 2021-08-18 12:36:42 --> UTF-8 Support Enabled
INFO - 2021-08-18 12:36:42 --> Utf8 Class Initialized
INFO - 2021-08-18 12:36:42 --> Config Class Initialized
INFO - 2021-08-18 12:36:42 --> Hooks Class Initialized
INFO - 2021-08-18 12:36:42 --> URI Class Initialized
DEBUG - 2021-08-18 12:36:42 --> UTF-8 Support Enabled
INFO - 2021-08-18 12:36:42 --> Router Class Initialized
INFO - 2021-08-18 12:36:42 --> Utf8 Class Initialized
INFO - 2021-08-18 12:36:42 --> URI Class Initialized
INFO - 2021-08-18 12:36:42 --> Output Class Initialized
INFO - 2021-08-18 12:36:42 --> Config Class Initialized
INFO - 2021-08-18 12:36:42 --> Router Class Initialized
INFO - 2021-08-18 12:36:42 --> Hooks Class Initialized
INFO - 2021-08-18 12:36:42 --> Security Class Initialized
INFO - 2021-08-18 12:36:42 --> Output Class Initialized
DEBUG - 2021-08-18 12:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 12:36:42 --> Input Class Initialized
DEBUG - 2021-08-18 12:36:42 --> UTF-8 Support Enabled
INFO - 2021-08-18 12:36:42 --> Utf8 Class Initialized
INFO - 2021-08-18 12:36:42 --> Language Class Initialized
INFO - 2021-08-18 12:36:42 --> Security Class Initialized
INFO - 2021-08-18 12:36:42 --> URI Class Initialized
ERROR - 2021-08-18 12:36:42 --> 404 Page Not Found: Assets/js
DEBUG - 2021-08-18 12:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 12:36:42 --> Router Class Initialized
INFO - 2021-08-18 12:36:42 --> Input Class Initialized
INFO - 2021-08-18 12:36:42 --> Language Class Initialized
INFO - 2021-08-18 12:36:42 --> Output Class Initialized
ERROR - 2021-08-18 12:36:42 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 12:36:42 --> Security Class Initialized
DEBUG - 2021-08-18 12:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 12:36:42 --> Input Class Initialized
INFO - 2021-08-18 12:36:42 --> Language Class Initialized
ERROR - 2021-08-18 12:36:42 --> 404 Page Not Found: Assets/js
INFO - 2021-08-18 12:36:43 --> Config Class Initialized
INFO - 2021-08-18 12:36:43 --> Hooks Class Initialized
INFO - 2021-08-18 12:36:43 --> Config Class Initialized
INFO - 2021-08-18 12:36:43 --> Hooks Class Initialized
DEBUG - 2021-08-18 12:36:43 --> UTF-8 Support Enabled
INFO - 2021-08-18 12:36:43 --> Utf8 Class Initialized
INFO - 2021-08-18 12:36:43 --> URI Class Initialized
DEBUG - 2021-08-18 12:36:43 --> UTF-8 Support Enabled
INFO - 2021-08-18 12:36:43 --> Utf8 Class Initialized
INFO - 2021-08-18 12:36:43 --> URI Class Initialized
INFO - 2021-08-18 12:36:43 --> Router Class Initialized
INFO - 2021-08-18 12:36:43 --> Router Class Initialized
INFO - 2021-08-18 12:36:43 --> Output Class Initialized
INFO - 2021-08-18 12:36:43 --> Output Class Initialized
INFO - 2021-08-18 12:36:43 --> Security Class Initialized
INFO - 2021-08-18 12:36:43 --> Security Class Initialized
DEBUG - 2021-08-18 12:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 12:36:43 --> Input Class Initialized
INFO - 2021-08-18 12:36:43 --> Language Class Initialized
DEBUG - 2021-08-18 12:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 12:36:43 --> Input Class Initialized
INFO - 2021-08-18 12:36:43 --> Language Class Initialized
ERROR - 2021-08-18 12:36:43 --> 404 Page Not Found: Assets/css
ERROR - 2021-08-18 12:36:43 --> 404 Page Not Found: Assets/css
INFO - 2021-08-18 13:50:07 --> Config Class Initialized
INFO - 2021-08-18 13:50:07 --> Hooks Class Initialized
DEBUG - 2021-08-18 13:50:07 --> UTF-8 Support Enabled
INFO - 2021-08-18 13:50:07 --> Utf8 Class Initialized
INFO - 2021-08-18 13:50:07 --> URI Class Initialized
DEBUG - 2021-08-18 13:50:07 --> No URI present. Default controller set.
INFO - 2021-08-18 13:50:07 --> Router Class Initialized
INFO - 2021-08-18 13:50:07 --> Output Class Initialized
INFO - 2021-08-18 13:50:07 --> Security Class Initialized
DEBUG - 2021-08-18 13:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 13:50:07 --> Input Class Initialized
INFO - 2021-08-18 13:50:07 --> Language Class Initialized
INFO - 2021-08-18 13:50:07 --> Loader Class Initialized
INFO - 2021-08-18 13:50:07 --> Helper loaded: url_helper
INFO - 2021-08-18 13:50:07 --> Helper loaded: file_helper
DEBUG - 2021-08-18 13:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 13:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 13:50:07 --> Controller Class Initialized
INFO - 2021-08-18 13:50:07 --> Helper loaded: cookie_helper
INFO - 2021-08-18 13:50:07 --> Model "CookieModel" initialized
INFO - 2021-08-18 13:50:07 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 13:50:07 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-18 13:50:07 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 13:50:07 --> Final output sent to browser
DEBUG - 2021-08-18 13:50:07 --> Total execution time: 0.0726
INFO - 2021-08-18 13:50:12 --> Config Class Initialized
INFO - 2021-08-18 13:50:12 --> Hooks Class Initialized
DEBUG - 2021-08-18 13:50:12 --> UTF-8 Support Enabled
INFO - 2021-08-18 13:50:12 --> Utf8 Class Initialized
INFO - 2021-08-18 13:50:12 --> URI Class Initialized
INFO - 2021-08-18 13:50:12 --> Router Class Initialized
INFO - 2021-08-18 13:50:12 --> Output Class Initialized
INFO - 2021-08-18 13:50:12 --> Security Class Initialized
DEBUG - 2021-08-18 13:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 13:50:12 --> Input Class Initialized
INFO - 2021-08-18 13:50:12 --> Language Class Initialized
INFO - 2021-08-18 13:50:12 --> Loader Class Initialized
INFO - 2021-08-18 13:50:12 --> Helper loaded: url_helper
INFO - 2021-08-18 13:50:12 --> Helper loaded: file_helper
DEBUG - 2021-08-18 13:50:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 13:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 13:50:12 --> Controller Class Initialized
INFO - 2021-08-18 13:50:12 --> Helper loaded: cookie_helper
INFO - 2021-08-18 13:50:12 --> Model "CookieModel" initialized
INFO - 2021-08-18 13:50:12 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 13:50:12 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/pilates.php
INFO - 2021-08-18 13:50:12 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 13:50:12 --> Final output sent to browser
DEBUG - 2021-08-18 13:50:12 --> Total execution time: 0.0345
INFO - 2021-08-18 13:51:31 --> Config Class Initialized
INFO - 2021-08-18 13:51:31 --> Hooks Class Initialized
DEBUG - 2021-08-18 13:51:31 --> UTF-8 Support Enabled
INFO - 2021-08-18 13:51:31 --> Utf8 Class Initialized
INFO - 2021-08-18 13:51:31 --> URI Class Initialized
DEBUG - 2021-08-18 13:51:31 --> No URI present. Default controller set.
INFO - 2021-08-18 13:51:31 --> Router Class Initialized
INFO - 2021-08-18 13:51:31 --> Output Class Initialized
INFO - 2021-08-18 13:51:31 --> Security Class Initialized
DEBUG - 2021-08-18 13:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 13:51:31 --> Input Class Initialized
INFO - 2021-08-18 13:51:31 --> Language Class Initialized
INFO - 2021-08-18 13:51:31 --> Loader Class Initialized
INFO - 2021-08-18 13:51:31 --> Helper loaded: url_helper
INFO - 2021-08-18 13:51:31 --> Helper loaded: file_helper
DEBUG - 2021-08-18 13:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 13:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 13:51:31 --> Controller Class Initialized
INFO - 2021-08-18 13:51:31 --> Helper loaded: cookie_helper
INFO - 2021-08-18 13:51:31 --> Model "CookieModel" initialized
INFO - 2021-08-18 13:51:31 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 13:51:31 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-18 13:51:31 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 13:51:31 --> Final output sent to browser
DEBUG - 2021-08-18 13:51:31 --> Total execution time: 0.0451
INFO - 2021-08-18 13:51:33 --> Config Class Initialized
INFO - 2021-08-18 13:51:33 --> Hooks Class Initialized
DEBUG - 2021-08-18 13:51:33 --> UTF-8 Support Enabled
INFO - 2021-08-18 13:51:33 --> Utf8 Class Initialized
INFO - 2021-08-18 13:51:33 --> URI Class Initialized
INFO - 2021-08-18 13:51:33 --> Router Class Initialized
INFO - 2021-08-18 13:51:33 --> Output Class Initialized
INFO - 2021-08-18 13:51:33 --> Security Class Initialized
DEBUG - 2021-08-18 13:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 13:51:33 --> Input Class Initialized
INFO - 2021-08-18 13:51:33 --> Language Class Initialized
INFO - 2021-08-18 13:51:33 --> Loader Class Initialized
INFO - 2021-08-18 13:51:33 --> Helper loaded: url_helper
INFO - 2021-08-18 13:51:33 --> Helper loaded: file_helper
DEBUG - 2021-08-18 13:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 13:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 13:51:33 --> Controller Class Initialized
INFO - 2021-08-18 13:51:33 --> Helper loaded: cookie_helper
INFO - 2021-08-18 13:51:33 --> Model "CookieModel" initialized
INFO - 2021-08-18 13:51:33 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 13:51:33 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/pilates.php
INFO - 2021-08-18 13:51:33 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 13:51:33 --> Final output sent to browser
DEBUG - 2021-08-18 13:51:33 --> Total execution time: 0.0455
INFO - 2021-08-18 13:51:34 --> Config Class Initialized
INFO - 2021-08-18 13:51:34 --> Hooks Class Initialized
DEBUG - 2021-08-18 13:51:34 --> UTF-8 Support Enabled
INFO - 2021-08-18 13:51:34 --> Utf8 Class Initialized
INFO - 2021-08-18 13:51:34 --> URI Class Initialized
DEBUG - 2021-08-18 13:51:34 --> No URI present. Default controller set.
INFO - 2021-08-18 13:51:34 --> Router Class Initialized
INFO - 2021-08-18 13:51:34 --> Output Class Initialized
INFO - 2021-08-18 13:51:34 --> Security Class Initialized
DEBUG - 2021-08-18 13:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 13:51:34 --> Input Class Initialized
INFO - 2021-08-18 13:51:34 --> Language Class Initialized
INFO - 2021-08-18 13:51:34 --> Loader Class Initialized
INFO - 2021-08-18 13:51:34 --> Helper loaded: url_helper
INFO - 2021-08-18 13:51:34 --> Helper loaded: file_helper
DEBUG - 2021-08-18 13:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 13:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 13:51:34 --> Controller Class Initialized
INFO - 2021-08-18 13:51:34 --> Helper loaded: cookie_helper
INFO - 2021-08-18 13:51:34 --> Model "CookieModel" initialized
INFO - 2021-08-18 13:51:34 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 13:51:34 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-18 13:51:34 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 13:51:34 --> Final output sent to browser
DEBUG - 2021-08-18 13:51:34 --> Total execution time: 0.0326
INFO - 2021-08-18 13:52:33 --> Config Class Initialized
INFO - 2021-08-18 13:52:33 --> Hooks Class Initialized
DEBUG - 2021-08-18 13:52:33 --> UTF-8 Support Enabled
INFO - 2021-08-18 13:52:33 --> Utf8 Class Initialized
INFO - 2021-08-18 13:52:33 --> URI Class Initialized
DEBUG - 2021-08-18 13:52:33 --> No URI present. Default controller set.
INFO - 2021-08-18 13:52:33 --> Router Class Initialized
INFO - 2021-08-18 13:52:33 --> Output Class Initialized
INFO - 2021-08-18 13:52:33 --> Security Class Initialized
DEBUG - 2021-08-18 13:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 13:52:33 --> Input Class Initialized
INFO - 2021-08-18 13:52:33 --> Language Class Initialized
INFO - 2021-08-18 13:52:33 --> Loader Class Initialized
INFO - 2021-08-18 13:52:33 --> Helper loaded: url_helper
INFO - 2021-08-18 13:52:33 --> Helper loaded: file_helper
DEBUG - 2021-08-18 13:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 13:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 13:52:33 --> Controller Class Initialized
INFO - 2021-08-18 13:52:33 --> Helper loaded: cookie_helper
INFO - 2021-08-18 13:52:33 --> Model "CookieModel" initialized
INFO - 2021-08-18 13:52:33 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 13:52:33 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-18 13:52:33 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 13:52:33 --> Final output sent to browser
DEBUG - 2021-08-18 13:52:33 --> Total execution time: 0.0459
INFO - 2021-08-18 13:52:43 --> Config Class Initialized
INFO - 2021-08-18 13:52:43 --> Hooks Class Initialized
DEBUG - 2021-08-18 13:52:43 --> UTF-8 Support Enabled
INFO - 2021-08-18 13:52:43 --> Utf8 Class Initialized
INFO - 2021-08-18 13:52:43 --> URI Class Initialized
DEBUG - 2021-08-18 13:52:43 --> No URI present. Default controller set.
INFO - 2021-08-18 13:52:43 --> Router Class Initialized
INFO - 2021-08-18 13:52:43 --> Output Class Initialized
INFO - 2021-08-18 13:52:43 --> Security Class Initialized
DEBUG - 2021-08-18 13:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 13:52:43 --> Input Class Initialized
INFO - 2021-08-18 13:52:43 --> Language Class Initialized
INFO - 2021-08-18 13:52:43 --> Loader Class Initialized
INFO - 2021-08-18 13:52:43 --> Helper loaded: url_helper
INFO - 2021-08-18 13:52:43 --> Helper loaded: file_helper
DEBUG - 2021-08-18 13:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 13:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 13:52:43 --> Controller Class Initialized
INFO - 2021-08-18 13:52:43 --> Helper loaded: cookie_helper
INFO - 2021-08-18 13:52:43 --> Model "CookieModel" initialized
INFO - 2021-08-18 13:52:43 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 13:52:43 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-18 13:52:43 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 13:52:43 --> Final output sent to browser
DEBUG - 2021-08-18 13:52:43 --> Total execution time: 0.0576
INFO - 2021-08-18 13:52:55 --> Config Class Initialized
INFO - 2021-08-18 13:52:55 --> Hooks Class Initialized
DEBUG - 2021-08-18 13:52:55 --> UTF-8 Support Enabled
INFO - 2021-08-18 13:52:55 --> Utf8 Class Initialized
INFO - 2021-08-18 13:52:55 --> URI Class Initialized
DEBUG - 2021-08-18 13:52:55 --> No URI present. Default controller set.
INFO - 2021-08-18 13:52:55 --> Router Class Initialized
INFO - 2021-08-18 13:52:55 --> Output Class Initialized
INFO - 2021-08-18 13:52:55 --> Security Class Initialized
DEBUG - 2021-08-18 13:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-18 13:52:55 --> Input Class Initialized
INFO - 2021-08-18 13:52:55 --> Language Class Initialized
INFO - 2021-08-18 13:52:55 --> Loader Class Initialized
INFO - 2021-08-18 13:52:55 --> Helper loaded: url_helper
INFO - 2021-08-18 13:52:55 --> Helper loaded: file_helper
DEBUG - 2021-08-18 13:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-18 13:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-18 13:52:55 --> Controller Class Initialized
INFO - 2021-08-18 13:52:55 --> Helper loaded: cookie_helper
INFO - 2021-08-18 13:52:55 --> Model "CookieModel" initialized
INFO - 2021-08-18 13:52:55 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-08-18 13:52:55 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-08-18 13:52:55 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-08-18 13:52:55 --> Final output sent to browser
DEBUG - 2021-08-18 13:52:55 --> Total execution time: 0.0357
