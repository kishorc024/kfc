<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-08-06 07:31:00 --> Config Class Initialized
INFO - 2021-08-06 07:31:00 --> Hooks Class Initialized
DEBUG - 2021-08-06 07:31:00 --> UTF-8 Support Enabled
INFO - 2021-08-06 07:31:00 --> Utf8 Class Initialized
INFO - 2021-08-06 07:31:00 --> URI Class Initialized
DEBUG - 2021-08-06 07:31:00 --> No URI present. Default controller set.
INFO - 2021-08-06 07:31:00 --> Router Class Initialized
INFO - 2021-08-06 07:31:00 --> Output Class Initialized
INFO - 2021-08-06 07:31:00 --> Security Class Initialized
DEBUG - 2021-08-06 07:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 07:31:00 --> Input Class Initialized
INFO - 2021-08-06 07:31:00 --> Language Class Initialized
INFO - 2021-08-06 07:31:00 --> Loader Class Initialized
INFO - 2021-08-06 07:31:00 --> Helper loaded: url_helper
INFO - 2021-08-06 07:31:00 --> Helper loaded: file_helper
INFO - 2021-08-06 07:31:00 --> Database Driver Class Initialized
DEBUG - 2021-08-06 07:31:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 07:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 07:31:00 --> Controller Class Initialized
INFO - 2021-08-06 07:31:00 --> Helper loaded: cookie_helper
INFO - 2021-08-06 07:31:00 --> Model "CookieModel" initialized
INFO - 2021-08-06 07:31:00 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 07:31:00 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-06 07:31:00 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 07:31:00 --> Final output sent to browser
DEBUG - 2021-08-06 07:31:00 --> Total execution time: 0.2226
INFO - 2021-08-06 07:31:02 --> Config Class Initialized
INFO - 2021-08-06 07:31:02 --> Hooks Class Initialized
DEBUG - 2021-08-06 07:31:02 --> UTF-8 Support Enabled
INFO - 2021-08-06 07:31:02 --> Utf8 Class Initialized
INFO - 2021-08-06 07:31:02 --> URI Class Initialized
INFO - 2021-08-06 07:31:02 --> Router Class Initialized
INFO - 2021-08-06 07:31:02 --> Output Class Initialized
INFO - 2021-08-06 07:31:02 --> Security Class Initialized
DEBUG - 2021-08-06 07:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 07:31:02 --> Input Class Initialized
INFO - 2021-08-06 07:31:02 --> Language Class Initialized
INFO - 2021-08-06 07:31:02 --> Loader Class Initialized
INFO - 2021-08-06 07:31:02 --> Helper loaded: url_helper
INFO - 2021-08-06 07:31:02 --> Helper loaded: file_helper
INFO - 2021-08-06 07:31:02 --> Database Driver Class Initialized
DEBUG - 2021-08-06 07:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 07:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 07:31:02 --> Controller Class Initialized
INFO - 2021-08-06 07:31:02 --> Helper loaded: cookie_helper
INFO - 2021-08-06 07:31:02 --> Model "CookieModel" initialized
INFO - 2021-08-06 07:31:02 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 07:31:02 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-06 07:31:02 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 07:31:02 --> Final output sent to browser
DEBUG - 2021-08-06 07:31:02 --> Total execution time: 0.1485
INFO - 2021-08-06 07:31:34 --> Config Class Initialized
INFO - 2021-08-06 07:31:34 --> Hooks Class Initialized
DEBUG - 2021-08-06 07:31:34 --> UTF-8 Support Enabled
INFO - 2021-08-06 07:31:34 --> Utf8 Class Initialized
INFO - 2021-08-06 07:31:34 --> URI Class Initialized
INFO - 2021-08-06 07:31:34 --> Router Class Initialized
INFO - 2021-08-06 07:31:34 --> Output Class Initialized
INFO - 2021-08-06 07:31:34 --> Security Class Initialized
DEBUG - 2021-08-06 07:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 07:31:34 --> Input Class Initialized
INFO - 2021-08-06 07:31:34 --> Language Class Initialized
INFO - 2021-08-06 07:31:34 --> Loader Class Initialized
INFO - 2021-08-06 07:31:34 --> Helper loaded: url_helper
INFO - 2021-08-06 07:31:34 --> Helper loaded: file_helper
INFO - 2021-08-06 07:31:34 --> Database Driver Class Initialized
DEBUG - 2021-08-06 07:31:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 07:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 07:31:34 --> Controller Class Initialized
INFO - 2021-08-06 07:31:34 --> Helper loaded: cookie_helper
INFO - 2021-08-06 07:31:34 --> Model "CookieModel" initialized
INFO - 2021-08-06 07:31:34 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 07:31:34 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-06 07:31:34 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 07:31:34 --> Final output sent to browser
DEBUG - 2021-08-06 07:31:34 --> Total execution time: 0.0911
INFO - 2021-08-06 07:31:37 --> Config Class Initialized
INFO - 2021-08-06 07:31:37 --> Hooks Class Initialized
DEBUG - 2021-08-06 07:31:37 --> UTF-8 Support Enabled
INFO - 2021-08-06 07:31:37 --> Utf8 Class Initialized
INFO - 2021-08-06 07:31:37 --> URI Class Initialized
INFO - 2021-08-06 07:31:37 --> Router Class Initialized
INFO - 2021-08-06 07:31:37 --> Output Class Initialized
INFO - 2021-08-06 07:31:37 --> Security Class Initialized
DEBUG - 2021-08-06 07:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 07:31:37 --> Input Class Initialized
INFO - 2021-08-06 07:31:37 --> Language Class Initialized
INFO - 2021-08-06 07:31:37 --> Loader Class Initialized
INFO - 2021-08-06 07:31:37 --> Helper loaded: url_helper
INFO - 2021-08-06 07:31:37 --> Helper loaded: file_helper
INFO - 2021-08-06 07:31:37 --> Database Driver Class Initialized
DEBUG - 2021-08-06 07:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 07:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 07:31:37 --> Controller Class Initialized
INFO - 2021-08-06 07:31:37 --> Helper loaded: cookie_helper
INFO - 2021-08-06 07:31:37 --> Model "CookieModel" initialized
INFO - 2021-08-06 07:31:37 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 07:31:37 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-06 07:31:37 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 07:31:37 --> Final output sent to browser
DEBUG - 2021-08-06 07:31:37 --> Total execution time: 0.0530
INFO - 2021-08-06 07:41:24 --> Config Class Initialized
INFO - 2021-08-06 07:41:24 --> Hooks Class Initialized
DEBUG - 2021-08-06 07:41:24 --> UTF-8 Support Enabled
INFO - 2021-08-06 07:41:24 --> Utf8 Class Initialized
INFO - 2021-08-06 07:41:24 --> URI Class Initialized
INFO - 2021-08-06 07:41:24 --> Router Class Initialized
INFO - 2021-08-06 07:41:24 --> Output Class Initialized
INFO - 2021-08-06 07:41:25 --> Security Class Initialized
DEBUG - 2021-08-06 07:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 07:41:25 --> Input Class Initialized
INFO - 2021-08-06 07:41:25 --> Language Class Initialized
INFO - 2021-08-06 07:41:25 --> Loader Class Initialized
INFO - 2021-08-06 07:41:25 --> Helper loaded: url_helper
INFO - 2021-08-06 07:41:25 --> Helper loaded: file_helper
INFO - 2021-08-06 07:41:25 --> Database Driver Class Initialized
DEBUG - 2021-08-06 07:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 07:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 07:41:25 --> Controller Class Initialized
INFO - 2021-08-06 07:41:25 --> Helper loaded: cookie_helper
INFO - 2021-08-06 07:41:25 --> Model "CookieModel" initialized
INFO - 2021-08-06 07:41:25 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 07:41:25 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-06 07:41:25 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 07:41:25 --> Final output sent to browser
DEBUG - 2021-08-06 07:41:25 --> Total execution time: 0.9058
INFO - 2021-08-06 07:43:19 --> Config Class Initialized
INFO - 2021-08-06 07:43:19 --> Hooks Class Initialized
DEBUG - 2021-08-06 07:43:19 --> UTF-8 Support Enabled
INFO - 2021-08-06 07:43:19 --> Utf8 Class Initialized
INFO - 2021-08-06 07:43:19 --> URI Class Initialized
INFO - 2021-08-06 07:43:19 --> Router Class Initialized
INFO - 2021-08-06 07:43:19 --> Output Class Initialized
INFO - 2021-08-06 07:43:19 --> Security Class Initialized
DEBUG - 2021-08-06 07:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 07:43:19 --> Input Class Initialized
INFO - 2021-08-06 07:43:19 --> Language Class Initialized
INFO - 2021-08-06 07:43:19 --> Loader Class Initialized
INFO - 2021-08-06 07:43:19 --> Helper loaded: url_helper
INFO - 2021-08-06 07:43:19 --> Helper loaded: file_helper
INFO - 2021-08-06 07:43:19 --> Database Driver Class Initialized
DEBUG - 2021-08-06 07:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 07:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 07:43:19 --> Controller Class Initialized
INFO - 2021-08-06 07:43:19 --> Helper loaded: cookie_helper
INFO - 2021-08-06 07:43:19 --> Model "CookieModel" initialized
INFO - 2021-08-06 07:43:19 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 07:43:19 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-06 07:43:19 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 07:43:19 --> Final output sent to browser
DEBUG - 2021-08-06 07:43:19 --> Total execution time: 0.0639
INFO - 2021-08-06 08:03:58 --> Config Class Initialized
INFO - 2021-08-06 08:03:58 --> Hooks Class Initialized
DEBUG - 2021-08-06 08:03:58 --> UTF-8 Support Enabled
INFO - 2021-08-06 08:03:58 --> Utf8 Class Initialized
INFO - 2021-08-06 08:03:58 --> URI Class Initialized
INFO - 2021-08-06 08:03:58 --> Router Class Initialized
INFO - 2021-08-06 08:03:58 --> Output Class Initialized
INFO - 2021-08-06 08:03:58 --> Security Class Initialized
DEBUG - 2021-08-06 08:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 08:03:58 --> Input Class Initialized
INFO - 2021-08-06 08:03:58 --> Language Class Initialized
INFO - 2021-08-06 08:03:58 --> Loader Class Initialized
INFO - 2021-08-06 08:03:58 --> Helper loaded: url_helper
INFO - 2021-08-06 08:03:58 --> Helper loaded: file_helper
INFO - 2021-08-06 08:03:58 --> Database Driver Class Initialized
DEBUG - 2021-08-06 08:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 08:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 08:03:58 --> Controller Class Initialized
INFO - 2021-08-06 08:03:58 --> Helper loaded: cookie_helper
INFO - 2021-08-06 08:03:58 --> Model "CookieModel" initialized
INFO - 2021-08-06 08:03:58 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 08:03:58 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-06 08:03:58 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 08:03:58 --> Final output sent to browser
DEBUG - 2021-08-06 08:03:58 --> Total execution time: 0.1432
INFO - 2021-08-06 08:04:03 --> Config Class Initialized
INFO - 2021-08-06 08:04:03 --> Hooks Class Initialized
DEBUG - 2021-08-06 08:04:03 --> UTF-8 Support Enabled
INFO - 2021-08-06 08:04:03 --> Utf8 Class Initialized
INFO - 2021-08-06 08:04:03 --> URI Class Initialized
INFO - 2021-08-06 08:04:03 --> Router Class Initialized
INFO - 2021-08-06 08:04:03 --> Config Class Initialized
INFO - 2021-08-06 08:04:03 --> Output Class Initialized
INFO - 2021-08-06 08:04:03 --> Hooks Class Initialized
INFO - 2021-08-06 08:04:03 --> Security Class Initialized
DEBUG - 2021-08-06 08:04:03 --> UTF-8 Support Enabled
INFO - 2021-08-06 08:04:03 --> Utf8 Class Initialized
INFO - 2021-08-06 08:04:03 --> Config Class Initialized
INFO - 2021-08-06 08:04:03 --> Hooks Class Initialized
INFO - 2021-08-06 08:04:03 --> URI Class Initialized
INFO - 2021-08-06 08:04:03 --> Router Class Initialized
DEBUG - 2021-08-06 08:04:03 --> UTF-8 Support Enabled
INFO - 2021-08-06 08:04:03 --> Utf8 Class Initialized
INFO - 2021-08-06 08:04:03 --> Output Class Initialized
INFO - 2021-08-06 08:04:03 --> URI Class Initialized
INFO - 2021-08-06 08:04:03 --> Security Class Initialized
DEBUG - 2021-08-06 08:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 08:04:03 --> Input Class Initialized
INFO - 2021-08-06 08:04:03 --> Language Class Initialized
DEBUG - 2021-08-06 08:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 08:04:03 --> Router Class Initialized
INFO - 2021-08-06 08:04:03 --> Input Class Initialized
INFO - 2021-08-06 08:04:03 --> Output Class Initialized
INFO - 2021-08-06 08:04:03 --> Language Class Initialized
INFO - 2021-08-06 08:04:03 --> Security Class Initialized
DEBUG - 2021-08-06 08:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 08:04:03 --> Input Class Initialized
INFO - 2021-08-06 08:04:03 --> Language Class Initialized
ERROR - 2021-08-06 08:04:04 --> 404 Page Not Found: Assets/js
ERROR - 2021-08-06 08:04:04 --> 404 Page Not Found: Assets/js
ERROR - 2021-08-06 08:04:04 --> 404 Page Not Found: Assets/js
INFO - 2021-08-06 08:04:04 --> Config Class Initialized
INFO - 2021-08-06 08:04:04 --> Hooks Class Initialized
INFO - 2021-08-06 08:04:04 --> Config Class Initialized
INFO - 2021-08-06 08:04:04 --> Hooks Class Initialized
DEBUG - 2021-08-06 08:04:04 --> UTF-8 Support Enabled
INFO - 2021-08-06 08:04:04 --> Utf8 Class Initialized
INFO - 2021-08-06 08:04:04 --> URI Class Initialized
INFO - 2021-08-06 08:04:04 --> Router Class Initialized
DEBUG - 2021-08-06 08:04:04 --> UTF-8 Support Enabled
INFO - 2021-08-06 08:04:04 --> Utf8 Class Initialized
INFO - 2021-08-06 08:04:04 --> Output Class Initialized
INFO - 2021-08-06 08:04:04 --> URI Class Initialized
INFO - 2021-08-06 08:04:04 --> Security Class Initialized
DEBUG - 2021-08-06 08:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 08:04:04 --> Input Class Initialized
INFO - 2021-08-06 08:04:04 --> Language Class Initialized
ERROR - 2021-08-06 08:04:04 --> 404 Page Not Found: Assets/css
INFO - 2021-08-06 08:04:04 --> Router Class Initialized
INFO - 2021-08-06 08:04:04 --> Output Class Initialized
INFO - 2021-08-06 08:04:04 --> Security Class Initialized
DEBUG - 2021-08-06 08:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 08:04:04 --> Input Class Initialized
INFO - 2021-08-06 08:04:04 --> Language Class Initialized
ERROR - 2021-08-06 08:04:04 --> 404 Page Not Found: Assets/css
INFO - 2021-08-06 08:04:34 --> Config Class Initialized
INFO - 2021-08-06 08:04:34 --> Hooks Class Initialized
DEBUG - 2021-08-06 08:04:34 --> UTF-8 Support Enabled
INFO - 2021-08-06 08:04:34 --> Utf8 Class Initialized
INFO - 2021-08-06 08:04:34 --> URI Class Initialized
INFO - 2021-08-06 08:04:34 --> Router Class Initialized
INFO - 2021-08-06 08:04:34 --> Output Class Initialized
INFO - 2021-08-06 08:04:34 --> Security Class Initialized
DEBUG - 2021-08-06 08:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 08:04:34 --> Input Class Initialized
INFO - 2021-08-06 08:04:34 --> Language Class Initialized
INFO - 2021-08-06 08:04:34 --> Loader Class Initialized
INFO - 2021-08-06 08:04:34 --> Helper loaded: url_helper
INFO - 2021-08-06 08:04:34 --> Helper loaded: file_helper
INFO - 2021-08-06 08:04:34 --> Database Driver Class Initialized
DEBUG - 2021-08-06 08:04:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 08:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 08:04:34 --> Controller Class Initialized
INFO - 2021-08-06 08:04:34 --> Helper loaded: cookie_helper
INFO - 2021-08-06 08:04:34 --> Model "CookieModel" initialized
INFO - 2021-08-06 08:04:34 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 08:04:34 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-06 08:04:34 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 08:04:34 --> Final output sent to browser
DEBUG - 2021-08-06 08:04:34 --> Total execution time: 0.0701
INFO - 2021-08-06 08:04:35 --> Config Class Initialized
INFO - 2021-08-06 08:04:35 --> Hooks Class Initialized
DEBUG - 2021-08-06 08:04:35 --> UTF-8 Support Enabled
INFO - 2021-08-06 08:04:35 --> Utf8 Class Initialized
INFO - 2021-08-06 08:04:35 --> URI Class Initialized
INFO - 2021-08-06 08:04:35 --> Router Class Initialized
INFO - 2021-08-06 08:04:35 --> Output Class Initialized
INFO - 2021-08-06 08:04:35 --> Security Class Initialized
DEBUG - 2021-08-06 08:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 08:04:35 --> Input Class Initialized
INFO - 2021-08-06 08:04:35 --> Language Class Initialized
ERROR - 2021-08-06 08:04:35 --> 404 Page Not Found: Assets/css
INFO - 2021-08-06 08:04:35 --> Config Class Initialized
INFO - 2021-08-06 08:04:35 --> Hooks Class Initialized
DEBUG - 2021-08-06 08:04:35 --> UTF-8 Support Enabled
INFO - 2021-08-06 08:04:35 --> Utf8 Class Initialized
INFO - 2021-08-06 08:04:35 --> URI Class Initialized
INFO - 2021-08-06 08:04:35 --> Router Class Initialized
INFO - 2021-08-06 08:04:35 --> Output Class Initialized
INFO - 2021-08-06 08:04:35 --> Security Class Initialized
DEBUG - 2021-08-06 08:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 08:04:35 --> Input Class Initialized
INFO - 2021-08-06 08:04:35 --> Language Class Initialized
ERROR - 2021-08-06 08:04:35 --> 404 Page Not Found: Assets/css
INFO - 2021-08-06 08:04:35 --> Config Class Initialized
INFO - 2021-08-06 08:04:35 --> Hooks Class Initialized
DEBUG - 2021-08-06 08:04:35 --> UTF-8 Support Enabled
INFO - 2021-08-06 08:04:35 --> Utf8 Class Initialized
INFO - 2021-08-06 08:04:35 --> URI Class Initialized
INFO - 2021-08-06 08:04:35 --> Router Class Initialized
INFO - 2021-08-06 08:04:35 --> Output Class Initialized
INFO - 2021-08-06 08:04:35 --> Security Class Initialized
DEBUG - 2021-08-06 08:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 08:04:35 --> Input Class Initialized
INFO - 2021-08-06 08:04:35 --> Language Class Initialized
ERROR - 2021-08-06 08:04:35 --> 404 Page Not Found: Assets/js
INFO - 2021-08-06 08:04:35 --> Config Class Initialized
INFO - 2021-08-06 08:04:35 --> Hooks Class Initialized
DEBUG - 2021-08-06 08:04:35 --> UTF-8 Support Enabled
INFO - 2021-08-06 08:04:35 --> Utf8 Class Initialized
INFO - 2021-08-06 08:04:35 --> URI Class Initialized
INFO - 2021-08-06 08:04:35 --> Router Class Initialized
INFO - 2021-08-06 08:04:35 --> Output Class Initialized
INFO - 2021-08-06 08:04:35 --> Security Class Initialized
DEBUG - 2021-08-06 08:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 08:04:35 --> Input Class Initialized
INFO - 2021-08-06 08:04:35 --> Language Class Initialized
ERROR - 2021-08-06 08:04:35 --> 404 Page Not Found: Assets/js
INFO - 2021-08-06 08:04:36 --> Config Class Initialized
INFO - 2021-08-06 08:04:36 --> Hooks Class Initialized
DEBUG - 2021-08-06 08:04:36 --> UTF-8 Support Enabled
INFO - 2021-08-06 08:04:36 --> Utf8 Class Initialized
INFO - 2021-08-06 08:04:36 --> URI Class Initialized
INFO - 2021-08-06 08:04:36 --> Router Class Initialized
INFO - 2021-08-06 08:04:36 --> Output Class Initialized
INFO - 2021-08-06 08:04:36 --> Security Class Initialized
DEBUG - 2021-08-06 08:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 08:04:36 --> Input Class Initialized
INFO - 2021-08-06 08:04:36 --> Language Class Initialized
ERROR - 2021-08-06 08:04:36 --> 404 Page Not Found: Assets/js
INFO - 2021-08-06 08:12:07 --> Config Class Initialized
INFO - 2021-08-06 08:12:07 --> Hooks Class Initialized
DEBUG - 2021-08-06 08:12:07 --> UTF-8 Support Enabled
INFO - 2021-08-06 08:12:07 --> Utf8 Class Initialized
INFO - 2021-08-06 08:12:07 --> URI Class Initialized
INFO - 2021-08-06 08:12:07 --> Router Class Initialized
INFO - 2021-08-06 08:12:07 --> Output Class Initialized
INFO - 2021-08-06 08:12:07 --> Security Class Initialized
DEBUG - 2021-08-06 08:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 08:12:07 --> Input Class Initialized
INFO - 2021-08-06 08:12:07 --> Language Class Initialized
INFO - 2021-08-06 08:12:07 --> Loader Class Initialized
INFO - 2021-08-06 08:12:07 --> Helper loaded: url_helper
INFO - 2021-08-06 08:12:07 --> Helper loaded: file_helper
INFO - 2021-08-06 08:12:07 --> Database Driver Class Initialized
DEBUG - 2021-08-06 08:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 08:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 08:12:07 --> Controller Class Initialized
INFO - 2021-08-06 08:12:07 --> Helper loaded: cookie_helper
INFO - 2021-08-06 08:12:07 --> Model "CookieModel" initialized
INFO - 2021-08-06 08:12:07 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 08:12:07 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/services.php
INFO - 2021-08-06 08:12:07 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 08:12:07 --> Final output sent to browser
DEBUG - 2021-08-06 08:12:07 --> Total execution time: 0.2006
INFO - 2021-08-06 08:12:33 --> Config Class Initialized
INFO - 2021-08-06 08:12:33 --> Hooks Class Initialized
DEBUG - 2021-08-06 08:12:33 --> UTF-8 Support Enabled
INFO - 2021-08-06 08:12:33 --> Utf8 Class Initialized
INFO - 2021-08-06 08:12:33 --> URI Class Initialized
INFO - 2021-08-06 08:12:33 --> Router Class Initialized
INFO - 2021-08-06 08:12:33 --> Output Class Initialized
INFO - 2021-08-06 08:12:33 --> Security Class Initialized
DEBUG - 2021-08-06 08:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 08:12:33 --> Input Class Initialized
INFO - 2021-08-06 08:12:33 --> Language Class Initialized
INFO - 2021-08-06 08:12:33 --> Loader Class Initialized
INFO - 2021-08-06 08:12:33 --> Helper loaded: url_helper
INFO - 2021-08-06 08:12:33 --> Helper loaded: file_helper
INFO - 2021-08-06 08:12:33 --> Database Driver Class Initialized
DEBUG - 2021-08-06 08:12:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 08:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 08:12:33 --> Controller Class Initialized
INFO - 2021-08-06 08:12:33 --> Helper loaded: cookie_helper
INFO - 2021-08-06 08:12:33 --> Model "CookieModel" initialized
INFO - 2021-08-06 08:12:33 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 08:12:33 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/services.php
INFO - 2021-08-06 08:12:33 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 08:12:33 --> Final output sent to browser
DEBUG - 2021-08-06 08:12:33 --> Total execution time: 0.0700
INFO - 2021-08-06 08:12:37 --> Config Class Initialized
INFO - 2021-08-06 08:12:37 --> Hooks Class Initialized
DEBUG - 2021-08-06 08:12:37 --> UTF-8 Support Enabled
INFO - 2021-08-06 08:12:37 --> Utf8 Class Initialized
INFO - 2021-08-06 08:12:37 --> URI Class Initialized
INFO - 2021-08-06 08:12:37 --> Router Class Initialized
INFO - 2021-08-06 08:12:37 --> Output Class Initialized
INFO - 2021-08-06 08:12:37 --> Security Class Initialized
DEBUG - 2021-08-06 08:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 08:12:37 --> Input Class Initialized
INFO - 2021-08-06 08:12:37 --> Language Class Initialized
INFO - 2021-08-06 08:12:37 --> Loader Class Initialized
INFO - 2021-08-06 08:12:37 --> Helper loaded: url_helper
INFO - 2021-08-06 08:12:37 --> Helper loaded: file_helper
INFO - 2021-08-06 08:12:37 --> Database Driver Class Initialized
DEBUG - 2021-08-06 08:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 08:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 08:12:37 --> Controller Class Initialized
INFO - 2021-08-06 08:12:37 --> Helper loaded: cookie_helper
INFO - 2021-08-06 08:12:37 --> Model "CookieModel" initialized
INFO - 2021-08-06 08:12:37 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 08:12:37 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/services.php
INFO - 2021-08-06 08:12:37 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 08:12:37 --> Final output sent to browser
DEBUG - 2021-08-06 08:12:37 --> Total execution time: 0.0436
INFO - 2021-08-06 08:12:52 --> Config Class Initialized
INFO - 2021-08-06 08:12:52 --> Hooks Class Initialized
DEBUG - 2021-08-06 08:12:52 --> UTF-8 Support Enabled
INFO - 2021-08-06 08:12:52 --> Utf8 Class Initialized
INFO - 2021-08-06 08:12:52 --> URI Class Initialized
INFO - 2021-08-06 08:12:52 --> Router Class Initialized
INFO - 2021-08-06 08:12:52 --> Output Class Initialized
INFO - 2021-08-06 08:12:52 --> Security Class Initialized
DEBUG - 2021-08-06 08:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 08:12:52 --> Input Class Initialized
INFO - 2021-08-06 08:12:52 --> Language Class Initialized
INFO - 2021-08-06 08:12:52 --> Loader Class Initialized
INFO - 2021-08-06 08:12:52 --> Helper loaded: url_helper
INFO - 2021-08-06 08:12:52 --> Helper loaded: file_helper
INFO - 2021-08-06 08:12:52 --> Database Driver Class Initialized
DEBUG - 2021-08-06 08:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 08:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 08:12:52 --> Controller Class Initialized
INFO - 2021-08-06 08:12:52 --> Helper loaded: cookie_helper
INFO - 2021-08-06 08:12:52 --> Model "CookieModel" initialized
INFO - 2021-08-06 08:12:52 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 08:12:52 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/success_stories.php
INFO - 2021-08-06 08:12:52 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 08:12:52 --> Final output sent to browser
DEBUG - 2021-08-06 08:12:52 --> Total execution time: 0.0938
INFO - 2021-08-06 08:13:04 --> Config Class Initialized
INFO - 2021-08-06 08:13:04 --> Hooks Class Initialized
DEBUG - 2021-08-06 08:13:04 --> UTF-8 Support Enabled
INFO - 2021-08-06 08:13:04 --> Utf8 Class Initialized
INFO - 2021-08-06 08:13:04 --> URI Class Initialized
INFO - 2021-08-06 08:13:04 --> Router Class Initialized
INFO - 2021-08-06 08:13:04 --> Output Class Initialized
INFO - 2021-08-06 08:13:04 --> Security Class Initialized
DEBUG - 2021-08-06 08:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 08:13:04 --> Input Class Initialized
INFO - 2021-08-06 08:13:04 --> Language Class Initialized
INFO - 2021-08-06 08:13:04 --> Loader Class Initialized
INFO - 2021-08-06 08:13:04 --> Helper loaded: url_helper
INFO - 2021-08-06 08:13:04 --> Helper loaded: file_helper
INFO - 2021-08-06 08:13:04 --> Database Driver Class Initialized
DEBUG - 2021-08-06 08:13:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 08:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 08:13:04 --> Controller Class Initialized
INFO - 2021-08-06 08:13:04 --> Helper loaded: cookie_helper
INFO - 2021-08-06 08:13:04 --> Model "CookieModel" initialized
INFO - 2021-08-06 08:13:04 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 08:13:04 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/team.php
INFO - 2021-08-06 08:13:04 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 08:13:04 --> Final output sent to browser
DEBUG - 2021-08-06 08:13:04 --> Total execution time: 0.0731
INFO - 2021-08-06 08:13:18 --> Config Class Initialized
INFO - 2021-08-06 08:13:18 --> Hooks Class Initialized
DEBUG - 2021-08-06 08:13:18 --> UTF-8 Support Enabled
INFO - 2021-08-06 08:13:18 --> Utf8 Class Initialized
INFO - 2021-08-06 08:13:18 --> URI Class Initialized
INFO - 2021-08-06 08:13:18 --> Router Class Initialized
INFO - 2021-08-06 08:13:18 --> Output Class Initialized
INFO - 2021-08-06 08:13:18 --> Security Class Initialized
DEBUG - 2021-08-06 08:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 08:13:18 --> Input Class Initialized
INFO - 2021-08-06 08:13:18 --> Language Class Initialized
INFO - 2021-08-06 08:13:18 --> Loader Class Initialized
INFO - 2021-08-06 08:13:18 --> Helper loaded: url_helper
INFO - 2021-08-06 08:13:18 --> Helper loaded: file_helper
INFO - 2021-08-06 08:13:18 --> Database Driver Class Initialized
DEBUG - 2021-08-06 08:13:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 08:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 08:13:18 --> Controller Class Initialized
INFO - 2021-08-06 08:13:18 --> Helper loaded: cookie_helper
INFO - 2021-08-06 08:13:18 --> Model "CookieModel" initialized
INFO - 2021-08-06 08:13:18 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 08:13:18 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/team.php
INFO - 2021-08-06 08:13:18 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 08:13:18 --> Final output sent to browser
DEBUG - 2021-08-06 08:13:18 --> Total execution time: 0.0499
INFO - 2021-08-06 08:42:15 --> Config Class Initialized
INFO - 2021-08-06 08:42:15 --> Hooks Class Initialized
DEBUG - 2021-08-06 08:42:15 --> UTF-8 Support Enabled
INFO - 2021-08-06 08:42:15 --> Utf8 Class Initialized
INFO - 2021-08-06 08:42:15 --> URI Class Initialized
INFO - 2021-08-06 08:42:15 --> Router Class Initialized
INFO - 2021-08-06 08:42:15 --> Output Class Initialized
INFO - 2021-08-06 08:42:15 --> Security Class Initialized
DEBUG - 2021-08-06 08:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 08:42:15 --> Input Class Initialized
INFO - 2021-08-06 08:42:15 --> Language Class Initialized
INFO - 2021-08-06 08:42:15 --> Loader Class Initialized
INFO - 2021-08-06 08:42:15 --> Helper loaded: url_helper
INFO - 2021-08-06 08:42:15 --> Helper loaded: file_helper
INFO - 2021-08-06 08:42:15 --> Database Driver Class Initialized
DEBUG - 2021-08-06 08:42:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 08:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 08:42:15 --> Controller Class Initialized
INFO - 2021-08-06 08:42:15 --> Helper loaded: cookie_helper
INFO - 2021-08-06 08:42:15 --> Model "CookieModel" initialized
INFO - 2021-08-06 08:42:15 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 08:42:15 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/success_stories.php
INFO - 2021-08-06 08:42:15 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 08:42:15 --> Final output sent to browser
DEBUG - 2021-08-06 08:42:15 --> Total execution time: 0.1658
INFO - 2021-08-06 08:43:42 --> Config Class Initialized
INFO - 2021-08-06 08:43:42 --> Hooks Class Initialized
DEBUG - 2021-08-06 08:43:42 --> UTF-8 Support Enabled
INFO - 2021-08-06 08:43:42 --> Utf8 Class Initialized
INFO - 2021-08-06 08:43:42 --> URI Class Initialized
INFO - 2021-08-06 08:43:42 --> Router Class Initialized
INFO - 2021-08-06 08:43:42 --> Output Class Initialized
INFO - 2021-08-06 08:43:42 --> Security Class Initialized
DEBUG - 2021-08-06 08:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 08:43:42 --> Input Class Initialized
INFO - 2021-08-06 08:43:42 --> Language Class Initialized
INFO - 2021-08-06 08:43:42 --> Loader Class Initialized
INFO - 2021-08-06 08:43:42 --> Helper loaded: url_helper
INFO - 2021-08-06 08:43:42 --> Helper loaded: file_helper
INFO - 2021-08-06 08:43:42 --> Database Driver Class Initialized
DEBUG - 2021-08-06 08:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 08:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 08:43:42 --> Controller Class Initialized
INFO - 2021-08-06 08:43:42 --> Helper loaded: cookie_helper
INFO - 2021-08-06 08:43:42 --> Model "CookieModel" initialized
INFO - 2021-08-06 08:43:42 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 08:43:42 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/success_stories.php
INFO - 2021-08-06 08:43:42 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 08:43:42 --> Final output sent to browser
DEBUG - 2021-08-06 08:43:42 --> Total execution time: 0.0636
INFO - 2021-08-06 08:52:54 --> Config Class Initialized
INFO - 2021-08-06 08:52:54 --> Hooks Class Initialized
DEBUG - 2021-08-06 08:52:54 --> UTF-8 Support Enabled
INFO - 2021-08-06 08:52:54 --> Utf8 Class Initialized
INFO - 2021-08-06 08:52:54 --> URI Class Initialized
INFO - 2021-08-06 08:52:54 --> Router Class Initialized
INFO - 2021-08-06 08:52:54 --> Output Class Initialized
INFO - 2021-08-06 08:52:54 --> Security Class Initialized
DEBUG - 2021-08-06 08:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 08:52:54 --> Input Class Initialized
INFO - 2021-08-06 08:52:54 --> Language Class Initialized
INFO - 2021-08-06 08:52:54 --> Loader Class Initialized
INFO - 2021-08-06 08:52:54 --> Helper loaded: url_helper
INFO - 2021-08-06 08:52:54 --> Helper loaded: file_helper
INFO - 2021-08-06 08:52:54 --> Database Driver Class Initialized
DEBUG - 2021-08-06 08:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 08:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 08:52:54 --> Controller Class Initialized
INFO - 2021-08-06 08:52:54 --> Helper loaded: cookie_helper
INFO - 2021-08-06 08:52:54 --> Model "CookieModel" initialized
INFO - 2021-08-06 08:52:54 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 08:52:54 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/success_stories.php
INFO - 2021-08-06 08:52:54 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 08:52:54 --> Final output sent to browser
DEBUG - 2021-08-06 08:52:54 --> Total execution time: 0.1556
INFO - 2021-08-06 08:54:08 --> Config Class Initialized
INFO - 2021-08-06 08:54:08 --> Hooks Class Initialized
DEBUG - 2021-08-06 08:54:08 --> UTF-8 Support Enabled
INFO - 2021-08-06 08:54:08 --> Utf8 Class Initialized
INFO - 2021-08-06 08:54:08 --> URI Class Initialized
INFO - 2021-08-06 08:54:08 --> Router Class Initialized
INFO - 2021-08-06 08:54:08 --> Output Class Initialized
INFO - 2021-08-06 08:54:08 --> Security Class Initialized
DEBUG - 2021-08-06 08:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 08:54:08 --> Input Class Initialized
INFO - 2021-08-06 08:54:08 --> Language Class Initialized
INFO - 2021-08-06 08:54:08 --> Loader Class Initialized
INFO - 2021-08-06 08:54:09 --> Helper loaded: url_helper
INFO - 2021-08-06 08:54:09 --> Helper loaded: file_helper
INFO - 2021-08-06 08:54:09 --> Database Driver Class Initialized
DEBUG - 2021-08-06 08:54:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 08:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 08:54:09 --> Controller Class Initialized
INFO - 2021-08-06 08:54:09 --> Helper loaded: cookie_helper
INFO - 2021-08-06 08:54:09 --> Model "CookieModel" initialized
INFO - 2021-08-06 08:54:09 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 08:54:09 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/success_stories.php
INFO - 2021-08-06 08:54:09 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 08:54:09 --> Final output sent to browser
DEBUG - 2021-08-06 08:54:09 --> Total execution time: 0.0671
INFO - 2021-08-06 08:56:12 --> Config Class Initialized
INFO - 2021-08-06 08:56:12 --> Hooks Class Initialized
DEBUG - 2021-08-06 08:56:12 --> UTF-8 Support Enabled
INFO - 2021-08-06 08:56:12 --> Utf8 Class Initialized
INFO - 2021-08-06 08:56:12 --> URI Class Initialized
INFO - 2021-08-06 08:56:12 --> Router Class Initialized
INFO - 2021-08-06 08:56:12 --> Output Class Initialized
INFO - 2021-08-06 08:56:12 --> Security Class Initialized
DEBUG - 2021-08-06 08:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 08:56:12 --> Input Class Initialized
INFO - 2021-08-06 08:56:12 --> Language Class Initialized
INFO - 2021-08-06 08:56:12 --> Loader Class Initialized
INFO - 2021-08-06 08:56:12 --> Helper loaded: url_helper
INFO - 2021-08-06 08:56:12 --> Helper loaded: file_helper
INFO - 2021-08-06 08:56:12 --> Database Driver Class Initialized
DEBUG - 2021-08-06 08:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 08:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 08:56:12 --> Controller Class Initialized
INFO - 2021-08-06 08:56:12 --> Helper loaded: cookie_helper
INFO - 2021-08-06 08:56:12 --> Model "CookieModel" initialized
INFO - 2021-08-06 08:56:12 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 08:56:12 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/success_stories.php
INFO - 2021-08-06 08:56:12 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 08:56:12 --> Final output sent to browser
DEBUG - 2021-08-06 08:56:12 --> Total execution time: 0.0558
INFO - 2021-08-06 08:57:01 --> Config Class Initialized
INFO - 2021-08-06 08:57:01 --> Hooks Class Initialized
DEBUG - 2021-08-06 08:57:01 --> UTF-8 Support Enabled
INFO - 2021-08-06 08:57:01 --> Utf8 Class Initialized
INFO - 2021-08-06 08:57:01 --> URI Class Initialized
INFO - 2021-08-06 08:57:01 --> Router Class Initialized
INFO - 2021-08-06 08:57:01 --> Output Class Initialized
INFO - 2021-08-06 08:57:01 --> Security Class Initialized
DEBUG - 2021-08-06 08:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 08:57:01 --> Input Class Initialized
INFO - 2021-08-06 08:57:01 --> Language Class Initialized
INFO - 2021-08-06 08:57:01 --> Loader Class Initialized
INFO - 2021-08-06 08:57:01 --> Helper loaded: url_helper
INFO - 2021-08-06 08:57:01 --> Helper loaded: file_helper
INFO - 2021-08-06 08:57:01 --> Database Driver Class Initialized
DEBUG - 2021-08-06 08:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 08:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 08:57:01 --> Controller Class Initialized
INFO - 2021-08-06 08:57:01 --> Helper loaded: cookie_helper
INFO - 2021-08-06 08:57:01 --> Model "CookieModel" initialized
INFO - 2021-08-06 08:57:01 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 08:57:01 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/success_stories.php
INFO - 2021-08-06 08:57:01 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 08:57:01 --> Final output sent to browser
DEBUG - 2021-08-06 08:57:01 --> Total execution time: 0.0568
INFO - 2021-08-06 08:58:18 --> Config Class Initialized
INFO - 2021-08-06 08:58:18 --> Hooks Class Initialized
DEBUG - 2021-08-06 08:58:18 --> UTF-8 Support Enabled
INFO - 2021-08-06 08:58:18 --> Utf8 Class Initialized
INFO - 2021-08-06 08:58:18 --> URI Class Initialized
INFO - 2021-08-06 08:58:18 --> Router Class Initialized
INFO - 2021-08-06 08:58:18 --> Output Class Initialized
INFO - 2021-08-06 08:58:18 --> Security Class Initialized
DEBUG - 2021-08-06 08:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 08:58:18 --> Input Class Initialized
INFO - 2021-08-06 08:58:18 --> Language Class Initialized
INFO - 2021-08-06 08:58:18 --> Loader Class Initialized
INFO - 2021-08-06 08:58:18 --> Helper loaded: url_helper
INFO - 2021-08-06 08:58:18 --> Helper loaded: file_helper
INFO - 2021-08-06 08:58:18 --> Database Driver Class Initialized
DEBUG - 2021-08-06 08:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 08:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 08:58:18 --> Controller Class Initialized
INFO - 2021-08-06 08:58:18 --> Helper loaded: cookie_helper
INFO - 2021-08-06 08:58:18 --> Model "CookieModel" initialized
INFO - 2021-08-06 08:58:18 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 08:58:18 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/success_stories.php
INFO - 2021-08-06 08:58:18 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 08:58:18 --> Final output sent to browser
DEBUG - 2021-08-06 08:58:18 --> Total execution time: 0.0485
INFO - 2021-08-06 08:58:49 --> Config Class Initialized
INFO - 2021-08-06 08:58:49 --> Hooks Class Initialized
DEBUG - 2021-08-06 08:58:49 --> UTF-8 Support Enabled
INFO - 2021-08-06 08:58:49 --> Utf8 Class Initialized
INFO - 2021-08-06 08:58:49 --> URI Class Initialized
INFO - 2021-08-06 08:58:49 --> Router Class Initialized
INFO - 2021-08-06 08:58:49 --> Output Class Initialized
INFO - 2021-08-06 08:58:49 --> Security Class Initialized
DEBUG - 2021-08-06 08:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 08:58:49 --> Input Class Initialized
INFO - 2021-08-06 08:58:49 --> Language Class Initialized
INFO - 2021-08-06 08:58:49 --> Loader Class Initialized
INFO - 2021-08-06 08:58:49 --> Helper loaded: url_helper
INFO - 2021-08-06 08:58:49 --> Helper loaded: file_helper
INFO - 2021-08-06 08:58:49 --> Database Driver Class Initialized
DEBUG - 2021-08-06 08:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 08:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 08:58:49 --> Controller Class Initialized
INFO - 2021-08-06 08:58:49 --> Helper loaded: cookie_helper
INFO - 2021-08-06 08:58:49 --> Model "CookieModel" initialized
INFO - 2021-08-06 08:58:49 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 08:58:49 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/success_stories.php
INFO - 2021-08-06 08:58:49 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 08:58:49 --> Final output sent to browser
DEBUG - 2021-08-06 08:58:49 --> Total execution time: 0.0508
INFO - 2021-08-06 08:58:51 --> Config Class Initialized
INFO - 2021-08-06 08:58:51 --> Hooks Class Initialized
DEBUG - 2021-08-06 08:58:51 --> UTF-8 Support Enabled
INFO - 2021-08-06 08:58:51 --> Utf8 Class Initialized
INFO - 2021-08-06 08:58:51 --> URI Class Initialized
INFO - 2021-08-06 08:58:51 --> Router Class Initialized
INFO - 2021-08-06 08:58:51 --> Output Class Initialized
INFO - 2021-08-06 08:58:51 --> Security Class Initialized
DEBUG - 2021-08-06 08:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 08:58:51 --> Input Class Initialized
INFO - 2021-08-06 08:58:51 --> Language Class Initialized
INFO - 2021-08-06 08:58:51 --> Loader Class Initialized
INFO - 2021-08-06 08:58:51 --> Helper loaded: url_helper
INFO - 2021-08-06 08:58:51 --> Helper loaded: file_helper
INFO - 2021-08-06 08:58:51 --> Database Driver Class Initialized
DEBUG - 2021-08-06 08:58:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 08:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 08:58:51 --> Controller Class Initialized
INFO - 2021-08-06 08:58:51 --> Helper loaded: cookie_helper
INFO - 2021-08-06 08:58:51 --> Model "CookieModel" initialized
INFO - 2021-08-06 08:58:51 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 08:58:51 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/success_stories.php
INFO - 2021-08-06 08:58:51 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 08:58:51 --> Final output sent to browser
DEBUG - 2021-08-06 08:58:51 --> Total execution time: 0.0398
INFO - 2021-08-06 08:58:53 --> Config Class Initialized
INFO - 2021-08-06 08:58:53 --> Hooks Class Initialized
DEBUG - 2021-08-06 08:58:53 --> UTF-8 Support Enabled
INFO - 2021-08-06 08:58:53 --> Utf8 Class Initialized
INFO - 2021-08-06 08:58:53 --> URI Class Initialized
INFO - 2021-08-06 08:58:53 --> Router Class Initialized
INFO - 2021-08-06 08:58:53 --> Output Class Initialized
INFO - 2021-08-06 08:58:53 --> Security Class Initialized
DEBUG - 2021-08-06 08:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 08:58:53 --> Input Class Initialized
INFO - 2021-08-06 08:58:53 --> Language Class Initialized
INFO - 2021-08-06 08:58:53 --> Loader Class Initialized
INFO - 2021-08-06 08:58:53 --> Helper loaded: url_helper
INFO - 2021-08-06 08:58:53 --> Helper loaded: file_helper
INFO - 2021-08-06 08:58:53 --> Database Driver Class Initialized
DEBUG - 2021-08-06 08:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 08:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 08:58:53 --> Controller Class Initialized
INFO - 2021-08-06 08:58:53 --> Helper loaded: cookie_helper
INFO - 2021-08-06 08:58:53 --> Model "CookieModel" initialized
INFO - 2021-08-06 08:58:53 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 08:58:53 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/success_stories.php
INFO - 2021-08-06 08:58:53 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 08:58:53 --> Final output sent to browser
DEBUG - 2021-08-06 08:58:53 --> Total execution time: 0.0619
INFO - 2021-08-06 08:59:08 --> Config Class Initialized
INFO - 2021-08-06 08:59:08 --> Hooks Class Initialized
DEBUG - 2021-08-06 08:59:08 --> UTF-8 Support Enabled
INFO - 2021-08-06 08:59:08 --> Utf8 Class Initialized
INFO - 2021-08-06 08:59:08 --> URI Class Initialized
INFO - 2021-08-06 08:59:08 --> Router Class Initialized
INFO - 2021-08-06 08:59:08 --> Output Class Initialized
INFO - 2021-08-06 08:59:08 --> Security Class Initialized
DEBUG - 2021-08-06 08:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 08:59:08 --> Input Class Initialized
INFO - 2021-08-06 08:59:08 --> Language Class Initialized
INFO - 2021-08-06 08:59:08 --> Loader Class Initialized
INFO - 2021-08-06 08:59:08 --> Helper loaded: url_helper
INFO - 2021-08-06 08:59:08 --> Helper loaded: file_helper
INFO - 2021-08-06 08:59:08 --> Database Driver Class Initialized
DEBUG - 2021-08-06 08:59:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 08:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 08:59:08 --> Controller Class Initialized
INFO - 2021-08-06 08:59:08 --> Helper loaded: cookie_helper
INFO - 2021-08-06 08:59:08 --> Model "CookieModel" initialized
INFO - 2021-08-06 08:59:08 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 08:59:08 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/success_stories.php
INFO - 2021-08-06 08:59:08 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 08:59:08 --> Final output sent to browser
DEBUG - 2021-08-06 08:59:08 --> Total execution time: 0.0652
INFO - 2021-08-06 08:59:27 --> Config Class Initialized
INFO - 2021-08-06 08:59:27 --> Hooks Class Initialized
DEBUG - 2021-08-06 08:59:27 --> UTF-8 Support Enabled
INFO - 2021-08-06 08:59:27 --> Utf8 Class Initialized
INFO - 2021-08-06 08:59:27 --> URI Class Initialized
INFO - 2021-08-06 08:59:27 --> Router Class Initialized
INFO - 2021-08-06 08:59:27 --> Output Class Initialized
INFO - 2021-08-06 08:59:27 --> Security Class Initialized
DEBUG - 2021-08-06 08:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 08:59:27 --> Input Class Initialized
INFO - 2021-08-06 08:59:27 --> Language Class Initialized
INFO - 2021-08-06 08:59:27 --> Loader Class Initialized
INFO - 2021-08-06 08:59:27 --> Helper loaded: url_helper
INFO - 2021-08-06 08:59:27 --> Helper loaded: file_helper
INFO - 2021-08-06 08:59:27 --> Database Driver Class Initialized
DEBUG - 2021-08-06 08:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 08:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 08:59:27 --> Controller Class Initialized
INFO - 2021-08-06 08:59:27 --> Helper loaded: cookie_helper
INFO - 2021-08-06 08:59:27 --> Model "CookieModel" initialized
INFO - 2021-08-06 08:59:27 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 08:59:27 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/success_stories.php
INFO - 2021-08-06 08:59:27 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 08:59:27 --> Final output sent to browser
DEBUG - 2021-08-06 08:59:27 --> Total execution time: 0.0622
INFO - 2021-08-06 08:59:54 --> Config Class Initialized
INFO - 2021-08-06 08:59:54 --> Hooks Class Initialized
DEBUG - 2021-08-06 08:59:54 --> UTF-8 Support Enabled
INFO - 2021-08-06 08:59:54 --> Utf8 Class Initialized
INFO - 2021-08-06 08:59:54 --> URI Class Initialized
INFO - 2021-08-06 08:59:54 --> Router Class Initialized
INFO - 2021-08-06 08:59:54 --> Output Class Initialized
INFO - 2021-08-06 08:59:54 --> Security Class Initialized
DEBUG - 2021-08-06 08:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 08:59:54 --> Input Class Initialized
INFO - 2021-08-06 08:59:54 --> Language Class Initialized
INFO - 2021-08-06 08:59:54 --> Loader Class Initialized
INFO - 2021-08-06 08:59:54 --> Helper loaded: url_helper
INFO - 2021-08-06 08:59:54 --> Helper loaded: file_helper
INFO - 2021-08-06 08:59:54 --> Database Driver Class Initialized
DEBUG - 2021-08-06 08:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 08:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 08:59:54 --> Controller Class Initialized
INFO - 2021-08-06 08:59:54 --> Helper loaded: cookie_helper
INFO - 2021-08-06 08:59:54 --> Model "CookieModel" initialized
INFO - 2021-08-06 08:59:54 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 08:59:54 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/success_stories.php
INFO - 2021-08-06 08:59:54 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 08:59:54 --> Final output sent to browser
DEBUG - 2021-08-06 08:59:54 --> Total execution time: 0.0445
INFO - 2021-08-06 09:00:02 --> Config Class Initialized
INFO - 2021-08-06 09:00:02 --> Hooks Class Initialized
DEBUG - 2021-08-06 09:00:02 --> UTF-8 Support Enabled
INFO - 2021-08-06 09:00:02 --> Utf8 Class Initialized
INFO - 2021-08-06 09:00:02 --> URI Class Initialized
INFO - 2021-08-06 09:00:02 --> Router Class Initialized
INFO - 2021-08-06 09:00:02 --> Output Class Initialized
INFO - 2021-08-06 09:00:02 --> Security Class Initialized
DEBUG - 2021-08-06 09:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 09:00:02 --> Input Class Initialized
INFO - 2021-08-06 09:00:02 --> Language Class Initialized
INFO - 2021-08-06 09:00:02 --> Loader Class Initialized
INFO - 2021-08-06 09:00:02 --> Helper loaded: url_helper
INFO - 2021-08-06 09:00:02 --> Helper loaded: file_helper
INFO - 2021-08-06 09:00:02 --> Database Driver Class Initialized
DEBUG - 2021-08-06 09:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 09:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 09:00:02 --> Controller Class Initialized
INFO - 2021-08-06 09:00:02 --> Helper loaded: cookie_helper
INFO - 2021-08-06 09:00:02 --> Model "CookieModel" initialized
INFO - 2021-08-06 09:00:02 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 09:00:02 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/success_stories.php
INFO - 2021-08-06 09:00:02 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 09:00:02 --> Final output sent to browser
DEBUG - 2021-08-06 09:00:02 --> Total execution time: 0.0397
INFO - 2021-08-06 09:01:09 --> Config Class Initialized
INFO - 2021-08-06 09:01:09 --> Hooks Class Initialized
DEBUG - 2021-08-06 09:01:09 --> UTF-8 Support Enabled
INFO - 2021-08-06 09:01:09 --> Utf8 Class Initialized
INFO - 2021-08-06 09:01:09 --> URI Class Initialized
INFO - 2021-08-06 09:01:09 --> Router Class Initialized
INFO - 2021-08-06 09:01:09 --> Output Class Initialized
INFO - 2021-08-06 09:01:09 --> Security Class Initialized
DEBUG - 2021-08-06 09:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 09:01:09 --> Input Class Initialized
INFO - 2021-08-06 09:01:09 --> Language Class Initialized
INFO - 2021-08-06 09:01:09 --> Loader Class Initialized
INFO - 2021-08-06 09:01:09 --> Helper loaded: url_helper
INFO - 2021-08-06 09:01:09 --> Helper loaded: file_helper
INFO - 2021-08-06 09:01:09 --> Database Driver Class Initialized
DEBUG - 2021-08-06 09:01:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 09:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 09:01:09 --> Controller Class Initialized
INFO - 2021-08-06 09:01:09 --> Helper loaded: cookie_helper
INFO - 2021-08-06 09:01:09 --> Model "CookieModel" initialized
INFO - 2021-08-06 09:01:09 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 09:01:09 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/success_stories.php
INFO - 2021-08-06 09:01:09 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 09:01:09 --> Final output sent to browser
DEBUG - 2021-08-06 09:01:09 --> Total execution time: 0.0740
INFO - 2021-08-06 09:01:30 --> Config Class Initialized
INFO - 2021-08-06 09:01:30 --> Hooks Class Initialized
DEBUG - 2021-08-06 09:01:30 --> UTF-8 Support Enabled
INFO - 2021-08-06 09:01:30 --> Utf8 Class Initialized
INFO - 2021-08-06 09:01:30 --> URI Class Initialized
INFO - 2021-08-06 09:01:30 --> Router Class Initialized
INFO - 2021-08-06 09:01:30 --> Output Class Initialized
INFO - 2021-08-06 09:01:30 --> Security Class Initialized
DEBUG - 2021-08-06 09:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 09:01:30 --> Input Class Initialized
INFO - 2021-08-06 09:01:30 --> Language Class Initialized
INFO - 2021-08-06 09:01:30 --> Loader Class Initialized
INFO - 2021-08-06 09:01:30 --> Helper loaded: url_helper
INFO - 2021-08-06 09:01:30 --> Helper loaded: file_helper
INFO - 2021-08-06 09:01:30 --> Database Driver Class Initialized
DEBUG - 2021-08-06 09:01:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 09:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 09:01:30 --> Controller Class Initialized
INFO - 2021-08-06 09:01:30 --> Helper loaded: cookie_helper
INFO - 2021-08-06 09:01:30 --> Model "CookieModel" initialized
INFO - 2021-08-06 09:01:30 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 09:01:30 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/success_stories.php
INFO - 2021-08-06 09:01:30 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 09:01:30 --> Final output sent to browser
DEBUG - 2021-08-06 09:01:30 --> Total execution time: 0.0458
INFO - 2021-08-06 09:03:14 --> Config Class Initialized
INFO - 2021-08-06 09:03:14 --> Hooks Class Initialized
DEBUG - 2021-08-06 09:03:14 --> UTF-8 Support Enabled
INFO - 2021-08-06 09:03:14 --> Utf8 Class Initialized
INFO - 2021-08-06 09:03:14 --> URI Class Initialized
INFO - 2021-08-06 09:03:14 --> Router Class Initialized
INFO - 2021-08-06 09:03:14 --> Output Class Initialized
INFO - 2021-08-06 09:03:14 --> Security Class Initialized
DEBUG - 2021-08-06 09:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 09:03:14 --> Input Class Initialized
INFO - 2021-08-06 09:03:14 --> Language Class Initialized
INFO - 2021-08-06 09:03:14 --> Loader Class Initialized
INFO - 2021-08-06 09:03:14 --> Helper loaded: url_helper
INFO - 2021-08-06 09:03:14 --> Helper loaded: file_helper
INFO - 2021-08-06 09:03:14 --> Database Driver Class Initialized
DEBUG - 2021-08-06 09:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 09:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 09:03:14 --> Controller Class Initialized
INFO - 2021-08-06 09:03:14 --> Helper loaded: cookie_helper
INFO - 2021-08-06 09:03:14 --> Model "CookieModel" initialized
INFO - 2021-08-06 09:03:14 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 09:03:14 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/success_stories.php
INFO - 2021-08-06 09:03:14 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 09:03:14 --> Final output sent to browser
DEBUG - 2021-08-06 09:03:14 --> Total execution time: 0.0955
INFO - 2021-08-06 09:04:17 --> Config Class Initialized
INFO - 2021-08-06 09:04:17 --> Hooks Class Initialized
DEBUG - 2021-08-06 09:04:17 --> UTF-8 Support Enabled
INFO - 2021-08-06 09:04:17 --> Utf8 Class Initialized
INFO - 2021-08-06 09:04:17 --> URI Class Initialized
INFO - 2021-08-06 09:04:17 --> Router Class Initialized
INFO - 2021-08-06 09:04:17 --> Output Class Initialized
INFO - 2021-08-06 09:04:17 --> Security Class Initialized
DEBUG - 2021-08-06 09:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 09:04:17 --> Input Class Initialized
INFO - 2021-08-06 09:04:17 --> Language Class Initialized
INFO - 2021-08-06 09:04:17 --> Loader Class Initialized
INFO - 2021-08-06 09:04:17 --> Helper loaded: url_helper
INFO - 2021-08-06 09:04:17 --> Helper loaded: file_helper
INFO - 2021-08-06 09:04:17 --> Database Driver Class Initialized
DEBUG - 2021-08-06 09:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 09:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 09:04:17 --> Controller Class Initialized
INFO - 2021-08-06 09:04:17 --> Helper loaded: cookie_helper
INFO - 2021-08-06 09:04:17 --> Model "CookieModel" initialized
INFO - 2021-08-06 09:04:17 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 09:04:17 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/success_stories.php
INFO - 2021-08-06 09:04:17 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 09:04:17 --> Final output sent to browser
DEBUG - 2021-08-06 09:04:17 --> Total execution time: 0.0514
INFO - 2021-08-06 09:05:27 --> Config Class Initialized
INFO - 2021-08-06 09:05:27 --> Hooks Class Initialized
DEBUG - 2021-08-06 09:05:27 --> UTF-8 Support Enabled
INFO - 2021-08-06 09:05:27 --> Utf8 Class Initialized
INFO - 2021-08-06 09:05:27 --> URI Class Initialized
INFO - 2021-08-06 09:05:27 --> Router Class Initialized
INFO - 2021-08-06 09:05:27 --> Output Class Initialized
INFO - 2021-08-06 09:05:27 --> Security Class Initialized
DEBUG - 2021-08-06 09:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 09:05:27 --> Input Class Initialized
INFO - 2021-08-06 09:05:27 --> Language Class Initialized
INFO - 2021-08-06 09:05:27 --> Loader Class Initialized
INFO - 2021-08-06 09:05:27 --> Helper loaded: url_helper
INFO - 2021-08-06 09:05:27 --> Helper loaded: file_helper
INFO - 2021-08-06 09:05:27 --> Database Driver Class Initialized
DEBUG - 2021-08-06 09:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 09:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 09:05:27 --> Controller Class Initialized
INFO - 2021-08-06 09:05:27 --> Helper loaded: cookie_helper
INFO - 2021-08-06 09:05:27 --> Model "CookieModel" initialized
INFO - 2021-08-06 09:05:27 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 09:05:27 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/success_stories.php
INFO - 2021-08-06 09:05:27 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 09:05:27 --> Final output sent to browser
DEBUG - 2021-08-06 09:05:27 --> Total execution time: 0.0422
INFO - 2021-08-06 09:06:55 --> Config Class Initialized
INFO - 2021-08-06 09:06:55 --> Hooks Class Initialized
DEBUG - 2021-08-06 09:06:55 --> UTF-8 Support Enabled
INFO - 2021-08-06 09:06:55 --> Utf8 Class Initialized
INFO - 2021-08-06 09:06:55 --> URI Class Initialized
INFO - 2021-08-06 09:06:55 --> Router Class Initialized
INFO - 2021-08-06 09:06:55 --> Output Class Initialized
INFO - 2021-08-06 09:06:55 --> Security Class Initialized
DEBUG - 2021-08-06 09:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 09:06:55 --> Input Class Initialized
INFO - 2021-08-06 09:06:55 --> Language Class Initialized
INFO - 2021-08-06 09:06:55 --> Loader Class Initialized
INFO - 2021-08-06 09:06:55 --> Helper loaded: url_helper
INFO - 2021-08-06 09:06:55 --> Helper loaded: file_helper
INFO - 2021-08-06 09:06:55 --> Database Driver Class Initialized
DEBUG - 2021-08-06 09:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 09:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 09:06:55 --> Controller Class Initialized
INFO - 2021-08-06 09:06:55 --> Helper loaded: cookie_helper
INFO - 2021-08-06 09:06:55 --> Model "CookieModel" initialized
INFO - 2021-08-06 09:06:55 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 09:06:55 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/success_stories.php
INFO - 2021-08-06 09:06:55 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 09:06:55 --> Final output sent to browser
DEBUG - 2021-08-06 09:06:55 --> Total execution time: 0.0482
INFO - 2021-08-06 09:07:12 --> Config Class Initialized
INFO - 2021-08-06 09:07:12 --> Hooks Class Initialized
DEBUG - 2021-08-06 09:07:12 --> UTF-8 Support Enabled
INFO - 2021-08-06 09:07:12 --> Utf8 Class Initialized
INFO - 2021-08-06 09:07:12 --> URI Class Initialized
INFO - 2021-08-06 09:07:12 --> Router Class Initialized
INFO - 2021-08-06 09:07:12 --> Output Class Initialized
INFO - 2021-08-06 09:07:12 --> Security Class Initialized
DEBUG - 2021-08-06 09:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 09:07:12 --> Input Class Initialized
INFO - 2021-08-06 09:07:12 --> Language Class Initialized
INFO - 2021-08-06 09:07:12 --> Loader Class Initialized
INFO - 2021-08-06 09:07:12 --> Helper loaded: url_helper
INFO - 2021-08-06 09:07:12 --> Helper loaded: file_helper
INFO - 2021-08-06 09:07:12 --> Database Driver Class Initialized
DEBUG - 2021-08-06 09:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 09:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 09:07:12 --> Controller Class Initialized
INFO - 2021-08-06 09:07:12 --> Helper loaded: cookie_helper
INFO - 2021-08-06 09:07:12 --> Model "CookieModel" initialized
INFO - 2021-08-06 09:07:12 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 09:07:12 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/success_stories.php
INFO - 2021-08-06 09:07:12 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 09:07:12 --> Final output sent to browser
DEBUG - 2021-08-06 09:07:12 --> Total execution time: 0.0999
INFO - 2021-08-06 10:56:38 --> Config Class Initialized
INFO - 2021-08-06 10:56:38 --> Hooks Class Initialized
DEBUG - 2021-08-06 10:56:38 --> UTF-8 Support Enabled
INFO - 2021-08-06 10:56:38 --> Utf8 Class Initialized
INFO - 2021-08-06 10:56:38 --> URI Class Initialized
INFO - 2021-08-06 10:56:38 --> Router Class Initialized
INFO - 2021-08-06 10:56:38 --> Output Class Initialized
INFO - 2021-08-06 10:56:38 --> Security Class Initialized
DEBUG - 2021-08-06 10:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 10:56:38 --> Input Class Initialized
INFO - 2021-08-06 10:56:38 --> Language Class Initialized
INFO - 2021-08-06 10:56:38 --> Loader Class Initialized
INFO - 2021-08-06 10:56:38 --> Helper loaded: url_helper
INFO - 2021-08-06 10:56:38 --> Helper loaded: file_helper
INFO - 2021-08-06 10:56:38 --> Database Driver Class Initialized
DEBUG - 2021-08-06 10:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 10:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 10:56:38 --> Controller Class Initialized
INFO - 2021-08-06 10:56:38 --> Helper loaded: cookie_helper
INFO - 2021-08-06 10:56:38 --> Model "CookieModel" initialized
INFO - 2021-08-06 10:56:38 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 10:56:38 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/success_stories.php
INFO - 2021-08-06 10:56:38 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 10:56:38 --> Final output sent to browser
DEBUG - 2021-08-06 10:56:38 --> Total execution time: 0.2154
INFO - 2021-08-06 10:58:34 --> Config Class Initialized
INFO - 2021-08-06 10:58:34 --> Hooks Class Initialized
DEBUG - 2021-08-06 10:58:34 --> UTF-8 Support Enabled
INFO - 2021-08-06 10:58:34 --> Utf8 Class Initialized
INFO - 2021-08-06 10:58:34 --> URI Class Initialized
INFO - 2021-08-06 10:58:34 --> Router Class Initialized
INFO - 2021-08-06 10:58:34 --> Output Class Initialized
INFO - 2021-08-06 10:58:34 --> Security Class Initialized
DEBUG - 2021-08-06 10:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 10:58:34 --> Input Class Initialized
INFO - 2021-08-06 10:58:34 --> Language Class Initialized
INFO - 2021-08-06 10:58:34 --> Loader Class Initialized
INFO - 2021-08-06 10:58:34 --> Helper loaded: url_helper
INFO - 2021-08-06 10:58:34 --> Helper loaded: file_helper
INFO - 2021-08-06 10:58:34 --> Database Driver Class Initialized
DEBUG - 2021-08-06 10:58:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 10:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 10:58:34 --> Controller Class Initialized
INFO - 2021-08-06 10:58:34 --> Helper loaded: cookie_helper
INFO - 2021-08-06 10:58:34 --> Model "CookieModel" initialized
INFO - 2021-08-06 10:58:34 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 10:58:34 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/success_stories.php
INFO - 2021-08-06 10:58:34 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 10:58:34 --> Final output sent to browser
DEBUG - 2021-08-06 10:58:34 --> Total execution time: 0.0509
INFO - 2021-08-06 10:58:36 --> Config Class Initialized
INFO - 2021-08-06 10:58:36 --> Hooks Class Initialized
DEBUG - 2021-08-06 10:58:36 --> UTF-8 Support Enabled
INFO - 2021-08-06 10:58:36 --> Utf8 Class Initialized
INFO - 2021-08-06 10:58:36 --> URI Class Initialized
INFO - 2021-08-06 10:58:36 --> Router Class Initialized
INFO - 2021-08-06 10:58:36 --> Output Class Initialized
INFO - 2021-08-06 10:58:36 --> Security Class Initialized
DEBUG - 2021-08-06 10:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 10:58:36 --> Input Class Initialized
INFO - 2021-08-06 10:58:36 --> Language Class Initialized
INFO - 2021-08-06 10:58:36 --> Loader Class Initialized
INFO - 2021-08-06 10:58:36 --> Helper loaded: url_helper
INFO - 2021-08-06 10:58:36 --> Helper loaded: file_helper
INFO - 2021-08-06 10:58:36 --> Database Driver Class Initialized
DEBUG - 2021-08-06 10:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 10:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 10:58:36 --> Controller Class Initialized
INFO - 2021-08-06 10:58:36 --> Helper loaded: cookie_helper
INFO - 2021-08-06 10:58:36 --> Model "CookieModel" initialized
INFO - 2021-08-06 10:58:36 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 10:58:36 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/success_stories.php
INFO - 2021-08-06 10:58:36 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 10:58:36 --> Final output sent to browser
DEBUG - 2021-08-06 10:58:36 --> Total execution time: 0.0400
INFO - 2021-08-06 10:59:00 --> Config Class Initialized
INFO - 2021-08-06 10:59:00 --> Hooks Class Initialized
DEBUG - 2021-08-06 10:59:00 --> UTF-8 Support Enabled
INFO - 2021-08-06 10:59:00 --> Utf8 Class Initialized
INFO - 2021-08-06 10:59:00 --> URI Class Initialized
INFO - 2021-08-06 10:59:00 --> Router Class Initialized
INFO - 2021-08-06 10:59:00 --> Output Class Initialized
INFO - 2021-08-06 10:59:00 --> Security Class Initialized
DEBUG - 2021-08-06 10:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 10:59:00 --> Input Class Initialized
INFO - 2021-08-06 10:59:00 --> Language Class Initialized
INFO - 2021-08-06 10:59:00 --> Loader Class Initialized
INFO - 2021-08-06 10:59:00 --> Helper loaded: url_helper
INFO - 2021-08-06 10:59:00 --> Helper loaded: file_helper
INFO - 2021-08-06 10:59:00 --> Database Driver Class Initialized
DEBUG - 2021-08-06 10:59:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 10:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 10:59:00 --> Controller Class Initialized
INFO - 2021-08-06 10:59:00 --> Helper loaded: cookie_helper
INFO - 2021-08-06 10:59:00 --> Model "CookieModel" initialized
INFO - 2021-08-06 10:59:00 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 10:59:00 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/success_stories.php
INFO - 2021-08-06 10:59:00 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 10:59:00 --> Final output sent to browser
DEBUG - 2021-08-06 10:59:00 --> Total execution time: 0.0731
INFO - 2021-08-06 10:59:19 --> Config Class Initialized
INFO - 2021-08-06 10:59:19 --> Hooks Class Initialized
DEBUG - 2021-08-06 10:59:19 --> UTF-8 Support Enabled
INFO - 2021-08-06 10:59:19 --> Utf8 Class Initialized
INFO - 2021-08-06 10:59:19 --> URI Class Initialized
INFO - 2021-08-06 10:59:19 --> Router Class Initialized
INFO - 2021-08-06 10:59:19 --> Output Class Initialized
INFO - 2021-08-06 10:59:19 --> Security Class Initialized
DEBUG - 2021-08-06 10:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 10:59:19 --> Input Class Initialized
INFO - 2021-08-06 10:59:19 --> Language Class Initialized
INFO - 2021-08-06 10:59:19 --> Loader Class Initialized
INFO - 2021-08-06 10:59:19 --> Helper loaded: url_helper
INFO - 2021-08-06 10:59:19 --> Helper loaded: file_helper
INFO - 2021-08-06 10:59:19 --> Database Driver Class Initialized
DEBUG - 2021-08-06 10:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 10:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 10:59:19 --> Controller Class Initialized
INFO - 2021-08-06 10:59:19 --> Helper loaded: cookie_helper
INFO - 2021-08-06 10:59:19 --> Model "CookieModel" initialized
INFO - 2021-08-06 10:59:19 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 10:59:19 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/team.php
INFO - 2021-08-06 10:59:19 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 10:59:19 --> Final output sent to browser
DEBUG - 2021-08-06 10:59:19 --> Total execution time: 0.0419
INFO - 2021-08-06 10:59:27 --> Config Class Initialized
INFO - 2021-08-06 10:59:27 --> Hooks Class Initialized
DEBUG - 2021-08-06 10:59:27 --> UTF-8 Support Enabled
INFO - 2021-08-06 10:59:27 --> Utf8 Class Initialized
INFO - 2021-08-06 10:59:27 --> URI Class Initialized
INFO - 2021-08-06 10:59:27 --> Router Class Initialized
INFO - 2021-08-06 10:59:27 --> Output Class Initialized
INFO - 2021-08-06 10:59:27 --> Security Class Initialized
DEBUG - 2021-08-06 10:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 10:59:27 --> Input Class Initialized
INFO - 2021-08-06 10:59:27 --> Language Class Initialized
INFO - 2021-08-06 10:59:27 --> Loader Class Initialized
INFO - 2021-08-06 10:59:27 --> Helper loaded: url_helper
INFO - 2021-08-06 10:59:27 --> Helper loaded: file_helper
INFO - 2021-08-06 10:59:27 --> Database Driver Class Initialized
DEBUG - 2021-08-06 10:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 10:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 10:59:27 --> Controller Class Initialized
INFO - 2021-08-06 10:59:27 --> Helper loaded: cookie_helper
INFO - 2021-08-06 10:59:27 --> Model "CookieModel" initialized
INFO - 2021-08-06 10:59:27 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 10:59:27 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/gallery.php
INFO - 2021-08-06 10:59:27 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 10:59:27 --> Final output sent to browser
DEBUG - 2021-08-06 10:59:27 --> Total execution time: 0.0652
INFO - 2021-08-06 19:43:56 --> Config Class Initialized
INFO - 2021-08-06 19:43:56 --> Hooks Class Initialized
DEBUG - 2021-08-06 19:43:56 --> UTF-8 Support Enabled
INFO - 2021-08-06 19:43:56 --> Utf8 Class Initialized
INFO - 2021-08-06 19:43:56 --> URI Class Initialized
INFO - 2021-08-06 19:43:56 --> Router Class Initialized
INFO - 2021-08-06 19:43:56 --> Output Class Initialized
INFO - 2021-08-06 19:43:56 --> Security Class Initialized
DEBUG - 2021-08-06 19:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 19:43:56 --> Input Class Initialized
INFO - 2021-08-06 19:43:56 --> Language Class Initialized
INFO - 2021-08-06 19:43:56 --> Loader Class Initialized
INFO - 2021-08-06 19:43:56 --> Helper loaded: url_helper
INFO - 2021-08-06 19:43:56 --> Helper loaded: file_helper
INFO - 2021-08-06 19:43:56 --> Database Driver Class Initialized
DEBUG - 2021-08-06 19:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 19:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 19:43:56 --> Controller Class Initialized
INFO - 2021-08-06 19:43:56 --> Helper loaded: cookie_helper
INFO - 2021-08-06 19:43:56 --> Model "CookieModel" initialized
INFO - 2021-08-06 19:43:56 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 19:43:56 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/success_stories.php
INFO - 2021-08-06 19:43:56 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 19:43:56 --> Final output sent to browser
DEBUG - 2021-08-06 19:43:56 --> Total execution time: 0.1958
INFO - 2021-08-06 19:44:42 --> Config Class Initialized
INFO - 2021-08-06 19:44:42 --> Hooks Class Initialized
DEBUG - 2021-08-06 19:44:42 --> UTF-8 Support Enabled
INFO - 2021-08-06 19:44:42 --> Utf8 Class Initialized
INFO - 2021-08-06 19:44:42 --> URI Class Initialized
INFO - 2021-08-06 19:44:42 --> Router Class Initialized
INFO - 2021-08-06 19:44:42 --> Output Class Initialized
INFO - 2021-08-06 19:44:42 --> Security Class Initialized
DEBUG - 2021-08-06 19:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 19:44:43 --> Input Class Initialized
INFO - 2021-08-06 19:44:43 --> Language Class Initialized
INFO - 2021-08-06 19:44:43 --> Loader Class Initialized
INFO - 2021-08-06 19:44:43 --> Helper loaded: url_helper
INFO - 2021-08-06 19:44:43 --> Helper loaded: file_helper
INFO - 2021-08-06 19:44:43 --> Database Driver Class Initialized
DEBUG - 2021-08-06 19:44:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 19:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 19:44:43 --> Controller Class Initialized
INFO - 2021-08-06 19:44:43 --> Helper loaded: cookie_helper
INFO - 2021-08-06 19:44:43 --> Model "CookieModel" initialized
INFO - 2021-08-06 19:44:43 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 19:44:43 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/success_stories.php
INFO - 2021-08-06 19:44:43 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 19:44:43 --> Final output sent to browser
DEBUG - 2021-08-06 19:44:43 --> Total execution time: 0.0884
INFO - 2021-08-06 19:44:48 --> Config Class Initialized
INFO - 2021-08-06 19:44:48 --> Hooks Class Initialized
DEBUG - 2021-08-06 19:44:48 --> UTF-8 Support Enabled
INFO - 2021-08-06 19:44:48 --> Utf8 Class Initialized
INFO - 2021-08-06 19:44:48 --> URI Class Initialized
DEBUG - 2021-08-06 19:44:48 --> No URI present. Default controller set.
INFO - 2021-08-06 19:44:48 --> Router Class Initialized
INFO - 2021-08-06 19:44:48 --> Output Class Initialized
INFO - 2021-08-06 19:44:48 --> Security Class Initialized
DEBUG - 2021-08-06 19:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 19:44:48 --> Input Class Initialized
INFO - 2021-08-06 19:44:48 --> Language Class Initialized
INFO - 2021-08-06 19:44:48 --> Loader Class Initialized
INFO - 2021-08-06 19:44:48 --> Helper loaded: url_helper
INFO - 2021-08-06 19:44:48 --> Helper loaded: file_helper
INFO - 2021-08-06 19:44:48 --> Database Driver Class Initialized
DEBUG - 2021-08-06 19:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 19:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 19:44:48 --> Controller Class Initialized
INFO - 2021-08-06 19:44:48 --> Helper loaded: cookie_helper
INFO - 2021-08-06 19:44:48 --> Model "CookieModel" initialized
INFO - 2021-08-06 19:44:48 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 19:44:48 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-06 19:44:48 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 19:44:48 --> Final output sent to browser
DEBUG - 2021-08-06 19:44:48 --> Total execution time: 0.1344
INFO - 2021-08-06 19:46:18 --> Config Class Initialized
INFO - 2021-08-06 19:46:18 --> Hooks Class Initialized
DEBUG - 2021-08-06 19:46:18 --> UTF-8 Support Enabled
INFO - 2021-08-06 19:46:18 --> Utf8 Class Initialized
INFO - 2021-08-06 19:46:18 --> URI Class Initialized
INFO - 2021-08-06 19:46:18 --> Router Class Initialized
INFO - 2021-08-06 19:46:18 --> Output Class Initialized
INFO - 2021-08-06 19:46:18 --> Security Class Initialized
DEBUG - 2021-08-06 19:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 19:46:18 --> Input Class Initialized
INFO - 2021-08-06 19:46:18 --> Language Class Initialized
INFO - 2021-08-06 19:46:18 --> Loader Class Initialized
INFO - 2021-08-06 19:46:18 --> Helper loaded: url_helper
INFO - 2021-08-06 19:46:18 --> Helper loaded: file_helper
INFO - 2021-08-06 19:46:18 --> Database Driver Class Initialized
DEBUG - 2021-08-06 19:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 19:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 19:46:18 --> Controller Class Initialized
INFO - 2021-08-06 19:46:18 --> Helper loaded: cookie_helper
INFO - 2021-08-06 19:46:18 --> Model "CookieModel" initialized
INFO - 2021-08-06 19:46:18 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 19:46:18 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/services.php
INFO - 2021-08-06 19:46:18 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 19:46:18 --> Final output sent to browser
DEBUG - 2021-08-06 19:46:18 --> Total execution time: 0.0426
INFO - 2021-08-06 19:53:24 --> Config Class Initialized
INFO - 2021-08-06 19:53:24 --> Hooks Class Initialized
DEBUG - 2021-08-06 19:53:24 --> UTF-8 Support Enabled
INFO - 2021-08-06 19:53:24 --> Utf8 Class Initialized
INFO - 2021-08-06 19:53:24 --> URI Class Initialized
DEBUG - 2021-08-06 19:53:24 --> No URI present. Default controller set.
INFO - 2021-08-06 19:53:24 --> Router Class Initialized
INFO - 2021-08-06 19:53:24 --> Output Class Initialized
INFO - 2021-08-06 19:53:24 --> Security Class Initialized
DEBUG - 2021-08-06 19:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 19:53:24 --> Input Class Initialized
INFO - 2021-08-06 19:53:24 --> Language Class Initialized
INFO - 2021-08-06 19:53:24 --> Loader Class Initialized
INFO - 2021-08-06 19:53:24 --> Helper loaded: url_helper
INFO - 2021-08-06 19:53:24 --> Helper loaded: file_helper
INFO - 2021-08-06 19:53:24 --> Database Driver Class Initialized
DEBUG - 2021-08-06 19:53:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 19:53:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 19:53:24 --> Controller Class Initialized
INFO - 2021-08-06 19:53:24 --> Helper loaded: cookie_helper
INFO - 2021-08-06 19:53:24 --> Model "CookieModel" initialized
INFO - 2021-08-06 19:53:24 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 19:53:24 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-06 19:53:24 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 19:53:24 --> Final output sent to browser
DEBUG - 2021-08-06 19:53:24 --> Total execution time: 0.1223
INFO - 2021-08-06 19:53:26 --> Config Class Initialized
INFO - 2021-08-06 19:53:26 --> Hooks Class Initialized
DEBUG - 2021-08-06 19:53:26 --> UTF-8 Support Enabled
INFO - 2021-08-06 19:53:26 --> Utf8 Class Initialized
INFO - 2021-08-06 19:53:27 --> URI Class Initialized
DEBUG - 2021-08-06 19:53:27 --> No URI present. Default controller set.
INFO - 2021-08-06 19:53:27 --> Router Class Initialized
INFO - 2021-08-06 19:53:27 --> Output Class Initialized
INFO - 2021-08-06 19:53:27 --> Security Class Initialized
DEBUG - 2021-08-06 19:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 19:53:27 --> Input Class Initialized
INFO - 2021-08-06 19:53:27 --> Language Class Initialized
INFO - 2021-08-06 19:53:27 --> Loader Class Initialized
INFO - 2021-08-06 19:53:27 --> Helper loaded: url_helper
INFO - 2021-08-06 19:53:27 --> Helper loaded: file_helper
INFO - 2021-08-06 19:53:27 --> Database Driver Class Initialized
DEBUG - 2021-08-06 19:53:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 19:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 19:53:27 --> Controller Class Initialized
INFO - 2021-08-06 19:53:27 --> Helper loaded: cookie_helper
INFO - 2021-08-06 19:53:27 --> Model "CookieModel" initialized
INFO - 2021-08-06 19:53:27 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 19:53:27 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/index.php
INFO - 2021-08-06 19:53:27 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 19:53:27 --> Final output sent to browser
DEBUG - 2021-08-06 19:53:27 --> Total execution time: 0.0489
INFO - 2021-08-06 19:54:17 --> Config Class Initialized
INFO - 2021-08-06 19:54:17 --> Hooks Class Initialized
DEBUG - 2021-08-06 19:54:17 --> UTF-8 Support Enabled
INFO - 2021-08-06 19:54:17 --> Utf8 Class Initialized
INFO - 2021-08-06 19:54:17 --> URI Class Initialized
INFO - 2021-08-06 19:54:17 --> Router Class Initialized
INFO - 2021-08-06 19:54:17 --> Output Class Initialized
INFO - 2021-08-06 19:54:17 --> Security Class Initialized
DEBUG - 2021-08-06 19:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 19:54:17 --> Input Class Initialized
INFO - 2021-08-06 19:54:17 --> Language Class Initialized
INFO - 2021-08-06 19:54:17 --> Loader Class Initialized
INFO - 2021-08-06 19:54:17 --> Helper loaded: url_helper
INFO - 2021-08-06 19:54:17 --> Helper loaded: file_helper
INFO - 2021-08-06 19:54:17 --> Database Driver Class Initialized
DEBUG - 2021-08-06 19:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 19:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 19:54:17 --> Controller Class Initialized
INFO - 2021-08-06 19:54:17 --> Helper loaded: cookie_helper
INFO - 2021-08-06 19:54:17 --> Model "CookieModel" initialized
INFO - 2021-08-06 19:54:17 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 19:54:17 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/services.php
INFO - 2021-08-06 19:54:17 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 19:54:17 --> Final output sent to browser
DEBUG - 2021-08-06 19:54:17 --> Total execution time: 0.0523
INFO - 2021-08-06 19:54:35 --> Config Class Initialized
INFO - 2021-08-06 19:54:35 --> Hooks Class Initialized
DEBUG - 2021-08-06 19:54:35 --> UTF-8 Support Enabled
INFO - 2021-08-06 19:54:35 --> Utf8 Class Initialized
INFO - 2021-08-06 19:54:35 --> URI Class Initialized
INFO - 2021-08-06 19:54:35 --> Router Class Initialized
INFO - 2021-08-06 19:54:35 --> Output Class Initialized
INFO - 2021-08-06 19:54:35 --> Security Class Initialized
DEBUG - 2021-08-06 19:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 19:54:35 --> Input Class Initialized
INFO - 2021-08-06 19:54:35 --> Language Class Initialized
INFO - 2021-08-06 19:54:35 --> Loader Class Initialized
INFO - 2021-08-06 19:54:35 --> Helper loaded: url_helper
INFO - 2021-08-06 19:54:35 --> Helper loaded: file_helper
INFO - 2021-08-06 19:54:35 --> Database Driver Class Initialized
DEBUG - 2021-08-06 19:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 19:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 19:54:35 --> Controller Class Initialized
INFO - 2021-08-06 19:54:35 --> Helper loaded: cookie_helper
INFO - 2021-08-06 19:54:35 --> Model "CookieModel" initialized
INFO - 2021-08-06 19:54:35 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 19:54:35 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/pilates.php
INFO - 2021-08-06 19:54:35 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 19:54:35 --> Final output sent to browser
DEBUG - 2021-08-06 19:54:35 --> Total execution time: 0.0432
INFO - 2021-08-06 19:54:45 --> Config Class Initialized
INFO - 2021-08-06 19:54:45 --> Hooks Class Initialized
DEBUG - 2021-08-06 19:54:45 --> UTF-8 Support Enabled
INFO - 2021-08-06 19:54:45 --> Utf8 Class Initialized
INFO - 2021-08-06 19:54:45 --> URI Class Initialized
INFO - 2021-08-06 19:54:45 --> Router Class Initialized
INFO - 2021-08-06 19:54:45 --> Output Class Initialized
INFO - 2021-08-06 19:54:45 --> Security Class Initialized
DEBUG - 2021-08-06 19:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 19:54:45 --> Input Class Initialized
INFO - 2021-08-06 19:54:45 --> Language Class Initialized
INFO - 2021-08-06 19:54:45 --> Loader Class Initialized
INFO - 2021-08-06 19:54:45 --> Helper loaded: url_helper
INFO - 2021-08-06 19:54:45 --> Helper loaded: file_helper
INFO - 2021-08-06 19:54:45 --> Database Driver Class Initialized
DEBUG - 2021-08-06 19:54:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 19:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 19:54:45 --> Controller Class Initialized
INFO - 2021-08-06 19:54:45 --> Helper loaded: cookie_helper
INFO - 2021-08-06 19:54:45 --> Model "CookieModel" initialized
INFO - 2021-08-06 19:54:45 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 19:54:45 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/success_stories.php
INFO - 2021-08-06 19:54:45 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 19:54:45 --> Final output sent to browser
DEBUG - 2021-08-06 19:54:45 --> Total execution time: 0.0648
INFO - 2021-08-06 19:54:51 --> Config Class Initialized
INFO - 2021-08-06 19:54:51 --> Hooks Class Initialized
DEBUG - 2021-08-06 19:54:51 --> UTF-8 Support Enabled
INFO - 2021-08-06 19:54:51 --> Utf8 Class Initialized
INFO - 2021-08-06 19:54:51 --> URI Class Initialized
INFO - 2021-08-06 19:54:51 --> Router Class Initialized
INFO - 2021-08-06 19:54:51 --> Output Class Initialized
INFO - 2021-08-06 19:54:51 --> Security Class Initialized
DEBUG - 2021-08-06 19:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 19:54:51 --> Input Class Initialized
INFO - 2021-08-06 19:54:51 --> Language Class Initialized
INFO - 2021-08-06 19:54:51 --> Config Class Initialized
INFO - 2021-08-06 19:54:51 --> Hooks Class Initialized
ERROR - 2021-08-06 19:54:51 --> 404 Page Not Found: Assets/js
DEBUG - 2021-08-06 19:54:51 --> UTF-8 Support Enabled
INFO - 2021-08-06 19:54:51 --> Utf8 Class Initialized
INFO - 2021-08-06 19:54:51 --> URI Class Initialized
INFO - 2021-08-06 19:54:51 --> Router Class Initialized
INFO - 2021-08-06 19:54:51 --> Output Class Initialized
INFO - 2021-08-06 19:54:51 --> Security Class Initialized
DEBUG - 2021-08-06 19:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 19:54:51 --> Input Class Initialized
INFO - 2021-08-06 19:54:51 --> Language Class Initialized
INFO - 2021-08-06 19:54:51 --> Config Class Initialized
ERROR - 2021-08-06 19:54:51 --> 404 Page Not Found: Assets/js
INFO - 2021-08-06 19:54:51 --> Hooks Class Initialized
DEBUG - 2021-08-06 19:54:51 --> UTF-8 Support Enabled
INFO - 2021-08-06 19:54:51 --> Utf8 Class Initialized
INFO - 2021-08-06 19:54:51 --> URI Class Initialized
INFO - 2021-08-06 19:54:51 --> Router Class Initialized
INFO - 2021-08-06 19:54:51 --> Output Class Initialized
INFO - 2021-08-06 19:54:51 --> Security Class Initialized
DEBUG - 2021-08-06 19:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 19:54:51 --> Input Class Initialized
INFO - 2021-08-06 19:54:51 --> Language Class Initialized
ERROR - 2021-08-06 19:54:51 --> 404 Page Not Found: Assets/js
INFO - 2021-08-06 19:54:51 --> Config Class Initialized
INFO - 2021-08-06 19:54:51 --> Hooks Class Initialized
INFO - 2021-08-06 19:54:51 --> Config Class Initialized
DEBUG - 2021-08-06 19:54:51 --> UTF-8 Support Enabled
INFO - 2021-08-06 19:54:51 --> Hooks Class Initialized
INFO - 2021-08-06 19:54:51 --> Utf8 Class Initialized
INFO - 2021-08-06 19:54:51 --> URI Class Initialized
DEBUG - 2021-08-06 19:54:51 --> UTF-8 Support Enabled
INFO - 2021-08-06 19:54:51 --> Router Class Initialized
INFO - 2021-08-06 19:54:51 --> Utf8 Class Initialized
INFO - 2021-08-06 19:54:51 --> URI Class Initialized
INFO - 2021-08-06 19:54:51 --> Output Class Initialized
INFO - 2021-08-06 19:54:51 --> Router Class Initialized
INFO - 2021-08-06 19:54:51 --> Security Class Initialized
INFO - 2021-08-06 19:54:51 --> Output Class Initialized
DEBUG - 2021-08-06 19:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 19:54:51 --> Input Class Initialized
INFO - 2021-08-06 19:54:51 --> Language Class Initialized
INFO - 2021-08-06 19:54:51 --> Security Class Initialized
ERROR - 2021-08-06 19:54:51 --> 404 Page Not Found: Assets/css
DEBUG - 2021-08-06 19:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 19:54:51 --> Input Class Initialized
INFO - 2021-08-06 19:54:51 --> Language Class Initialized
ERROR - 2021-08-06 19:54:51 --> 404 Page Not Found: Assets/css
INFO - 2021-08-06 20:09:35 --> Config Class Initialized
INFO - 2021-08-06 20:09:35 --> Hooks Class Initialized
DEBUG - 2021-08-06 20:09:35 --> UTF-8 Support Enabled
INFO - 2021-08-06 20:09:35 --> Utf8 Class Initialized
INFO - 2021-08-06 20:09:35 --> URI Class Initialized
INFO - 2021-08-06 20:09:35 --> Router Class Initialized
INFO - 2021-08-06 20:09:35 --> Output Class Initialized
INFO - 2021-08-06 20:09:35 --> Security Class Initialized
DEBUG - 2021-08-06 20:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 20:09:35 --> Input Class Initialized
INFO - 2021-08-06 20:09:35 --> Language Class Initialized
INFO - 2021-08-06 20:09:35 --> Loader Class Initialized
INFO - 2021-08-06 20:09:35 --> Helper loaded: url_helper
INFO - 2021-08-06 20:09:35 --> Helper loaded: file_helper
INFO - 2021-08-06 20:09:35 --> Database Driver Class Initialized
DEBUG - 2021-08-06 20:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 20:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 20:09:35 --> Controller Class Initialized
INFO - 2021-08-06 20:09:35 --> Helper loaded: cookie_helper
INFO - 2021-08-06 20:09:35 --> Model "CookieModel" initialized
INFO - 2021-08-06 20:09:35 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 20:09:35 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/success_stories.php
INFO - 2021-08-06 20:09:35 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 20:09:35 --> Final output sent to browser
DEBUG - 2021-08-06 20:09:35 --> Total execution time: 0.1148
INFO - 2021-08-06 20:09:36 --> Config Class Initialized
INFO - 2021-08-06 20:09:36 --> Hooks Class Initialized
DEBUG - 2021-08-06 20:09:36 --> UTF-8 Support Enabled
INFO - 2021-08-06 20:09:36 --> Utf8 Class Initialized
INFO - 2021-08-06 20:09:36 --> Config Class Initialized
INFO - 2021-08-06 20:09:36 --> Hooks Class Initialized
INFO - 2021-08-06 20:09:36 --> URI Class Initialized
INFO - 2021-08-06 20:09:36 --> Router Class Initialized
DEBUG - 2021-08-06 20:09:36 --> UTF-8 Support Enabled
INFO - 2021-08-06 20:09:36 --> Utf8 Class Initialized
INFO - 2021-08-06 20:09:36 --> Output Class Initialized
INFO - 2021-08-06 20:09:36 --> URI Class Initialized
INFO - 2021-08-06 20:09:36 --> Security Class Initialized
INFO - 2021-08-06 20:09:36 --> Router Class Initialized
DEBUG - 2021-08-06 20:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 20:09:36 --> Input Class Initialized
INFO - 2021-08-06 20:09:36 --> Language Class Initialized
INFO - 2021-08-06 20:09:36 --> Output Class Initialized
ERROR - 2021-08-06 20:09:36 --> 404 Page Not Found: Assets/css
INFO - 2021-08-06 20:09:36 --> Security Class Initialized
DEBUG - 2021-08-06 20:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 20:09:36 --> Input Class Initialized
INFO - 2021-08-06 20:09:36 --> Language Class Initialized
ERROR - 2021-08-06 20:09:36 --> 404 Page Not Found: Assets/css
INFO - 2021-08-06 20:09:36 --> Config Class Initialized
INFO - 2021-08-06 20:09:36 --> Hooks Class Initialized
DEBUG - 2021-08-06 20:09:36 --> UTF-8 Support Enabled
INFO - 2021-08-06 20:09:36 --> Utf8 Class Initialized
INFO - 2021-08-06 20:09:36 --> URI Class Initialized
INFO - 2021-08-06 20:09:36 --> Router Class Initialized
INFO - 2021-08-06 20:09:36 --> Output Class Initialized
INFO - 2021-08-06 20:09:36 --> Security Class Initialized
DEBUG - 2021-08-06 20:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 20:09:36 --> Input Class Initialized
INFO - 2021-08-06 20:09:36 --> Language Class Initialized
ERROR - 2021-08-06 20:09:36 --> 404 Page Not Found: Assets/js
INFO - 2021-08-06 20:09:37 --> Config Class Initialized
INFO - 2021-08-06 20:09:37 --> Hooks Class Initialized
DEBUG - 2021-08-06 20:09:37 --> UTF-8 Support Enabled
INFO - 2021-08-06 20:09:37 --> Utf8 Class Initialized
INFO - 2021-08-06 20:09:37 --> URI Class Initialized
INFO - 2021-08-06 20:09:37 --> Router Class Initialized
INFO - 2021-08-06 20:09:37 --> Output Class Initialized
INFO - 2021-08-06 20:09:37 --> Security Class Initialized
DEBUG - 2021-08-06 20:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 20:09:37 --> Input Class Initialized
INFO - 2021-08-06 20:09:37 --> Language Class Initialized
ERROR - 2021-08-06 20:09:37 --> 404 Page Not Found: Assets/js
INFO - 2021-08-06 20:09:37 --> Config Class Initialized
INFO - 2021-08-06 20:09:37 --> Hooks Class Initialized
DEBUG - 2021-08-06 20:09:37 --> UTF-8 Support Enabled
INFO - 2021-08-06 20:09:37 --> Utf8 Class Initialized
INFO - 2021-08-06 20:09:37 --> URI Class Initialized
INFO - 2021-08-06 20:09:37 --> Router Class Initialized
INFO - 2021-08-06 20:09:37 --> Output Class Initialized
INFO - 2021-08-06 20:09:37 --> Security Class Initialized
DEBUG - 2021-08-06 20:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 20:09:37 --> Input Class Initialized
INFO - 2021-08-06 20:09:37 --> Language Class Initialized
ERROR - 2021-08-06 20:09:37 --> 404 Page Not Found: Assets/js
INFO - 2021-08-06 20:19:53 --> Config Class Initialized
INFO - 2021-08-06 20:19:53 --> Hooks Class Initialized
DEBUG - 2021-08-06 20:19:53 --> UTF-8 Support Enabled
INFO - 2021-08-06 20:19:53 --> Utf8 Class Initialized
INFO - 2021-08-06 20:19:53 --> URI Class Initialized
INFO - 2021-08-06 20:19:53 --> Router Class Initialized
INFO - 2021-08-06 20:19:53 --> Output Class Initialized
INFO - 2021-08-06 20:19:53 --> Security Class Initialized
DEBUG - 2021-08-06 20:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-06 20:19:53 --> Input Class Initialized
INFO - 2021-08-06 20:19:53 --> Language Class Initialized
INFO - 2021-08-06 20:19:53 --> Loader Class Initialized
INFO - 2021-08-06 20:19:53 --> Helper loaded: url_helper
INFO - 2021-08-06 20:19:53 --> Helper loaded: file_helper
INFO - 2021-08-06 20:19:53 --> Database Driver Class Initialized
DEBUG - 2021-08-06 20:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-06 20:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-06 20:19:53 --> Controller Class Initialized
INFO - 2021-08-06 20:19:53 --> Helper loaded: cookie_helper
INFO - 2021-08-06 20:19:53 --> Model "CookieModel" initialized
INFO - 2021-08-06 20:19:53 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/header.php
INFO - 2021-08-06 20:19:53 --> File loaded: E:\xampp\htdocs\changemegym\application\views\user/success_stories.php
INFO - 2021-08-06 20:19:53 --> File loaded: E:\xampp\htdocs\changemegym\application\views\layout/footer.php
INFO - 2021-08-06 20:19:53 --> Final output sent to browser
DEBUG - 2021-08-06 20:19:53 --> Total execution time: 0.0659
