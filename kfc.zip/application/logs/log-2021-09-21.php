<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-09-21 15:36:51 --> Config Class Initialized
INFO - 2021-09-21 15:36:51 --> Hooks Class Initialized
DEBUG - 2021-09-21 15:36:51 --> UTF-8 Support Enabled
INFO - 2021-09-21 15:36:51 --> Utf8 Class Initialized
INFO - 2021-09-21 15:36:51 --> URI Class Initialized
DEBUG - 2021-09-21 15:36:51 --> No URI present. Default controller set.
INFO - 2021-09-21 15:36:51 --> Router Class Initialized
INFO - 2021-09-21 15:36:51 --> Output Class Initialized
INFO - 2021-09-21 15:36:51 --> Security Class Initialized
DEBUG - 2021-09-21 15:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-21 15:36:51 --> Input Class Initialized
INFO - 2021-09-21 15:36:51 --> Language Class Initialized
INFO - 2021-09-21 15:36:51 --> Loader Class Initialized
INFO - 2021-09-21 15:36:51 --> Helper loaded: url_helper
INFO - 2021-09-21 15:36:51 --> Helper loaded: file_helper
DEBUG - 2021-09-21 15:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-21 15:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-21 15:36:52 --> Controller Class Initialized
INFO - 2021-09-21 15:36:52 --> Helper loaded: cookie_helper
INFO - 2021-09-21 15:36:52 --> Model "CookieModel" initialized
INFO - 2021-09-21 15:36:52 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-21 15:36:52 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-09-21 15:36:52 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-21 15:36:52 --> Final output sent to browser
DEBUG - 2021-09-21 15:36:52 --> Total execution time: 0.9781
INFO - 2021-09-21 15:38:07 --> Config Class Initialized
INFO - 2021-09-21 15:38:07 --> Hooks Class Initialized
DEBUG - 2021-09-21 15:38:07 --> UTF-8 Support Enabled
INFO - 2021-09-21 15:38:07 --> Utf8 Class Initialized
INFO - 2021-09-21 15:38:07 --> URI Class Initialized
INFO - 2021-09-21 15:38:07 --> Router Class Initialized
INFO - 2021-09-21 15:38:07 --> Output Class Initialized
INFO - 2021-09-21 15:38:07 --> Security Class Initialized
DEBUG - 2021-09-21 15:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-21 15:38:07 --> Input Class Initialized
INFO - 2021-09-21 15:38:07 --> Language Class Initialized
INFO - 2021-09-21 15:38:07 --> Loader Class Initialized
INFO - 2021-09-21 15:38:07 --> Helper loaded: url_helper
INFO - 2021-09-21 15:38:07 --> Helper loaded: file_helper
DEBUG - 2021-09-21 15:38:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-21 15:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-21 15:38:07 --> Controller Class Initialized
INFO - 2021-09-21 15:38:07 --> Helper loaded: cookie_helper
INFO - 2021-09-21 15:38:07 --> Model "CookieModel" initialized
INFO - 2021-09-21 15:38:07 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-21 15:38:07 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/team.php
INFO - 2021-09-21 15:38:07 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-21 15:38:07 --> Final output sent to browser
DEBUG - 2021-09-21 15:38:07 --> Total execution time: 0.1021
INFO - 2021-09-21 15:39:03 --> Config Class Initialized
INFO - 2021-09-21 15:39:03 --> Hooks Class Initialized
DEBUG - 2021-09-21 15:39:03 --> UTF-8 Support Enabled
INFO - 2021-09-21 15:39:03 --> Utf8 Class Initialized
INFO - 2021-09-21 15:39:03 --> URI Class Initialized
INFO - 2021-09-21 15:39:03 --> Router Class Initialized
INFO - 2021-09-21 15:39:03 --> Output Class Initialized
INFO - 2021-09-21 15:39:03 --> Security Class Initialized
DEBUG - 2021-09-21 15:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-21 15:39:03 --> Input Class Initialized
INFO - 2021-09-21 15:39:03 --> Language Class Initialized
INFO - 2021-09-21 15:39:03 --> Loader Class Initialized
INFO - 2021-09-21 15:39:03 --> Helper loaded: url_helper
INFO - 2021-09-21 15:39:03 --> Helper loaded: file_helper
DEBUG - 2021-09-21 15:39:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-21 15:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-21 15:39:03 --> Controller Class Initialized
INFO - 2021-09-21 15:39:03 --> Helper loaded: cookie_helper
INFO - 2021-09-21 15:39:03 --> Model "CookieModel" initialized
INFO - 2021-09-21 15:39:03 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-21 15:39:03 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/team.php
INFO - 2021-09-21 15:39:03 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-21 15:39:03 --> Final output sent to browser
DEBUG - 2021-09-21 15:39:03 --> Total execution time: 0.0488
INFO - 2021-09-21 15:42:47 --> Config Class Initialized
INFO - 2021-09-21 15:42:47 --> Hooks Class Initialized
DEBUG - 2021-09-21 15:42:47 --> UTF-8 Support Enabled
INFO - 2021-09-21 15:42:47 --> Utf8 Class Initialized
INFO - 2021-09-21 15:42:47 --> URI Class Initialized
INFO - 2021-09-21 15:42:47 --> Router Class Initialized
INFO - 2021-09-21 15:42:47 --> Output Class Initialized
INFO - 2021-09-21 15:42:47 --> Security Class Initialized
DEBUG - 2021-09-21 15:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-21 15:42:47 --> Input Class Initialized
INFO - 2021-09-21 15:42:47 --> Language Class Initialized
INFO - 2021-09-21 15:42:47 --> Loader Class Initialized
INFO - 2021-09-21 15:42:47 --> Helper loaded: url_helper
INFO - 2021-09-21 15:42:47 --> Helper loaded: file_helper
DEBUG - 2021-09-21 15:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-21 15:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-21 15:42:47 --> Controller Class Initialized
INFO - 2021-09-21 15:42:47 --> Helper loaded: cookie_helper
INFO - 2021-09-21 15:42:47 --> Model "CookieModel" initialized
INFO - 2021-09-21 15:42:47 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-21 15:42:47 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/pilates.php
INFO - 2021-09-21 15:42:47 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-21 15:42:47 --> Final output sent to browser
DEBUG - 2021-09-21 15:42:47 --> Total execution time: 0.0747
INFO - 2021-09-21 15:43:34 --> Config Class Initialized
INFO - 2021-09-21 15:43:34 --> Hooks Class Initialized
DEBUG - 2021-09-21 15:43:34 --> UTF-8 Support Enabled
INFO - 2021-09-21 15:43:34 --> Utf8 Class Initialized
INFO - 2021-09-21 15:43:34 --> URI Class Initialized
INFO - 2021-09-21 15:43:34 --> Router Class Initialized
INFO - 2021-09-21 15:43:34 --> Output Class Initialized
INFO - 2021-09-21 15:43:34 --> Security Class Initialized
DEBUG - 2021-09-21 15:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-21 15:43:34 --> Input Class Initialized
INFO - 2021-09-21 15:43:34 --> Language Class Initialized
INFO - 2021-09-21 15:43:34 --> Loader Class Initialized
INFO - 2021-09-21 15:43:34 --> Helper loaded: url_helper
INFO - 2021-09-21 15:43:34 --> Helper loaded: file_helper
DEBUG - 2021-09-21 15:43:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-21 15:43:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-21 15:43:34 --> Controller Class Initialized
INFO - 2021-09-21 15:43:34 --> Helper loaded: cookie_helper
INFO - 2021-09-21 15:43:34 --> Model "CookieModel" initialized
INFO - 2021-09-21 15:43:34 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-21 15:43:34 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/gallery.php
INFO - 2021-09-21 15:43:34 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-21 15:43:34 --> Final output sent to browser
DEBUG - 2021-09-21 15:43:34 --> Total execution time: 0.0574
INFO - 2021-09-21 15:44:49 --> Config Class Initialized
INFO - 2021-09-21 15:44:49 --> Hooks Class Initialized
DEBUG - 2021-09-21 15:44:49 --> UTF-8 Support Enabled
INFO - 2021-09-21 15:44:49 --> Utf8 Class Initialized
INFO - 2021-09-21 15:44:49 --> URI Class Initialized
INFO - 2021-09-21 15:44:49 --> Router Class Initialized
INFO - 2021-09-21 15:44:49 --> Output Class Initialized
INFO - 2021-09-21 15:44:49 --> Security Class Initialized
DEBUG - 2021-09-21 15:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-21 15:44:49 --> Input Class Initialized
INFO - 2021-09-21 15:44:49 --> Language Class Initialized
INFO - 2021-09-21 15:44:49 --> Loader Class Initialized
INFO - 2021-09-21 15:44:49 --> Helper loaded: url_helper
INFO - 2021-09-21 15:44:49 --> Helper loaded: file_helper
DEBUG - 2021-09-21 15:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-21 15:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-21 15:44:49 --> Controller Class Initialized
INFO - 2021-09-21 15:44:49 --> Helper loaded: cookie_helper
INFO - 2021-09-21 15:44:49 --> Model "CookieModel" initialized
INFO - 2021-09-21 15:44:49 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-21 15:44:49 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-09-21 15:44:49 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-21 15:44:49 --> Final output sent to browser
DEBUG - 2021-09-21 15:44:49 --> Total execution time: 0.0471
INFO - 2021-09-21 15:50:03 --> Config Class Initialized
INFO - 2021-09-21 15:50:03 --> Hooks Class Initialized
DEBUG - 2021-09-21 15:50:03 --> UTF-8 Support Enabled
INFO - 2021-09-21 15:50:03 --> Utf8 Class Initialized
INFO - 2021-09-21 15:50:03 --> URI Class Initialized
INFO - 2021-09-21 15:50:03 --> Router Class Initialized
INFO - 2021-09-21 15:50:03 --> Output Class Initialized
INFO - 2021-09-21 15:50:03 --> Security Class Initialized
DEBUG - 2021-09-21 15:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-21 15:50:03 --> Input Class Initialized
INFO - 2021-09-21 15:50:03 --> Language Class Initialized
INFO - 2021-09-21 15:50:03 --> Loader Class Initialized
INFO - 2021-09-21 15:50:03 --> Helper loaded: url_helper
INFO - 2021-09-21 15:50:03 --> Helper loaded: file_helper
DEBUG - 2021-09-21 15:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-21 15:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-21 15:50:03 --> Controller Class Initialized
INFO - 2021-09-21 15:50:03 --> Helper loaded: cookie_helper
INFO - 2021-09-21 15:50:03 --> Model "CookieModel" initialized
INFO - 2021-09-21 15:50:03 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-21 15:50:03 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-09-21 15:50:03 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-21 15:50:03 --> Final output sent to browser
DEBUG - 2021-09-21 15:50:03 --> Total execution time: 0.0554
INFO - 2021-09-21 15:50:18 --> Config Class Initialized
INFO - 2021-09-21 15:50:18 --> Hooks Class Initialized
DEBUG - 2021-09-21 15:50:18 --> UTF-8 Support Enabled
INFO - 2021-09-21 15:50:18 --> Utf8 Class Initialized
INFO - 2021-09-21 15:50:18 --> URI Class Initialized
INFO - 2021-09-21 15:50:18 --> Router Class Initialized
INFO - 2021-09-21 15:50:18 --> Output Class Initialized
INFO - 2021-09-21 15:50:18 --> Security Class Initialized
DEBUG - 2021-09-21 15:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-21 15:50:18 --> Input Class Initialized
INFO - 2021-09-21 15:50:18 --> Language Class Initialized
INFO - 2021-09-21 15:50:18 --> Loader Class Initialized
INFO - 2021-09-21 15:50:18 --> Helper loaded: url_helper
INFO - 2021-09-21 15:50:18 --> Helper loaded: file_helper
DEBUG - 2021-09-21 15:50:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-21 15:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-21 15:50:18 --> Controller Class Initialized
INFO - 2021-09-21 15:50:18 --> Helper loaded: cookie_helper
INFO - 2021-09-21 15:50:18 --> Model "CookieModel" initialized
INFO - 2021-09-21 15:50:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-21 15:50:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-09-21 15:50:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-21 15:50:18 --> Final output sent to browser
DEBUG - 2021-09-21 15:50:18 --> Total execution time: 0.0487
INFO - 2021-09-21 15:50:49 --> Config Class Initialized
INFO - 2021-09-21 15:50:49 --> Hooks Class Initialized
DEBUG - 2021-09-21 15:50:49 --> UTF-8 Support Enabled
INFO - 2021-09-21 15:50:49 --> Utf8 Class Initialized
INFO - 2021-09-21 15:50:49 --> URI Class Initialized
INFO - 2021-09-21 15:50:49 --> Router Class Initialized
INFO - 2021-09-21 15:50:49 --> Output Class Initialized
INFO - 2021-09-21 15:50:49 --> Security Class Initialized
DEBUG - 2021-09-21 15:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-21 15:50:49 --> Input Class Initialized
INFO - 2021-09-21 15:50:49 --> Language Class Initialized
INFO - 2021-09-21 15:50:49 --> Loader Class Initialized
INFO - 2021-09-21 15:50:49 --> Helper loaded: url_helper
INFO - 2021-09-21 15:50:49 --> Helper loaded: file_helper
DEBUG - 2021-09-21 15:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-21 15:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-21 15:50:49 --> Controller Class Initialized
INFO - 2021-09-21 15:50:49 --> Helper loaded: cookie_helper
INFO - 2021-09-21 15:50:49 --> Model "CookieModel" initialized
INFO - 2021-09-21 15:50:49 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-21 15:50:49 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-09-21 15:50:49 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-21 15:50:49 --> Final output sent to browser
DEBUG - 2021-09-21 15:50:49 --> Total execution time: 0.0439
INFO - 2021-09-21 15:50:52 --> Config Class Initialized
INFO - 2021-09-21 15:50:52 --> Hooks Class Initialized
DEBUG - 2021-09-21 15:50:52 --> UTF-8 Support Enabled
INFO - 2021-09-21 15:50:52 --> Utf8 Class Initialized
INFO - 2021-09-21 15:50:52 --> URI Class Initialized
INFO - 2021-09-21 15:50:52 --> Router Class Initialized
INFO - 2021-09-21 15:50:52 --> Output Class Initialized
INFO - 2021-09-21 15:50:52 --> Security Class Initialized
DEBUG - 2021-09-21 15:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-21 15:50:52 --> Input Class Initialized
INFO - 2021-09-21 15:50:52 --> Language Class Initialized
INFO - 2021-09-21 15:50:52 --> Loader Class Initialized
INFO - 2021-09-21 15:50:52 --> Helper loaded: url_helper
INFO - 2021-09-21 15:50:52 --> Helper loaded: file_helper
DEBUG - 2021-09-21 15:50:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-21 15:50:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-21 15:50:52 --> Controller Class Initialized
INFO - 2021-09-21 15:50:52 --> Helper loaded: cookie_helper
INFO - 2021-09-21 15:50:52 --> Model "CookieModel" initialized
INFO - 2021-09-21 15:50:52 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-21 15:50:52 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-09-21 15:50:52 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-21 15:50:52 --> Final output sent to browser
DEBUG - 2021-09-21 15:50:52 --> Total execution time: 0.0375
INFO - 2021-09-21 15:56:38 --> Config Class Initialized
INFO - 2021-09-21 15:56:38 --> Hooks Class Initialized
DEBUG - 2021-09-21 15:56:38 --> UTF-8 Support Enabled
INFO - 2021-09-21 15:56:38 --> Utf8 Class Initialized
INFO - 2021-09-21 15:56:38 --> URI Class Initialized
INFO - 2021-09-21 15:56:38 --> Router Class Initialized
INFO - 2021-09-21 15:56:38 --> Output Class Initialized
INFO - 2021-09-21 15:56:38 --> Security Class Initialized
DEBUG - 2021-09-21 15:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-21 15:56:38 --> Input Class Initialized
INFO - 2021-09-21 15:56:38 --> Language Class Initialized
INFO - 2021-09-21 15:56:38 --> Loader Class Initialized
INFO - 2021-09-21 15:56:38 --> Helper loaded: url_helper
INFO - 2021-09-21 15:56:38 --> Helper loaded: file_helper
DEBUG - 2021-09-21 15:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-21 15:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-21 15:56:38 --> Controller Class Initialized
INFO - 2021-09-21 15:56:38 --> Helper loaded: cookie_helper
INFO - 2021-09-21 15:56:38 --> Model "CookieModel" initialized
INFO - 2021-09-21 15:56:38 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-21 15:56:38 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/gallery.php
INFO - 2021-09-21 15:56:38 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-21 15:56:38 --> Final output sent to browser
DEBUG - 2021-09-21 15:56:38 --> Total execution time: 0.0524
INFO - 2021-09-21 15:58:18 --> Config Class Initialized
INFO - 2021-09-21 15:58:18 --> Hooks Class Initialized
DEBUG - 2021-09-21 15:58:18 --> UTF-8 Support Enabled
INFO - 2021-09-21 15:58:18 --> Utf8 Class Initialized
INFO - 2021-09-21 15:58:18 --> URI Class Initialized
INFO - 2021-09-21 15:58:18 --> Router Class Initialized
INFO - 2021-09-21 15:58:18 --> Output Class Initialized
INFO - 2021-09-21 15:58:18 --> Security Class Initialized
DEBUG - 2021-09-21 15:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-21 15:58:18 --> Input Class Initialized
INFO - 2021-09-21 15:58:18 --> Language Class Initialized
INFO - 2021-09-21 15:58:18 --> Loader Class Initialized
INFO - 2021-09-21 15:58:18 --> Helper loaded: url_helper
INFO - 2021-09-21 15:58:18 --> Helper loaded: file_helper
DEBUG - 2021-09-21 15:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-21 15:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-21 15:58:18 --> Controller Class Initialized
INFO - 2021-09-21 15:58:18 --> Helper loaded: cookie_helper
INFO - 2021-09-21 15:58:18 --> Model "CookieModel" initialized
INFO - 2021-09-21 15:58:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-21 15:58:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/gallery.php
INFO - 2021-09-21 15:58:18 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-21 15:58:18 --> Final output sent to browser
DEBUG - 2021-09-21 15:58:18 --> Total execution time: 0.0510
INFO - 2021-09-21 15:58:27 --> Config Class Initialized
INFO - 2021-09-21 15:58:27 --> Hooks Class Initialized
DEBUG - 2021-09-21 15:58:27 --> UTF-8 Support Enabled
INFO - 2021-09-21 15:58:27 --> Utf8 Class Initialized
INFO - 2021-09-21 15:58:27 --> URI Class Initialized
INFO - 2021-09-21 15:58:27 --> Router Class Initialized
INFO - 2021-09-21 15:58:27 --> Output Class Initialized
INFO - 2021-09-21 15:58:27 --> Security Class Initialized
DEBUG - 2021-09-21 15:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-21 15:58:27 --> Input Class Initialized
INFO - 2021-09-21 15:58:28 --> Language Class Initialized
INFO - 2021-09-21 15:58:28 --> Loader Class Initialized
INFO - 2021-09-21 15:58:28 --> Helper loaded: url_helper
INFO - 2021-09-21 15:58:28 --> Helper loaded: file_helper
DEBUG - 2021-09-21 15:58:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-21 15:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-21 15:58:28 --> Controller Class Initialized
INFO - 2021-09-21 15:58:28 --> Helper loaded: cookie_helper
INFO - 2021-09-21 15:58:28 --> Model "CookieModel" initialized
INFO - 2021-09-21 15:58:28 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-21 15:58:28 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-09-21 15:58:28 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-21 15:58:28 --> Final output sent to browser
DEBUG - 2021-09-21 15:58:28 --> Total execution time: 0.0448
INFO - 2021-09-21 15:59:50 --> Config Class Initialized
INFO - 2021-09-21 15:59:50 --> Hooks Class Initialized
DEBUG - 2021-09-21 15:59:50 --> UTF-8 Support Enabled
INFO - 2021-09-21 15:59:50 --> Utf8 Class Initialized
INFO - 2021-09-21 15:59:50 --> URI Class Initialized
INFO - 2021-09-21 15:59:50 --> Router Class Initialized
INFO - 2021-09-21 15:59:50 --> Output Class Initialized
INFO - 2021-09-21 15:59:50 --> Security Class Initialized
DEBUG - 2021-09-21 15:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-21 15:59:50 --> Input Class Initialized
INFO - 2021-09-21 15:59:51 --> Language Class Initialized
INFO - 2021-09-21 15:59:51 --> Loader Class Initialized
INFO - 2021-09-21 15:59:51 --> Helper loaded: url_helper
INFO - 2021-09-21 15:59:51 --> Helper loaded: file_helper
DEBUG - 2021-09-21 15:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-21 15:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-21 15:59:51 --> Controller Class Initialized
INFO - 2021-09-21 15:59:51 --> Helper loaded: cookie_helper
INFO - 2021-09-21 15:59:51 --> Model "CookieModel" initialized
INFO - 2021-09-21 15:59:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-21 15:59:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/success_stories.php
INFO - 2021-09-21 15:59:51 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-21 15:59:51 --> Final output sent to browser
DEBUG - 2021-09-21 15:59:51 --> Total execution time: 0.0712
INFO - 2021-09-21 16:12:31 --> Config Class Initialized
INFO - 2021-09-21 16:12:31 --> Hooks Class Initialized
DEBUG - 2021-09-21 16:12:31 --> UTF-8 Support Enabled
INFO - 2021-09-21 16:12:31 --> Utf8 Class Initialized
INFO - 2021-09-21 16:12:31 --> URI Class Initialized
DEBUG - 2021-09-21 16:12:31 --> No URI present. Default controller set.
INFO - 2021-09-21 16:12:31 --> Router Class Initialized
INFO - 2021-09-21 16:12:31 --> Output Class Initialized
INFO - 2021-09-21 16:12:31 --> Security Class Initialized
DEBUG - 2021-09-21 16:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-21 16:12:31 --> Input Class Initialized
INFO - 2021-09-21 16:12:31 --> Language Class Initialized
INFO - 2021-09-21 16:12:31 --> Loader Class Initialized
INFO - 2021-09-21 16:12:31 --> Helper loaded: url_helper
INFO - 2021-09-21 16:12:31 --> Helper loaded: file_helper
DEBUG - 2021-09-21 16:12:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-21 16:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-21 16:12:31 --> Controller Class Initialized
INFO - 2021-09-21 16:12:31 --> Helper loaded: cookie_helper
INFO - 2021-09-21 16:12:31 --> Model "CookieModel" initialized
INFO - 2021-09-21 16:12:31 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-21 16:12:31 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-09-21 16:12:31 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-21 16:12:31 --> Final output sent to browser
DEBUG - 2021-09-21 16:12:31 --> Total execution time: 0.0509
INFO - 2021-09-21 16:12:31 --> Config Class Initialized
INFO - 2021-09-21 16:12:31 --> Hooks Class Initialized
DEBUG - 2021-09-21 16:12:31 --> UTF-8 Support Enabled
INFO - 2021-09-21 16:12:31 --> Utf8 Class Initialized
INFO - 2021-09-21 16:12:31 --> URI Class Initialized
DEBUG - 2021-09-21 16:12:32 --> No URI present. Default controller set.
INFO - 2021-09-21 16:12:32 --> Router Class Initialized
INFO - 2021-09-21 16:12:32 --> Output Class Initialized
INFO - 2021-09-21 16:12:32 --> Security Class Initialized
DEBUG - 2021-09-21 16:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-21 16:12:32 --> Input Class Initialized
INFO - 2021-09-21 16:12:32 --> Language Class Initialized
INFO - 2021-09-21 16:12:32 --> Loader Class Initialized
INFO - 2021-09-21 16:12:32 --> Helper loaded: url_helper
INFO - 2021-09-21 16:12:32 --> Helper loaded: file_helper
DEBUG - 2021-09-21 16:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-21 16:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-21 16:12:32 --> Controller Class Initialized
INFO - 2021-09-21 16:12:32 --> Helper loaded: cookie_helper
INFO - 2021-09-21 16:12:32 --> Model "CookieModel" initialized
INFO - 2021-09-21 16:12:32 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/header.php
INFO - 2021-09-21 16:12:32 --> File loaded: E:\xampp\htdocs\changeme\application\views\user/index.php
INFO - 2021-09-21 16:12:32 --> File loaded: E:\xampp\htdocs\changeme\application\views\layout/footer.php
INFO - 2021-09-21 16:12:32 --> Final output sent to browser
DEBUG - 2021-09-21 16:12:32 --> Total execution time: 0.0766
