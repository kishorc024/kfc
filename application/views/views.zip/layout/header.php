<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="description" content="<?= $meta_description; ?>">
    <meta name="keywords" content="<?= $meta_keywords; ?>">
    <title><?= $meta_title; ?></title>
    <meta property="og:title" content="<?= $meta_title; ?>" />
    <meta property="og:description" content="<?= $meta_description; ?>" />
    <meta property="og:image" content="<?= $meta_image; ?>" />
    <meta property="og:url" content="<?= $meta_url; ?>" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <link
        href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&amp;display=swap"
        rel="stylesheet">


    <link rel="stylesheet" href="<?= base_url();?>assets/css/bootstrap.min.css">

    <link rel="stylesheet" href="<?= base_url();?>assets/css/jquery-ui.css">

    <link rel="stylesheet" href="<?= base_url();?>assets/css/font-awesome.min.css">

    <link rel="stylesheet" href="<?= base_url();?>assets/css/flaticon/flaticon.css">

    <link rel="stylesheet" href="<?= base_url();?>assets/fonts/fontawesome-5/css/all.min.css">

    <link rel="stylesheet" href="<?= base_url();?>assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="<?= base_url();?>assets/css/owl.theme.default.min.css">

    <link rel="stylesheet" href="<?= base_url();?>assets/css/jquery.fancybox.min.css" />

    <link rel="stylesheet" href="<?= base_url();?>assets/css/animate.css">

    <link rel="stylesheet" href="<?= base_url();?>assets/css/stellarnav.min.css">

    <link rel="stylesheet" href="<?= base_url();?>assets/css/style.css">

    <link rel="shortcut icon" type="image/png" href="<?= base_url();?>assets/images/favicon.ico">

    <style>
    @media screen and (max-width:480px){
    .main {
        display: flex;
        flex-direction: column-reverse;
    }
    .ocb-text2-area {
    position: relative;
    margin: auto 0px;
}
.rf-logo{
    align:center;
    width:202px;
    height:50px;
    margin-top:25px;
}
}
</style>
   
</head>

<body>

    <header class="header-area rexfit-header">
        <div class="rf-navbar">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-3">
                        <div class="rf-logo">
                            <a href="<?= base_url();?>">
                            <img src="<?= base_url();?>assets/images/logo.png" alt="">
                        </a>
                            
                        </div>
                    </div>
                    <div class="col-9">
                        <div class="stellarnav rexfit-nav navSlideOnly " style="margin-top:25px">
                            <ul>
                                
                                <li><a href="<?= base_url();?>">Home</a></li>
                                <li><a href="<?= base_url('pilates');?>">Pilates</a></li>
                                <li><a href="<?= base_url('services/#functional_training');?>">Functional Training</a></li>
                                <li><a href="<?= base_url('services/#nutrition_coaching');?>">Nutrition Coaching</a></li>
                                <li><a href="<?= base_url('success_stories');?>">Success Stories</a></li>
                                <li><a href="<?= base_url('about/team');?>">About</a>
                                    <ul>
                                        <li><a href="<?= base_url('about/team');?>">Meet The Team</a></li>
                                        <li><a href="<?= base_url('about/gallery');?>">Gallery</a></li>                                        
                                        <li><a href="<?= base_url('contact');?>">Contact Us</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>