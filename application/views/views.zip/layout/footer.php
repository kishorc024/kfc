<footer class="footer-area">
    <div class="footer-widget-area">
        <div class="container">
            <div class="row">
                <div class="col-md-5">
                    <div class="footer-widget footer-log-text">
                        <div class="footer-logo">
                            <!-- <img src="<?= base_url();?>assets/images/logo.png" alt=""> -->
                            <h3 style="color:white">CHANGE ME FUNCTIONAL TRAINING AND PILATES STUDIO</h3>
                        </div>
                        <div class="footer-text">
                            <p>A PLACE WHERE FITNESS BECOMES THE BEST PART OF YOUR DAY!</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="footer-widget">
                            <h4>Menu</h4>
                                <ul class="flinks">
                                    <li><a href="<?= base_url();?>">HOME</a></li>
                                    <li><a href="<?= base_url('pilates');?>">PILATES</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-md-9">
                            <div class="footer-widget">
                            <h4>Menu</h4>
                                <ul class="flinks">
                                    <li><a href="<?= base_url('services/#functional_training');?>">FUNCTIONAL
                                            TRAINING</a></li>
                                    <li><a href="<?= base_url('services/#nutrition_coaching');?>">NUTRITION COACHING</a>
                                    </li>
                                </ul>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="col-md-3">
                    
                    <div class="footer-widget">
                        <h4>Contact Us</h4>
                        <ul class="flinks">
                            <li><a style="font-size:20px" href="tel:+91 8080064746"> +91 8080064746</a></li>
                            <li><a style="font-size:20px" href="tel:+91 9834484160"> +91 9834484160</a></li>
                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <div class="footer-copyright">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="copyright-text">
                        <p>© All Rights Reserved By ChangeMe</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>

<script src="<?= base_url();?>assets/js/jquery-3.2.0.min.js"></script>

<script src="<?= base_url();?>assets/js/jquery-ui.js"></script>

<script src="<?= base_url();?>assets/js/jquery-migrate-3.0.1.js"></script>
<script src="<?= base_url();?>assets/js/jquery.min.js"></script>

<script src="<?= base_url();?>assets/js/jquery.mobile.custom.min.js"></script>

<script src="<?= base_url();?>assets/js/owl.carousel.min.js"></script>

<script src="<?= base_url();?>assets/js/jquery.counterup.min.js"></script>

<script src="<?= base_url();?>assets/js/countdown.js"></script>

<script src="<?= base_url();?>assets/js/stellarnav.min.js"></script>

<script src="<?= base_url();?>assets/js/jquery.scrollUp.js"></script>

<script src="<?= base_url();?>assets/js/jquery.waypoints.min.js"></script>

<script src="<?= base_url();?>assets/js/shuffle.min.js"></script>

<script src="<?= base_url();?>assets/js/jquery.fancybox.min.js"></script>

<script src="<?= base_url();?>assets/fonts/fontawesome-5/js/all.min.js"></script>

<script src="<?= base_url();?>assets/js/wow.min.js"></script>

<script src="<?= base_url();?>assets/js/bootstrap.min.js"></script>

<script src="<?= base_url();?>assets/js/theme.js"></script>
</body>

</html>