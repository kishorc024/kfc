<section class="page-title-area">
    <div class="pta-bg">
        <img src="<?= base_url();?>assets/img/bg/pta-1.jpg" alt="">
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="page-titleV1">
                    <h2>GALLERY</h2>
                </div>
            </div>
        </div>
        
    </div>
</section>


<section class="gallery-area section-padding">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="single-gallery-V1">
                    <div class="sg-img">
                    <a data-fancybox="gallery" href="<?= base_url();?>assets/images/gallery/gallery1.jpg">
                        <img src="<?= base_url();?>assets/images/gallery/gallery1.jpg" alt="">
                    </a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="single-gallery-V1">
                <div class="sg-img">
                    <a data-fancybox="gallery" href="<?= base_url();?>assets/images/gallery/gallery2.jpg">
                        <img src="<?= base_url();?>assets/images/gallery/gallery2.jpg" alt="">
                    </a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="single-gallery-V1">
                <div class="sg-img">
                    <a data-fancybox="gallery" href="<?= base_url();?>assets/images/gallery/gallery3.jpg">
                        <img src="<?= base_url();?>assets/images/gallery/gallery3.jpg" alt="">
                    </a>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
</section>