<section class="page-title-area">
    <div class="pta-bg">
        <img src="<?= base_url();?>assets/img/bg/pta-1.jpg" alt="">
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="page-titleV1">
                    <h2>Success Stories</h2>
                </div>
            </div>
        </div>
        
    </div>
</section>

<section class="services-area section-padding">
    <div class="container">
<!-- 
    <div class="row">
        <div class="col-md-6 single-servicesV1">
        <p>For me, fitness part of my everyday
                            life fitness does mean having big
                            musclese mean being active, quick
                            and flexible can be defin.</p>
                            <h4>Geeta Patel</h4>
        </div>
        <div class="col-md-6">
            
        </div>
        <div class="col-md-6">
            
        </div>
        <div class="col-md-6">
            
        </div>
    </div> -->

        <div class="row">
            <div class="col-md-4">
                <div class="single-servicesV1">
                <img src="<?= base_url();?>assets/images/personal.jpg" alt="">
                    <div class="ss-text">
                        <p>" At the age of 15, My sister Seetal Patel met an car accident while riding a bicycle 
                            and was one month in coma. Since my left shoulder was hurt and in frozen condition, 
                            my parents took me to various hospitals and physiotherapy at Nasik and Mumbai for almost eight years but could not get 
                            recovered. Since I heard about Change Me provides advance physiotherapy exercises, 
                            I took my sister who has completely recovered in 8 days with Pilates rehab workouts. Thank you for such a wonderful job. 
                            Change Me really changed my sister. "</p>
                            <h4 >Geeta Patel</h4>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="single-servicesV1">
                <img src="<?= base_url();?>assets/images/personal.jpg" alt="">
                    <div class="ss-text">
                        <p>" Does justice to its name "Change Me". Not at all like a traditional gym, bit more of a modern and scientific 
                            approach towards changing the way you treat your body. And the results show, helps you to adapt a healthy lifestyle. 
                            Must try for everyone who values healthy lifestyle. "</p>
                            <h4 >Ajit Vaidya</h4>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="single-servicesV1">
                <img src="<?= base_url();?>assets/images/personal.jpg" alt="">
                    <div class="ss-text">
                        <p>" ‘Change Me’ is not just any gymnasium. It is feather in cap of fitness industry of Kolhapur. Fitness enthusiastic people should GO for it . It has dedicated Pilates studio of international standards. It has all other conventional features of gym.
Mr. Sanjeev is skilled towering key person & ardent trainer of this gym . Miss Sakshi is nutritionist & women trainer of difference. It has other well trained staff also.
I got good results of my own short stint of 12 sessions of Pilates & fitness combo . My backache reduced. I had sour muscles couple of days after heating weights but found good healthy morning trek routine afterwards. "</p>
                            <h4 >Dr. Priyadarshi Ghodke</h4>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="single-servicesV1">
                <img src="<?= base_url();?>assets/images/personal.jpg" alt="">
                    <div class="ss-text">
                        <p>"Change Me has helped me achieve my long pending goal of weight loss. Before Change Me I kept on switching gyms to find one which delivers it’s promised results but had always faced with disappointment but Change Me not only delivered what it promised but it also made me fall in love with my workouts and keep it interesting. They provide diet consultation as well, which is very convenient as I don’t have to consult for diet and workout with different people. "</p>
                            <h4 >Rhutesh Patil</h4>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="single-servicesV1">
                <img src="<?= base_url();?>assets/images/personal.jpg" alt="">
                    <div class="ss-text">
                        <p>" Best gym in kolhapur with highly qualified trainers and the workouts are designed according to the client’s needs. Here the ambience is very homely and very safe. It is well maintained and proper sanitization and all precautions are taken care of. I can surely say that this is the best gym one can join to get transformed!!! "</p>
                            <h4 >Devika Narake</h4>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="single-servicesV1">
                <img src="<?= base_url();?>assets/images/personal.jpg" alt="">
                    <div class="ss-text">
                        <p>" This is the best place for all types of workouts. New workout every single day and very friendly environment. Also my experience with pilates has been great. It literally lifted my personality and improved my body posture. Also the only gym in kolhapur having pilates. I really thank the whole team to take all these efforts for our fitness. Once u start doing these workouts you'll never feel like quitting. Literally love working out at this place❤💯 "</p>
                            <h4 >Kanupriya Ranbhare</h4>
                    </div>
                </div>
            </div>
            <div class="col-md-4 ">
                <div class="single-servicesV1">
                <img src="<?= base_url();?>assets/images/personal.jpg" alt="">
                    <div class="ss-text">
                        <p>" This gym is amazing. Amazing facility, top equipment and great environment. Lost around 10 kgs weight within 2 months. Body becomes agile and athletic. Good service with friendly staff, super clean, lots of attention towards hygiene. I would surely recommend change me from beginners to professional athletes to train at.
Thanks to Sanjeev Sir, Sakshi and change me team.  "</p>
                            <h4 >Rajvardhan Sarnobat
</h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>