
<section class="page-title-area">
    <div class="pta-bg">
        <img src="<?= base_url();?>assets/img/bg/pta-1.jpg" alt="">
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="page-titleV1">
                    <h2>PILATES</h2>
                </div>
            </div>
        </div>
        
    </div>
</section>

<section class="fitness-video section-padding">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                    <div class="ocb-img ">
                        <img src="<?= base_url();?>assets/images/pilates/p-1.jpg" alt="">
                    </div>
            </div>
            <div class="col-md-6 ">
                <div class="ocb-text2-area">
                    <div class="ocb-title">
                        <h3>PILATES</h3>
                    </div>
                    <div class="ocb-text">
                        <p>Pilates is a method of exercise that consists of low-impact flexibility and muscular strength and
                             endurance movements. Pilates emphasizes proper postural alignment, core strength and muscle balance.</p>
                    </div>
                </div>
            </div>
        </div>
        <br>
        <div class="row main">
            
            <div class="col-md-6 " >
                <div class="ocb-text2-area">
                    <div class="ocb-title">
                        <h3>PHYSIO PILATES</h3>
                    </div>
                    <div class="ocb-text">
                        <p>Physio Pilates is a unique blend of Pilates and core exercises offered under the direct supervision
                             of a physiotherapist, either individually or in small groups. Those familiar with the Pilates Method 
                             will recognize exercises designed to improve mobility and strength, optimize core muscle recruitment, 
                             and enhance athletic performance. Physio Pilates begins with an assessment during which the best 
                             exercises are chosen to suit your body, injuries, and fitness goals.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="">
                    <div class="ocb-img">
                        <img src="<?= base_url();?>assets/images/pilates/p-2.jpg" alt="">
                    </div>
                </div>
            </div>
        </div>
        <br>
        <div class="row">
            <div class="col-md-6">
                <div class="">
                    <div class="ocb-img" >
                        <img src="<?= base_url();?>assets/images/pilates/p-3.jpg" alt="">
                    </div>
                </div>
            </div>
            <div class="col-md-6 " >
                <div class="ocb-text2-area">
                    <div class="ocb-title">
                        <h3>PRENATAL </h3>
                    </div>
                    <div class="ocb-text">
                        <p>Pilates are ideal exercises if you’re trying to get pregnant, since they build strength, balance, endurance and muscle tone all things that will help your conception efforts. 
                            Yoga, in particular, is designed to help you relax, which is especially important when you’re trying to conceive.</p>
                    </div>
                </div>
            </div>
        </div>
        <br>
        <div class="row main">
            
            <div class="col-md-6 " >
                <div class="ocb-text2-area">
                    <div class="ocb-title">
                        <h3>POST NATAL</h3>
                    </div>
                    <div class="ocb-text">
                        <p>Pilates can help your strengthen your abdominal wall, reducing your ‘pregnancy tummy’ regain the good posture you’ll need to nurse and carry your baby around. 
                            strengthen your arm muscles, so you can lift and carry your baby more easily.</p>
                        <p>Postnatal Pilates is one of the best forms of self-care moms can do, promoting total-body alignment, better posture and enhanced awareness of your “new” post-baby body, which work hand in hand to prevent issues like lower-back pain and shoulder and neck tensions. 
</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="">
                    <div class="ocb-img " >
                        <img src="<?= base_url();?>assets/images/pilates/p-4.jpg" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


