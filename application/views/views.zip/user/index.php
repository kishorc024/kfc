<style>
.parallax {
    padding-top: 200px;
    padding-bottom: 200px;
    overflow: hidden;
    position: relative;
    width: 100%;
    background-image: url(assets/images/gallery/gallery3.jpg);
    background-attachment: fixed;
    background-size: cover;
    -moz-background-size: cover;
    -webkit-background-size: cover;
    background-repeat: no-repeat;
    background-position: top center;
}

.parallax .parallax-text p{
    text-align:center;
    color:white;
    font-size: 45px;
    line-height: 60px;
    text-transform: capitalize;
    font-weight: 600;
}


.centered {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background-color:#3a3a3a;
  opacity: .7;
  padding:15px;
}
.img-title{
    color:white;font-weight:800;font-size:28px

}
@media screen and (max-width:480px) {
    .img-title{
    color:white;font-weight:200;font-size:14px

} 
.parallax .parallax-text p{
    text-align:center;
    color:white;
    font-size: 15px;
    line-height: 30px;
    text-transform: capitalize;
    font-weight: 200;
}  
}
</style>
<section class="hero-area hero_V3">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="hero1-carousel owl-carousel owl-theme">
                    <div class="item">
                        <div class="hero-content">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="hero-text">
                                        <p>A PLACE WHERE FITNESS BECOMES THE BEST PART OF YOUR DAY!</p>
                                        <div class="hero-btn">
                                            <a href="https://wa.link/z1pj9c" target="_blank" class="hero3-btn"
                                                style="border:solid 1px red; background-color:red;">Contact Us</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="hero-img">
                                        <!-- <img src="assets/img/section-img/hero-3-img.png" alt=""> -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>


<br>

<section class="our-new-classes-area">
    <div class="container-fluid">
        <br>
        <div class="row">

            <div class="col-md-4 " >

                <div class="single-classes">
                    <div class="scs-img">
                        <a href="<?= base_url('pilates');?>"> <img
                                src="<?= base_url();?>assets/images/services/pilates.jpg" alt="">
                                <div class="centered"><h4 class="img-title">PILATES</h4></div></a>
                    </div>
                    
                </div>
            </div>
            <div class="col-md-4 ">
                <div class="single-classes">
                    <div class="scs-img">
                        <a href="<?= base_url('services/#functional_training');?>"> <img
                                src="<?= base_url();?>assets/images/services/functional_training.jpg" alt="">
                                <div class="centered"><h4 class="img-title">FUNCTIONAL TRAINING</h4></div></a>
                    </div>
                   
                </div>
            </div>
            <div class="col-md-4 " >
                <div class="single-classes">
                    <div class="scs-img">
                    <a href="<?= base_url('services/#nutrition_coaching');?>"> 
                    <img src="<?= base_url();?>assets/images/services/nutrition_coaching.jpg" alt="">
                        <div class="centered"><h4 class="img-title">NUTRITION COACHING</h4></div></a>
                    </div>
                    
                </div>
            </div>

        </div>
    </div>
</section>
<section>
    <div class="parallax">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 " >
                    <!-- <h4>Definition of a really good workout - <br>
                    When you hate doing it but love finishing it. 
                </h4> -->

                <div class="parallax-text">
                                        <p>Definition of a really good workout - <br>
                    " When you hate doing it but love finishing it. "</p>
                                    </div>
                </div>
                <!-- <div class="col-lg-5">
                    <img src="<?= base_url('assets/images/changemelogo.png');?>" alt="" class="img-fluid">
                </div> -->
            </div>
        </div>
    </div>
</section>

<section class="" style="background-color:#F1F1F1">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="section-titleV1">
                    <h3>Member Testimonials</h3>

                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="single-testimonial">
                                <p style="min-height:400px">“ At the age of 15, My sister Seetal Patel met an car
                                    accident while riding a bicycle and was one month in coma.
                                    Since my left shoulder was hurt and in frozen condition, my parents took me to
                                    various hospitals and physiotherapy
                                    at Nasik and Mumbai for almost eight years but could not get recovered.
                                    Since I heard about <span> ‘Change Me’ </span> provides advance physiotherapy
                                    exercises,
                                    I took my sister who has completely recovered in 8 days with Pilates rehab workouts.
                                    Thank you for such a wonderful job. Change Me really changed my sister. ”</p>
                                <h4>Geeta Patel</h4>
                                <hr>
                            </div>
                        </div>

                        <div class="col-lg-6">
                            <div class="single-testimonial">
                                <p style="min-height:400px">“ <span> ‘Change Me’ </span>is not just any gymnasium. It is
                                    feather in cap of fitness industry of Kolhapur.
                                    Fitness enthusiastic people should GO for it . It has dedicated Pilates studio of
                                    international standards.
                                    It has all other conventional features of gym.
                                    Mr. Sanjeev is skilled towering key person & ardent trainer of this gym . Miss
                                    Sakshi is nutritionist & women trainer of difference. It has other well trained
                                    staff also.
                                    I got good results of my own short stint of 12 sessions of Pilates & fitness combo .
                                    My backache reduced. I had sour muscles couple of days after heating weights but
                                    found good healthy morning trek routine afterwards. ”</p>
                                <h4>Dr. Priyadarshi Ghodke</h4>
                                <hr>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="single-testimonial">
                                <p style="min-height:300px">“ <span> ‘Change Me’ </span> has helped me achieve my long
                                    pending goal of weight loss. Before Change Me I kept on switching gyms to find one
                                    which delivers it’s promised results but had always faced with disappointment but
                                    Change Me not only delivered what it promised but it also made me fall in love with
                                    my workouts and keep it interesting. They provide diet consultation as well, which
                                    is very convenient as I don’t have to consult for diet and workout with different
                                    people. ”</p>
                                <h4>Rhutesh Patil</h4>
                                <hr>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="single-testimonial">
                                <p style="min-height:300px">“ Best gym in kolhapur with highly qualified trainers and
                                    the workouts are designed according to the client’s needs. Here the ambience is very
                                    homely and very safe. It is well maintained and proper sanitization and all
                                    precautions are taken care of. I can surely say that this is the best gym one can
                                    join to get transformed!!! ”</p>

                                <h4>Devika Narake</h4>
                                <hr>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="single-testimonial">
                                <p style="min-height:300px">“ This is the best place for all types of workouts. New
                                    workout every single day and very friendly environment. Also my experience with
                                    pilates has been great. It literally lifted my personality and improved my body
                                    posture. Also the only gym in kolhapur having pilates. I really thank the whole team
                                    to take all these efforts for our fitness. Once u start doing these workouts you'll
                                    never feel like quitting. Literally love working out at this place❤💯 ”</p>
                                <h4>Kanupriya Ranbhare</h4>
                                <hr>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="single-testimonial">
                                <p style="min-height:300px">“ This gym is amazing. Amazing facility, top equipment and
                                    great environment. Lost around 10 kgs weight within 2 months. Body becomes agile and
                                    athletic. Good service with friendly staff, super clean, lots of attention towards
                                    hygiene. I would surely recommend change me from beginners to professional athletes
                                    to train at.
                                    Thanks to Sanjeev Sir, Sakshi and change me team. ”</p>
                                <h4>Rajvardhan Sarnobat</h4>
                                <hr>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>