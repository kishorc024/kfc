<section class="page-title-area">
    <div class="pta-bg">
        <img src="<?= base_url();?>assets/img/bg/pta-1.jpg" alt="">
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="page-titleV1">
                    <h2>MEET OUR TEAM</h2>
                </div>
            </div>
        </div>
        
    </div>
</section>

<section class="fitness-video section-padding" id="functional_training">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6 text-center">
                
                        <img src="<?= base_url();?>assets/images/t-1.jpg" alt="" style="width:auto">
            </div>
            <div class="col-md-6 ">
                <div class="ocb-text2-area">
                    <div class="ocb-title">
                    <h3>Sanjeev Kalkunde</h3>
                        <h5>Founder</h5>
                    </div>
                    <div class="ocb-text">
                        <p>His great passion for fitness gave him a opportunity to work with the Royal families in United Arab Emirates and Carnival Cruise Lines in USA. With a work experience of 23 years overseas, Sanjeev came with a dream to set up his own fitness hub in the city of wrestlers. He introduced the lastest trends of exercise such as functional training in 2016 and established the first Pilates studio in 2019 to add on to the fitness culture in Kolhapur.  </p>
                        
                    </div>
                </div>
            </div>
        </div>
        <br><br>
        <div class="row main">
            
            <div class="col-md-6 ">
                <div class="ocb-text2-area">
                    <div class="ocb-title">
                    <h3>Sakshi Kalkunde</h3>
                        <h5>CEO</h5>
                    </div>
                    <div class="ocb-text">
                        <p>Sakshi is a Certified Fitness Trainer, Pilates Trainer, Dance Fitness expert and Nutritionist. She started her career at the mere age of 14 and by 16 was the youngest in her batch to be certified. Her aim is to make accessible high end workout programs and be in line with the current fitness trends. </p>
                        
                    </div>
                </div>
            </div>
            <div class="col-md-6 text-center">
                        <img src="<?= base_url();?>assets/images/t-1.jpg" alt="">
                        
            </div>
        </div>
        <br><br>
        <div class="row">
        <div class="col-md-6 text-center">
                        <img src="<?= base_url();?>assets/images/t-1.jpg" alt="">
                        
            </div>
            <div class="col-md-6 ">
                <div class="ocb-text2-area" >
                    <div class="ocb-title">
                    <h3>Santosh Patil</h3>
                        <h5>Trainer</h5>
                    </div>
                    <div class="ocb-text">
                        <p>With hard work, dedication and determination, Santosh earned a gold medal in the All India University Men's Physique competition in 2019.  </p>
                        
                    </div>
                </div>
            </div>
        </div>
        <br><br>
        <div class="row main">
            
            <div class="col-md-6 ">
                <div class="ocb-text2-area">
                    <div class="ocb-title">
                    <h3>Sagar</h3>
                        <h5>Fighting Skills Pro Trainer</h5>
                    </div>
                    <div class="ocb-text">
                        <p>Sagar has earned 2 gold & 3 silver medals at National level and 8 gold, 4 silver & 2 bronze medals at State level in Taekwondo. </p>
                        
                    </div>
                </div>
            </div>
            <div class="col-md-6 text-center">
                        <img src="<?= base_url();?>assets/images/t-1.jpg" alt="">
                        
            </div>
        </div>
        <br><br>
        <div class="row">
        <div class="col-md-6 text-center">
                        <img src="<?= base_url();?>assets/images/t-1.jpg" alt="">
                        
            </div>
            <div class="col-md-6 ">
                <div class="ocb-text2-area">
                    <div class="ocb-title">
                    <h3>Akshay Mane</h3>
                        <h5>Trainer</h5>
                    </div>
                    <div class="ocb-text">
                        <p>He has won several marathons and has been in the fitness industry for more than 10 years. </p>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

