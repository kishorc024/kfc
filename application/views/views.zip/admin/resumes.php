<div class="page-wrapper">
    <div class="content">
        <div class="row">
            <div class="col-lg-4">
                <h4 class="page-title">Resumes (<?= sizeof($result); ?>)</h4>
            </div>
		
            <div class="col-lg-3">
                <input type="text" value="" id="search" name="search" onkeyup="mySearch()" class="form-control pull-right" autocomplete="off" placeholder="Search">
            </div>
            <div class="col-lg-2 text-right m-b-20">
               
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="table-responsive">
                    <table class="table table-striped custom-table" id="myTable">
                        <thead>
                            <tr>
                                <th class="text-center">Action</th>
                                <th class="text-center">No</th>
                                <th class="text-center">Candidate Details</th>
                                <th class="text-center">Resumes</th>
                                
                                <!-- <th></th> -->
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $count = 1;
                            foreach ($result as $row) {
                                ?>
                            <tr>
                                <td class="text-center" style="width:100px;">
                                    
                                    <a href="<?= base_url('admin/deleteresume/' . $row->id); ?>"
                                        style="color:red;" title="click to delete"
                                        onclick="return confirm('Sure to delete?');"><i class="material-icons">
                                            delete
                                        </i></a>
                                </td>
                                <td class="text-center"><?= $count; ?></td>                                
                                
                                
                                <td class="text-center">
									<?= $row->name ." - ". $row->phone ."<br>".$row->email; ?> 
								</td>
                                <td class="text-center">
									<a class="text-center" href="<?= base_url('resumes/'.$row->filename.'.pdf'); ?>" title="View Resume" target="_blank">
                                    <img src="<?= base_url('assets/admin/pdf-icon.png');?>" alt="Resume" width="50" height="50">
									</a>
								</td>
                            </tr>
                            <?php ++$count;
                            } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function publish(id)
	{
        $.ajax({
            url   : '<?php echo base_url('admin/publishdoctor/')?>' + id,
            success: function (data) {
                if(data == "success")
                {
                    document.getElementById("publish_" + id).style.display="none";
                    document.getElementById("unpublish_" + id).style.display="block";
                }
            },
            cache: false
        }).fail(function (jqXHR, textStatus, error) {
        });
	}

	function unpublish(id)
	{
        $.ajax({
            url   : '<?php echo base_url('admin/unpublishdoctor/')?>' + id,
            success: function (data) {
                if(data == "success")
                {
                    document.getElementById("unpublish_" + id).style.display="none";
                    document.getElementById("publish_" + id).style.display="block";
                }
            },
            cache: false
        }).fail(function (jqXHR, textStatus, error) {
        });
	}
</script>
