<div class="page-wrapper">
    <div class="content">
        <div class="row">
            <div class="col-sm-12">
                <h4 class="page-title">Dashboard</h4>
            </div>
            <div class="col-sm-12">
			
			
			</div>		
        </div>
    </div>
</div>
